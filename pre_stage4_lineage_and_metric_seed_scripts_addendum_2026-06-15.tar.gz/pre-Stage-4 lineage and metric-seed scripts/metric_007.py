#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jan 11 17:32:59 2026

@author: dakini

metric_007.py  — Stage 1 diagnostics
-----------------------------------
Reads eigenshell NPZ artifacts produced by metric_003/004/005/006 and computes:

(1) Frame transport between adjacent shells using orthogonal Procrustes:
      R_k  ~  V_{k+1}^T V_k  (then re-orthogonalized by SVD)

(2) Commutator (local non-commutativity) between consecutive transports:
      C_k = R_{k+1} R_k - R_k R_{k+1}
      comm_norm[k] = ||C_k||_F

(3) Cumulative holonomy across shells:
      H = Π_k R_k
      hol_dev = ||H - I||_F
      hol_angles = angles of eigenvalues of H (principal arguments)

(4) QC-style dilatation proxy from the leading 2×2 block of each transport:
      A2 = R_k[:2,:2]
      s1 >= s2 singular values of A2
      K = s1/s2  (>=1)
      mu = (K-1)/(K+1)  (Beltrami-like proxy)

Outputs:
  metric_007_outputs/metric_007__<srcfile_stem>.npz
  plots/metric_007/<srcfile_stem>__comm_norm.png
  plots/metric_007/<srcfile_stem>__K_dilatation.png

Usage:
  python metric_007.py
  python metric_007.py --metric_tag metric_006
  python metric_007.py --fit NUFIT --preprocess zscore --dm32 signed
  python metric_007.py --all

Assumptions:
- Input NPZ contains per-shell eigenvectors V[shell, d, d] or V[shell, d, r]
- If V is not square, we transport within the available subspace r.
"""

from __future__ import annotations

import os
import re
import glob
import argparse
import numpy as np
import matplotlib.pyplot as plt


# -------------------------
# Paths / conventions
# -------------------------

INPUT_DIR = "metric_007_inputs"
OUTPUT_DIR = "metric_007_outputs"
PLOTS_DIR = os.path.join("plots", "metric_007")

NPZ_GLOB = os.path.join(INPUT_DIR, "eigshells__metric_*__*.npz")


# -------------------------
# Utilities
# -------------------------

def ensure_dirs() -> None:
    os.makedirs(INPUT_DIR, exist_ok=True)
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    os.makedirs(PLOTS_DIR, exist_ok=True)


def _as_str(x) -> str:
    try:
        return str(x)
    except Exception:
        return repr(x)


def parse_filename_meta(path: str) -> dict:
    """
    Parse filenames like:
      eigshells__metric_006__NUFIT__zscore__signed.npz
    Returns dict with: metric_tag, fit, preprocess, dm32, stem
    """
    base = os.path.basename(path)
    stem = base[:-4] if base.endswith(".npz") else base

    # Default fallbacks
    meta = {"metric_tag": None, "fit": None, "preprocess": None, "dm32": None, "stem": stem}

    m = re.match(r"eigshells__(metric_\d+)__([^_]+)__([^_]+)__([^_]+)\.npz$", base)
    if m:
        meta["metric_tag"] = m.group(1)
        meta["fit"] = m.group(2)
        meta["preprocess"] = m.group(3)
        meta["dm32"] = m.group(4)
    return meta


def discover_inputs(metric_tag: str | None,
                    fit: str | None,
                    preprocess: str | None,
                    dm32: str | None) -> list[str]:
    paths = sorted(glob.glob(NPZ_GLOB))
    out = []
    for p in paths:
        meta = parse_filename_meta(p)
        if metric_tag and meta["metric_tag"] != metric_tag:
            continue
        if fit and meta["fit"] != fit:
            continue
        if preprocess and meta["preprocess"] != preprocess:
            continue
        if dm32 and meta["dm32"] != dm32:
            continue
        out.append(p)
    return out



def load_eigshells_npz(path: str):
    z = np.load(path, allow_pickle=True)

    if "eigvecs" not in z.files:
        raise ValueError(f"[{path}] Expected key 'eigvecs' not found. Keys: {z.files}")
    V = z["eigvecs"]

    evals = z["eigvals"] if "eigvals" in z.files else None

    payload = {k: z[k] for k in z.files}
    payload["_metric007_detected_V_key"] = np.array(["eigvecs"], dtype=object)
    payload["_metric007_detected_evals_key"] = np.array(["eigvals" if "eigvals" in z.files else None], dtype=object)

    return V, evals, payload


# def load_eigshells_npz(path: str) -> tuple[np.ndarray, np.ndarray | None, dict]:
#     """
#     Robustly load eigenvectors cube and eigenvalues matrix from an NPZ,
#     without assuming exact key names.
#     Returns (V, evals_or_None, payload_dict)
#     """
#     z = np.load(path, allow_pickle=True)
#     payload = {k: z[k] for k in z.files}

#     # Heuristic: eigenvectors likely 3D: (S, d, r) or (S, d, d)
#     # Choose the largest 3D array by total size.
#     candidates_3d = []
#     for k, a in payload.items():
#         if isinstance(a, np.ndarray) and a.ndim == 3 and a.size > 0:
#             candidates_3d.append((a.size, k, a))
#     if not candidates_3d:
#         keys = ", ".join(payload.keys())
#         raise ValueError(f"[{path}] Could not find a 3D eigenvector array. Keys: {keys}")

#     candidates_3d.sort(reverse=True, key=lambda t: t[0])
#     V_key = candidates_3d[0][1]
#     V = candidates_3d[0][2]

#     # Heuristic: eigenvalues likely 2D: (S, r) or (S, d)
#     candidates_2d = []
#     for k, a in payload.items():
#         if isinstance(a, np.ndarray) and a.ndim == 2 and a.shape[0] == V.shape[0]:
#             candidates_2d.append((a.size, k, a))
#     evals = None
#     if candidates_2d:
#         candidates_2d.sort(reverse=True, key=lambda t: t[0])
#         evals_key = candidates_2d[0][1]
#         evals = candidates_2d[0][2]
#     else:
#         evals_key = None

#     # Attach which keys we chose (helpful for debugging provenance)
#     payload["_metric007_detected_V_key"] = np.array([V_key], dtype=object)
#     payload["_metric007_detected_evals_key"] = np.array([evals_key], dtype=object)

#     return V, evals, payload


def orthogonal_procrustes(A: np.ndarray, B: np.ndarray) -> np.ndarray:
    """
    Find the closest orthogonal matrix R to A^T B in Frobenius norm
    by re-orthogonalizing via SVD.
      M = A^T B
      M = U S V^T
      R = U V^T

    A, B: (d, r) frames with orthonormal columns (or approximately).
    Returns R: (r, r) orthogonal transport in the subspace.
    """
    M = A.T @ B
    U, _, VT = np.linalg.svd(M, full_matrices=False)
    R = U @ VT
    return R


def holonomy_angles(H: np.ndarray) -> np.ndarray:
    """
    Return principal arguments of eigenvalues of H (in radians).
    For orthogonal H, eigenvalues lie on unit circle (numerically near).
    """
    w = np.linalg.eigvals(H)
    ang = np.angle(w)
    # sort by absolute angle (largest first) for readability
    idx = np.argsort(-np.abs(ang))
    return ang[idx]


def safe_svd_singular_ratio(A: np.ndarray, eps: float = 1e-12) -> tuple[float, float, float]:
    """
    Return (s1, s2, K=s1/max(s2,eps)) where s1>=s2>=...
    """
    s = np.linalg.svd(A, compute_uv=False)
    if s.size == 0:
        return 0.0, 0.0, 1.0
    s1 = float(s[0])
    s2 = float(s[1]) if s.size > 1 else float(s[0])
    K = s1 / max(s2, eps)
    if K < 1.0:
        K = 1.0 / max(K, eps)
    return s1, s2, K


# -------------------------
# Core metric_007
# -------------------------

def run_metric_007_on_file(path: str) -> str:
    meta = parse_filename_meta(path)
    stem = meta["stem"]

    V, evals, payload = load_eigshells_npz(path)
    # V: (S, d, r) or (S, d, d)
    S, d, r = V.shape

    # Compute transports R_k for k=0..S-2 in the r-dimensional frame space
    R_list = []
    for k in range(S - 1):
        A = V[k + 1]
        B = V[k]
        R = orthogonal_procrustes(A, B)
        R_list.append(R)
    R_arr = np.stack(R_list, axis=0) if R_list else np.zeros((0, r, r), dtype=float)

    # Commutators between consecutive transports: k=0..S-3
    comm_norm = np.zeros(max(S - 2, 0), dtype=float)
    if R_arr.shape[0] >= 2:
        for k in range(R_arr.shape[0] - 1):
            C = R_arr[k + 1] @ R_arr[k] - R_arr[k] @ R_arr[k + 1]
            comm_norm[k] = np.linalg.norm(C, ord="fro")

    # Cumulative holonomy
    H = np.eye(r)
    for k in range(R_arr.shape[0]):
        H = R_arr[k] @ H
    hol_dev = float(np.linalg.norm(H - np.eye(r), ord="fro"))
    hol_ang = holonomy_angles(H)

    # QC-style dilatation proxy from leading 2×2 block of each R_k
    K = np.ones(R_arr.shape[0], dtype=float)
    mu = np.zeros(R_arr.shape[0], dtype=float)
    s1s = np.zeros(R_arr.shape[0], dtype=float)
    s2s = np.zeros(R_arr.shape[0], dtype=float)

    if r >= 2 and R_arr.shape[0] > 0:
        for k in range(R_arr.shape[0]):
            A2 = R_arr[k][:2, :2]
            s1, s2, Kk = safe_svd_singular_ratio(A2)
            s1s[k] = s1
            s2s[k] = s2
            K[k] = Kk
            mu[k] = (Kk - 1.0) / (Kk + 1.0)

    # Save outputs
    out_npz = os.path.join(OUTPUT_DIR, f"metric_007__{stem}.npz")
    np.savez(
        out_npz,
        src_file=np.array([os.path.basename(path)], dtype=object),
        metric_tag=np.array([_as_str(meta.get("metric_tag"))], dtype=object),
        fit=np.array([_as_str(meta.get("fit"))], dtype=object),
        preprocess=np.array([_as_str(meta.get("preprocess"))], dtype=object),
        dm32=np.array([_as_str(meta.get("dm32"))], dtype=object),
        S=np.array([S], dtype=int),
        d=np.array([d], dtype=int),
        r=np.array([r], dtype=int),
        R=R_arr,
        comm_norm=comm_norm,
        holonomy=H,
        hol_dev=np.array([hol_dev], dtype=float),
        hol_angles=hol_ang,
        K=K,
        mu=mu,
        s1=s1s,
        s2=s2s,
        **{k: payload[k] for k in payload.keys() if not str(k).startswith("__")}  # keep provenance
    )

    # Plots
    # comm_norm is length (S-2) aligned between R_k and R_{k+1}; K is length (S-1) for each R_k
    if comm_norm.size > 0:
        plt.figure()
        plt.plot(np.arange(comm_norm.size), comm_norm)
        plt.xlabel("shell index k (commutator between R_{k+1} and R_k)")
        plt.ylabel("||R_{k+1}R_k - R_kR_{k+1}||_F")
        plt.title(f"metric_007 commutator norm\n{stem}")
        plt.tight_layout()
        plt.savefig(os.path.join(PLOTS_DIR, f"{stem}__comm_norm.png"), dpi=160)
        plt.close()

    if K.size > 0:
        plt.figure()
        plt.plot(np.arange(K.size), K)
        plt.xlabel("shell index k (transport R_k)")
        plt.ylabel("K (2×2 singular ratio proxy)")
        plt.title(f"metric_007 QC-style dilatation proxy\n{stem}\nHolonomy dev ||H-I||_F = {hol_dev:.4g}")
        plt.tight_layout()
        plt.savefig(os.path.join(PLOTS_DIR, f"{stem}__K_dilatation.png"), dpi=160)
        plt.close()

    return out_npz


def main() -> None:
    parser = argparse.ArgumentParser(description="metric_007: commutator holonomy + QC dilatation proxy from eigshell NPZs")
    parser.add_argument("--metric_tag", default=None, help="Filter to a source metric tag like metric_003, metric_004, metric_005, metric_006")
    parser.add_argument("--fit", default=None, help="Filter to FIT: NUFIT / BARI / VALENCIA")
    parser.add_argument("--preprocess", default=None, help="Filter to preprocess: zscore / dimensionless / ...")
    parser.add_argument("--dm32", default=None, help="Filter to dm32_mode: signed / abs / drop / ...")
    parser.add_argument("--all", action="store_true", help="Run over all discovered inputs (default behavior)")
    args = parser.parse_args()

    ensure_dirs()

    # Default behavior: run over all discovered inputs (same as --all)
    targets = discover_inputs(
        metric_tag=args.metric_tag,
        fit=args.fit,
        preprocess=args.preprocess,
        dm32=args.dm32
    )

    if not targets:
        print("No input NPZ files found matching filters.")
        print(f"Looked for: {NPZ_GLOB}")
        print("Tip: ls metric_007_inputs | sort")
        return

    print(f"Discovered {len(targets)} input NPZ file(s).")
    for p in targets:
        meta = parse_filename_meta(p)
        print(f"  - {os.path.basename(p)}  [tag={meta.get('metric_tag')}, fit={meta.get('fit')}, prep={meta.get('preprocess')}, dm32={meta.get('dm32')}]")

    print("\nRunning metric_007...\n")
    out_files = []
    for p in targets:
        out_npz = run_metric_007_on_file(p)
        out_files.append(out_npz)
        print(f"OK: {os.path.basename(p)} -> {out_npz}")

    print("\nDone.")
    print(f"Outputs: {OUTPUT_DIR}")
    print(f"Plots:   {PLOTS_DIR}")


if __name__ == "__main__":
    main()
