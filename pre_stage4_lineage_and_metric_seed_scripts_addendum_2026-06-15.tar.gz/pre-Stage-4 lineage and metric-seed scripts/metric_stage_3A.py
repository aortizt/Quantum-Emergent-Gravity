#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
metric_stage_3A.py  — Stage 3A FIT-level discriminant (canonical: metric_003)

Goal
----
Take the *metric_003 eigenshell stream* (eigshells__metric_003__<FIT>__<preprocess>__<dm32>.npz),
compute the Stage-2 commutator/holonomy signals (same math as metric_007),
and then aggregate them into a single FIT-level summary table for Stage 3A.

What this replaces
------------------
- metric_007.py was designed to run on metric_003/004/005/006.
- Here we hard-pin to metric_003 only and produce the one table Stage 3A needs.

Outputs
-------
1) NPZ per FIT in OUTPUT_DIR with: comm_norm (W), holonomy, hol_dev, etc.
2) stage3A_summary.csv and stage3A_summary.json in OUTPUT_DIR
3) A console-printed table

Typical usage
-------------
# from project root (e.g., 010-Quantum_Emergent_Gravity):
python metric_stage_3A.py --root . --preprocess zscore --dm32 signed

# if you already have the eigshell NPZs in metric_007_inputs:
python metric_stage_3A.py --root . --search-dirs metric_007_inputs
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple, Optional

import numpy as np


# -------------------------
# File discovery + loading
# -------------------------

@dataclass
class EigshellMeta:
    metric_tag: str
    fit: str
    preprocess: str
    dm32: str
    stem: str


def parse_filename_meta(path: str) -> EigshellMeta:
    """
    Parse filenames like:
      eigshells__metric_003__NUFIT__zscore__signed.npz
    """
    p = Path(path)
    stem = p.stem
    parts = stem.split("__")
    # expected: ["eigshells", "metric_003", "NUFIT", "zscore", "signed"]
    if len(parts) < 5:
        raise ValueError(f"Unrecognized eigshell filename format: {p.name}")
    metric_tag = parts[1]  # metric_003
    fit = parts[2]
    preprocess = parts[3]
    dm32 = parts[4]
    return EigshellMeta(metric_tag=metric_tag, fit=fit, preprocess=preprocess, dm32=dm32, stem=stem)


def robust_load_eigshells_npz(path: str) -> Tuple[np.ndarray, Optional[np.ndarray], Dict]:
    """
    Robustly load eigenvectors cube V and (optional) eigenvalues from an NPZ,
    without assuming exact key names.
    Returns (V, evals_or_None, payload_dict).
    """
    z = np.load(path, allow_pickle=True)
    payload = {k: z[k] for k in z.files}

    # pick eigenvectors: largest 3D array
    cand3 = []
    for k, a in payload.items():
        if isinstance(a, np.ndarray) and a.ndim == 3 and a.size > 0:
            cand3.append((a.size, k, a))
    if not cand3:
        raise ValueError(f"[{path}] Could not find a 3D eigenvector array. Keys={list(payload.keys())}")
    cand3.sort(reverse=True, key=lambda t: t[0])
    V_key = cand3[0][1]
    V = cand3[0][2]

    # eigenvalues: a 2D array with same first dimension as V (shell count)
    evals = None
    cand2 = []
    for k, a in payload.items():
        if isinstance(a, np.ndarray) and a.ndim == 2 and a.shape[0] == V.shape[0]:
            cand2.append((a.size, k, a))
    if cand2:
        cand2.sort(reverse=True, key=lambda t: t[0])
        evals = cand2[0][2]

    payload["_V_key"] = np.array([V_key], dtype=object)
    return V, evals, payload


def discover_metric003_files(root: Path,
                            preprocess: Optional[str],
                            dm32: Optional[str],
                            search_dirs: List[str]) -> List[Path]:
    """
    Search for eigshells__metric_003__*.npz under given dirs (relative to root),
    or under root recursively if search_dirs is empty.
    """
    patterns = []
    if preprocess and dm32:
        patterns.append(f"eigshells__metric_003__*__{preprocess}__{dm32}.npz")
    elif preprocess and not dm32:
        patterns.append(f"eigshells__metric_003__*__{preprocess}__*.npz")
    elif dm32 and not preprocess:
        patterns.append(f"eigshells__metric_003__*__*__{dm32}.npz")
    else:
        patterns.append("eigshells__metric_003__*.npz")

    found: List[Path] = []
    if search_dirs:
        for d in search_dirs:
            base = (root / d).resolve()
            for pat in patterns:
                found.extend(sorted(base.glob(pat)))
    else:
        for pat in patterns:
            found.extend(sorted(root.rglob(pat)))

    # de-dup by resolved path
    uniq = {}
    for p in found:
        uniq[p.resolve()] = p
    return sorted(uniq.values())


# -------------------------
# Stage-2 signal extraction
# -------------------------

def safe_svd_orthogonal_procrustes(A: np.ndarray) -> np.ndarray:
    """Return the closest orthogonal matrix to A via SVD."""
    U, _, Vt = np.linalg.svd(A, full_matrices=False)
    R = U @ Vt
    # enforce det +1 (proper rotation) if needed
    if np.linalg.det(R) < 0:
        U[:, -1] *= -1
        R = U @ Vt
    return R


def commutator_norm(A: np.ndarray, B: np.ndarray, ord: str = "fro") -> float:
    C = A @ B - B @ A
    if ord == "fro":
        return float(np.linalg.norm(C, ord="fro"))
    return float(np.linalg.norm(C))


def holonomy_from_transports(R_list: List[np.ndarray]) -> np.ndarray:
    """Holonomy = ordered product of transports."""
    H = np.eye(R_list[0].shape[0], dtype=float)
    for R in R_list:
        H = R @ H
    return H


def rotation_angle_from_matrix(R: np.ndarray) -> float:
    """
    For an orthogonal matrix in SO(n), a proxy 'total rotation angle' from trace.
    In 3D this matches the standard formula; in higher dimensions it is a scalar proxy.
    """
    tr = float(np.trace(R))
    n = R.shape[0]
    # clamp
    x = (tr - 1.0) / (n - 1.0) if n > 1 else 1.0
    x = max(-1.0, min(1.0, x))
    return float(np.arccos(x))


def compute_stage2_signals(V: np.ndarray) -> Dict[str, np.ndarray | float]:
    """
    Given V with shape (S, d, r) or (S, d, d) (shells, ambient dim, subspace rank),
    compute shell-to-shell transports, commutator norms, and holonomy deviation.
    """
    if V.ndim != 3:
        raise ValueError(f"Expected V.ndim=3, got {V.ndim}")

    S = V.shape[0]
    d = V.shape[1]
    r = V.shape[2]

    # transports between shells: R_k maps shell k -> k+1 in r-dim subspace
    R_list: List[np.ndarray] = []
    for k in range(S - 1):
        Vk = V[k]      # (d, r)
        Vk1 = V[k + 1] # (d, r)
        A = Vk1.T @ Vk  # (r, r)
        Rk = safe_svd_orthogonal_procrustes(A)
        R_list.append(Rk)

    # commutators between consecutive transports: W_k = ||[R_{k+1}, R_k]||
    # define length S-2 aligned to "middle shell index" (k+1), but we store at index k for simplicity
    comm = np.zeros(max(S - 2, 0), dtype=float)
    for k in range(S - 2):
        comm[k] = commutator_norm(R_list[k + 1], R_list[k], ord="fro")

    # holonomy + deviation
    if R_list:
        H = holonomy_from_transports(R_list)
        hol_dev = float(np.linalg.norm(H - np.eye(r), ord="fro"))
        hol_angle = rotation_angle_from_matrix(H)
    else:
        H = np.eye(r)
        hol_dev = 0.0
        hol_angle = 0.0

    return {
        "S": int(S),
        "d": int(d),
        "r": int(r),
        "R": np.stack(R_list, axis=0) if R_list else np.zeros((0, r, r), dtype=float),
        "comm_norm": comm,          # W signal
        "holonomy": H,
        "hol_dev": hol_dev,
        "hol_angle": hol_angle,
    }


# -------------------------
# Stage-3A aggregation
# -------------------------

def q90(x: np.ndarray) -> float:
    return float(np.quantile(x, 0.90)) if x.size else float("nan")


def summarize_W(W: np.ndarray, top_k: int = 5) -> Dict:
    if W.size == 0:
        return dict(medianW=float("nan"), q90W=float("nan"), maxW=float("nan"),
                    topW_shells=[], topW_values=[])
    med = float(np.median(W))
    q = q90(W)
    mx = float(np.max(W))
    # shell indices: comm[k] compares R_{k+1} vs R_k, i.e. around shell k+1
    idx = np.argsort(W)[::-1][:min(top_k, W.size)]
    top_shells = [int(i + 1) for i in idx]  # +1 to point at the "middle shell"
    top_vals = [float(W[i]) for i in idx]
    return dict(medianW=med, q90W=q, maxW=mx, topW_shells=top_shells, topW_values=top_vals)


def compute_overlaps(top_shells_by_fit: Dict[str, List[int]]) -> Dict[str, int]:
    fits = sorted(top_shells_by_fit.keys())
    overlaps = {}
    for i in range(len(fits)):
        for j in range(i + 1, len(fits)):
            a = set(top_shells_by_fit[fits[i]])
            b = set(top_shells_by_fit[fits[j]])
            overlaps[f"{fits[i]}∩{fits[j]}"] = len(a & b)
    return overlaps


# -------------------------
# CLI / main
# -------------------------

def main(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser(description="Stage 3A (metric_003-only) commutator discriminant table.")
    ap.add_argument("--root", default=".", help="Project root (default: .)")
    ap.add_argument("--preprocess", default=None, help="Filter preprocess tag (e.g. zscore). If omitted, any.")
    ap.add_argument("--dm32", default=None, help="Filter dm32 tag (signed/abs/drop). If omitted, any.")
    ap.add_argument("--search-dirs", nargs="*", default=["metric_007_inputs", "metric_003_outputs"],
                    help="Directories (relative to root) to search first for eigshell NPZs.")
    ap.add_argument("--output-dir", default="metric_stage_3A_outputs", help="Where to write outputs.")
    ap.add_argument("--top-k", type=int, default=5, help="How many top-W shells to record per FIT.")
    args = ap.parse_args(argv)

    root = Path(args.root).resolve()
    outdir = (root / args.output_dir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)

    # Prefer explicit dirs; if no files are found, fall back to recursive search.
    files = discover_metric003_files(root, args.preprocess, args.dm32, args.search_dirs)
    if not files:
        files = discover_metric003_files(root, args.preprocess, args.dm32, search_dirs=[])

    if not files:
        print("ERROR: No metric_003 eigshell NPZ files found.")
        print("Searched dirs:", args.search_dirs, "under root:", root)
        print("Try: --search-dirs metric_007_inputs metric_003_outputs  (or omit to search recursively)")
        return 2

    # Group by FIT (keep first match per FIT)
    by_fit: Dict[str, Path] = {}
    metas: Dict[str, EigshellMeta] = {}
    for f in files:
        meta = parse_filename_meta(str(f))
        if meta.metric_tag != "metric_003":
            continue
        if args.preprocess and meta.preprocess != args.preprocess:
            continue
        if args.dm32 and meta.dm32 != args.dm32:
            continue
        if meta.fit not in by_fit:
            by_fit[meta.fit] = f
            metas[meta.fit] = meta

    if not by_fit:
        print("ERROR: Found files, but none matched the requested preprocess/dm32 filters.")
        print("Found candidates:", [p.name for p in files[:20]])
        return 3

    # Process each FIT
    summary_rows: List[Dict] = []
    top_shells: Dict[str, List[int]] = {}

    for fit in sorted(by_fit.keys()):
        fpath = by_fit[fit]
        meta = metas[fit]
        V, evals, payload = robust_load_eigshells_npz(str(fpath))
        sig = compute_stage2_signals(V)
        W = sig["comm_norm"]

        stats = summarize_W(W, top_k=args.top_k)
        top_shells[fit] = stats["topW_shells"]

        # Save per-FIT NPZ (stage2 signals, for provenance)
        out_npz = outdir / f"stage3A__{meta.stem}.npz"
        np.savez(
            out_npz,
            src_file=np.array([str(fpath)], dtype=object),
            fit=np.array([fit], dtype=object),
            preprocess=np.array([meta.preprocess], dtype=object),
            dm32=np.array([meta.dm32], dtype=object),
            S=np.array([sig["S"]], dtype=int),
            d=np.array([sig["d"]], dtype=int),
            r=np.array([sig["r"]], dtype=int),
            R=sig["R"],
            comm_norm=W,
            holonomy=sig["holonomy"],
            hol_dev=np.array([sig["hol_dev"]], dtype=float),
            hol_angle=np.array([sig["hol_angle"]], dtype=float),
            _V_key=payload.get("_V_key", np.array(["unknown"], dtype=object)),
        )

        summary_rows.append({
            "FIT": fit,
            "src": fpath.name,
            "preprocess": meta.preprocess,
            "dm32": meta.dm32,
            "S": sig["S"],
            "r": sig["r"],
            "medianW": stats["medianW"],
            "q90W": stats["q90W"],
            "maxW": stats["maxW"],
            "hol_dev": float(sig["hol_dev"]),
            "hol_angle": float(sig["hol_angle"]),
            "topW_shells": stats["topW_shells"],
            "topW_values": stats["topW_values"],
        })

    overlaps = compute_overlaps(top_shells)

    # Write summary CSV (simple, JSON fields as strings)
    csv_path = outdir / "stage3A_summary.csv"
    with csv_path.open("w", encoding="utf-8") as f:
        headers = ["FIT", "src", "preprocess", "dm32", "S", "r",
                   "medianW", "q90W", "maxW", "hol_dev", "hol_angle",
                   "topW_shells", "topW_values"]
        f.write(",".join(headers) + "\n")
        for row in summary_rows:
            vals = []
            for h in headers:
                v = row[h]
                if isinstance(v, (list, dict)):
                    v = json.dumps(v)
                vals.append(str(v))
            f.write(",".join(vals) + "\n")

    # Write JSON (includes overlaps)
    json_path = outdir / "stage3A_summary.json"
    with json_path.open("w", encoding="utf-8") as f:
        json.dump({"rows": summary_rows, "overlaps": overlaps}, f, indent=2)

    # Print console table (compact)
    print("\n=== Stage 3A summary (metric_003-only) ===")
    print(f"root: {root}")
    print(f"out : {outdir}\n")
    for row in summary_rows:
        print(f"{row['FIT']:9s}  med={row['medianW']:.4g}  q90={row['q90W']:.4g}  max={row['maxW']:.4g}  hol_dev={row['hol_dev']:.4g}  top={row['topW_shells']}")
    print("\nOverlaps (top shells):", overlaps)
    print(f"\nWrote: {csv_path}")
    print(f"Wrote: {json_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
