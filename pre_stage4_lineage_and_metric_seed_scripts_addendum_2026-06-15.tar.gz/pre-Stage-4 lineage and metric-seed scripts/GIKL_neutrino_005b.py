#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GIKL_neutrino_005b.py

v005b = "atlas patch" (still the KL+GI firewall layer, but with a global coordinate atlas)
---------------------------------------------------------------------------------------
Why this patch exists:
- In v005, "zscore" vs "dimensionless" appeared identical because we *pairwise* min–max
  normalized each comparison to [0,1], which largely quotients out per-coordinate affine
  transforms (including z-scoring and scaling).
- v005b keeps the min–max → [0,1] histogram gridding, BUT defines mins/maxs from a *global
  reference atlas* (union of all samples across fits and orderings, per mode).
  This makes the coordinate system an "atlas" rather than a per-experiment renormalization.

What v005b does:
- Builds global atlas parameters for each (preprocess_mode, dm32_mode):
    * For preprocess="zscore": pooled mean/std over ALL samples (fits × {NO,IO}), then
      compute pooled mins/maxs after z-scoring.
    * For preprocess="dimensionless": apply physical scaling, then pooled mins/maxs.
- Uses that atlas (mins/maxs) for:
    * within-fit NO vs IO KL + GI-flow tracks
    * cross-fit KLs (NO vs NO, IO vs IO)
- Exports CSVs:
    neutrino_kl_v005b_results.csv
    neutrino_kl_v005b_results_crossfit.csv

Important: Still no variograms/fractality/quasi-conformality here. This is the atlas-corrected
KL+GI stage you asked for before v006.

Data source: Table 14.7 manual transcription (your screenshot).
"""

import numpy as np
import csv
from dataclasses import dataclass
from typing import Dict, Tuple, List

# ============================
# 0) Configuration
# ============================

FITS = ["NUFIT", "BARI", "VALENCIA"]
ORDERINGS = ["NO", "IO"]

PREPROCESS_MODES = ["zscore", "dimensionless"]
DM32_MODES = ["signed", "abs", "drop"]

N_SAMPLES = 5000
BINS = 18
ALPHA = 0.2
T_STEPS = 30

DM21_SCALE = 75.0
DM32_SCALE = 2500.0

CSV_OUT = "neutrino_kl_v005b_results.csv"

# ============================
# 1) Manual transcription of Table 14.7
# ============================

TABLE_14_7: Dict[str, Dict[str, Dict[str, Tuple[float, float, float]]]] = {
    "NUFIT": {
        "NO": {
            "sin2_t12_10m1": (3.03, 0.12, 0.11),
            "sin2_t23_10m1": (5.72, 0.18, 0.23),
            "sin2_t13_10m2": (2.203, 0.056, 0.059),
            "dcp_deg":      (197.0, 42.0, 25.0),
            "dm2_21":       (74.1, 2.1, 2.0),
            "dm2_32":       (2437.0, 28.0, 27.0),
        },
        "IO": {
            "sin2_t12_10m1": (3.03, 0.12, 0.11),
            "sin2_t23_10m1": (5.78, 0.16, 0.21),
            "sin2_t13_10m2": (2.219, 0.060, 0.057),
            "dcp_deg":      (286.0, 27.0, 32.0),
            "dm2_21":       (74.1, 2.1, 2.0),
            "dm2_32":       (-2498.0, 32.0, 25.0),
        },
    },
    "BARI": {
        "NO": {
            "sin2_t12_10m1": (3.03, 0.13, 0.13),
            "sin2_t23_10m1": (4.55, 0.15, 0.15),
            "sin2_t13_10m2": (2.23, 0.06, 0.06),
            "dcp_deg":      (223.0, 32.0, 23.0),
            "dm2_21":       (73.6, 1.6, 1.5),
            "dm2_32":       (2448.0, 23.0, 31.0),
        },
        "IO": {
            "sin2_t12_10m1": (3.03, 0.13, 0.13),
            "sin2_t23_10m1": (5.69, 0.13, 0.21),
            "sin2_t13_10m2": (2.23, 0.06, 0.06),
            "dcp_deg":      (274.0, 25.0, 27.0),
            "dm2_21":       (73.6, 1.6, 1.5),
            "dm2_32":       (-2492.0, 25.0, 30.0),
        },
    },
    "VALENCIA": {
        "NO": {
            "sin2_t12_10m1": (3.18, 0.16, 0.16),
            "sin2_t23_10m1": (5.74, 0.14, 0.14),
            "sin2_t13_10m2": (2.200, 0.069, 0.062),
            "dcp_deg":      (194.0, 24.0, 22.0),
            "dm2_21":       (75.0, 2.2, 2.0),
            "dm2_32":       (2470.0, 24.0, 30.0),
        },
        "IO": {
            "sin2_t12_10m1": (3.18, 0.16, 0.16),
            "sin2_t23_10m1": (5.78, 0.10, 0.17),
            "sin2_t13_10m2": (2.225, 0.064, 0.070),
            "dcp_deg":      (284.0, 26.0, 28.0),
            "dm2_21":       (75.0, 2.2, 2.0),
            "dm2_32":       (-2520.0, 30.0, 20.0),
        },
    },
}

SCALE = {
    "sin2_t12_10m1": 1e-1,
    "sin2_t23_10m1": 1e-1,
    "sin2_t13_10m2": 1e-2,
    "dcp_deg":       1.0,
    "dm2_21":        1.0,
    "dm2_32":        1.0,
}

# ============================
# 2) Sampling base embedding
# ============================

def sym_sigma(up: float, down: float) -> float:
    return 0.5 * (abs(up) + abs(down))

def sample_normal(rng: np.random.Generator, mu: float, up: float, down: float, n: int) -> np.ndarray:
    sig = max(sym_sigma(up, down), 1e-12)
    return rng.normal(mu, sig, size=n)

def sample_angle_deg(rng: np.random.Generator, mu_deg: float, up: float, down: float, n: int) -> np.ndarray:
    sig = max(sym_sigma(up, down), 1e-12)
    return (rng.normal(mu_deg, sig, size=n) % 360.0)

def build_cloud_raw(fit: str, ordering: str, n: int, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed)
    row = TABLE_14_7[fit][ordering]

    s12 = sample_normal(rng, *row["sin2_t12_10m1"], n) * SCALE["sin2_t12_10m1"]
    s23 = sample_normal(rng, *row["sin2_t23_10m1"], n) * SCALE["sin2_t23_10m1"]
    s13 = sample_normal(rng, *row["sin2_t13_10m2"], n) * SCALE["sin2_t13_10m2"]
    dm21 = sample_normal(rng, *row["dm2_21"], n)
    dm32 = sample_normal(rng, *row["dm2_32"], n)

    dcp = sample_angle_deg(rng, *row["dcp_deg"], n)
    rad = np.deg2rad(dcp)
    c = np.cos(rad)
    s = np.sin(rad)

    return np.vstack([s12, s23, s13, c, s, dm21, dm32]).T

# ============================
# 3) Toggles + preprocess helpers
# ============================

def apply_dm32_mode(X: np.ndarray, mode: str) -> np.ndarray:
    X = np.asarray(X, dtype=float)
    if mode == "signed":
        return X
    if mode == "abs":
        Y = X.copy()
        Y[:, -1] = np.abs(Y[:, -1])
        return Y
    if mode == "drop":
        return X[:, :-1]
    raise ValueError(f"Unknown dm32 mode: {mode}")

def apply_dimensionless(X: np.ndarray) -> np.ndarray:
    X = np.asarray(X, dtype=float).copy()
    if X.shape[1] == 7:
        X[:, -2] = X[:, -2] / DM21_SCALE
        X[:, -1] = X[:, -1] / DM32_SCALE
    elif X.shape[1] == 6:
        X[:, -1] = X[:, -1] / DM21_SCALE
    return X

# ============================
# 4) Global atlas builder
# ============================

@dataclass
class Atlas:
    preprocess: str
    dm32_mode: str
    mu: np.ndarray
    sd: np.ndarray
    mins: np.ndarray
    maxs: np.ndarray
    edges: List[np.ndarray]

def build_global_atlas(preprocess: str, dm32_mode: str) -> Atlas:
    chunks = []
    seed0 = 12345 + (hash((preprocess, dm32_mode)) % 10000)
    k = 0
    for fit in FITS:
        for ordering in ORDERINGS:
            X = build_cloud_raw(fit, ordering, n=N_SAMPLES, seed=seed0 + 97 * k)
            X = apply_dm32_mode(X, dm32_mode)
            chunks.append(X)
            k += 1
    Xall = np.vstack(chunks)

    if preprocess == "zscore":
        mu = Xall.mean(axis=0)
        sd = Xall.std(axis=0)
        sd = np.where(sd > 0, sd, 1.0)
        Xall_p = (Xall - mu) / sd
    elif preprocess == "dimensionless":
        mu = np.zeros(Xall.shape[1], dtype=float)
        sd = np.ones(Xall.shape[1], dtype=float)
        Xall_p = apply_dimensionless(Xall)
    else:
        raise ValueError(f"Unknown preprocess mode: {preprocess}")

    mins = np.nanmin(Xall_p, axis=0)
    maxs = np.nanmax(Xall_p, axis=0)
    span = maxs - mins
    span = np.where(np.isfinite(span) & (span > 0), span, 1.0)
    maxs = mins + span

    edges = [np.linspace(0.0, 1.0, BINS + 1) for _ in range(Xall_p.shape[1])]

    return Atlas(preprocess, dm32_mode, mu, sd, mins, maxs, edges)

def apply_atlas_preprocess(X: np.ndarray, atlas: Atlas) -> np.ndarray:
    X = np.asarray(X, dtype=float)
    if atlas.preprocess == "zscore":
        return (X - atlas.mu) / atlas.sd
    if atlas.preprocess == "dimensionless":
        return apply_dimensionless(X)
    raise ValueError("Invalid atlas preprocess")

# ============================
# 5) Histogram + KL + GI
# ============================

def hist_nd_atlas(X: np.ndarray, atlas: Atlas) -> np.ndarray:
    Y = (X - atlas.mins) / (atlas.maxs - atlas.mins + 1e-12)
    Y = np.clip(Y, 0.0, 1.0)
    H, _ = np.histogramdd(Y, bins=atlas.edges)
    return H / (H.sum() + 1e-15)

def safe_kl(P: np.ndarray, Q: np.ndarray, eps: float = 1e-15) -> float:
    P = np.asarray(P, dtype=float).ravel()
    Q = np.asarray(Q, dtype=float).ravel()
    P = np.clip(P, eps, None); Q = np.clip(Q, eps, None)
    P = P / P.sum(); Q = Q / Q.sum()
    return max(0.0, float(np.sum(P * np.log(P / Q))))

def gi_flow(current: np.ndarray, target: np.ndarray, alpha: float, T: int):
    cur = np.asarray(current, dtype=float).copy()
    tgt = np.asarray(target, dtype=float).copy()
    cur = np.clip(cur, 0.0, None); cur = cur / (cur.sum() + 1e-15)
    tgt = np.clip(tgt, 0.0, None); tgt = tgt / (tgt.sum() + 1e-15)

    track = []
    for _ in range(T):
        track.append(safe_kl(cur, tgt))
        cur = (1.0 - alpha) * cur + alpha * tgt
        cur = np.clip(cur, 0.0, None); cur = cur / (cur.sum() + 1e-15)
    track.append(safe_kl(cur, tgt))
    return np.array(track), cur

def track_summary(track: np.ndarray) -> Dict[str, float]:
    t = np.asarray(track, dtype=float)
    init = float(t[0])
    final = float(t[-1])
    auc = float(np.trapezoid(t, dx=1.0))
    target = init / 2.0
    idxs = np.where(t <= target)[0]
    half = float(idxs[0]) if idxs.size else float("nan")
    idxs1 = np.where(t <= 1.0)[0]
    t1 = float(idxs1[0]) if idxs1.size else float("nan")
    return {"kl_init": init, "kl_final": final, "auc": auc, "t_half": half, "t_below1": t1}

# ============================
# 6) Runs + cross-fit
# ============================

def run_with_atlas(fit: str, atlas: Atlas) -> Tuple[float, float, np.ndarray, np.ndarray]:
    X_no = build_cloud_raw(fit, "NO", n=N_SAMPLES, seed=1)
    X_io = build_cloud_raw(fit, "IO", n=N_SAMPLES, seed=2)

    X_no = apply_dm32_mode(X_no, atlas.dm32_mode)
    X_io = apply_dm32_mode(X_io, atlas.dm32_mode)

    X_no = apply_atlas_preprocess(X_no, atlas)
    X_io = apply_atlas_preprocess(X_io, atlas)

    P_no = hist_nd_atlas(X_no, atlas)
    P_io = hist_nd_atlas(X_io, atlas)

    kl_no_io = safe_kl(P_no, P_io)
    kl_io_no = safe_kl(P_io, P_no)

    tr_no_io, _ = gi_flow(P_no, P_io, alpha=ALPHA, T=T_STEPS)
    tr_io_no, _ = gi_flow(P_io, P_no, alpha=ALPHA, T=T_STEPS)

    return kl_no_io, kl_io_no, tr_no_io, tr_io_no

def cross_fit_kls(ordering: str, atlas: Atlas) -> List[Dict[str, float]]:
    clouds = {}
    seed0 = 777 + (hash((ordering, atlas.preprocess, atlas.dm32_mode)) % 10000)
    for i, fit in enumerate(FITS):
        X = build_cloud_raw(fit, ordering, n=N_SAMPLES, seed=seed0 + 101 * i)
        X = apply_dm32_mode(X, atlas.dm32_mode)
        X = apply_atlas_preprocess(X, atlas)
        clouds[fit] = X

    out = []
    for i in range(len(FITS)):
        for j in range(i + 1, len(FITS)):
            f1, f2 = FITS[i], FITS[j]
            P1 = hist_nd_atlas(clouds[f1], atlas)
            P2 = hist_nd_atlas(clouds[f2], atlas)
            out.append({
                "ordering": ordering,
                "preprocess": atlas.preprocess,
                "dm32_mode": atlas.dm32_mode,
                "fit_a": f1,
                "fit_b": f2,
                "kl_a_b": safe_kl(P1, P2),
                "kl_b_a": safe_kl(P2, P1),
            })
    return out

def main():
    all_rows = []
    cross_rows = []

    print("\n=== v005b RUN SETTINGS ===")
    print("FITS:", FITS)
    print("PREPROCESS_MODES:", PREPROCESS_MODES)
    print("DM32_MODES:", DM32_MODES)
    print(f"N={N_SAMPLES}, bins={BINS}, alpha={ALPHA}, T={T_STEPS}")
    print("==========================\n")

    for preprocess in PREPROCESS_MODES:
        for dm32_mode in DM32_MODES:
            atlas = build_global_atlas(preprocess, dm32_mode)

            print(f"\n######## ATLAS preprocess={preprocess} | dm32_mode={dm32_mode} ########")
            print("Dims:", len(atlas.mins))
            print("Atlas mins:", atlas.mins)
            print("Atlas maxs:", atlas.maxs)

            for fit in FITS:
                kl_no_io, kl_io_no, tr_no_io, tr_io_no = run_with_atlas(fit, atlas)
                s1 = track_summary(tr_no_io)
                s2 = track_summary(tr_io_no)

                print(f"\nFIT: {fit}")
                print(f"KL(NO||IO)={kl_no_io:.6f}  KL(IO||NO)={kl_io_no:.6f}")
                print("NO→IO first 5:", tr_no_io[:5])
                print("IO→NO first 5:", tr_io_no[:5])
                print(f"NO→IO t_half={s1['t_half']}  t<=1={s1['t_below1']}  AUC={s1['auc']:.3f}")
                print(f"IO→NO t_half={s2['t_half']}  t<=1={s2['t_below1']}  AUC={s2['auc']:.3f}")

                all_rows.append({
                    "fit": fit,
                    "preprocess": preprocess,
                    "dm32_mode": dm32_mode,
                    "n": N_SAMPLES,
                    "bins": BINS,
                    "alpha": ALPHA,
                    "T": T_STEPS,
                    "kl_no_io": kl_no_io,
                    "kl_io_no": kl_io_no,
                    "no_to_io_kl_init": s1["kl_init"],
                    "no_to_io_kl_final": s1["kl_final"],
                    "no_to_io_auc": s1["auc"],
                    "no_to_io_t_half": s1["t_half"],
                    "no_to_io_t_below1": s1["t_below1"],
                    "io_to_no_kl_init": s2["kl_init"],
                    "io_to_no_kl_final": s2["kl_final"],
                    "io_to_no_auc": s2["auc"],
                    "io_to_no_t_half": s2["t_half"],
                    "io_to_no_t_below1": s2["t_below1"],
                    "no_to_io_track_10": ";".join(f"{x:.6g}" for x in tr_no_io[:10]),
                    "io_to_no_track_10": ";".join(f"{x:.6g}" for x in tr_io_no[:10]),
                    "atlas_mins": ";".join(f"{x:.6g}" for x in atlas.mins),
                    "atlas_maxs": ";".join(f"{x:.6g}" for x in atlas.maxs),
                })

            cross_rows.extend(cross_fit_kls("NO", atlas))
            cross_rows.extend(cross_fit_kls("IO", atlas))

    with open(CSV_OUT, "w", newline="", encoding="utf-8") as f:
        fieldnames = list(all_rows[0].keys()) if all_rows else []
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(all_rows)

    cross_out = CSV_OUT.replace(".csv", "_crossfit.csv")
    with open(cross_out, "w", newline="", encoding="utf-8") as f:
        fieldnames = list(cross_rows[0].keys()) if cross_rows else []
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(cross_rows)

    print("\n=== CSV written ===")
    print("Main:", CSV_OUT)
    print("Cross-fit:", cross_out)
    print("===================\n")

if __name__ == "__main__":
    main()
