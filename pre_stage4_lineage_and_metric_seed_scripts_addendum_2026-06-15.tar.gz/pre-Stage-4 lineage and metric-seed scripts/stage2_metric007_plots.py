#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
stage2_metric007_plots.py

Reproducible Stage-2 analysis for metric_007 outputs:
  - FIT-wise comm_norm[k] vs shell
  - FIT-wise K[k] vs shell (log y)
  - eigenvalue min-adjacent-gap per shell from eigshell inputs
  - eigenvalue-gap-weighted commutators:
        comm/(gap+eps)  and  comm*(gap+eps)
  - robust summary table (median, q90, max, trimmed mean)
  - prints top shells by K for each FIT
  - near-degeneracy cross-check:
        smallest gaps vs largest K vs largest comm/gap + overlaps

Run:
  python3 stage2_metric007_plots.py
or:
  /home/dakini/python_envs/python3.11/bin/python3.11 stage2_metric007_plots.py
"""

from __future__ import annotations

import os
import glob
import argparse
from dataclasses import dataclass
from typing import Dict, List, Tuple

import numpy as np
import matplotlib.pyplot as plt


# ----------------------------
# Data containers
# ----------------------------
@dataclass
class Metric007Data:
    fit: str
    metric_tag: str
    preprocess: str
    dm32: str
    comm: np.ndarray          # shape (S,)
    K: np.ndarray             # shape (S,)
    hol_dev: float
    path: str


# ----------------------------
# IO helpers
# ----------------------------
def load_metric007_npz(outdir: str, metric_tag: str, fit: str,
                      preprocess: str = "zscore", dm32: str = "signed") -> Metric007Data:
    p = os.path.join(outdir, f"metric_007__eigshells__{metric_tag}__{fit}__{preprocess}__{dm32}.npz")
    if not os.path.exists(p):
        raise FileNotFoundError(p)

    z = np.load(p, allow_pickle=True)

    comm = np.asarray(z["comm_norm"], dtype=float).reshape(-1)
    K = np.asarray(z["K"], dtype=float).reshape(-1) if "K" in z.files else np.full_like(comm, np.nan)
    hol_dev = float(z["hol_dev"][0]) if "hol_dev" in z.files else float("nan")

    S = min(len(comm), len(K))
    comm = comm[:S]
    K = K[:S]

    return Metric007Data(
        fit=fit, metric_tag=metric_tag, preprocess=preprocess, dm32=dm32,
        comm=comm, K=K, hol_dev=hol_dev, path=p
    )


def load_eigvals_inputs(indir: str, metric_tag: str, fit: str,
                        preprocess: str = "zscore", dm32: str = "signed") -> Tuple[str, np.ndarray]:
    p = os.path.join(indir, f"eigshells__{metric_tag}__{fit}__{preprocess}__{dm32}.npz")
    if not os.path.exists(p):
        raise FileNotFoundError(p)

    z = np.load(p, allow_pickle=True)
    eigvals = np.asarray(z["eigvals"], dtype=float)  # shape (S, D)
    return p, eigvals


# ----------------------------
# Math helpers
# ----------------------------
def trimmed_mean(x: np.ndarray, trim: float = 0.1) -> float:
    x = np.asarray(x, dtype=float).reshape(-1)
    x = x[np.isfinite(x)]
    if x.size == 0:
        return float("nan")
    x = np.sort(x)
    n = len(x)
    a = int(np.floor(trim * n))
    b = int(np.ceil((1 - trim) * n))
    if b <= a:
        return float(np.mean(x))
    return float(np.mean(x[a:b]))


def min_adjacent_gap(eigvals_shell: np.ndarray) -> float:
    lam = np.sort(np.asarray(eigvals_shell, dtype=float).reshape(-1))
    if lam.size < 2:
        return float("nan")
    d = np.diff(lam)
    d = np.abs(d[np.isfinite(d)])
    if d.size == 0:
        return float("nan")
    return float(np.min(d))


def compute_gaps(eigvals: np.ndarray) -> np.ndarray:
    return np.array([min_adjacent_gap(eigvals[k]) for k in range(eigvals.shape[0])], dtype=float)


# ----------------------------
# Plot helpers
# ----------------------------
def plot_series(shells: np.ndarray, series: Dict[str, np.ndarray],
                title: str, xlabel: str, ylabel: str,
                ylog: bool = False, savepath: str | None = None) -> None:
    plt.figure()
    for label, y in series.items():
        y = np.asarray(y, dtype=float).reshape(-1)
        n = min(len(shells), len(y))
        plt.plot(shells[:n], y[:n], marker="o", linewidth=1.5, label=label)
    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    if ylog:
        plt.yscale("log")
    plt.grid(True, alpha=0.3)
    plt.legend()
    plt.tight_layout()
    if savepath:
        plt.savefig(savepath, dpi=200)
    plt.show()


def safe_top_shells_by_K(comm: np.ndarray, K: np.ndarray, topn: int = 8) -> List[Tuple[int, float, float]]:
    comm = np.asarray(comm, float).reshape(-1)
    K = np.asarray(K, float).reshape(-1)
    S = min(len(comm), len(K))
    comm = comm[:S]
    K = K[:S]

    finite = np.isfinite(comm) & np.isfinite(K)
    idx_all = np.arange(S)[finite]
    if idx_all.size == 0:
        return []

    Kf = K[finite]
    order = np.argsort(-Kf)  # descending by K
    topn = min(int(topn), order.size)
    idx = idx_all[order[:topn]]
    return [(int(i), float(K[i]), float(comm[i])) for i in idx]


# ----------------------------
# Near-degeneracy reporting (NEW)
# ----------------------------
def top_indices(x: np.ndarray, topn: int = 8, largest: bool = True) -> np.ndarray:
    x = np.asarray(x, float).reshape(-1)
    finite = np.isfinite(x)
    idx_all = np.arange(len(x))[finite]
    if idx_all.size == 0:
        return np.array([], dtype=int)

    xf = x[finite]
    order = np.argsort(-xf) if largest else np.argsort(xf)
    topn = min(int(topn), order.size)
    return idx_all[order[:topn]]


def report_near_degeneracy_for_fit(
    fit: str,
    comm: np.ndarray,
    K: np.ndarray,
    gaps: np.ndarray,
    comm_over_gap: np.ndarray,
    topn_gap: int = 8,
    topn_K: int = 8,
    topn_weighted: int = 8,
) -> None:
    comm = np.asarray(comm, float).reshape(-1)
    K = np.asarray(K, float).reshape(-1)
    gaps = np.asarray(gaps, float).reshape(-1)
    wcomm = np.asarray(comm_over_gap, float).reshape(-1)

    S = min(len(comm), len(K), len(gaps), len(wcomm))
    comm, K, gaps, wcomm = comm[:S], K[:S], gaps[:S], wcomm[:S]

    idx_gap = top_indices(gaps, topn=topn_gap, largest=False)
    idx_K   = top_indices(K, topn=topn_K, largest=True)
    idx_w   = top_indices(wcomm, topn=topn_weighted, largest=True)

    set_gap = set(idx_gap.tolist())
    set_K = set(idx_K.tolist())
    set_w = set(idx_w.tolist())

    print(f"\n=== {fit}: near-degeneracy / instability cross-check ===")

    print(f"Smallest gaps (top {len(idx_gap)}):")
    for k in idx_gap:
        print(f"  k={int(k):2d}  gap={gaps[k]:.3e}  K={K[k]:.3f}  comm={comm[k]:.4f}  comm/gap={wcomm[k]:.3e}")

    print(f"\nLargest K (top {len(idx_K)}):")
    for k in idx_K:
        print(f"  k={int(k):2d}  K={K[k]:.3f}  gap={gaps[k]:.3e}  comm={comm[k]:.4f}  comm/gap={wcomm[k]:.3e}")

    print(f"\nLargest comm/gap (top {len(idx_w)}):")
    for k in idx_w:
        print(f"  k={int(k):2d}  comm/gap={wcomm[k]:.3e}  gap={gaps[k]:.3e}  K={K[k]:.3f}  comm={comm[k]:.4f}")

    inter_K_gap = sorted(set_K & set_gap)
    inter_w_gap = sorted(set_w & set_gap)
    inter_K_w = sorted(set_K & set_w)

    print("\nOverlaps:")
    print("  (K ∩ smallest-gap) shells:", inter_K_gap)
    print("  (comm/gap ∩ smallest-gap) shells:", inter_w_gap)
    print("  (K ∩ comm/gap) shells:", inter_K_w)


def report_near_degeneracy_all_fits(
    fits: List[str],
    comm_by_fit: Dict[str, np.ndarray],
    K_by_fit: Dict[str, np.ndarray],
    gap_by_fit: Dict[str, np.ndarray],
    comm_over_gap_by_fit: Dict[str, np.ndarray],
    topn_gap: int = 8,
    topn_K: int = 8,
    topn_weighted: int = 8,
) -> None:
    for fit in fits:
        report_near_degeneracy_for_fit(
            fit=fit,
            comm=comm_by_fit[fit],
            K=K_by_fit[fit],
            gaps=gap_by_fit[fit],
            comm_over_gap=comm_over_gap_by_fit[fit],
            topn_gap=topn_gap,
            topn_K=topn_K,
            topn_weighted=topn_weighted,
        )


# ----------------------------
# Reporting
# ----------------------------
def print_stage2_table(rows: List[Tuple[str, str, float, float, float, float, float, float, float, float]]) -> None:
    print("\nfit       tag       comm_med comm_q90 comm_max hol_dev | K_med  K_q90  K_max  K_tmean")
    for r in rows:
        fit, tag, comm_med, comm_q90, comm_max, hol_dev, K_med, K_q90, K_max, K_tmean = r
        print(f"{fit:9s} {tag:9s} "
              f"{comm_med:8.4f} {comm_q90:8.4f} {comm_max:8.4f} {hol_dev:7.4f} | "
              f"{K_med:6.3f} {K_q90:6.3f} {K_max:7.3f} {K_tmean:7.3f}")


# ----------------------------
# Main
# ----------------------------
def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=str,
                    default="/home/dakini/Downloads/010-Quantum_Emergent_Gravity",
                    help="Project root directory containing metric_007_outputs/ and metric_007_inputs/")
    ap.add_argument("--metric_tag", type=str, default="metric_003")
    ap.add_argument("--inputs_metric_tag", type=str, default="metric_003")
    ap.add_argument("--preprocess", type=str, default="zscore")
    ap.add_argument("--dm32", type=str, default="signed")
    ap.add_argument("--fits", type=str, default="NUFIT,BARI,VALENCIA")
    ap.add_argument("--topn", type=int, default=8)
    ap.add_argument("--eps", type=float, default=1e-12)
    ap.add_argument("--nd_top_gap", type=int, default=8, help="Near-degeneracy: smallest gaps to print")
    ap.add_argument("--nd_top_K", type=int, default=8, help="Near-degeneracy: largest K to print")
    ap.add_argument("--nd_top_weighted", type=int, default=8, help="Near-degeneracy: largest comm/gap to print")
    args = ap.parse_args()

    root = args.root
    outdir = os.path.join(root, "metric_007_outputs")
    indir = os.path.join(root, "metric_007_inputs")
    savedir = os.path.join(root, "plots_stage2")
    os.makedirs(savedir, exist_ok=True)

    fits = [s.strip() for s in args.fits.split(",") if s.strip()]
    metric_tag = args.metric_tag
    inputs_metric_tag = args.inputs_metric_tag
    preprocess = args.preprocess
    dm32 = args.dm32
    eps = float(args.eps)

    print("ROOT   =", root)
    print("OUTDIR =", outdir, "exists?", os.path.isdir(outdir))
    print("INDIR  =", indir,  "exists?", os.path.isdir(indir))
    print("SAVEDIR=", savedir)

    out_files = sorted(glob.glob(os.path.join(outdir, "*.npz")))
    print("Found", len(out_files), "NPZ output files in metric_007_outputs")

    # ---- load outputs per FIT
    data_by_fit: Dict[str, Metric007Data] = {}
    for fit in fits:
        d = load_metric007_npz(outdir, metric_tag, fit, preprocess, dm32)
        data_by_fit[fit] = d
        print(f"{fit:9s}: shells={len(d.comm)} hol_dev={d.hol_dev:.4f} file={os.path.basename(d.path)}")

    # Common shells axis (use min length across FITs)
    S = min(len(d.comm) for d in data_by_fit.values())
    shells = np.arange(S, dtype=int)

    # Extract aligned arrays per FIT
    comm_by_fit = {fit: data_by_fit[fit].comm[:S] for fit in fits}
    K_by_fit    = {fit: data_by_fit[fit].K[:S] for fit in fits}
    hol_by_fit  = {fit: float(data_by_fit[fit].hol_dev) for fit in fits}

    # ---- Stage-2 summary table
    rows = []
    for fit in fits:
        comm = comm_by_fit[fit]
        K = K_by_fit[fit]
        rows.append((
            fit, metric_tag,
            float(np.median(comm)),
            float(np.quantile(comm, 0.90)),
            float(np.max(comm)),
            hol_by_fit[fit],
            float(np.median(K)),
            float(np.quantile(K, 0.90)),
            float(np.max(K)),
            trimmed_mean(K, 0.10),
        ))
    print_stage2_table(rows)

    # ---- Top shells by K
    for fit in fits:
        top = safe_top_shells_by_K(comm_by_fit[fit], K_by_fit[fit], topn=args.topn)
        print(f"\nTop {min(args.topn, len(K_by_fit[fit]))} shells by K for {fit} ({metric_tag}):")
        if not top:
            print("  [no finite K values]")
        else:
            for (k, Kk, Ck) in top:
                if k >= S:
                    continue
                print(f"  shell={k:2d} | K={Kk:10.3f} | comm_norm={Ck:8.4f}")

    # ---- plots: comm_norm vs shell
    plot_series(
        shells,
        {fit: comm_by_fit[fit] for fit in fits},
        title=f"metric_007: comm_norm vs shell ({preprocess}/{dm32}) — {metric_tag}",
        xlabel="shell index k",
        ylabel="comm_norm[k]",
        ylog=False,
        savepath=os.path.join(savedir, "stage2_comm_norm_vs_shell.png"),
    )

    # ---- plots: K vs shell (log y)
    plot_series(
        shells,
        {fit: K_by_fit[fit] for fit in fits},
        title=f"metric_007: K vs shell (log y) ({preprocess}/{dm32}) — {metric_tag}",
        xlabel="shell index k",
        ylabel="K[k]",
        ylog=True,
        savepath=os.path.join(savedir, "stage2_K_vs_shell_log.png"),
    )

    # ---- eigenvalue gaps + weighted commutators
    gap_by_fit: Dict[str, np.ndarray] = {}
    for fit in fits:
        pin, eigvals = load_eigvals_inputs(indir, inputs_metric_tag, fit, preprocess, dm32)
        gaps = compute_gaps(eigvals)[:S]
        gap_by_fit[fit] = gaps
        print(f"gaps[{fit}] from {os.path.basename(pin)} | min={float(np.nanmin(gaps)):.3g} median={float(np.nanmedian(gaps)):.3g}")

    comm_over_gap_by_fit = {fit: comm_by_fit[fit] / (gap_by_fit[fit] + eps) for fit in fits}
    comm_times_gap_by_fit = {fit: comm_by_fit[fit] * (gap_by_fit[fit] + eps) for fit in fits}

    # ---- near-degeneracy cross-check (prints smallest gaps + overlaps)
    report_near_degeneracy_all_fits(
        fits=fits,
        comm_by_fit=comm_by_fit,
        K_by_fit=K_by_fit,
        gap_by_fit=gap_by_fit,
        comm_over_gap_by_fit=comm_over_gap_by_fit,
        topn_gap=args.nd_top_gap,
        topn_K=args.nd_top_K,
        topn_weighted=args.nd_top_weighted,
    )

    # ---- weighted commutator plots
    plot_series(
        shells,
        comm_over_gap_by_fit,
        title="Weighted commutator: comm_norm / (min-gap + eps) (log y)",
        xlabel="shell index k",
        ylabel="comm_norm[k] / (gap[k] + eps)",
        ylog=True,
        savepath=os.path.join(savedir, "stage2_comm_over_gap_log.png"),
    )

    plot_series(
        shells,
        comm_times_gap_by_fit,
        title="Weighted commutator: comm_norm * (min-gap + eps)",
        xlabel="shell index k",
        ylabel="comm_norm[k] * (gap[k] + eps)",
        ylog=False,
        savepath=os.path.join(savedir, "stage2_comm_times_gap.png"),
    )

    # ---- gaps plot
    plot_series(
        shells,
        {fit: gap_by_fit[fit] for fit in fits},
        title="Eigenvalue min-adjacent-gap vs shell (log y)",
        xlabel="shell index k",
        ylabel="min adjacent eigenvalue gap",
        ylog=True,
        savepath=os.path.join(savedir, "stage2_min_gap_vs_shell_log.png"),
    )

    print("\nSaved figures to:", savedir)
    for fn in [
        "stage2_comm_norm_vs_shell.png",
        "stage2_K_vs_shell_log.png",
        "stage2_comm_over_gap_log.png",
        "stage2_comm_times_gap.png",
        "stage2_min_gap_vs_shell_log.png",
    ]:
        print(" -", fn)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
