#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
metric_006.py

Option B: Refine transport rule (midpoint / symmetrized).

PATCH (Stage 0 for metric_007):
- Export per-shell eigensystems to NPZ (same contract as metric_003 patch).

Original file: :contentReference[oaicite:10]{index=10}
"""

import numpy as np
import hashlib
import pandas as pd
import os
import json
import matplotlib.pyplot as plt

# ============================================================
# 0) Configuration
# ============================================================

FITS = ["NUFIT", "BARI", "VALENCIA"]

PREPROCESS = "zscore"
DM32_MODE = "signed"

N_SAMPLES = 5000
N_RADIAL_BINS = 20
MIN_PER_BIN = 150

K_SWEEP = [2, 3]

RNG_SEED = 123
rng = np.random.default_rng(RNG_SEED)

OUTDIR = "metric_006_outputs"
os.makedirs(OUTDIR, exist_ok=True)

EPS = 1e-12

# ----------------------------
# Stage 0 export (NEW)
# ----------------------------
EXPORT_EIGENSYSTEMS = True
EXPORT_DIR = "metric_007_inputs"
EXPORT_TAG = "metric_006"
os.makedirs(EXPORT_DIR, exist_ok=True)

# ============================================================
# 1) Import atlas machinery (from v007)
# ============================================================

from GIKL_neutrino_007_fixed import (
    build_cloud_raw,
    apply_dm32_mode,
    build_global_atlas,
    apply_atlas_preprocess,
)

# ============================================================
# 2) Linear algebra helpers
# ============================================================


def _matrix_fingerprint(A: np.ndarray) -> dict:
    """Stable-ish fingerprint for sanity checks (float tolerant summary + byte hash)."""
    A = np.asarray(A)
    Af = np.ascontiguousarray(A.astype(np.float64, copy=False))
    h = hashlib.sha256(Af.tobytes()).hexdigest()[:16]
    return dict(
        sha16=h,
        shape=tuple(A.shape),
        fro=float(np.linalg.norm(Af, ord='fro')),
        maxabs=float(np.max(np.abs(Af))),
        mean=float(np.mean(Af)),
        std=float(np.std(Af)),
        sym_err=float(np.linalg.norm(Af - Af.T, ord='fro')) if Af.ndim == 2 else float('nan'),
    )

def fisher_eigenvectors(X):
    C = np.cov(X, rowvar=False)
    vals, vecs = np.linalg.eigh(C)
    idx = np.argsort(vals)[::-1]
    return vals[idx], vecs[:, idx], C

def polar_orthogonal(M):
    U, _, Vt = np.linalg.svd(M, full_matrices=False)
    return U @ Vt

def subspace_transport(Va, Vb):
    return polar_orthogonal(Va.T @ Vb)

def frob_norm(A):
    return float(np.linalg.norm(A, ord="fro"))

def orthonormalize(X):
    Q, _ = np.linalg.qr(X)
    return Q

def export_shell_eigs(fit, shells):
    if not shells:
        return
    D = shells[0]["vecs"].shape[0]
    S = len(shells)

    shell_ids = np.array([s["shell"] for s in shells], dtype=int)
    shell_centers = np.array([s["r_mean"] for s in shells], dtype=float)
    counts = np.array([s["n"] for s in shells], dtype=int)

    # metric_006 build_shells does not keep eigvals; compute them here from stored vecs?
    # Better: store eigvals directly during build_shells. We'll do that.
    eigvals = np.zeros((S, D), dtype=float)
    eigvecs = np.zeros((S, D, D), dtype=float)

    fps = []
    for i, s in enumerate(shells):
        eigvals[i, :] = np.asarray(s["eigvals"], dtype=float).ravel()
        eigvecs[i, :, :] = np.asarray(s["vecs"], dtype=float)
        fps.append(s.get("fingerprint", {}))

    meta = {
        "tag": EXPORT_TAG,
        "fit": fit,
        "preprocess": PREPROCESS,
        "dm32_mode": DM32_MODE,
        "N_SAMPLES_per_ordering": int(N_SAMPLES),
        "N_RADIAL_BINS": int(N_RADIAL_BINS),
        "MIN_PER_BIN": int(MIN_PER_BIN),
        "note": "Per-shell covariance/Fisher eigensystems. eigvecs are columns, sorted by descending eigvals.",
    }

    outpath = os.path.join(
        EXPORT_DIR,
        f"eigshells__{EXPORT_TAG}__{fit}__{PREPROCESS}__{DM32_MODE}.npz"
    )
    np.savez_compressed(
        outpath,
        metric_id=EXPORT_TAG,
        fit_name=fit,
        shell_ids=shell_ids,
        shell_centers=shell_centers,
        counts=counts,
        eigvals=eigvals,
        eigvecs=eigvecs,
        fingerprints=np.array(fps, dtype=object),
        meta_json=json.dumps(meta),
    )
    print("[export] wrote:", outpath)

# ============================================================
# 3) Grassmann geodesic midpoint subspace
# ============================================================

def grassmann_midpoint(Va, Vb):
    K = Va.shape[1]
    M = Va.T @ Vb
    U, s, Vt = np.linalg.svd(M, full_matrices=False)

    s = np.clip(s, -1.0, 1.0)
    theta = np.arccos(s)

    A = Va @ U
    V = Vt.T
    B = Vb @ V

    B_perp = B - A * s
    Q = orthonormalize(B_perp)

    c = np.cos(theta / 2.0)
    t = np.sin(theta / 2.0)

    Vm_cols = []
    for i in range(K):
        if t[i] < 1e-10:
            Vm_cols.append(A[:, i])
        else:
            Vm_cols.append(A[:, i] * c[i] + Q[:, i] * t[i])

    Vm = np.column_stack(Vm_cols)
    Vm = orthonormalize(Vm)
    return Vm

# ============================================================
# 4) Build shells
# ============================================================

def build_shells(fit, atlas):
    X_no = build_cloud_raw(fit, "NO", N_SAMPLES, seed=1)
    X_io = build_cloud_raw(fit, "IO", N_SAMPLES, seed=2)

    X_no = apply_atlas_preprocess(apply_dm32_mode(X_no, DM32_MODE), atlas)
    X_io = apply_atlas_preprocess(apply_dm32_mode(X_io, DM32_MODE), atlas)

    X = np.vstack([X_no, X_io])

    center = np.median(X, axis=0)
    r = np.linalg.norm(X - center, axis=1)

    edges = np.quantile(r, np.linspace(0, 1, N_RADIAL_BINS + 1))
    sid = np.digitize(r, edges) - 1

    shells = []
    for k in range(N_RADIAL_BINS):
        m = (sid == k)
        n = int(np.sum(m))
        if n < MIN_PER_BIN:
            continue

        Xk = X[m]
        r_mean = float(np.mean(r[m]))

        vals, vecs, C = fisher_eigenvectors(Xk)
        fp = _matrix_fingerprint(C)
        fp["k"] = int(k)
        d = vecs.shape[0]

        shells.append({
            "shell": int(k),
            "r_mean": float(r_mean),
            "eigvals": vals,    # NEW: store for export
            "vecs": vecs,
            "d": int(d),
            "n": n,
            "fingerprint": fp,
        })

    shells = sorted(shells, key=lambda s: s["r_mean"])
    return shells

# ============================================================
# 5) Triangle defects under refined rules
# ============================================================

def triangle_defects_refined(shells, K):
    rows = []
    if len(shells) < 3:
        return pd.DataFrame(rows)

    K_eff = min(K, min(s["d"] for s in shells))

    for i in range(len(shells) - 2):
        s0, s1, s2 = shells[i], shells[i+1], shells[i+2]
        V0 = s0["vecs"][:, :K_eff]
        V1 = s1["vecs"][:, :K_eff]
        V2 = s2["vecs"][:, :K_eff]

        R01 = subspace_transport(V0, V1)
        R12 = subspace_transport(V1, V2)
        R_fine = R01 @ R12

        R02_dir = subspace_transport(V0, V2)

        Vm = grassmann_midpoint(V0, V2)
        R0m = subspace_transport(V0, Vm)
        Rm2 = subspace_transport(Vm, V2)
        R02_mid = R0m @ Rm2

        R02_sym = polar_orthogonal(0.5 * (R02_dir + R02_mid))

        rows.append({
            "shell0": s0["shell"],
            "shell1": s1["shell"],
            "shell2": s2["shell"],
            "r_mid": 0.5 * (s0["r_mean"] + s2["r_mean"]),
            "K": int(K_eff),
            "defect_direct": frob_norm(R02_dir - R_fine),
            "defect_midpoint": frob_norm(R02_mid - R_fine),
            "defect_sym": frob_norm(R02_sym - R_fine),
        })

    return pd.DataFrame(rows)

def global_defects_refined(shells, K):
    if len(shells) < 2:
        return {"global_direct": np.nan, "global_midpoint": np.nan, "global_sym": np.nan, "K_eff": np.nan}

    K_eff = min(K, min(s["d"] for s in shells))
    V_first = shells[0]["vecs"][:, :K_eff]
    V_last  = shells[-1]["vecs"][:, :K_eff]

    R_comp = np.eye(K_eff)
    for i in range(len(shells) - 1):
        V0 = shells[i]["vecs"][:, :K_eff]
        V1 = shells[i+1]["vecs"][:, :K_eff]
        R_comp = R_comp @ subspace_transport(V0, V1)

    R_dir = subspace_transport(V_first, V_last)

    Vm = grassmann_midpoint(V_first, V_last)
    R_mid = subspace_transport(V_first, Vm) @ subspace_transport(Vm, V_last)

    R_sym = polar_orthogonal(0.5 * (R_dir + R_mid))

    return {
        "global_direct": frob_norm(R_dir - R_comp),
        "global_midpoint": frob_norm(R_mid - R_comp),
        "global_sym": frob_norm(R_sym - R_comp),
        "K_eff": int(K_eff),
    }

# ============================================================
# 6) Main
# ============================================================

def main():
    atlas = build_global_atlas(PREPROCESS, DM32_MODE, atlas_quantiles=None)

    shells_by_fit = {}
    for fit in FITS:
        print(f"\n--- FIT: {fit} (building shells) ---")
        shells_by_fit[fit] = build_shells(fit, atlas)
        print(f"Shells kept: {len(shells_by_fit[fit])}")

        if EXPORT_EIGENSYSTEMS:
            export_shell_eigs(fit, shells_by_fit[fit])

    all_rows = []
    sum_rows = []

    for K in K_SWEEP:
        print(f"\n=== K = {K} ===")
        for fit in FITS:
            shells = shells_by_fit[fit]
            df = triangle_defects_refined(shells, K)
            df["fit"] = fit
            all_rows.append(df)

            gd = global_defects_refined(shells, K)
            sum_rows.append({
                "fit": fit,
                "K": int(gd["K_eff"]),
                "num_shells": len(shells),
                "global_defect_direct": gd["global_direct"],
                "global_defect_midpoint": gd["global_midpoint"],
                "global_defect_sym": gd["global_sym"],
            })

            if len(df) > 0:
                plt.figure()
                plt.plot(df["r_mid"], df["defect_direct"], "o-", label="direct")
                plt.plot(df["r_mid"], df["defect_midpoint"], "o-", label="midpoint")
                plt.plot(df["r_mid"], df["defect_sym"], "o-", label="sym")
                plt.xlabel("r (scale)")
                plt.ylabel("triangle defect ||R02 - R01R12||_F")
                plt.title(f"{fit}: refined transport defects (K={int(df['K'].iloc[0])})")
                plt.legend()
                plt.tight_layout()
                plt.savefig(f"{OUTDIR}/{fit}_defects_K{K}.png")
                plt.close()

        dfK = pd.concat(
            [d for d in all_rows if len(d) > 0 and int(d["K"].iloc[0]) == K],
            ignore_index=True
        ) if any(len(d) > 0 and int(d["K"].iloc[0]) == K for d in all_rows) else pd.DataFrame()

        if len(dfK) > 0:
            plt.figure()
            for fit in FITS:
                dff = dfK[dfK["fit"] == fit]
                if len(dff) == 0:
                    continue
                plt.plot(dff["r_mid"], dff["defect_direct"], "o-", label=f"{fit} (direct)")
            plt.xlabel("r (scale)")
            plt.ylabel("triangle defect")
            plt.title(f"metric_006: direct defects vs scale (K={K})")
            plt.legend()
            plt.tight_layout()
            plt.savefig(f"{OUTDIR}/crossfit_direct_K{K}.png")
            plt.close()

            plt.figure()
            for fit in FITS:
                dff = dfK[dfK["fit"] == fit]
                if len(dff) == 0:
                    continue
                plt.plot(dff["r_mid"], dff["defect_midpoint"], "o-", label=f"{fit} (midpoint)")
            plt.xlabel("r (scale)")
            plt.ylabel("triangle defect")
            plt.title(f"metric_006: midpoint defects vs scale (K={K})")
            plt.legend()
            plt.tight_layout()
            plt.savefig(f"{OUTDIR}/crossfit_midpoint_K{K}.png")
            plt.close()

            plt.figure()
            for fit in FITS:
                dff = dfK[dfK["fit"] == fit]
                if len(dff) == 0:
                    continue
                plt.plot(dff["r_mid"], dff["defect_sym"], "o-", label=f"{fit} (sym)")
            plt.xlabel("r (scale)")
            plt.ylabel("triangle defect")
            plt.title(f"metric_006: sym defects vs scale (K={K})")
            plt.legend()
            plt.tight_layout()
            plt.savefig(f"{OUTDIR}/crossfit_sym_K{K}.png")
            plt.close()

    df_all = pd.concat(all_rows, ignore_index=True) if all_rows else pd.DataFrame()
    df_sum = pd.DataFrame(sum_rows)

    df_all.to_csv(f"{OUTDIR}/metric_006_triangle_defects.csv", index=False)
    df_sum.to_csv(f"{OUTDIR}/metric_006_summary.csv", index=False)

    print("\n=== metric_006 completed ===")
    print("Outputs written to:", OUTDIR)
    if EXPORT_EIGENSYSTEMS:
        print("Stage-0 eigensystems written to:", EXPORT_DIR)

if __name__ == "__main__":
    main()
