#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GIKL_neutrino_004.py

v004: Table-driven neutrino-oscillation parameter ingestion (manual transcription)
--------------------------------------------------------------------------
This version avoids PDF glyph-map / table-extraction brittleness by using
the values from the (screenshoted) table "Table 14.7: Global fit results".

Key features
- Treats each column (NuFIT w/o SK-atm, BARI, VALENCIA) as a separate "theory"/fit.
- Builds NO and IO parameter clouds using the table central values + uncertainties.
- Uses circular (angle) handling for δ_CP: sample angle on S^1 and embed as (cos, sin)
  to avoid discontinuities near 0°/360°.
- Uses shared-grid histogram + safe KL + convex GI-flow tracking KL(current || target).

Units / scaling from the table
- sin^2(theta12) / 10^-1  : table entry x => x * 1e-1
- sin^2(theta23) / 10^-1  : table entry x => x * 1e-1
- sin^2(theta13) / 10^-2  : table entry x => x * 1e-2
- δ_CP / degrees          : degrees
- Δm^2_21 / meV^2         : meV^2
- Δm^2_32 / meV^2         : meV^2 (IO values negative in the table)
"""

import numpy as np

# ----------------------------
# 1) Manual transcription of Table 14.7 (central ± errors)
# ----------------------------
# Each entry: (central, +err, -err) in the *table's displayed units*.
# We'll apply the scale factors below.

TABLE_14_7 = {
    "NUFIT": {
        "NO": {
            "sin2_t12_10m1": (3.03, 0.12, 0.11),
            "sin2_t23_10m1": (5.72, 0.18, 0.23),
            "sin2_t13_10m2": (2.203, 0.056, 0.059),
            "dcp_deg":      (197.0, 42.0, 25.0),
            "dm2_21":       (74.1, 2.1, 2.0),
            "dm2_32":       (2437.0, 28.0, 27.0),
        },
        "IO": {
            "sin2_t12_10m1": (3.03, 0.12, 0.11),
            "sin2_t23_10m1": (5.78, 0.16, 0.21),
            "sin2_t13_10m2": (2.219, 0.060, 0.057),
            "dcp_deg":      (286.0, 27.0, 32.0),
            "dm2_21":       (74.1, 2.1, 2.0),
            "dm2_32":       (-2498.0, 32.0, 25.0),
        },
    },
    "BARI": {
        "NO": {
            "sin2_t12_10m1": (3.03, 0.13, 0.13),
            "sin2_t23_10m1": (4.55, 0.15, 0.15),
            "sin2_t13_10m2": (2.23, 0.06, 0.06),
            "dcp_deg":      (223.0, 32.0, 23.0),
            "dm2_21":       (73.6, 1.6, 1.5),
            "dm2_32":       (2448.0, 23.0, 31.0),
        },
        "IO": {
            "sin2_t12_10m1": (3.03, 0.13, 0.13),
            "sin2_t23_10m1": (5.69, 0.13, 0.21),
            "sin2_t13_10m2": (2.23, 0.06, 0.06),
            "dcp_deg":      (274.0, 25.0, 27.0),
            "dm2_21":       (73.6, 1.6, 1.5),
            "dm2_32":       (-2492.0, 25.0, 30.0),
        },
    },
    "VALENCIA": {
        "NO": {
            "sin2_t12_10m1": (3.18, 0.16, 0.16),
            "sin2_t23_10m1": (5.74, 0.14, 0.14),
            "sin2_t13_10m2": (2.200, 0.069, 0.062),
            "dcp_deg":      (194.0, 24.0, 22.0),
            "dm2_21":       (75.0, 2.2, 2.0),
            "dm2_32":       (2470.0, 24.0, 30.0),
        },
        "IO": {
            "sin2_t12_10m1": (3.18, 0.16, 0.16),
            "sin2_t23_10m1": (5.78, 0.10, 0.17),
            "sin2_t13_10m2": (2.225, 0.064, 0.070),
            "dcp_deg":      (284.0, 26.0, 28.0),
            "dm2_21":       (75.0, 2.2, 2.0),
            "dm2_32":       (-2520.0, 30.0, 20.0),
        },
    },
}

# Scale factors from the table headings
SCALE = {
    "sin2_t12_10m1": 1e-1,
    "sin2_t23_10m1": 1e-1,
    "sin2_t13_10m2": 1e-2,
    "dcp_deg":       1.0,
    "dm2_21":        1.0,
    "dm2_32":        1.0,
}

# ----------------------------
# 2) Utilities: angle-safe sampling & vector building
# ----------------------------
def sym_sigma(up: float, down: float) -> float:
    """Convert asymmetric (+up, -down) to a single sigma (mean of magnitudes)."""
    return 0.5 * (abs(up) + abs(down))

def sample_normal(rng: np.random.Generator, mu: float, up: float, down: float, n: int) -> np.ndarray:
    """Normal sampling with sigma derived from asymmetric errors."""
    sig = sym_sigma(up, down)
    sig = max(sig, 1e-12)
    return rng.normal(mu, sig, size=n)

def sample_angle_deg(rng: np.random.Generator, mu_deg: float, up: float, down: float, n: int) -> np.ndarray:
    """
    Sample an angle in degrees with a Gaussian in angle-space, then wrap to [0, 360).
    (For MVP this is sufficient; later you may switch to Von Mises.)
    """
    sig = sym_sigma(up, down)
    sig = max(sig, 1e-12)
    ang = rng.normal(mu_deg, sig, size=n) % 360.0
    return ang

def build_cloud_from_table(fit: str, ordering: str, n: int = 4000, seed: int = 0) -> np.ndarray:
    """
    Returns a cloud with coordinates:
      [sin^2 t12, sin^2 t23, sin^2 t13, cos(dcp), sin(dcp), dm2_21, dm2_32]
    """
    rng = np.random.default_rng(seed)
    row = TABLE_14_7[fit][ordering]

    s12 = sample_normal(rng, *row["sin2_t12_10m1"], n) * SCALE["sin2_t12_10m1"]
    s23 = sample_normal(rng, *row["sin2_t23_10m1"], n) * SCALE["sin2_t23_10m1"]
    s13 = sample_normal(rng, *row["sin2_t13_10m2"], n) * SCALE["sin2_t13_10m2"]
    dm21 = sample_normal(rng, *row["dm2_21"], n)
    dm32 = sample_normal(rng, *row["dm2_32"], n)

    dcp = sample_angle_deg(rng, *row["dcp_deg"], n)
    rad = np.deg2rad(dcp)
    c = np.cos(rad)
    s = np.sin(rad)

    return np.vstack([s12, s23, s13, c, s, dm21, dm32]).T

def centers_from_table(fit: str, ordering: str) -> np.ndarray:
    """Central values in the same embedding used for clouds."""
    row = TABLE_14_7[fit][ordering]
    s12 = row["sin2_t12_10m1"][0] * SCALE["sin2_t12_10m1"]
    s23 = row["sin2_t23_10m1"][0] * SCALE["sin2_t23_10m1"]
    s13 = row["sin2_t13_10m2"][0] * SCALE["sin2_t13_10m2"]
    dm21 = row["dm2_21"][0]
    dm32 = row["dm2_32"][0]
    dcp = row["dcp_deg"][0] % 360.0
    rad = np.deg2rad(dcp)
    c = np.cos(rad)
    s = np.sin(rad)
    return np.array([s12, s23, s13, c, s, dm21, dm32], dtype=float)

# ----------------------------
# 3) Shared-grid histogram, safe KL, GI-flow
# ----------------------------
def make_shared_edges(Xa: np.ndarray, Xb: np.ndarray, bins: int = 18):
    Xall = np.vstack([Xa, Xb])
    mins = np.nanmin(Xall, axis=0)
    maxs = np.nanmax(Xall, axis=0)

    span = (maxs - mins)
    span = np.where(np.isfinite(span) & (span > 0), span, 1.0)
    maxs = mins + span

    edges = [np.linspace(0.0, 1.0, bins + 1) for _ in range(Xall.shape[1])]
    return mins, maxs, edges

def hist_nd_shared(X: np.ndarray, mins: np.ndarray, maxs: np.ndarray, edges):
    X = np.asarray(X, dtype=float)
    Y = (X - mins) / (maxs - mins + 1e-12)
    Y = np.clip(Y, 0.0, 1.0)
    H, _ = np.histogramdd(Y, bins=edges)
    return H / (H.sum() + 1e-15)

def safe_kl(P: np.ndarray, Q: np.ndarray, eps: float = 1e-15) -> float:
    P = np.asarray(P, dtype=float).ravel()
    Q = np.asarray(Q, dtype=float).ravel()
    P = np.clip(P, eps, None); Q = np.clip(Q, eps, None)
    P = P / P.sum(); Q = Q / Q.sum()
    return max(0.0, float(np.sum(P * np.log(P / Q))))

def gi_flow(current: np.ndarray, target: np.ndarray, alpha: float = 0.2, T: int = 30):
    cur = np.asarray(current, dtype=float).copy()
    tgt = np.asarray(target, dtype=float).copy()
    cur = np.clip(cur, 0.0, None); cur = cur / (cur.sum() + 1e-15)
    tgt = np.clip(tgt, 0.0, None); tgt = tgt / (tgt.sum() + 1e-15)

    track = []
    for _ in range(T):
        track.append(safe_kl(cur, tgt))
        cur = (1.0 - alpha) * cur + alpha * tgt
        cur = np.clip(cur, 0.0, None); cur = cur / (cur.sum() + 1e-15)
    track.append(safe_kl(cur, tgt))
    return np.array(track), cur

# ----------------------------
# 4) Run: each fit as a separate "theory"
# ----------------------------
def run_one_fit(fit: str, bins: int = 18, n: int = 5000):
    X_no = build_cloud_from_table(fit, "NO", n=n, seed=1)
    X_io = build_cloud_from_table(fit, "IO", n=n, seed=2)

    mins, maxs, edges = make_shared_edges(X_no, X_io, bins=bins)
    P_no = hist_nd_shared(X_no, mins, maxs, edges)
    P_io = hist_nd_shared(X_io, mins, maxs, edges)

    kl_no_io = safe_kl(P_no, P_io)
    kl_io_no = safe_kl(P_io, P_no)

    track_no_to_io, _ = gi_flow(P_no, P_io, alpha=0.2, T=30)
    track_io_to_no, _ = gi_flow(P_io, P_no, alpha=0.2, T=30)

    c_no = centers_from_table(fit, "NO")
    c_io = centers_from_table(fit, "IO")

    print("\n==============================")
    print(f"FIT/THEORY: {fit}")
    print("Embedding coords: [s12, s23, s13, cos(dcp), sin(dcp), dm21, dm32]")
    print("Center NO:", np.array2string(c_no, precision=6, floatmode="fixed"))
    print("Center IO:", np.array2string(c_io, precision=6, floatmode="fixed"))
    print("KL(NO || IO) initial:", kl_no_io)
    print("KL(IO || NO) initial:", kl_io_no)
    print("GI-flow KL track NO→IO (first 5):", track_no_to_io[:5])
    print("GI-flow KL track IO→NO (first 5):", track_io_to_no[:5])
    print("==============================\n")

    return {
        "fit": fit,
        "kl_no_io": kl_no_io,
        "kl_io_no": kl_io_no,
        "track_no_to_io": track_no_to_io,
        "track_io_to_no": track_io_to_no,
    }

def cross_fit_comparisons(fits, bins: int = 18, n: int = 5000):
    """
    Robustness check: compare NO distributions across fits, and IO across fits.
    """
    clouds = {}
    for fit in fits:
        clouds[(fit, "NO")] = build_cloud_from_table(fit, "NO", n=n, seed=10 + (hash(fit) % 997))
        clouds[(fit, "IO")] = build_cloud_from_table(fit, "IO", n=n, seed=20 + (hash(fit) % 997))

    for ordering in ["NO", "IO"]:
        print(f"\n=== CROSS-FIT KLs for ordering: {ordering} ===")
        for i in range(len(fits)):
            for j in range(i + 1, len(fits)):
                f1, f2 = fits[i], fits[j]
                X1, X2 = clouds[(f1, ordering)], clouds[(f2, ordering)]
                mins, maxs, edges = make_shared_edges(X1, X2, bins=bins)
                P1 = hist_nd_shared(X1, mins, maxs, edges)
                P2 = hist_nd_shared(X2, mins, maxs, edges)
                print(f"{f1:8s} vs {f2:8s} | KL({f1}||{f2})={safe_kl(P1,P2):.6f} | KL({f2}||{f1})={safe_kl(P2,P1):.6f}")
        print("====================================\n")

if __name__ == "__main__":
    fits = ["NUFIT", "BARI", "VALENCIA"]

    for fit in fits:
        run_one_fit(fit, bins=18, n=5000)

    cross_fit_comparisons(fits, bins=18, n=5000)
