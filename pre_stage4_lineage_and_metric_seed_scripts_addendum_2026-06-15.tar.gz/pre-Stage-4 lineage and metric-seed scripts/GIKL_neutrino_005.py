#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GIKL_neutrino_005.py

v005 goals (as requested)
- Run KL + GI-flow under two independent preprocessing regimes:
    (A) Per-dimension z-scoring before histogramming
    (B) Physically-motivated dimensionless coordinates (adimensionalization)
- Add a toggle experiment for dm2_32:
    keep signed / take abs(dm2_32) / drop dm2_32 entirely
- Export a compact CSV with: fit, preprocessing mode, dm32 mode,
  KLs, GI-flow track summaries, and cross-fit KLs (NO vs NO; IO vs IO).

Important: This file still does NOT implement variograms / fractality / quasi-conformality.
It is the "clean KL+GI sanity layer" you can trust before adding those diagnostics.

Data source: manual transcription from Table 14.7 (your screenshot).
"""

import numpy as np
import csv
from dataclasses import dataclass
from typing import Dict, Tuple, List

# ============================
# 0) Configuration
# ============================

FITS = ["NUFIT", "BARI", "VALENCIA"]

# Two independent preprocessing regimes to compare
PREPROCESS_MODES = ["zscore", "dimensionless"]  # run both

# dm2_32 handling toggles
DM32_MODES = ["signed", "abs", "drop"]          # run all three

# Cloud + histogram settings
N_SAMPLES = 5000
BINS = 18
ALPHA = 0.2
T_STEPS = 30

# Dimensionless scales (physically natural-ish)
# sin^2 and (cos,sin) are already dimensionless.
# dm2_21 ~ 74 meV^2 ; dm2_32 ~ 2500 meV^2
DM21_SCALE = 75.0
DM32_SCALE = 2500.0

# Output
CSV_OUT = "neutrino_kl_v005_results.csv"

# ============================
# 1) Manual transcription of Table 14.7 (central ± errors)
# ============================
# Each entry: (central, +err, -err) in the *table's displayed units*.

TABLE_14_7: Dict[str, Dict[str, Dict[str, Tuple[float, float, float]]]] = {
    "NUFIT": {
        "NO": {
            "sin2_t12_10m1": (3.03, 0.12, 0.11),
            "sin2_t23_10m1": (5.72, 0.18, 0.23),
            "sin2_t13_10m2": (2.203, 0.056, 0.059),
            "dcp_deg":      (197.0, 42.0, 25.0),
            "dm2_21":       (74.1, 2.1, 2.0),
            "dm2_32":       (2437.0, 28.0, 27.0),
        },
        "IO": {
            "sin2_t12_10m1": (3.03, 0.12, 0.11),
            "sin2_t23_10m1": (5.78, 0.16, 0.21),
            "sin2_t13_10m2": (2.219, 0.060, 0.057),
            "dcp_deg":      (286.0, 27.0, 32.0),
            "dm2_21":       (74.1, 2.1, 2.0),
            "dm2_32":       (-2498.0, 32.0, 25.0),
        },
    },
    "BARI": {
        "NO": {
            "sin2_t12_10m1": (3.03, 0.13, 0.13),
            "sin2_t23_10m1": (4.55, 0.15, 0.15),
            "sin2_t13_10m2": (2.23, 0.06, 0.06),
            "dcp_deg":      (223.0, 32.0, 23.0),
            "dm2_21":       (73.6, 1.6, 1.5),
            "dm2_32":       (2448.0, 23.0, 31.0),
        },
        "IO": {
            "sin2_t12_10m1": (3.03, 0.13, 0.13),
            "sin2_t23_10m1": (5.69, 0.13, 0.21),
            "sin2_t13_10m2": (2.23, 0.06, 0.06),
            "dcp_deg":      (274.0, 25.0, 27.0),
            "dm2_21":       (73.6, 1.6, 1.5),
            "dm2_32":       (-2492.0, 25.0, 30.0),
        },
    },
    "VALENCIA": {
        "NO": {
            "sin2_t12_10m1": (3.18, 0.16, 0.16),
            "sin2_t23_10m1": (5.74, 0.14, 0.14),
            "sin2_t13_10m2": (2.200, 0.069, 0.062),
            "dcp_deg":      (194.0, 24.0, 22.0),
            "dm2_21":       (75.0, 2.2, 2.0),
            "dm2_32":       (2470.0, 24.0, 30.0),
        },
        "IO": {
            "sin2_t12_10m1": (3.18, 0.16, 0.16),
            "sin2_t23_10m1": (5.78, 0.10, 0.17),
            "sin2_t13_10m2": (2.225, 0.064, 0.070),
            "dcp_deg":      (284.0, 26.0, 28.0),
            "dm2_21":       (75.0, 2.2, 2.0),
            "dm2_32":       (-2520.0, 30.0, 20.0),
        },
    },
}

# Scale factors from the table headings
SCALE = {
    "sin2_t12_10m1": 1e-1,
    "sin2_t23_10m1": 1e-1,
    "sin2_t13_10m2": 1e-2,
    "dcp_deg":       1.0,
    "dm2_21":        1.0,
    "dm2_32":        1.0,
}

# ============================
# 2) Sampling + embeddings
# ============================

def sym_sigma(up: float, down: float) -> float:
    return 0.5 * (abs(up) + abs(down))

def sample_normal(rng: np.random.Generator, mu: float, up: float, down: float, n: int) -> np.ndarray:
    sig = max(sym_sigma(up, down), 1e-12)
    return rng.normal(mu, sig, size=n)

def sample_angle_deg(rng: np.random.Generator, mu_deg: float, up: float, down: float, n: int) -> np.ndarray:
    sig = max(sym_sigma(up, down), 1e-12)
    return (rng.normal(mu_deg, sig, size=n) % 360.0)

def build_cloud(fit: str, ordering: str, n: int, seed: int) -> np.ndarray:
    """
    Base embedding (before preprocess / dm32 toggles):
      [s12, s23, s13, cos(dcp), sin(dcp), dm21, dm32]
    """
    rng = np.random.default_rng(seed)
    row = TABLE_14_7[fit][ordering]

    s12 = sample_normal(rng, *row["sin2_t12_10m1"], n) * SCALE["sin2_t12_10m1"]
    s23 = sample_normal(rng, *row["sin2_t23_10m1"], n) * SCALE["sin2_t23_10m1"]
    s13 = sample_normal(rng, *row["sin2_t13_10m2"], n) * SCALE["sin2_t13_10m2"]
    dm21 = sample_normal(rng, *row["dm2_21"], n)
    dm32 = sample_normal(rng, *row["dm2_32"], n)

    dcp = sample_angle_deg(rng, *row["dcp_deg"], n)
    rad = np.deg2rad(dcp)
    c = np.cos(rad)
    s = np.sin(rad)

    return np.vstack([s12, s23, s13, c, s, dm21, dm32]).T

# ============================
# 3) Preprocessing regimes
# ============================

def apply_dm32_mode(X: np.ndarray, mode: str) -> np.ndarray:
    X = np.asarray(X, dtype=float)
    if mode == "signed":
        return X
    if mode == "abs":
        Y = X.copy()
        Y[:, -1] = np.abs(Y[:, -1])
        return Y
    if mode == "drop":
        return X[:, :-1]
    raise ValueError(f"Unknown dm32 mode: {mode}")

def apply_dimensionless(X: np.ndarray) -> np.ndarray:
    """
    Adimensionalization: divide (dm21, dm32) by physically natural scales.
    Structure assumptions:
      - dim==7: [..., dm21, dm32]
      - dim==6: [..., dm21]  (dm32 dropped)
    """
    X = np.asarray(X, dtype=float).copy()
    if X.shape[1] == 7:
        X[:, -2] = X[:, -2] / DM21_SCALE
        X[:, -1] = X[:, -1] / DM32_SCALE
    elif X.shape[1] == 6:
        X[:, -1] = X[:, -1] / DM21_SCALE
    return X

def apply_zscore_pair(X_no: np.ndarray, X_io: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    Xall = np.vstack([X_no, X_io])
    mu = Xall.mean(axis=0)
    sd = Xall.std(axis=0)
    sd = np.where(sd > 0, sd, 1.0)
    return (X_no - mu) / sd, (X_io - mu) / sd

# ============================
# 4) Histogram + KL + GI flow
# ============================

def make_shared_edges(Xa: np.ndarray, Xb: np.ndarray, bins: int):
    Xall = np.vstack([Xa, Xb])
    mins = np.nanmin(Xall, axis=0)
    maxs = np.nanmax(Xall, axis=0)

    span = maxs - mins
    span = np.where(np.isfinite(span) & (span > 0), span, 1.0)
    maxs = mins + span

    edges = [np.linspace(0.0, 1.0, bins + 1) for _ in range(Xall.shape[1])]
    return mins, maxs, edges

def hist_nd_shared(X: np.ndarray, mins: np.ndarray, maxs: np.ndarray, edges):
    X = np.asarray(X, dtype=float)
    Y = (X - mins) / (maxs - mins + 1e-12)
    Y = np.clip(Y, 0.0, 1.0)
    H, _ = np.histogramdd(Y, bins=edges)
    return H / (H.sum() + 1e-15)

def safe_kl(P: np.ndarray, Q: np.ndarray, eps: float = 1e-15) -> float:
    P = np.asarray(P, dtype=float).ravel()
    Q = np.asarray(Q, dtype=float).ravel()
    P = np.clip(P, eps, None); Q = np.clip(Q, eps, None)
    P = P / P.sum(); Q = Q / Q.sum()
    return max(0.0, float(np.sum(P * np.log(P / Q))))

def gi_flow(current: np.ndarray, target: np.ndarray, alpha: float, T: int):
    cur = np.asarray(current, dtype=float).copy()
    tgt = np.asarray(target, dtype=float).copy()
    cur = np.clip(cur, 0.0, None); cur = cur / (cur.sum() + 1e-15)
    tgt = np.clip(tgt, 0.0, None); tgt = tgt / (tgt.sum() + 1e-15)

    track = []
    for _ in range(T):
        track.append(safe_kl(cur, tgt))
        cur = (1.0 - alpha) * cur + alpha * tgt
        cur = np.clip(cur, 0.0, None); cur = cur / (cur.sum() + 1e-15)
    track.append(safe_kl(cur, tgt))
    return np.array(track), cur

def track_summary(track: np.ndarray) -> Dict[str, float]:
    t = np.asarray(track, dtype=float)
    init = float(t[0])
    final = float(t[-1])
    auc = float(np.trapz(t, dx=1.0))
    target = init / 2.0
    idxs = np.where(t <= target)[0]
    half = float(idxs[0]) if idxs.size else float("nan")
    idxs1 = np.where(t <= 1.0)[0]
    t1 = float(idxs1[0]) if idxs1.size else float("nan")
    return {"kl_init": init, "kl_final": final, "auc": auc, "t_half": half, "t_below1": t1}

# ============================
# 5) Experiment runner
# ============================

@dataclass
class FitResult:
    fit: str
    preprocess: str
    dm32_mode: str
    kl_no_io: float
    kl_io_no: float
    track_no_to_io: np.ndarray
    track_io_to_no: np.ndarray

def run_one(fit: str, preprocess: str, dm32_mode: str) -> FitResult:
    X_no = build_cloud(fit, "NO", n=N_SAMPLES, seed=1)
    X_io = build_cloud(fit, "IO", n=N_SAMPLES, seed=2)

    X_no = apply_dm32_mode(X_no, dm32_mode)
    X_io = apply_dm32_mode(X_io, dm32_mode)

    if preprocess == "dimensionless":
        X_no = apply_dimensionless(X_no)
        X_io = apply_dimensionless(X_io)
    elif preprocess == "zscore":
        X_no, X_io = apply_zscore_pair(X_no, X_io)
    else:
        raise ValueError(f"Unknown preprocess mode: {preprocess}")

    mins, maxs, edges = make_shared_edges(X_no, X_io, bins=BINS)
    P_no = hist_nd_shared(X_no, mins, maxs, edges)
    P_io = hist_nd_shared(X_io, mins, maxs, edges)

    kl_no_io = safe_kl(P_no, P_io)
    kl_io_no = safe_kl(P_io, P_no)

    track_no_to_io, _ = gi_flow(P_no, P_io, alpha=ALPHA, T=T_STEPS)
    track_io_to_no, _ = gi_flow(P_io, P_no, alpha=ALPHA, T=T_STEPS)

    return FitResult(
        fit=fit,
        preprocess=preprocess,
        dm32_mode=dm32_mode,
        kl_no_io=kl_no_io,
        kl_io_no=kl_io_no,
        track_no_to_io=track_no_to_io,
        track_io_to_no=track_io_to_no,
    )

def cross_fit_kls(ordering: str, preprocess: str, dm32_mode: str) -> List[Dict[str, float]]:
    clouds = {}
    for fit in FITS:
        X = build_cloud(fit, ordering, n=N_SAMPLES, seed=10 + (hash((fit, ordering)) % 997))
        X = apply_dm32_mode(X, dm32_mode)
        if preprocess == "dimensionless":
            X = apply_dimensionless(X)
        elif preprocess == "zscore":
            # cross-fit zscore: within-cloud normalization (keeps "shape" but removes scale)
            mu = X.mean(axis=0)
            sd = X.std(axis=0)
            sd = np.where(sd > 0, sd, 1.0)
            X = (X - mu) / sd
        clouds[fit] = X

    out = []
    for i in range(len(FITS)):
        for j in range(i + 1, len(FITS)):
            f1, f2 = FITS[i], FITS[j]
            X1, X2 = clouds[f1], clouds[f2]
            mins, maxs, edges = make_shared_edges(X1, X2, bins=BINS)
            P1 = hist_nd_shared(X1, mins, maxs, edges)
            P2 = hist_nd_shared(X2, mins, maxs, edges)
            out.append({
                "ordering": ordering,
                "preprocess": preprocess,
                "dm32_mode": dm32_mode,
                "fit_a": f1,
                "fit_b": f2,
                "kl_a_b": safe_kl(P1, P2),
                "kl_b_a": safe_kl(P2, P1),
            })
    return out

def main():
    all_rows = []
    cross_rows = []

    print("\n=== v005 RUN SETTINGS ===")
    print("FITS:", FITS)
    print("PREPROCESS_MODES:", PREPROCESS_MODES)
    print("DM32_MODES:", DM32_MODES)
    print(f"N={N_SAMPLES}, bins={BINS}, alpha={ALPHA}, T={T_STEPS}")
    print("=========================\n")

    for preprocess in PREPROCESS_MODES:
        for dm32_mode in DM32_MODES:
            print(f"\n######## preprocess={preprocess} | dm32_mode={dm32_mode} ########")
            for fit in FITS:
                res = run_one(fit, preprocess, dm32_mode)
                s1 = track_summary(res.track_no_to_io)
                s2 = track_summary(res.track_io_to_no)

                print(f"\nFIT: {fit}")
                print(f"KL(NO||IO)={res.kl_no_io:.6f}  KL(IO||NO)={res.kl_io_no:.6f}")
                print("NO→IO first 5:", res.track_no_to_io[:5])
                print("IO→NO first 5:", res.track_io_to_no[:5])
                print(f"NO→IO t_half={s1['t_half']}  t<=1={s1['t_below1']}  AUC={s1['auc']:.3f}")
                print(f"IO→NO t_half={s2['t_half']}  t<=1={s2['t_below1']}  AUC={s2['auc']:.3f}")

                row = {
                    "fit": fit,
                    "preprocess": preprocess,
                    "dm32_mode": dm32_mode,
                    "n": N_SAMPLES,
                    "bins": BINS,
                    "alpha": ALPHA,
                    "T": T_STEPS,
                    "kl_no_io": res.kl_no_io,
                    "kl_io_no": res.kl_io_no,
                    "no_to_io_kl_init": s1["kl_init"],
                    "no_to_io_kl_final": s1["kl_final"],
                    "no_to_io_auc": s1["auc"],
                    "no_to_io_t_half": s1["t_half"],
                    "no_to_io_t_below1": s1["t_below1"],
                    "io_to_no_kl_init": s2["kl_init"],
                    "io_to_no_kl_final": s2["kl_final"],
                    "io_to_no_auc": s2["auc"],
                    "io_to_no_t_half": s2["t_half"],
                    "io_to_no_t_below1": s2["t_below1"],
                    "no_to_io_track_10": ";".join(f"{x:.6g}" for x in res.track_no_to_io[:10]),
                    "io_to_no_track_10": ";".join(f"{x:.6g}" for x in res.track_io_to_no[:10]),
                }
                all_rows.append(row)

            cross_rows.extend(cross_fit_kls("NO", preprocess, dm32_mode))
            cross_rows.extend(cross_fit_kls("IO", preprocess, dm32_mode))

    with open(CSV_OUT, "w", newline="", encoding="utf-8") as f:
        fieldnames = list(all_rows[0].keys()) if all_rows else []
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(all_rows)

    cross_out = CSV_OUT.replace(".csv", "_crossfit.csv")
    with open(cross_out, "w", newline="", encoding="utf-8") as f:
        fieldnames = list(cross_rows[0].keys()) if cross_rows else []
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(cross_rows)

    print("\n=== CSV written ===")
    print("Main:", CSV_OUT)
    print("Cross-fit:", cross_out)
    print("===================\n")

if __name__ == "__main__":
    main()
