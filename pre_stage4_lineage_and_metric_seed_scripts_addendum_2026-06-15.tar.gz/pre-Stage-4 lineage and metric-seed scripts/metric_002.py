#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jan 10 19:43:07 2026

@author: dakini
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
metric_002.py

Emergent metric diagnostics from PDG likelihood geometry.
Scale-aware funnel metric with curvature diagnostics.

Primary questions:
- Does funnel flattening actually occur?
- If it "looks flat", does it fail at second order?
- Is anisotropy scale-dependent?
- Is curvature stable under small likelihood perturbations?

NO spacetime assumptions.
NO intrinsic curvature assumed.
"""

import numpy as np
import pandas as pd
import os
import matplotlib.pyplot as plt

# ============================================================
# 0) Import / mirror atlas machinery (from v007)
# ============================================================

# ---- configuration ----
FITS = ["NUFIT", "BARI", "VALENCIA"]
ORDERINGS = ["NO", "IO"]

PREPROCESS = "zscore"
DM32_MODE = "signed"
N_SAMPLES = 5000
RNG_SEED = 123
rng = np.random.default_rng(RNG_SEED)

# radial binning
N_RADIAL_BINS = 20
MIN_PER_BIN = 150

# transport perturbation
EPS_PERT = 0.05  # small reweighting

# optional geometric sanity check
ENABLE_MENGER = False

PLOT_DIR = "metric_002_plots"
os.makedirs(PLOT_DIR, exist_ok=True)

# ============================================================
# 1) --- Paste-in minimal atlas machinery hooks ---
# (assumes metric_002.py is in same directory as v007 file)
# ============================================================

from GIKL_neutrino_007_fixed import (
    build_cloud_raw,
    apply_dm32_mode,
    build_global_atlas,
    apply_atlas_preprocess,
)

# ============================================================
# 2) Helpers
# ============================================================

def second_difference(y):
    """Discrete second difference."""
    y = np.asarray(y, float)
    return y[2:] - 2*y[1:-1] + y[:-2]

def fisher_anisotropy(X):
    """
    Fisher imbalance proxy:
    eigenvalue ratio of inverse covariance.
    """
    C = np.cov(X, rowvar=False)
    vals = np.linalg.eigvalsh(C)
    vals = np.clip(vals, 1e-12, None)
    return np.max(vals) / np.min(vals)

def wasserstein_1d(a, b):
    """
    Cheap 1D Wasserstein distance between sorted samples.
    """
    a = np.sort(a)
    b = np.sort(b)
    n = min(len(a), len(b))
    return np.mean(np.abs(a[:n] - b[:n]))

def menger_curvature(points):
    """
    Average Menger curvature over random triples.
    Purely extrinsic, sanity check only.
    """
    if len(points) < 3:
        return np.nan
    idx = rng.choice(len(points), size=(200,3), replace=True)
    kappa = []
    for i,j,k in idx:
        x,y,z = points[i], points[j], points[k]
        a = np.linalg.norm(y-z)
        b = np.linalg.norm(x-z)
        c = np.linalg.norm(x-y)
        s = 0.5*(a+b+c)
        area = max(s*(s-a)*(s-b)*(s-c), 0.0)
        if area <= 0:
            continue
        area = np.sqrt(area)
        kappa.append(4*area/(a*b*c))
    return np.mean(kappa) if kappa else np.nan

# ============================================================
# 3) Main analysis per FIT
# ============================================================

def analyze_fit(fit, atlas):
    print(f"\n--- FIT: {fit} ---")

    # ---- sample NO / IO ----
    X_no = build_cloud_raw(fit, "NO", N_SAMPLES, seed=1)
    X_io = build_cloud_raw(fit, "IO", N_SAMPLES, seed=2)

    X_no = apply_atlas_preprocess(apply_dm32_mode(X_no, DM32_MODE), atlas)
    X_io = apply_atlas_preprocess(apply_dm32_mode(X_io, DM32_MODE), atlas)

    # mixture
    X = np.vstack([X_no, X_io])
    labels = np.concatenate([
        np.zeros(len(X_no), dtype=int),
        np.ones(len(X_io), dtype=int)
    ])

    # ---- radial coordinate ----
    center = np.median(X, axis=0)
    r = np.linalg.norm(X - center, axis=1)

    # bin by r
    edges = np.quantile(r, np.linspace(0, 1, N_RADIAL_BINS+1))
    bin_id = np.digitize(r, edges) - 1

    shell_stats = []

    for k in range(N_RADIAL_BINS):
        m = (bin_id == k)
        if np.sum(m) < MIN_PER_BIN:
            continue

        Xk = X[m]
        rk = r[m]

        # transverse covariance (full, no privileged direction)
        C = np.cov(Xk, rowvar=False)
        vals = np.linalg.eigvalsh(C)

        # diagnostics
        var_trace = np.trace(C)
        fisher_k = fisher_anisotropy(Xk)

        shell = {
            "fit": fit,
            "shell": k,
            "r_mean": np.mean(rk),
            "var_trace": var_trace,
            "fisher_k": fisher_k,
        }

        if ENABLE_MENGER:
            shell["menger"] = menger_curvature(Xk)

        shell_stats.append(shell)

    df = pd.DataFrame(shell_stats).sort_values("r_mean").reset_index(drop=True)

    # ========================================================
    # 4) Curvature diagnostics (second differences)
    # ========================================================

    df["var_curv"] = np.nan
    df["fisher_curv"] = np.nan

    if len(df) >= 3:
       var_dd = second_difference(df["var_trace"].values)
       fish_dd = second_difference(np.log(df["fisher_k"].values))

    # positional assignment: rows 1 ... n-2
       df.iloc[1:-1, df.columns.get_loc("var_curv")] = var_dd
       df.iloc[1:-1, df.columns.get_loc("fisher_curv")] = fish_dd


    # ========================================================
    # 5) Transport instability (NO/IO perturbation)
    # ========================================================

    r_no = r[labels == 0]
    r_io = r[labels == 1]

    # baseline mixture
    W0 = wasserstein_1d(r_no, r_io)

    # perturbed mixture
    n_pert = int(EPS_PERT * len(r_no))
    idx_drop = rng.choice(len(r_no), size=n_pert, replace=False)
    r_no_p = np.delete(r_no, idx_drop)
    Wp = wasserstein_1d(r_no_p, r_io)

    transport_jump = Wp - W0

    # ========================================================
    # 6) Plots
    # ========================================================

    plt.figure()
    plt.plot(df["r_mean"], df["var_trace"], "o-")
    plt.xlabel("r (scale)")
    plt.ylabel("trace(C⊥)")
    plt.title(f"{fit}: transverse variance profile")
    plt.tight_layout()
    plt.savefig(f"{PLOT_DIR}/{fit}_variance_profile.png")
    plt.close()

    plt.figure()
    plt.plot(df["r_mean"], df["fisher_k"], "o-")
    plt.xlabel("r (scale)")
    plt.ylabel("Fisher anisotropy κ")
    plt.title(f"{fit}: Fisher imbalance")
    plt.tight_layout()
    plt.savefig(f"{PLOT_DIR}/{fit}_fisher_profile.png")
    plt.close()

    # ========================================================
    # 7) Report
    # ========================================================

    print("Mean |var_curv|:",
          np.nanmean(np.abs(df["var_curv"].values)))
    print("Mean |fisher_curv|:",
          np.nanmean(np.abs(df["fisher_curv"].values)))
    print("Transport instability ΔW:", transport_jump)

    return df

# ============================================================
# 8) Run all FITs
# ============================================================

def main():
    atlas = build_global_atlas(PREPROCESS, DM32_MODE, atlas_quantiles=None)
    results = []

    for fit in FITS:
        df = analyze_fit(fit, atlas)
        results.append(df)

    all_df = pd.concat(results, ignore_index=True)
    all_df.to_csv("metric_002_shell_diagnostics.csv", index=False)

    print("\n=== metric_002 completed ===")
    print("Outputs:")
    print(" - metric_002_shell_diagnostics.csv")
    print(" - plots in", PLOT_DIR)

if __name__ == "__main__":
    main()
