#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jan 11 08:52:50 2026

@author: dakini
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
metric_006.py

Option B: Refine transport rule (midpoint / symmetrized) to test robustness
of VALENCIA's transport associativity defects in K>=2 subspaces.

We compare three coarse maps from shell k to k+2:

  1) DIRECT:
       R02_dir = polar(V0^T V2)

  2) MIDPOINT (Grassmann geodesic midpoint subspace):
       Build Vm = midpoint_subspace(V0, V2)
       R02_mid = polar(V0^T Vm) @ polar(Vm^T V2)

  3) SYMMETRIZED:
       R02_sym = polar( (R02_dir + R02_mid)/2 )

Defect is always measured against the fine-step composition:
    R_fine = R01 @ R12
    defect_* = ||R02_* - R_fine||_F

We run K in {2,3} by default (K=1 is provably trivial and will be ~0).

Outputs:
- metric_006_outputs/metric_006_triangle_defects.csv
- metric_006_outputs/metric_006_summary.csv
- plots:
    {FIT}_defects_K{K}.png  (three curves: direct/mid/sym)
    crossfit_defects_K{K}.png
"""

import numpy as np
import pandas as pd
import os
import matplotlib.pyplot as plt

# ============================================================
# 0) Configuration
# ============================================================

FITS = ["NUFIT", "BARI", "VALENCIA"]

PREPROCESS = "zscore"
DM32_MODE = "signed"

N_SAMPLES = 5000
N_RADIAL_BINS = 20
MIN_PER_BIN = 150

# We focus on K>=2; include K=1 only if you want (it will be identically ~0)
K_SWEEP = [2, 3]

RNG_SEED = 123
rng = np.random.default_rng(RNG_SEED)

OUTDIR = "metric_006_outputs"
os.makedirs(OUTDIR, exist_ok=True)

EPS = 1e-12

# ============================================================
# 1) Import atlas machinery (from v007)
# ============================================================

from GIKL_neutrino_007_fixed import (
    build_cloud_raw,
    apply_dm32_mode,
    build_global_atlas,
    apply_atlas_preprocess,
)

# ============================================================
# 2) Linear algebra helpers
# ============================================================

def fisher_eigenvectors(X):
    """
    Fisher proxy = Cov^{-1}. Eigenvectors are same as Cov eigenvectors.
    Return eigenvalues (descending) and eigenvectors (columns), from Cov.
    """
    C = np.cov(X, rowvar=False)
    vals, vecs = np.linalg.eigh(C)
    idx = np.argsort(vals)[::-1]
    return vals[idx], vecs[:, idx]

def polar_orthogonal(M):
    """
    Closest orthogonal matrix to M in Frobenius norm:
      M = U S V^T => R = U V^T
    """
    U, _, Vt = np.linalg.svd(M, full_matrices=False)
    return U @ Vt

def subspace_transport(Va, Vb):
    """
    Va, Vb are orthonormal bases (d x K).
    Transport in O(K) via polar factor of overlap Va^T Vb.
    """
    return polar_orthogonal(Va.T @ Vb)

def frob_norm(A):
    return float(np.linalg.norm(A, ord="fro"))

def orthonormalize(X):
    """
    Orthonormalize columns via QR. Returns Q with same number of columns (if full rank).
    """
    Q, _ = np.linalg.qr(X)
    return Q

# ============================================================
# 3) Grassmann geodesic midpoint subspace
# ============================================================

def grassmann_midpoint(Va, Vb):
    """
    Compute a geodesic midpoint subspace between Va and Vb on the Grassmann manifold.

    Va, Vb: d x K orthonormal.
    Steps:
      SVD: Va^T Vb = U diag(s) V^T, with s = cos(theta)
      Define A = Va U, B = Vb V
      Orthogonal complement directions Q from (B - A diag(s))
      Midpoint columns: A cos(theta/2) + Q sin(theta/2), columnwise
      Re-orthonormalize

    Handles small angles robustly.
    """
    K = Va.shape[1]
    M = Va.T @ Vb
    U, s, Vt = np.linalg.svd(M, full_matrices=False)

    s = np.clip(s, -1.0, 1.0)
    theta = np.arccos(s)  # principal angles

    A = Va @ U               # d x K
    V = Vt.T
    B = Vb @ V               # d x K

    # orthogonal component
    B_perp = B - A * s  # broadcast s over columns
    # If some angles ~0, corresponding column of B_perp is ~0; QR will still behave.
    Q = orthonormalize(B_perp)  # d x K (may be arbitrary for near-zero columns)

    c = np.cos(theta / 2.0)
    t = np.sin(theta / 2.0)

    # Build midpoint columns, replacing unstable Q-columns when t ~ 0
    Vm_cols = []
    for i in range(K):
        if t[i] < 1e-10:
            Vm_cols.append(A[:, i])
        else:
            Vm_cols.append(A[:, i] * c[i] + Q[:, i] * t[i])

    Vm = np.column_stack(Vm_cols)
    Vm = orthonormalize(Vm)
    return Vm

# ============================================================
# 4) Build shells (same as metric_002/003/004/005)
# ============================================================

def build_shells(fit, atlas):
    X_no = build_cloud_raw(fit, "NO", N_SAMPLES, seed=1)
    X_io = build_cloud_raw(fit, "IO", N_SAMPLES, seed=2)

    X_no = apply_atlas_preprocess(apply_dm32_mode(X_no, DM32_MODE), atlas)
    X_io = apply_atlas_preprocess(apply_dm32_mode(X_io, DM32_MODE), atlas)

    X = np.vstack([X_no, X_io])

    center = np.median(X, axis=0)
    r = np.linalg.norm(X - center, axis=1)

    edges = np.quantile(r, np.linspace(0, 1, N_RADIAL_BINS + 1))
    sid = np.digitize(r, edges) - 1

    shells = []
    for k in range(N_RADIAL_BINS):
        m = (sid == k)
        if np.sum(m) < MIN_PER_BIN:
            continue

        Xk = X[m]
        r_mean = float(np.mean(r[m]))

        vals, vecs = fisher_eigenvectors(Xk)
        d = vecs.shape[0]

        shells.append({
            "shell": k,
            "r_mean": r_mean,
            "vecs": vecs,
            "d": d,
            "n": int(np.sum(m)),
        })

    shells = sorted(shells, key=lambda s: s["r_mean"])
    return shells

# ============================================================
# 5) Triangle defects under refined rules
# ============================================================

def triangle_defects_refined(shells, K):
    """
    For each triple (i,i+1,i+2), compute:
      R_fine = R01 @ R12
      R02_dir  = polar(V0^T V2)
      R02_mid  = polar(V0^T Vm) @ polar(Vm^T V2)   where Vm is Grassmann midpoint of (V0,V2)
      R02_sym  = polar( (R02_dir + R02_mid)/2 )

      defects: ||R02_* - R_fine||_F
    """
    rows = []
    if len(shells) < 3:
        return pd.DataFrame(rows)

    K_eff = min(K, min(s["d"] for s in shells))

    for i in range(len(shells) - 2):
        s0, s1, s2 = shells[i], shells[i+1], shells[i+2]
        V0 = s0["vecs"][:, :K_eff]
        V1 = s1["vecs"][:, :K_eff]
        V2 = s2["vecs"][:, :K_eff]

        R01 = subspace_transport(V0, V1)
        R12 = subspace_transport(V1, V2)
        R_fine = R01 @ R12

        # direct coarse
        R02_dir = subspace_transport(V0, V2)

        # midpoint coarse (Grassmann midpoint between V0 and V2)
        Vm = grassmann_midpoint(V0, V2)
        R0m = subspace_transport(V0, Vm)
        Rm2 = subspace_transport(Vm, V2)
        R02_mid = R0m @ Rm2

        # symmetrized coarse
        R02_sym = polar_orthogonal(0.5 * (R02_dir + R02_mid))

        rows.append({
            "shell0": s0["shell"],
            "shell1": s1["shell"],
            "shell2": s2["shell"],
            "r_mid": 0.5 * (s0["r_mean"] + s2["r_mean"]),
            "K": int(K_eff),
            "defect_direct": frob_norm(R02_dir - R_fine),
            "defect_midpoint": frob_norm(R02_mid - R_fine),
            "defect_sym": frob_norm(R02_sym - R_fine),
        })

    return pd.DataFrame(rows)

def global_defects_refined(shells, K):
    """
    Global analogue: compare first->last direct vs step composition,
    and first->last midpoint-based coarse vs step composition.
    """
    if len(shells) < 2:
        return {"global_direct": np.nan, "global_midpoint": np.nan, "global_sym": np.nan, "K_eff": np.nan}

    K_eff = min(K, min(s["d"] for s in shells))
    V_first = shells[0]["vecs"][:, :K_eff]
    V_last  = shells[-1]["vecs"][:, :K_eff]

    # fine composition over all steps
    R_comp = np.eye(K_eff)
    for i in range(len(shells) - 1):
        V0 = shells[i]["vecs"][:, :K_eff]
        V1 = shells[i+1]["vecs"][:, :K_eff]
        R_comp = R_comp @ subspace_transport(V0, V1)

    # direct coarse
    R_dir = subspace_transport(V_first, V_last)

    # midpoint coarse between endpoints
    Vm = grassmann_midpoint(V_first, V_last)
    R_mid = subspace_transport(V_first, Vm) @ subspace_transport(Vm, V_last)

    # sym
    R_sym = polar_orthogonal(0.5 * (R_dir + R_mid))

    return {
        "global_direct": frob_norm(R_dir - R_comp),
        "global_midpoint": frob_norm(R_mid - R_comp),
        "global_sym": frob_norm(R_sym - R_comp),
        "K_eff": int(K_eff),
    }

# ============================================================
# 6) Main
# ============================================================

def main():
    atlas = build_global_atlas(PREPROCESS, DM32_MODE, atlas_quantiles=None)

    # Precompute shells once per FIT so K comparisons are apples-to-apples
    shells_by_fit = {}
    for fit in FITS:
        print(f"\n--- FIT: {fit} (building shells) ---")
        shells_by_fit[fit] = build_shells(fit, atlas)
        print(f"Shells kept: {len(shells_by_fit[fit])}")

    all_rows = []
    sum_rows = []

    for K in K_SWEEP:
        print(f"\n=== K = {K} ===")
        for fit in FITS:
            shells = shells_by_fit[fit]
            df = triangle_defects_refined(shells, K)
            df["fit"] = fit
            all_rows.append(df)

            gd = global_defects_refined(shells, K)
            sum_rows.append({
                "fit": fit,
                "K": int(gd["K_eff"]),
                "num_shells": len(shells),
                "global_defect_direct": gd["global_direct"],
                "global_defect_midpoint": gd["global_midpoint"],
                "global_defect_sym": gd["global_sym"],
            })

            # per-FIT plot (direct vs midpoint vs sym)
            if len(df) > 0:
                plt.figure()
                plt.plot(df["r_mid"], df["defect_direct"], "o-", label="direct")
                plt.plot(df["r_mid"], df["defect_midpoint"], "o-", label="midpoint")
                plt.plot(df["r_mid"], df["defect_sym"], "o-", label="sym")
                plt.xlabel("r (scale)")
                plt.ylabel("triangle defect ||R02 - R01R12||_F")
                plt.title(f"{fit}: refined transport defects (K={int(df['K'].iloc[0])})")
                plt.legend()
                plt.tight_layout()
                plt.savefig(f"{OUTDIR}/{fit}_defects_K{K}.png")
                plt.close()

        # cross-FIT overlay for each rule (same K)
        dfK = pd.concat([d for d in all_rows if len(d) > 0 and int(d["K"].iloc[0]) == K], ignore_index=True) \
              if any(len(d) > 0 and int(d["K"].iloc[0]) == K for d in all_rows) else pd.DataFrame()

        if len(dfK) > 0:
            plt.figure()
            for fit in FITS:
                dff = dfK[dfK["fit"] == fit]
                if len(dff) == 0:
                    continue
                plt.plot(dff["r_mid"], dff["defect_direct"], "o-", label=f"{fit} (direct)")
            plt.xlabel("r (scale)")
            plt.ylabel("triangle defect")
            plt.title(f"metric_006: direct defects vs scale (K={K})")
            plt.legend()
            plt.tight_layout()
            plt.savefig(f"{OUTDIR}/crossfit_direct_K{K}.png")
            plt.close()

            plt.figure()
            for fit in FITS:
                dff = dfK[dfK["fit"] == fit]
                if len(dff) == 0:
                    continue
                plt.plot(dff["r_mid"], dff["defect_midpoint"], "o-", label=f"{fit} (midpoint)")
            plt.xlabel("r (scale)")
            plt.ylabel("triangle defect")
            plt.title(f"metric_006: midpoint defects vs scale (K={K})")
            plt.legend()
            plt.tight_layout()
            plt.savefig(f"{OUTDIR}/crossfit_midpoint_K{K}.png")
            plt.close()

            plt.figure()
            for fit in FITS:
                dff = dfK[dfK["fit"] == fit]
                if len(dff) == 0:
                    continue
                plt.plot(dff["r_mid"], dff["defect_sym"], "o-", label=f"{fit} (sym)")
            plt.xlabel("r (scale)")
            plt.ylabel("triangle defect")
            plt.title(f"metric_006: sym defects vs scale (K={K})")
            plt.legend()
            plt.tight_layout()
            plt.savefig(f"{OUTDIR}/crossfit_sym_K{K}.png")
            plt.close()

    df_all = pd.concat(all_rows, ignore_index=True) if all_rows else pd.DataFrame()
    df_sum = pd.DataFrame(sum_rows)

    df_all.to_csv(f"{OUTDIR}/metric_006_triangle_defects.csv", index=False)
    df_sum.to_csv(f"{OUTDIR}/metric_006_summary.csv", index=False)

    print("\n=== metric_006 completed ===")
    print("Outputs written to:", OUTDIR)
    print(" - metric_006_triangle_defects.csv")
    print(" - metric_006_summary.csv")
    print(" - plots: {FIT}_defects_K{K}.png and crossfit_{rule}_K{K}.png")

if __name__ == "__main__":
    main()
