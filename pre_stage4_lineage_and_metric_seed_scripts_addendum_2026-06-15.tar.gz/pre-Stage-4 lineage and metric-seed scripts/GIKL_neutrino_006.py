#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GIKL_neutrino_006.py

v006 = "variograms + OT + Procrustes" (geometry layer on top of v005b frozen atlas)
---------------------------------------------------------------------------------
What stays from v005b:
- Same raw sampling from Table 14.7 (manual transcription).
- Same (preprocess_mode, dm32_mode) global atlas concept.
- Same histogram gridding on [0,1]^d with fixed atlas mins/maxs.

What v006 adds:
1) ATLAS_QUANTILES toggle (optional "safety valve"):
   - If set, we trim extreme *radial* atlas points BEFORE computing atlas mins/maxs.
   - Default is OFF (None).

2) Variograms:
   - We define a scalar field z(x) on the atlas using per-point histogram log-probability
     under its own ordering distribution (NO or IO). Then compare variograms NO vs IO.

3) OT + Procrustes:
   - On subsamples of NO and IO point clouds (in atlas coordinates), compute an entropic
     Sinkhorn OT plan (uniform weights), build barycentric mapping, then Procrustes-align.
   - Output residual summaries and diagnostic plots.

Outputs (written to current working directory):
- neutrino_geom_v006_summary.csv
- neutrino_geom_v006_variograms.csv
- plots/variogram_{fit}_{preprocess}_{dm32}_{qtag}.png
- plots/residual_hist_{fit}_{preprocess}_{dm32}_{qtag}.png
- plots/match_scatter_{fit}_{preprocess}_{dm32}_{qtag}.png

Notes:
- OT is done on a subsample size M_OT (default 1500) to keep memory bounded.
- If Sinkhorn becomes unstable for a configuration, the code falls back to NN matching.
"""

import numpy as np
import csv
import os
from dataclasses import dataclass
from typing import Dict, Tuple, List, Optional

# ============================
# 0) Configuration
# ============================

FITS = ["NUFIT", "BARI", "VALENCIA"]
ORDERINGS = ["NO", "IO"]

# v006 defaults chosen from your v005b results
PREPROCESS_MODES = ["zscore"]  # keep baseline clean; add "dimensionless" later if needed
DM32_MODES = ["signed", "abs", "drop"]

N_SAMPLES = 5000
BINS = 18

# Quantile trim safety valve (OFF by default)
ATLAS_QUANTILES: Optional[Tuple[float, float]] = None
# Example: ATLAS_QUANTILES = (0.005, 0.995)

# Variogram settings
N_LAGS = 25
MAX_LAG_FRAC = 0.5
VARIO_N_PAIRS = 200_000

# OT settings
M_OT = 1500
OT_REG = 1e-2
OT_ITERS = 300
OT_EPS = 1e-12

RNG_SEED = 123
rng = np.random.default_rng(RNG_SEED)

OUT_SUMMARY = "neutrino_geom_v006_summary.csv"
OUT_VARIO = "neutrino_geom_v006_variograms.csv"
PLOT_DIR = "plots"

# scaling used in v005b
DM21_SCALE = 75.0
DM32_SCALE = 2500.0

# ============================
# 1) Manual transcription of Table 14.7 (unchanged from v005b)
# ============================

TABLE_14_7: Dict[str, Dict[str, Dict[str, Tuple[float, float, float]]]] = {
    "NUFIT": {
        "NO": {
            "sin2_t12_10m1": (3.03, 0.12, 0.11),
            "sin2_t23_10m1": (5.72, 0.18, 0.23),
            "sin2_t13_10m2": (2.203, 0.056, 0.059),
            "dcp_deg":      (197.0, 42.0, 25.0),
            "dm2_21":       (74.1, 2.1, 2.0),
            "dm2_32":       (2437.0, 28.0, 27.0),
        },
        "IO": {
            "sin2_t12_10m1": (3.03, 0.12, 0.11),
            "sin2_t23_10m1": (5.78, 0.16, 0.21),
            "sin2_t13_10m2": (2.219, 0.060, 0.057),
            "dcp_deg":      (286.0, 27.0, 32.0),
            "dm2_21":       (74.1, 2.1, 2.0),
            "dm2_32":       (-2498.0, 32.0, 25.0),
        },
    },
    "BARI": {
        "NO": {
            "sin2_t12_10m1": (3.03, 0.13, 0.13),
            "sin2_t23_10m1": (4.55, 0.15, 0.15),
            "sin2_t13_10m2": (2.23, 0.06, 0.06),
            "dcp_deg":      (223.0, 32.0, 23.0),
            "dm2_21":       (73.6, 1.6, 1.5),
            "dm2_32":       (2448.0, 23.0, 31.0),
        },
        "IO": {
            "sin2_t12_10m1": (3.03, 0.13, 0.13),
            "sin2_t23_10m1": (5.69, 0.13, 0.21),
            "sin2_t13_10m2": (2.23, 0.06, 0.06),
            "dcp_deg":      (274.0, 25.0, 27.0),
            "dm2_21":       (73.6, 1.6, 1.5),
            "dm2_32":       (-2492.0, 25.0, 30.0),
        },
    },
    "VALENCIA": {
        "NO": {
            "sin2_t12_10m1": (3.18, 0.16, 0.16),
            "sin2_t23_10m1": (5.74, 0.14, 0.14),
            "sin2_t13_10m2": (2.200, 0.069, 0.062),
            "dcp_deg":      (194.0, 24.0, 22.0),
            "dm2_21":       (75.0, 2.2, 2.0),
            "dm2_32":       (2470.0, 24.0, 30.0),
        },
        "IO": {
            "sin2_t12_10m1": (3.18, 0.16, 0.16),
            "sin2_t23_10m1": (5.78, 0.10, 0.17),
            "sin2_t13_10m2": (2.225, 0.064, 0.070),
            "dcp_deg":      (284.0, 26.0, 28.0),
            "dm2_21":       (75.0, 2.2, 2.0),
            "dm2_32":       (-2520.0, 30.0, 20.0),
        },
    },
}

SCALE = {
    "sin2_t12_10m1": 1e-1,
    "sin2_t23_10m1": 1e-1,
    "sin2_t13_10m2": 1e-2,
    "dcp_deg":       1.0,
    "dm2_21":        1.0,
    "dm2_32":        1.0,
}

# ============================
# 2) Sampling
# ============================

def sym_sigma(up: float, down: float) -> float:
    return 0.5 * (abs(up) + abs(down))

def sample_normal(rng: np.random.Generator, mu: float, up: float, down: float, n: int) -> np.ndarray:
    sig = max(sym_sigma(up, down), 1e-12)
    return rng.normal(mu, sig, size=n)

def sample_angle_deg(rng: np.random.Generator, mu_deg: float, up: float, down: float, n: int) -> np.ndarray:
    sig = max(sym_sigma(up, down), 1e-12)
    return (rng.normal(mu_deg, sig, size=n) % 360.0)

def build_cloud_raw(fit: str, ordering: str, n: int, seed: int) -> np.ndarray:
    r = np.random.default_rng(seed)
    row = TABLE_14_7[fit][ordering]

    s12 = sample_normal(r, *row["sin2_t12_10m1"], n) * SCALE["sin2_t12_10m1"]
    s23 = sample_normal(r, *row["sin2_t23_10m1"], n) * SCALE["sin2_t23_10m1"]
    s13 = sample_normal(r, *row["sin2_t13_10m2"], n) * SCALE["sin2_t13_10m2"]
    dm21 = sample_normal(r, *row["dm2_21"], n)
    dm32 = sample_normal(r, *row["dm2_32"], n)

    dcp = sample_angle_deg(r, *row["dcp_deg"], n)
    rad = np.deg2rad(dcp)
    c = np.cos(rad)
    s = np.sin(rad)

    return np.vstack([s12, s23, s13, c, s, dm21, dm32]).T

# ============================
# 3) Toggles + preprocess helpers
# ============================

def apply_dm32_mode(X: np.ndarray, mode: str) -> np.ndarray:
    X = np.asarray(X, dtype=float)
    if mode == "signed":
        return X
    if mode == "abs":
        Y = X.copy()
        Y[:, -1] = np.abs(Y[:, -1])
        return Y
    if mode == "drop":
        return X[:, :-1]
    raise ValueError(f"Unknown dm32 mode: {mode}")

def apply_dimensionless(X: np.ndarray) -> np.ndarray:
    X = np.asarray(X, dtype=float).copy()
    if X.shape[1] == 7:
        X[:, -2] = X[:, -2] / DM21_SCALE
        X[:, -1] = X[:, -1] / DM32_SCALE
    elif X.shape[1] == 6:
        X[:, -1] = X[:, -1] / DM21_SCALE
    return X

# ============================
# 4) Atlas + quantile trim
# ============================

def radial_quantile_mask(X: np.ndarray, q: Optional[Tuple[float, float]]) -> np.ndarray:
    if q is None:
        return np.ones(len(X), dtype=bool)
    ql, qh = q
    mu = np.median(X, axis=0)
    r = np.linalg.norm(X - mu, axis=1)
    lo, hi = np.quantile(r, [ql, qh])
    return (r >= lo) & (r <= hi)

@dataclass
class Atlas:
    preprocess: str
    dm32_mode: str
    mu: np.ndarray
    sd: np.ndarray
    mins: np.ndarray
    maxs: np.ndarray
    edges: List[np.ndarray]
    quantiles: Optional[Tuple[float, float]]

def build_global_atlas(preprocess: str, dm32_mode: str, atlas_quantiles: Optional[Tuple[float,float]]) -> Atlas:
    chunks = []
    seed0 = 12345 + (hash((preprocess, dm32_mode)) % 10000)
    k = 0
    for fit in FITS:
        for ordering in ORDERINGS:
            X = build_cloud_raw(fit, ordering, n=N_SAMPLES, seed=seed0 + 97 * k)
            X = apply_dm32_mode(X, dm32_mode)
            chunks.append(X)
            k += 1
    Xall = np.vstack(chunks)

    if preprocess == "zscore":
        mu = Xall.mean(axis=0)
        sd = Xall.std(axis=0)
        sd = np.where(sd > 0, sd, 1.0)
        Xall_p = (Xall - mu) / sd
    elif preprocess == "dimensionless":
        mu = np.zeros(Xall.shape[1], dtype=float)
        sd = np.ones(Xall.shape[1], dtype=float)
        Xall_p = apply_dimensionless(Xall)
    else:
        raise ValueError(f"Unknown preprocess mode: {preprocess}")

    # Quantile trimming applied here (atlas-only)
    mask = radial_quantile_mask(Xall_p, atlas_quantiles)
    Xref = Xall_p[mask] if np.any(mask) else Xall_p

    mins = np.nanmin(Xref, axis=0)
    maxs = np.nanmax(Xref, axis=0)

    # Ensure non-degenerate spans
    span = maxs - mins
    span = np.where(np.isfinite(span) & (span > 0), span, 1.0)
    maxs = mins + span

    edges = [np.linspace(0.0, 1.0, BINS + 1) for _ in range(Xall_p.shape[1])]
    return Atlas(preprocess, dm32_mode, mu, sd, mins, maxs, edges, atlas_quantiles)

def apply_atlas_preprocess(X: np.ndarray, atlas: Atlas) -> np.ndarray:
    X = np.asarray(X, dtype=float)
    if atlas.preprocess == "zscore":
        return (X - atlas.mu) / atlas.sd
    if atlas.preprocess == "dimensionless":
        return apply_dimensionless(X)
    raise ValueError("Invalid atlas preprocess")

def atlas_qtag(q: Optional[Tuple[float,float]]) -> str:
    if q is None:
        return "qNONE"
    return f"q{q[0]:.3g}_{q[1]:.3g}".replace(".", "p")

# ============================
# 5) Histogram helpers (reused)
# ============================

def hist_nd_atlas(X: np.ndarray, atlas: Atlas) -> np.ndarray:
    Y = (X - atlas.mins) / (atlas.maxs - atlas.mins + 1e-12)
    Y = np.clip(Y, 0.0, 1.0)
    H, _ = np.histogramdd(Y, bins=atlas.edges)
    return H / (H.sum() + 1e-15)

def points_to_bin_indices(X: np.ndarray, atlas: Atlas) -> np.ndarray:
    """
    Map points to histogram bin indices (per dimension).
    Returns integer array of shape (n, d) in [0, BINS-1].
    """
    Y = (X - atlas.mins) / (atlas.maxs - atlas.mins + 1e-12)
    Y = np.clip(Y, 0.0, 1.0 - 1e-15)  # keep inside last bin
    idx = np.floor(Y * BINS).astype(int)
    idx = np.clip(idx, 0, BINS - 1)
    return idx

def scalar_field_logprob(X: np.ndarray, atlas: Atlas, P: np.ndarray) -> np.ndarray:
    """
    z(x) = -log P(bin(x)) (a cheap "energy-like" scalar).
    """
    idx = points_to_bin_indices(X, atlas)
    # flatten multi-index
    flat = np.ravel_multi_index(idx.T, dims=P.shape)
    p = P.ravel()[flat]
    return -np.log(np.clip(p, 1e-15, None))

# ============================
# 6) Variograms
# ============================

def variogram_empirical(coords: np.ndarray, values: np.ndarray,
                        n_lags: int = N_LAGS, max_lag_frac: float = MAX_LAG_FRAC,
                        n_pairs: int = VARIO_N_PAIRS):
    """
    Empirical semivariogram via random pair sampling:
        gamma(h) = 0.5 E[(Z(x)-Z(y))^2 | ||x-y||≈h]
    """
    n = len(coords)
    if n < 2:
        return None

    i = rng.integers(0, n, size=n_pairs)
    j = rng.integers(0, n, size=n_pairs)
    m = i != j
    i, j = i[m], j[m]

    d = np.linalg.norm(coords[i] - coords[j], axis=1)
    dv = values[i] - values[j]
    gamma = 0.5 * (dv * dv)

    dmax = np.quantile(d, 0.999)
    dmax = max_lag_frac * dmax
    edges = np.linspace(0.0, dmax, n_lags + 1)

    idx = np.digitize(d, edges) - 1
    keep = (idx >= 0) & (idx < n_lags)
    idx = idx[keep]
    gamma = gamma[keep]

    lag_centers = 0.5 * (edges[:-1] + edges[1:])
    gamma_binned = np.full(n_lags, np.nan)
    counts = np.zeros(n_lags, dtype=int)

    for k in range(n_lags):
        sel = (idx == k)
        counts[k] = int(np.sum(sel))
        if counts[k] > 100:
            gamma_binned[k] = float(np.mean(gamma[sel]))

    return lag_centers, gamma_binned, counts

# ============================
# 7) OT (Sinkhorn) + Procrustes
# ============================

def sinkhorn_plan_uniform(C: np.ndarray, reg: float, n_iter: int = OT_ITERS, eps: float = OT_EPS) -> np.ndarray:
    """
    Sinkhorn-Knopp for uniform marginals with kernel K=exp(-C/reg).
    C: (m,m) cost matrix (squared Euclidean recommended).
    Returns transport plan P.
    """
    # Stabilize kernel range
    Cmin = np.min(C)
    K = np.exp(-(C - Cmin) / max(reg, 1e-12))
    K = np.clip(K, 1e-300, None)

    m = C.shape[0]
    a = np.full(m, 1.0 / m)
    b = np.full(m, 1.0 / m)

    u = np.ones(m)
    v = np.ones(m)

    for _ in range(n_iter):
        Ku = K @ v
        Ku = np.where(Ku > eps, Ku, eps)
        u = a / Ku
        Kv = K.T @ u
        Kv = np.where(Kv > eps, Kv, eps)
        v = b / Kv

    P = (u[:, None] * K) * v[None, :]
    # renormalize small drift
    P = np.clip(P, 0.0, None)
    Psum = P.sum()
    if Psum > 0:
        P /= Psum
    return P

def barycentric_map(P: np.ndarray, Y: np.ndarray) -> np.ndarray:
    """Map each source point i to sum_j P_ij Y_j / sum_j P_ij."""
    w = P.sum(axis=1, keepdims=True)
    w = np.where(w > 0, w, 1.0)
    return (P @ Y) / w

def procrustes_align(A: np.ndarray, B: np.ndarray):
    """
    Align B to A with similarity transform.
    Returns aligned B, residual norms, and transform pieces.
    """
    Ac = A - A.mean(axis=0, keepdims=True)
    Bc = B - B.mean(axis=0, keepdims=True)

    normA = np.linalg.norm(Ac)
    normB = np.linalg.norm(Bc)
    if normA < 1e-12 or normB < 1e-12:
        return B.copy(), np.full(len(B), np.nan), None

    Acn = Ac / normA
    Bcn = Bc / normB

    M = Bcn.T @ Acn
    U, _, Vt = np.linalg.svd(M)
    R = U @ Vt

    B_aligned = (Bcn @ R) * normA + A.mean(axis=0, keepdims=True)
    res = np.linalg.norm(A - B_aligned, axis=1)
    return B_aligned, res, {"R": R, "scale": normA / normB}

def nn_match(A: np.ndarray, B: np.ndarray) -> np.ndarray:
    """Nearest-neighbor matching: returns B matched to each A (same length as A)."""
    try:
        from sklearn.neighbors import NearestNeighbors
        nn = NearestNeighbors(n_neighbors=1).fit(B)
        _, ind = nn.kneighbors(A, return_distance=True)
        return B[ind[:, 0]]
    except Exception:
        # brute force fallback
        out = np.empty_like(A)
        for i in range(len(A)):
            d = np.sum((B - A[i])**2, axis=1)
            out[i] = B[np.argmin(d)]
        return out

# ============================
# 8) Plotting
# ============================

def ensure_plot_dir():
    os.makedirs(PLOT_DIR, exist_ok=True)

def plot_variogram(lags, g_no, g_io, fit, atlas, qtag):
    import matplotlib.pyplot as plt
    ensure_plot_dir()
    plt.figure()
    plt.plot(lags, g_no, marker="o", label="NO")
    plt.plot(lags, g_io, marker="o", label="IO")
    plt.xlabel("lag ||x-y||")
    plt.ylabel("semivariogram γ(h)")
    plt.title(f"Variograms | {fit} | {atlas.preprocess} | {atlas.dm32_mode} | {qtag}")
    plt.legend()
    fn = os.path.join(PLOT_DIR, f"variogram_{fit}_{atlas.preprocess}_{atlas.dm32_mode}_{qtag}.png")
    plt.tight_layout()
    plt.savefig(fn, dpi=160)
    plt.close()

def plot_residual_hist(res, fit, atlas, qtag):
    import matplotlib.pyplot as plt
    ensure_plot_dir()
    plt.figure()
    plt.hist(res[np.isfinite(res)], bins=50)
    plt.xlabel("||A - Procrustes(OT(A))||")
    plt.ylabel("count")
    plt.title(f"Residual histogram | {fit} | {atlas.preprocess} | {atlas.dm32_mode} | {qtag}")
    fn = os.path.join(PLOT_DIR, f"residual_hist_{fit}_{atlas.preprocess}_{atlas.dm32_mode}_{qtag}.png")
    plt.tight_layout()
    plt.savefig(fn, dpi=160)
    plt.close()

def plot_match_scatter(A, Bm, fit, atlas, qtag):
    import matplotlib.pyplot as plt
    ensure_plot_dir()
    # Use first 2 coordinates for a simple visual
    plt.figure()
    plt.scatter(A[:,0], A[:,1], s=8, alpha=0.6, label="NO (A)")
    plt.scatter(Bm[:,0], Bm[:,1], s=8, alpha=0.6, label="IO matched (B̂)")
    plt.xlabel("coord 0")
    plt.ylabel("coord 1")
    plt.title(f"Match scatter (2D) | {fit} | {atlas.preprocess} | {atlas.dm32_mode} | {qtag}")
    plt.legend()
    fn = os.path.join(PLOT_DIR, f"match_scatter_{fit}_{atlas.preprocess}_{atlas.dm32_mode}_{qtag}.png")
    plt.tight_layout()
    plt.savefig(fn, dpi=160)
    plt.close()

# ============================
# 9) Main experiment
# ============================

def run_one_fit(fit: str, atlas: Atlas) -> Tuple[Dict[str, float], List[Dict[str, float]]]:
    # Build NO/IO clouds in raw space
    X_no_raw = build_cloud_raw(fit, "NO", n=N_SAMPLES, seed=1)
    X_io_raw = build_cloud_raw(fit, "IO", n=N_SAMPLES, seed=2)

    # Apply dm32 mode + atlas preprocess → atlas space
    X_no = apply_dm32_mode(X_no_raw, atlas.dm32_mode)
    X_io = apply_dm32_mode(X_io_raw, atlas.dm32_mode)
    X_no = apply_atlas_preprocess(X_no, atlas)
    X_io = apply_atlas_preprocess(X_io, atlas)

    # Build histograms and scalar fields
    P_no = hist_nd_atlas(X_no, atlas)
    P_io = hist_nd_atlas(X_io, atlas)
    z_no = scalar_field_logprob(X_no, atlas, P_no)
    z_io = scalar_field_logprob(X_io, atlas, P_io)

    # Variograms
    v_no = variogram_empirical(X_no, z_no)
    v_io = variogram_empirical(X_io, z_io)

    vario_rows: List[Dict[str, float]] = []
    if v_no is not None and v_io is not None:
        lags, g_no, c_no = v_no
        _,    g_io, c_io = v_io
        qtag = atlas_qtag(atlas.quantiles)

        # plot
        plot_variogram(lags, g_no, g_io, fit, atlas, qtag)

        for k in range(len(lags)):
            vario_rows.append({
                "fit": fit,
                "preprocess": atlas.preprocess,
                "dm32_mode": atlas.dm32_mode,
                "atlas_quantiles": str(atlas.quantiles),
                "lag": float(lags[k]),
                "gamma_no": float(g_no[k]) if np.isfinite(g_no[k]) else np.nan,
                "gamma_io": float(g_io[k]) if np.isfinite(g_io[k]) else np.nan,
                "count_no": int(c_no[k]),
                "count_io": int(c_io[k]),
            })

    # OT + Procrustes (subsample)
    m = min(M_OT, len(X_no), len(X_io))
    idx_no = rng.choice(len(X_no), size=m, replace=False)
    idx_io = rng.choice(len(X_io), size=m, replace=False)
    A = X_no[idx_no]
    B = X_io[idx_io]

    # Compute squared-Euclidean cost
    # C_ij = ||A_i - B_j||^2
    # (m,m) is OK for m<=1500
    try:
        AA = np.sum(A*A, axis=1, keepdims=True)
        BB = np.sum(B*B, axis=1, keepdims=True).T
        C = AA + BB - 2.0 * (A @ B.T)
        C = np.clip(C, 0.0, None)

        P = sinkhorn_plan_uniform(C, reg=OT_REG, n_iter=OT_ITERS)
        B_map = barycentric_map(P, B)
        matching_method = "sinkhorn"
    except Exception:
        B_map = nn_match(A, B)
        matching_method = "nn_fallback"

    # plot pre-Procrustes matching scatter (2D)
    qtag = atlas_qtag(atlas.quantiles)
    plot_match_scatter(A, B_map, fit, atlas, qtag)

    # Procrustes
    B_aligned, res, _ = procrustes_align(A, B_map)
    plot_residual_hist(res, fit, atlas, qtag)

    summary = {
        "fit": fit,
        "preprocess": atlas.preprocess,
        "dm32_mode": atlas.dm32_mode,
        "atlas_quantiles": str(atlas.quantiles),
        "n": N_SAMPLES,
        "bins": BINS,
        "m_ot": m,
        "ot_reg": OT_REG,
        "ot_iters": OT_ITERS,
        "matching": matching_method,
        "res_mean": float(np.nanmean(res)),
        "res_median": float(np.nanmedian(res)),
        "res_p95": float(np.nanpercentile(res, 95)),
        "res_max": float(np.nanmax(res)),
    }

    return summary, vario_rows

def main():
    os.makedirs(PLOT_DIR, exist_ok=True)

    all_summaries: List[Dict[str, float]] = []
    all_vario_rows: List[Dict[str, float]] = []

    print("\n=== v006 RUN SETTINGS ===")
    print("FITS:", FITS)
    print("PREPROCESS_MODES:", PREPROCESS_MODES)
    print("DM32_MODES:", DM32_MODES)
    print(f"N={N_SAMPLES}, bins={BINS}, M_OT={M_OT}, OT_REG={OT_REG}, iters={OT_ITERS}")
    print(f"ATLAS_QUANTILES={ATLAS_QUANTILES}")
    print("=========================\n")

    for preprocess in PREPROCESS_MODES:
        for dm32_mode in DM32_MODES:
            atlas = build_global_atlas(preprocess, dm32_mode, atlas_quantiles=ATLAS_QUANTILES)

            print(f"\n######## ATLAS preprocess={preprocess} | dm32_mode={dm32_mode} | {atlas_qtag(atlas.quantiles)} ########")
            print("Dims:", len(atlas.mins))
            print("Atlas mins:", atlas.mins)
            print("Atlas maxs:", atlas.maxs)

            for fit in FITS:
                summary, vario_rows = run_one_fit(fit, atlas)
                print(summary)
                all_summaries.append(summary)
                all_vario_rows.extend(vario_rows)

    # Write summary CSV
    if all_summaries:
        with open(OUT_SUMMARY, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(all_summaries[0].keys()))
            w.writeheader()
            w.writerows(all_summaries)

    # Write variogram CSV
    if all_vario_rows:
        with open(OUT_VARIO, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(all_vario_rows[0].keys()))
            w.writeheader()
            w.writerows(all_vario_rows)

    print("\n=== Outputs written ===")
    print("Summary:", OUT_SUMMARY)
    print("Variograms:", OUT_VARIO)
    print("Plots dir:", PLOT_DIR)
    print("=======================\n")

if __name__ == "__main__":
    main()
