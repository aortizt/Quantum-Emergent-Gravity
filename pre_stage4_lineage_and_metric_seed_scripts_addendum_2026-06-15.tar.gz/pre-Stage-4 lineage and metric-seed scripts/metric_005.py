#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jan 10 20:42:32 2026

@author: dakini
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
metric_005.py

Option C: Reduce subspace dimension (K sweep) for transport-associativity defect.

We repeat metric_004's triangle defect diagnostic for K = 1,2,3 (or up to dimension),
to determine whether the defect lives in:
- K=1: dominant axis itself (strongest claim)
- K>=2: coupling between modes / subspace effects (weaker, but informative)

Outputs:
- metric_005_outputs/metric_005_triangle_defects_all.csv
- metric_005_outputs/metric_005_summary_all.csv
- plots:
    {FIT}_triangle_defect_K{K}.png
    crossfit_triangle_defect_K{K}.png
"""

import numpy as np
import pandas as pd
import os
import matplotlib.pyplot as plt

# ============================================================
# 0) Configuration
# ============================================================

FITS = ["NUFIT", "BARI", "VALENCIA"]

PREPROCESS = "zscore"
DM32_MODE = "signed"

N_SAMPLES = 5000
N_RADIAL_BINS = 20
MIN_PER_BIN = 150

# Sweep these K values (will be clipped to <= dimension)
K_SWEEP = [1, 2, 3]

RNG_SEED = 123
rng = np.random.default_rng(RNG_SEED)

OUTDIR = "metric_005_outputs"
os.makedirs(OUTDIR, exist_ok=True)

# ============================================================
# 1) Import atlas machinery (from v007)
# ============================================================

from GIKL_neutrino_007_fixed import (
    build_cloud_raw,
    apply_dm32_mode,
    build_global_atlas,
    apply_atlas_preprocess,
)

# ============================================================
# 2) Linear algebra helpers
# ============================================================

def fisher_eigenvectors(X):
    """
    Fisher proxy = Cov^{-1}. Eigenvectors are same as Cov eigenvectors.
    Return eigenvalues (descending) and eigenvectors (columns), from Cov.
    """
    C = np.cov(X, rowvar=False)
    vals, vecs = np.linalg.eigh(C)
    idx = np.argsort(vals)[::-1]
    return vals[idx], vecs[:, idx]

def polar_orthogonal(M):
    """
    Closest orthogonal matrix to M in Frobenius norm:
      M = U S V^T => R = U V^T
    """
    U, _, Vt = np.linalg.svd(M, full_matrices=False)
    return U @ Vt

def subspace_transport(Va, Vb):
    """
    Va, Vb are orthonormal bases (d x K).
    Transport in O(K) via polar factor of overlap Va^T Vb.
    """
    M = Va.T @ Vb
    return polar_orthogonal(M)

def frob_norm(A):
    return float(np.linalg.norm(A, ord="fro"))

# ============================================================
# 3) Build shells
# ============================================================

def build_shells(fit, atlas):
    # sample NO / IO
    X_no = build_cloud_raw(fit, "NO", N_SAMPLES, seed=1)
    X_io = build_cloud_raw(fit, "IO", N_SAMPLES, seed=2)

    X_no = apply_atlas_preprocess(apply_dm32_mode(X_no, DM32_MODE), atlas)
    X_io = apply_atlas_preprocess(apply_dm32_mode(X_io, DM32_MODE), atlas)

    X = np.vstack([X_no, X_io])

    # radial depth (statistical)
    center = np.median(X, axis=0)
    r = np.linalg.norm(X - center, axis=1)

    edges = np.quantile(r, np.linspace(0, 1, N_RADIAL_BINS + 1))
    sid = np.digitize(r, edges) - 1

    shells = []
    for k in range(N_RADIAL_BINS):
        m = (sid == k)
        if np.sum(m) < MIN_PER_BIN:
            continue

        Xk = X[m]
        r_mean = float(np.mean(r[m]))

        vals, vecs = fisher_eigenvectors(Xk)
        d = vecs.shape[0]

        shells.append({
            "shell": k,
            "r_mean": r_mean,
            "eigvals": vals,
            "vecs": vecs,
            "d": d,
            "n": int(np.sum(m)),
        })

    shells = sorted(shells, key=lambda s: s["r_mean"])
    return shells

# ============================================================
# 4) Triangle defect for a given K
# ============================================================

def triangle_defects(shells, K):
    """
    For triple shells i,i+1,i+2 (sorted order):
      R01 = transport(V0,V1)
      R12 = transport(V1,V2)
      R02 = transport(V0,V2)
      defect = ||R02 - R01@R12||_F
    """
    rows = []
    if len(shells) < 3:
        return pd.DataFrame(rows)

    K_eff = min(K, min(s["d"] for s in shells))  # safe clip

    for i in range(len(shells) - 2):
        s0, s1, s2 = shells[i], shells[i+1], shells[i+2]

        V0 = s0["vecs"][:, :K_eff]
        V1 = s1["vecs"][:, :K_eff]
        V2 = s2["vecs"][:, :K_eff]

        R01 = subspace_transport(V0, V1)
        R12 = subspace_transport(V1, V2)
        R02 = subspace_transport(V0, V2)

        defect = frob_norm(R02 - (R01 @ R12))

        rows.append({
            "shell0": s0["shell"],
            "shell1": s1["shell"],
            "shell2": s2["shell"],
            "r0": s0["r_mean"],
            "r1": s1["r_mean"],
            "r2": s2["r_mean"],
            "r_mid": 0.5 * (s0["r_mean"] + s2["r_mean"]),
            "K": int(K_eff),
            "defect_fro": defect,
        })

    return pd.DataFrame(rows)

def global_defect(shells, K):
    """
    Compare direct transport first->last vs composed step-by-step transport.
    """
    if len(shells) < 2:
        return np.nan

    K_eff = min(K, min(s["d"] for s in shells))
    V_first = shells[0]["vecs"][:, :K_eff]
    V_last  = shells[-1]["vecs"][:, :K_eff]

    R_direct = subspace_transport(V_first, V_last)

    R_comp = np.eye(K_eff)
    for i in range(len(shells) - 1):
        V0 = shells[i]["vecs"][:, :K_eff]
        V1 = shells[i+1]["vecs"][:, :K_eff]
        R_comp = R_comp @ subspace_transport(V0, V1)

    return frob_norm(R_direct - R_comp)

# ============================================================
# 5) Main
# ============================================================

def main():
    atlas = build_global_atlas(PREPROCESS, DM32_MODE, atlas_quantiles=None)

    all_defects = []
    all_summary = []

    # Precompute shells once per FIT (important: identical shells across K)
    shells_by_fit = {}
    for fit in FITS:
        print(f"\n--- FIT: {fit} (building shells) ---")
        shells_by_fit[fit] = build_shells(fit, atlas)
        print(f"Shells kept: {len(shells_by_fit[fit])}")

    for K in K_SWEEP:
        print(f"\n=== K = {K} ===")

        # Per-FIT computations + plots
        for fit in FITS:
            shells = shells_by_fit[fit]

            df = triangle_defects(shells, K)
            df["fit"] = fit
            all_defects.append(df)

            g = global_defect(shells, K)
            all_summary.append({
                "fit": fit,
                "K": int(min(K, min(s["d"] for s in shells) if shells else K)),
                "num_shells": len(shells),
                "global_defect_fro": g
            })

            # Plot per FIT
            if len(df) > 0:
                plt.figure()
                plt.plot(df["r_mid"], df["defect_fro"], "o-")
                plt.xlabel("r (scale), midpoint of (k,k+2)")
                plt.ylabel("triangle defect ||R02 - R01R12||_F")
                plt.title(f"{fit}: transport defect (K={int(df['K'].iloc[0])})")
                plt.tight_layout()
                plt.savefig(f"{OUTDIR}/{fit}_triangle_defect_K{K}.png")
                plt.close()

        # Cross-FIT overlay for this K
        dfK = pd.concat([d for d in all_defects if (len(d) > 0 and int(d["K"].iloc[0]) == K)], ignore_index=True) \
              if any(len(d) > 0 and int(d["K"].iloc[0]) == K for d in all_defects) else pd.DataFrame()

        if len(dfK) > 0:
            plt.figure()
            for fit in FITS:
                dff = dfK[dfK["fit"] == fit]
                if len(dff) == 0:
                    continue
                plt.plot(dff["r_mid"], dff["defect_fro"], "o-", label=fit)
            plt.xlabel("r (scale)")
            plt.ylabel("triangle defect (Frobenius)")
            plt.title(f"metric_005: transport defect vs scale (K={K})")
            plt.legend()
            plt.tight_layout()
            plt.savefig(f"{OUTDIR}/crossfit_triangle_defect_K{K}.png")
            plt.close()

    # Save CSVs
    df_all = pd.concat(all_defects, ignore_index=True) if all_defects else pd.DataFrame()
    df_sum = pd.DataFrame(all_summary)

    df_all.to_csv(f"{OUTDIR}/metric_005_triangle_defects_all.csv", index=False)
    df_sum.to_csv(f"{OUTDIR}/metric_005_summary_all.csv", index=False)

    print("\n=== metric_005 completed ===")
    print("Outputs written to:", OUTDIR)
    print(" - metric_005_triangle_defects_all.csv")
    print(" - metric_005_summary_all.csv")
    print(" - per-FIT plots + cross-FIT overlays for each K")

if __name__ == "__main__":
    main()
