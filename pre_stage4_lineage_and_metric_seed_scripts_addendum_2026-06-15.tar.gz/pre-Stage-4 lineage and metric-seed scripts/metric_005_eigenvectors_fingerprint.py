#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
metric_005.py

Option C: Reduce subspace dimension (K sweep) for transport-associativity defect.

PATCH (Stage 0 for metric_007):
- Export per-shell eigensystems to NPZ (same contract as metric_003 patch).

Original file: :contentReference[oaicite:8]{index=8}
"""

import numpy as np
import hashlib
import pandas as pd
import os
import json
import matplotlib.pyplot as plt

# ============================================================
# 0) Configuration
# ============================================================

FITS = ["NUFIT", "BARI", "VALENCIA"]

PREPROCESS = "zscore"
DM32_MODE = "signed"

N_SAMPLES = 5000
N_RADIAL_BINS = 20
MIN_PER_BIN = 150

K_SWEEP = [1, 2, 3]

RNG_SEED = 123
rng = np.random.default_rng(RNG_SEED)

OUTDIR = "metric_005_outputs"
os.makedirs(OUTDIR, exist_ok=True)

# ----------------------------
# Stage 0 export (NEW)
# ----------------------------
EXPORT_EIGENSYSTEMS = True
EXPORT_DIR = "metric_007_inputs"
EXPORT_TAG = "metric_005"
os.makedirs(EXPORT_DIR, exist_ok=True)

# ============================================================
# 1) Import atlas machinery (from v007)
# ============================================================

from GIKL_neutrino_007_fixed import (
    build_cloud_raw,
    apply_dm32_mode,
    build_global_atlas,
    apply_atlas_preprocess,
)

# ============================================================
# 2) Linear algebra helpers
# ============================================================


def _matrix_fingerprint(A: np.ndarray) -> dict:
    """Stable-ish fingerprint for sanity checks (float tolerant summary + byte hash)."""
    A = np.asarray(A)
    Af = np.ascontiguousarray(A.astype(np.float64, copy=False))
    h = hashlib.sha256(Af.tobytes()).hexdigest()[:16]
    return dict(
        sha16=h,
        shape=tuple(A.shape),
        fro=float(np.linalg.norm(Af, ord='fro')),
        maxabs=float(np.max(np.abs(Af))),
        mean=float(np.mean(Af)),
        std=float(np.std(Af)),
        sym_err=float(np.linalg.norm(Af - Af.T, ord='fro')) if Af.ndim == 2 else float('nan'),
    )

def fisher_eigenvectors(X):
    C = np.cov(X, rowvar=False)
    vals, vecs = np.linalg.eigh(C)
    idx = np.argsort(vals)[::-1]
    return vals[idx], vecs[:, idx], C

def polar_orthogonal(M):
    U, _, Vt = np.linalg.svd(M, full_matrices=False)
    return U @ Vt

def subspace_transport(Va, Vb):
    M = Va.T @ Vb
    return polar_orthogonal(M)

def frob_norm(A):
    return float(np.linalg.norm(A, ord="fro"))

def export_shell_eigs(fit, shells):
    if not shells:
        return
    D = shells[0]["vecs"].shape[0]
    S = len(shells)

    shell_ids = np.array([s["shell"] for s in shells], dtype=int)
    shell_centers = np.array([s["r_mean"] for s in shells], dtype=float)
    counts = np.array([s["n"] for s in shells], dtype=int)

    eigvals = np.zeros((S, D), dtype=float)
    eigvecs = np.zeros((S, D, D), dtype=float)
    fps = []
    for i, s in enumerate(shells):
        eigvals[i, :] = np.asarray(s["eigvals"], dtype=float).ravel()
        eigvecs[i, :, :] = np.asarray(s["vecs"], dtype=float)
        fps.append(s.get("fingerprint", {}))

    meta = {
        "tag": EXPORT_TAG,
        "fit": fit,
        "preprocess": PREPROCESS,
        "dm32_mode": DM32_MODE,
        "N_SAMPLES_per_ordering": int(N_SAMPLES),
        "N_RADIAL_BINS": int(N_RADIAL_BINS),
        "MIN_PER_BIN": int(MIN_PER_BIN),
        "note": "Per-shell covariance/Fisher eigensystems. eigvecs are columns, sorted by descending eigvals.",
    }

    outpath = os.path.join(
        EXPORT_DIR,
        f"eigshells__{EXPORT_TAG}__{fit}__{PREPROCESS}__{DM32_MODE}.npz"
    )
    np.savez_compressed(
        outpath,
        metric_id=EXPORT_TAG,
        fit_name=fit,
        shell_ids=shell_ids,
        shell_centers=shell_centers,
        counts=counts,
        eigvals=eigvals,
        eigvecs=eigvecs,
        fingerprints=np.array(fps, dtype=object),
        meta_json=json.dumps(meta),
    )
    print("[export] wrote:", outpath)

# ============================================================
# 3) Build shells
# ============================================================

def build_shells(fit, atlas):
    X_no = build_cloud_raw(fit, "NO", N_SAMPLES, seed=1)
    X_io = build_cloud_raw(fit, "IO", N_SAMPLES, seed=2)

    X_no = apply_atlas_preprocess(apply_dm32_mode(X_no, DM32_MODE), atlas)
    X_io = apply_atlas_preprocess(apply_dm32_mode(X_io, DM32_MODE), atlas)

    X = np.vstack([X_no, X_io])

    center = np.median(X, axis=0)
    r = np.linalg.norm(X - center, axis=1)

    edges = np.quantile(r, np.linspace(0, 1, N_RADIAL_BINS + 1))
    sid = np.digitize(r, edges) - 1

    shells = []
    for k in range(N_RADIAL_BINS):
        m = (sid == k)
        n = int(np.sum(m))
        if n < MIN_PER_BIN:
            continue

        Xk = X[m]
        r_mean = float(np.mean(r[m]))

        vals, vecs, C = fisher_eigenvectors(Xk)
        fp = _matrix_fingerprint(C)
        fp["k"] = int(k)
        d = vecs.shape[0]

        shells.append({
            "shell": int(k),
            "r_mean": float(r_mean),
            "eigvals": vals,
            "vecs": vecs,
            "d": int(d),
            "n": n,
            "fingerprint": fp,
        })

    shells = sorted(shells, key=lambda s: s["r_mean"])
    return shells

# ============================================================
# 4) Triangle defect for a given K
# ============================================================

def triangle_defects(shells, K):
    rows = []
    if len(shells) < 3:
        return pd.DataFrame(rows)

    K_eff = min(K, min(s["d"] for s in shells))

    for i in range(len(shells) - 2):
        s0, s1, s2 = shells[i], shells[i+1], shells[i+2]

        V0 = s0["vecs"][:, :K_eff]
        V1 = s1["vecs"][:, :K_eff]
        V2 = s2["vecs"][:, :K_eff]

        R01 = subspace_transport(V0, V1)
        R12 = subspace_transport(V1, V2)
        R02 = subspace_transport(V0, V2)

        defect = frob_norm(R02 - (R01 @ R12))

        rows.append({
            "shell0": s0["shell"],
            "shell1": s1["shell"],
            "shell2": s2["shell"],
            "r0": s0["r_mean"],
            "r1": s1["r_mean"],
            "r2": s2["r_mean"],
            "r_mid": 0.5 * (s0["r_mean"] + s2["r_mean"]),
            "K": int(K_eff),
            "defect_fro": defect,
        })

    return pd.DataFrame(rows)

def global_defect(shells, K):
    if len(shells) < 2:
        return np.nan

    K_eff = min(K, min(s["d"] for s in shells))
    V_first = shells[0]["vecs"][:, :K_eff]
    V_last  = shells[-1]["vecs"][:, :K_eff]

    R_direct = subspace_transport(V_first, V_last)

    R_comp = np.eye(K_eff)
    for i in range(len(shells) - 1):
        V0 = shells[i]["vecs"][:, :K_eff]
        V1 = shells[i+1]["vecs"][:, :K_eff]
        R_comp = R_comp @ subspace_transport(V0, V1)

    return frob_norm(R_direct - R_comp)

# ============================================================
# 5) Main
# ============================================================

def main():
    atlas = build_global_atlas(PREPROCESS, DM32_MODE, atlas_quantiles=None)

    all_defects = []
    all_summary = []

    shells_by_fit = {}
    for fit in FITS:
        print(f"\n--- FIT: {fit} (building shells) ---")
        shells_by_fit[fit] = build_shells(fit, atlas)
        print(f"Shells kept: {len(shells_by_fit[fit])}")

        if EXPORT_EIGENSYSTEMS:
            export_shell_eigs(fit, shells_by_fit[fit])

    for K in K_SWEEP:
        print(f"\n=== K = {K} ===")

        for fit in FITS:
            shells = shells_by_fit[fit]

            df = triangle_defects(shells, K)
            df["fit"] = fit
            all_defects.append(df)

            g = global_defect(shells, K)
            all_summary.append({
                "fit": fit,
                "K": int(min(K, min(s["d"] for s in shells) if shells else K)),
                "num_shells": len(shells),
                "global_defect_fro": g
            })

            if len(df) > 0:
                plt.figure()
                plt.plot(df["r_mid"], df["defect_fro"], "o-")
                plt.xlabel("r (scale), midpoint of (k,k+2)")
                plt.ylabel("triangle defect ||R02 - R01R12||_F")
                plt.title(f"{fit}: transport defect (K={int(df['K'].iloc[0])})")
                plt.tight_layout()
                plt.savefig(f"{OUTDIR}/{fit}_triangle_defect_K{K}.png")
                plt.close()

        dfK = pd.concat(
            [d for d in all_defects if (len(d) > 0 and int(d["K"].iloc[0]) == K)],
            ignore_index=True
        ) if any(len(d) > 0 and int(d["K"].iloc[0]) == K for d in all_defects) else pd.DataFrame()

        if len(dfK) > 0:
            plt.figure()
            for fit in FITS:
                dff = dfK[dfK["fit"] == fit]
                if len(dff) == 0:
                    continue
                plt.plot(dff["r_mid"], dff["defect_fro"], "o-", label=fit)
            plt.xlabel("r (scale)")
            plt.ylabel("triangle defect (Frobenius)")
            plt.title(f"metric_005: transport defect vs scale (K={K})")
            plt.legend()
            plt.tight_layout()
            plt.savefig(f"{OUTDIR}/crossfit_triangle_defect_K{K}.png")
            plt.close()

    df_all = pd.concat(all_defects, ignore_index=True) if all_defects else pd.DataFrame()
    df_sum = pd.DataFrame(all_summary)

    df_all.to_csv(f"{OUTDIR}/metric_005_triangle_defects_all.csv", index=False)
    df_sum.to_csv(f"{OUTDIR}/metric_005_summary_all.csv", index=False)

    print("\n=== metric_005 completed ===")
    print("Outputs written to:", OUTDIR)
    if EXPORT_EIGENSYSTEMS:
        print("Stage-0 eigensystems written to:", EXPORT_DIR)

if __name__ == "__main__":
    main()
