#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GIKL_neutrino_007.py

v007 = "reverse OT flow (atlas→samples) + variograms" (geometry layer on top of v005b frozen atlas)
---------------------------------------------------------------------------------
What stays from v005b:
- Same raw sampling from Table 14.7 (manual transcription).
- Same (preprocess_mode, dm32_mode) global atlas concept.
- Same histogram gridding on [0,1]^d with fixed atlas mins/maxs.

What v007 adds:
1) Reverse OT flow (atlas → samples):
   - For each hypothesis atlas (NO vs IO), compute entropic OT plan from atlas points to the
     mixed sample cloud X = X_NO ∪ X_IO, and convert the plan into a per-sample log-likelihood score.
   - The score difference Δℓ = ℓ_NO − ℓ_IO is used as a geometry-induced classifier.
2) Variograms (kept from v006 for context):
   - Same scalar field z(x) and empirical variograms NO vs IO.

Outputs (written to current working directory):
- neutrino_geom_v007_summary.csv
- neutrino_geom_v007_variograms.csv
- plots/variogram_{fit}_{preprocess}_{dm32}_{qtag}.png
- plots/residual_hist_{fit}_{preprocess}_{dm32}_{qtag}.png
- plots/match_scatter_{fit}_{preprocess}_{dm32}_{qtag}.png

Notes:
- OT is done on a subsample size M_OT (default 1500) to keep memory bounded.
- If Sinkhorn becomes unstable for a configuration, the code falls back to NN matching.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import csv
import os
from dataclasses import dataclass
from typing import Dict, Tuple, List, Optional

# ============================
# 0) Configuration
# ============================

FITS = ["NUFIT", "BARI", "VALENCIA"]
ORDERINGS = ["NO", "IO"]

# v006 defaults chosen from your v005b results
PREPROCESS_MODES = ["zscore"]  # keep baseline clean; add "dimensionless" later if needed
DM32_MODES = ["signed", "abs", "drop"]

N_SAMPLES = 5000
BINS = 18

# Quantile trim safety valve (OFF by default)
ATLAS_QUANTILES: Optional[Tuple[float, float]] = None
# Example: ATLAS_QUANTILES = None  # keep long tails; no quantile trimming

# Variogram settings
N_LAGS = 25
MAX_LAG_FRAC = 0.5
VARIO_N_PAIRS = 200_000

# OT settings
M_OT = 1500
N_KEEP_SAMPLES = 3000  # evaluation sample count per FIT (union NO+IO)
OT_REG = 1e-2
OT_ITERS = 300
OT_EPS = 1e-12

RNG_SEED = 123
rng = np.random.default_rng(RNG_SEED)

OUT_SUMMARY = "neutrino_geom_v007_summary.csv"
OUT_VARIO = "neutrino_geom_v007_variograms.csv"
OUT_SCORES = "neutrino_geom_v007_ot_scores.csv"
PLOT_DIR = "plots"

# scaling used in v005b
DM21_SCALE = 75.0
DM32_SCALE = 2500.0

# ============================
# 1) Manual transcription of Table 14.7 (unchanged from v005b)
# ============================

TABLE_14_7: Dict[str, Dict[str, Dict[str, Tuple[float, float, float]]]] = {
    "NUFIT": {
        "NO": {
            "sin2_t12_10m1": (3.03, 0.12, 0.11),
            "sin2_t23_10m1": (5.72, 0.18, 0.23),
            "sin2_t13_10m2": (2.203, 0.056, 0.059),
            "dcp_deg":      (197.0, 42.0, 25.0),
            "dm2_21":       (74.1, 2.1, 2.0),
            "dm2_32":       (2437.0, 28.0, 27.0),
        },
        "IO": {
            "sin2_t12_10m1": (3.03, 0.12, 0.11),
            "sin2_t23_10m1": (5.78, 0.16, 0.21),
            "sin2_t13_10m2": (2.219, 0.060, 0.057),
            "dcp_deg":      (286.0, 27.0, 32.0),
            "dm2_21":       (74.1, 2.1, 2.0),
            "dm2_32":       (-2498.0, 32.0, 25.0),
        },
    },
    "BARI": {
        "NO": {
            "sin2_t12_10m1": (3.03, 0.13, 0.13),
            "sin2_t23_10m1": (4.55, 0.15, 0.15),
            "sin2_t13_10m2": (2.23, 0.06, 0.06),
            "dcp_deg":      (223.0, 32.0, 23.0),
            "dm2_21":       (73.6, 1.6, 1.5),
            "dm2_32":       (2448.0, 23.0, 31.0),
        },
        "IO": {
            "sin2_t12_10m1": (3.03, 0.13, 0.13),
            "sin2_t23_10m1": (5.69, 0.13, 0.21),
            "sin2_t13_10m2": (2.23, 0.06, 0.06),
            "dcp_deg":      (274.0, 25.0, 27.0),
            "dm2_21":       (73.6, 1.6, 1.5),
            "dm2_32":       (-2492.0, 25.0, 30.0),
        },
    },
    "VALENCIA": {
        "NO": {
            "sin2_t12_10m1": (3.18, 0.16, 0.16),
            "sin2_t23_10m1": (5.74, 0.14, 0.14),
            "sin2_t13_10m2": (2.200, 0.069, 0.062),
            "dcp_deg":      (194.0, 24.0, 22.0),
            "dm2_21":       (75.0, 2.2, 2.0),
            "dm2_32":       (2470.0, 24.0, 30.0),
        },
        "IO": {
            "sin2_t12_10m1": (3.18, 0.16, 0.16),
            "sin2_t23_10m1": (5.78, 0.10, 0.17),
            "sin2_t13_10m2": (2.225, 0.064, 0.070),
            "dcp_deg":      (284.0, 26.0, 28.0),
            "dm2_21":       (75.0, 2.2, 2.0),
            "dm2_32":       (-2520.0, 30.0, 20.0),
        },
    },
}

SCALE = {
    "sin2_t12_10m1": 1e-1,
    "sin2_t23_10m1": 1e-1,
    "sin2_t13_10m2": 1e-2,
    "dcp_deg":       1.0,
    "dm2_21":        1.0,
    "dm2_32":        1.0,
}

# ============================
# 2) Sampling
# ============================

def sym_sigma(up: float, down: float) -> float:
    return 0.5 * (abs(up) + abs(down))

def sample_normal(rng: np.random.Generator, mu: float, up: float, down: float, n: int) -> np.ndarray:
    sig = max(sym_sigma(up, down), 1e-12)
    return rng.normal(mu, sig, size=n)

def sample_angle_deg(rng: np.random.Generator, mu_deg: float, up: float, down: float, n: int) -> np.ndarray:
    sig = max(sym_sigma(up, down), 1e-12)
    return (rng.normal(mu_deg, sig, size=n) % 360.0)

def build_cloud_raw(fit: str, ordering: str, n: int, seed: int) -> np.ndarray:
    r = np.random.default_rng(seed)
    row = TABLE_14_7[fit][ordering]

    s12 = sample_normal(r, *row["sin2_t12_10m1"], n) * SCALE["sin2_t12_10m1"]
    s23 = sample_normal(r, *row["sin2_t23_10m1"], n) * SCALE["sin2_t23_10m1"]
    s13 = sample_normal(r, *row["sin2_t13_10m2"], n) * SCALE["sin2_t13_10m2"]
    dm21 = sample_normal(r, *row["dm2_21"], n)
    dm32 = sample_normal(r, *row["dm2_32"], n)

    dcp = sample_angle_deg(r, *row["dcp_deg"], n)
    rad = np.deg2rad(dcp)
    c = np.cos(rad)
    s = np.sin(rad)

    return np.vstack([s12, s23, s13, c, s, dm21, dm32]).T

# ============================
# 3) Toggles + preprocess helpers
# ============================

def apply_dm32_mode(X: np.ndarray, mode: str) -> np.ndarray:
    X = np.asarray(X, dtype=float)
    if mode == "signed":
        return X
    if mode == "abs":
        Y = X.copy()
        Y[:, -1] = np.abs(Y[:, -1])
        return Y
    if mode == "drop":
        return X[:, :-1]
    raise ValueError(f"Unknown dm32 mode: {mode}")

def apply_dimensionless(X: np.ndarray) -> np.ndarray:
    X = np.asarray(X, dtype=float).copy()
    if X.shape[1] == 7:
        X[:, -2] = X[:, -2] / DM21_SCALE
        X[:, -1] = X[:, -1] / DM32_SCALE
    elif X.shape[1] == 6:
        X[:, -1] = X[:, -1] / DM21_SCALE
    return X

# ============================
# 4) Atlas + quantile trim
# ============================

def radial_quantile_mask(X: np.ndarray, q: Optional[Tuple[float, float]]) -> np.ndarray:
    if q is None:
        return np.ones(len(X), dtype=bool)
    ql, qh = q
    mu = np.median(X, axis=0)
    r = np.linalg.norm(X - mu, axis=1)
    lo, hi = np.quantile(r, [ql, qh])
    return (r >= lo) & (r <= hi)

@dataclass
class Atlas:
    preprocess: str
    dm32_mode: str
    mu: np.ndarray
    sd: np.ndarray
    mins: np.ndarray
    maxs: np.ndarray
    edges: List[np.ndarray]
    quantiles: Optional[Tuple[float, float]]

def build_global_atlas(preprocess: str, dm32_mode: str, atlas_quantiles: Optional[Tuple[float,float]]) -> Atlas:
    chunks = []
    seed0 = 12345 + (hash((preprocess, dm32_mode)) % 10000)
    k = 0
    for fit in FITS:
        for ordering in ORDERINGS:
            X = build_cloud_raw(fit, ordering, n=N_SAMPLES, seed=seed0 + 97 * k)
            X = apply_dm32_mode(X, dm32_mode)
            chunks.append(X)
            k += 1
    Xall = np.vstack(chunks)

    if preprocess == "zscore":
        mu = Xall.mean(axis=0)
        sd = Xall.std(axis=0)
        sd = np.where(sd > 0, sd, 1.0)
        Xall_p = (Xall - mu) / sd
    elif preprocess == "dimensionless":
        mu = np.zeros(Xall.shape[1], dtype=float)
        sd = np.ones(Xall.shape[1], dtype=float)
        Xall_p = apply_dimensionless(Xall)
    else:
        raise ValueError(f"Unknown preprocess mode: {preprocess}")

    # Quantile trimming applied here (atlas-only)
    mask = radial_quantile_mask(Xall_p, atlas_quantiles)
    Xref = Xall_p[mask] if np.any(mask) else Xall_p

    mins = np.nanmin(Xref, axis=0)
    maxs = np.nanmax(Xref, axis=0)

    # Ensure non-degenerate spans
    span = maxs - mins
    span = np.where(np.isfinite(span) & (span > 0), span, 1.0)
    maxs = mins + span

    edges = [np.linspace(0.0, 1.0, BINS + 1) for _ in range(Xall_p.shape[1])]
    return Atlas(preprocess, dm32_mode, mu, sd, mins, maxs, edges, atlas_quantiles)

def apply_atlas_preprocess(X: np.ndarray, atlas: Atlas) -> np.ndarray:
    X = np.asarray(X, dtype=float)
    if atlas.preprocess == "zscore":
        return (X - atlas.mu) / atlas.sd
    if atlas.preprocess == "dimensionless":
        return apply_dimensionless(X)
    raise ValueError("Invalid atlas preprocess")

def atlas_qtag(q: Optional[Tuple[float,float]]) -> str:
    if q is None:
        return "qNONE"
    return f"q{q[0]:.3g}_{q[1]:.3g}".replace(".", "p")

# ============================
# 5) Histogram helpers (reused)
# ============================

def hist_nd_atlas(X: np.ndarray, atlas: Atlas) -> np.ndarray:
    Y = (X - atlas.mins) / (atlas.maxs - atlas.mins + 1e-12)
    Y = np.clip(Y, 0.0, 1.0)
    H, _ = np.histogramdd(Y, bins=atlas.edges)
    return H / (H.sum() + 1e-15)

def points_to_bin_indices(X: np.ndarray, atlas: Atlas) -> np.ndarray:
    """
    Map points to histogram bin indices (per dimension).
    Returns integer array of shape (n, d) in [0, BINS-1].
    """
    Y = (X - atlas.mins) / (atlas.maxs - atlas.mins + 1e-12)
    Y = np.clip(Y, 0.0, 1.0 - 1e-15)  # keep inside last bin
    idx = np.floor(Y * BINS).astype(int)
    idx = np.clip(idx, 0, BINS - 1)
    return idx

def scalar_field_logprob(X: np.ndarray, atlas: Atlas, P: np.ndarray) -> np.ndarray:
    """
    z(x) = -log P(bin(x)) (a cheap "energy-like" scalar).
    """
    idx = points_to_bin_indices(X, atlas)
    # flatten multi-index
    flat = np.ravel_multi_index(idx.T, dims=P.shape)
    p = P.ravel()[flat]
    return -np.log(np.clip(p, 1e-15, None))

# ============================
# 6) Variograms
# ============================

def variogram_empirical(coords: np.ndarray, values: np.ndarray,
                        n_lags: int = N_LAGS, max_lag_frac: float = MAX_LAG_FRAC,
                        n_pairs: int = VARIO_N_PAIRS):
    """
    Empirical semivariogram via random pair sampling:
        gamma(h) = 0.5 E[(Z(x)-Z(y))^2 | ||x-y||≈h]
    """
    n = len(coords)
    if n < 2:
        return None

    i = rng.integers(0, n, size=n_pairs)
    j = rng.integers(0, n, size=n_pairs)
    m = i != j
    i, j = i[m], j[m]

    d = np.linalg.norm(coords[i] - coords[j], axis=1)
    dv = values[i] - values[j]
    gamma = 0.5 * (dv * dv)

    dmax = np.quantile(d, 0.999)
    dmax = max_lag_frac * dmax
    edges = np.linspace(0.0, dmax, n_lags + 1)

    idx = np.digitize(d, edges) - 1
    keep = (idx >= 0) & (idx < n_lags)
    idx = idx[keep]
    gamma = gamma[keep]

    lag_centers = 0.5 * (edges[:-1] + edges[1:])
    gamma_binned = np.full(n_lags, np.nan)
    counts = np.zeros(n_lags, dtype=int)

    for k in range(n_lags):
        sel = (idx == k)
        counts[k] = int(np.sum(sel))
        if counts[k] > 100:
            gamma_binned[k] = float(np.mean(gamma[sel]))

    return lag_centers, gamma_binned, counts

# ============================
# 7) OT (Sinkhorn) + Procrustes
# ============================

def sinkhorn_plan_uniform(C: np.ndarray, reg: float, n_iter: int = OT_ITERS, eps: float = OT_EPS) -> np.ndarray:
    """
    Sinkhorn-Knopp for uniform marginals with kernel K=exp(-C/reg).
    C: (m,m) cost matrix (squared Euclidean recommended).
    Returns transport plan P.
    """
    # Stabilize kernel range
    Cmin = np.min(C)
    K = np.exp(-(C - Cmin) / max(reg, 1e-12))
    K = np.clip(K, 1e-300, None)

    m = C.shape[0]
    a = np.full(m, 1.0 / m)
    b = np.full(m, 1.0 / m)

    u = np.ones(m)
    v = np.ones(m)

    for _ in range(n_iter):
        Ku = K @ v
        Ku = np.where(Ku > eps, Ku, eps)
        u = a / Ku
        Kv = K.T @ u
        Kv = np.where(Kv > eps, Kv, eps)
        v = b / Kv

    P = (u[:, None] * K) * v[None, :]
    # renormalize small drift
    P = np.clip(P, 0.0, None)
    Psum = P.sum()
    if Psum > 0:
        P /= Psum
    return P


def sinkhorn_plan_rect(C: np.ndarray, reg: float, n_iter: int = OT_ITERS, eps: float = OT_EPS) -> np.ndarray:
    """Rectangular Sinkhorn-Knopp for uniform marginals.

    Given cost matrix C (m,n), returns transport plan P (m,n) such that
    row sums ≈ 1/m and column sums ≈ 1/n (up to numerical tolerance).
    """
    C = np.asarray(C, dtype=float)
    m, n = C.shape
    # Stabilize exponentials by subtracting the min cost
    Cmin = float(np.min(C))
    K = np.exp(-(C - Cmin) / max(reg, 1e-12))
    K = np.clip(K, 1e-300, None)

    a = np.full(m, 1.0 / m)
    b = np.full(n, 1.0 / n)

    u = np.ones(m)
    v = np.ones(n)

    for _ in range(int(n_iter)):
        Kv = K @ v
        Kv = np.where(Kv > eps, Kv, eps)
        u = a / Kv

        Ktu = K.T @ u
        Ktu = np.where(Ktu > eps, Ktu, eps)
        v = b / Ktu

    P = (u[:, None] * K) * v[None, :]
    P = np.clip(P, 0.0, None)
    s = float(np.sum(P))
    if s > 0:
        P /= s
    return P


def ot_sample_loglik(A: np.ndarray, X: np.ndarray, reg: float, n_iter: int = OT_ITERS) -> Tuple[np.ndarray, np.ndarray]:
    """Per-sample log-likelihood via reverse OT flow (atlas→samples).

    Builds the cost C_ij = ||A_i - X_j||^2, computes rectangular entropic OT plan P,
    then scores each sample x_j by:

        ell(x_j) = log( sum_i P_ij * exp(-C_ij / reg) )

    Returns:
      ell: (n,) log-scores
      C:   (m,n) cost matrix (useful for diagnostics)
    """
    A = np.asarray(A, dtype=float)
    X = np.asarray(X, dtype=float)

    AA = np.sum(A * A, axis=1, keepdims=True)       # (m,1)
    XX = np.sum(X * X, axis=1, keepdims=True).T     # (1,n)
    C = AA + XX - 2.0 * (A @ X.T)                   # (m,n)
    C = np.clip(C, 0.0, None)

    P = sinkhorn_plan_rect(C, reg=reg, n_iter=n_iter)

    W = P * np.exp(-C / max(reg, 1e-12))
    s = np.sum(W, axis=0)
    ell = np.log(np.clip(s, 1e-300, None))
    return ell, C


def auc_mann_whitney(y: np.ndarray, score: np.ndarray) -> float:
    """Compute ROC AUC using the Mann–Whitney U statistic (no sklearn dependency)."""
    y = np.asarray(y).astype(int)
    score = np.asarray(score, dtype=float)
    pos = score[y == 1]
    neg = score[y == 0]
    n_pos = len(pos)
    n_neg = len(neg)
    if n_pos == 0 or n_neg == 0:
        return float("nan")

    # Rank scores; average ranks for ties
    order = np.argsort(score)
    ranks = np.empty_like(order, dtype=float)
    ranks[order] = np.arange(1, len(score) + 1, dtype=float)

    # Tie adjustment (average ranks for equal scores)
    # (simple pass over sorted scores)
    sorted_scores = score[order]
    i = 0
    while i < len(sorted_scores):
        j = i + 1
        while j < len(sorted_scores) and sorted_scores[j] == sorted_scores[i]:
            j += 1
        if j - i > 1:
            avg = np.mean(ranks[order[i:j]])
            ranks[order[i:j]] = avg
        i = j

    U = np.sum(ranks[y == 1]) - n_pos * (n_pos + 1) / 2.0
    auc = U / (n_pos * n_neg)
    return float(auc)


def roc_curve_basic(y: np.ndarray, score: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """Basic ROC curve points (FPR, TPR) without sklearn."""
    y = np.asarray(y).astype(int)
    score = np.asarray(score, dtype=float)

    # Sort by descending score
    order = np.argsort(-score)
    y_sorted = y[order]

    P = np.sum(y_sorted == 1)
    N = np.sum(y_sorted == 0)
    if P == 0 or N == 0:
        return np.array([0.0, 1.0]), np.array([0.0, 1.0])

    tps = np.cumsum(y_sorted == 1)
    fps = np.cumsum(y_sorted == 0)

    tpr = tps / P
    fpr = fps / N

    # include origin
    fpr = np.concatenate([[0.0], fpr, [1.0]])
    tpr = np.concatenate([[0.0], tpr, [1.0]])
    return fpr, tpr


def plot_deltaell_hist(delta: np.ndarray, y: np.ndarray, fit: str, atlas: Atlas, qtag: str) -> str:
    """Histogram of Δℓ split by label."""
    ensure_plot_dir()
    delta = np.asarray(delta, float)
    y = np.asarray(y).astype(int)

    plt.figure(figsize=(7, 4.5))
    plt.hist(delta[y == 0], bins=50, alpha=0.6, density=True, label="NO samples")
    plt.hist(delta[y == 1], bins=50, alpha=0.6, density=True, label="IO samples")
    plt.axvline(0.0, linestyle="--")
    plt.title(f"Δℓ = ℓ_NO − ℓ_IO | {fit} | {atlas.preprocess_mode}/{atlas.dm32_mode} | {qtag}")
    plt.xlabel("Δℓ")
    plt.ylabel("density")
    plt.legend()
    fn = f"plots/deltaell_hist_{fit}_{atlas.preprocess_mode}_{atlas.dm32_mode}_{qtag}.png"
    plt.tight_layout()
    plt.savefig(fn, dpi=160)
    plt.close()
    return fn


def plot_roc(delta: np.ndarray, y: np.ndarray, fit: str, atlas: Atlas, qtag: str, auc: float) -> str:
    """ROC curve for Δℓ used as score (larger => NO)."""
    ensure_plot_dir()
    # For ROC we want score that increases with positive class; take IO as positive => use -delta
    score = -np.asarray(delta, float)
    y = np.asarray(y).astype(int)
    fpr, tpr = roc_curve_basic(y, score)

    plt.figure(figsize=(5.2, 5.2))
    plt.plot(fpr, tpr, linewidth=2)
    plt.plot([0, 1], [0, 1], linestyle="--")
    plt.title(f"ROC (IO=1) | AUC={auc:.3f}\n{fit} | {atlas.preprocess_mode}/{atlas.dm32_mode} | {qtag}")
    plt.xlabel("FPR")
    plt.ylabel("TPR")
    fn = f"plots/roc_{fit}_{atlas.preprocess_mode}_{atlas.dm32_mode}_{qtag}.png"
    plt.tight_layout()
    plt.savefig(fn, dpi=160)
    plt.close()
    return fn


def plot_deltaell_vs_radius(delta: np.ndarray, X: np.ndarray, center: np.ndarray, fit: str, atlas: Atlas, qtag: str) -> str:
    """Scatter Δℓ vs radius in atlas space."""
    ensure_plot_dir()
    X = np.asarray(X, float)
    center = np.asarray(center, float)
    r = np.linalg.norm(X - center[None, :], axis=1)
    delta = np.asarray(delta, float)

    plt.figure(figsize=(7, 4.5))
    plt.scatter(r, delta, s=8, alpha=0.35)
    plt.axhline(0.0, linestyle="--")
    plt.title(f"Δℓ vs radius | {fit} | {atlas.preprocess_mode}/{atlas.dm32_mode} | {qtag}")
    plt.xlabel("radius ||x - center||")
    plt.ylabel("Δℓ")
    fn = f"plots/deltaell_vs_radius_{fit}_{atlas.preprocess_mode}_{atlas.dm32_mode}_{qtag}.png"
    plt.tight_layout()
    plt.savefig(fn, dpi=160)
    plt.close()
    return fn

def barycentric_map(P: np.ndarray, Y: np.ndarray) -> np.ndarray:
    """Map each source point i to sum_j P_ij Y_j / sum_j P_ij."""
    w = P.sum(axis=1, keepdims=True)
    w = np.where(w > 0, w, 1.0)
    return (P @ Y) / w

def procrustes_align(A: np.ndarray, B: np.ndarray):
    """
    Align B to A with similarity transform.
    Returns aligned B, residual norms, and transform pieces.
    """
    Ac = A - A.mean(axis=0, keepdims=True)
    Bc = B - B.mean(axis=0, keepdims=True)

    normA = np.linalg.norm(Ac)
    normB = np.linalg.norm(Bc)
    if normA < 1e-12 or normB < 1e-12:
        return B.copy(), np.full(len(B), np.nan), None

    Acn = Ac / normA
    Bcn = Bc / normB

    M = Bcn.T @ Acn
    U, _, Vt = np.linalg.svd(M)
    R = U @ Vt

    B_aligned = (Bcn @ R) * normA + A.mean(axis=0, keepdims=True)
    res = np.linalg.norm(A - B_aligned, axis=1)
    return B_aligned, res, {"R": R, "scale": normA / normB}

def nn_match(A: np.ndarray, B: np.ndarray) -> np.ndarray:
    """Nearest-neighbor matching: returns B matched to each A (same length as A)."""
    try:
        from sklearn.neighbors import NearestNeighbors
        nn = NearestNeighbors(n_neighbors=1).fit(B)
        _, ind = nn.kneighbors(A, return_distance=True)
        return B[ind[:, 0]]
    except Exception:
        # brute force fallback
        out = np.empty_like(A)
        for i in range(len(A)):
            d = np.sum((B - A[i])**2, axis=1)
            out[i] = B[np.argmin(d)]
        return out

# ============================
# 8) Plotting
# ============================

def ensure_plot_dir():
    os.makedirs(PLOT_DIR, exist_ok=True)

def plot_variogram(lags, g_no, g_io, fit, atlas, qtag):
    import matplotlib.pyplot as plt
    ensure_plot_dir()
    plt.figure()
    plt.plot(lags, g_no, marker="o", label="NO")
    plt.plot(lags, g_io, marker="o", label="IO")
    plt.xlabel("lag ||x-y||")
    plt.ylabel("semivariogram γ(h)")
    plt.title(f"Variograms | {fit} | {atlas.preprocess} | {atlas.dm32_mode} | {qtag}")
    plt.legend()
    fn = os.path.join(PLOT_DIR, f"variogram_{fit}_{atlas.preprocess}_{atlas.dm32_mode}_{qtag}.png")
    plt.tight_layout()
    plt.savefig(fn, dpi=160)
    plt.close()

def plot_residual_hist(res, fit, atlas, qtag):
    import matplotlib.pyplot as plt
    ensure_plot_dir()
    plt.figure()
    plt.hist(res[np.isfinite(res)], bins=50)
    plt.xlabel("||A - Procrustes(OT(A))||")
    plt.ylabel("count")
    plt.title(f"Residual histogram | {fit} | {atlas.preprocess} | {atlas.dm32_mode} | {qtag}")
    fn = os.path.join(PLOT_DIR, f"residual_hist_{fit}_{atlas.preprocess}_{atlas.dm32_mode}_{qtag}.png")
    plt.tight_layout()
    plt.savefig(fn, dpi=160)
    plt.close()

def plot_match_scatter(A, Bm, fit, atlas, qtag):
    import matplotlib.pyplot as plt
    ensure_plot_dir()
    # Use first 2 coordinates for a simple visual
    plt.figure()
    plt.scatter(A[:,0], A[:,1], s=8, alpha=0.6, label="NO (A)")
    plt.scatter(Bm[:,0], Bm[:,1], s=8, alpha=0.6, label="IO matched (B̂)")
    plt.xlabel("coord 0")
    plt.ylabel("coord 1")
    plt.title(f"Match scatter (2D) | {fit} | {atlas.preprocess} | {atlas.dm32_mode} | {qtag}")
    plt.legend()
    fn = os.path.join(PLOT_DIR, f"match_scatter_{fit}_{atlas.preprocess}_{atlas.dm32_mode}_{qtag}.png")
    plt.tight_layout()
    plt.savefig(fn, dpi=160)
    plt.close()

# ============================
# 9) Main experiment
# ============================

def run_one_fit(fit: str, atlas: Atlas) -> Tuple[Dict[str, float], List[Dict[str, float]], pd.DataFrame]:
    """
    v007 runner (per FIT):
      - Build NO/IO clouds in atlas space
      - Compute variograms (kept from v006 for context)
      - Reverse OT flow: atlas(NO)→samples and atlas(IO)→samples
      - Produce per-sample scores ℓ_NO, ℓ_IO and Δℓ = ℓ_NO − ℓ_IO
    Returns:
      summary: one-row dict
      vario_rows: list of rows for variograms CSV
      scores_df: per-sample scores dataframe
    """
    # Build NO/IO clouds in raw space
    X_no_raw = build_cloud_raw(fit, "NO", n=N_SAMPLES, seed=1)
    X_io_raw = build_cloud_raw(fit, "IO", n=N_SAMPLES, seed=2)

    # Apply dm32 mode + atlas preprocess → atlas space
    X_no = apply_dm32_mode(X_no_raw, atlas.dm32_mode)
    X_io = apply_dm32_mode(X_io_raw, atlas.dm32_mode)
    X_no = apply_atlas_preprocess(X_no, atlas)
    X_io = apply_atlas_preprocess(X_io, atlas)

    # Build histograms and scalar fields
    P_no = hist_nd_atlas(X_no, atlas)
    P_io = hist_nd_atlas(X_io, atlas)
    z_no = scalar_field_logprob(X_no, atlas, P_no)
    z_io = scalar_field_logprob(X_io, atlas, P_io)

    # Variograms
    v_no = variogram_empirical(X_no, z_no)
    v_io = variogram_empirical(X_io, z_io)

    vario_rows: List[Dict[str, float]] = []
    qtag = atlas_qtag(atlas.quantiles)

    if v_no is not None and v_io is not None:
        lags, g_no, c_no = v_no
        _,    g_io, c_io = v_io

        plot_variogram(lags, g_no, g_io, fit, atlas, qtag)

        for k in range(len(lags)):
            vario_rows.append({
                "fit": fit,
                "preprocess_mode": atlas.preprocess_mode,
                "dm32_mode": atlas.dm32_mode,
                "qtag": qtag,
                "lag": float(lags[k]),
                "gamma_no": float(g_no[k]),
                "gamma_io": float(g_io[k]),
                "count_no": float(c_no[k]),
                "count_io": float(c_io[k]),
            })

    # ----------------------------
    # Reverse OT flow (atlas → samples)
    # ----------------------------
    # Samples: union, with labels (0=NO, 1=IO)
    X = np.vstack([X_no, X_io])
    y = np.concatenate([np.zeros(len(X_no), dtype=int), np.ones(len(X_io), dtype=int)])

    # Subsample samples for speed (reproducible)
    n = len(X)
    n_keep = min(n, N_KEEP_SAMPLES)
    idx = rng.choice(n, size=n_keep, replace=False)
    X = X[idx]
    y = y[idx]

    # Subsample atlases for OT (balanced)
    m = min(M_OT, len(X_no), len(X_io))
    A_no = X_no[rng.choice(len(X_no), size=m, replace=False)]
    A_io = X_io[rng.choice(len(X_io), size=m, replace=False)]

    ell_no, _Cno = ot_sample_loglik(A_no, X, reg=OT_REG, n_iter=OT_ITERS)
    ell_io, _Cio = ot_sample_loglik(A_io, X, reg=OT_REG, n_iter=OT_ITERS)
    delta = ell_no - ell_io

    # AUC: treat IO as positive class; score should increase for IO, so use -delta
    auc = auc_mann_whitney(y, -delta)

    # Plots
    plot_deltaell_hist(delta, y, fit, atlas, qtag)
    plot_roc(delta, y, fit, atlas, qtag, auc=auc)
    center = np.median(np.vstack([A_no, A_io]), axis=0)
    plot_deltaell_vs_radius(delta, X, center, fit, atlas, qtag)

    # Per-sample table
    scores_df = pd.DataFrame({
        "fit": fit,
        "preprocess_mode": atlas.preprocess_mode,
        "dm32_mode": atlas.dm32_mode,
        "qtag": qtag,
        "sample_id": np.arange(len(X), dtype=int),
        "label": y,
        "ell_no": ell_no,
        "ell_io": ell_io,
        "delta_ell": delta,
    })

    # Summary row
    def _stats(arr):
        arr = np.asarray(arr, float)
        return float(np.mean(arr)), float(np.median(arr)), float(np.std(arr)), float(np.percentile(arr, 95))

    d_no = delta[y == 0]
    d_io = delta[y == 1]
    mean_no, med_no, sd_no, p95_no = _stats(d_no) if len(d_no) else (float("nan"),)*4
    mean_io, med_io, sd_io, p95_io = _stats(d_io) if len(d_io) else (float("nan"),)*4

    summary = {
        "fit": fit,
        "preprocess_mode": atlas.preprocess_mode,
        "dm32_mode": atlas.dm32_mode,
        "qtag": qtag,
        "n_samples_raw": N_SAMPLES,
        "n_eval": int(len(X)),
        "m_ot": int(m),
        "bins": int(BINS),
        "ot_reg": float(OT_REG),
        "ot_iters": int(OT_ITERS),
        "auc_io": float(auc),
        "delta_mean_no": mean_no,
        "delta_median_no": med_no,
        "delta_std_no": sd_no,
        "delta_p95_no": p95_no,
        "delta_mean_io": mean_io,
        "delta_median_io": med_io,
        "delta_std_io": sd_io,
        "delta_p95_io": p95_io,
        "delta_mean_all": float(np.mean(delta)),
        "delta_std_all": float(np.std(delta)),
    }

    return summary, vario_rows, scores_df

def main():
    os.makedirs(PLOT_DIR, exist_ok=True)

    all_summaries: List[Dict[str, float]] = []
    all_vario_rows: List[Dict[str, float]] = []
    all_scores: List[pd.DataFrame] = []

    print("\n=== v007 RUN SETTINGS ===")
    print("FITS:", FITS)
    print("PREPROCESS_MODES:", PREPROCESS_MODES)
    print("DM32_MODES:", DM32_MODES)
    print(f"N={N_SAMPLES}, bins={BINS}, M_OT={M_OT}, N_KEEP={N_KEEP_SAMPLES}, OT_REG={OT_REG}, iters={OT_ITERS}")
    print(f"ATLAS_QUANTILES={ATLAS_QUANTILES}")
    print("=========================\n")

    for preprocess in PREPROCESS_MODES:
        for dm32_mode in DM32_MODES:
            atlas = build_global_atlas(preprocess, dm32_mode, atlas_quantiles=ATLAS_QUANTILES)

            print(f"\n######## ATLAS preprocess={preprocess} | dm32_mode={dm32_mode} | {atlas_qtag(atlas.quantiles)} ########")
            print("Dims:", len(atlas.mins))
            print("Atlas mins:", atlas.mins)
            print("Atlas maxs:", atlas.maxs)

            for fit in FITS:
                summary, vario_rows, scores_df = run_one_fit(fit, atlas)
                all_scores.append(scores_df)
                print(summary)
                all_summaries.append(summary)
                all_vario_rows.extend(vario_rows)

    # Write summary CSV
    if all_summaries:
        with open(OUT_SUMMARY, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(all_summaries[0].keys()))
            w.writeheader()
            w.writerows(all_summaries)

    # Write variogram CSV
    if all_vario_rows:
        with open(OUT_VARIO, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(all_vario_rows[0].keys()))
            w.writeheader()
            w.writerows(all_vario_rows)
    # Write per-sample OT scores
    if all_scores:
        scores = pd.concat(all_scores, ignore_index=True)
        scores.to_csv(OUT_SCORES, index=False)


    print("\n=== Outputs written ===")
    print("Summary:", OUT_SUMMARY)
    print("Variograms:", OUT_VARIO)
    print("OT scores:", OUT_SCORES)
    print("Plots dir:", PLOT_DIR)
    print("=======================\n")

if __name__ == "__main__":
    main()
