#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
metric_003.py

Scale–resolved diagonalization of Fisher matrices.
Directional coherence diagnostics across scale and across FITs.

PATCH (Stage 0 for metric_007):
- Export per-shell Fisher/Cov eigensystems to NPZ so later holonomy/QC metrics
  can run without recomputation.
- Sort shells by r_mean (consistent with metric_004/005/006 and with "scale" logic).

Original file: :contentReference[oaicite:4]{index=4}
"""

import numpy as np
import hashlib
import pandas as pd
import os
import json
import matplotlib.pyplot as plt

# ============================================================
# 0) Configuration
# ============================================================

FITS = ["NUFIT", "BARI", "VALENCIA"]
ORDERINGS = ["NO", "IO"]

PREPROCESS = "zscore"
DM32_MODE = "signed"

N_SAMPLES = 5000
N_RADIAL_BINS = 20
MIN_PER_BIN = 150

RNG_SEED = 123
rng = np.random.default_rng(RNG_SEED)

OUTDIR = "metric_003_outputs"
os.makedirs(OUTDIR, exist_ok=True)

# ----------------------------
# Stage 0 export (NEW)
# ----------------------------
EXPORT_EIGENSYSTEMS = True
EXPORT_DIR = "metric_007_inputs"
EXPORT_TAG = "metric_003"
os.makedirs(EXPORT_DIR, exist_ok=True)

# ============================================================
# 1) Import atlas machinery (from v007)
# ============================================================

from GIKL_neutrino_007_fixed import (
    build_cloud_raw,
    apply_dm32_mode,
    build_global_atlas,
    apply_atlas_preprocess,
)

# ============================================================
# 2) Helpers
# ============================================================


def _matrix_fingerprint(A: np.ndarray) -> dict:
    """Stable-ish fingerprint for sanity checks (float tolerant summary + byte hash)."""
    A = np.asarray(A)
    Af = np.ascontiguousarray(A.astype(np.float64, copy=False))
    h = hashlib.sha256(Af.tobytes()).hexdigest()[:16]
    return dict(
        sha16=h,
        shape=tuple(A.shape),
        fro=float(np.linalg.norm(Af, ord='fro')),
        maxabs=float(np.max(np.abs(Af))),
        mean=float(np.mean(Af)),
        std=float(np.std(Af)),
        sym_err=float(np.linalg.norm(Af - Af.T, ord='fro')) if Af.ndim == 2 else float('nan'),
    )

def fisher_eigensystem(X):
    """
    Fisher proxy: inverse covariance eigensystem.
    Returns eigenvalues (descending) and eigenvectors (columns).
    NOTE: eigvecs of Cov and Cov^{-1} are the same; we work with Cov eigvecs.
    """
    C = np.cov(X, rowvar=False)
    vals, vecs = np.linalg.eigh(C)
    idx = np.argsort(vals)[::-1]
    return vals[idx], vecs[:, idx], C

def angle_between(u, v):
    """
    Angle between vectors (absolute, sign-invariant).
    """
    c = np.abs(np.dot(u, v))
    c = np.clip(c, -1.0, 1.0)
    return np.arccos(c)

def export_shell_eigs(fit, shells):
    """
    Write a deterministic NPZ artifact for metric_007 (and beyond).
    shells must already be sorted by r_mean.
    """
    if not shells:
        return

    # shapes
    D = shells[0]["eigvecs"].shape[0]
    S = len(shells)

    shell_ids = np.array([s["shell"] for s in shells], dtype=int)
    shell_centers = np.array([s["r_mean"] for s in shells], dtype=float)
    counts = np.array([s["n"] for s in shells], dtype=int)

    eigvals = np.zeros((S, D), dtype=float)
    eigvecs = np.zeros((S, D, D), dtype=float)

    fps = []
    for i, s in enumerate(shells):
        eigvals[i, :] = np.asarray(s["eigvals"], dtype=float).ravel()
        eigvecs[i, :, :] = np.asarray(s["eigvecs"], dtype=float)
        fps.append(s.get("fingerprint", {}))

    meta = {
        "tag": EXPORT_TAG,
        "fit": fit,
        "preprocess": PREPROCESS,
        "dm32_mode": DM32_MODE,
        "N_SAMPLES_per_ordering": int(N_SAMPLES),
        "N_RADIAL_BINS": int(N_RADIAL_BINS),
        "MIN_PER_BIN": int(MIN_PER_BIN),
        "note": "Per-shell covariance/Fisher eigensystems. eigvecs are columns, sorted by descending eigvals.",
    }

    outpath = os.path.join(
        EXPORT_DIR,
        f"eigshells__{EXPORT_TAG}__{fit}__{PREPROCESS}__{DM32_MODE}.npz"
    )
    np.savez_compressed(
        outpath,
        metric_id=EXPORT_TAG,
        fit_name=fit,
        shell_ids=shell_ids,
        shell_centers=shell_centers,
        counts=counts,
        eigvals=eigvals,
        eigvecs=eigvecs,
        fingerprints=np.array(fps, dtype=object),
        meta_json=json.dumps(meta),
    )
    print("[export] wrote:", outpath)

# ============================================================
# 3) Per-FIT shell eigensystems
# ============================================================

def analyze_fit(fit, atlas):
    print(f"\n--- FIT: {fit} ---")

    # Sample
    X_no = build_cloud_raw(fit, "NO", N_SAMPLES, seed=1)
    X_io = build_cloud_raw(fit, "IO", N_SAMPLES, seed=2)

    X_no = apply_atlas_preprocess(apply_dm32_mode(X_no, DM32_MODE), atlas)
    X_io = apply_atlas_preprocess(apply_dm32_mode(X_io, DM32_MODE), atlas)

    X = np.vstack([X_no, X_io])

    # Radial coordinate
    center = np.median(X, axis=0)
    r = np.linalg.norm(X - center, axis=1)

    # Radial shells
    edges = np.quantile(r, np.linspace(0, 1, N_RADIAL_BINS + 1))
    shell_id = np.digitize(r, edges) - 1

    shells = []

    for k in range(N_RADIAL_BINS):
        m = (shell_id == k)
        n = int(np.sum(m))
        if n < MIN_PER_BIN:
            continue

        Xk = X[m]
        rmean = float(np.mean(r[m]))

        vals, vecs, C = fisher_eigensystem(Xk)
        fp = _matrix_fingerprint(C)
        fp["k"] = int(k)

        shells.append({
            "shell": int(k),
            "r_mean": float(rmean),
            "eigvals": vals,
            "eigvecs": vecs,
            "n": n,
            "fingerprint": fp,
        })

    # IMPORTANT: sort shells by scale (consistent with metric_004/005/006)
    shells = sorted(shells, key=lambda s: s["r_mean"])

    if EXPORT_EIGENSYSTEMS:
        export_shell_eigs(fit, shells)

    return shells

# ============================================================
# 4) Eigenvector rotation vs scale
# ============================================================

def rotation_vs_scale(shells, mode=0):
    """
    Compute eigenvector rotation angles between adjacent shells
    for a given eigenmode index.
    """
    angles = []
    rmid = []

    for i in range(len(shells) - 1):
        v1 = shells[i]["eigvecs"][:, mode]
        v2 = shells[i + 1]["eigvecs"][:, mode]

        theta = angle_between(v1, v2)
        angles.append(theta)
        rmid.append(0.5 * (shells[i]["r_mean"] + shells[i + 1]["r_mean"]))

    return np.array(rmid), np.array(angles)

# ============================================================
# 5) Alignment persistence
# ============================================================

def persistence_length(shells, mode=0, threshold=np.pi/6):
    """
    How many consecutive shells does an eigenvector remain aligned?
    """
    count = 0
    for i in range(len(shells) - 1):
        v1 = shells[i]["eigvecs"][:, mode]
        v2 = shells[i + 1]["eigvecs"][:, mode]
        if angle_between(v1, v2) < threshold:
            count += 1
        else:
            break
    return count

# ============================================================
# 6) Cross-FIT coherence
# ============================================================

def cross_fit_overlap(shells_A, shells_B, mode=0):
    """
    Overlap of dominant eigenvectors between two FITs
    at matching shell index (zip).
    """
    overlaps = []
    rvals = []

    for sA, sB in zip(shells_A, shells_B):
        vA = sA["eigvecs"][:, mode]
        vB = sB["eigvecs"][:, mode]
        overlaps.append(np.abs(np.dot(vA, vB)))
        rvals.append(sA["r_mean"])

    return np.array(rvals), np.array(overlaps)

# ============================================================
# 7) Main
# ============================================================

def main():
    atlas = build_global_atlas(PREPROCESS, DM32_MODE, atlas_quantiles=None)

    shell_data = {}
    for fit in FITS:
        shell_data[fit] = analyze_fit(fit, atlas)

    # --------------------------------------------------------
    # Eigenvector rotation plots (dominant mode)
    # --------------------------------------------------------

    for fit in FITS:
        rmid, angles = rotation_vs_scale(shell_data[fit], mode=0)

        plt.figure()
        plt.plot(rmid, angles, "o-")
        plt.xlabel("r (scale)")
        plt.ylabel("rotation angle (rad)")
        plt.title(f"{fit}: dominant eigenvector rotation")
        plt.tight_layout()
        plt.savefig(f"{OUTDIR}/{fit}_rotation.png")
        plt.close()

    # --------------------------------------------------------
    # Persistence table
    # --------------------------------------------------------

    rows = []
    for fit in FITS:
        p = persistence_length(shell_data[fit], mode=0)
        rows.append({"FIT": fit, "persistence_shells": p})

    df_persist = pd.DataFrame(rows)
    df_persist.to_csv(f"{OUTDIR}/persistence.csv", index=False)

    # --------------------------------------------------------
    # Cross-FIT coherence
    # --------------------------------------------------------

    pairs = [("NUFIT", "BARI"), ("NUFIT", "VALENCIA"), ("BARI", "VALENCIA")]

    for A, B in pairs:
        rvals, ov = cross_fit_overlap(shell_data[A], shell_data[B], mode=0)

        plt.figure()
        plt.plot(rvals, ov, "o-")
        plt.xlabel("r (scale)")
        plt.ylabel("|v·w|")
        plt.title(f"Cross-FIT coherence: {A} vs {B}")
        plt.tight_layout()
        plt.savefig(f"{OUTDIR}/{A}_{B}_coherence.png")
        plt.close()

    print("\n=== metric_003 completed ===")
    print("Outputs written to:", OUTDIR)
    if EXPORT_EIGENSYSTEMS:
        print("Stage-0 eigensystems written to:", EXPORT_DIR)

if __name__ == "__main__":
    main()
