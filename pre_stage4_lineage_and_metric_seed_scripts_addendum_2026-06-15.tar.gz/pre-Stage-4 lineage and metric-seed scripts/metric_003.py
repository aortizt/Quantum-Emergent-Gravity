#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jan 10 19:58:28 2026

@author: dakini
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
metric_003.py

Scale–resolved diagonalization of Fisher matrices.
Directional coherence diagnostics across scale and across FITs.

WHAT THIS DOES:
- Computes Fisher eigensystems per radial shell
- Measures eigenvector rotation vs scale
- Measures alignment persistence
- Measures cross-FIT directional coherence

WHAT THIS DOES NOT DO:
- No curvature claims
- No transport / holonomy
- No spacetime or physical interpretation
"""

import numpy as np
import pandas as pd
import os
import matplotlib.pyplot as plt

# ============================================================
# 0) Configuration
# ============================================================

FITS = ["NUFIT", "BARI", "VALENCIA"]
ORDERINGS = ["NO", "IO"]

PREPROCESS = "zscore"
DM32_MODE = "signed"

N_SAMPLES = 5000
N_RADIAL_BINS = 20
MIN_PER_BIN = 150

RNG_SEED = 123
rng = np.random.default_rng(RNG_SEED)

OUTDIR = "metric_003_outputs"
os.makedirs(OUTDIR, exist_ok=True)

# ============================================================
# 1) Import atlas machinery (from v007)
# ============================================================

from GIKL_neutrino_007_fixed import (
    build_cloud_raw,
    apply_dm32_mode,
    build_global_atlas,
    apply_atlas_preprocess,
)

# ============================================================
# 2) Helpers
# ============================================================

def fisher_eigensystem(X):
    """
    Fisher proxy: inverse covariance eigensystem.
    Returns eigenvalues (descending) and eigenvectors.
    """
    C = np.cov(X, rowvar=False)
    vals, vecs = np.linalg.eigh(C)
    idx = np.argsort(vals)[::-1]
    return vals[idx], vecs[:, idx]

def angle_between(u, v):
    """
    Angle between vectors (absolute, sign-invariant).
    """
    c = np.abs(np.dot(u, v))
    c = np.clip(c, -1.0, 1.0)
    return np.arccos(c)

# ============================================================
# 3) Per-FIT shell eigensystems
# ============================================================

def analyze_fit(fit, atlas):
    print(f"\n--- FIT: {fit} ---")

    # Sample
    X_no = build_cloud_raw(fit, "NO", N_SAMPLES, seed=1)
    X_io = build_cloud_raw(fit, "IO", N_SAMPLES, seed=2)

    X_no = apply_atlas_preprocess(apply_dm32_mode(X_no, DM32_MODE), atlas)
    X_io = apply_atlas_preprocess(apply_dm32_mode(X_io, DM32_MODE), atlas)

    X = np.vstack([X_no, X_io])

    # Radial coordinate
    center = np.median(X, axis=0)
    r = np.linalg.norm(X - center, axis=1)

    # Radial shells
    edges = np.quantile(r, np.linspace(0, 1, N_RADIAL_BINS + 1))
    shell_id = np.digitize(r, edges) - 1

    shells = []

    for k in range(N_RADIAL_BINS):
        m = (shell_id == k)
        if np.sum(m) < MIN_PER_BIN:
            continue

        Xk = X[m]
        rmean = np.mean(r[m])

        vals, vecs = fisher_eigensystem(Xk)

        shells.append({
            "shell": k,
            "r_mean": rmean,
            "eigvals": vals,
            "eigvecs": vecs,
        })

    return shells

# ============================================================
# 4) Eigenvector rotation vs scale
# ============================================================

def rotation_vs_scale(shells, mode=0):
    """
    Compute eigenvector rotation angles between adjacent shells
    for a given eigenmode index.
    """
    angles = []
    rmid = []

    for i in range(len(shells) - 1):
        v1 = shells[i]["eigvecs"][:, mode]
        v2 = shells[i + 1]["eigvecs"][:, mode]

        theta = angle_between(v1, v2)
        angles.append(theta)
        rmid.append(0.5 * (shells[i]["r_mean"] + shells[i + 1]["r_mean"]))

    return np.array(rmid), np.array(angles)

# ============================================================
# 5) Alignment persistence
# ============================================================

def persistence_length(shells, mode=0, threshold=np.pi/6):
    """
    How many consecutive shells does an eigenvector remain aligned?
    """
    count = 0
    for i in range(len(shells) - 1):
        v1 = shells[i]["eigvecs"][:, mode]
        v2 = shells[i + 1]["eigvecs"][:, mode]
        if angle_between(v1, v2) < threshold:
            count += 1
        else:
            break
    return count

# ============================================================
# 6) Cross-FIT coherence
# ============================================================

def cross_fit_overlap(shells_A, shells_B, mode=0):
    """
    Overlap of dominant eigenvectors between two FITs
    at matching shell index.
    """
    overlaps = []
    rvals = []

    for sA, sB in zip(shells_A, shells_B):
        vA = sA["eigvecs"][:, mode]
        vB = sB["eigvecs"][:, mode]
        overlaps.append(np.abs(np.dot(vA, vB)))
        rvals.append(sA["r_mean"])

    return np.array(rvals), np.array(overlaps)

# ============================================================
# 7) Main
# ============================================================

def main():
    atlas = build_global_atlas(PREPROCESS, DM32_MODE, atlas_quantiles=None)

    shell_data = {}
    for fit in FITS:
        shell_data[fit] = analyze_fit(fit, atlas)

    # --------------------------------------------------------
    # Eigenvector rotation plots (dominant mode)
    # --------------------------------------------------------

    for fit in FITS:
        rmid, angles = rotation_vs_scale(shell_data[fit], mode=0)

        plt.figure()
        plt.plot(rmid, angles, "o-")
        plt.xlabel("r (scale)")
        plt.ylabel("rotation angle (rad)")
        plt.title(f"{fit}: dominant eigenvector rotation")
        plt.tight_layout()
        plt.savefig(f"{OUTDIR}/{fit}_rotation.png")
        plt.close()

    # --------------------------------------------------------
    # Persistence table
    # --------------------------------------------------------

    rows = []
    for fit in FITS:
        p = persistence_length(shell_data[fit], mode=0)
        rows.append({"FIT": fit, "persistence_shells": p})

    df_persist = pd.DataFrame(rows)
    df_persist.to_csv(f"{OUTDIR}/persistence.csv", index=False)

    # --------------------------------------------------------
    # Cross-FIT coherence
    # --------------------------------------------------------

    pairs = [("NUFIT", "BARI"), ("NUFIT", "VALENCIA"), ("BARI", "VALENCIA")]

    for A, B in pairs:
        rvals, ov = cross_fit_overlap(shell_data[A], shell_data[B], mode=0)

        plt.figure()
        plt.plot(rvals, ov, "o-")
        plt.xlabel("r (scale)")
        plt.ylabel("|v·w|")
        plt.title(f"Cross-FIT coherence: {A} vs {B}")
        plt.tight_layout()
        plt.savefig(f"{OUTDIR}/{A}_{B}_coherence.png")
        plt.close()

    print("\n=== metric_003 completed ===")
    print("Outputs written to:", OUTDIR)

if __name__ == "__main__":
    main()
