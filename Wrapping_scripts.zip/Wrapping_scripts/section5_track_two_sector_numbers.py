#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Section 5 two-sector law number tracker for the QEG Physica D manuscript.

Purpose
-------
Build a manuscript-facing audit package for the minimal result table in
Section 5 (Canonical two-sector law), using only the listed Stage-6Q and
Stage-6P v6 evidence files.

Run location
------------
This script is intended to be run from Spyder, from the PhysicaD folder, but
it uses absolute paths so the current working directory is not critical.

Input root
----------
/home/dakini/Downloads/010-Quantum_Emergent_Gravity

Output root
-----------
/home/dakini/Downloads/010-Quantum_Emergent_Gravity/PhysicaD

Important policy
----------------
The script does NOT invent or fit numbers. It inventories columns and rows,
extracts transparent candidates by explicit pattern rules, and flags ambiguous
cases for review. The manuscript draft table is therefore an audit object, not
an authority that silently chooses among conflicting candidates.
"""

from __future__ import annotations

import csv
import json
import math
import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd


# ---------------------------------------------------------------------------
# Fixed paths supplied by the user
# ---------------------------------------------------------------------------
PROJECT_ROOT = Path("/home/dakini/Downloads/010-Quantum_Emergent_Gravity")
PHYSICA_D_ROOT = Path("/home/dakini/Downloads/010-Quantum_Emergent_Gravity/PhysicaD")

OUTPUT_DIR = PHYSICA_D_ROOT / "section5_two_sector_minimal_table_numbers"

INPUT_FILES: Dict[str, str] = {
    # Stage-6Q canonical law extraction
    "6Q_canonical_parameters": "metric_stage_6Q_outputs/canonical_law_extraction_v1/stage6Q_canonical_parameters.csv",
    "6Q_invariant_summary": "metric_stage_6Q_outputs/canonical_law_extraction_v1/stage6Q_invariant_summary.csv",
    "6Q_dimensionless_ratios": "metric_stage_6Q_outputs/canonical_law_extraction_v1/stage6Q_dimensionless_ratios.csv",
    "6Q_transformation_tests": "metric_stage_6Q_outputs/canonical_law_extraction_v1/stage6Q_transformation_tests.csv",
    "6Q_canonical_curve": "metric_stage_6Q_outputs/canonical_law_extraction_v1/stage6Q_canonical_curve.csv",

    # Stage-6P v6 family-universality evidence behind Section 5
    "6P_v6_family_two_lobe_fit_summary": "metric_stage_6P_outputs/two_lobe_universality_test_v6/stage6P_v6_family_two_lobe_fit_summary.csv",
    "6P_v6_family_lobe_parameters": "metric_stage_6P_outputs/two_lobe_universality_test_v6/stage6P_v6_family_lobe_parameters.csv",
    "6P_v6_pairwise_family_parameter_distances": "metric_stage_6P_outputs/two_lobe_universality_test_v6/stage6P_v6_pairwise_family_parameter_distances.csv",
    "6P_v6_candidate_vs_canonical_comparison": "metric_stage_6P_outputs/two_lobe_universality_test_v6/stage6P_v6_candidate_vs_canonical_comparison.csv",
}


# ---------------------------------------------------------------------------
# Concept definitions for the minimal Section-5 table and support notes
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class ConceptSpec:
    concept: str
    quantity: str
    symbol_tex: str
    required_for_table: bool
    row_patterns: Tuple[str, ...]
    column_patterns: Tuple[str, ...]
    preferred_sources: Tuple[str, ...]
    note: str


CONCEPTS: List[ConceptSpec] = [
    ConceptSpec(
        concept="early_sector_center",
        quantity="Early-sector center",
        symbol_tex=r"$\\mu_E$",
        required_for_table=True,
        row_patterns=(
            r"\bmu[_\s\-]*(e|early)\b",
            r"\bearly[_\s\-]*(mu|center|centre)\b",
            r"\bmu[_\s\-]*left\b",
            r"\bearly.*center\b",
            r"\bcenter.*early\b",
        ),
        column_patterns=(
            r"^mu[_\s\-]*(e|early)$",
            r"^early[_\s\-]*(mu|center|centre)$",
            r"^mu[_\s\-]*left$",
            r"early.*center",
        ),
        preferred_sources=("6Q_canonical_parameters", "6Q_invariant_summary", "6P_v6_family_lobe_parameters"),
        note="Manuscript-facing early/boundary lobe location.",
    ),
    ConceptSpec(
        concept="central_sector_center",
        quantity="Central-sector center",
        symbol_tex=r"$\\mu_C$",
        required_for_table=True,
        row_patterns=(
            r"\bmu[_\s\-]*(c|central|bulk)\b",
            r"\bcentral[_\s\-]*(mu|center|centre)\b",
            r"\bbulk[_\s\-]*(mu|center|centre)\b",
            r"\bcenter.*central\b",
        ),
        column_patterns=(
            r"^mu[_\s\-]*(c|central|bulk)$",
            r"^central[_\s\-]*(mu|center|centre)$",
            r"^bulk[_\s\-]*(mu|center|centre)$",
            r"central.*center",
        ),
        preferred_sources=("6Q_canonical_parameters", "6Q_invariant_summary", "6P_v6_family_lobe_parameters"),
        note="Manuscript-facing central/bulk lobe location.",
    ),
    ConceptSpec(
        concept="sector_separation",
        quantity="Sector separation",
        symbol_tex=r"$\\Delta\\mu=\\mu_C-\\mu_E$",
        required_for_table=True,
        row_patterns=(
            r"\b(delta|difference|separation)[_\s\-]*mu\b",
            r"\bmu[_\s\-]*(delta|difference|separation)\b",
            r"\bcentral.*early.*separation\b",
            r"\bearly.*central.*separation\b",
            r"\bsector.*separation\b",
            r"\blobe.*separation\b",
        ),
        column_patterns=(
            r"delta.*mu",
            r"mu.*delta",
            r"sector.*separation",
            r"lobe.*separation",
            r"central.*early.*separation",
        ),
        preferred_sources=("6Q_invariant_summary", "6Q_canonical_parameters", "6Q_dimensionless_ratios"),
        note="Prefer an explicitly reported separation; otherwise compute manually in the manuscript after review.",
    ),
    ConceptSpec(
        concept="early_mass_fraction",
        quantity="Early mass fraction",
        symbol_tex=r"$f_E$",
        required_for_table=True,
        row_patterns=(
            r"\bearly.*mass.*fraction\b",
            r"\bmass.*fraction.*early\b",
            r"\bf[_\s\-]*e\b",
            r"\bearly[_\s\-]*fraction\b",
            r"\bM[_\s\-]*E\s*/",
        ),
        column_patterns=(
            r"early.*mass.*fraction",
            r"mass.*fraction.*early",
            r"^f[_\s\-]*e$",
            r"early.*fraction",
            r"^m[_\s\-]*e[_\s\-]*fraction$",
        ),
        preferred_sources=("6Q_invariant_summary", "6Q_dimensionless_ratios", "6Q_canonical_parameters"),
        note="Normalized early-sector mass, not a fitted cosmological identification.",
    ),
    ConceptSpec(
        concept="central_mass_fraction",
        quantity="Central mass fraction",
        symbol_tex=r"$f_C$",
        required_for_table=True,
        row_patterns=(
            r"\bcentral.*mass.*fraction\b",
            r"\bbulk.*mass.*fraction\b",
            r"\bmass.*fraction.*central\b",
            r"\bmass.*fraction.*bulk\b",
            r"\bf[_\s\-]*c\b",
            r"\bcentral[_\s\-]*fraction\b",
            r"\bM[_\s\-]*C\s*/",
        ),
        column_patterns=(
            r"central.*mass.*fraction",
            r"bulk.*mass.*fraction",
            r"mass.*fraction.*central",
            r"mass.*fraction.*bulk",
            r"^f[_\s\-]*c$",
            r"central.*fraction",
            r"^m[_\s\-]*c[_\s\-]*fraction$",
        ),
        preferred_sources=("6Q_invariant_summary", "6Q_dimensionless_ratios", "6Q_canonical_parameters"),
        note="Normalized central-sector mass, not a fitted cosmological identification.",
    ),
    ConceptSpec(
        concept="width_ratio",
        quantity="Width ratio",
        symbol_tex=r"$r_\\sigma=\\sigma_E/\\sigma_C$",
        required_for_table=True,
        row_patterns=(
            r"\b(width|sigma)[_\s\-]*(ratio|quotient)\b",
            r"\br[_\s\-]*sigma\b",
            r"\bsigma[_\s\-]*e\s*/\s*sigma[_\s\-]*c\b",
            r"\bearly.*central.*width\b",
        ),
        column_patterns=(
            r"width.*ratio",
            r"sigma.*ratio",
            r"^r[_\s\-]*sigma$",
            r"early.*central.*width",
        ),
        preferred_sources=("6Q_dimensionless_ratios", "6Q_invariant_summary", "6Q_canonical_parameters"),
        note="Dimensionless early/central width comparison.",
    ),
    ConceptSpec(
        concept="amplitude_ratio",
        quantity="Amplitude ratio",
        symbol_tex=r"$r_A=A_E/A_C$",
        required_for_table=True,
        row_patterns=(
            r"\b(amplitude|amp)[_\s\-]*(ratio|quotient)\b",
            r"\br[_\s\-]*a\b",
            r"\bA[_\s\-]*E\s*/\s*A[_\s\-]*C\b",
            r"\bearly.*central.*amplitude\b",
        ),
        column_patterns=(
            r"amplitude.*ratio",
            r"amp.*ratio",
            r"^r[_\s\-]*a$",
            r"early.*central.*amplitude",
        ),
        preferred_sources=("6Q_dimensionless_ratios", "6Q_invariant_summary", "6Q_canonical_parameters"),
        note="Dimensionless early/central amplitude comparison.",
    ),
    ConceptSpec(
        concept="family_spread_early_center",
        quantity="Family spread of early center",
        symbol_tex=r"$\\operatorname{spread}(\\mu_E)$",
        required_for_table=False,
        row_patterns=(
            r"spread.*mu.*early",
            r"early.*mu.*spread",
            r"early.*center.*spread",
            r"family.*early.*center",
        ),
        column_patterns=(
            r"spread.*mu.*early",
            r"early.*mu.*spread",
            r"early.*center.*spread",
            r"family.*early.*center",
        ),
        preferred_sources=("6P_v6_family_lobe_parameters", "6P_v6_pairwise_family_parameter_distances", "6Q_invariant_summary"),
        note="Section-6 bridge/support only: early-sector universality diagnostic.",
    ),
    ConceptSpec(
        concept="family_spread_central_center",
        quantity="Family spread of central center",
        symbol_tex=r"$\\operatorname{spread}(\\mu_C)$",
        required_for_table=False,
        row_patterns=(
            r"spread.*mu.*central",
            r"central.*mu.*spread",
            r"central.*center.*spread",
            r"family.*central.*center",
        ),
        column_patterns=(
            r"spread.*mu.*central",
            r"central.*mu.*spread",
            r"central.*center.*spread",
            r"family.*central.*center",
        ),
        preferred_sources=("6P_v6_family_lobe_parameters", "6P_v6_pairwise_family_parameter_distances", "6Q_invariant_summary"),
        note="Section-6 bridge/support only: central-sector universality diagnostic.",
    ),
    ConceptSpec(
        concept="fit_r2",
        quantity="Two-sector fit quality",
        symbol_tex=r"$R^2$",
        required_for_table=False,
        row_patterns=(r"\br\^?2\b", r"\br2\b", r"fit.*quality", r"coefficient.*determination"),
        column_patterns=(r"^r2$", r"r[_\s\-]*squared", r"r\^?2", r"fit.*r2"),
        preferred_sources=("6P_v6_family_two_lobe_fit_summary", "6Q_invariant_summary", "6Q_canonical_parameters"),
        note="Support note only unless you decide to include fit quality in the caption.",
    ),
    ConceptSpec(
        concept="fit_corr",
        quantity="Two-sector correlation",
        symbol_tex=r"$\\mathrm{corr}$",
        required_for_table=False,
        row_patterns=(r"\bcorr(elation)?\b",),
        column_patterns=(r"corr", r"correlation"),
        preferred_sources=("6P_v6_family_two_lobe_fit_summary", "6Q_invariant_summary", "6Q_canonical_parameters"),
        note="Support note only unless you decide to include fit quality in the caption.",
    ),
]

REQUIRED_TABLE_CONCEPTS = [c.concept for c in CONCEPTS if c.required_for_table]
CONCEPT_BY_NAME = {c.concept: c for c in CONCEPTS}

FAMILY_LABELS = ("BARI", "NUFIT", "VALENCIA", "POOLED")
FAMILY_COL_PATTERNS = (
    r"^family$",
    r"^fit$",
    r"^fit_id$",
    r"source.*family",
    r"family.*id",
    r"lineage",
    r"npz.*file",
)

TEXT_ID_COL_PATTERNS = (
    r"parameter",
    r"quantity",
    r"metric",
    r"name",
    r"label",
    r"invariant",
    r"ratio",
    r"symbol",
    r"component",
    r"lobe",
    r"sector",
    r"description",
    r"test",
    r"variant",
    r"family",
    r"fit",
    r"model",
)

VALUE_COL_PATTERNS = (
    r"^value$",
    r"estimate",
    r"mean",
    r"median",
    r"canonical",
    r"best",
    r"score",
    r"ratio",
    r"fraction",
    r"center",
    r"mu",
    r"sigma",
    r"amplitude",
    r"mass",
    r"r2",
    r"corr",
    r"rmse",
    r"distance",
    r"spread",
    r"stability",
    r"similarity",
)

SOURCE_PRIORITY = {
    "6Q_canonical_parameters": 0,
    "6Q_invariant_summary": 1,
    "6Q_dimensionless_ratios": 2,
    "6P_v6_family_lobe_parameters": 3,
    "6P_v6_family_two_lobe_fit_summary": 4,
    "6P_v6_candidate_vs_canonical_comparison": 5,
    "6P_v6_pairwise_family_parameter_distances": 6,
    "6Q_transformation_tests": 7,
    "6Q_canonical_curve": 8,
}


# ---------------------------------------------------------------------------
# Utility functions
# ---------------------------------------------------------------------------
def normalize_text(x: object) -> str:
    if x is None:
        return ""
    s = str(x)
    s = s.replace("\\", " ")
    s = s.replace("$", " ")
    s = re.sub(r"[^0-9A-Za-z_\.\-+/]+", " ", s)
    s = re.sub(r"\s+", " ", s).strip().lower()
    return s


def re_any(patterns: Iterable[str], text: str) -> bool:
    return any(re.search(p, text, flags=re.IGNORECASE) for p in patterns)


def safe_numeric(series: pd.Series) -> pd.Series:
    if pd.api.types.is_numeric_dtype(series):
        return pd.to_numeric(series, errors="coerce")
    cleaned = series.astype(str).str.replace(",", "", regex=False)
    return pd.to_numeric(cleaned, errors="coerce")


def compact_numeric_summary(values: pd.Series, max_unique: int = 12) -> str:
    vals = safe_numeric(values).dropna().to_numpy(dtype=float)
    if vals.size == 0:
        return ""
    finite = vals[np.isfinite(vals)]
    if finite.size == 0:
        return ""
    unique_vals = np.unique(np.round(finite, 12))
    if unique_vals.size <= max_unique:
        return "; ".join(f"{v:.12g}" for v in unique_vals)
    return (
        f"n={finite.size}; min={np.min(finite):.12g}; "
        f"median={np.median(finite):.12g}; max={np.max(finite):.12g}; "
        f"mean={np.mean(finite):.12g}"
    )


def first_nonempty(values: Iterable[object]) -> str:
    for v in values:
        s = str(v).strip()
        if s and s.lower() not in {"nan", "none", "null"}:
            return s
    return ""


def latex_escape(s: object) -> str:
    out = str(s)
    replacements = {
        "\\": r"\textbackslash{}",
        "&": r"\&",
        "%": r"\%",
        "$": r"\$",
        "#": r"\#",
        "_": r"\_",
        "{": r"\{",
        "}": r"\}",
        "~": r"\textasciitilde{}",
        "^": r"\textasciicircum{}",
    }
    for old, new in replacements.items():
        out = out.replace(old, new)
    return out


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def maybe_round_for_distinct(x: float, places: int = 10) -> float:
    if not np.isfinite(x):
        return np.nan
    return round(float(x), places)


def extract_family_value(row: pd.Series, family_cols: List[str]) -> str:
    joined = " ".join(str(row.get(c, "")) for c in family_cols)
    hits = [fam for fam in FAMILY_LABELS if re.search(rf"\b{fam}\b", joined, re.IGNORECASE)]
    return ";".join(dict.fromkeys(hits))


# ---------------------------------------------------------------------------
# Read and inventory inputs
# ---------------------------------------------------------------------------
def resolve_inputs() -> pd.DataFrame:
    rows = []
    for label, rel in INPUT_FILES.items():
        path = PROJECT_ROOT / rel
        rows.append({
            "source_label": label,
            "relative_path": rel,
            "absolute_path": str(path),
            "exists": path.exists(),
            "size_bytes": path.stat().st_size if path.exists() else None,
        })
    return pd.DataFrame(rows)


def read_inputs(input_report: pd.DataFrame) -> Dict[str, pd.DataFrame]:
    data: Dict[str, pd.DataFrame] = {}
    for _, row in input_report.iterrows():
        if not bool(row["exists"]):
            continue
        label = row["source_label"]
        path = Path(row["absolute_path"])
        try:
            df = pd.read_csv(path)
            df["__source_label"] = label
            df["__relative_path"] = row["relative_path"]
            df["__row_index"] = np.arange(len(df))
            data[label] = df
        except Exception as exc:  # fail-loud in report, not in run
            data[label] = pd.DataFrame({
                "__source_label": [label],
                "__relative_path": [row["relative_path"]],
                "__row_index": [0],
                "__read_error": [repr(exc)],
            })
    return data


def build_column_inventory(data: Dict[str, pd.DataFrame]) -> pd.DataFrame:
    rows = []
    for label, df in data.items():
        rel = first_nonempty(df.get("__relative_path", pd.Series([INPUT_FILES.get(label, "")])).head(1))
        for col in df.columns:
            if col.startswith("__"):
                continue
            numeric = safe_numeric(df[col])
            nonnull = df[col].notna().sum()
            numeric_nonnull = numeric.notna().sum()
            rows.append({
                "source_label": label,
                "relative_path": rel,
                "column": col,
                "normalized_column": normalize_text(col),
                "dtype": str(df[col].dtype),
                "rows": len(df),
                "nonnull": int(nonnull),
                "numeric_nonnull": int(numeric_nonnull),
                "numeric_summary": compact_numeric_summary(df[col]),
                "example_values": "; ".join(map(str, df[col].dropna().astype(str).head(5).tolist())),
            })
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# Candidate extraction
# ---------------------------------------------------------------------------
def find_text_id_columns(df: pd.DataFrame) -> List[str]:
    cols = []
    for col in df.columns:
        if col.startswith("__"):
            continue
        ncol = normalize_text(col)
        if re_any(TEXT_ID_COL_PATTERNS, ncol):
            cols.append(col)
    # If no obvious ID columns exist, use all nonnumeric columns as text context.
    if not cols:
        for col in df.columns:
            if col.startswith("__"):
                continue
            numeric_nonnull = safe_numeric(df[col]).notna().sum()
            nonnull = df[col].notna().sum()
            if nonnull > 0 and numeric_nonnull < max(1, nonnull // 2):
                cols.append(col)
    return cols


def find_family_columns(df: pd.DataFrame) -> List[str]:
    cols = []
    for col in df.columns:
        if col.startswith("__"):
            continue
        ncol = normalize_text(col)
        if re_any(FAMILY_COL_PATTERNS, ncol):
            cols.append(col)
            continue
        values = " ".join(df[col].dropna().astype(str).head(100).tolist())
        if any(re.search(rf"\b{fam}\b", values, flags=re.IGNORECASE) for fam in FAMILY_LABELS):
            cols.append(col)
    return list(dict.fromkeys(cols))


def find_value_columns(df: pd.DataFrame) -> List[str]:
    cols = []
    for col in df.columns:
        if col.startswith("__"):
            continue
        ncol = normalize_text(col)
        numeric_nonnull = safe_numeric(df[col]).notna().sum()
        if numeric_nonnull == 0:
            continue
        if re_any(VALUE_COL_PATTERNS, ncol) or numeric_nonnull > 0:
            cols.append(col)
    return cols


def extract_column_level_candidates(data: Dict[str, pd.DataFrame]) -> List[Dict[str, object]]:
    out: List[Dict[str, object]] = []
    for label, df in data.items():
        rel = first_nonempty(df.get("__relative_path", pd.Series([INPUT_FILES.get(label, "")])).head(1))
        family_cols = find_family_columns(df)
        for col in df.columns:
            if col.startswith("__"):
                continue
            ncol = normalize_text(col)
            numeric = safe_numeric(df[col])
            if numeric.notna().sum() == 0:
                continue
            for spec in CONCEPTS:
                if re_any(spec.column_patterns, ncol):
                    out.append({
                        "extraction_level": "column",
                        "concept": spec.concept,
                        "quantity": spec.quantity,
                        "symbol_tex": spec.symbol_tex,
                        "required_for_table": spec.required_for_table,
                        "source_label": label,
                        "relative_path": rel,
                        "row_index": "ALL",
                        "matched_text": col,
                        "matched_column": col,
                        "value_column": col,
                        "family_columns": ";".join(family_cols),
                        "family_hit": "",
                        "numeric_count": int(numeric.notna().sum()),
                        "numeric_summary": compact_numeric_summary(df[col]),
                        "min": numeric.min(skipna=True),
                        "median": numeric.median(skipna=True),
                        "max": numeric.max(skipna=True),
                        "mean": numeric.mean(skipna=True),
                        "note": spec.note,
                    })
    return out


def extract_row_level_candidates(data: Dict[str, pd.DataFrame]) -> List[Dict[str, object]]:
    out: List[Dict[str, object]] = []
    for label, df in data.items():
        rel = first_nonempty(df.get("__relative_path", pd.Series([INPUT_FILES.get(label, "")])).head(1))
        text_cols = find_text_id_columns(df)
        value_cols = find_value_columns(df)
        family_cols = find_family_columns(df)
        if not value_cols:
            continue
        for idx, row in df.iterrows():
            row_text = " | ".join(str(row.get(c, "")) for c in text_cols)
            nrow_text = normalize_text(row_text)
            if not nrow_text:
                continue
            family_hit = extract_family_value(row, family_cols)
            for spec in CONCEPTS:
                if not re_any(spec.row_patterns, nrow_text):
                    continue
                # For a row-level concept hit, report all numeric value-like columns.
                for vcol in value_cols:
                    val = safe_numeric(pd.Series([row.get(vcol)])).iloc[0]
                    if pd.isna(val):
                        continue
                    out.append({
                        "extraction_level": "row",
                        "concept": spec.concept,
                        "quantity": spec.quantity,
                        "symbol_tex": spec.symbol_tex,
                        "required_for_table": spec.required_for_table,
                        "source_label": label,
                        "relative_path": rel,
                        "row_index": int(row.get("__row_index", idx)),
                        "matched_text": row_text,
                        "matched_column": " | ".join(text_cols),
                        "value_column": vcol,
                        "family_columns": ";".join(family_cols),
                        "family_hit": family_hit,
                        "numeric_count": 1,
                        "numeric_summary": f"{float(val):.12g}",
                        "min": float(val),
                        "median": float(val),
                        "max": float(val),
                        "mean": float(val),
                        "note": spec.note,
                    })
    return out


def build_candidate_table(data: Dict[str, pd.DataFrame]) -> pd.DataFrame:
    rows = extract_column_level_candidates(data) + extract_row_level_candidates(data)
    if not rows:
        return pd.DataFrame(columns=[
            "extraction_level", "concept", "quantity", "symbol_tex", "required_for_table",
            "source_label", "relative_path", "row_index", "matched_text",
            "matched_column", "value_column", "family_columns", "family_hit",
            "numeric_count", "numeric_summary", "min", "median", "max", "mean", "note",
        ])
    cand = pd.DataFrame(rows)
    cand["source_priority"] = cand["source_label"].map(SOURCE_PRIORITY).fillna(999).astype(int)
    cand = cand.sort_values([
        "required_for_table", "concept", "source_priority", "source_label",
        "extraction_level", "row_index", "value_column",
    ], ascending=[False, True, True, True, True, True, True]).reset_index(drop=True)
    return cand


# ---------------------------------------------------------------------------
# Draft minimal result table construction
# ---------------------------------------------------------------------------
def concept_source_priority(spec: ConceptSpec, source_label: str) -> int:
    if source_label in spec.preferred_sources:
        return spec.preferred_sources.index(source_label)
    return 100 + SOURCE_PRIORITY.get(source_label, 999)


def choose_for_concept(cand: pd.DataFrame, spec: ConceptSpec) -> Dict[str, object]:
    sub = cand[cand["concept"] == spec.concept].copy()
    if sub.empty:
        return {
            "quantity": spec.quantity,
            "symbol_tex": spec.symbol_tex,
            "concept": spec.concept,
            "status": "MISSING",
            "manuscript_value": "",
            "candidate_summary": "No candidate found in listed files.",
            "source_label": "",
            "relative_path": "",
            "source_detail": "",
            "note": spec.note,
        }

    sub["concept_source_priority"] = sub["source_label"].apply(lambda s: concept_source_priority(spec, s))
    sub = sub.sort_values([
        "concept_source_priority", "source_priority", "extraction_level", "source_label", "row_index", "value_column"
    ]).copy()

    # Prefer the best source tier only, but do not silently choose if multiple non-identical values remain.
    best_priority = int(sub["concept_source_priority"].min())
    best = sub[sub["concept_source_priority"] == best_priority].copy()

    # Build distinct values from the mean/median/min/max summaries. For row-level, min=median=max.
    values = []
    for _, r in best.iterrows():
        val = r.get("median", np.nan)
        if pd.notna(val) and np.isfinite(float(val)):
            values.append(maybe_round_for_distinct(float(val)))
    distinct = sorted(set(v for v in values if pd.notna(v)))

    source_labels = sorted(best["source_label"].dropna().astype(str).unique().tolist())
    rels = sorted(best["relative_path"].dropna().astype(str).unique().tolist())
    detail_parts = []
    for _, r in best.head(12).iterrows():
        detail_parts.append(
            f"{r['source_label']} :: {r['value_column']} :: {r['numeric_summary']}"
        )
    if len(best) > 12:
        detail_parts.append(f"... plus {len(best) - 12} more best-tier candidates")

    if len(distinct) == 1:
        status = "OK_UNIQUE_AT_BEST_PRIORITY"
        manuscript_value = f"{distinct[0]:.12g}"
    elif len(distinct) > 1:
        status = "REVIEW_MULTIPLE_BEST_PRIORITY_VALUES"
        manuscript_value = "REVIEW"
    else:
        status = "REVIEW_NONNUMERIC_OR_EMPTY_BEST_PRIORITY"
        manuscript_value = "REVIEW"

    return {
        "quantity": spec.quantity,
        "symbol_tex": spec.symbol_tex,
        "concept": spec.concept,
        "status": status,
        "manuscript_value": manuscript_value,
        "candidate_summary": "; ".join(detail_parts),
        "source_label": ";".join(source_labels),
        "relative_path": ";".join(rels),
        "source_detail": " | ".join(detail_parts),
        "note": spec.note,
    }


def build_minimal_table_draft(cand: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for concept in REQUIRED_TABLE_CONCEPTS:
        rows.append(choose_for_concept(cand, CONCEPT_BY_NAME[concept]))
    rows.append({
        "quantity": "Invariant status",
        "symbol_tex": "--",
        "concept": "invariant_status",
        "status": "MANUAL_TEXT",
        "manuscript_value": "early hard; central soft/review as supported by Stage-6P/6Q",
        "candidate_summary": "This is a manuscript interpretation tag, not a scalar extracted from a CSV.",
        "source_label": "6P_v6_family_lobe_parameters;6Q_invariant_summary",
        "relative_path": "",
        "source_detail": "Use after checking extracted family/canonical rows.",
        "note": "Keep this qualitative unless the Stage-6Q file has an explicit invariant tag column.",
    })
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# Support summaries: family universality, transformation tests, curve columns
# ---------------------------------------------------------------------------
def build_family_support_summary(data: Dict[str, pd.DataFrame]) -> pd.DataFrame:
    rows: List[Dict[str, object]] = []
    support_sources = [
        "6P_v6_family_two_lobe_fit_summary",
        "6P_v6_family_lobe_parameters",
        "6P_v6_pairwise_family_parameter_distances",
        "6P_v6_candidate_vs_canonical_comparison",
    ]
    for label in support_sources:
        df = data.get(label)
        if df is None or df.empty:
            rows.append({
                "source_label": label,
                "status": "MISSING_OR_EMPTY",
                "relative_path": INPUT_FILES.get(label, ""),
                "rows": 0,
                "family_columns": "",
                "family_values_detected": "",
                "numeric_columns": "",
                "numeric_summary": "",
            })
            continue
        rel = first_nonempty(df.get("__relative_path", pd.Series([INPUT_FILES.get(label, "")])).head(1))
        family_cols = find_family_columns(df)
        value_cols = find_value_columns(df)
        family_values: List[str] = []
        for col in family_cols:
            text = " ".join(df[col].dropna().astype(str).tolist())
            for fam in FAMILY_LABELS:
                if re.search(rf"\b{fam}\b", text, flags=re.IGNORECASE):
                    family_values.append(fam)
        family_values = list(dict.fromkeys(family_values))
        numeric_parts = []
        for col in value_cols[:30]:
            numeric_parts.append(f"{col}: {compact_numeric_summary(df[col])}")
        rows.append({
            "source_label": label,
            "status": "READ",
            "relative_path": rel,
            "rows": len(df),
            "family_columns": ";".join(family_cols),
            "family_values_detected": ";".join(family_values),
            "numeric_columns": ";".join(value_cols),
            "numeric_summary": " | ".join(numeric_parts),
        })
    return pd.DataFrame(rows)


def build_transformation_support_summary(data: Dict[str, pd.DataFrame]) -> pd.DataFrame:
    label = "6Q_transformation_tests"
    df = data.get(label)
    if df is None or df.empty:
        return pd.DataFrame([{
            "source_label": label,
            "status": "MISSING_OR_EMPTY",
            "relative_path": INPUT_FILES.get(label, ""),
            "rows": 0,
            "text_columns": "",
            "numeric_columns": "",
            "numeric_summary": "",
        }])
    rel = first_nonempty(df.get("__relative_path", pd.Series([INPUT_FILES.get(label, "")])).head(1))
    text_cols = find_text_id_columns(df)
    value_cols = find_value_columns(df)
    parts = []
    for col in value_cols[:40]:
        parts.append(f"{col}: {compact_numeric_summary(df[col])}")
    return pd.DataFrame([{
        "source_label": label,
        "status": "READ",
        "relative_path": rel,
        "rows": len(df),
        "text_columns": ";".join(text_cols),
        "numeric_columns": ";".join(value_cols),
        "numeric_summary": " | ".join(parts),
    }])


def build_curve_support_summary(data: Dict[str, pd.DataFrame]) -> pd.DataFrame:
    label = "6Q_canonical_curve"
    df = data.get(label)
    if df is None or df.empty:
        return pd.DataFrame([{
            "source_label": label,
            "status": "MISSING_OR_EMPTY",
            "relative_path": INPUT_FILES.get(label, ""),
            "rows": 0,
            "columns": "",
            "numeric_summary": "",
        }])
    rel = first_nonempty(df.get("__relative_path", pd.Series([INPUT_FILES.get(label, "")])).head(1))
    value_cols = find_value_columns(df)
    parts = []
    for col in value_cols[:50]:
        parts.append(f"{col}: {compact_numeric_summary(df[col])}")
    return pd.DataFrame([{
        "source_label": label,
        "status": "READ",
        "relative_path": rel,
        "rows": len(df),
        "columns": ";".join([c for c in df.columns if not c.startswith("__")]),
        "numeric_summary": " | ".join(parts),
    }])


# ---------------------------------------------------------------------------
# LaTeX draft
# ---------------------------------------------------------------------------
def build_latex_table(table: pd.DataFrame) -> str:
    lines = []
    lines.append(r"% Auto-generated by section5_track_two_sector_numbers.py")
    lines.append(r"% Review all rows marked REVIEW before using in the manuscript.")
    lines.append(r"\begin{table*}[t]")
    lines.append(r"\centering")
    lines.append(r"\small")
    lines.append(r"\caption{Canonical two-sector law: minimal manuscript-facing invariants. Values marked REVIEW require manual adjudication from the accompanying candidate audit table; no values are invented by the extraction script.}")
    lines.append(r"\label{tab:section5-canonical-two-sector-law}")
    lines.append(r"\begin{tabular}{p{0.26\textwidth} c p{0.20\textwidth} p{0.38\textwidth}}")
    lines.append(r"\hline")
    lines.append(r"Quantity & Symbol & Manuscript value & Source/status \\")
    lines.append(r"\hline")
    for _, row in table.iterrows():
        quantity = latex_escape(row["quantity"])
        symbol = str(row["symbol_tex"])
        value = latex_escape(row["manuscript_value"])
        status = latex_escape(row["status"])
        src = latex_escape(row["source_label"])
        lines.append(f"{quantity} & {symbol} & {value} & {status}; {src} \\")
    lines.append(r"\hline")
    lines.append(r"\end{tabular}")
    lines.append(r"\end{table*}")
    lines.append("")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Main execution
# ---------------------------------------------------------------------------
def main() -> None:
    started = datetime.now()
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    input_report = resolve_inputs()
    data = read_inputs(input_report)
    column_inventory = build_column_inventory(data)
    candidates = build_candidate_table(data)
    minimal_table = build_minimal_table_draft(candidates)
    family_support = build_family_support_summary(data)
    transform_support = build_transformation_support_summary(data)
    curve_support = build_curve_support_summary(data)

    # Write CSV outputs.
    input_report.to_csv(OUTPUT_DIR / "section5_input_presence_report.csv", index=False)
    column_inventory.to_csv(OUTPUT_DIR / "section5_input_column_inventory.csv", index=False)
    candidates.to_csv(OUTPUT_DIR / "section5_candidate_numbers_long.csv", index=False)
    minimal_table.to_csv(OUTPUT_DIR / "section5_minimal_result_table_draft.csv", index=False)
    family_support.to_csv(OUTPUT_DIR / "section5_family_universality_support_summary.csv", index=False)
    transform_support.to_csv(OUTPUT_DIR / "section5_transformation_support_summary.csv", index=False)
    curve_support.to_csv(OUTPUT_DIR / "section5_canonical_curve_support_summary.csv", index=False)

    # Write LaTeX snippet.
    latex = build_latex_table(minimal_table)
    write_text(OUTPUT_DIR / "section5_minimal_result_table_draft.tex", latex)

    # Write machine-readable run summary.
    finished = datetime.now()
    summary = {
        "script": Path(__file__).name,
        "started_local": started.isoformat(timespec="seconds"),
        "finished_local": finished.isoformat(timespec="seconds"),
        "project_root": str(PROJECT_ROOT),
        "physica_d_root": str(PHYSICA_D_ROOT),
        "output_dir": str(OUTPUT_DIR),
        "input_files_requested": len(INPUT_FILES),
        "input_files_found": int(input_report["exists"].sum()),
        "input_files_missing": input_report.loc[~input_report["exists"], "relative_path"].tolist(),
        "candidate_rows": int(len(candidates)),
        "minimal_table_rows": int(len(minimal_table)),
        "minimal_table_status_counts": minimal_table["status"].value_counts(dropna=False).to_dict(),
        "policy": "No values invented; REVIEW rows require manual adjudication using section5_candidate_numbers_long.csv.",
    }
    write_text(OUTPUT_DIR / "section5_run_summary.json", json.dumps(summary, indent=2))

    ledger_lines = [
        "============================================================",
        "SECTION 5 TWO-SECTOR LAW NUMBER TRACKER",
        "============================================================",
        f"Started:  {summary['started_local']}",
        f"Finished: {summary['finished_local']}",
        "",
        f"Project root:   {PROJECT_ROOT}",
        f"PhysicaD root:  {PHYSICA_D_ROOT}",
        f"Output folder:  {OUTPUT_DIR}",
        "",
        f"Input files requested: {summary['input_files_requested']}",
        f"Input files found:     {summary['input_files_found']}",
        f"Candidate rows:         {summary['candidate_rows']}",
        "",
        "Outputs written:",
        "  - section5_input_presence_report.csv",
        "  - section5_input_column_inventory.csv",
        "  - section5_candidate_numbers_long.csv",
        "  - section5_minimal_result_table_draft.csv",
        "  - section5_minimal_result_table_draft.tex",
        "  - section5_family_universality_support_summary.csv",
        "  - section5_transformation_support_summary.csv",
        "  - section5_canonical_curve_support_summary.csv",
        "  - section5_run_summary.json",
        "",
        "Policy:",
        "  No scalar is invented or silently fitted by this script.",
        "  Rows marked REVIEW in the draft table require manual selection from",
        "  section5_candidate_numbers_long.csv and the original listed evidence files.",
        "",
        "Minimal table status counts:",
    ]
    for k, v in summary["minimal_table_status_counts"].items():
        ledger_lines.append(f"  {k}: {v}")
    if summary["input_files_missing"]:
        ledger_lines.extend(["", "Missing listed files:"])
        for rel in summary["input_files_missing"]:
            ledger_lines.append(f"  - {rel}")
    write_text(OUTPUT_DIR / "section5_run_ledger.txt", "\n".join(ledger_lines) + "\n")

    print("============================================================")
    print("SECTION 5 TWO-SECTOR LAW NUMBER TRACKER COMPLETE")
    print("============================================================")
    print(f"Output folder: {OUTPUT_DIR}")
    print(f"Input files found: {summary['input_files_found']} / {summary['input_files_requested']}")
    print(f"Candidate rows: {summary['candidate_rows']}")
    print("Draft table status counts:")
    for k, v in summary["minimal_table_status_counts"].items():
        print(f"  {k}: {v}")
    print("Review files before pasting the LaTeX table into Section 5.")


if __name__ == "__main__":
    main()
