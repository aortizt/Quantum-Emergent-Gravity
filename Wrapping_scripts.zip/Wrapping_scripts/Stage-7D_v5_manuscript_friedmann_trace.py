#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Stage-7D v5: Manuscript Friedmann Trace
Project: Quantum-Emergent Gravity
Purpose:
    Consolidate and verify the existing Stage-7D v2/v3/v4 Friedmann,
    Lambda-closure, and acceleration-proxy outputs for manuscript use.

This script performs NO new candidate search and NO physical promotion.
It traces the already frozen canonical corridor through:

    v2 age corridor
      -> v3 Lambda-like closure
      -> v4 q0/z_acc bookkeeping

Primary outputs:
    metric_stage_7D_outputs/friedmann_manuscript_trace_v5/
        stage7D_v5_friedmann_manuscript_trace.csv
        stage7D_v5_friedmann_manuscript_trace.json
        stage7D_v5_friedmann_manuscript_table.tex
        stage7D_v5_friedmann_trace_report.txt

Spyder:
    %runfile /path/to/Stage-7D_v5_manuscript_friedmann_trace.py --wdir

Terminal:
    python3 Stage-7D_v5_manuscript_friedmann_trace.py \
        /home/dakini/Downloads/010-Quantum_Emergent_Gravity
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd

SCRIPT = "Stage-7D_v5_manuscript_friedmann_trace.py"
STAGE = "Stage-7D v5"

LOCKED = {
    "Omega_m": 0.315,
    "Omega_Lambda": 0.685,
    "Omega_K": 0.0007,
    "h": 0.674,
    "H0_km_s_Mpc": 67.4,
    "age_Gyr": 13.797,
}

EXPECTED_FILES = {
    "v2_corridor": "stage7D_v2_age_corridor_table.csv",
    "v2_summary": "stage7D_v2_summary.json",
    "v3_corridor": "stage7D_v3_dark_energy_closure_corridor_table.csv",
    "v3_summary": "stage7D_v3_dark_energy_lambda_summary.json",
    "v4_corridor": "stage7D_v4_acceleration_proxy_corridor_table.csv",
    "v4_summary": "stage7D_v4_acceleration_proxy_summary.json",
}

HUBBLE_TIME_GYR_FACTOR = 9.777752


def infer_root(arg: Optional[str]) -> Path:
    if arg:
        return Path(arg).expanduser().resolve()
    cwd = Path.cwd().resolve()
    if (cwd / "metric_stage_7D_outputs").exists():
        return cwd
    known = Path("/home/dakini/Downloads/010-Quantum_Emergent_Gravity")
    if known.exists():
        return known.resolve()
    return cwd


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def safe_float(value: Any, default: float = math.nan) -> float:
    try:
        if value is None:
            return default
        out = float(value)
        return out if math.isfinite(out) else default
    except Exception:
        return default


def pct_difference(value: float, reference: float) -> float:
    if not math.isfinite(value) or not math.isfinite(reference) or reference == 0:
        return math.nan
    return abs(value - reference) / abs(reference) * 100.0


def friedmann_age_late_time(omega_m: float, omega_lambda: float, omega_k: float, h: float) -> float:
    """Exact numerical counterpart of the Stage-7D v2 polishing integral."""
    a = np.linspace(1.0e-5, 1.0, 20000)
    e2 = omega_m / a**3 + omega_k / a**2 + omega_lambda
    if np.any(~np.isfinite(e2)) or np.any(e2 <= 0):
        return math.nan
    integral = float(np.trapezoid(1.0 / (a * np.sqrt(e2)), a))
    return HUBBLE_TIME_GYR_FACTOR / h * integral


def q0_proxy(omega_m: float, omega_lambda: float) -> float:
    return 0.5 * omega_m - omega_lambda


def z_acc_proxy(omega_m: float, omega_lambda: float) -> float:
    if omega_m <= 0 or omega_lambda <= 0:
        return math.nan
    return (2.0 * omega_lambda / omega_m) ** (1.0 / 3.0) - 1.0


def recursive_find(root: Path, filename: str) -> List[Path]:
    """Find all exact-name matches, preferring Stage-7D and curated-output trees."""
    matches = []
    for p in root.rglob(filename):
        if ".git" in p.parts or "__pycache__" in p.parts:
            continue
        matches.append(p.resolve())

    def score(p: Path) -> Tuple[int, int, str]:
        s = str(p).lower()
        priority = 0
        if "20_curated_outputs" in s:
            priority += 4
        if "stage-7d" in s or "stage_7d" in s or "stage7d" in s:
            priority += 3
        if "metric_stage_7d_outputs" in s:
            priority += 2
        if "friedmann" in s or "dark_energy" in s or "acceleration" in s:
            priority += 1
        return (-priority, len(p.parts), str(p))

    return sorted(matches, key=score)


def resolve_inputs(root: Path) -> Tuple[Dict[str, Path], Dict[str, List[str]]]:
    resolved: Dict[str, Path] = {}
    alternatives: Dict[str, List[str]] = {}
    for key, filename in EXPECTED_FILES.items():
        matches = recursive_find(root, filename)
        if not matches:
            continue
        resolved[key] = matches[0]
        alternatives[key] = [str(p) for p in matches]
    return resolved, alternatives


def select_stable_row(df: pd.DataFrame) -> pd.Series:
    if df.empty:
        raise ValueError("Corridor table is empty.")
    if "corridor_label" in df.columns:
        mask = df["corridor_label"].astype(str).str.contains(
            "meaningful_stable_anchor", case=False, na=False
        )
        if mask.any():
            return df.loc[mask].iloc[0]
    return df.iloc[0]


def read_json(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def almost_equal(a: float, b: float, atol: float = 5e-7, rtol: float = 5e-6) -> bool:
    if not (math.isfinite(a) and math.isfinite(b)):
        return False
    return abs(a - b) <= atol + rtol * abs(b)


def latex_escape(text: str) -> str:
    replacements = {
        "\\": r"\textbackslash{}",
        "_": r"\_",
        "%": r"\%",
        "&": r"\&",
        "#": r"\#",
        "{": r"\{",
        "}": r"\}",
    }
    out = str(text)
    for old, new in replacements.items():
        out = out.replace(old, new)
    return out


def build_latex_table(rows: pd.DataFrame) -> str:
    lookup = {r["quantity_key"]: r for _, r in rows.iterrows()}
    ordered = ["Omega_m", "Omega_K", "Omega_Lambda", "age_Gyr", "q0", "z_acc"]
    body = []
    labels = {
        "Omega_m": r"Matter-like anchor $\Omega_m$",
        "Omega_K": r"Curvature-like anchor $\Omega_K$",
        "Omega_Lambda": r"Lambda-like closure $\Omega_\Lambda$",
        "age_Gyr": r"Formal age $t_0$",
        "q0": r"Deceleration proxy $q_0$",
        "z_acc": r"Transition proxy $z_{\mathrm{acc}}$",
    }
    for key in ordered:
        r = lookup[key]
        if key == "age_Gyr":
            qeg = f"{r['qeg_like_value']:.5f}\\,\\mathrm{{Gyr}}"
            ref = f"{r['locked_reference']:.3f}\\,\\mathrm{{Gyr}}"
        else:
            qeg = f"{r['qeg_like_value']:.6g}"
            ref = f"{r['locked_reference']:.6g}"
        sep = (
            f"{r['relative_difference_pct']:.3f}\\%"
            if math.isfinite(r["relative_difference_pct"])
            else f"{r['absolute_difference']:.6g} absolute"
        )
        body.append(
            f"{labels[key]} & \\({qeg}\\) & \\({ref}\\) & {sep} & "
            f"{latex_escape(r['dependency_status'])} \\\\"  # noqa: W605
        )

    return """% Auto-generated by Stage-7D_v5_manuscript_friedmann_trace.py
\\begin{table*}[t]
\\centering
\\scriptsize
\\setlength{\\tabcolsep}{4pt}
\\caption{Verified manuscript trace of the canonical Friedmann/GR-adjacent
bookkeeping corridor.  Downstream quantities share the same two anchors and
must not be counted as independent predictions.}
\\label{tab:appendix-friedmann-corridor-traced}
\\begin{tabular}{p{0.20\\textwidth} p{0.14\\textwidth} p{0.14\\textwidth}
                p{0.15\\textwidth} p{0.27\\textwidth}}
\\hline
Quantity & QEG-like value & Locked reference & Separation & Dependency status \\\\
\\hline
""" + "\n".join(body) + """
\\hline
\\end{tabular}
\\end{table*}
"""


def main() -> None:
    parser = argparse.ArgumentParser(description="Trace Stage-7D Friedmann outputs into a manuscript table.")
    parser.add_argument("project_root", nargs="?", default=None)
    parser.add_argument("--output-dir", default=None)
    args = parser.parse_args()

    root = infer_root(args.project_root)
    out_dir = (
        Path(args.output_dir).expanduser().resolve()
        if args.output_dir
        else root / "metric_stage_7D_outputs" / "friedmann_manuscript_trace_v5"
    )
    out_dir.mkdir(parents=True, exist_ok=True)

    resolved, alternatives = resolve_inputs(root)
    required = ["v2_corridor", "v3_corridor", "v4_corridor"]
    missing = [key for key in required if key not in resolved]
    if missing:
        expected = ", ".join(EXPECTED_FILES[k] for k in missing)
        raise FileNotFoundError(
            f"Missing required Stage-7D corridor files under {root}: {expected}"
        )

    v2 = pd.read_csv(resolved["v2_corridor"])
    v3 = pd.read_csv(resolved["v3_corridor"])
    v4 = pd.read_csv(resolved["v4_corridor"])
    r2 = select_stable_row(v2)
    r3 = select_stable_row(v3)
    r4 = select_stable_row(v4)

    om = safe_float(r2.get("omega_m_like_anchor"))
    ok = safe_float(r2.get("omega_k_like_anchor"))
    ol = safe_float(r2.get("omega_lambda_like_closure"))
    ol_recomputed = 1.0 - om - ok
    age = friedmann_age_late_time(om, ol_recomputed, ok, LOCKED["h"])
    q0 = q0_proxy(om, ol_recomputed)
    zacc = z_acc_proxy(om, ol_recomputed)

    q0_ref = q0_proxy(LOCKED["Omega_m"], LOCKED["Omega_Lambda"])
    zacc_ref = z_acc_proxy(LOCKED["Omega_m"], LOCKED["Omega_Lambda"])

    rows = pd.DataFrame([
        {
            "quantity_key": "Omega_m",
            "qeg_like_value": om,
            "locked_reference": LOCKED["Omega_m"],
            "absolute_difference": abs(om - LOCKED["Omega_m"]),
            "relative_difference_pct": pct_difference(om, LOCKED["Omega_m"]),
            "dependency_status": "Internally frozen comparator; physical identification not established.",
        },
        {
            "quantity_key": "Omega_K",
            "qeg_like_value": ok,
            "locked_reference": LOCKED["Omega_K"],
            "absolute_difference": abs(ok - LOCKED["Omega_K"]),
            "relative_difference_pct": math.nan,
            "dependency_status": "Internally preserved correction; percentage comparison is ill-conditioned near zero.",
        },
        {
            "quantity_key": "Omega_Lambda",
            "qeg_like_value": ol_recomputed,
            "locked_reference": LOCKED["Omega_Lambda"],
            "absolute_difference": abs(ol_recomputed - LOCKED["Omega_Lambda"]),
            "relative_difference_pct": pct_difference(ol_recomputed, LOCKED["Omega_Lambda"]),
            "dependency_status": "Algebraically induced by closure; not independent evidence.",
        },
        {
            "quantity_key": "age_Gyr",
            "qeg_like_value": age,
            "locked_reference": LOCKED["age_Gyr"],
            "absolute_difference": abs(age - LOCKED["age_Gyr"]),
            "relative_difference_pct": pct_difference(age, LOCKED["age_Gyr"]),
            "dependency_status": "Derived from the locked Hubble scale, the imported Friedmann form, and the closure corridor.",
        },
        {
            "quantity_key": "q0",
            "qeg_like_value": q0,
            "locked_reference": q0_ref,
            "absolute_difference": abs(q0 - q0_ref),
            "relative_difference_pct": pct_difference(q0, q0_ref),
            "dependency_status": "Derived from the same matter and Lambda-like closure terms.",
        },
        {
            "quantity_key": "z_acc",
            "qeg_like_value": zacc,
            "locked_reference": zacc_ref,
            "absolute_difference": abs(zacc - zacc_ref),
            "relative_difference_pct": pct_difference(zacc, zacc_ref),
            "dependency_status": "Derived from the same two-term late-time model.",
        },
    ])

    checks = {
        "v2_lambda_equals_recomputed_closure": almost_equal(ol, ol_recomputed),
        "v3_omega_m_matches_v2": almost_equal(safe_float(r3.get("omega_m_like_anchor")), om),
        "v3_omega_k_matches_v2": almost_equal(safe_float(r3.get("omega_k_like_anchor")), ok),
        "v3_lambda_matches_recomputed": almost_equal(safe_float(r3.get("omega_lambda_like_closure")), ol_recomputed),
        "v4_omega_m_matches_v2": almost_equal(safe_float(r4.get("omega_m_like_anchor")), om),
        "v4_omega_k_matches_v2": almost_equal(safe_float(r4.get("omega_k_like_anchor")), ok),
        "v4_lambda_matches_recomputed": almost_equal(safe_float(r4.get("omega_lambda_like_closure")), ol_recomputed),
        "v4_q0_matches_recomputed": almost_equal(safe_float(r4.get("q0_like_proxy")), q0),
        "v4_z_acc_matches_recomputed": almost_equal(safe_float(r4.get("z_acc_like_proxy")), zacc),
    }

    source_records = []
    for key, path in resolved.items():
        source_records.append({
            "role": key,
            "path": str(path),
            "sha256": sha256(path),
            "all_matches": alternatives.get(key, []),
        })

    verdict = (
        "TRACE_VERIFIED_APPENDIX_ONLY"
        if all(checks.values())
        else "TRACE_MISMATCH_REVIEW_REQUIRED"
    )

    summary = {
        "project": "Quantum-Emergent Gravity",
        "stage": STAGE,
        "script": SCRIPT,
        "verdict": verdict,
        "policy": {
            "new_candidate_search": False,
            "physical_promotion": False,
            "friedmann_derivation_claim": False,
            "age_prediction_claim": False,
            "lambda_independent_prediction_claim": False,
            "acceleration_derivation_claim": False,
        },
        "locked_references": LOCKED,
        "canonical_corridor": {
            "Omega_m_like": om,
            "Omega_K_like": ok,
            "Omega_Lambda_closure": ol_recomputed,
            "age_Gyr": age,
            "q0_like": q0,
            "z_acc_like": zacc,
        },
        "cross_stage_checks": checks,
        "sources": source_records,
        "interpretation": (
            "The v2/v3/v4 corridor is internally consistent. Omega_Lambda, age, q0, and z_acc "
            "are correlated downstream bookkeeping quantities, not independent QEG predictions."
        ),
    }

    rows.to_csv(out_dir / "stage7D_v5_friedmann_manuscript_trace.csv", index=False)
    with (out_dir / "stage7D_v5_friedmann_manuscript_trace.json").open("w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, sort_keys=True)
    (out_dir / "stage7D_v5_friedmann_manuscript_table.tex").write_text(
        build_latex_table(rows), encoding="utf-8"
    )

    report_lines = [
        "=" * 72,
        "STAGE-7D v5 MANUSCRIPT FRIEDMANN TRACE",
        "=" * 72,
        f"Verdict: {verdict}",
        "",
        "Canonical corridor:",
        f"  Omega_m_like       = {om:.12g}",
        f"  Omega_K_like       = {ok:.12g}",
        f"  Omega_Lambda_cl    = {ol_recomputed:.12g}",
        f"  age_Gyr             = {age:.12g}",
        f"  q0_like             = {q0:.12g}",
        f"  z_acc_like          = {zacc:.12g}",
        "",
        "Cross-stage checks:",
    ]
    report_lines.extend([f"  {k}: {v}" for k, v in checks.items()])
    report_lines.extend([
        "",
        "Claim ceiling:",
        "  Appendix-only compatibility bookkeeping.",
        "  No Friedmann, age, Lambda, acceleration, GR, or cosmic-time derivation.",
        "",
        "Sources:",
    ])
    report_lines.extend([f"  {r['role']}: {r['path']}" for r in source_records])
    (out_dir / "stage7D_v5_friedmann_trace_report.txt").write_text(
        "\n".join(report_lines) + "\n", encoding="utf-8"
    )

    print("\n".join(report_lines))
    print(f"\nOutputs written to: {out_dir}")


if __name__ == "__main__":
    main()
