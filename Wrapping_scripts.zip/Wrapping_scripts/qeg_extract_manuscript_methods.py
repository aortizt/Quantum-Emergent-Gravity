#!/usr/bin/env python3
"""
qeg_extract_manuscript_methods.py

Purpose
-------
Scan the curated QEG GitHub staging/reproducibility bundle and extract a
manuscript-facing inventory of TOP-LEVEL mathematical methods.

This is not a script-by-script history.  It aggregates the curated script
bundle into method families suitable for a Physica D manuscript:

    question -> method family -> representative evidence files -> paper section

Default input path is the user's current QEG curated bundle:
/home/dakini/Downloads/010-Quantum_Emergent_Gravity/metric_stage_7E_outputs/github_staging_reproducibility_bundle_v1

Outputs
-------
Created in <outdir>, default <root>/manuscript_method_inventory:

1. qeg_method_group_summary.csv
2. qeg_method_group_summary.json
3. qeg_script_method_hits.csv
4. qeg_manuscript_methods_inventory.md
5. qeg_section_method_map.md
6. qeg_top_method_inventory.tex

Design policy
-------------
The manuscript should NOT mention every implementation dependency, helper
script, local repair, or branch.  It should mention only the method families
that explain the scientific constraint chain.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
import re
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

DEFAULT_ROOT = Path(
    "/home/dakini/Downloads/010-Quantum_Emergent_Gravity/"
    "metric_stage_7E_outputs/github_staging_reproducibility_bundle_v1"
)

TEXT_EXTENSIONS = {
    ".py", ".txt", ".md", ".tex", ".json", ".csv", ".yaml", ".yml", ".rst"
}

MAX_BYTES_PER_FILE = 750_000  # enough for method signatures, avoids huge CSV dumps


@dataclass
class MethodGroup:
    key: str
    label: str
    manuscript_role: str
    section_hint: str
    priority: int
    patterns: List[str]


METHOD_GROUPS: List[MethodGroup] = [
    MethodGroup(
        key="lineage_provenance",
        label="Lineage and provenance reconstruction",
        manuscript_role=(
            "BARI/NUFIT/VALENCIA source lineage, family-label repair, checksums, "
            "repository/Zenodo reproducibility, and guardrails against orphaned pooled artifacts."
        ),
        section_hint="Sec. 2--3; Appendix B",
        priority=1,
        patterns=[
            r"\bBARI\b", r"\bNUFIT\b", r"\bVALENCIA\b", r"FIT_id", r"family", r"lineage",
            r"provenance", r"row[-_ ]?level", r"checksum|sha256", r"Zenodo|GitHub",
            r"repair", r"rebuild", r"source families?",
        ],
    ),
    MethodGroup(
        key="intrinsic_geometry",
        label="Intrinsic geometry and coordinate construction",
        manuscript_role=(
            "Intrinsic coordinate s, shell/band construction, metric candidates, Fisher/covariance "
            "eigensystems, radial organization, and stable geometric observables."
        ),
        section_hint="Sec. 3",
        priority=1,
        patterns=[
            r"intrinsic", r"coordinate", r"\bshell", r"band", r"metric_", r"radial",
            r"Fisher", r"covariance", r"eigen", r"anisotropy", r"atlas",
            r"geometry", r"obstruction", r"comm_norm", r"holonomy_dev_mean",
        ],
    ),
    MethodGroup(
        key="transport_alignment",
        label="Transport, alignment, and obstruction diagnostics",
        manuscript_role=(
            "Procrustes/polar alignment, optimal transport/Hungarian matching, commutators, "
            "holonomy-style quantities, shell transport, and quasiconformal/dilatation-like diagnostics."
        ),
        section_hint="Sec. 3 and Sec. 7",
        priority=2,
        patterns=[
            r"Procrustes", r"polar", r"orthogonal", r"optimal transport|\bOT\b", r"Hungarian",
            r"assignment", r"transport", r"commutator", r"holonomy", r"triangle defect",
            r"QC|quasi[- ]?conformal|dilatation", r"alignment", r"rotation",
        ],
    ),
    MethodGroup(
        key="distributional_statistics",
        label="Distributional and statistical diagnostics",
        manuscript_role=(
            "Histogram/profile construction, binning, bootstrap summaries, correlations, distances, "
            "spread/drift checks, and family/resolution descriptive statistics."
        ),
        section_hint="Sec. 3, Sec. 5--6",
        priority=3,
        patterns=[
            r"histogram|profile|binning|\bbins?\b", r"bootstrap", r"correlation|\bcorr\b",
            r"R\^?2|r2|rmse", r"distance", r"drift", r"spread", r"quantile",
            r"mean|median|variance|std", r"resolution", r"48[-_ ]?bin|361[-_ ]?bin",
        ],
    ),
    MethodGroup(
        key="nonlocal_operator",
        label="Nonlocal response geometry",
        manuscript_role=(
            "Kernel/operator tests linking curvature-like kappa(s) and density-like rho(s), including "
            "lagged correlations, response kernels, non-translation-invariant operators, and direction tests."
        ),
        section_hint="Sec. 4",
        priority=1,
        patterns=[
            r"nonlocal", r"kernel", r"operator", r"response", r"propagator", r"transfer",
            r"lag", r"memory", r"kappa", r"rho", r"density", r"curvature",
            r"source[-_ ]?response", r"boundary[-_ ]?forced", r"translation[-_ ]?invariant",
        ],
    ),
    MethodGroup(
        key="low_rank_modal",
        label="Low-rank and modal operator reduction",
        manuscript_role=(
            "SVD/singular-mode compression, rank-few reconstruction, collective mode interpretation, "
            "and non-tautological mode constraints."
        ),
        section_hint="Sec. 4--5 and Sec. 7",
        priority=1,
        patterns=[
            r"low[-_ ]?rank", r"rank[-_ ]?1|rank[-_ ]?2|rank[-_ ]?few", r"SVD|singular",
            r"mode", r"modal", r"basis", r"projection", r"separable", r"subspace",
            r"compression", r"dominant mode", r"collective",
        ],
    ),
    MethodGroup(
        key="closure_falsification",
        label="Closure falsification and negative controls",
        manuscript_role=(
            "Failure of local pointwise/PDE closures, weak Green-kernel analogues, nulls, ablations, "
            "tautology guards, and forbidden reconstruction pathways."
        ),
        section_hint="Sec. 4; Appendix C",
        priority=1,
        patterns=[
            r"PDE", r"differential", r"screened", r"Poisson", r"Green", r"local closure",
            r"failed|reject|rejected|underperform|weak", r"null", r"ablation", r"shuffle",
            r"tautolog", r"forbid|forbidden", r"negative control", r"adversarial",
        ],
    ),
    MethodGroup(
        key="two_sector_law",
        label="Canonical two-sector law extraction",
        manuscript_role=(
            "Constrained bimodal/two-lobe decomposition of rho(s) into early/boundary and central/bulk "
            "sectors, including lobe centers, widths, masses, separation, and skew."
        ),
        section_hint="Sec. 5--6",
        priority=1,
        patterns=[
            r"two[-_ ]?sector|two[-_ ]?lobe|bimodal|bimodality", r"early", r"central",
            r"boundary", r"bulk", r"lobe", r"Gaussian|skew", r"mass fraction",
            r"mu_early|mu_central|separation", r"E\(s\)|C\(s\)|rho\(s\).*E.*C",
        ],
    ),
    MethodGroup(
        key="universality_robustness",
        label="Family universality and robustness audits",
        manuscript_role=(
            "BARI/NUFIT/VALENCIA family-separated tests, pooled-artifact checks, coordinate changes, "
            "resolution stability, perturbation drift, and reproducibility hardening."
        ),
        section_hint="Sec. 6",
        priority=1,
        patterns=[
            r"universality|universal", r"family[-_ ]?separated|family[-_ ]?aware", r"pooled",
            r"coordinate robustness|reparameter|resolution", r"perturbation|drift", r"stability",
            r"BARI|NUFIT|VALENCIA", r"not a pooled artifact|pooled artifact",
        ],
    ),
    MethodGroup(
        key="recursive_dynamics",
        label="Recursive transport and nonlinear stability",
        manuscript_role=(
            "Recursive updates, attractors/fixed points, nonlinear stabilization, low-k collective modes, "
            "entropy/directionality channels, and partial-reversibility sandbox tests."
        ),
        section_hint="Sec. 7",
        priority=1,
        patterns=[
            r"recursive|recursion|iterate|iteration", r"fixed[-_ ]?point|attractor|converge|basin",
            r"nonlinear", r"saturation|logistic|tanh", r"low[-_ ]?k|spectral", r"entropy",
            r"directionality|forward|reverse|adjoint|inverse", r"reversibility|semigroup",
        ],
    ),
    MethodGroup(
        key="physics_comparison",
        label="Physics-facing comparison bookkeeping",
        manuscript_role=(
            "Locked-reference dimensionless comparisons to cosmological/GR-adjacent quantities, with "
            "non-identification guardrails and appendix-only Friedmann/Lambda/curvature material."
        ),
        section_hint="Sec. 8; Appendix D--E",
        priority=2,
        patterns=[
            r"Omega|Omega_m|Omega_Lambda|Omega_K|cosmology|Friedmann|GR[-_ ]?adjacent",
            r"matter[-_ ]?sector|dark matter|dark energy|curvature", r"benchmark|locked reference",
            r"comparison bookkeeping|dimensionless proximity|non[-_ ]?identification|guardrail",
            r"q0|acceleration|Hubble|scale factor",
        ],
    ),
]


def normalize_text(text: str) -> str:
    return text.replace("\x00", " ")


def iter_candidate_files(root: Path) -> Iterable[Path]:
    for p in root.rglob("*"):
        if not p.is_file():
            continue
        if p.suffix.lower() in TEXT_EXTENSIONS:
            # Skip generated inventory from earlier runs if root is reused.
            if "manuscript_method_inventory" in p.parts:
                continue
            yield p


def safe_read(path: Path) -> str:
    try:
        data = path.read_bytes()[:MAX_BYTES_PER_FILE]
        return normalize_text(data.decode("utf-8", errors="ignore"))
    except Exception as exc:  # noqa: BLE001 - audit script should not die on one file
        return f"__READ_ERROR__ {exc}"


def stage_sort_key(path: Path) -> Tuple[int, str]:
    m = re.search(r"stage[-_ ]?(\d+)([A-Za-z]*)", str(path), flags=re.I)
    if not m:
        return (999, str(path).lower())
    num = int(m.group(1))
    suffix = m.group(2).lower()
    # Convert letters to rough order: A=1, B=2, ..., AA not expected but safe.
    letter_score = 0
    for ch in suffix:
        if ch.isalpha():
            letter_score = letter_score * 26 + (ord(ch) - 96)
    return (num * 1000 + letter_score, str(path).lower())


def score_group(text: str, group: MethodGroup) -> Tuple[int, List[str]]:
    hits = []
    total = 0
    for pat in group.patterns:
        try:
            found = re.findall(pat, text, flags=re.I | re.M)
        except re.error:
            found = []
        if found:
            hits.append(pat)
            total += min(len(found), 25)  # cap repetitive CSV columns
    return total, hits


def relative(path: Path, root: Path) -> str:
    try:
        return str(path.relative_to(root))
    except ValueError:
        return str(path)


def write_csv(path: Path, rows: Sequence[Dict[str, object]], fieldnames: Sequence[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def tex_escape(s: str) -> str:
    repl = {
        "&": r"\&", "%": r"\%", "$": r"\$", "#": r"\#", "_": r"\_",
        "{": r"\{", "}": r"\}", "~": r"\textasciitilde{}", "^": r"\textasciicircum{}",
        "\\": r"\textbackslash{}",
    }
    return "".join(repl.get(ch, ch) for ch in s)


def main() -> int:
    ap = argparse.ArgumentParser(description="Extract top-level mathematical method inventory for QEG manuscript.")
    ap.add_argument("root", nargs="?", default=str(DEFAULT_ROOT), help="Curated QEG bundle root to scan.")
    ap.add_argument("--outdir", default=None, help="Output directory. Default: <root>/manuscript_method_inventory")
    ap.add_argument("--min-score", type=int, default=2, help="Minimum pattern score for a file-method hit.")
    ap.add_argument("--top-files", type=int, default=12, help="Representative files per method in the summary.")
    args = ap.parse_args()

    root = Path(args.root).expanduser().resolve()
    outdir = Path(args.outdir).expanduser().resolve() if args.outdir else root / "manuscript_method_inventory"
    outdir.mkdir(parents=True, exist_ok=True)

    if not root.exists():
        raise SystemExit(f"Root does not exist: {root}")

    method_hits: List[Dict[str, object]] = []
    group_accum: Dict[str, Dict[str, object]] = {
        g.key: {
            "group": g,
            "files": [],
            "score_total": 0,
            "hit_count": 0,
            "patterns": set(),
        }
        for g in METHOD_GROUPS
    }

    files = sorted(iter_candidate_files(root), key=stage_sort_key)
    for p in files:
        text = safe_read(p)
        rel = relative(p, root)
        for g in METHOD_GROUPS:
            score, patterns = score_group(text + "\n" + rel, g)
            if score >= args.min_score:
                method_hits.append({
                    "file": rel,
                    "method_key": g.key,
                    "method_label": g.label,
                    "score": score,
                    "matched_patterns": "; ".join(patterns[:10]),
                    "section_hint": g.section_hint,
                    "priority": g.priority,
                })
                acc = group_accum[g.key]
                acc["files"].append((score, rel))
                acc["score_total"] += score
                acc["hit_count"] += 1
                acc["patterns"].update(patterns)

    # Sort per group by score descending, then stage/path.
    group_rows: List[Dict[str, object]] = []
    for g in METHOD_GROUPS:
        acc = group_accum[g.key]
        reps = sorted(acc["files"], key=lambda x: (-x[0], stage_sort_key(root / x[1])))[: args.top_files]
        rep_files = [r for _, r in reps]
        group_rows.append({
            "priority": g.priority,
            "method_key": g.key,
            "method_label": g.label,
            "section_hint": g.section_hint,
            "hit_files": acc["hit_count"],
            "score_total": acc["score_total"],
            "manuscript_role": g.manuscript_role,
            "representative_files": " | ".join(rep_files),
        })

    group_rows.sort(key=lambda r: (int(r["priority"]), -int(r["score_total"]), str(r["method_key"])))
    method_hits.sort(key=lambda r: (int(r["priority"]), str(r["method_key"]), -int(r["score"]), str(r["file"])))

    write_csv(
        outdir / "qeg_script_method_hits.csv",
        method_hits,
        ["file", "method_key", "method_label", "score", "matched_patterns", "section_hint", "priority"],
    )
    write_csv(
        outdir / "qeg_method_group_summary.csv",
        group_rows,
        ["priority", "method_key", "method_label", "section_hint", "hit_files", "score_total", "manuscript_role", "representative_files"],
    )

    with (outdir / "qeg_method_group_summary.json").open("w", encoding="utf-8") as f:
        json.dump({
            "root": str(root),
            "file_count_scanned": len(files),
            "method_groups": group_rows,
            "notes": [
                "Scores are keyword-audit aids, not proof of scientific importance.",
                "The manuscript should use method families, not a script-by-script narration.",
                "Review representative files manually before final wording."
            ],
        }, f, indent=2)

    # Markdown inventory.
    md = []
    md.append("# QEG manuscript-facing mathematical methods inventory\n")
    md.append(f"Scanned root: `{root}`\n")
    md.append(f"Files scanned: **{len(files)}**\n")
    md.append("\nThis inventory is meant to support a Physica D manuscript written in method-result units. It is not a complete computational pipeline history.\n")
    md.append("\n## Top-level method families\n")
    for row in group_rows:
        md.append(f"\n### {row['method_label']}\n")
        md.append(f"- Manuscript section hint: **{row['section_hint']}**\n")
        md.append(f"- Files with hits: **{row['hit_files']}**; score total: **{row['score_total']}**\n")
        md.append(f"- Manuscript role: {row['manuscript_role']}\n")
        reps = str(row["representative_files"]).split(" | ") if row["representative_files"] else []
        if reps:
            md.append("- Representative files to inspect:\n")
            for rep in reps[: args.top_files]:
                md.append(f"  - `{rep}`\n")
    md.append("\n## Draft compression rule\n")
    md.append("\nUse these method families as subsection-level methods. Do not list helper functions, file-format conversions, every repair branch, or every low-level numerical dependency unless it changes a scientific claim.\n")
    (outdir / "qeg_manuscript_methods_inventory.md").write_text("".join(md), encoding="utf-8")

    # Section-method map.
    section_map = "# QEG section-to-method map\n\n"
    section_map += "| Paper section | Top mathematical methods | Manuscript function |\n"
    section_map += "|---|---|---|\n"
    section_map += "| Sec. 2 Data lineage | Lineage/provenance reconstruction; checksums; family labels | Establish that the pipeline remains downstream of BARI/NUFIT/VALENCIA roots. |\n"
    section_map += "| Sec. 3 Intrinsic geometry | Intrinsic coordinate, shell/band geometry, eigensystems, transport diagnostics | Build the internal coordinate and observables. |\n"
    section_map += "| Sec. 4 Nonlocal response | Closure falsification, nonlocal kernels, kappa/rho direction tests, low-rank compression | Move from failed local law to operator geometry. |\n"
    section_map += "| Sec. 5 Two-sector law | Modal decomposition, constrained bimodal fitting, lobe invariants | State the central mathematical result rho(s) approx E(s)+C(s). |\n"
    section_map += "| Sec. 6 Universality | Family separation, resolution checks, coordinate robustness | Show the law is not a pooled artifact. |\n"
    section_map += "| Sec. 7 Recursive transport | Recursive maps, fixed points, low-k/entropy/directionality/null channels | Test whether the law behaves dynamically, not merely as a fit. |\n"
    section_map += "| Sec. 8 Physics calibration | Locked-reference dimensionless comparisons, claim ladder | Report physics-facing proximity without identification claims. |\n"
    (outdir / "qeg_section_method_map.md").write_text(section_map, encoding="utf-8")

    # LaTeX table for manuscript.
    top = group_rows[:10]
    lines = []
    lines.append("% Auto-generated by qeg_extract_manuscript_methods.py\n")
    lines.append("\\begin{table}[htbp]\n")
    lines.append("\\centering\n")
    lines.append("\\caption{Top-level mathematical method families detected in the curated QEG script bundle. This table is a manuscript-compression aid, not a script-by-script inventory.}\n")
    lines.append("\\label{tab:auto-method-inventory}\n")
    lines.append("\\begin{tabular}{p{0.28\\linewidth}p{0.18\\linewidth}p{0.42\\linewidth}}\n")
    lines.append("\\toprule\n")
    lines.append("Method family & Section hint & Manuscript role \\\\\n")
    lines.append("\\midrule\n")
    for row in top:
        lines.append(
            f"{tex_escape(str(row['method_label']))} & {tex_escape(str(row['section_hint']))} & {tex_escape(str(row['manuscript_role']))} \\\\\n"
        )
    lines.append("\\bottomrule\n")
    lines.append("\\end{tabular}\n")
    lines.append("\\end{table}\n")
    (outdir / "qeg_top_method_inventory.tex").write_text("".join(lines), encoding="utf-8")

    print("QEG manuscript method inventory complete.")
    print(f"Scanned files : {len(files)}")
    print(f"Output dir    : {outdir}")
    print("Key outputs:")
    for name in [
        "qeg_method_group_summary.csv",
        "qeg_script_method_hits.csv",
        "qeg_manuscript_methods_inventory.md",
        "qeg_section_method_map.md",
        "qeg_top_method_inventory.tex",
    ]:
        print(f"  - {outdir / name}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
