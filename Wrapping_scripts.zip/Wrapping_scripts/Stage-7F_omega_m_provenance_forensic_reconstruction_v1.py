#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
========================================================================
QEG targeted forensic audit
Omega_m comparator provenance reconstruction
========================================================================

Purpose
-------
Reconstruct, without benchmark-driven selection, the first genuine
derivation paths of the two matter-sector comparison values currently under
review:

    persistent control : global_mu = 0.327995
    sub-percent value  : early_central_separation = 0.317696468538139

The audit distinguishes:

    1. direct numerical derivation from upstream quantities;
    2. downstream copying of an already existing value;
    3. explicit numeric literals in source code;
    4. repeated preservation of the same invariant;
    5. semantic overloading of the name early_central_separation.

The script does not fit, rescale, or rank quantities by closeness to Omega_m.
The external value is used only after provenance classification to reproduce
the already reported benchmark discrepancy.

Recommended use in Spyder
-------------------------
1. Open this file in Spyder.
2. Set USER_SUPPLIED_ROOT if the default project path is not correct.
3. Run the file.
4. Inspect the generated report and CSV tables.

Default project root
--------------------
/home/dakini/Downloads/010-Quantum_Emergent_Gravity

Output directory
----------------
metric_stage_7F_outputs/
    omega_m_provenance_forensic_reconstruction_v1/

Main outputs
------------
stage7F_value_occurrences.csv
stage7F_python_literal_assignments.csv
stage7F_python_formula_candidates.csv
stage7F_direct_mu_recomputations.csv
stage7F_feature_name_semantics.csv
stage7F_dependency_edges.csv
stage7F_filename_alias_audit.csv
stage7F_recommended_manuscript_freeze.csv
stage7F_provenance_verdict.json
Stage-7F_omega_m_provenance_forensic_report.txt
========================================================================
"""

from __future__ import annotations

import argparse
import ast
import csv
import datetime as dt
import hashlib
import json
import math
import os
import re
import sys
import traceback
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd


# ---------------------------------------------------------------------
# User configuration
# ---------------------------------------------------------------------

USER_SUPPLIED_ROOT: Optional[str] = None

DEFAULT_PROJECT_ROOT = Path(
    "/home/dakini/Downloads/010-Quantum_Emergent_Gravity"
)

OUTPUT_RELATIVE = (
    Path("metric_stage_7F_outputs")
    / "omega_m_provenance_forensic_reconstruction_v1"
)

SCRIPT_NAME = "Stage-7F_omega_m_provenance_forensic_reconstruction_v1.py"

OMEGA_M_REFERENCE = 0.315

REFERENCE_VALUES = {
    "global_mu_control": 0.327995,
    "sharp_candidate_full": 0.317696468538139,
    "sharp_candidate_rounded": 0.317696,
}

FEATURE_TOKENS = (
    "global_mu",
    "early_central_separation",
    "early-central separation",
    "mu_early",
    "early_mu",
    "mu_central",
    "central_mu",
    "early_center",
    "central_center",
    "early_centre",
    "central_centre",
)

TEXT_SUFFIXES = {
    ".py", ".csv", ".json", ".txt", ".md", ".yaml", ".yml", ".toml"
}
ARRAY_SUFFIXES = {".npz", ".npy"}

# The old filename is not required.  The extant file is the canonical alias.
FILENAME_ALIASES = {
    "stage6Yl_promotion_decision_panel.csv":
        "stage6Yl_omega_m_promotion_panel.csv",
}

MAX_TEXT_MB_DEFAULT = 80.0
MAX_CSV_ROWS_DEFAULT = 1_000_000
VALUE_TOLERANCE_DEFAULT = 5.0e-10
FORMULA_MATCH_TOLERANCE_DEFAULT = 5.0e-7


# ---------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------

@dataclass
class Occurrence:
    file_path: str
    file_type: str
    occurrence_kind: str
    feature_name: str
    value: Optional[float]
    matched_reference: str
    line_or_row: Optional[int]
    column_or_symbol: str
    context: str
    provenance_class: str
    sha256: str
    modified_time: float


@dataclass
class FormulaCandidate:
    file_path: str
    line_number: int
    assigned_symbol: str
    formula_text: str
    formula_class: str
    contains_early_term: bool
    contains_central_term: bool
    contains_reference_literal: bool
    notes: str


@dataclass
class DirectRecomputation:
    file_path: str
    row_index: int
    family: str
    resolution: str
    early_column: str
    central_column: str
    early_value: float
    central_value: float
    recomputed_abs_difference: float
    difference_from_global_mu: float
    difference_from_sharp_candidate: float
    formula_status: str
    row_context: str


# ---------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------

def now_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()


def normalize_name(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(value).lower()).strip("_")


def safe_float(value: Any) -> Optional[float]:
    try:
        x = float(value)
    except Exception:
        return None
    return x if math.isfinite(x) else None


def sha256_file(path: Path, block_size: int = 1024 * 1024) -> str:
    h = hashlib.sha256()
    try:
        with path.open("rb") as f:
            while True:
                block = f.read(block_size)
                if not block:
                    break
                h.update(block)
        return h.hexdigest()
    except Exception:
        return ""


def safe_rel(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve()))
    except Exception:
        return str(path)


def detect_project_root(start: Path) -> Path:
    start = start.expanduser().resolve()
    if start.is_file():
        start = start.parent

    indicators = (
        "metric_stage_6Yl_outputs",
        "metric_stage_6Yk_outputs",
        "metric_stage_6Yh_outputs",
        "metric_stage_6Q_outputs",
        "__qeg_evidence__",
    )

    current = start
    for _ in range(8):
        if any((current / item).exists() for item in indicators):
            return current
        if current.parent == current:
            break
        current = current.parent
    return start


def choose_root(cli_root: Optional[str]) -> Path:
    if cli_root:
        return detect_project_root(Path(cli_root))
    if USER_SUPPLIED_ROOT:
        return detect_project_root(Path(USER_SUPPLIED_ROOT))
    return detect_project_root(DEFAULT_PROJECT_ROOT)


def prepare_output_dir(path: Path, overwrite: bool) -> None:
    path.mkdir(parents=True, exist_ok=True)
    if any(path.iterdir()) and not overwrite:
        raise FileExistsError(
            f"Output directory is not empty: {path}\n"
            "Rerun with --overwrite, or clear the directory."
        )
    if overwrite:
        for child in path.iterdir():
            if child.is_file() or child.is_symlink():
                child.unlink()
            elif child.is_dir():
                import shutil
                shutil.rmtree(child)


def iter_project_files(root: Path) -> Iterator[Path]:
    skip_parts = {
        ".git", "__pycache__", ".pytest_cache", ".mypy_cache",
        "node_modules", ".venv", "venv",
    }
    output_abs = (root / OUTPUT_RELATIVE).resolve()

    for path in root.rglob("*"):
        if not path.is_file():
            continue
        if any(part in skip_parts for part in path.parts):
            continue
        try:
            if output_abs in path.resolve().parents:
                continue
        except Exception:
            pass
        if path.suffix.lower() in TEXT_SUFFIXES | ARRAY_SUFFIXES:
            yield path


def reference_match(value: Optional[float], tolerance: float) -> str:
    if value is None:
        return ""
    matches = []
    for name, ref in REFERENCE_VALUES.items():
        if abs(value - ref) <= tolerance:
            matches.append(name)
    return "|".join(matches)


def compact_context(value: Any, limit: int = 800) -> str:
    text = re.sub(r"\s+", " ", str(value)).strip()
    return text[:limit]


def row_as_context(row: pd.Series, limit: int = 1200) -> str:
    pairs = []
    for key, value in row.items():
        if pd.isna(value):
            continue
        pairs.append(f"{key}={value}")
    return compact_context("; ".join(pairs), limit)


def detect_family(text: str) -> str:
    upper = text.upper()
    found = [x for x in ("BARI", "NUFIT", "VALENCIA", "POOLED") if x in upper]
    return "|".join(found)


def detect_resolution(text: str) -> str:
    patterns = (
        r"\b(48|361)\s*[-_ ]?bins?\b",
        r"\bvalue_(48|361)\b",
        r"\bresolution[^0-9]*(48|361)\b",
    )
    hits = []
    for pattern in patterns:
        hits.extend(re.findall(pattern, text, flags=re.IGNORECASE))
    return "|".join(sorted(set(hits)))


def classify_occurrence(
    occurrence_kind: str,
    file_path: str,
    context: str,
) -> str:
    lower = (file_path + " " + context).lower()

    if occurrence_kind == "python_numeric_literal":
        return "HARD_CODED_LITERAL"

    if any(token in lower for token in (
        "historical_target", "historical_repair", "reconciliation_only",
        "known_prior", "manual", "fallback",
    )):
        return "HISTORICAL_OR_MANUAL_SEED"

    if any(token in lower for token in (
        "formula", "recomputed", "reconstruction", "weighted_mu",
        "mu_central", "central_mu", "mu_early", "early_mu",
    )):
        return "POSSIBLE_DERIVATION_REQUIRES_FORMULA_CHECK"

    if any(token in lower for token in (
        "source_file", "copied", "freeze", "promotion_panel",
        "manuscript_raw", "bookkeeping", "claim_status",
    )):
        return "DOWNSTREAM_PRESERVATION_OR_COPY"

    return "UNCLASSIFIED_OCCURRENCE"


def percent_discrepancy(value: float, benchmark: float) -> float:
    return abs(value - benchmark) / abs(benchmark) * 100.0


# ---------------------------------------------------------------------
# Python AST inspection
# ---------------------------------------------------------------------

def node_text(source: str, node: ast.AST) -> str:
    segment = ast.get_source_segment(source, node)
    if segment:
        return segment
    try:
        return ast.unparse(node)
    except Exception:
        return ""


def assigned_names(node: ast.AST) -> List[str]:
    names: List[str] = []

    def visit(target: ast.AST) -> None:
        if isinstance(target, ast.Name):
            names.append(target.id)
        elif isinstance(target, (ast.Tuple, ast.List)):
            for child in target.elts:
                visit(child)
        elif isinstance(target, ast.Attribute):
            names.append(node_text("", target) or target.attr)

    if isinstance(node, ast.Assign):
        for target in node.targets:
            visit(target)
    elif isinstance(node, ast.AnnAssign):
        visit(node.target)
    return names


def extract_numeric_constants(node: ast.AST) -> List[float]:
    values = []
    for child in ast.walk(node):
        if isinstance(child, ast.Constant) and isinstance(child.value, (int, float)):
            x = safe_float(child.value)
            if x is not None:
                values.append(x)
        elif isinstance(child, ast.UnaryOp) and isinstance(child.op, ast.USub):
            if isinstance(child.operand, ast.Constant):
                x = safe_float(child.operand.value)
                if x is not None:
                    values.append(-x)
    return values


def inspect_python(
    path: Path,
    root: Path,
    tolerance: float,
) -> Tuple[List[Occurrence], List[FormulaCandidate]]:
    occurrences: List[Occurrence] = []
    formulas: List[FormulaCandidate] = []

    try:
        source = path.read_text(encoding="utf-8", errors="replace")
        tree = ast.parse(source)
    except Exception:
        return occurrences, formulas

    rel = safe_rel(path, root)
    digest = sha256_file(path)
    mtime = path.stat().st_mtime

    for node in ast.walk(tree):
        if isinstance(node, (ast.Assign, ast.AnnAssign)):
            value_node = node.value
            symbols = assigned_names(node)
            formula = node_text(source, value_node)
            norm_formula = normalize_name(formula)
            norm_symbols = [normalize_name(x) for x in symbols]
            relevant_symbol = any(
                any(token in symbol for token in (
                    "global_mu", "early_central_separation",
                    "mu_early", "early_mu", "mu_central", "central_mu",
                ))
                for symbol in norm_symbols
            )
            relevant_formula = any(
                token in norm_formula
                for token in (
                    "global_mu", "early_central_separation",
                    "mu_early", "early_mu", "mu_central", "central_mu",
                )
            )

            numeric_values = extract_numeric_constants(value_node)
            for x in numeric_values:
                match = reference_match(x, tolerance)
                if match:
                    context = node_text(source, node)
                    occurrences.append(Occurrence(
                        file_path=rel,
                        file_type="python",
                        occurrence_kind="python_numeric_literal",
                        feature_name="|".join(symbols),
                        value=x,
                        matched_reference=match,
                        line_or_row=getattr(node, "lineno", None),
                        column_or_symbol="|".join(symbols),
                        context=compact_context(context),
                        provenance_class=classify_occurrence(
                            "python_numeric_literal", rel, context
                        ),
                        sha256=digest,
                        modified_time=mtime,
                    ))

            if relevant_symbol or relevant_formula:
                lower = formula.lower()
                has_early = bool(re.search(
                    r"(mu_early|early_mu|early.*cent(?:er|re))", lower
                ))
                has_central = bool(re.search(
                    r"(mu_central|central_mu|central.*cent(?:er|re))", lower
                ))
                has_abs_or_diff = (
                    "abs(" in lower or "absolute" in lower
                    or "-" in formula
                )
                formula_class = "OTHER_RELEVANT_FORMULA"
                if has_early and has_central and has_abs_or_diff:
                    formula_class = "DIRECT_EARLY_CENTRAL_FORMULA"
                elif any("global_mu" in s for s in norm_symbols):
                    formula_class = "GLOBAL_MU_ASSIGNMENT"
                elif any("early_central_separation" in s for s in norm_symbols):
                    formula_class = "SEPARATION_ASSIGNMENT"

                formulas.append(FormulaCandidate(
                    file_path=rel,
                    line_number=getattr(node, "lineno", -1),
                    assigned_symbol="|".join(symbols),
                    formula_text=compact_context(formula, 1200),
                    formula_class=formula_class,
                    contains_early_term=has_early,
                    contains_central_term=has_central,
                    contains_reference_literal=any(
                        bool(reference_match(x, tolerance))
                        for x in numeric_values
                    ),
                    notes=(
                        "Direct formula candidate"
                        if formula_class == "DIRECT_EARLY_CENTRAL_FORMULA"
                        else ""
                    ),
                ))

    return occurrences, formulas


# ---------------------------------------------------------------------
# CSV and JSON inspection
# ---------------------------------------------------------------------

EARLY_COLUMN_PATTERNS = (
    r"(^|_)mu_early($|_)",
    r"(^|_)early_mu($|_)",
    r"early.*cent(?:er|re)",
)
CENTRAL_COLUMN_PATTERNS = (
    r"(^|_)mu_central($|_)",
    r"(^|_)central_mu($|_)",
    r"central.*cent(?:er|re)",
)


def matching_columns(columns: Iterable[str], patterns: Sequence[str]) -> List[str]:
    out = []
    for column in columns:
        normalized = normalize_name(column)
        if any(re.search(pattern, normalized) for pattern in patterns):
            out.append(column)
    return out


def inspect_csv(
    path: Path,
    root: Path,
    tolerance: float,
    formula_tolerance: float,
    max_rows: int,
) -> Tuple[List[Occurrence], List[DirectRecomputation], List[Dict[str, Any]], List[Dict[str, Any]]]:
    occurrences: List[Occurrence] = []
    direct: List[DirectRecomputation] = []
    semantics: List[Dict[str, Any]] = []
    edges: List[Dict[str, Any]] = []

    rel = safe_rel(path, root)
    digest = sha256_file(path)
    mtime = path.stat().st_mtime

    try:
        df = pd.read_csv(path, low_memory=False, nrows=max_rows)
    except Exception:
        return occurrences, direct, semantics, edges

    norm_cols = {column: normalize_name(column) for column in df.columns}
    early_cols = matching_columns(df.columns, EARLY_COLUMN_PATTERNS)
    central_cols = matching_columns(df.columns, CENTRAL_COLUMN_PATTERNS)

    feature_cols = [
        column for column, norm in norm_cols.items()
        if any(token in norm for token in (
            "feature", "quantity", "observable", "name", "symbol",
        ))
    ]
    source_cols = [
        column for column, norm in norm_cols.items()
        if any(token in norm for token in (
            "source_file", "source_path", "input_file", "input_path",
            "parent_file", "upstream_file",
        ))
    ]

    numeric_df = df.apply(pd.to_numeric, errors="coerce")

    for idx, row in df.iterrows():
        context = row_as_context(row)
        context_lower = context.lower()

        feature_name = ""
        for column in feature_cols:
            value = row.get(column)
            if pd.notna(value) and any(
                token in str(value).lower()
                for token in ("global_mu", "early_central_separation")
            ):
                feature_name = str(value)
                break

        for column in df.columns:
            x = safe_float(row.get(column))
            if x is None:
                continue
            match = reference_match(x, tolerance)
            if not match:
                continue
            occurrence_kind = "csv_numeric_value"
            occurrences.append(Occurrence(
                file_path=rel,
                file_type="csv",
                occurrence_kind=occurrence_kind,
                feature_name=feature_name,
                value=x,
                matched_reference=match,
                line_or_row=int(idx),
                column_or_symbol=str(column),
                context=compact_context(context),
                provenance_class=classify_occurrence(
                    occurrence_kind, rel, context
                ),
                sha256=digest,
                modified_time=mtime,
            ))

        if "global_mu" in context_lower or "early_central_separation" in context_lower:
            for source_col in source_cols:
                src = row.get(source_col)
                if pd.isna(src):
                    continue
                edges.append({
                    "source_file": str(src),
                    "dependent_file": rel,
                    "edge_kind": "explicit_source_column",
                    "row_index": int(idx),
                    "context": compact_context(context),
                })

        for early_col in early_cols:
            early = safe_float(row.get(early_col))
            if early is None:
                continue
            for central_col in central_cols:
                central = safe_float(row.get(central_col))
                if central is None:
                    continue
                value = abs(central - early)
                d_global = abs(value - REFERENCE_VALUES["global_mu_control"])
                d_sharp = abs(value - REFERENCE_VALUES["sharp_candidate_full"])
                status = "DIRECT_MU_DIFFERENCE_OTHER_VALUE"
                if d_global <= formula_tolerance:
                    status = "DIRECT_MU_DIFFERENCE_MATCHES_GLOBAL_MU"
                elif d_sharp <= formula_tolerance:
                    status = "DIRECT_MU_DIFFERENCE_MATCHES_SHARP_CANDIDATE"

                direct.append(DirectRecomputation(
                    file_path=rel,
                    row_index=int(idx),
                    family=detect_family(context),
                    resolution=detect_resolution(context + " " + rel),
                    early_column=str(early_col),
                    central_column=str(central_col),
                    early_value=early,
                    central_value=central,
                    recomputed_abs_difference=value,
                    difference_from_global_mu=d_global,
                    difference_from_sharp_candidate=d_sharp,
                    formula_status=status,
                    row_context=compact_context(context),
                ))

        if "early_central_separation" in context_lower:
            note = ""
            for candidate_note in ("formula", "notes", "reason", "definition"):
                matching = [
                    column for column in df.columns
                    if candidate_note in normalize_name(column)
                ]
                for column in matching:
                    value = row.get(column)
                    if pd.notna(value):
                        note += f"{column}={value}; "
            semantics.append({
                "file_path": rel,
                "row_index": int(idx),
                "feature_label": "early_central_separation",
                "formula_or_notes": compact_context(note or context),
                "family": detect_family(context),
                "resolution": detect_resolution(context + " " + rel),
            })

    return occurrences, direct, semantics, edges


def flatten_json(obj: Any, prefix: str = "") -> Iterator[Tuple[str, Any]]:
    if isinstance(obj, dict):
        for key, value in obj.items():
            new_prefix = f"{prefix}.{key}" if prefix else str(key)
            yield from flatten_json(value, new_prefix)
    elif isinstance(obj, list):
        for index, value in enumerate(obj):
            yield from flatten_json(value, f"{prefix}[{index}]")
    else:
        yield prefix, obj


def inspect_json(
    path: Path,
    root: Path,
    tolerance: float,
) -> Tuple[List[Occurrence], List[Dict[str, Any]], List[Dict[str, Any]]]:
    occurrences: List[Occurrence] = []
    semantics: List[Dict[str, Any]] = []
    edges: List[Dict[str, Any]] = []

    rel = safe_rel(path, root)
    digest = sha256_file(path)
    mtime = path.stat().st_mtime

    try:
        obj = json.loads(path.read_text(encoding="utf-8", errors="replace"))
    except Exception:
        return occurrences, semantics, edges

    flattened = list(flatten_json(obj))
    text_context = compact_context(json.dumps(obj, default=str), 2000)

    for key, value in flattened:
        x = safe_float(value)
        if x is not None:
            match = reference_match(x, tolerance)
            if match:
                occurrence_kind = "json_numeric_value"
                context = f"{key}={value}"
                occurrences.append(Occurrence(
                    file_path=rel,
                    file_type="json",
                    occurrence_kind=occurrence_kind,
                    feature_name=key,
                    value=x,
                    matched_reference=match,
                    line_or_row=None,
                    column_or_symbol=key,
                    context=compact_context(context),
                    provenance_class=classify_occurrence(
                        occurrence_kind, rel, text_context
                    ),
                    sha256=digest,
                    modified_time=mtime,
                ))

        lower_key = key.lower()
        if "early_central_separation" in lower_key:
            semantics.append({
                "file_path": rel,
                "row_index": -1,
                "feature_label": "early_central_separation",
                "formula_or_notes": compact_context(f"{key}={value}"),
                "family": detect_family(key + " " + str(value)),
                "resolution": detect_resolution(key + " " + rel),
            })

        if any(token in lower_key for token in (
            "source_file", "source_path", "input_file", "input_path"
        )):
            if isinstance(value, str):
                edges.append({
                    "source_file": value,
                    "dependent_file": rel,
                    "edge_kind": "explicit_json_source",
                    "row_index": -1,
                    "context": compact_context(f"{key}={value}"),
                })

    return occurrences, semantics, edges


def inspect_text(
    path: Path,
    root: Path,
    tolerance: float,
    max_text_mb: float,
) -> List[Occurrence]:
    occurrences: List[Occurrence] = []
    if path.suffix.lower() in {".csv", ".json", ".py"}:
        return occurrences
    if path.stat().st_size > max_text_mb * 1024 * 1024:
        return occurrences

    rel = safe_rel(path, root)
    digest = sha256_file(path)
    mtime = path.stat().st_mtime

    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except Exception:
        return occurrences

    value_pattern = re.compile(
        r"[-+]?(?:\d+\.\d+|\d+)(?:[eE][-+]?\d+)?"
    )

    for line_number, line in enumerate(lines, start=1):
        lower = line.lower()
        relevant = any(token in lower for token in FEATURE_TOKENS)
        numeric_matches = []
        for token in value_pattern.findall(line):
            x = safe_float(token)
            if x is not None and reference_match(x, tolerance):
                numeric_matches.append(x)
        if not relevant and not numeric_matches:
            continue

        for x in numeric_matches:
            match = reference_match(x, tolerance)
            occurrences.append(Occurrence(
                file_path=rel,
                file_type=path.suffix.lower().lstrip("."),
                occurrence_kind="text_numeric_value",
                feature_name="",
                value=x,
                matched_reference=match,
                line_or_row=line_number,
                column_or_symbol="",
                context=compact_context(line),
                provenance_class=classify_occurrence(
                    "text_numeric_value", rel, line
                ),
                sha256=digest,
                modified_time=mtime,
            ))

    return occurrences


# ---------------------------------------------------------------------
# Optional NPZ/NPY inspection
# ---------------------------------------------------------------------

def inspect_array_file(
    path: Path,
    root: Path,
    tolerance: float,
) -> List[Occurrence]:
    occurrences: List[Occurrence] = []
    rel = safe_rel(path, root)
    digest = sha256_file(path)
    mtime = path.stat().st_mtime

    try:
        if path.suffix.lower() == ".npy":
            arrays = {"array": np.load(path, mmap_mode="r", allow_pickle=False)}
        else:
            data = np.load(path, allow_pickle=False)
            arrays = {key: data[key] for key in data.files}
    except Exception:
        return occurrences

    for key, array in arrays.items():
        key_lower = key.lower()
        if not any(token in key_lower for token in (
            "global_mu", "early_central", "mu_early", "early_mu",
            "mu_central", "central_mu",
        )):
            continue
        flat = np.asarray(array).reshape(-1)
        if flat.size > 10000:
            flat = flat[:10000]
        for index, raw in enumerate(flat):
            x = safe_float(raw)
            if x is None:
                continue
            match = reference_match(x, tolerance)
            if match:
                occurrences.append(Occurrence(
                    file_path=rel,
                    file_type=path.suffix.lower().lstrip("."),
                    occurrence_kind="array_numeric_value",
                    feature_name=key,
                    value=x,
                    matched_reference=match,
                    line_or_row=index,
                    column_or_symbol=key,
                    context=f"{key}[{index}]={x}",
                    provenance_class="ARRAY_VALUE_REQUIRES_GENERATOR_TRACE",
                    sha256=digest,
                    modified_time=mtime,
                ))
    return occurrences


# ---------------------------------------------------------------------
# Filename alias audit
# ---------------------------------------------------------------------

def build_alias_audit(root: Path) -> pd.DataFrame:
    rows = []
    for obsolete, canonical in FILENAME_ALIASES.items():
        obsolete_hits = list(root.rglob(obsolete))
        canonical_hits = list(root.rglob(canonical))
        rows.append({
            "obsolete_or_expected_name": obsolete,
            "canonical_extant_name": canonical,
            "obsolete_found_count": len(obsolete_hits),
            "canonical_found_count": len(canonical_hits),
            "canonical_paths": "|".join(safe_rel(x, root) for x in canonical_hits),
            "status": (
                "CANONICAL_ALIAS_CONFIRMED"
                if canonical_hits
                else "CANONICAL_ALIAS_NOT_FOUND"
            ),
            "interpretation": (
                "The missing obsolete filename is not treated as a missing "
                "scientific artifact when the canonical alias exists."
            ),
        })
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------
# Verdict
# ---------------------------------------------------------------------

def summarize_reference(
    occurrences: pd.DataFrame,
    direct_df: pd.DataFrame,
    reference_name: str,
) -> Dict[str, Any]:
    subset = occurrences[
        occurrences["matched_reference"].astype(str).str.contains(
            reference_name, regex=False, na=False
        )
    ].copy()

    hardcoded = subset[
        subset["provenance_class"].eq("HARD_CODED_LITERAL")
    ]
    preserved = subset[
        subset["provenance_class"].isin([
            "DOWNSTREAM_PRESERVATION_OR_COPY",
            "HISTORICAL_OR_MANUAL_SEED",
        ])
    ]

    if reference_name == "global_mu_control":
        direct_status = "DIRECT_MU_DIFFERENCE_MATCHES_GLOBAL_MU"
    else:
        direct_status = "DIRECT_MU_DIFFERENCE_MATCHES_SHARP_CANDIDATE"

    direct_matches = (
        direct_df[direct_df["formula_status"].eq(direct_status)]
        if not direct_df.empty
        else pd.DataFrame()
    )

    return {
        "reference_name": reference_name,
        "reference_value": REFERENCE_VALUES[reference_name],
        "occurrence_count": int(len(subset)),
        "file_count": int(subset["file_path"].nunique()) if not subset.empty else 0,
        "hardcoded_literal_count": int(len(hardcoded)),
        "downstream_or_historical_count": int(len(preserved)),
        "direct_mu_difference_match_count": int(len(direct_matches)),
        "direct_mu_difference_files": (
            sorted(direct_matches["file_path"].unique().tolist())
            if not direct_matches.empty else []
        ),
        "occurrence_files": (
            sorted(subset["file_path"].unique().tolist())
            if not subset.empty else []
        ),
    }


def determine_verdict(
    occurrence_df: pd.DataFrame,
    direct_df: pd.DataFrame,
    formula_df: pd.DataFrame,
    semantics_df: pd.DataFrame,
) -> Dict[str, Any]:
    global_summary = summarize_reference(
        occurrence_df, direct_df, "global_mu_control"
    )
    sharp_summary = summarize_reference(
        occurrence_df, direct_df, "sharp_candidate_full"
    )

    rounded_summary = summarize_reference(
        occurrence_df, direct_df, "sharp_candidate_rounded"
    )

    semantic_forms = []
    if not semantics_df.empty:
        semantic_forms = sorted(
            set(semantics_df["formula_or_notes"].dropna().astype(str))
        )

    # Global value: repeated preservation is meaningful, but its first genuine
    # generator must still be located to call provenance completely closed.
    if global_summary["direct_mu_difference_match_count"] > 0:
        global_status = "GLOBAL_MU_PROVENANCE_CLOSED_BY_DIRECT_RECOMPUTATION"
    elif global_summary["file_count"] >= 2:
        global_status = (
            "GLOBAL_MU_PERSISTENT_ACROSS_RECORDS_ORIGIN_FORMULA_STILL_REQUIRED"
        )
    else:
        global_status = "GLOBAL_MU_PROVENANCE_INCOMPLETE"

    # Sharp value: require a direct upstream formula match.  A literal followed
    # by downstream copies is not a reconstruction.
    sharp_direct_count = (
        sharp_summary["direct_mu_difference_match_count"]
        + rounded_summary["direct_mu_difference_match_count"]
    )
    sharp_hardcoded_count = (
        sharp_summary["hardcoded_literal_count"]
        + rounded_summary["hardcoded_literal_count"]
    )

    if sharp_direct_count > 0:
        sharp_status = "SHARP_VALUE_PROVENANCE_CLOSED_BY_DIRECT_RECOMPUTATION"
    elif sharp_hardcoded_count > 0:
        sharp_status = (
            "SHARP_VALUE_QUARANTINED_LITERAL_OR_CIRCULAR_LINEAGE_DETECTED"
        )
    else:
        sharp_status = "SHARP_VALUE_PROVENANCE_NOT_RECOVERED"

    semantic_overloading = False
    if not direct_df.empty:
        values = direct_df["recomputed_abs_difference"].dropna()
        semantic_overloading = bool(
            len(values) >= 2
            and (values.max() - values.min()) > 1.0e-3
        )
    if len(semantic_forms) > 1:
        semantic_overloading = True

    recommended_primary = "global_mu"
    if (
        global_status == "GLOBAL_MU_PROVENANCE_CLOSED_BY_DIRECT_RECOMPUTATION"
        and sharp_status == "SHARP_VALUE_PROVENANCE_CLOSED_BY_DIRECT_RECOMPUTATION"
    ):
        recommended_primary = (
            "manual_choice_required_after_formula-equivalence_and-family_review"
        )

    return {
        "generated_at": now_iso(),
        "script": SCRIPT_NAME,
        "external_reference_used_only_after_provenance_classification": {
            "Omega_m": OMEGA_M_REFERENCE,
        },
        "global_mu": {
            **global_summary,
            "status": global_status,
            "benchmark_discrepancy_percent": percent_discrepancy(
                REFERENCE_VALUES["global_mu_control"], OMEGA_M_REFERENCE
            ),
        },
        "sharp_candidate": {
            **sharp_summary,
            "rounded_occurrence_summary": rounded_summary,
            "status": sharp_status,
            "benchmark_discrepancy_percent": percent_discrepancy(
                REFERENCE_VALUES["sharp_candidate_full"], OMEGA_M_REFERENCE
            ),
        },
        "semantic_overloading_of_early_central_separation": semantic_overloading,
        "distinct_semantic_records_count": len(semantic_forms),
        "recommended_manuscript_primary": recommended_primary,
        "recommended_policy": (
            "Retain global_mu as the primary 4.125% matter-sector comparison. "
            "Do not promote the sub-percent value unless a first non-circular "
            "formula and its upstream operands are recovered."
        ),
    }


def build_freeze_table(verdict: Dict[str, Any]) -> pd.DataFrame:
    global_status = verdict["global_mu"]["status"]
    sharp_status = verdict["sharp_candidate"]["status"]

    return pd.DataFrame([
        {
            "quantity": "global_mu",
            "value": REFERENCE_VALUES["global_mu_control"],
            "Omega_m_reference": OMEGA_M_REFERENCE,
            "benchmark_discrepancy_percent": percent_discrepancy(
                REFERENCE_VALUES["global_mu_control"], OMEGA_M_REFERENCE
            ),
            "provenance_status": global_status,
            "manuscript_action": (
                "RETAIN_PRIMARY_COMPARISON"
                if "PERSISTENT" in global_status or "CLOSED" in global_status
                else "WITHHOLD_PENDING_TRACE"
            ),
            "allowed_language": (
                "The internally generated dimensionless statistic reappears "
                "in multiple preserved records and differs from the locked "
                "matter-sector benchmark by approximately 4.125%."
            ),
        },
        {
            "quantity": "early_central_separation",
            "value": REFERENCE_VALUES["sharp_candidate_full"],
            "Omega_m_reference": OMEGA_M_REFERENCE,
            "benchmark_discrepancy_percent": percent_discrepancy(
                REFERENCE_VALUES["sharp_candidate_full"], OMEGA_M_REFERENCE
            ),
            "provenance_status": sharp_status,
            "manuscript_action": (
                "ALLOW_ONLY_IF_DIRECT_FORMULA_CLOSED"
                if "CLOSED" in sharp_status
                else "QUARANTINE_SUB_PERCENT_VALUE"
            ),
            "allowed_language": (
                "A sub-percent candidate was recorded, but it is not promoted "
                "until the defining formula and upstream operands are traced "
                "without circular reuse of the value."
            ),
        },
    ])


def write_report(
    path: Path,
    root: Path,
    verdict: Dict[str, Any],
    occurrence_df: pd.DataFrame,
    direct_df: pd.DataFrame,
    formula_df: pd.DataFrame,
    semantics_df: pd.DataFrame,
    alias_df: pd.DataFrame,
) -> None:
    lines = []
    lines.append("=" * 78)
    lines.append("QEG OMEGA_m PROVENANCE FORENSIC REPORT")
    lines.append("=" * 78)
    lines.append(f"Generated: {verdict['generated_at']}")
    lines.append(f"Project root: {root}")
    lines.append("")
    lines.append("NON-FITTING RULE")
    lines.append("-" * 78)
    lines.append(
        "All provenance classification was completed before calculating "
        "distance to the external Omega_m reference."
    )
    lines.append("")
    lines.append("GLOBAL_MU")
    lines.append("-" * 78)
    for key, value in verdict["global_mu"].items():
        lines.append(f"{key}: {value}")
    lines.append("")
    lines.append("SUB-PERCENT CANDIDATE")
    lines.append("-" * 78)
    for key, value in verdict["sharp_candidate"].items():
        lines.append(f"{key}: {value}")
    lines.append("")
    lines.append("SEMANTIC OVERLOADING")
    lines.append("-" * 78)
    lines.append(
        "early_central_separation overloaded: "
        f"{verdict['semantic_overloading_of_early_central_separation']}"
    )
    lines.append(
        f"distinct semantic records: "
        f"{verdict['distinct_semantic_records_count']}"
    )
    lines.append("")
    lines.append("FILENAME ALIAS")
    lines.append("-" * 78)
    if alias_df.empty:
        lines.append("No filename alias rules evaluated.")
    else:
        lines.extend(alias_df.to_string(index=False).splitlines())
    lines.append("")
    lines.append("RECOMMENDED MANUSCRIPT POLICY")
    lines.append("-" * 78)
    lines.append(verdict["recommended_policy"])
    lines.append("")
    lines.append("COUNTS")
    lines.append("-" * 78)
    lines.append(f"value occurrences: {len(occurrence_df)}")
    lines.append(f"direct mu recomputations: {len(direct_df)}")
    lines.append(f"Python formula candidates: {len(formula_df)}")
    lines.append(f"feature semantic records: {len(semantics_df)}")
    lines.append("")
    lines.append("IMPORTANT INTERPRETATION")
    lines.append("-" * 78)
    lines.append(
        "Repeated preservation of a value is evidence of persistence, but it "
        "is not the same as recovering the first formula that generated it."
    )
    lines.append(
        "A downstream table containing a historical value cannot serve as "
        "proof that the value was independently reconstructed."
    )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


# ---------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------

def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        description="Forensic provenance reconstruction for QEG Omega_m comparators."
    )
    parser.add_argument("--root", default=None, help="Project root.")
    parser.add_argument(
        "--overwrite", action="store_true",
        help="Replace existing outputs."
    )
    parser.add_argument(
        "--max-text-mb", type=float, default=MAX_TEXT_MB_DEFAULT
    )
    parser.add_argument(
        "--max-csv-rows", type=int, default=MAX_CSV_ROWS_DEFAULT
    )
    parser.add_argument(
        "--value-tolerance", type=float,
        default=VALUE_TOLERANCE_DEFAULT
    )
    parser.add_argument(
        "--formula-tolerance", type=float,
        default=FORMULA_MATCH_TOLERANCE_DEFAULT
    )
    args = parser.parse_args(argv)

    root = choose_root(args.root)
    out_dir = root / OUTPUT_RELATIVE
    prepare_output_dir(out_dir, args.overwrite)

    all_occurrences: List[Occurrence] = []
    all_formulas: List[FormulaCandidate] = []
    all_direct: List[DirectRecomputation] = []
    all_semantics: List[Dict[str, Any]] = []
    all_edges: List[Dict[str, Any]] = []
    scan_errors: List[Dict[str, Any]] = []

    project_files = sorted(iter_project_files(root))

    for index, path in enumerate(project_files, start=1):
        try:
            suffix = path.suffix.lower()

            if suffix == ".py":
                occurrences, formulas = inspect_python(
                    path, root, args.value_tolerance
                )
                all_occurrences.extend(occurrences)
                all_formulas.extend(formulas)

            elif suffix == ".csv":
                occurrences, direct, semantics, edges = inspect_csv(
                    path=path,
                    root=root,
                    tolerance=args.value_tolerance,
                    formula_tolerance=args.formula_tolerance,
                    max_rows=args.max_csv_rows,
                )
                all_occurrences.extend(occurrences)
                all_direct.extend(direct)
                all_semantics.extend(semantics)
                all_edges.extend(edges)

            elif suffix == ".json":
                occurrences, semantics, edges = inspect_json(
                    path, root, args.value_tolerance
                )
                all_occurrences.extend(occurrences)
                all_semantics.extend(semantics)
                all_edges.extend(edges)

            elif suffix in ARRAY_SUFFIXES:
                all_occurrences.extend(
                    inspect_array_file(path, root, args.value_tolerance)
                )

            else:
                all_occurrences.extend(
                    inspect_text(
                        path, root, args.value_tolerance, args.max_text_mb
                    )
                )

        except Exception as exc:
            scan_errors.append({
                "file_path": safe_rel(path, root),
                "error": repr(exc),
                "traceback": traceback.format_exc(limit=3),
            })

        if index % 250 == 0:
            print(f"Scanned {index}/{len(project_files)} files...")

    occurrence_df = pd.DataFrame(
        [asdict(item) for item in all_occurrences]
    )
    formula_df = pd.DataFrame(
        [asdict(item) for item in all_formulas]
    )
    direct_df = pd.DataFrame(
        [asdict(item) for item in all_direct]
    )
    semantics_df = pd.DataFrame(all_semantics)
    edge_df = pd.DataFrame(all_edges)
    alias_df = build_alias_audit(root)
    error_df = pd.DataFrame(scan_errors)

    # Guarantee required columns even when a table is empty.
    occurrence_columns = list(Occurrence.__dataclass_fields__.keys())
    formula_columns = list(FormulaCandidate.__dataclass_fields__.keys())
    direct_columns = list(DirectRecomputation.__dataclass_fields__.keys())

    occurrence_df = occurrence_df.reindex(columns=occurrence_columns)
    formula_df = formula_df.reindex(columns=formula_columns)
    direct_df = direct_df.reindex(columns=direct_columns)

    semantics_df = semantics_df.reindex(columns=[
        "file_path", "row_index", "feature_label",
        "formula_or_notes", "family", "resolution",
    ])
    edge_df = edge_df.reindex(columns=[
        "source_file", "dependent_file", "edge_kind",
        "row_index", "context",
    ])

    verdict = determine_verdict(
        occurrence_df, direct_df, formula_df, semantics_df
    )
    verdict["run_metadata"] = {
        "project_root": str(root),
        "output_directory": str(out_dir),
        "files_scanned": len(project_files),
        "scan_error_count": len(scan_errors),
        "arguments": vars(args),
        "filename_policy": (
            "stage6Yl_omega_m_promotion_panel.csv is the canonical extant "
            "name; stage6Yl_promotion_decision_panel.csv is treated as an "
            "obsolete alias and is not required."
        ),
    }

    freeze_df = build_freeze_table(verdict)

    occurrence_df.to_csv(
        out_dir / "stage7F_value_occurrences.csv", index=False
    )
    occurrence_df[
        occurrence_df["occurrence_kind"].eq("python_numeric_literal")
    ].to_csv(
        out_dir / "stage7F_python_literal_assignments.csv", index=False
    )
    formula_df.to_csv(
        out_dir / "stage7F_python_formula_candidates.csv", index=False
    )
    direct_df.to_csv(
        out_dir / "stage7F_direct_mu_recomputations.csv", index=False
    )
    semantics_df.to_csv(
        out_dir / "stage7F_feature_name_semantics.csv", index=False
    )
    edge_df.to_csv(
        out_dir / "stage7F_dependency_edges.csv", index=False
    )
    alias_df.to_csv(
        out_dir / "stage7F_filename_alias_audit.csv", index=False
    )
    freeze_df.to_csv(
        out_dir / "stage7F_recommended_manuscript_freeze.csv", index=False
    )
    error_df.to_csv(
        out_dir / "stage7F_scan_errors.csv", index=False
    )

    with (out_dir / "stage7F_provenance_verdict.json").open(
        "w", encoding="utf-8"
    ) as f:
        json.dump(verdict, f, indent=2, ensure_ascii=False)

    write_report(
        out_dir / "Stage-7F_omega_m_provenance_forensic_report.txt",
        root,
        verdict,
        occurrence_df,
        direct_df,
        formula_df,
        semantics_df,
        alias_df,
    )

    print()
    print("=" * 78)
    print("OMEGA_m PROVENANCE FORENSIC AUDIT COMPLETE")
    print("=" * 78)
    print(f"Project root: {root}")
    print(f"Files scanned: {len(project_files)}")
    print(f"Output directory: {out_dir}")
    print()
    print("global_mu status:")
    print(" ", verdict["global_mu"]["status"])
    print("sharp candidate status:")
    print(" ", verdict["sharp_candidate"]["status"])
    print()
    print("Recommended manuscript policy:")
    print(" ", verdict["recommended_policy"])
    print("=" * 78)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
