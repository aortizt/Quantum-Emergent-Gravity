#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
QEG external temporal holdout: NuFIT 6.0
========================================

Scientific purpose
------------------
This script asks a narrow, falsifiable question:

    Do later neutrino global-fit values, which played no role in developing
    QEG, remain compatible with the frozen source geometry defined from the
    PDG-2024 BARI/NUFIT/VALENCIA panel?

NuFIT 6.0 is used as a TEMPORAL EXTERNAL HOLDOUT, not as a fourth fully
independent global-fit family. Two later analysis variants are tested:

    IC19 without SK atmospheric data
    IC24 with SK atmospheric data

The source-level audit is immediately executable. It freezes every scaling,
PCA direction, distance envelope, and comparison reference on the original
PDG-2024 source panel before projecting NuFIT 6.0.

A second, optional hook tests a downstream holdout rho-like profile generated
by the already frozen QEG transformations. Supplying such a profile is needed
before claiming external validation of the two-sector law itself.

Inputs hard-coded from primary tables
-------------------------------------
Training panel:
    PDG 2024 neutrino global-fit summary, Table 14.7.

Temporal holdout:
    NuFIT 6.0, Table 1, arXiv:2410.05380v2.

NuFIT 6.0 reports Delta m^2_31 for normal ordering, whereas the QEG source
panel uses Delta m^2_32. For normal ordering this script converts

    Delta m^2_32 = Delta m^2_31 - Delta m^2_21.

Outputs
-------
<ROOT>/external_holdout_nufit6_outputs/

The script is single-threaded and designed for Spyder.
"""

from __future__ import annotations

import json
import math
import os
import traceback
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Optional, Sequence, Tuple

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

try:
    from scipy.optimize import least_squares
    from scipy.spatial.distance import cdist
except Exception as exc:
    raise RuntimeError(
        "SciPy is required in the active Spyder environment."
    ) from exc


# ============================================================================
# USER SETTINGS
# ============================================================================

ROOT = Path(
    os.environ.get(
        "QEG_ROOT",
        "/home/dakini/Downloads/010-Quantum_Emergent_Gravity",
    )
).expanduser()

OUTPUT_DIR = ROOT / "external_holdout_nufit6_outputs"

# Optional downstream profile produced by the FROZEN QEG transformations.
# Expected: one coordinate column and one rho/profile/value column.
# Example:
# HOLDOUT_PROFILE_CSV = ROOT / "metric_external_holdout_outputs" / "rho_holdout.csv"
HOLDOUT_PROFILE_CSV: Optional[Path] = None

RANDOM_SEED = 20260621
N_NULL = 5000
N_MONTE_CARLO = 3000

# Predeclared source-level promotion ceilings.
NN_ENVELOPE_FACTOR = 1.25
MAHALANOBIS_ENVELOPE_FACTOR = 1.25
ORDERING_COSINE_MIN = 0.80

# Frozen manuscript-facing two-sector windows.
EARLY_CENTER_WINDOW = (0.10, 0.20)
CENTRAL_CENTER_WINDOW = (0.45, 0.65)
PROFILE_R2_MIN = 0.70
PROFILE_CORR_MIN = 0.80

EPS = 1.0e-12


# ============================================================================
# DATA DEFINITIONS
# ============================================================================

@dataclass(frozen=True)
class OscillationRecord:
    label: str
    family: str
    variant: str
    ordering: str
    sin2_theta12: float
    sin2_theta23: float
    sin2_theta13: float
    delta_cp_deg: float
    dm21_mev2: float
    dm32_mev2: float
    err_minus: Tuple[float, float, float, float, float, float]
    err_plus: Tuple[float, float, float, float, float, float]
    source: str


def record(
    label: str,
    family: str,
    variant: str,
    ordering: str,
    values: Sequence[float],
    minus: Sequence[float],
    plus: Sequence[float],
    source: str,
) -> OscillationRecord:
    return OscillationRecord(
        label=label,
        family=family,
        variant=variant,
        ordering=ordering,
        sin2_theta12=float(values[0]),
        sin2_theta23=float(values[1]),
        sin2_theta13=float(values[2]),
        delta_cp_deg=float(values[3]),
        dm21_mev2=float(values[4]),
        dm32_mev2=float(values[5]),
        err_minus=tuple(float(x) for x in minus),
        err_plus=tuple(float(x) for x in plus),
        source=source,
    )


# Original development panel: PDG 2024 Table 14.7.
TRAINING_RECORDS = (
    record(
        "NUFIT5p2_NO", "NUFIT", "PDG2024_without_SK_atm", "NO",
        [0.303, 0.572, 0.02203, 197.0, 74.1, 2437.0],
        [0.011, 0.023, 0.00059, 25.0, 2.0, 27.0],
        [0.012, 0.018, 0.00056, 42.0, 2.1, 28.0],
        "PDG2024_Table14.7",
    ),
    record(
        "NUFIT5p2_IO", "NUFIT", "PDG2024_without_SK_atm", "IO",
        [0.303, 0.578, 0.02219, 286.0, 74.1, -2498.0],
        [0.011, 0.021, 0.00057, 32.0, 2.0, 25.0],
        [0.012, 0.016, 0.00060, 27.0, 2.1, 32.0],
        "PDG2024_Table14.7",
    ),
    record(
        "BARI_NO", "BARI", "PDG2024", "NO",
        [0.303, 0.455, 0.02230, 223.0, 73.6, 2448.0],
        [0.013, 0.015, 0.00060, 23.0, 1.5, 31.0],
        [0.013, 0.018, 0.00070, 32.0, 1.6, 23.0],
        "PDG2024_Table14.7",
    ),
    record(
        "BARI_IO", "BARI", "PDG2024", "IO",
        [0.303, 0.569, 0.02230, 274.0, 73.6, -2492.0],
        [0.013, 0.021, 0.00060, 27.0, 1.5, 30.0],
        [0.013, 0.013, 0.00060, 25.0, 1.6, 25.0],
        "PDG2024_Table14.7",
    ),
    record(
        "VALENCIA_NO", "VALENCIA", "PDG2024", "NO",
        [0.318, 0.574, 0.02200, 194.0, 75.0, 2470.0],
        [0.016, 0.014, 0.00062, 22.0, 2.0, 30.0],
        [0.016, 0.014, 0.00069, 24.0, 2.2, 20.0],
        "PDG2024_Table14.7",
    ),
    record(
        "VALENCIA_IO", "VALENCIA", "PDG2024", "IO",
        [0.318, 0.578, 0.02225, 284.0, 75.0, -2520.0],
        [0.016, 0.017, 0.00070, 28.0, 2.0, 20.0],
        [0.016, 0.010, 0.00064, 26.0, 2.2, 30.0],
        "PDG2024_Table14.7",
    ),
)

# Temporal external holdout: NuFIT 6.0 Table 1.
# NO dm32 values below are converted from published dm31.
HOLDOUT_RECORDS = (
    record(
        "NUFIT6_IC19_NO", "NUFIT6", "IC19_without_SK_atm", "NO",
        [0.307, 0.561, 0.02195, 177.0, 74.9, 2534.0 - 74.9],
        [0.011, 0.015, 0.00058, 20.0, 1.9, math.hypot(23.0, 1.9)],
        [0.012, 0.012, 0.00054, 19.0, 1.9, math.hypot(25.0, 1.9)],
        "NuFIT6_Table1_IC19",
    ),
    record(
        "NUFIT6_IC19_IO", "NUFIT6", "IC19_without_SK_atm", "IO",
        [0.308, 0.562, 0.02224, 285.0, 74.9, -2510.0],
        [0.011, 0.015, 0.00057, 28.0, 1.9, 25.0],
        [0.012, 0.012, 0.00056, 25.0, 1.9, 24.0],
        "NuFIT6_Table1_IC19",
    ),
    record(
        "NUFIT6_IC24SK_NO", "NUFIT6", "IC24_with_SK_atm", "NO",
        [0.308, 0.470, 0.02215, 212.0, 74.9, 2513.0 - 74.9],
        [0.011, 0.013, 0.00058, 41.0, 1.9, math.hypot(19.0, 1.9)],
        [0.012, 0.017, 0.00056, 26.0, 1.9, math.hypot(21.0, 1.9)],
        "NuFIT6_Table1_IC24_SK",
    ),
    record(
        "NUFIT6_IC24SK_IO", "NUFIT6", "IC24_with_SK_atm", "IO",
        [0.308, 0.550, 0.02231, 274.0, 74.9, -2484.0],
        [0.011, 0.015, 0.00056, 25.0, 1.9, 20.0],
        [0.012, 0.012, 0.00056, 22.0, 1.9, 20.0],
        "NuFIT6_Table1_IC24_SK",
    ),
)

FEATURE_NAMES = (
    "sin2_theta12",
    "sin2_theta23",
    "sin2_theta13",
    "cos_delta_cp",
    "sin_delta_cp",
    "dm21_mev2",
    "dm32_mev2",
)


# ============================================================================
# NUMERICAL UTILITIES
# ============================================================================

def vector(r: OscillationRecord, absolute_atmospheric: bool) -> np.ndarray:
    angle = np.deg2rad(r.delta_cp_deg % 360.0)
    dm32 = abs(r.dm32_mev2) if absolute_atmospheric else r.dm32_mev2
    return np.array(
        [
            r.sin2_theta12,
            r.sin2_theta23,
            r.sin2_theta13,
            np.cos(angle),
            np.sin(angle),
            r.dm21_mev2,
            dm32,
        ],
        dtype=float,
    )


def matrix(records, absolute_atmospheric):
    return np.vstack([vector(r, absolute_atmospheric) for r in records])


def fit_scaler(x: np.ndarray, mode: str):
    if mode == "zscore":
        center = np.mean(x, axis=0)
        scale = np.std(x, axis=0, ddof=1)
    elif mode == "robust":
        center = np.median(x, axis=0)
        q75, q25 = np.percentile(x, [75, 25], axis=0)
        scale = (q75 - q25) / 1.349
    else:
        raise ValueError(f"Unknown scaler: {mode}")
    scale = np.where(np.abs(scale) < EPS, 1.0, scale)
    return center, scale


def standardize(x, center, scale):
    return (x - center) / scale


def ridge_mahalanobis(z_train, z_query, ridge=0.20):
    mean = np.mean(z_train, axis=0)
    cov = np.cov(z_train, rowvar=False, ddof=1)
    target = np.trace(cov) / cov.shape[0] * np.eye(cov.shape[0])
    shrunk = (1.0 - ridge) * cov + ridge * target + EPS * np.eye(cov.shape[0])
    inv = np.linalg.pinv(shrunk)

    def score(z):
        d = z - mean
        return np.sqrt(np.einsum("ij,jk,ik->i", d, inv, d))

    return score(z_train), score(z_query)


def frozen_pca(z_train, z_query):
    mean = np.mean(z_train, axis=0)
    centered = z_train - mean
    _, singular, vt = np.linalg.svd(centered, full_matrices=False)
    components = vt[:2]
    explained = singular**2
    explained /= max(np.sum(explained), EPS)
    return centered @ components.T, (z_query - mean) @ components.T, explained[:2]


def cosine(a, b):
    denom = np.linalg.norm(a) * np.linalg.norm(b)
    return float(np.dot(a, b) / denom) if denom > EPS else float("nan")


def empirical_lower_tail_p(real, null):
    return float((1 + np.sum(null <= real)) / (len(null) + 1))


def pairs(records):
    out = {}
    for r in records:
        key = f"{r.family}::{r.variant}"
        out.setdefault(key, {})[r.ordering] = r
    return {k: v for k, v in out.items() if {"NO", "IO"} <= set(v)}


def asymmetric_draw(rng, center, minus, plus, n):
    z = rng.normal(size=n)
    sigma = np.where(z < 0.0, minus, plus)
    return center + z * sigma


def sample_record(rng, r, n, absolute_atmospheric):
    centers = [
        r.sin2_theta12,
        r.sin2_theta23,
        r.sin2_theta13,
        r.delta_cp_deg,
        r.dm21_mev2,
        r.dm32_mev2,
    ]
    raw = np.column_stack(
        [
            asymmetric_draw(rng, centers[j], r.err_minus[j], r.err_plus[j], n)
            for j in range(6)
        ]
    )
    raw[:, 3] %= 360.0
    phase = np.deg2rad(raw[:, 3])
    dm32 = np.abs(raw[:, 5]) if absolute_atmospheric else raw[:, 5]
    return np.column_stack(
        [raw[:, 0], raw[:, 1], raw[:, 2],
         np.cos(phase), np.sin(phase), raw[:, 4], dm32]
    )


# ============================================================================
# SOURCE-LEVEL AUDIT
# ============================================================================

def audit_atlas(scaler_mode, absolute_atmospheric, rng):
    x_train = matrix(TRAINING_RECORDS, absolute_atmospheric)
    x_hold = matrix(HOLDOUT_RECORDS, absolute_atmospheric)
    center, scale = fit_scaler(x_train, scaler_mode)
    z_train = standardize(x_train, center, scale)
    z_hold = standardize(x_hold, center, scale)

    atlas = f"{scaler_mode}__{'absdm' if absolute_atmospheric else 'signeddm'}"

    d_train = cdist(z_train, z_train)
    np.fill_diagonal(d_train, np.inf)
    train_nn = np.min(d_train, axis=1)

    d_hold = cdist(z_hold, z_train)
    hold_nn = np.min(d_hold, axis=1)
    nearest = np.argmin(d_hold, axis=1)

    train_maha, hold_maha = ridge_mahalanobis(z_train, z_hold)
    train_pc, hold_pc, explained = frozen_pca(z_train, z_hold)

    train_rows = []
    for i, r in enumerate(TRAINING_RECORDS):
        train_rows.append(
            {
                "atlas": atlas,
                "label": r.label,
                "family": r.family,
                "ordering": r.ordering,
                "nearest_neighbor_distance": float(train_nn[i]),
                "ridge_mahalanobis": float(train_maha[i]),
                "pc1": float(train_pc[i, 0]),
                "pc2": float(train_pc[i, 1]),
            }
        )

    max_nn = float(np.max(train_nn))
    max_maha = float(np.max(train_maha))
    hold_rows = []
    for i, r in enumerate(HOLDOUT_RECORDS):
        hold_rows.append(
            {
                "atlas": atlas,
                "label": r.label,
                "variant": r.variant,
                "ordering": r.ordering,
                "nearest_training_label": TRAINING_RECORDS[int(nearest[i])].label,
                "nearest_neighbor_distance": float(hold_nn[i]),
                "training_nn_max": max_nn,
                "nn_envelope_ratio": float(hold_nn[i] / max(max_nn, EPS)),
                "nn_pass": bool(hold_nn[i] <= NN_ENVELOPE_FACTOR * max_nn),
                "ridge_mahalanobis": float(hold_maha[i]),
                "training_mahalanobis_max": max_maha,
                "mahalanobis_envelope_ratio": float(
                    hold_maha[i] / max(max_maha, EPS)
                ),
                "mahalanobis_pass": bool(
                    hold_maha[i] <= MAHALANOBIS_ENVELOPE_FACTOR * max_maha
                ),
                "pc1": float(hold_pc[i, 0]),
                "pc2": float(hold_pc[i, 1]),
            }
        )

    def z_of(r):
        return standardize(
            vector(r, absolute_atmospheric)[None, :], center, scale
        )[0]

    training_pair_vectors = []
    for pair in pairs(TRAINING_RECORDS).values():
        training_pair_vectors.append(z_of(pair["IO"]) - z_of(pair["NO"]))
    mean_pair_vector = np.mean(training_pair_vectors, axis=0)

    ordering_rows = []
    for source_type, pair_map in (
        ("training", pairs(TRAINING_RECORDS)),
        ("holdout", pairs(HOLDOUT_RECORDS)),
    ):
        for pair_name, pair in pair_map.items():
            displacement = z_of(pair["IO"]) - z_of(pair["NO"])
            similarity = cosine(displacement, mean_pair_vector)
            ordering_rows.append(
                {
                    "atlas": atlas,
                    "source_type": source_type,
                    "pair": pair_name,
                    "displacement_norm": float(np.linalg.norm(displacement)),
                    "cosine_to_training_mean": similarity,
                    "ordering_alignment_pass": bool(
                        similarity >= ORDERING_COSINE_MIN
                    ),
                }
            )

    null_rows = []
    for variant in sorted({r.variant for r in HOLDOUT_RECORDS}):
        idx = [i for i, r in enumerate(HOLDOUT_RECORDS) if r.variant == variant]
        real = float(np.mean(np.min(cdist(z_hold[idx], z_train), axis=1)))

        perm_null = np.empty(N_NULL)
        for b in range(N_NULL):
            perm = rng.permutation(z_hold.shape[1])
            shuffled = z_hold[idx][:, perm]
            perm_null[b] = np.mean(np.min(cdist(shuffled, z_train), axis=1))

        null_rows.append(
            {
                "atlas": atlas,
                "variant": variant,
                "null_type": "semantic_coordinate_permutation",
                "real_mean_nn": real,
                "null_q05": float(np.quantile(perm_null, 0.05)),
                "null_median": float(np.median(perm_null)),
                "null_q95": float(np.quantile(perm_null, 0.95)),
                "empirical_lower_tail_p": empirical_lower_tail_p(real, perm_null),
            }
        )

        phase_null = np.empty(N_NULL)
        records_variant = [HOLDOUT_RECORDS[i] for i in idx]
        for b in range(N_NULL):
            randomized = []
            for r in records_variant:
                row = vector(r, absolute_atmospheric).copy()
                angle = rng.uniform(0.0, 2.0 * np.pi)
                row[3] = np.cos(angle)
                row[4] = np.sin(angle)
                randomized.append(row)
            z_random = standardize(np.vstack(randomized), center, scale)
            phase_null[b] = np.mean(
                np.min(cdist(z_random, z_train), axis=1)
            )

        null_rows.append(
            {
                "atlas": atlas,
                "variant": variant,
                "null_type": "phase_randomization",
                "real_mean_nn": real,
                "null_q05": float(np.quantile(phase_null, 0.05)),
                "null_median": float(np.median(phase_null)),
                "null_q95": float(np.quantile(phase_null, 0.95)),
                "empirical_lower_tail_p": empirical_lower_tail_p(real, phase_null),
            }
        )

    metadata = {
        "atlas": atlas,
        "center": center.tolist(),
        "scale": scale.tolist(),
        "pca_explained_variance_ratio": explained.tolist(),
        "training_nn_max": max_nn,
        "training_mahalanobis_max": max_maha,
    }

    return (
        pd.DataFrame(train_rows),
        pd.DataFrame(hold_rows),
        pd.DataFrame(ordering_rows),
        pd.DataFrame(null_rows),
        metadata,
    )


def uncertainty_audit(rng, scaler_mode, absolute_atmospheric):
    x_train = matrix(TRAINING_RECORDS, absolute_atmospheric)
    center, scale = fit_scaler(x_train, scaler_mode)
    old_nufit = {
        r.ordering: r for r in TRAINING_RECORDS if r.family == "NUFIT"
    }
    atlas = f"{scaler_mode}__{'absdm' if absolute_atmospheric else 'signeddm'}"
    rows = []

    for hold in HOLDOUT_RECORDS:
        old = old_nufit[hold.ordering]
        old_draw = standardize(
            sample_record(rng, old, N_MONTE_CARLO, absolute_atmospheric),
            center, scale
        )
        new_draw = standardize(
            sample_record(rng, hold, N_MONTE_CARLO, absolute_atmospheric),
            center, scale
        )
        temporal = np.linalg.norm(new_draw - old_draw, axis=1)

        old_center = standardize(
            vector(old, absolute_atmospheric)[None, :], center, scale
        )[0]
        cross = []
        for r in TRAINING_RECORDS:
            if r.ordering == hold.ordering and r.family != "NUFIT":
                other = standardize(
                    vector(r, absolute_atmospheric)[None, :], center, scale
                )[0]
                cross.append(float(np.linalg.norm(other - old_center)))
        cross_reference = float(np.median(cross))

        rows.append(
            {
                "atlas": atlas,
                "label": hold.label,
                "variant": hold.variant,
                "ordering": hold.ordering,
                "temporal_shift_median": float(np.median(temporal)),
                "temporal_shift_q05": float(np.quantile(temporal, 0.05)),
                "temporal_shift_q95": float(np.quantile(temporal, 0.95)),
                "historical_cross_family_reference": cross_reference,
                "shift_to_cross_family_ratio": float(
                    np.median(temporal) / max(cross_reference, EPS)
                ),
                "prob_shift_below_cross_family_reference": float(
                    np.mean(temporal <= cross_reference)
                ),
            }
        )
    return pd.DataFrame(rows)


def leave_one_family_out(scaler_mode, absolute_atmospheric):
    atlas = f"{scaler_mode}__{'absdm' if absolute_atmospheric else 'signeddm'}"
    rows = []
    for held_family in sorted({r.family for r in TRAINING_RECORDS}):
        training = [r for r in TRAINING_RECORDS if r.family != held_family]
        testing = [r for r in TRAINING_RECORDS if r.family == held_family]
        x_train = matrix(training, absolute_atmospheric)
        x_test = matrix(testing, absolute_atmospheric)
        center, scale = fit_scaler(x_train, scaler_mode)
        z_train = standardize(x_train, center, scale)
        z_test = standardize(x_test, center, scale)

        d_train = cdist(z_train, z_train)
        np.fill_diagonal(d_train, np.inf)
        envelope = float(np.max(np.min(d_train, axis=1)))
        scores = np.min(cdist(z_test, z_train), axis=1)

        for r, score in zip(testing, scores):
            rows.append(
                {
                    "atlas": atlas,
                    "held_family": held_family,
                    "label": r.label,
                    "ordering": r.ordering,
                    "heldout_nn": float(score),
                    "training_nn_max": envelope,
                    "envelope_ratio": float(score / max(envelope, EPS)),
                    "pass_1p25_envelope": bool(
                        score <= NN_ENVELOPE_FACTOR * envelope
                    ),
                }
            )
    return pd.DataFrame(rows)


# ============================================================================
# OPTIONAL DOWNSTREAM TWO-SECTOR PROFILE AUDIT
# ============================================================================

def find_column(columns, candidates):
    by_lower = {c.lower(): c for c in columns}
    for candidate in candidates:
        if candidate.lower() in by_lower:
            return by_lower[candidate.lower()]
    for column in columns:
        if any(candidate.lower() in column.lower() for candidate in candidates):
            return column
    return None


def gaussian(s, amplitude, mu, sigma):
    sigma = max(float(sigma), 1.0e-4)
    return amplitude * np.exp(-0.5 * ((s - mu) / sigma) ** 2)


def two_lobe(s, baseline, ae, mue, sige, ac, muc, sigc):
    return (
        baseline
        + gaussian(s, ae, mue, sige)
        + gaussian(s, ac, muc, sigc)
    )


def downstream_profile_audit(profile_csv: Path):
    df = pd.read_csv(profile_csv)
    s_col = find_column(
        df.columns,
        ["s", "intrinsic_coordinate", "resampled_intrinsic_coordinate", "coordinate"],
    )
    y_col = find_column(
        df.columns,
        ["rho", "rho_like", "profile", "density", "value"],
    )
    if s_col is None or y_col is None:
        raise ValueError(
            f"Could not identify coordinate/profile columns in {profile_csv}. "
            f"Columns={list(df.columns)}"
        )

    clean = df[[s_col, y_col]].dropna().sort_values(s_col)
    s = clean[s_col].to_numpy(float)
    y = clean[y_col].to_numpy(float)
    if len(s) < 12:
        raise ValueError("The downstream profile requires at least 12 finite rows.")

    s = (s - np.min(s)) / max(np.max(s) - np.min(s), EPS)
    yrange = float(np.max(y) - np.min(y))

    p0 = np.array(
        [
            float(np.min(y)),
            max(0.3 * yrange, EPS), 0.15, 0.04,
            max(0.8 * yrange, EPS), 0.54, 0.12,
        ]
    )
    lower = np.array(
        [
            np.min(y) - yrange,
            0.0, EARLY_CENTER_WINDOW[0], 0.005,
            0.0, CENTRAL_CENTER_WINDOW[0], 0.015,
        ]
    )
    upper = np.array(
        [
            np.max(y),
            max(3.0 * yrange, 1.0), EARLY_CENTER_WINDOW[1], 0.15,
            max(3.0 * yrange, 1.0), CENTRAL_CENTER_WINDOW[1], 0.30,
        ]
    )

    fit = least_squares(
        lambda p: two_lobe(s, *p) - y,
        p0,
        bounds=(lower, upper),
        max_nfev=50000,
    )
    pred = two_lobe(s, *fit.x)
    ss_res = float(np.sum((y - pred) ** 2))
    ss_tot = float(np.sum((y - np.mean(y)) ** 2))
    r2 = 1.0 - ss_res / max(ss_tot, EPS)
    corr = float(np.corrcoef(y, pred)[0, 1])

    baseline, ae, mue, sige, ac, muc, sigc = fit.x
    early = gaussian(s, ae, mue, sige)
    central = gaussian(s, ac, muc, sigc)
    early_mass = float(np.trapezoid(early, s))
    central_mass = float(np.trapezoid(central, s))
    total_mass = max(early_mass + central_mass, EPS)

    pd.DataFrame(
        {
            "s_normalized": s,
            "observed": y,
            "predicted": pred,
            "early_component": early,
            "central_component": central,
        }
    ).to_csv(OUTPUT_DIR / "holdout_profile_two_lobe_fit.csv", index=False)

    fig, ax = plt.subplots(figsize=(8.5, 5.2))
    ax.plot(s, y, label="holdout profile")
    ax.plot(s, pred, label="frozen-window two-sector fit")
    ax.plot(s, early, linestyle="--", label="early component")
    ax.plot(s, central, linestyle="--", label="central component")
    ax.set_xlabel("normalized intrinsic coordinate")
    ax.set_ylabel("profile value")
    ax.set_title("External holdout: frozen two-sector profile audit")
    ax.legend()
    fig.tight_layout()
    fig.savefig(OUTPUT_DIR / "holdout_profile_two_lobe_fit.pdf")
    fig.savefig(OUTPUT_DIR / "holdout_profile_two_lobe_fit.png", dpi=200)
    plt.close(fig)

    return {
        "profile_csv": str(profile_csv),
        "coordinate_column": s_col,
        "profile_column": y_col,
        "n_rows": int(len(s)),
        "optimizer_success": bool(fit.success),
        "r2": r2,
        "correlation": corr,
        "baseline": float(baseline),
        "early_mu": float(mue),
        "early_sigma": float(sige),
        "central_mu": float(muc),
        "central_sigma": float(sigc),
        "early_mass_fraction": early_mass / total_mass,
        "central_mass_fraction": central_mass / total_mass,
        "quality_pass": bool(r2 >= PROFILE_R2_MIN and corr >= PROFILE_CORR_MIN),
        "early_window_pass": bool(
            EARLY_CENTER_WINDOW[0] <= mue <= EARLY_CENTER_WINDOW[1]
        ),
        "central_window_pass": bool(
            CENTRAL_CENTER_WINDOW[0] <= muc <= CENTRAL_CENTER_WINDOW[1]
        ),
    }


# ============================================================================
# FIGURES, VERDICT, REPORT
# ============================================================================

def pca_figure(train_df, hold_df, atlas):
    t = train_df[train_df["atlas"] == atlas]
    h = hold_df[hold_df["atlas"] == atlas]
    fig, ax = plt.subplots(figsize=(8.2, 6.0))

    for family, group in t.groupby("family"):
        ax.scatter(group["pc1"], group["pc2"], label=f"training {family}")
        for _, row in group.iterrows():
            ax.annotate(row["ordering"], (row["pc1"], row["pc2"]), fontsize=8)

    for variant, group in h.groupby("variant"):
        ax.scatter(
            group["pc1"], group["pc2"],
            marker="X", s=90, label=f"holdout {variant}"
        )
        for _, row in group.iterrows():
            ax.annotate(row["ordering"], (row["pc1"], row["pc2"]), fontsize=8)

    ax.set_xlabel("frozen PC1")
    ax.set_ylabel("frozen PC2")
    ax.set_title(f"NuFIT 6.0 temporal holdout in frozen source atlas\n{atlas}")
    ax.legend(fontsize=8)
    fig.tight_layout()
    safe = atlas.replace("__", "_")
    fig.savefig(OUTPUT_DIR / f"pca_holdout_{safe}.pdf")
    fig.savefig(OUTPUT_DIR / f"pca_holdout_{safe}.png", dpi=200)
    plt.close(fig)


def envelope_figure(hold_df):
    pivot = hold_df.pivot_table(
        index="label",
        columns="atlas",
        values="nn_envelope_ratio",
        aggfunc="first",
    )
    ax = pivot.plot(kind="bar", figsize=(10.5, 5.4))
    ax.axhline(NN_ENVELOPE_FACTOR, linestyle="--", label="predeclared ceiling")
    ax.set_ylabel("holdout NN distance / maximum training NN distance")
    ax.set_title("Frozen source-atlas envelope ratios")
    ax.legend(fontsize=8)
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "holdout_nn_envelope_ratios.pdf")
    plt.savefig(OUTPUT_DIR / "holdout_nn_envelope_ratios.png", dpi=200)
    plt.close()


def derive_verdict(hold_df, ordering_df, null_df):
    """
    The two z-score atlases are the predeclared primary gates. Robust-scaling
    atlases are retained as sensitivity diagnostics, because the six-row
    development panel can have very small interquartile ranges in individual
    coordinates. Ridge-Mahalanobis scores are also reported as review flags,
    not as hard gates, because feature dimension exceeds sample size.
    """
    results = {}
    primary_atlases = {"zscore__signeddm", "zscore__absdm"}

    for variant in sorted(hold_df["variant"].unique()):
        h_all = hold_df[hold_df["variant"] == variant]
        h = h_all[h_all["atlas"].isin(primary_atlases)]

        o_all = ordering_df[
            (ordering_df["source_type"] == "holdout")
            & ordering_df["pair"].str.contains(variant, regex=False)
        ]
        o = o_all[o_all["atlas"].isin(primary_atlases)]

        n_all = null_df[
            (null_df["variant"] == variant)
            & (null_df["null_type"] == "semantic_coordinate_permutation")
        ]
        n = n_all[n_all["atlas"].isin(primary_atlases)]

        primary_nn_pass = bool(h["nn_pass"].all())
        primary_ordering_pass = (
            bool(o["ordering_alignment_pass"].all()) if len(o) else False
        )
        primary_null_significant = int(
            np.sum(n["empirical_lower_tail_p"] <= 0.05)
        )
        primary_maha_pass = bool(h["mahalanobis_pass"].all())

        if (
            primary_nn_pass
            and primary_ordering_pass
            and primary_null_significant == len(n)
        ):
            verdict = (
                "SOURCE_LEVEL_TEMPORAL_HOLDOUT_SUPPORTED"
                if primary_maha_pass
                else "SOURCE_LEVEL_TEMPORAL_HOLDOUT_SUPPORTED_WITH_ONE_CLASS_REVIEW"
            )
        elif primary_nn_pass and primary_ordering_pass:
            verdict = "SOURCE_LEVEL_COMPATIBLE_STRESS_TEST_NULL_NOT_SEPARATED"
        else:
            verdict = "SOURCE_LEVEL_EXTERNAL_STRESS_OR_FAILURE"

        results[variant] = {
            "verdict": verdict,
            "primary_atlases": sorted(primary_atlases),
            "primary_nn_tests_pass": primary_nn_pass,
            "primary_ordering_tests_pass": primary_ordering_pass,
            "primary_mahalanobis_tests_pass": primary_maha_pass,
            "primary_semantic_permutation_p_le_0p05_count": primary_null_significant,
            "primary_semantic_permutation_total_atlases": int(len(n)),
            "all_atlas_nn_tests_pass": bool(h_all["nn_pass"].all()),
            "all_atlas_mahalanobis_tests_pass": bool(
                h_all["mahalanobis_pass"].all()
            ),
            "all_atlas_ordering_tests_pass": bool(
                o_all["ordering_alignment_pass"].all()
            ) if len(o_all) else False,
            "max_primary_nn_envelope_ratio": float(
                h["nn_envelope_ratio"].max()
            ),
            "max_primary_mahalanobis_envelope_ratio": float(
                h["mahalanobis_envelope_ratio"].max()
            ),
            "minimum_primary_ordering_cosine": float(
                o["cosine_to_training_mean"].min()
            ) if len(o) else None,
            "minimum_all_atlas_ordering_cosine": float(
                o_all["cosine_to_training_mean"].min()
            ) if len(o_all) else None,
        }

    return {
        "variant_results": results,
        "claim_ceiling": (
            "These verdicts test frozen source geometry only. Downstream "
            "two-sector validation requires a regenerated holdout profile "
            "produced by the frozen QEG transformations."
        ),
        "verdict_policy": (
            "Primary gates use z-score signed/absolute atmospheric atlases. "
            "Robust-scaling and ridge-Mahalanobis results remain sensitivity "
            "diagnostics because the development panel has six rows in a "
            "seven-dimensional circular embedding."
        ),
    }


def write_report(verdict, hold_df, ordering_df, null_df, profile_summary):
    lines = [
        "=" * 78,
        "QEG EXTERNAL TEMPORAL HOLDOUT: NUFIT 6.0",
        "=" * 78,
        "",
    ]
    for variant, result in verdict["variant_results"].items():
        lines.extend(
            [
                f"{variant}: {result['verdict']}",
                f"  max primary NN envelope ratio          = "
                f"{result['max_primary_nn_envelope_ratio']:.6f}",
                f"  max primary Mahalanobis envelope ratio = "
                f"{result['max_primary_mahalanobis_envelope_ratio']:.6f}",
                f"  minimum primary ordering cosine        = "
                f"{result['minimum_primary_ordering_cosine']:.6f}",
                f"  primary semantic-null p<=0.05 atlases  = "
                f"{result['primary_semantic_permutation_p_le_0p05_count']}/"
                f"{result['primary_semantic_permutation_total_atlases']}",
                "",
            ]
        )

    lines.extend(
        [
            "CLAIM CEILING",
            "-------------",
            verdict["claim_ceiling"],
            "",
            "INTERPRETIVE NOTE",
            "-----------------",
            "IC19 without SK-atm is the cleaner temporal continuation of the",
            "historical PDG-2024 NuFIT source. IC24 with SK-atm is a stronger",
            "stress test because the atmospheric update shifts theta23 and the",
            "mass-ordering preference.",
            "",
            "HOLDOUT SCORES",
            "--------------",
            hold_df.to_string(index=False),
            "",
            "HOLDOUT ORDERING ALIGNMENT",
            "--------------------------",
            ordering_df[ordering_df["source_type"] == "holdout"].to_string(index=False),
            "",
            "NULL AUDIT",
            "----------",
            null_df.to_string(index=False),
            "",
        ]
    )

    if profile_summary is None:
        lines.extend(
            [
                "DOWNSTREAM TWO-SECTOR STATUS",
                "----------------------------",
                "No HOLDOUT_PROFILE_CSV was supplied. Full held-out validation",
                "of the two-sector law is therefore pending.",
            ]
        )
    else:
        lines.extend(
            [
                "DOWNSTREAM TWO-SECTOR STATUS",
                "----------------------------",
                json.dumps(profile_summary, indent=2),
            ]
        )

    (OUTPUT_DIR / "QEG_external_temporal_holdout_report.txt").write_text(
        "\n".join(lines), encoding="utf-8"
    )


# ============================================================================
# MAIN
# ============================================================================

def main():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(RANDOM_SEED)

    pd.DataFrame([asdict(r) for r in TRAINING_RECORDS]).to_csv(
        OUTPUT_DIR / "training_PDG2024_source_panel.csv", index=False
    )
    pd.DataFrame([asdict(r) for r in HOLDOUT_RECORDS]).to_csv(
        OUTPUT_DIR / "holdout_NuFIT6_source_panel.csv", index=False
    )

    train_parts = []
    hold_parts = []
    ordering_parts = []
    null_parts = []
    uncertainty_parts = []
    lofo_parts = []
    metadata = []

    for scaler in ("zscore", "robust"):
        for absolute_dm in (False, True):
            train_df, hold_df, ordering_df, null_df, meta = audit_atlas(
                scaler, absolute_dm, rng
            )
            train_parts.append(train_df)
            hold_parts.append(hold_df)
            ordering_parts.append(ordering_df)
            null_parts.append(null_df)
            uncertainty_parts.append(
                uncertainty_audit(rng, scaler, absolute_dm)
            )
            lofo_parts.append(leave_one_family_out(scaler, absolute_dm))
            metadata.append(meta)

    train_df = pd.concat(train_parts, ignore_index=True)
    hold_df = pd.concat(hold_parts, ignore_index=True)
    ordering_df = pd.concat(ordering_parts, ignore_index=True)
    null_df = pd.concat(null_parts, ignore_index=True)
    uncertainty_df = pd.concat(uncertainty_parts, ignore_index=True)
    lofo_df = pd.concat(lofo_parts, ignore_index=True)

    train_df.to_csv(OUTPUT_DIR / "frozen_training_atlas_scores.csv", index=False)
    hold_df.to_csv(OUTPUT_DIR / "temporal_holdout_atlas_scores.csv", index=False)
    ordering_df.to_csv(
        OUTPUT_DIR / "ordering_displacement_alignment.csv", index=False
    )
    null_df.to_csv(OUTPUT_DIR / "semantic_and_phase_nulls.csv", index=False)
    uncertainty_df.to_csv(
        OUTPUT_DIR / "uncertainty_monte_carlo_temporal_shift.csv", index=False
    )
    lofo_df.to_csv(
        OUTPUT_DIR / "leave_one_family_out_source_audit.csv", index=False
    )
    (OUTPUT_DIR / "atlas_metadata.json").write_text(
        json.dumps(metadata, indent=2), encoding="utf-8"
    )

    for atlas in sorted(train_df["atlas"].unique()):
        pca_figure(train_df, hold_df, atlas)
    envelope_figure(hold_df)

    profile_summary = None
    if HOLDOUT_PROFILE_CSV is not None:
        profile_path = Path(HOLDOUT_PROFILE_CSV)
        if not profile_path.is_absolute():
            profile_path = ROOT / profile_path
        if not profile_path.exists():
            raise FileNotFoundError(f"HOLDOUT_PROFILE_CSV not found: {profile_path}")
        profile_summary = downstream_profile_audit(profile_path)
        (OUTPUT_DIR / "holdout_profile_summary.json").write_text(
            json.dumps(profile_summary, indent=2), encoding="utf-8"
        )

    verdict = derive_verdict(hold_df, ordering_df, null_df)
    if profile_summary is not None:
        verdict["downstream_profile"] = profile_summary

    (OUTPUT_DIR / "verdict.json").write_text(
        json.dumps(verdict, indent=2), encoding="utf-8"
    )
    write_report(verdict, hold_df, ordering_df, null_df, profile_summary)

    print("=" * 78)
    print("QEG EXTERNAL TEMPORAL HOLDOUT COMPLETE")
    print("=" * 78)
    for variant, result in verdict["variant_results"].items():
        print(f"{variant}: {result['verdict']}")
    print(f"Outputs: {OUTPUT_DIR}")
    if profile_summary is None:
        print(
            "Source-level audit complete. Downstream two-sector validation "
            "remains pending HOLDOUT_PROFILE_CSV."
        )


if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
        raise
