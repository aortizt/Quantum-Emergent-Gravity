#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Stage-7F — Decoherence-Surrogate Audit and Experiment (v1)
===========================================================
Project: Quantum-Emergent Gravity (QEG)

Purpose
-------
This contemporary Spyder-friendly script coordinates three tasks:

  OPTION 2 — Retrospective evidence audit
      Locate existing QEG scripts/outputs containing operational ingredients
      relevant to decoherence-like behavior: transformation-selective
      admissibility, entropy, phase/null tests, forward/reverse asymmetry,
      inverse/adjoint recovery, low-rank contraction, and stable modes.

  OPTION 3 — Semantic/evidentiary tally
      Classify the recovered evidence by channel, preserve provenance, and
      produce a claim ladder from static sector selection to a possible
      decoherence-like surrogate. A keyword hit is never treated as proof.

  OPTION 4 — New Gram-density surrogate experiment
      Reuse family-aware QEG profiles and an existing nonlocal/operator matrix.
      Construct a positive-semidefinite trace-one ensemble Gram-density
      surrogate and test:

          C_l1(n) = sum_{i != j} |rho_ij(n)|
          P(n)    = tr[rho(n)^2]
          S(n)    = -tr[rho(n) log rho(n)]

      together with pointer-subspace stability, family consistency,
      forward/adjoint comparison, pseudoinverse echo recovery, and matched
      nulls.

Scientific boundary
-------------------
The constructed rho is an ensemble/Gram-density SURROGATE. It is not asserted
as a physical quantum density matrix. The script does not infer a physical
environment, a partial trace, or a quantum decoherence time. Its strongest
permitted positive tag is a decoherence-like/einselection-like candidate.

Default project root
--------------------
/home/dakini/Downloads/010-Quantum_Emergent_Gravity

Outputs
-------
metric_stage_7F_outputs/decoherence_surrogate_audit_v1/

The script is deterministic under RANDOM_SEED, single-process, and uses plain
CSV/JSON/TXT/PNG outputs.
"""

from __future__ import annotations

import argparse
import json
import logging
import math
import os
import re
import sys
import traceback
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

# Matplotlib is optional for the numerical audit, but normally available in
# the QEG environment. A missing installation does not stop CSV/JSON outputs.
try:
    import matplotlib.pyplot as plt
    HAVE_MATPLOTLIB = True
except Exception:
    HAVE_MATPLOTLIB = False


# ============================================================================
# USER CONFIGURATION — safe to edit in Spyder
# ============================================================================

PROJECT_ROOT_DEFAULT = Path(
    "/home/dakini/Downloads/010-Quantum_Emergent_Gravity"
)

OUTPUT_RELATIVE = Path(
    "metric_stage_7F_outputs/decoherence_surrogate_audit_v1"
)

RANDOM_SEED = 20260619
N_STEPS = 12
N_NULL_RUNS = 24
MAX_OPERATOR_DIM = 128
MAX_TEXT_FILE_MB = 12.0
MAX_CSV_INSPECTION_MB = 100.0
ECHO_STEPS = 5
POINTER_RANK = 3
EARLY_FRACTION = 0.20
CENTRAL_WINDOW = (0.35, 0.70)

# The manuscript-safe sentence explicitly approved for retention.
BASELINE_MANUSCRIPT_SENTENCE = (
    "The transformation-selective admissibility boundary is mathematically "
    "reminiscent of the sector pruning associated with decoherence-induced "
    "superselection: a common precursor support is reduced to a preferred "
    "admissible subset after radial standardization.  The analogy is "
    "structural only; no environment, quantum reduced state, or loss of "
    "off-diagonal phase coherence is inferred from the present calculation."
)


# ============================================================================
# DATA CLASSES
# ============================================================================

@dataclass
class AssetCandidate:
    path: str
    kind: str
    score: float
    size_bytes: int
    rows: Optional[int] = None
    cols: Optional[int] = None
    columns: Optional[str] = None
    reason: str = ""


@dataclass
class ProfileEnsemble:
    source_path: str
    coordinate_column: str
    value_column: str
    group_columns: List[str]
    labels: List[str]
    grid: np.ndarray
    states: np.ndarray       # shape: (n_states, n_grid)
    metadata: pd.DataFrame


@dataclass
class OperatorBundle:
    source_path: str
    matrix: np.ndarray
    original_shape: Tuple[int, int]
    original_spectral_radius: float
    original_spectral_norm: float
    numerical_rank: int
    asymmetry: float
    toeplitz_deviation: float


# ============================================================================
# LOGGING / SERIALIZATION
# ============================================================================

def setup_logging(output_dir: Path) -> logging.Logger:
    output_dir.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger("stage7F_decoherence")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()

    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    stream = logging.StreamHandler(sys.stdout)
    stream.setFormatter(formatter)
    logger.addHandler(stream)

    file_handler = logging.FileHandler(
        output_dir / "stage7F_execution.log", mode="w", encoding="utf-8"
    )
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    return logger


def json_safe(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        if not np.isfinite(value):
            return None
        return float(value)
    if isinstance(value, np.ndarray):
        return [json_safe(v) for v in value.tolist()]
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(v) for v in value]
    if isinstance(value, pd.Timestamp):
        return value.isoformat()
    if pd.isna(value) if not isinstance(value, (str, bytes)) else False:
        return None
    return value


def write_json(path: Path, payload: Dict[str, Any]) -> None:
    with path.open("w", encoding="utf-8") as handle:
        json.dump(json_safe(payload), handle, indent=2, ensure_ascii=False)


def atomic_to_csv(df: pd.DataFrame, path: Path) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    df.to_csv(tmp, index=False)
    tmp.replace(path)


# ============================================================================
# GENERAL UTILITIES
# ============================================================================

def normalize_name(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(name).strip().lower()).strip("_")


def safe_read_text(path: Path, max_mb: float = MAX_TEXT_FILE_MB) -> Optional[str]:
    try:
        if path.stat().st_size > max_mb * 1024 * 1024:
            return None
        for encoding in ("utf-8", "utf-8-sig", "latin-1"):
            try:
                return path.read_text(encoding=encoding, errors="strict")
            except UnicodeDecodeError:
                continue
        return path.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return None


def safe_read_csv(path: Path, nrows: Optional[int] = None) -> Optional[pd.DataFrame]:
    options = [
        {"sep": ","},
        {"sep": None, "engine": "python"},
        {"sep": "\t"},
        {"sep": ";"},
    ]
    for opts in options:
        for encoding in ("utf-8", "utf-8-sig", "latin-1"):
            try:
                return pd.read_csv(
                    path,
                    nrows=nrows,
                    encoding=encoding,
                    low_memory=False,
                    **opts,
                )
            except Exception:
                continue
    return None


def numeric_frame(df: pd.DataFrame) -> pd.DataFrame:
    result = pd.DataFrame(index=df.index)
    for col in df.columns:
        converted = pd.to_numeric(df[col], errors="coerce")
        if converted.notna().mean() >= 0.80:
            result[col] = converted
    return result


def l2_normalize_rows(matrix: np.ndarray, eps: float = 1e-15) -> np.ndarray:
    matrix = np.asarray(matrix, dtype=float)
    norms = np.linalg.norm(matrix, axis=1, keepdims=True)
    norms = np.where(norms > eps, norms, 1.0)
    return matrix / norms


def l2_normalize(vector: np.ndarray, eps: float = 1e-15) -> np.ndarray:
    vector = np.asarray(vector, dtype=float)
    norm = float(np.linalg.norm(vector))
    return vector / norm if norm > eps else vector.copy()


def interpolate_vector(vector: np.ndarray, new_n: int) -> np.ndarray:
    vector = np.asarray(vector, dtype=float)
    if len(vector) == new_n:
        return vector.copy()
    old_x = np.linspace(0.0, 1.0, len(vector))
    new_x = np.linspace(0.0, 1.0, new_n)
    return np.interp(new_x, old_x, vector)


def finite_or_nan(value: Any) -> float:
    try:
        out = float(value)
        return out if np.isfinite(out) else float("nan")
    except Exception:
        return float("nan")


def canonical_family(value: Any) -> str:
    text = str(value).upper()
    if "BARI" in text:
        return "BARI"
    if "NUFIT" in text or "NU_FIT" in text:
        return "NUFIT"
    if "VALENCIA" in text:
        return "VALENCIA"
    if "POOL" in text:
        return "POOLED"
    return str(value)


# ============================================================================
# BRANCH 1 — PROJECT INVENTORY AND SEMANTIC EVIDENCE AUDIT
# ============================================================================

CHANNEL_PATTERNS: Dict[str, List[str]] = {
    "static_sector_selection": [
        r"admissib", r"obstruction", r"symmetry.?break", r"sector pruning",
        r"square.?root argument", r"logarithmic argument", r"radial standard",
        r"superselection", r"transformation.?selective",
    ],
    "coherence_phase": [
        r"coherence", r"off.?diagonal", r"phase random", r"phase scramble",
        r"interference", r"dephas", r"coherent",
    ],
    "entropy_information": [
        r"entropy", r"kullback", r"\bkl\b", r"information.?geometr",
        r"purity", r"mixedness", r"divergence", r"contraction",
    ],
    "reversibility_echo": [
        r"forward.?reverse", r"reverse", r"adjoint", r"pseudoinverse",
        r"inverse recovery", r"echo", r"irreversib", r"reversib",
    ],
    "pointer_mode_stability": [
        r"pointer", r"stable basis", r"eigenvector stabil", r"dominant mode",
        r"low.?rank", r"family.?universal", r"attractor", r"mode retention",
    ],
    "environment_reduced_state": [
        r"environment", r"partial trace", r"reduced density", r"open quantum",
        r"system.?environment", r"hilbert space",
    ],
    "low_k_collective": [
        r"low.?k", r"spectral overlap", r"collective mode", r"spectral entropy",
    ],
}

TEXT_SUFFIXES = {".py", ".txt", ".md", ".tex", ".json", ".yaml", ".yml"}
DATA_SUFFIXES = {".csv", ".json", ".npz", ".npy"}


def inventory_project(root: Path, output_dir: Path, logger: logging.Logger) -> pd.DataFrame:
    records: List[Dict[str, Any]] = []
    output_resolved = output_dir.resolve()
    for path in sorted(root.rglob("*")):
        try:
            if not path.is_file():
                continue
            resolved = path.resolve()
            if output_resolved == resolved or output_resolved in resolved.parents:
                continue
            stat = path.stat()
            records.append({
                "relative_path": str(path.relative_to(root)),
                "absolute_path": str(path),
                "suffix": path.suffix.lower(),
                "size_bytes": stat.st_size,
                "size_mb": stat.st_size / (1024 * 1024),
            })
        except Exception:
            continue
    df = pd.DataFrame(records)
    atomic_to_csv(df, output_dir / "stage7F_project_file_inventory.csv")
    logger.info("Inventory complete: %d files", len(df))
    return df


def semantic_context_audit(
    root: Path,
    inventory: pd.DataFrame,
    output_dir: Path,
    logger: logging.Logger,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    hits: List[Dict[str, Any]] = []

    for record in inventory.to_dict("records"):
        path = Path(record["absolute_path"])
        suffix = path.suffix.lower()
        if suffix not in TEXT_SUFFIXES:
            continue
        text = safe_read_text(path)
        if not text:
            continue
        lines = text.splitlines()
        for line_no, line in enumerate(lines, start=1):
            lower = line.lower()
            for channel, patterns in CHANNEL_PATTERNS.items():
                matched = [p for p in patterns if re.search(p, lower, flags=re.I)]
                if not matched:
                    continue
                start = max(0, line_no - 2)
                end = min(len(lines), line_no + 1)
                context = " ".join(part.strip() for part in lines[start:end] if part.strip())
                hits.append({
                    "channel": channel,
                    "relative_path": record["relative_path"],
                    "line_number": line_no,
                    "matched_patterns": " | ".join(matched),
                    "line": line.strip()[:1000],
                    "context": context[:2500],
                })

    hits_df = pd.DataFrame(hits)
    if hits_df.empty:
        hits_df = pd.DataFrame(columns=[
            "channel", "relative_path", "line_number", "matched_patterns",
            "line", "context",
        ])

    tally_df = (
        hits_df.groupby("channel", dropna=False)
        .agg(
            hit_count=("channel", "size"),
            file_count=("relative_path", "nunique"),
        )
        .reset_index()
        .sort_values(["hit_count", "file_count"], ascending=False)
    )

    atomic_to_csv(hits_df, output_dir / "stage7F_semantic_context_hits.csv")
    atomic_to_csv(tally_df, output_dir / "stage7F_semantic_channel_tally.csv")
    logger.info("Semantic audit: %d contextual hits across %d channels", len(hits_df), len(tally_df))
    return hits_df, tally_df


# ============================================================================
# BRANCH 2 — TRANSFORMATION-SELECTIVE ADMISSIBILITY AUDIT
# ============================================================================

ADMISSIBILITY_NAMES = {
    "admissible", "is_admissible", "valid", "is_valid", "accepted", "pass",
    "admissibility", "status", "verdict",
}
METRIC_NAMES = {
    "metric", "metric_family", "construction", "metric_construction",
    "geometry", "metric_type", "candidate_metric",
}
TRANSFORM_NAMES = {
    "transformation", "transform", "transform_class", "transformation_class",
    "standardization", "coordinate_transform", "map_class",
}
OBSTRUCTION_NAMES = {
    "obstruction", "failure_reason", "reason", "invalid_reason", "domain_error",
    "notes", "diagnostic",
}
FAMILY_NAMES = {
    "family", "source_family", "fit", "fit_id", "dataset", "lineage",
}


def find_column(df: pd.DataFrame, aliases: Iterable[str]) -> Optional[str]:
    normalized = {normalize_name(c): c for c in df.columns}
    for alias in aliases:
        if alias in normalized:
            return normalized[alias]
    for norm, original in normalized.items():
        if any(alias in norm for alias in aliases):
            return original
    return None


def parse_admissible(value: Any) -> Optional[bool]:
    if isinstance(value, (bool, np.bool_)):
        return bool(value)
    if isinstance(value, (int, float, np.integer, np.floating)) and np.isfinite(value):
        return bool(int(value))
    text = normalize_name(value)
    if text in {"true", "yes", "y", "1", "pass", "passed", "accepted", "admissible", "valid", "ok"}:
        return True
    if text in {"false", "no", "n", "0", "fail", "failed", "rejected", "inadmissible", "invalid", "error"}:
        return False
    if "inadmiss" in text or "invalid" in text or "fail" in text or "reject" in text:
        return False
    if "admiss" in text or "valid" in text or "pass" in text or "accept" in text:
        return True
    return None


def canonical_metric(value: Any) -> str:
    text = normalize_name(value)
    if "log" in text and "rad" in text:
        return "logarithmic_radial"
    if "radial" in text and ("weight" in text or "weighted" in text):
        return "radial_weighted"
    if "hybrid" in text:
        return "hybrid"
    if "euclid" in text:
        return "euclidean"
    return text or "unknown"


def audit_admissibility(
    root: Path,
    inventory: pd.DataFrame,
    output_dir: Path,
    logger: logging.Logger,
) -> Tuple[pd.DataFrame, pd.DataFrame, Dict[str, Any]]:
    raw_rows: List[Dict[str, Any]] = []

    csv_records = inventory[inventory["suffix"] == ".csv"].to_dict("records")
    for record in csv_records:
        path = Path(record["absolute_path"])
        if record["size_mb"] > MAX_CSV_INSPECTION_MB:
            continue
        header = safe_read_csv(path, nrows=8)
        if header is None or header.empty:
            continue
        adm_col = find_column(header, ADMISSIBILITY_NAMES)
        metric_col = find_column(header, METRIC_NAMES)
        transform_col = find_column(header, TRANSFORM_NAMES)
        obstruction_col = find_column(header, OBSTRUCTION_NAMES)
        family_col = find_column(header, FAMILY_NAMES)

        # Require at least an admissibility/status field and one structural field.
        if adm_col is None or (metric_col is None and transform_col is None):
            continue
        full = safe_read_csv(path)
        if full is None or full.empty:
            continue
        for idx, row in full.iterrows():
            admissible = parse_admissible(row.get(adm_col))
            if admissible is None:
                continue
            raw_rows.append({
                "source_file": str(path.relative_to(root)),
                "source_row": int(idx),
                "metric_raw": row.get(metric_col) if metric_col else "",
                "metric": canonical_metric(row.get(metric_col)) if metric_col else "unknown",
                "transformation": str(row.get(transform_col)) if transform_col else "unknown",
                "family": canonical_family(row.get(family_col)) if family_col else "UNKNOWN",
                "admissible": admissible,
                "obstruction": str(row.get(obstruction_col)) if obstruction_col else "",
            })

    raw_df = pd.DataFrame(raw_rows)
    if raw_df.empty:
        raw_df = pd.DataFrame(columns=[
            "source_file", "source_row", "metric_raw", "metric", "transformation",
            "family", "admissible", "obstruction",
        ])
        summary_df = pd.DataFrame(columns=[
            "metric", "total", "admissible_count", "inadmissible_count",
            "admissible_fraction", "transformation_classes", "families",
        ])
        status = {
            "table_found": False,
            "categorical_split_found": False,
            "expected_27_27_0_0_pattern_found": False,
            "notes": "No machine-readable admissibility table was identified.",
        }
    else:
        summary_df = (
            raw_df.groupby("metric", dropna=False)
            .agg(
                total=("admissible", "size"),
                admissible_count=("admissible", "sum"),
                transformation_classes=("transformation", "nunique"),
                families=("family", "nunique"),
            )
            .reset_index()
        )
        summary_df["inadmissible_count"] = summary_df["total"] - summary_df["admissible_count"]
        summary_df["admissible_fraction"] = summary_df["admissible_count"] / summary_df["total"]
        summary_df = summary_df[[
            "metric", "total", "admissible_count", "inadmissible_count",
            "admissible_fraction", "transformation_classes", "families",
        ]].sort_values("metric")

        fractions = summary_df.set_index("metric")["admissible_fraction"].to_dict()
        categorical = (
            len(summary_df) >= 2
            and any(v >= 0.95 for v in fractions.values())
            and any(v <= 0.05 for v in fractions.values())
        )
        counts = summary_df.set_index("metric")[["admissible_count", "total"]].to_dict("index")
        expected = all(
            key in counts
            for key in ["euclidean", "radial_weighted", "hybrid", "logarithmic_radial"]
        )
        if expected:
            expected = (
                counts["euclidean"]["admissible_count"] == 27
                and counts["radial_weighted"]["admissible_count"] == 27
                and counts["hybrid"]["admissible_count"] == 0
                and counts["logarithmic_radial"]["admissible_count"] == 0
            )
        status = {
            "table_found": True,
            "categorical_split_found": bool(categorical),
            "expected_27_27_0_0_pattern_found": bool(expected),
            "source_files": sorted(raw_df["source_file"].unique().tolist()),
            "obstruction_examples": sorted(
                {x for x in raw_df.loc[~raw_df["admissible"], "obstruction"].astype(str) if x and x != "nan"}
            )[:30],
        }

    atomic_to_csv(raw_df, output_dir / "stage7F_admissibility_rows.csv")
    atomic_to_csv(summary_df, output_dir / "stage7F_admissibility_summary.csv")
    write_json(output_dir / "stage7F_admissibility_status.json", status)
    logger.info(
        "Admissibility audit: rows=%d, categorical_split=%s",
        len(raw_df), status.get("categorical_split_found"),
    )
    return raw_df, summary_df, status


# ============================================================================
# BRANCH 3 — PROFILE / OPERATOR ASSET DISCOVERY
# ============================================================================

COORDINATE_ALIASES = [
    "s", "intrinsic_s", "intrinsic_coordinate", "coordinate", "bin_center",
    "grid", "x", "position", "normalized_s",
]
VALUE_ALIASES = [
    "rho", "rho_like", "rho_q", "density", "profile", "value", "signal",
    "weight", "amplitude", "observable", "response",
]
GROUP_ALIASES = [
    "family", "source_family", "fit", "fit_id", "dataset", "lineage",
    "metric", "metric_family", "transformation", "transform", "variant",
    "ordering", "resolution",
]


def profile_candidate_score(path: Path, df: pd.DataFrame) -> Tuple[float, str]:
    name = path.name.lower()
    score = 0.0
    reasons: List[str] = []
    coord = find_column(df, COORDINATE_ALIASES)
    value = find_column(df, VALUE_ALIASES)
    family = find_column(df, FAMILY_NAMES)

    if coord:
        score += 3.0
        reasons.append(f"coordinate={coord}")
    if value:
        score += 4.0
        reasons.append(f"value={value}")
    if family:
        score += 5.0
        reasons.append(f"family={family}")
    for token, pts in [
        ("family_aware", 7), ("stage6p", 5), ("stage6q", 5), ("stage6o", 4),
        ("profile", 4), ("rho", 3), ("canonical", 2), ("361", 1), ("48", 1),
    ]:
        if token in name:
            score += pts
            reasons.append(token)
    num = numeric_frame(df)
    if num.shape[1] >= 2:
        score += 1.0
    return score, "; ".join(reasons)


def operator_candidate_score(path: Path, numeric: pd.DataFrame) -> Tuple[float, str]:
    name = path.name.lower()
    score = 0.0
    reasons: List[str] = []
    for token, pts in [
        ("kernel_matrix_best", 10), ("operator_matrix", 9), ("transition_matrix", 9),
        ("propagator", 8), ("transport_matrix", 8), ("kernel", 6),
        ("operator", 5), ("matrix", 3), ("stage6j", 5), ("stage6k", 4),
        ("stage6y", 3), ("stage7c", 3),
    ]:
        if token in name:
            score += pts
            reasons.append(token)
    rows, cols = numeric.shape
    if rows == cols and rows >= 4:
        score += 8
        reasons.append(f"square={rows}")
    elif abs(rows - cols) <= 1 and min(rows, cols) >= 4:
        score += 3
        reasons.append(f"near_square={rows}x{cols}")
    return score, "; ".join(reasons)


def discover_assets(
    root: Path,
    inventory: pd.DataFrame,
    output_dir: Path,
    logger: logging.Logger,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    profile_records: List[Dict[str, Any]] = []
    operator_records: List[Dict[str, Any]] = []

    for record in inventory[inventory["suffix"] == ".csv"].to_dict("records"):
        path = Path(record["absolute_path"])
        if record["size_mb"] > MAX_CSV_INSPECTION_MB:
            continue
        sample = safe_read_csv(path, nrows=80)
        if sample is None or sample.empty:
            continue

        p_score, p_reason = profile_candidate_score(path, sample)
        if p_score >= 4:
            profile_records.append(asdict(AssetCandidate(
                path=str(path),
                kind="profile",
                score=p_score,
                size_bytes=int(record["size_bytes"]),
                rows=None,
                cols=len(sample.columns),
                columns=" | ".join(map(str, sample.columns)),
                reason=p_reason,
            )))

        num = numeric_frame(sample)
        o_score, o_reason = operator_candidate_score(path, num)
        if o_score >= 8:
            operator_records.append(asdict(AssetCandidate(
                path=str(path),
                kind="operator",
                score=o_score,
                size_bytes=int(record["size_bytes"]),
                rows=len(sample),
                cols=num.shape[1],
                columns=" | ".join(map(str, num.columns)),
                reason=o_reason,
            )))

    profiles = pd.DataFrame(profile_records)
    operators = pd.DataFrame(operator_records)
    if not profiles.empty:
        profiles = profiles.sort_values(["score", "size_bytes"], ascending=[False, True])
    if not operators.empty:
        operators = operators.sort_values(["score", "size_bytes"], ascending=[False, True])

    atomic_to_csv(profiles, output_dir / "stage7F_profile_asset_candidates.csv")
    atomic_to_csv(operators, output_dir / "stage7F_operator_asset_candidates.csv")
    logger.info("Asset discovery: %d profile candidates, %d operator candidates", len(profiles), len(operators))
    return profiles, operators


def choose_value_column(df: pd.DataFrame, coordinate_col: Optional[str]) -> Optional[str]:
    normalized = {normalize_name(c): c for c in df.columns}
    for alias in VALUE_ALIASES:
        if alias in normalized and normalized[alias] != coordinate_col:
            return normalized[alias]
    # Fuzzy preference.
    for norm, original in normalized.items():
        if original == coordinate_col:
            continue
        if any(alias in norm for alias in VALUE_ALIASES):
            if pd.to_numeric(df[original], errors="coerce").notna().mean() >= 0.70:
                return original
    # Numeric fallback with highest nonconstant variance.
    candidates: List[Tuple[float, str]] = []
    for col in df.columns:
        if col == coordinate_col:
            continue
        series = pd.to_numeric(df[col], errors="coerce")
        if series.notna().mean() >= 0.80:
            variance = float(series.var(skipna=True))
            if np.isfinite(variance) and variance > 0:
                candidates.append((variance, col))
    return max(candidates)[1] if candidates else None


def build_profile_ensemble(path: Path, logger: logging.Logger) -> ProfileEnsemble:
    df = safe_read_csv(path)
    if df is None or df.empty:
        raise ValueError(f"Could not read profile candidate: {path}")

    coordinate_col = find_column(df, COORDINATE_ALIASES)
    if coordinate_col is None:
        raise ValueError("No intrinsic-coordinate-like column was found")
    value_col = choose_value_column(df, coordinate_col)
    if value_col is None:
        raise ValueError("No profile/value column was found")

    candidate_groups: List[str] = []
    normalized_cols = {normalize_name(c): c for c in df.columns}
    # Family first, then metric/transformation/variant where informative.
    for alias in GROUP_ALIASES:
        col = normalized_cols.get(alias)
        if col and col not in candidate_groups:
            n_unique = df[col].nunique(dropna=True)
            if 1 < n_unique <= 100:
                candidate_groups.append(col)
    # Fuzzy family recovery.
    if not any("family" in normalize_name(c) or normalize_name(c) in {"fit", "fit_id"} for c in candidate_groups):
        fam = find_column(df, FAMILY_NAMES)
        if fam and fam not in candidate_groups and 1 < df[fam].nunique(dropna=True) <= 100:
            candidate_groups.insert(0, fam)

    # Avoid exploding into one group per row.
    group_cols = candidate_groups[:3]
    work = df.copy()
    work[coordinate_col] = pd.to_numeric(work[coordinate_col], errors="coerce")
    work[value_col] = pd.to_numeric(work[value_col], errors="coerce")
    work = work.dropna(subset=[coordinate_col, value_col])

    if not group_cols:
        # Fall back to one state per numeric value column, if possible.
        numeric_cols = [
            c for c in df.columns
            if c != coordinate_col and pd.to_numeric(df[c], errors="coerce").notna().mean() >= 0.80
        ]
        if len(numeric_cols) < 2:
            raise ValueError("Profile table has neither grouping labels nor multiple numeric profile columns")
        coord = pd.to_numeric(df[coordinate_col], errors="coerce")
        valid = coord.notna()
        x = coord[valid].to_numpy(dtype=float)
        order = np.argsort(x)
        x = x[order]
        grid = np.linspace(float(np.nanmin(x)), float(np.nanmax(x)), len(np.unique(x)))
        states = []
        labels = []
        metadata_rows = []
        for col in numeric_cols:
            y = pd.to_numeric(df.loc[valid, col], errors="coerce").to_numpy(dtype=float)[order]
            mask = np.isfinite(x) & np.isfinite(y)
            if mask.sum() < 4:
                continue
            states.append(np.interp(grid, x[mask], y[mask]))
            labels.append(str(col))
            metadata_rows.append({"label": str(col), "family": canonical_family(col)})
        if len(states) < 2:
            raise ValueError("Could not construct at least two profile states")
        matrix = l2_normalize_rows(np.vstack(states))
        return ProfileEnsemble(
            source_path=str(path), coordinate_column=coordinate_col,
            value_column="multiple_numeric_columns", group_columns=[], labels=labels,
            grid=grid, states=matrix, metadata=pd.DataFrame(metadata_rows),
        )

    grouped = list(work.groupby(group_cols, dropna=False, sort=True))
    # Determine common intrinsic grid from overlap where possible.
    mins, maxs, lengths = [], [], []
    for _, group in grouped:
        x = group[coordinate_col].to_numpy(dtype=float)
        if len(np.unique(x)) >= 4:
            mins.append(float(np.nanmin(x)))
            maxs.append(float(np.nanmax(x)))
            lengths.append(len(np.unique(x)))
    if not lengths:
        raise ValueError("No group has enough coordinate points")
    lo = max(mins)
    hi = min(maxs)
    if not np.isfinite(lo) or not np.isfinite(hi) or hi <= lo:
        lo = min(mins)
        hi = max(maxs)
    n_grid = int(np.median(lengths))
    n_grid = max(8, min(n_grid, 1024))
    grid = np.linspace(lo, hi, n_grid)

    states: List[np.ndarray] = []
    labels: List[str] = []
    metadata_rows: List[Dict[str, Any]] = []
    for key, group in grouped:
        key_tuple = key if isinstance(key, tuple) else (key,)
        x = group[coordinate_col].to_numpy(dtype=float)
        y = group[value_col].to_numpy(dtype=float)
        order = np.argsort(x)
        x, y = x[order], y[order]
        # Average duplicate coordinates.
        local = pd.DataFrame({"x": x, "y": y}).groupby("x", as_index=False)["y"].mean()
        x, y = local["x"].to_numpy(), local["y"].to_numpy()
        if len(x) < 4:
            continue
        state = np.interp(grid, x, y)
        if not np.all(np.isfinite(state)) or np.linalg.norm(state) <= 1e-15:
            continue
        label_parts = [f"{col}={val}" for col, val in zip(group_cols, key_tuple)]
        label = " | ".join(label_parts)
        meta = {col: val for col, val in zip(group_cols, key_tuple)}
        meta["label"] = label
        family_value = next(
            (val for col, val in zip(group_cols, key_tuple)
             if "family" in normalize_name(col) or normalize_name(col) in {"fit", "fit_id"}),
            label,
        )
        meta["family"] = canonical_family(family_value)
        states.append(state)
        labels.append(label)
        metadata_rows.append(meta)

    if len(states) < 2:
        raise ValueError("Fewer than two valid grouped profile states were constructed")

    matrix = l2_normalize_rows(np.vstack(states))
    logger.info(
        "Profile ensemble built from %s: states=%d, grid=%d, groups=%s, value=%s",
        path.name, matrix.shape[0], matrix.shape[1], group_cols, value_col,
    )
    return ProfileEnsemble(
        source_path=str(path), coordinate_column=coordinate_col,
        value_column=value_col, group_columns=group_cols, labels=labels,
        grid=grid, states=matrix, metadata=pd.DataFrame(metadata_rows),
    )


def clean_square_matrix(df: pd.DataFrame) -> Optional[np.ndarray]:
    num = numeric_frame(df).dropna(axis=0, how="all").dropna(axis=1, how="all")
    if num.empty:
        return None
    arr = num.to_numpy(dtype=float)
    # Drop a monotone index-like first column when it makes the remainder square.
    if arr.shape[1] == arr.shape[0] + 1:
        first = arr[:, 0]
        if np.all(np.isfinite(first)) and (
            np.allclose(first, np.arange(len(first)), atol=1e-8)
            or np.allclose(first, np.arange(1, len(first) + 1), atol=1e-8)
        ):
            arr = arr[:, 1:]
    if arr.shape[0] == arr.shape[1] and arr.shape[0] >= 4 and np.all(np.isfinite(arr)):
        return arr
    return None


def spectral_radius(matrix: np.ndarray) -> float:
    try:
        values = np.linalg.eigvals(matrix)
        return float(np.max(np.abs(values)))
    except Exception:
        return float("nan")


def toeplitz_deviation(matrix: np.ndarray) -> float:
    n = matrix.shape[0]
    toeplitz = np.zeros_like(matrix, dtype=float)
    for offset in range(-(n - 1), n):
        diag = np.diag(matrix, k=offset)
        mean = float(np.mean(diag)) if len(diag) else 0.0
        if offset >= 0:
            i = np.arange(0, n - offset)
            toeplitz[i, i + offset] = mean
        else:
            i = np.arange(0, n + offset)
            toeplitz[i - offset, i] = mean
    denom = np.linalg.norm(matrix, ord="fro")
    return float(np.linalg.norm(matrix - toeplitz, ord="fro") / denom) if denom > 0 else float("nan")


def build_operator_bundle(path: Path, logger: logging.Logger) -> OperatorBundle:
    df = safe_read_csv(path)
    if df is None or df.empty:
        raise ValueError(f"Could not read operator candidate: {path}")
    matrix = clean_square_matrix(df)
    if matrix is None:
        raise ValueError(f"Candidate is not a usable square numeric matrix: {path}")

    # Limit dimension without altering broad operator geometry: use linear
    # interpolation of rows/columns when a very large matrix is encountered.
    original_shape = matrix.shape
    if matrix.shape[0] > MAX_OPERATOR_DIM:
        old = np.linspace(0, 1, matrix.shape[0])
        new = np.linspace(0, 1, MAX_OPERATOR_DIM)
        row_resampled = np.vstack([np.interp(new, old, row) for row in matrix])
        matrix = np.vstack([np.interp(new, old, row_resampled[:, j]) for j in range(row_resampled.shape[1])]).T

    svals = np.linalg.svd(matrix, compute_uv=False)
    norm2 = float(svals[0]) if len(svals) else 0.0
    if norm2 <= 1e-15:
        raise ValueError("Operator matrix is numerically zero")
    stable = matrix / norm2
    asym = float(np.linalg.norm(matrix - matrix.T, ord="fro") / np.linalg.norm(matrix, ord="fro"))
    rank = int(np.linalg.matrix_rank(matrix))
    bundle = OperatorBundle(
        source_path=str(path),
        matrix=stable,
        original_shape=original_shape,
        original_spectral_radius=spectral_radius(matrix),
        original_spectral_norm=norm2,
        numerical_rank=rank,
        asymmetry=asym,
        toeplitz_deviation=toeplitz_deviation(matrix),
    )
    logger.info(
        "Operator loaded from %s: shape=%s -> %s, rank=%d, asymmetry=%.4g",
        path.name, original_shape, stable.shape, rank, asym,
    )
    return bundle


def select_usable_assets(
    profile_candidates: pd.DataFrame,
    operator_candidates: pd.DataFrame,
    logger: logging.Logger,
) -> Tuple[ProfileEnsemble, OperatorBundle, pd.DataFrame]:
    attempts: List[Dict[str, Any]] = []
    ensemble: Optional[ProfileEnsemble] = None
    operator: Optional[OperatorBundle] = None

    for record in profile_candidates.to_dict("records"):
        path = Path(record["path"])
        try:
            candidate = build_profile_ensemble(path, logger)
            attempts.append({"kind": "profile", "path": str(path), "success": True, "message": "selected"})
            ensemble = candidate
            break
        except Exception as exc:
            attempts.append({"kind": "profile", "path": str(path), "success": False, "message": str(exc)})

    for record in operator_candidates.to_dict("records"):
        path = Path(record["path"])
        try:
            candidate = build_operator_bundle(path, logger)
            attempts.append({"kind": "operator", "path": str(path), "success": True, "message": "selected"})
            operator = candidate
            break
        except Exception as exc:
            attempts.append({"kind": "operator", "path": str(path), "success": False, "message": str(exc)})

    attempts_df = pd.DataFrame(attempts)
    if ensemble is None:
        raise RuntimeError("No usable family/profile ensemble could be constructed")
    if operator is None:
        raise RuntimeError("No usable pre-existing QEG operator matrix could be loaded")
    return ensemble, operator, attempts_df


# ============================================================================
# BRANCH 4 — GRAM-DENSITY SURROGATE EXPERIMENT
# ============================================================================

def density_surrogate(states: np.ndarray, weights: Optional[np.ndarray] = None) -> np.ndarray:
    states = l2_normalize_rows(states)
    m, n = states.shape
    if weights is None:
        weights = np.full(m, 1.0 / m)
    weights = np.asarray(weights, dtype=float)
    weights = np.maximum(weights, 0)
    weights = weights / weights.sum() if weights.sum() > 0 else np.full(m, 1.0 / m)
    rho = np.zeros((n, n), dtype=float)
    for weight, state in zip(weights, states):
        rho += weight * np.outer(state, state)
    rho = 0.5 * (rho + rho.T)
    trace = float(np.trace(rho))
    return rho / trace if trace > 1e-15 else rho


def density_metrics(
    rho: np.ndarray,
    states: Optional[np.ndarray] = None,
) -> Dict[str, float]:
    rho = 0.5 * (rho + rho.T)
    n = rho.shape[0]
    # The nonzero eigenvalues of rho = X^T X / m equal those of the
    # much smaller Gram matrix X X^T / m. Using the latter keeps this
    # audit practical on the user's older single-process workstation.
    if states is not None and len(states) > 0:
        normalized_states = l2_normalize_rows(states)
        gram_small = (normalized_states @ normalized_states.T) / len(normalized_states)
        eigvals = np.linalg.eigvalsh(0.5 * (gram_small + gram_small.T))
    else:
        eigvals = np.linalg.eigvalsh(rho)
    eigvals = np.clip(eigvals, 0.0, None)
    if eigvals.sum() > 0:
        eigvals = eigvals / eigvals.sum()
    positive = eigvals[eigvals > 1e-15]
    entropy_raw = float(-np.sum(positive * np.log(positive))) if len(positive) else 0.0
    entropy_norm = entropy_raw / math.log(n) if n > 1 else 0.0
    purity = float(np.sum(eigvals ** 2))
    effective_rank = float(np.exp(entropy_raw))
    offdiag = rho - np.diag(np.diag(rho))
    coherence_l1_raw = float(np.sum(np.abs(offdiag)))
    coherence_l1_norm = coherence_l1_raw / max(n - 1, 1)
    offdiag_fro = float(np.linalg.norm(offdiag, ord="fro"))
    total_fro = float(np.linalg.norm(rho, ord="fro"))
    diagonal = np.clip(np.diag(rho), 0, None)
    diagonal = diagonal / diagonal.sum() if diagonal.sum() > 0 else diagonal
    positive_diag = diagonal[diagonal > 1e-15]
    diagonal_entropy = float(-np.sum(positive_diag * np.log(positive_diag)))
    diagonal_entropy_norm = diagonal_entropy / math.log(n) if n > 1 else 0.0
    return {
        "coherence_l1_raw": coherence_l1_raw,
        "coherence_l1_norm": coherence_l1_norm,
        "purity": purity,
        "von_neumann_entropy": entropy_raw,
        "von_neumann_entropy_norm": entropy_norm,
        "effective_rank": effective_rank,
        "offdiag_fro_fraction": offdiag_fro / total_fro if total_fro > 0 else float("nan"),
        "diagonal_entropy_norm": diagonal_entropy_norm,
        "largest_eigenvalue": float(eigvals[-1]) if len(eigvals) else float("nan"),
    }


def state_coordinate_metrics(state: np.ndarray) -> Dict[str, float]:
    state = l2_normalize(state)
    probabilities = state ** 2
    probabilities = probabilities / probabilities.sum() if probabilities.sum() > 0 else probabilities
    positive = probabilities[probabilities > 1e-15]
    shannon = float(-np.sum(positive * np.log(positive))) if len(positive) else 0.0
    n = len(state)
    coherence = float((np.sum(np.abs(state)) ** 2 - 1.0) / max(n - 1, 1))
    return {
        "state_coherence_l1_norm": coherence,
        "state_coordinate_entropy_norm": shannon / math.log(n) if n > 1 else 0.0,
        "state_inverse_participation": float(np.sum(probabilities ** 2)),
    }


def top_subspace_from_states(states: np.ndarray, rank: int) -> np.ndarray:
    normalized_states = l2_normalize_rows(states)
    # Columns of U span the nonzero eigenspace of the ensemble density
    # surrogate without diagonalizing an n x n matrix.
    u, _s, _vt = np.linalg.svd(normalized_states.T, full_matrices=False)
    rank = max(1, min(rank, u.shape[1]))
    return u[:, :rank]


def subspace_overlap(a: np.ndarray, b: np.ndarray) -> float:
    singular = np.linalg.svd(a.T @ b, compute_uv=False)
    return float(np.mean(np.clip(singular, 0, 1) ** 2))


def evolve_states(states: np.ndarray, operator: np.ndarray) -> np.ndarray:
    evolved = np.vstack([operator @ state for state in states])
    return l2_normalize_rows(evolved)


def trajectory_metrics(
    initial_states: np.ndarray,
    operator: np.ndarray,
    labels: Sequence[str],
    metadata: pd.DataFrame,
    n_steps: int,
    experiment_name: str,
) -> Tuple[pd.DataFrame, pd.DataFrame, List[np.ndarray]]:
    states = l2_normalize_rows(initial_states)
    pooled_rows: List[Dict[str, Any]] = []
    family_rows: List[Dict[str, Any]] = []
    state_history: List[np.ndarray] = [states.copy()]
    previous_basis: Optional[np.ndarray] = None

    for step in range(n_steps + 1):
        rho = density_surrogate(states)
        metrics = density_metrics(rho, states=states)
        basis = top_subspace_from_states(states, POINTER_RANK)
        pointer = subspace_overlap(previous_basis, basis) if previous_basis is not None else float("nan")
        previous_basis = basis
        pairwise = states @ states.T
        upper = pairwise[np.triu_indices_from(pairwise, k=1)]
        metrics.update({
            "experiment": experiment_name,
            "step": step,
            "pointer_subspace_stability": pointer,
            "mean_pairwise_overlap": float(np.mean(upper)) if len(upper) else float("nan"),
            "mean_abs_pairwise_overlap": float(np.mean(np.abs(upper))) if len(upper) else float("nan"),
        })
        pooled_rows.append(metrics)

        for idx, (label, state) in enumerate(zip(labels, states)):
            local = state_coordinate_metrics(state)
            local.update({
                "experiment": experiment_name,
                "step": step,
                "state_index": idx,
                "label": label,
                "family": metadata.iloc[idx].get("family", "UNKNOWN") if idx < len(metadata) else "UNKNOWN",
            })
            family_rows.append(local)

        if step < n_steps:
            states = evolve_states(states, operator)
            state_history.append(states.copy())

    return pd.DataFrame(pooled_rows), pd.DataFrame(family_rows), state_history


def echo_metrics(
    initial_states: np.ndarray,
    operator: np.ndarray,
    labels: Sequence[str],
    metadata: pd.DataFrame,
    steps: int,
    experiment_name: str,
) -> pd.DataFrame:
    states0 = l2_normalize_rows(initial_states)
    forward = states0.copy()
    for _ in range(steps):
        forward = evolve_states(forward, operator)

    pinv = np.linalg.pinv(operator, rcond=1e-8)
    recovered = forward.copy()
    for _ in range(steps):
        recovered = evolve_states(recovered, pinv)

    rows = []
    for idx, (label, original, rec) in enumerate(zip(labels, states0, recovered)):
        overlap = float(np.dot(original, rec))
        fidelity = float(np.clip(overlap ** 2, 0, 1))
        rows.append({
            "experiment": experiment_name,
            "echo_steps": steps,
            "state_index": idx,
            "label": label,
            "family": metadata.iloc[idx].get("family", "UNKNOWN") if idx < len(metadata) else "UNKNOWN",
            "echo_fidelity": fidelity,
            "echo_error": 1.0 - fidelity,
            "recovery_l2_error": float(np.linalg.norm(original - np.sign(overlap if overlap != 0 else 1) * rec)),
        })
    return pd.DataFrame(rows)


def random_orthogonal(n: int, rng: np.random.Generator) -> np.ndarray:
    q, r = np.linalg.qr(rng.normal(size=(n, n)))
    signs = np.sign(np.diag(r))
    signs[signs == 0] = 1
    return q * signs


def svd_matched_random_operator(operator: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    s = np.linalg.svd(operator, compute_uv=False)
    q1 = random_orthogonal(len(s), rng)
    q2 = random_orthogonal(len(s), rng)
    return q1 @ np.diag(s) @ q2.T


def permutation_conjugate(operator: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    perm = rng.permutation(operator.shape[0])
    return operator[np.ix_(perm, perm)]


def phase_scramble_states(states: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    scrambled: List[np.ndarray] = []
    for state in states:
        spectrum = np.fft.rfft(state)
        amplitudes = np.abs(spectrum)
        phases = rng.uniform(-np.pi, np.pi, size=len(spectrum))
        phases[0] = np.angle(spectrum[0])
        if len(state) % 2 == 0 and len(phases) > 1:
            phases[-1] = np.angle(spectrum[-1])
        new_spectrum = amplitudes * np.exp(1j * phases)
        scrambled.append(np.fft.irfft(new_spectrum, n=len(state)).real)
    return l2_normalize_rows(np.vstack(scrambled))


def summarize_trajectory(df: pd.DataFrame, echo_df: pd.DataFrame) -> Dict[str, float]:
    first = df.sort_values("step").iloc[0]
    last = df.sort_values("step").iloc[-1]
    transient = df[df["step"] >= max(1, int(df["step"].max() // 3))]
    return {
        "delta_coherence_l1_norm": float(last["coherence_l1_norm"] - first["coherence_l1_norm"]),
        "delta_purity": float(last["purity"] - first["purity"]),
        "delta_entropy_norm": float(last["von_neumann_entropy_norm"] - first["von_neumann_entropy_norm"]),
        "delta_effective_rank": float(last["effective_rank"] - first["effective_rank"]),
        "delta_diagonal_entropy_norm": float(last["diagonal_entropy_norm"] - first["diagonal_entropy_norm"]),
        "final_largest_eigenvalue": float(last["largest_eigenvalue"]),
        "mean_pointer_stability_after_transient": float(transient["pointer_subspace_stability"].mean(skipna=True)),
        "mean_echo_error": float(echo_df["echo_error"].mean()),
        "min_echo_error": float(echo_df["echo_error"].min()),
        "max_echo_error": float(echo_df["echo_error"].max()),
    }


def empirical_pvalue(null_values: Sequence[float], observed: float, direction: str) -> float:
    null = np.asarray([x for x in null_values if np.isfinite(x)], dtype=float)
    if len(null) == 0 or not np.isfinite(observed):
        return float("nan")
    if direction == "less":
        return float((1 + np.sum(null <= observed)) / (len(null) + 1))
    if direction == "greater":
        return float((1 + np.sum(null >= observed)) / (len(null) + 1))
    return float((1 + np.sum(np.abs(null) >= abs(observed))) / (len(null) + 1))


def run_surrogate_experiment(
    ensemble: ProfileEnsemble,
    operator_bundle: OperatorBundle,
    output_dir: Path,
    logger: logging.Logger,
) -> Dict[str, Any]:
    rng = np.random.default_rng(RANDOM_SEED)
    n = operator_bundle.matrix.shape[0]
    states = np.vstack([interpolate_vector(row, n) for row in ensemble.states])
    states = l2_normalize_rows(states)
    grid = np.linspace(float(ensemble.grid.min()), float(ensemble.grid.max()), n)
    operator = operator_bundle.matrix

    # Persist the exact reused objects.
    state_df = pd.DataFrame(states, columns=[f"x_{i:04d}" for i in range(n)])
    state_df.insert(0, "label", ensemble.labels)
    state_df.insert(1, "family", ensemble.metadata["family"].tolist())
    atomic_to_csv(state_df, output_dir / "stage7F_selected_profile_states_resampled.csv")
    pd.DataFrame(operator).to_csv(output_dir / "stage7F_selected_operator_normalized.csv", index=False)

    real_pooled, real_family, real_history = trajectory_metrics(
        states, operator, ensemble.labels, ensemble.metadata, N_STEPS, "QEG_REAL_OPERATOR"
    )
    real_echo = echo_metrics(
        states, operator, ensemble.labels, ensemble.metadata, ECHO_STEPS, "QEG_REAL_OPERATOR"
    )
    real_summary = summarize_trajectory(real_pooled, real_echo)

    all_pooled = [real_pooled]
    all_family = [real_family]
    all_echo = [real_echo]
    null_summary_rows: List[Dict[str, Any]] = []

    # Adjoint comparator is scientifically distinct from randomized nulls.
    adj_pooled, adj_family, _ = trajectory_metrics(
        states, operator.T, ensemble.labels, ensemble.metadata, N_STEPS, "ADJOINT_COMPARATOR"
    )
    adj_echo = echo_metrics(
        states, operator.T, ensemble.labels, ensemble.metadata, ECHO_STEPS, "ADJOINT_COMPARATOR"
    )
    adj_summary = summarize_trajectory(adj_pooled, adj_echo)
    all_pooled.append(adj_pooled)
    all_family.append(adj_family)
    all_echo.append(adj_echo)

    for run in range(N_NULL_RUNS):
        null_specs = [
            ("SVD_MATCHED_RANDOM", svd_matched_random_operator(operator, rng), states),
            ("PERMUTATION_CONJUGATE", permutation_conjugate(operator, rng), states),
            ("PHASE_SCRAMBLED_INPUT", operator, phase_scramble_states(states, rng)),
        ]
        for null_kind, null_operator, null_states in null_specs:
            name = f"{null_kind}_{run:03d}"
            pooled, family, _ = trajectory_metrics(
                null_states, null_operator, ensemble.labels, ensemble.metadata, N_STEPS, name
            )
            echo = echo_metrics(
                null_states, null_operator, ensemble.labels, ensemble.metadata, ECHO_STEPS, name
            )
            summary = summarize_trajectory(pooled, echo)
            summary.update({"null_kind": null_kind, "run": run, "experiment": name})
            null_summary_rows.append(summary)
            all_pooled.append(pooled)
            all_family.append(family)
            all_echo.append(echo)

    pooled_df = pd.concat(all_pooled, ignore_index=True)
    family_df = pd.concat(all_family, ignore_index=True)
    echo_df = pd.concat(all_echo, ignore_index=True)
    null_summary_df = pd.DataFrame(null_summary_rows)

    atomic_to_csv(pooled_df, output_dir / "stage7F_density_surrogate_trajectories.csv")
    atomic_to_csv(family_df, output_dir / "stage7F_family_state_trajectories.csv")
    atomic_to_csv(echo_df, output_dir / "stage7F_echo_recovery_results.csv")
    atomic_to_csv(null_summary_df, output_dir / "stage7F_matched_null_summary.csv")

    comparison_rows: List[Dict[str, Any]] = []
    expected_directions = {
        "delta_coherence_l1_norm": "less",      # more negative is decoherence-like
        "delta_purity": "less",                 # more negative is mixing-like
        "delta_entropy_norm": "greater",        # more positive is mixing-like
        "mean_pointer_stability_after_transient": "greater",
        "mean_echo_error": "greater",
    }
    for metric, direction in expected_directions.items():
        observed = real_summary[metric]
        all_null = null_summary_df[metric].to_numpy(dtype=float)
        p_all = empirical_pvalue(all_null, observed, direction)
        row = {
            "metric": metric,
            "expected_direction": direction,
            "observed": observed,
            "adjoint_comparator": adj_summary.get(metric),
            "null_mean": float(np.nanmean(all_null)),
            "null_std": float(np.nanstd(all_null)),
            "null_q05": float(np.nanquantile(all_null, 0.05)),
            "null_q50": float(np.nanquantile(all_null, 0.50)),
            "null_q95": float(np.nanquantile(all_null, 0.95)),
            "empirical_p_all_nulls": p_all,
        }
        for null_kind, group in null_summary_df.groupby("null_kind"):
            vals = group[metric].to_numpy(dtype=float)
            row[f"p_{normalize_name(null_kind)}"] = empirical_pvalue(vals, observed, direction)
            row[f"mean_{normalize_name(null_kind)}"] = float(np.nanmean(vals))
        comparison_rows.append(row)
    comparison_df = pd.DataFrame(comparison_rows)
    atomic_to_csv(comparison_df, output_dir / "stage7F_real_vs_null_comparison.csv")

    # Family consistency is measured on state-level coordinate observables.
    real_family_start = real_family[real_family["step"] == 0].set_index("label")
    real_family_end = real_family[real_family["step"] == N_STEPS].set_index("label")
    family_delta = real_family_end[[
        "state_coherence_l1_norm", "state_coordinate_entropy_norm",
        "state_inverse_participation",
    ]].subtract(real_family_start[[
        "state_coherence_l1_norm", "state_coordinate_entropy_norm",
        "state_inverse_participation",
    ]])
    family_delta = family_delta.reset_index()
    family_delta = family_delta.merge(
        ensemble.metadata[["label", "family"]], on="label", how="left"
    )
    atomic_to_csv(family_delta, output_dir / "stage7F_family_metric_deltas.csv")

    grouped_family = (
        family_delta.groupby("family", dropna=False)
        .agg(
            states=("label", "size"),
            mean_delta_state_coherence=("state_coherence_l1_norm", "mean"),
            mean_delta_coordinate_entropy=("state_coordinate_entropy_norm", "mean"),
            mean_delta_inverse_participation=("state_inverse_participation", "mean"),
        )
        .reset_index()
    )
    atomic_to_csv(grouped_family, output_dir / "stage7F_family_consistency_summary.csv")

    # Plot only the real operator and the three aggregated null bands.
    if HAVE_MATPLOTLIB:
        plot_metrics = [
            "coherence_l1_norm", "purity", "von_neumann_entropy_norm",
            "effective_rank", "pointer_subspace_stability",
        ]
        for metric in plot_metrics:
            fig, ax = plt.subplots(figsize=(8.5, 5.0))
            real = pooled_df[pooled_df["experiment"] == "QEG_REAL_OPERATOR"].sort_values("step")
            ax.plot(real["step"], real[metric], marker="o", label="QEG real operator")
            adj = pooled_df[pooled_df["experiment"] == "ADJOINT_COMPARATOR"].sort_values("step")
            ax.plot(adj["step"], adj[metric], marker="s", label="Adjoint comparator")
            for null_kind in ["SVD_MATCHED_RANDOM", "PERMUTATION_CONJUGATE", "PHASE_SCRAMBLED_INPUT"]:
                subset = pooled_df[pooled_df["experiment"].str.startswith(null_kind)]
                if subset.empty:
                    continue
                summary = subset.groupby("step")[metric].agg(["mean", "std"]).reset_index()
                ax.plot(summary["step"], summary["mean"], label=f"{null_kind} mean")
                ax.fill_between(
                    summary["step"].to_numpy(),
                    (summary["mean"] - summary["std"]).to_numpy(),
                    (summary["mean"] + summary["std"]).to_numpy(),
                    alpha=0.15,
                )
            ax.set_xlabel("Recursive operator step")
            ax.set_ylabel(metric.replace("_", " "))
            ax.set_title(f"Stage-7F decoherence-surrogate diagnostic: {metric}")
            ax.legend(fontsize=8)
            fig.tight_layout()
            fig.savefig(output_dir / f"stage7F_{metric}.png", dpi=180)
            plt.close(fig)

        fig, ax = plt.subplots(figsize=(9.0, 5.5))
        for idx, (label, state) in enumerate(zip(ensemble.labels, states)):
            ax.plot(grid, state, label=label[:80])
        ax.set_xlabel("Resampled intrinsic coordinate")
        ax.set_ylabel("L2-normalized profile")
        ax.set_title("Selected QEG profile ensemble used in Stage-7F")
        if len(ensemble.labels) <= 12:
            ax.legend(fontsize=7)
        fig.tight_layout()
        fig.savefig(output_dir / "stage7F_selected_profile_ensemble.png", dpi=180)
        plt.close(fig)

    # Adjudication criteria: evidence must beat matched nulls, not merely move.
    compare = comparison_df.set_index("metric")
    criteria = {
        "coherence_suppression": bool(
            real_summary["delta_coherence_l1_norm"] < 0
            and compare.loc["delta_coherence_l1_norm", "empirical_p_all_nulls"] <= 0.05
        ),
        "purity_loss": bool(
            real_summary["delta_purity"] < 0
            and compare.loc["delta_purity", "empirical_p_all_nulls"] <= 0.05
        ),
        "entropy_growth": bool(
            real_summary["delta_entropy_norm"] > 0
            and compare.loc["delta_entropy_norm", "empirical_p_all_nulls"] <= 0.05
        ),
        "pointer_subspace_stability": bool(
            real_summary["mean_pointer_stability_after_transient"] >= 0.80
            and compare.loc[
                "mean_pointer_stability_after_transient", "empirical_p_all_nulls"
            ] <= 0.05
        ),
        "echo_irrecoverability": bool(
            real_summary["mean_echo_error"] > 0
            and compare.loc["mean_echo_error", "empirical_p_all_nulls"] <= 0.05
        ),
    }

    # Family agreement is descriptive and separate from the five null gates.
    expected_families = {"BARI", "NUFIT", "VALENCIA"}
    present_families = set(grouped_family["family"].astype(str))
    family_complete = expected_families.issubset(present_families)
    entropy_family_signs = np.sign(grouped_family["mean_delta_coordinate_entropy"].to_numpy(dtype=float))
    coherence_family_signs = np.sign(grouped_family["mean_delta_state_coherence"].to_numpy(dtype=float))
    family_consistent = bool(
        len(grouped_family) >= 2
        and (np.all(entropy_family_signs >= 0) or np.all(entropy_family_signs <= 0))
        and (np.all(coherence_family_signs >= 0) or np.all(coherence_family_signs <= 0))
    )

    passed = sum(criteria.values())
    if criteria["coherence_suppression"] and criteria["entropy_growth"] and passed >= 3:
        dynamic_tag = "DECOHERENCE_LIKE_CONTRACTION_CANDIDATE"
    elif passed >= 2:
        dynamic_tag = "INFORMATION_LOSS_SURROGATE_REVIEW_REQUIRED"
    else:
        dynamic_tag = "NO_NULL_RESISTANT_DECOHERENCE_LIKE_DYNAMICS"

    if dynamic_tag == "DECOHERENCE_LIKE_CONTRACTION_CANDIDATE" and criteria["pointer_subspace_stability"]:
        pointer_tag = "POINTER_SECTOR_EINSELECTION_ANALOGUE_CANDIDATE"
    else:
        pointer_tag = "POINTER_SECTOR_NOT_PROMOTED"

    result = {
        "profile_source": ensemble.source_path,
        "operator_source": operator_bundle.source_path,
        "n_states": int(states.shape[0]),
        "operator_dimension": int(n),
        "families_present": sorted(present_families),
        "all_three_core_families_present": family_complete,
        "family_direction_consistent": family_consistent,
        "operator_properties": {
            "original_shape": operator_bundle.original_shape,
            "original_spectral_radius": operator_bundle.original_spectral_radius,
            "original_spectral_norm": operator_bundle.original_spectral_norm,
            "numerical_rank": operator_bundle.numerical_rank,
            "asymmetry": operator_bundle.asymmetry,
            "toeplitz_deviation": operator_bundle.toeplitz_deviation,
        },
        "real_summary": real_summary,
        "adjoint_summary": adj_summary,
        "criteria": criteria,
        "criteria_passed": passed,
        "dynamic_tag": dynamic_tag,
        "pointer_tag": pointer_tag,
    }
    write_json(output_dir / "stage7F_surrogate_experiment_summary.json", result)
    logger.info("Surrogate experiment complete: %s; %s", dynamic_tag, pointer_tag)
    return result


# ============================================================================
# FINAL EVIDENCE LADDER, REPORT, AND MANUSCRIPT LANGUAGE
# ============================================================================

def build_evidence_ladder(
    admissibility_status: Dict[str, Any],
    semantic_tally: pd.DataFrame,
    experiment: Optional[Dict[str, Any]],
    experiment_error: Optional[str],
) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    tally = {
        row["channel"]: int(row["hit_count"])
        for row in semantic_tally.to_dict("records")
    }
    d1 = bool(admissibility_status.get("categorical_split_found"))
    d2_prior = tally.get("entropy_information", 0) > 0 and tally.get("reversibility_echo", 0) > 0
    dynamic_tag = experiment.get("dynamic_tag") if experiment else None
    pointer_tag = experiment.get("pointer_tag") if experiment else None
    d2 = bool(dynamic_tag in {
        "DECOHERENCE_LIKE_CONTRACTION_CANDIDATE",
        "INFORMATION_LOSS_SURROGATE_REVIEW_REQUIRED",
    })
    d3 = bool(pointer_tag == "POINTER_SECTOR_EINSELECTION_ANALOGUE_CANDIDATE")

    rows = [
        {
            "level": "D0",
            "name": "No decoherence-relevant structure",
            "supported": not any([d1, d2_prior, d2, d3]),
            "basis": "No static or dynamic channel recovered.",
        },
        {
            "level": "D1",
            "name": "Static sector selection",
            "supported": d1,
            "basis": "Machine-readable transformation-selective admissibility split.",
        },
        {
            "level": "D2",
            "name": "Dynamic coherence/information-loss surrogate",
            "supported": d2,
            "basis": dynamic_tag or experiment_error or "Experiment not executed.",
        },
        {
            "level": "D2-prior",
            "name": "Retrospective entropy/reversibility ingredients",
            "supported": d2_prior,
            "basis": "Existing project files contain both entropy/information and reversibility/echo channels; this is context, not promotion by itself.",
        },
        {
            "level": "D3",
            "name": "Pointer-sector / einselection analogue",
            "supported": d3,
            "basis": pointer_tag or experiment_error or "Experiment not executed.",
        },
        {
            "level": "D4",
            "name": "Physical decoherence mechanism",
            "supported": False,
            "basis": "Forbidden from automatic promotion: no physical system-environment Hilbert-space split, reduced state, or partial trace has been established.",
        },
    ]
    df = pd.DataFrame(rows)

    highest = "D0"
    if d1:
        highest = "D1"
    if d2:
        highest = "D2"
    if d3:
        highest = "D3"

    summary = {
        "highest_supported_level": highest,
        "static_sector_selection": d1,
        "retrospective_dynamic_ingredients_present": d2_prior,
        "dynamic_surrogate_supported": d2,
        "pointer_sector_analogue_supported": d3,
        "physical_decoherence_claim_permitted": False,
    }
    return df, summary


def manuscript_language(
    ladder_summary: Dict[str, Any],
    experiment: Optional[Dict[str, Any]],
) -> str:
    lines = [
        "BASELINE MANUSCRIPT-SAFE LANGUAGE (retain regardless of dynamic result)",
        "--------------------------------------------------------------------",
        BASELINE_MANUSCRIPT_SENTENCE,
        "",
        "CONDITIONAL STAGE-7F LANGUAGE",
        "------------------------------",
    ]
    highest = ladder_summary["highest_supported_level"]
    if highest == "D3":
        lines.append(
            "When the family-aware profile ensemble is propagated by the frozen QEG "
            "operator, the Gram-density surrogate exhibits null-resistant information-"
            "loss diagnostics together with a stable leading eigensubspace.  This supports "
            "a pointer-sector or einselection-like analogue within the reconstructed "
            "profile dynamics.  The statement remains surrogate-level: no physical "
            "environment, reduced quantum state, or microscopic decoherence mechanism "
            "has been identified."
        )
    elif highest == "D2":
        tag = experiment.get("dynamic_tag") if experiment else ""
        lines.append(
            "The retrospective and operator-propagation audits identify a dynamic "
            "information-loss surrogate beyond the static admissibility boundary "
            f"({tag}).  The result may be described as decoherence-like only at the "
            "level of the constructed Gram-density ensemble; it is not evidence of a "
            "physical open-system quantum process."
        )
    elif highest == "D1":
        lines.append(
            "The present evidence supports transformation-selective sector pruning but "
            "does not yet establish null-resistant coherence loss, entropy growth, purity "
            "loss, or a stable pointer basis.  Decoherence should therefore appear only "
            "as a structural analogy in the Discussion."
        )
    else:
        lines.append(
            "No decoherence-adjacent wording should be promoted beyond a future-work "
            "motivation."
        )
    lines.extend([
        "",
        "PERMANENT CLAIM GUARDRAIL",
        "-------------------------",
        "The Stage-7F Gram-density object is a positive-semidefinite, trace-one surrogate "
        "constructed from QEG profiles. It is not a physical quantum density matrix. "
        "No system-environment tensor product, partial trace, decoherence time, or "
        "modification of quantum mechanics is inferred.",
    ])
    return "\n".join(lines) + "\n"


def write_report(
    output_dir: Path,
    root: Path,
    inventory: pd.DataFrame,
    semantic_tally: pd.DataFrame,
    admissibility_status: Dict[str, Any],
    experiment: Optional[Dict[str, Any]],
    experiment_error: Optional[str],
    ladder_summary: Dict[str, Any],
) -> None:
    lines = [
        "=" * 78,
        "STAGE-7F DECOHERENCE-SURROGATE AUDIT — FINAL REPORT",
        "=" * 78,
        f"Project root: {root}",
        f"Files inventoried: {len(inventory)}",
        "",
        "RETROSPECTIVE CHANNEL TALLY",
        "---------------------------",
    ]
    if semantic_tally.empty:
        lines.append("No semantic evidence hits were recovered.")
    else:
        for row in semantic_tally.to_dict("records"):
            lines.append(
                f"{row['channel']}: {row['hit_count']} contextual hits in {row['file_count']} files"
            )

    lines.extend([
        "",
        "TRANSFORMATION-SELECTIVE ADMISSIBILITY",
        "--------------------------------------",
        f"Machine-readable table found: {admissibility_status.get('table_found')}",
        f"Categorical admissibility split found: {admissibility_status.get('categorical_split_found')}",
        f"Exact 27/27, 27/27, 0/27, 0/27 pattern found: {admissibility_status.get('expected_27_27_0_0_pattern_found')}",
        "",
        "NEW GRAM-DENSITY SURROGATE EXPERIMENT",
        "-------------------------------------",
    ])
    if experiment is None:
        lines.append("Experiment not completed.")
        lines.append(f"Reason: {experiment_error}")
    else:
        lines.append(f"Profile source: {experiment['profile_source']}")
        lines.append(f"Operator source: {experiment['operator_source']}")
        lines.append(f"States: {experiment['n_states']}")
        lines.append(f"Operator dimension: {experiment['operator_dimension']}")
        lines.append(f"Families present: {', '.join(experiment['families_present'])}")
        lines.append(f"Dynamic tag: {experiment['dynamic_tag']}")
        lines.append(f"Pointer tag: {experiment['pointer_tag']}")
        lines.append(f"Null-resistant criteria passed: {experiment['criteria_passed']} / 5")
        for key, value in experiment["criteria"].items():
            lines.append(f"  {key}: {value}")

    lines.extend([
        "",
        "CLAIM LADDER",
        "------------",
        f"Highest supported level: {ladder_summary['highest_supported_level']}",
        f"Physical decoherence claim permitted: {ladder_summary['physical_decoherence_claim_permitted']}",
        "",
        "INTERPRETIVE RULE",
        "-----------------",
        "D1 permits a structural superselection-like analogy.",
        "D2 permits carefully qualified decoherence-like surrogate wording.",
        "D3 permits a pointer-sector/einselection-like analogue wording.",
        "D4 is never auto-promoted and requires a physically justified system/environment decomposition.",
        "",
        "END REPORT",
        "=" * 78,
    ])
    (output_dir / "stage7F_final_report.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")


# ============================================================================
# OPTIONAL SELF-TEST FIXTURE
# ============================================================================

def build_self_test_fixture(root: Path) -> None:
    """Create a small deterministic fixture used only with --self-test."""
    root.mkdir(parents=True, exist_ok=True)
    out6o = root / "metric_stage_6O_outputs/provenance_branch_family_aware_rebuild_from_6D"
    out6j = root / "metric_stage_6J_outputs"
    out4d = root / "metric_stage_4D_outputs"
    out6o.mkdir(parents=True, exist_ok=True)
    out6j.mkdir(parents=True, exist_ok=True)
    out4d.mkdir(parents=True, exist_ok=True)

    s = np.linspace(0, 1, 48)
    rows = []
    for family, shift in [("BARI", -0.02), ("NUFIT", 0.0), ("VALENCIA", 0.02)]:
        rho = (
            0.35 * np.exp(-0.5 * ((s - (0.08 + shift)) / 0.04) ** 2)
            + 1.0 * np.exp(-0.5 * ((s - (0.55 + shift)) / 0.13) ** 2)
        )
        for x, y in zip(s, rho):
            rows.append({"family": family, "s": x, "rho_like": y})
    pd.DataFrame(rows).to_csv(
        out6o / "stage6O_family_aware_profile_48bins_from_6D.csv", index=False
    )

    n = 48
    grid = np.arange(n)
    kernel = np.exp(-np.abs(grid[:, None] - grid[None, :]) / 5.0)
    kernel *= np.linspace(1.3, 0.7, n)[:, None]
    kernel += 0.03 * np.tril(np.ones((n, n)), -1)
    pd.DataFrame(kernel).to_csv(out6j / "stage6J_kernel_matrix_best.csv", index=False)

    transformations = [f"T{i}" for i in range(1, 8)]
    rows = []
    for metric, allowed in [
        ("euclidean", True), ("radial_weighted", True),
        ("hybrid", False), ("logarithmic_radial", False),
    ]:
        for family in ["BARI", "NUFIT", "VALENCIA"]:
            for transformation in transformations:
                # 7 x 3 = 21 in fixture; the exact 27 pattern is intentionally not forged.
                rows.append({
                    "metric": metric,
                    "family": family,
                    "transformation": transformation,
                    "admissible": allowed,
                    "obstruction": "" if allowed else (
                        "negative square-root argument" if metric == "hybrid"
                        else "non-positive logarithmic argument"
                    ),
                })
    pd.DataFrame(rows).to_csv(out4d / "stage4D_admissibility_audit.csv", index=False)

    (root / "stage7_prior_notes.txt").write_text(
        "Entropy channel positive. Forward/reverse and inverse/adjoint recovery tests. "
        "Low-k collective mode retained. Phase randomization null evaluated.\n",
        encoding="utf-8",
    )


# ============================================================================
# MAIN
# ============================================================================

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Stage-7F QEG decoherence-surrogate audit and experiment"
    )
    parser.add_argument(
        "--root", type=Path, default=PROJECT_ROOT_DEFAULT,
        help="QEG project root",
    )
    parser.add_argument(
        "--self-test", action="store_true",
        help="Build and run against a deterministic synthetic fixture",
    )
    args, _unknown = parser.parse_known_args()
    return args


def main() -> int:
    args = parse_args()
    root = args.root.expanduser().resolve()
    if args.self_test:
        root = Path("/tmp/qeg_stage7F_self_test").resolve()
        if root.exists():
            import shutil
            shutil.rmtree(root)
        build_self_test_fixture(root)

    output_dir = root / OUTPUT_RELATIVE
    logger = setup_logging(output_dir)
    logger.info("Stage-7F started")
    logger.info("Project root: %s", root)

    if not root.exists():
        logger.error("Project root does not exist: %s", root)
        return 2

    experiment: Optional[Dict[str, Any]] = None
    experiment_error: Optional[str] = None

    try:
        inventory = inventory_project(root, output_dir, logger)
        hits, semantic_tally = semantic_context_audit(root, inventory, output_dir, logger)
        adm_rows, adm_summary, adm_status = audit_admissibility(
            root, inventory, output_dir, logger
        )
        profile_candidates, operator_candidates = discover_assets(
            root, inventory, output_dir, logger
        )

        attempts_df = pd.DataFrame(columns=["kind", "path", "success", "message"])
        try:
            ensemble, operator, attempts_df = select_usable_assets(
                profile_candidates, operator_candidates, logger
            )
            atomic_to_csv(attempts_df, output_dir / "stage7F_asset_selection_attempts.csv")
            selection = {
                "profile": {
                    "source_path": ensemble.source_path,
                    "coordinate_column": ensemble.coordinate_column,
                    "value_column": ensemble.value_column,
                    "group_columns": ensemble.group_columns,
                    "state_count": int(ensemble.states.shape[0]),
                    "grid_count": int(ensemble.states.shape[1]),
                    "labels": ensemble.labels,
                },
                "operator": {
                    "source_path": operator.source_path,
                    "original_shape": operator.original_shape,
                    "used_shape": operator.matrix.shape,
                    "rank": operator.numerical_rank,
                    "asymmetry": operator.asymmetry,
                    "toeplitz_deviation": operator.toeplitz_deviation,
                },
            }
            write_json(output_dir / "stage7F_selected_assets.json", selection)
            experiment = run_surrogate_experiment(
                ensemble, operator, output_dir, logger
            )
        except Exception as exc:
            experiment_error = f"{type(exc).__name__}: {exc}"
            logger.warning("Surrogate experiment could not be completed: %s", experiment_error)
            if not attempts_df.empty:
                atomic_to_csv(attempts_df, output_dir / "stage7F_asset_selection_attempts.csv")
            (output_dir / "stage7F_experiment_error.txt").write_text(
                experiment_error + "\n\n" + traceback.format_exc(), encoding="utf-8"
            )

        ladder_df, ladder_summary = build_evidence_ladder(
            adm_status, semantic_tally, experiment, experiment_error
        )
        atomic_to_csv(ladder_df, output_dir / "stage7F_evidence_ladder.csv")
        write_json(output_dir / "stage7F_evidence_ladder_summary.json", ladder_summary)

        language = manuscript_language(ladder_summary, experiment)
        (output_dir / "stage7F_manuscript_language.txt").write_text(language, encoding="utf-8")

        write_report(
            output_dir, root, inventory, semantic_tally, adm_status,
            experiment, experiment_error, ladder_summary,
        )

        master_summary = {
            "script": Path(__file__).name,
            "project_root": str(root),
            "output_dir": str(output_dir),
            "random_seed": RANDOM_SEED,
            "files_inventoried": len(inventory),
            "semantic_hits": len(hits),
            "semantic_channels": semantic_tally.to_dict("records"),
            "admissibility_status": adm_status,
            "experiment_completed": experiment is not None,
            "experiment_error": experiment_error,
            "experiment": experiment,
            "evidence_ladder": ladder_summary,
            "claim_guardrail": (
                "No physical decoherence claim. The Gram-density object is a surrogate; "
                "no physical environment, partial trace, or quantum reduced state is inferred."
            ),
        }
        write_json(output_dir / "stage7F_master_summary.json", master_summary)

        logger.info("Stage-7F complete")
        logger.info("Highest supported evidence level: %s", ladder_summary["highest_supported_level"])
        logger.info("Outputs: %s", output_dir)
        return 0

    except Exception as exc:
        logger.exception("Fatal Stage-7F error: %s", exc)
        (output_dir / "stage7F_FATAL_ERROR.txt").write_text(
            f"{type(exc).__name__}: {exc}\n\n{traceback.format_exc()}",
            encoding="utf-8",
        )
        return 1


if __name__ == "__main__":
    main()
