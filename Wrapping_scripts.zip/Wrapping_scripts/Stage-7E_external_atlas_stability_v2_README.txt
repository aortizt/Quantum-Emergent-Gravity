QEG EXTERNAL-ATLAS STABILITY v2 — FINAL HOLDOUT SCRIPT
=====================================================

File
----
Stage-7E_external_atlas_stability_v2_final.py

Recommended local location
--------------------------
<PROJECT_ROOT>/metric_stage_7E_scripts/

The script is path-independent and may later be moved into a dedicated
paper-support or latest-scripts directory.  Its default output location is:

<PROJECT_ROOT>/metric_stage_7E_outputs/external_atlas_stability_v2_final/

What v2 adds
------------
1. Uncertainty-symmetric parametric bootstrap envelopes.
2. Corrected Monte Carlo comparison:
   temporal NuFIT displacement and historical cross-family displacement are
   sampled under the same uncertainty model.
3. NO-to-IO arrows on every frozen PCA atlas.
4. PCA loading attribution and coordinate-dominance diagnostics.
5. Exact semantic-coordinate permutation tests over all non-identity
   permutations of the seven circularized coordinates.
6. Phase-randomization nulls.
7. Predeclared combined source-stability statistic:
       S = (E O N T)^(1/4)

   Here O combines the central primary-atlas ordering cosine with the
   uncertainty-bootstrap probability that the cosine remains positive.
   The stricter probability cosine >= 0.8 is still reported separately,
   but it is not used as a hard combined-score gate because the published
   source tables do not provide the full parameter covariance matrices.
8. Restartable deterministic bootstrap CSVs.
9. Proposition-ready LaTeX snippet.
10. Human-readable report, machine-readable verdict, manifests, and figures.

Scientific role
---------------
The holdout remains outside the proof.

Its intended placement is immediately after the appendix theorem/conjecture
under a heading such as:

    External temporal stability test.

The script explicitly limits the claim to source-atlas stability.  It does not
claim held-out validation of the downstream two-sector operator law.

Input files
-----------
Preferred:
- training_PDG2024_source_panel.csv
- holdout_NuFIT6_source_panel.csv

The script searches the previous v1 output directory, the project root, and
the script directory.  Paths can be forced with:

    QEG_TRAINING_CSV=/absolute/path/training_PDG2024_source_panel.csv
    QEG_HOLDOUT_CSV=/absolute/path/holdout_NuFIT6_source_panel.csv

If the CSVs are absent, the exact v1 values are reconstructed from the built-in
fallback table and the source manifest records that fact.

Normal Spyder run
-----------------
Open the script in Spyder and press Run.

Optional terminal-equivalent environment variables:

    export QEG_ROOT=/home/dakini/Downloads/010-Quantum_Emergent_Gravity
    export QEG_BOOTSTRAP_REPS=5000
    export QEG_PHASE_NULL_REPS=10000

Runtime check only
------------------
A small test run can be made with:

    export QEG_FAST_TEST=1

Never use FAST_TEST outputs in the manuscript.

Main outputs
------------
- analysis_contract.json
- source_manifest.json
- central_holdout_atlas_scores.csv
- bootstrap_envelope_temporal_summary.csv
- bootstrap_ordering_summary.csv
- semantic_and_phase_null_summary.csv
- pca_loading_attribution.csv
- pca_loading_diagnostics.csv
- combined_source_stability_statistic.csv
- combined_source_stability_bootstrap_summary.csv
- verdict.json
- QEG_external_atlas_stability_v2_report.txt
- external_temporal_stability_test_snippet.tex
- PCA arrow figures
- PCA loading figures
- uncertainty-symmetric envelope figure
- combined-statistic figure

Interpretation
--------------
The z-score signed/absolute atlases are the predeclared primary gates.
Robust atlases and ridge-Mahalanobis remain sensitivity/review diagnostics
because the development panel has six rows in a seven-dimensional circular
embedding.

The combined statistic is an audit summary, not a physical invariant.
