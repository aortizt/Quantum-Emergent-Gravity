#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Stage-7F v2 — Targeted global_mu origin-formula trace
====================================================

Purpose
-------
Recover, if possible, the first non-circular formula and upstream operands
that generated the QEG statistic

    global_mu = 0.327995

The script also preserves the already recoverable sub-percent candidate:

    early_central_separation
        = abs(central_mu - early_mu)
        = 0.317696468538139

Scientific rule
---------------
No distance to Omega_m is used to discover or rank a formula.  The external
benchmark is applied only after provenance classification.

Default project root
--------------------
/home/dakini/Downloads/010-Quantum_Emergent_Gravity

Recommended use in Spyder
-------------------------
Run the file directly.  To override the root, edit PROJECT_ROOT below or run:

    python Stage-7F_v2_global_mu_origin_formula_trace.py /path/to/project

Outputs
-------
metric_stage_7F_outputs/global_mu_origin_formula_trace_v2/
    stage7F_v2_candidate_file_inventory.csv
    stage7F_v2_exact_value_occurrences.csv
    stage7F_v2_python_assignment_trace.csv
    stage7F_v2_column_aggregate_reconstructions.csv
    stage7F_v2_pairwise_operand_reconstructions.csv
    stage7F_v2_sharp_candidate_closure.csv
    stage7F_v2_dependency_ancestor_trace.csv
    stage7F_v2_global_mu_formula_verdict.json
    Stage-7F_v2_global_mu_formula_report.txt

Verdict classes
---------------
FORMULA_CLOSED_FROM_CODE_AND_OPERANDS
FORMULA_CLOSED_FROM_OUTPUT_AGGREGATION
FORMULA_CANDIDATE_REQUIRES_SOURCE_CONFIRMATION
LITERAL_OR_DOWNSTREAM_ONLY
UNRESOLVED
"""

from __future__ import annotations

import ast
import csv
import hashlib
import json
import math
import os
import re
import sys
import traceback
from collections import defaultdict, deque
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Optional

import numpy as np
import pandas as pd


# ---------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------

PROJECT_ROOT = Path(
    "/home/dakini/Downloads/010-Quantum_Emergent_Gravity"
)

GLOBAL_MU = 0.327995
SHARP_VALUE = 0.317696468538139
OMEGA_M_REFERENCE = 0.315

EXACT_TOL = 5e-10
FORMULA_TOL = 5e-7
MAX_CSV_ROWS = 1_000_000
MAX_TEXT_MB = 80.0
ANCESTOR_DEPTH = 5

OUT_REL = Path(
    "metric_stage_7F_outputs/global_mu_origin_formula_trace_v2"
)

V1_REL = Path(
    "metric_stage_7F_outputs/omega_m_provenance_forensic_reconstruction_v1"
)

LIKELY_MU_RE = re.compile(
    r"(?:^|_)(?:mu|mean|centre|center|centroid|location|peak)(?:_|$)",
    re.IGNORECASE,
)
LIKELY_WEIGHT_RE = re.compile(
    r"(?:weight|mass|amplitude|amp|count|frequency|prob|density)",
    re.IGNORECASE,
)
FORMULA_NAME_RE = re.compile(
    r"(global_mu|mu_global|early_central_separation|"
    r"central.*early|early.*central|mu.*difference|difference.*mu)",
    re.IGNORECASE,
)

ARCHIVE_MARKERS = (
    "zenodo_script_output_trace",
    "github_staging_reproducibility_bundle",
    "QEG_Curated_Manuscript_Zenodo_READY",
    "QEG_Manuscript_Reproducibility_Zenodo_READY",
    "__qeg_evidence__",
    "raw_v1_snapshot",
    "ledger",
    "README",
)

TEXT_SUFFIXES = {
    ".py", ".txt", ".md", ".tex", ".json", ".yaml", ".yml", ".toml"
}


# ---------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------

def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def finite_float(value: Any) -> Optional[float]:
    try:
        x = float(value)
    except (TypeError, ValueError):
        return None
    return x if math.isfinite(x) else None


def near(a: Any, b: float, tol: float = EXACT_TOL) -> bool:
    x = finite_float(a)
    return x is not None and abs(x - b) <= tol


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def relpath(path: Path, root: Path) -> str:
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except Exception:
        return path.as_posix()


def is_archive_like(path_text: str) -> bool:
    lower = path_text.lower()
    return any(marker.lower() in lower for marker in ARCHIVE_MARKERS)


def stage_rank(path_text: str) -> tuple[int, int, str]:
    """
    Lower is earlier.  This is only an ordering aid, never proof of origin.
    """
    s = path_text.lower()
    m = re.search(r"stage[-_ ]?(\d+)([a-z]*)", s)
    if not m:
        return (999, 999, s)
    major = int(m.group(1))
    letters = m.group(2)
    minor = 0
    for ch in letters:
        minor = minor * 26 + (ord(ch) - 96)
    return (major, minor, s)


def read_text_safely(path: Path) -> Optional[str]:
    try:
        if path.stat().st_size > MAX_TEXT_MB * 1024 * 1024:
            return None
        return path.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return None


def write_csv(path: Path, rows: list[dict[str, Any]], columns: list[str]) -> None:
    df = pd.DataFrame(rows)
    for col in columns:
        if col not in df.columns:
            df[col] = np.nan
    df = df[columns]
    df.to_csv(path, index=False)


def json_dump(path: Path, obj: Any) -> None:
    path.write_text(
        json.dumps(obj, indent=2, ensure_ascii=False, default=str),
        encoding="utf-8",
    )


# ---------------------------------------------------------------------
# Load Stage-7F v1 evidence, if present
# ---------------------------------------------------------------------

def find_v1_dir(root: Path) -> Optional[Path]:
    p = root / V1_REL
    if p.exists():
        return p
    candidates = list(root.rglob("stage7F_value_occurrences.csv"))
    return candidates[0].parent if candidates else None


def load_v1_table(v1_dir: Optional[Path], name: str) -> pd.DataFrame:
    if v1_dir is None:
        return pd.DataFrame()
    p = v1_dir / name
    if not p.exists():
        # Also allow the table in the project root if copied there.
        alternatives = list(v1_dir.parent.rglob(name))
        if alternatives:
            p = alternatives[0]
        else:
            return pd.DataFrame()
    try:
        return pd.read_csv(p)
    except Exception:
        return pd.DataFrame()


# ---------------------------------------------------------------------
# Dependency graph
# ---------------------------------------------------------------------

def normalize_dependency_path(text: Any, root: Path) -> Optional[str]:
    if text is None or (isinstance(text, float) and np.isnan(text)):
        return None
    s = str(text).strip()
    if not s:
        return None
    p = Path(s)
    if p.is_absolute():
        try:
            return p.resolve().relative_to(root.resolve()).as_posix()
        except Exception:
            return p.as_posix()
    return p.as_posix().lstrip("./")


def build_ancestor_trace(
    edges: pd.DataFrame,
    seeds: set[str],
    root: Path,
    max_depth: int = ANCESTOR_DEPTH,
) -> tuple[set[str], list[dict[str, Any]]]:
    if edges.empty:
        return set(), []

    incoming: dict[str, list[tuple[str, str, str]]] = defaultdict(list)
    for _, row in edges.iterrows():
        source = normalize_dependency_path(row.get("source_file"), root)
        dep = normalize_dependency_path(row.get("dependent_file"), root)
        if not source or not dep:
            continue
        incoming[dep].append(
            (
                source,
                str(row.get("edge_kind", "")),
                str(row.get("context", "")),
            )
        )

    found: set[str] = set()
    trace: list[dict[str, Any]] = []
    q: deque[tuple[str, int, str]] = deque(
        (seed, 0, seed) for seed in seeds
    )
    visited: set[tuple[str, int]] = set()

    while q:
        node, depth, seed = q.popleft()
        if (node, depth) in visited or depth >= max_depth:
            continue
        visited.add((node, depth))
        for source, kind, context in incoming.get(node, []):
            found.add(source)
            trace.append(
                {
                    "seed_file": seed,
                    "dependent_file": node,
                    "source_file": source,
                    "depth": depth + 1,
                    "edge_kind": kind,
                    "context": context,
                }
            )
            q.append((source, depth + 1, seed))

    return found, trace


# ---------------------------------------------------------------------
# Candidate-file selection
# ---------------------------------------------------------------------

def collect_candidate_files(
    root: Path,
    occurrences: pd.DataFrame,
    dependency_edges: pd.DataFrame,
) -> tuple[list[Path], list[dict[str, Any]], list[dict[str, Any]]]:
    seed_rows: list[dict[str, Any]] = []
    seed_paths: set[str] = set()

    if not occurrences.empty and "value" in occurrences.columns:
        vals = pd.to_numeric(occurrences["value"], errors="coerce")
        exact = np.isclose(vals, GLOBAL_MU, atol=EXACT_TOL, rtol=0)
        for _, row in occurrences.loc[exact].iterrows():
            file_text = normalize_dependency_path(row.get("file_path"), root)
            if not file_text:
                continue
            seed_paths.add(file_text)
            seed_rows.append(
                {
                    "file_path": file_text,
                    "reason": "exact_global_mu_occurrence",
                    "occurrence_kind": row.get("occurrence_kind"),
                    "feature_name": row.get("feature_name"),
                    "provenance_class": row.get("provenance_class"),
                }
            )

    # Always include the likely origin neighborhood, even if v1 tables moved.
    for pattern in (
        "metric_stage_6Yh*",
        "metric_stage_6Yh_v1a*",
        "metric_stage_6Yi*",
        "metric_stage_6Yj*",
        "metric_stage_6Yk*",
        "metric_stage_6Yl*",
        "metric_stage_6H*",
        "metric_stage_6N*",
        "metric_stage_6P*",
        "metric_stage_6Q*",
    ):
        for p in root.glob(pattern):
            if p.is_dir():
                for child in p.rglob("*"):
                    if child.is_file():
                        seed_paths.add(relpath(child, root))

    ancestors, trace = build_ancestor_trace(
        dependency_edges, seed_paths, root
    )

    all_rel = set(seed_paths) | set(ancestors)
    files: list[Path] = []
    inventory: list[dict[str, Any]] = []

    for rel in sorted(all_rel, key=stage_rank):
        p = Path(rel)
        if not p.is_absolute():
            p = root / rel
        if not p.exists() or not p.is_file():
            continue
        if p.suffix.lower() not in TEXT_SUFFIXES | {".csv"}:
            continue
        files.append(p)
        inventory.append(
            {
                "file_path": relpath(p, root),
                "stage_rank": repr(stage_rank(relpath(p, root))[:2]),
                "archive_like": is_archive_like(relpath(p, root)),
                "size_bytes": p.stat().st_size,
                "modified_time": p.stat().st_mtime,
                "sha256": sha256_file(p),
                "selection_reason": (
                    "seed_or_stage_neighborhood"
                    if relpath(p, root) in seed_paths
                    else "dependency_ancestor"
                ),
            }
        )

    return files, inventory, trace


# ---------------------------------------------------------------------
# Exact-value occurrences
# ---------------------------------------------------------------------

def inspect_text_occurrences(path: Path, root: Path) -> list[dict[str, Any]]:
    text = read_text_safely(path)
    if text is None:
        return []

    rows: list[dict[str, Any]] = []
    patterns = {
        "global_mu": re.compile(
            r"(?<![\d.])0\.327995(?:0+)?(?!\d)"
        ),
        "sharp_candidate": re.compile(
            r"(?<![\d.])0\.317696468538139(?!\d)"
        ),
    }

    lines = text.splitlines()
    for i, line in enumerate(lines, start=1):
        for name, pattern in patterns.items():
            if pattern.search(line):
                rows.append(
                    {
                        "file_path": relpath(path, root),
                        "file_type": path.suffix.lower().lstrip("."),
                        "target_name": name,
                        "line_or_row": i,
                        "column_or_key": "",
                        "context": line.strip()[:1500],
                        "archive_like": is_archive_like(relpath(path, root)),
                        "occurrence_class": (
                            "literal_or_textual_occurrence"
                        ),
                    }
                )
    return rows


def inspect_csv_occurrences(path: Path, root: Path) -> list[dict[str, Any]]:
    try:
        df = pd.read_csv(path, nrows=MAX_CSV_ROWS)
    except Exception:
        return []

    rows: list[dict[str, Any]] = []
    for col in df.columns:
        numeric = pd.to_numeric(df[col], errors="coerce")
        for target_name, target in (
            ("global_mu", GLOBAL_MU),
            ("sharp_candidate", SHARP_VALUE),
        ):
            mask = np.isclose(
                numeric.to_numpy(dtype=float, na_value=np.nan),
                target,
                atol=EXACT_TOL,
                rtol=0,
                equal_nan=False,
            )
            for idx in np.flatnonzero(mask):
                context = "; ".join(
                    f"{c}={df.iloc[idx][c]}"
                    for c in df.columns[:40]
                )
                rows.append(
                    {
                        "file_path": relpath(path, root),
                        "file_type": "csv",
                        "target_name": target_name,
                        "line_or_row": int(idx),
                        "column_or_key": str(col),
                        "context": context[:4000],
                        "archive_like": is_archive_like(relpath(path, root)),
                        "occurrence_class": "numeric_csv_cell",
                    }
                )
    return rows


# ---------------------------------------------------------------------
# Python AST trace
# ---------------------------------------------------------------------

def target_names(node: ast.AST) -> list[str]:
    out: list[str] = []
    if isinstance(node, ast.Name):
        out.append(node.id)
    elif isinstance(node, ast.Attribute):
        parts = []
        cur: Any = node
        while isinstance(cur, ast.Attribute):
            parts.append(cur.attr)
            cur = cur.value
        if isinstance(cur, ast.Name):
            parts.append(cur.id)
        out.append(".".join(reversed(parts)))
    elif isinstance(node, (ast.Tuple, ast.List)):
        for elt in node.elts:
            out.extend(target_names(elt))
    elif isinstance(node, ast.Subscript):
        try:
            out.append(ast.unparse(node))
        except Exception:
            pass
    return out


def names_used(node: Optional[ast.AST]) -> list[str]:
    if node is None:
        return []
    return sorted(
        {
            child.id
            for child in ast.walk(node)
            if isinstance(child, ast.Name)
        }
    )


def numeric_literals(node: Optional[ast.AST]) -> list[float]:
    if node is None:
        return []
    values: list[float] = []
    for child in ast.walk(node):
        if isinstance(child, ast.Constant) and isinstance(
            child.value, (int, float)
        ):
            x = finite_float(child.value)
            if x is not None:
                values.append(x)
    return values


class SafeNumericEvaluator:
    """
    Evaluates only simple scalar expressions built from already known
    numeric assignments.  It does not execute arbitrary project code.

    The second return value is a taint flag.  A value is tainted when its
    dependency chain contains the literal 0.327995.  Tainted expressions
    can document downstream propagation but cannot close provenance.
    """

    def __init__(self) -> None:
        self.env: dict[str, tuple[float, bool]] = {}

    def eval(self, node: Optional[ast.AST]) -> tuple[Optional[float], bool]:
        if node is None:
            return None, False
        if isinstance(node, ast.Constant):
            value = finite_float(node.value)
            return value, bool(value is not None and near(value, GLOBAL_MU, EXACT_TOL))
        if isinstance(node, ast.Name):
            return self.env.get(node.id, (None, False))
        if isinstance(node, ast.UnaryOp):
            x, tainted = self.eval(node.operand)
            if x is None:
                return None, tainted
            if isinstance(node.op, ast.USub):
                return -x, tainted
            if isinstance(node.op, ast.UAdd):
                return x, tainted
            return None, tainted
        if isinstance(node, ast.BinOp):
            a, ta = self.eval(node.left)
            b, tb = self.eval(node.right)
            tainted = ta or tb
            if a is None or b is None:
                return None, tainted
            try:
                if isinstance(node.op, ast.Add):
                    return a + b, tainted
                if isinstance(node.op, ast.Sub):
                    return a - b, tainted
                if isinstance(node.op, ast.Mult):
                    return a * b, tainted
                if isinstance(node.op, ast.Div):
                    return a / b, tainted
                if isinstance(node.op, ast.Pow):
                    return a ** b, tainted
                if isinstance(node.op, ast.Mod):
                    return a % b, tainted
            except Exception:
                return None, tainted
        if isinstance(node, ast.Call):
            name = ""
            if isinstance(node.func, ast.Name):
                name = node.func.id
            elif isinstance(node.func, ast.Attribute):
                name = node.func.attr
            if name in {"abs", "fabs"} and len(node.args) == 1:
                x, tainted = self.eval(node.args[0])
                return (abs(x), tainted) if x is not None else (None, tainted)
            if name in {"float"} and len(node.args) == 1:
                return self.eval(node.args[0])
        return None, False


def inspect_python_assignments(
    path: Path, root: Path
) -> list[dict[str, Any]]:
    text = read_text_safely(path)
    if text is None:
        return []

    try:
        tree = ast.parse(text, filename=str(path))
    except SyntaxError as exc:
        return [
            {
                "file_path": relpath(path, root),
                "line_number": getattr(exc, "lineno", -1),
                "assigned_symbol": "",
                "expression": "",
                "names_used": "",
                "numeric_literals": "",
                "safe_evaluated_value": np.nan,
                "matches_global_mu": False,
                "contains_global_mu_literal": False,
                "archive_like": is_archive_like(relpath(path, root)),
                "trace_class": "syntax_error",
                "notes": str(exc),
            }
        ]

    evaluator = SafeNumericEvaluator()
    rows: list[dict[str, Any]] = []

    assignment_nodes: list[
        tuple[ast.AST, Optional[ast.AST], int]
    ] = []

    for node in ast.walk(tree):
        if isinstance(node, ast.Assign):
            for target in node.targets:
                assignment_nodes.append(
                    (target, node.value, getattr(node, "lineno", -1))
                )
        elif isinstance(node, ast.AnnAssign):
            assignment_nodes.append(
                (node.target, node.value, getattr(node, "lineno", -1))
            )
        elif isinstance(node, ast.NamedExpr):
            assignment_nodes.append(
                (node.target, node.value, getattr(node, "lineno", -1))
            )

    assignment_nodes.sort(key=lambda item: item[2])

    for target, value_node, lineno in assignment_nodes:
        symbols = target_names(target)
        if not symbols:
            continue

        try:
            expression = ast.get_source_segment(text, value_node) or ast.unparse(value_node)
        except Exception:
            expression = ""

        value, depends_on_target_literal = evaluator.eval(value_node)
        literals = numeric_literals(value_node)
        name_hits = any(
            FORMULA_NAME_RE.search(symbol or "")
            for symbol in symbols
        )
        expression_hit = bool(
            FORMULA_NAME_RE.search(expression or "")
        )
        literal_hit = any(
            abs(x - GLOBAL_MU) <= EXACT_TOL for x in literals
        )
        evaluated_hit = (
            value is not None
            and near(value, GLOBAL_MU, FORMULA_TOL)
            and not depends_on_target_literal
        )

        # Keep assignments relevant to mu provenance, exact literals,
        # candidate formula operators, or exact evaluated values.
        relevant = (
            name_hits
            or expression_hit
            or literal_hit
            or evaluated_hit
            or (
                any(LIKELY_MU_RE.search(s) for s in symbols)
                and any(op in expression for op in ("mean", "median", "-", "+"))
            )
        )
        if relevant:
            trace_class = "relevant_assignment"
            if evaluated_hit and not literal_hit:
                trace_class = "code_expression_reconstructs_global_mu"
            elif literal_hit:
                trace_class = "contains_global_mu_literal"
            elif name_hits:
                trace_class = "global_mu_named_assignment"

            rows.append(
                {
                    "file_path": relpath(path, root),
                    "line_number": lineno,
                    "assigned_symbol": "|".join(symbols),
                    "expression": expression[:3000],
                    "names_used": "|".join(names_used(value_node)),
                    "numeric_literals": "|".join(
                        f"{x:.17g}" for x in literals
                    ),
                    "safe_evaluated_value": value,
                    "matches_global_mu": bool(evaluated_hit),
                    "contains_global_mu_literal": bool(literal_hit),
                    "depends_on_global_mu_literal": bool(depends_on_target_literal),
                    "archive_like": is_archive_like(relpath(path, root)),
                    "trace_class": trace_class,
                    "notes": "",
                }
            )

        # Update scalar environment after recording.
        if value is not None:
            for symbol in symbols:
                if re.fullmatch(r"[A-Za-z_]\w*", symbol):
                    evaluator.env[symbol] = (value, depends_on_target_literal)

    return rows


# ---------------------------------------------------------------------
# CSV aggregate and pairwise reconstruction
# ---------------------------------------------------------------------

def likely_numeric_columns(df: pd.DataFrame) -> list[str]:
    cols: list[str] = []
    for col in df.columns:
        numeric = pd.to_numeric(df[col], errors="coerce")
        if numeric.notna().sum() >= 2:
            cols.append(str(col))
    return cols


def aggregate_rows_for_csv(
    path: Path, root: Path
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    try:
        df = pd.read_csv(path, nrows=MAX_CSV_ROWS)
    except Exception:
        return [], []

    numeric_cols = likely_numeric_columns(df)
    aggregate_rows: list[dict[str, Any]] = []
    pair_rows: list[dict[str, Any]] = []

    forbidden_operand_re = re.compile(
        r"(global_mu|omega[_ ]?m|benchmark|reference|target|discrepancy)",
        re.IGNORECASE,
    )
    preferred_cols = [
        c for c in numeric_cols
        if LIKELY_MU_RE.search(c)
        and not forbidden_operand_re.search(c)
    ]
    if not preferred_cols:
        preferred_cols = numeric_cols[:30]

    ops = {
        "mean": np.nanmean,
        "median": np.nanmedian,
        "min": np.nanmin,
        "max": np.nanmax,
        "std_population": np.nanstd,
        "range": lambda a: np.nanmax(a) - np.nanmin(a),
        "q25": lambda a: np.nanquantile(a, 0.25),
        "q75": lambda a: np.nanquantile(a, 0.75),
    }

    for col in preferred_cols[:80]:
        arr = pd.to_numeric(df[col], errors="coerce").to_numpy(dtype=float)
        arr = arr[np.isfinite(arr)]
        if arr.size < 2:
            continue
        # A column already containing the target value is downstream/circular
        # evidence, not an independent aggregate reconstruction.
        if np.isclose(arr, GLOBAL_MU, atol=EXACT_TOL, rtol=0).any():
            continue
        for op_name, func in ops.items():
            try:
                value = float(func(arr))
            except Exception:
                continue
            if abs(value - GLOBAL_MU) <= FORMULA_TOL:
                aggregate_rows.append(
                    {
                        "file_path": relpath(path, root),
                        "column": col,
                        "operation": op_name,
                        "operand_count": int(arr.size),
                        "computed_value": value,
                        "difference_from_global_mu": value - GLOBAL_MU,
                        "archive_like": is_archive_like(relpath(path, root)),
                        "formula_text": f"{op_name}({col})",
                        "status": "EXACT_AGGREGATE_MATCH",
                    }
                )

    # Weighted means are tested only with semantically plausible columns.
    weight_cols = [
        c for c in numeric_cols if LIKELY_WEIGHT_RE.search(c)
    ]
    for value_col in preferred_cols[:40]:
        values = pd.to_numeric(df[value_col], errors="coerce")
        for weight_col in weight_cols[:30]:
            if value_col == weight_col:
                continue
            weights = pd.to_numeric(df[weight_col], errors="coerce")
            mask = values.notna() & weights.notna() & np.isfinite(values) & np.isfinite(weights)
            if mask.sum() < 2:
                continue
            w = weights[mask].to_numpy(dtype=float)
            x = values[mask].to_numpy(dtype=float)
            if np.allclose(w.sum(), 0.0):
                continue
            value = float(np.average(x, weights=w))
            if abs(value - GLOBAL_MU) <= FORMULA_TOL:
                aggregate_rows.append(
                    {
                        "file_path": relpath(path, root),
                        "column": value_col,
                        "operation": f"weighted_mean_by:{weight_col}",
                        "operand_count": int(mask.sum()),
                        "computed_value": value,
                        "difference_from_global_mu": value - GLOBAL_MU,
                        "archive_like": is_archive_like(relpath(path, root)),
                        "formula_text": (
                            f"sum({value_col}*{weight_col})/"
                            f"sum({weight_col})"
                        ),
                        "status": "EXACT_WEIGHTED_AGGREGATE_MATCH",
                    }
                )

    # Pairwise row-wise operations among likely mu/center columns.
    pair_cols = preferred_cols[:40]
    for i, a_col in enumerate(pair_cols):
        a = pd.to_numeric(df[a_col], errors="coerce")
        for b_col in pair_cols[i + 1:]:
            b = pd.to_numeric(df[b_col], errors="coerce")
            mask = a.notna() & b.notna()
            if not mask.any():
                continue
            operations = {
                "abs_difference": (a[mask] - b[mask]).abs(),
                "difference_a_minus_b": a[mask] - b[mask],
                "difference_b_minus_a": b[mask] - a[mask],
                "sum": a[mask] + b[mask],
                "mean_pair": (a[mask] + b[mask]) / 2.0,
            }
            nonzero_b = b[mask].replace(0, np.nan)
            operations["ratio_a_over_b"] = a[mask] / nonzero_b
            nonzero_a = a[mask].replace(0, np.nan)
            operations["ratio_b_over_a"] = b[mask] / nonzero_a

            for op_name, series in operations.items():
                numeric = pd.to_numeric(series, errors="coerce")
                hit = np.isclose(
                    numeric.to_numpy(dtype=float, na_value=np.nan),
                    GLOBAL_MU,
                    atol=FORMULA_TOL,
                    rtol=0,
                    equal_nan=False,
                )
                for pos in np.flatnonzero(hit):
                    idx = numeric.index[pos]
                    aval = finite_float(a.loc[idx])
                    bval = finite_float(b.loc[idx])
                    if (
                        aval is None
                        or bval is None
                        or near(aval, GLOBAL_MU, EXACT_TOL)
                        or near(bval, GLOBAL_MU, EXACT_TOL)
                    ):
                        continue
                    pair_rows.append(
                        {
                            "file_path": relpath(path, root),
                            "row_index": int(idx) if isinstance(idx, (int, np.integer)) else str(idx),
                            "operand_a_column": a_col,
                            "operand_b_column": b_col,
                            "operand_a_value": aval,
                            "operand_b_value": bval,
                            "operation": op_name,
                            "computed_value": finite_float(numeric.loc[idx]),
                            "difference_from_global_mu": finite_float(numeric.loc[idx]) - GLOBAL_MU,
                            "archive_like": is_archive_like(relpath(path, root)),
                            "status": "EXACT_PAIRWISE_MATCH",
                        }
                    )

    return aggregate_rows, pair_rows


# ---------------------------------------------------------------------
# Sharp candidate closure
# ---------------------------------------------------------------------

def close_sharp_candidate(
    direct_recomputations: pd.DataFrame,
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    if direct_recomputations.empty:
        return rows

    needed = {
        "early_value",
        "central_value",
        "recomputed_abs_difference",
    }
    if not needed.issubset(direct_recomputations.columns):
        return rows

    diffs = pd.to_numeric(
        direct_recomputations["recomputed_abs_difference"],
        errors="coerce",
    )
    mask = np.isclose(
        diffs, SHARP_VALUE, atol=FORMULA_TOL, rtol=0
    )

    for _, row in direct_recomputations.loc[mask].iterrows():
        early = finite_float(row.get("early_value"))
        central = finite_float(row.get("central_value"))
        if early is None or central is None:
            continue
        value = abs(central - early)
        rows.append(
            {
                "file_path": row.get("file_path"),
                "row_index": row.get("row_index"),
                "family": row.get("family"),
                "early_column": row.get("early_column"),
                "central_column": row.get("central_column"),
                "early_value": early,
                "central_value": central,
                "formula": "abs(central_mu - early_mu)",
                "recomputed_value": value,
                "difference_from_sharp_value": value - SHARP_VALUE,
                "status": (
                    "SHARP_FORMULA_CLOSED"
                    if abs(value - SHARP_VALUE) <= FORMULA_TOL
                    else "NO_MATCH"
                ),
            }
        )
    return rows


# ---------------------------------------------------------------------
# Verdict
# ---------------------------------------------------------------------

def classify_global_mu(
    assignment_rows: list[dict[str, Any]],
    aggregate_rows: list[dict[str, Any]],
    pair_rows: list[dict[str, Any]],
    exact_rows: list[dict[str, Any]],
) -> tuple[str, list[dict[str, Any]]]:
    code_hits = [
        r for r in assignment_rows
        if r.get("matches_global_mu")
        and not r.get("contains_global_mu_literal")
        and not r.get("depends_on_global_mu_literal")
        and not r.get("archive_like")
    ]
    aggregate_hits = [
        r for r in aggregate_rows
        if not r.get("archive_like")
    ]
    pair_hits = [
        r for r in pair_rows
        if not r.get("archive_like")
    ]

    ranked: list[dict[str, Any]] = []
    for row in code_hits:
        ranked.append(
            {
                "candidate_type": "code_expression",
                "file_path": row.get("file_path"),
                "location": row.get("line_number"),
                "formula": row.get("expression"),
                "computed_value": row.get("safe_evaluated_value"),
                "rank_reason": (
                    "non-archive code expression evaluates to global_mu "
                    "without containing the target literal"
                ),
            }
        )
    for row in aggregate_hits:
        ranked.append(
            {
                "candidate_type": "column_aggregate",
                "file_path": row.get("file_path"),
                "location": row.get("column"),
                "formula": row.get("formula_text"),
                "computed_value": row.get("computed_value"),
                "rank_reason": (
                    "non-archive output aggregation reproduces global_mu"
                ),
            }
        )
    for row in pair_hits:
        ranked.append(
            {
                "candidate_type": "pairwise_operands",
                "file_path": row.get("file_path"),
                "location": row.get("row_index"),
                "formula": (
                    f"{row.get('operation')}("
                    f"{row.get('operand_a_column')},"
                    f"{row.get('operand_b_column')})"
                ),
                "computed_value": row.get("computed_value"),
                "rank_reason": (
                    "non-archive row operands reproduce global_mu"
                ),
            }
        )

    ranked.sort(
        key=lambda r: (
            is_archive_like(str(r.get("file_path", ""))),
            stage_rank(str(r.get("file_path", ""))),
        )
    )

    if code_hits:
        return "FORMULA_CLOSED_FROM_CODE_AND_OPERANDS", ranked
    if aggregate_hits or pair_hits:
        return "FORMULA_CLOSED_FROM_OUTPUT_AGGREGATION", ranked

    nonarchive_exact = [
        r for r in exact_rows if not r.get("archive_like")
    ]
    if nonarchive_exact:
        return "LITERAL_OR_DOWNSTREAM_ONLY", ranked
    return "UNRESOLVED", ranked


# ---------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------

def main() -> int:
    root = PROJECT_ROOT
    if len(sys.argv) > 1 and sys.argv[1].strip():
        root = Path(sys.argv[1]).expanduser()

    root = root.resolve()
    if not root.exists():
        raise FileNotFoundError(f"Project root not found: {root}")

    outdir = root / OUT_REL
    outdir.mkdir(parents=True, exist_ok=True)

    v1_dir = find_v1_dir(root)
    occurrences = load_v1_table(
        v1_dir, "stage7F_value_occurrences.csv"
    )
    dependency_edges = load_v1_table(
        v1_dir, "stage7F_dependency_edges.csv"
    )
    direct_recomputations = load_v1_table(
        v1_dir, "stage7F_direct_mu_recomputations.csv"
    )

    files, inventory_rows, ancestor_trace = collect_candidate_files(
        root, occurrences, dependency_edges
    )

    exact_rows: list[dict[str, Any]] = []
    assignment_rows: list[dict[str, Any]] = []
    aggregate_rows: list[dict[str, Any]] = []
    pair_rows: list[dict[str, Any]] = []
    scan_errors: list[dict[str, Any]] = []

    for path in files:
        try:
            if path.suffix.lower() == ".csv":
                exact_rows.extend(inspect_csv_occurrences(path, root))
                agg, pair = aggregate_rows_for_csv(path, root)
                aggregate_rows.extend(agg)
                pair_rows.extend(pair)
            else:
                exact_rows.extend(inspect_text_occurrences(path, root))

            if path.suffix.lower() == ".py":
                assignment_rows.extend(
                    inspect_python_assignments(path, root)
                )
        except Exception as exc:
            scan_errors.append(
                {
                    "file_path": relpath(path, root),
                    "error": repr(exc),
                    "traceback": traceback.format_exc(),
                }
            )

    sharp_rows = close_sharp_candidate(direct_recomputations)
    verdict, ranked_candidates = classify_global_mu(
        assignment_rows,
        aggregate_rows,
        pair_rows,
        exact_rows,
    )

    # Manuscript policy is derived only after provenance classification.
    discrepancy_pct = (
        abs(GLOBAL_MU - OMEGA_M_REFERENCE)
        / OMEGA_M_REFERENCE
        * 100.0
    )
    sharp_discrepancy_pct = (
        abs(SHARP_VALUE - OMEGA_M_REFERENCE)
        / OMEGA_M_REFERENCE
        * 100.0
    )

    if verdict.startswith("FORMULA_CLOSED"):
        manuscript_action = (
            "global_mu may be retained with its recovered formula, "
            "subject to human confirmation of the top-ranked source row."
        )
    else:
        manuscript_action = (
            "retain global_mu only as a persistent internally generated "
            "statistic; do not print a defining formula until the origin "
            "is closed."
        )

    summary = {
        "generated_at": now_iso(),
        "script": Path(__file__).name if "__file__" in globals() else "Stage-7F_v2_global_mu_origin_formula_trace.py",
        "project_root": str(root),
        "v1_evidence_directory": str(v1_dir) if v1_dir else None,
        "non_fitting_rule": (
            "No Omega_m distance was used to select or rank formulas."
        ),
        "global_mu": {
            "value": GLOBAL_MU,
            "provenance_verdict": verdict,
            "candidate_count": len(ranked_candidates),
            "top_candidates": ranked_candidates[:25],
            "benchmark_reference_applied_after_classification": OMEGA_M_REFERENCE,
            "benchmark_discrepancy_percent": discrepancy_pct,
            "manuscript_action": manuscript_action,
        },
        "sharp_candidate": {
            "value": SHARP_VALUE,
            "formula": "abs(central_mu - early_mu)",
            "closure_row_count": len(sharp_rows),
            "provenance_verdict": (
                "SHARP_FORMULA_CLOSED"
                if sharp_rows
                else "SHARP_FORMULA_NOT_RECONSTRUCTED"
            ),
            "benchmark_reference_applied_after_classification": OMEGA_M_REFERENCE,
            "benchmark_discrepancy_percent": sharp_discrepancy_pct,
            "manuscript_action": (
                "Eligible for guarded reporting as a separately defined "
                "early-central separation, not as a replacement for "
                "global_mu unless the manuscript explicitly distinguishes "
                "the two statistics."
            ),
        },
        "counts": {
            "candidate_files": len(files),
            "exact_occurrences": len(exact_rows),
            "python_assignment_rows": len(assignment_rows),
            "aggregate_matches": len(aggregate_rows),
            "pairwise_matches": len(pair_rows),
            "dependency_ancestor_edges": len(ancestor_trace),
            "scan_errors": len(scan_errors),
        },
    }

    write_csv(
        outdir / "stage7F_v2_candidate_file_inventory.csv",
        inventory_rows,
        [
            "file_path", "stage_rank", "archive_like", "size_bytes",
            "modified_time", "sha256", "selection_reason",
        ],
    )
    write_csv(
        outdir / "stage7F_v2_exact_value_occurrences.csv",
        exact_rows,
        [
            "file_path", "file_type", "target_name", "line_or_row",
            "column_or_key", "context", "archive_like",
            "occurrence_class",
        ],
    )
    write_csv(
        outdir / "stage7F_v2_python_assignment_trace.csv",
        assignment_rows,
        [
            "file_path", "line_number", "assigned_symbol",
            "expression", "names_used", "numeric_literals",
            "safe_evaluated_value", "matches_global_mu",
            "contains_global_mu_literal",
            "depends_on_global_mu_literal", "archive_like",
            "trace_class", "notes",
        ],
    )
    write_csv(
        outdir / "stage7F_v2_column_aggregate_reconstructions.csv",
        aggregate_rows,
        [
            "file_path", "column", "operation", "operand_count",
            "computed_value", "difference_from_global_mu",
            "archive_like", "formula_text", "status",
        ],
    )
    write_csv(
        outdir / "stage7F_v2_pairwise_operand_reconstructions.csv",
        pair_rows,
        [
            "file_path", "row_index", "operand_a_column",
            "operand_b_column", "operand_a_value", "operand_b_value",
            "operation", "computed_value",
            "difference_from_global_mu", "archive_like", "status",
        ],
    )
    write_csv(
        outdir / "stage7F_v2_sharp_candidate_closure.csv",
        sharp_rows,
        [
            "file_path", "row_index", "family", "early_column",
            "central_column", "early_value", "central_value",
            "formula", "recomputed_value",
            "difference_from_sharp_value", "status",
        ],
    )
    write_csv(
        outdir / "stage7F_v2_dependency_ancestor_trace.csv",
        ancestor_trace,
        [
            "seed_file", "dependent_file", "source_file", "depth",
            "edge_kind", "context",
        ],
    )
    write_csv(
        outdir / "stage7F_v2_scan_errors.csv",
        scan_errors,
        ["file_path", "error", "traceback"],
    )
    json_dump(
        outdir / "stage7F_v2_global_mu_formula_verdict.json",
        summary,
    )

    report_lines = [
        "=" * 79,
        "QEG GLOBAL_MU ORIGIN-FORMULA TRACE — STAGE-7F v2",
        "=" * 79,
        f"Generated: {summary['generated_at']}",
        f"Project root: {root}",
        "",
        "NON-FITTING RULE",
        "-" * 79,
        summary["non_fitting_rule"],
        "",
        "GLOBAL_MU",
        "-" * 79,
        f"value: {GLOBAL_MU:.15g}",
        f"provenance_verdict: {verdict}",
        f"candidate_count: {len(ranked_candidates)}",
        f"benchmark discrepancy (applied afterward): {discrepancy_pct:.6f}%",
        f"manuscript_action: {manuscript_action}",
        "",
        "TOP FORMULA CANDIDATES",
        "-" * 79,
    ]
    if ranked_candidates:
        for i, candidate in enumerate(ranked_candidates[:25], start=1):
            report_lines.extend(
                [
                    f"{i}. type={candidate['candidate_type']}",
                    f"   file={candidate['file_path']}",
                    f"   location={candidate['location']}",
                    f"   formula={candidate['formula']}",
                    f"   computed_value={candidate['computed_value']}",
                    f"   reason={candidate['rank_reason']}",
                ]
            )
    else:
        report_lines.append(
            "No non-circular formula candidate was recovered."
        )

    report_lines.extend(
        [
            "",
            "SUB-PERCENT EARLY-CENTRAL SEPARATION",
            "-" * 79,
            "formula: abs(central_mu - early_mu)",
            f"value: {SHARP_VALUE:.15g}",
            f"closure rows: {len(sharp_rows)}",
            (
                "status: SHARP_FORMULA_CLOSED"
                if sharp_rows
                else "status: SHARP_FORMULA_NOT_RECONSTRUCTED"
            ),
            f"benchmark discrepancy (applied afterward): {sharp_discrepancy_pct:.6f}%",
        ]
    )
    if sharp_rows:
        first = sharp_rows[0]
        report_lines.extend(
            [
                f"example early_mu: {first['early_value']:.15g}",
                f"example central_mu: {first['central_value']:.15g}",
                f"direct recomputation: {first['recomputed_value']:.15g}",
                f"source: {first['file_path']}",
            ]
        )

    report_lines.extend(
        [
            "",
            "COUNTS",
            "-" * 79,
            *[
                f"{key}: {value}"
                for key, value in summary["counts"].items()
            ],
            "",
            "INTERPRETATION",
            "-" * 79,
            (
                "Repeated preservation is not formula recovery.  A formula "
                "is promoted only when code or upstream operands reconstruct "
                "the value without reusing the target literal."
            ),
        ]
    )

    (outdir / "Stage-7F_v2_global_mu_formula_report.txt").write_text(
        "\n".join(report_lines) + "\n",
        encoding="utf-8",
    )

    print("\n".join(report_lines))
    print(f"\nOutputs written to:\n{outdir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
