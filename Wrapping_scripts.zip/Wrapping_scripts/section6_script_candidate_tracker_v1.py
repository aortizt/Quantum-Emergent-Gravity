#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
===============================================================================
QEG Physica D — Section 6 Script Candidate Tracker
Section name in paper:
    Family universality and resolution robustness

Project:
    Quantum-Emergent Gravity

Purpose
-------
This Spyder-friendly audit script scans the QEG project tree for scripts,
ledgers, and notes that can supply the missing mathematics for manuscript
Section 6 only, especially:

1) the two-sector template class for
       rho(s) ~= E(s) + C(s)

2) the family-universality test across
       BARI / NUFIT / VALENCIA

3) the resolution-robustness test across
       48 bins / 361 bins

4) the normalization / mass-fraction definitions

5) the transformation / coordinate-robustness bookkeeping relevant to
       Section 6

This script does not refit, relabel, or regenerate QEG data.
It only locates candidate source scripts and summarizes why they are relevant.

Default project root
--------------------
/home/dakini/Downloads/010-Quantum_Emergent_Gravity

Outputs
-------
PhysicaD/section6_script_candidate_audit/
    section6_script_candidate_audit.csv
    section6_script_candidate_audit.json
    section6_script_candidate_audit_notes.txt
    section6_top_candidate_snippets.txt

Spyder usage
------------
Open this file in Spyder and run it.

Optional terminal usage
-----------------------
python3 section6_script_candidate_tracker_v1.py
python3 section6_script_candidate_tracker_v1.py /home/dakini/Downloads/010-Quantum_Emergent_Gravity

===============================================================================
"""

from __future__ import annotations

import csv
import hashlib
import json
import re
import sys
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, Iterable, List, Tuple


DEFAULT_PROJECT_ROOT = Path("/home/dakini/Downloads/010-Quantum_Emergent_Gravity")
SECTION_NAME = "Family universality and resolution robustness"

# Keep the scan broad enough to catch scripts moved into curated folders,
# but avoid huge binary/data folders.
INCLUDE_SUFFIXES = {".py", ".md", ".txt", ".tex"}
EXCLUDE_DIR_PARTS = {
    ".git", "__pycache__", ".ipynb_checkpoints", "venv", ".venv",
    "env", "node_modules", "cache", "plots", "figures",
}

# Weighted evidence keys.  These are deliberately Section-6-specific.
PATTERNS: Dict[str, Tuple[int, List[str]]] = {
    # Section-6 identity: family universality and resolution robustness.
    "section6_name_or_intent": (
        40,
        [
            r"family universality",
            r"resolution robustness",
            r"family[-_ ]aware universality",
            r"two[-_ ]lobe universality",
            r"universality test",
        ],
    ),
    "families": (
        25,
        [r"\bBARI\b", r"\bNUFIT\b", r"\bVALENCIA\b", r"EXPECTED_FAMILIES"],
    ),
    "resolution": (
        20,
        [r"\b48\b", r"\b361\b", r"48bins", r"361bins", r"resolution", r"n_bins"],
    ),

    # Missing mathematics: template class E+C and fitting windows.
    "two_lobe_law": (
        35,
        [
            r"rho\(s\)\s*[~≈=]+.*E\(s\).*C\(s\)",
            r"E\(s\).*C\(s\)",
            r"two_lobe",
            r"two[-_ ]lobe",
            r"early\s*\+\s*central",
            r"early.*central.*lobe",
            r"canonical two-lobe",
        ],
    ),
    "template_definitions": (
        40,
        [
            r"def gaussian",
            r"def two_gaussian",
            r"def skewed_gaussian",
            r"def fit_two_lobe",
            r"def fit_skewed_two_lobe",
            r"def canonical_component_curve",
            r"def build_canonical_curve",
            r"EARLY_WINDOW",
            r"CENTRAL_WINDOW",
        ],
    ),
    "component_labels": (
        20,
        [
            r"E_early",
            r"C_central",
            r"early_component",
            r"central_component",
            r"rho_canonical",
            r"mu_early",
            r"mu_central",
            r"sigma_early",
            r"sigma_central",
        ],
    ),

    # Missing mathematics: mass fractions and normalization.
    "mass_fraction_normalization": (
        35,
        [
            r"mass_fraction",
            r"window_mass_fraction",
            r"component_integral",
            r"canonical_component_curve",
            r"normalize mass",
            r"early_mass_fraction",
            r"central_mass_fraction",
            r"np\.trapz",
            r"np\.trapezoid",
        ],
    ),

    # Missing mathematics: transformations / robustness.
    "transformation_tests": (
        35,
        [
            r"transformation_tests",
            r"coordinate_variants",
            r"coordinate robustness",
            r"resolution_stability",
            r"amplitude_scaling_invariance",
            r"reflection_asymmetry",
            r"reparameterization",
            r"rank_uniformized",
            r"arc_length",
            r"cumulative_mass",
        ],
    ),

    # Provenance repair / selection, useful but not final math.
    "provenance_repair": (
        15,
        [
            r"family_preserving",
            r"provenance",
            r"no row-index",
            r"row-index",
            r"explicit family labels",
            r"FIT_id",
            r"Stage-6O",
        ],
    ),

    # Output files likely to support Section 6.
    "section6_outputs": (
        25,
        [
            r"stage6P_v6_family_two_lobe_fit_summary",
            r"stage6P_v6_family_lobe_parameters",
            r"stage6P_v6_candidate_vs_canonical_comparison",
            r"stage6Q_canonical_parameters",
            r"stage6Q_dimensionless_ratios",
            r"stage6Q_transformation_tests",
            r"stage6Q_canonical_curve",
        ],
    ),

    # Caution: physics comparison belongs later, not Section 6 core.
    "physics_later_warning": (
        -10,
        [
            r"cosmology",
            r"Omega",
            r"PDG",
            r"Friedmann",
            r"Green-function",
            r"kernel",
        ],
    ),
}


PRIMARY_SCRIPT_NAME_HINTS = {
    "Stage-6P_two_lobe_universality_test_on_v5_candidate_v6.py": 120,
    "Stage-6Q_canonical_law_extraction_v1.py": 110,
    "Stage-6N_canonical_two_lobe_law_v1a.py": 70,
    "Stage-6M_targeted_modal_resolution_v2c.py": 60,
    "Stage-6O_direct_modal_rho_provenance_audit_v1.py": 30,
}


@dataclass
class Candidate:
    rank_score: int
    role: str
    path: str
    relative_path: str
    suffix: str
    sha256_12: str
    size_bytes: int
    matched_groups: str
    matched_terms: str
    section6_use: str
    caution: str


def echo(msg: str = "") -> None:
    print(msg, flush=True)


def banner(title: str) -> None:
    echo("=" * 79)
    echo(title)
    echo("=" * 79)


def resolve_project_root(argv: List[str]) -> Path:
    if len(argv) >= 2:
        p = Path(argv[1]).expanduser().resolve()
        if p.exists():
            return p
        raise FileNotFoundError(f"Explicit project root does not exist: {p}")
    if DEFAULT_PROJECT_ROOT.exists():
        return DEFAULT_PROJECT_ROOT
    return Path.cwd().resolve()


def should_skip(path: Path) -> bool:
    parts = set(path.parts)
    if parts.intersection(EXCLUDE_DIR_PARTS):
        return True
    if path.suffix.lower() not in INCLUDE_SUFFIXES:
        return True
    if path.name.startswith("section6_script_candidate_tracker"):
        return True
    if "section6_script_candidate_audit" in path.parts:
        return True
    # Avoid scanning very large markdown ledgers if they become enormous?  We keep
    # them but cap snippet extraction later.
    return False


def safe_read_text(path: Path, max_bytes: int = 2_000_000) -> str:
    data = path.read_bytes()
    if len(data) > max_bytes:
        data = data[:max_bytes]
    return data.decode("utf-8", errors="ignore")


def sha256_12(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()[:12]


def find_matches(text: str) -> Tuple[int, Dict[str, List[str]]]:
    score = 0
    found: Dict[str, List[str]] = {}
    for group, (weight, patterns) in PATTERNS.items():
        hits = []
        for pat in patterns:
            if re.search(pat, text, flags=re.IGNORECASE | re.MULTILINE):
                hits.append(pat)
        if hits:
            found[group] = hits
            score += weight * len(hits)
    return score, found


def classify_role(path: Path, found: Dict[str, List[str]], score: int) -> Tuple[str, str, str]:
    name = path.name
    groups = set(found.keys())

    # Filename identity beats keyword scoring.  This prevents a ledger or the
    # tracker script itself from being mistaken for the mathematical source.
    if "Stage-6P" in name:
        role = "PRIMARY_SECTION6_METHOD_SOURCE"
        use = (
            "Use for manuscript Section 6 family-universality/resolution-robustness method: "
            "family split, 48/361 resolutions, bounded two-Gaussian diagnostic fit, "
            "fit quality, mass-window fractions, and candidate-vs-canonical comparison."
        )
    elif "Stage-6Q" in name:
        role = "PRIMARY_SECTION6_CANONICALIZATION_SOURCE"
        use = (
            "Use for Section 6 normalization/canonicalization paragraph: E_early+C_central curve, "
            "dimensionless ratios, invariant summaries, and transformation bookkeeping."
        )
    elif "Stage-6N" in name:
        role = "SUPPORTING_POOLED_COORDINATE_ROBUSTNESS_SOURCE"
        use = (
            "Use only as supporting provenance: pooled canonical law and monotone coordinate robustness. "
            "Do not treat as final family-universality closure."
        )
    elif "Stage-6M" in name:
        role = "SUPPORTING_DISCOVERY_SOURCE"
        use = (
            "Use for historical/methodological explanation of how constrained bimodality was discovered. "
            "Not the final Section 6 family universality audit."
        )
    elif "Stage-6O" in name:
        role = "PROVENANCE_SUPPORT_SOURCE"
        use = (
            "Use for notes on family-label repair and why row-index assignment was forbidden. "
            "Not the source of the E/C template mathematics."
        )
    elif path.name.upper().endswith("LEDGER.MD") or "EVIDENCE_LEDGER" in path.name:
        role = "LEDGER_CONTEXT_SOURCE"
        use = (
            "Use for transition narrative and to identify expected script/output names. "
            "Do not use ledger prose as the primary mathematical source if scripts are available."
        )
    elif "families" in groups and "resolution" in groups and "template_definitions" in groups:
        role = "PRIMARY_SECTION6_METHOD_SOURCE"
        use = (
            "Use for manuscript Section 6 family-universality/resolution-robustness method if it is the current curated copy of Stage-6P."
        )
    elif "section6_outputs" in groups and "transformation_tests" in groups:
        role = "PRIMARY_SECTION6_CANONICALIZATION_SOURCE"
        use = (
            "Use for Section 6 normalization/canonicalization if it is the current curated copy of Stage-6Q."
        )
    elif "coordinate_variants" in "".join(sum(found.values(), [])):
        role = "SUPPORTING_POOLED_COORDINATE_ROBUSTNESS_SOURCE"
        use = (
            "Use only as supporting provenance: pooled coordinate robustness, not final family closure."
        )
    elif "provenance_repair" in groups:
        role = "PROVENANCE_SUPPORT_SOURCE"
        use = (
            "Use for notes on family-label repair and why row-index assignment was forbidden."
        )
    else:
        role = "REVIEW_CANDIDATE"
        use = "Review manually; candidate contains Section-6-related tokens but role is uncertain."

    caution = ""
    if "physics_later_warning" in groups:
        caution = (
            "Contains physics/cosmology/Green/kernel language. Keep such material out of Section 6 "
            "unless it is only a caution/provenance note; Section 6 should stay family-universality/resolution-focused."
        )

    return role, use, caution


def safe_short_name(path: Path) -> str:
    return path.name


def make_candidate(project_root: Path, path: Path) -> Candidate:
    text = safe_read_text(path)
    score, found = find_matches(text)
    score += PRIMARY_SCRIPT_NAME_HINTS.get(path.name, 0)

    groups_sorted = sorted(found.keys())
    matched_terms = []
    for group in groups_sorted:
        # Store short readable terms rather than raw regex for common cases.
        matched_terms.extend(found[group][:8])

    role, use, caution = classify_role(path, found, score)

    rel = str(path.relative_to(project_root)) if str(path).startswith(str(project_root)) else str(path)
    try:
        digest = sha256_12(path)
    except Exception:
        digest = ""

    return Candidate(
        rank_score=int(score),
        role=role,
        path=str(path),
        relative_path=rel,
        suffix=path.suffix.lower(),
        sha256_12=digest,
        size_bytes=path.stat().st_size,
        matched_groups=";".join(groups_sorted),
        matched_terms=";".join(matched_terms),
        section6_use=use,
        caution=caution,
    )


def extract_snippets(path: Path, terms: Iterable[str], max_per_file: int = 8, radius: int = 450) -> List[str]:
    text = safe_read_text(path)
    snippets = []
    seen_spans = []
    for term in terms:
        # Treat term as plain-ish when possible; regex otherwise.
        try:
            matches = list(re.finditer(term, text, flags=re.IGNORECASE | re.MULTILINE))
        except re.error:
            matches = list(re.finditer(re.escape(term), text, flags=re.IGNORECASE | re.MULTILINE))
        for m in matches[:3]:
            start = max(0, m.start() - radius)
            end = min(len(text), m.end() + radius)
            # Avoid near-duplicates.
            if any(abs(start - s) < radius for s, _ in seen_spans):
                continue
            seen_spans.append((start, end))
            snip = text[start:end].replace("\r\n", "\n")
            snippets.append(f"\n--- {path.name} :: match {term!r} ---\n{snip}\n")
            if len(snippets) >= max_per_file:
                return snippets
    return snippets


def write_outputs(project_root: Path, candidates: List[Candidate]) -> Path:
    out_dir = project_root / "PhysicaD" / "section6_script_candidate_audit"
    if not out_dir.exists():
        out_dir = project_root / "section6_script_candidate_audit"
    out_dir.mkdir(parents=True, exist_ok=True)

    csv_path = out_dir / "section6_script_candidate_audit.csv"
    json_path = out_dir / "section6_script_candidate_audit.json"
    notes_path = out_dir / "section6_script_candidate_audit_notes.txt"
    snippets_path = out_dir / "section6_top_candidate_snippets.txt"

    rows = [asdict(c) for c in candidates]
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()) if rows else list(Candidate.__dataclass_fields__.keys()))
        writer.writeheader()
        writer.writerows(rows)

    summary = {
        "project_root": str(project_root),
        "section_name_in_paper": SECTION_NAME,
        "n_candidates": len(candidates),
        "outputs": {
            "csv": str(csv_path),
            "json": str(json_path),
            "notes": str(notes_path),
            "snippets": str(snippets_path),
        },
        "top_candidates": rows[:20],
        "recommended_minimal_script_set": [
            {
                "role": "PRIMARY_SECTION6_METHOD_SOURCE",
                "script": "Stage-6P_two_lobe_universality_test_on_v5_candidate_v6.py",
                "why": "Defines family/resolution test, two-Gaussian E/C diagnostic model, windows, fit metrics, and window mass fractions.",
            },
            {
                "role": "PRIMARY_SECTION6_CANONICALIZATION_SOURCE",
                "script": "Stage-6Q_canonical_law_extraction_v1.py",
                "why": "Extracts normalized canonical E+C curve, ratios, invariant summary, and transformation bookkeeping.",
            },
            {
                "role": "SUPPORTING_POOLED_COORDINATE_ROBUSTNESS_SOURCE",
                "script": "Stage-6N_canonical_two_lobe_law_v1a.py",
                "why": "Documents pooled two-lobe law and coordinate variants; useful as background, not the final Section 6 family closure.",
            },
        ],
    }
    with json_path.open("w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)

    notes = []
    notes.append("=" * 79)
    notes.append("QEG Physica D — Section 6 Script Candidate Audit")
    notes.append("=" * 79)
    notes.append(f"Section name in paper: {SECTION_NAME}")
    notes.append(f"Project root: {project_root}")
    notes.append("")
    notes.append("READING OF RESULTS")
    notes.append("------------------")
    notes.append("Use the top-ranked candidates to recover the missing Section 6 mathematics.")
    notes.append("")
    notes.append("Minimal likely set:")
    notes.append("1) Stage-6P_two_lobe_universality_test_on_v5_candidate_v6.py")
    notes.append("   - final family universality + resolution robustness audit")
    notes.append("   - bounded two-Gaussian diagnostic template")
    notes.append("   - EARLY_WINDOW / CENTRAL_WINDOW")
    notes.append("   - window mass fractions")
    notes.append("")
    notes.append("2) Stage-6Q_canonical_law_extraction_v1.py")
    notes.append("   - normalized canonical E(s)+C(s) representation")
    notes.append("   - early/central mass fractions and ratios")
    notes.append("   - transformation bookkeeping: amplitude scaling, resolution stability, reflection")
    notes.append("")
    notes.append("3) Stage-6N_canonical_two_lobe_law_v1a.py")
    notes.append("   - pooled coordinate robustness and model zoo support")
    notes.append("   - useful only as background unless Section 6 needs a short prehistory sentence")
    notes.append("")
    notes.append("Avoid putting Stage-6R or later physics/cosmology material into Section 6.")
    notes.append("")
    notes.append("TOP CANDIDATES")
    notes.append("--------------")
    for i, c in enumerate(candidates[:20], start=1):
        notes.append(f"{i:02d}. score={c.rank_score:5d} role={c.role}")
        notes.append(f"    {c.relative_path}")
        notes.append(f"    use: {c.section6_use}")
        if c.caution:
            notes.append(f"    caution: {c.caution}")
        notes.append("")
    notes.append("=" * 79)
    notes_path.write_text("\n".join(notes), encoding="utf-8")

    # Snippets for top candidates only.
    snippet_terms = [
        "def two_gaussian", "def fit_two_lobe", "EARLY_WINDOW", "CENTRAL_WINDOW",
        "def window_mass_fraction", "def build_canonical_curve",
        "def canonical_component_curve", "def transformation_tests",
        "def add_dimensionless_ratios", "coordinate_variants",
        "family universality", "resolution robustness",
    ]
    snips = []
    for c in candidates[:8]:
        p = Path(c.path)
        if p.exists():
            snips.append("\n" + "=" * 79 + f"\nFILE: {c.relative_path}\nROLE: {c.role}\n" + "=" * 79 + "\n")
            snips.extend(extract_snippets(p, snippet_terms))
    snippets_path.write_text("\n".join(snips), encoding="utf-8")

    return out_dir


def main(argv: List[str]) -> int:
    banner("QEG Physica D — Section 6 Script Candidate Tracker")
    project_root = resolve_project_root(argv)
    echo(f"Project root: {project_root}")
    echo(f"Section name in paper: {SECTION_NAME}")
    echo("Scanning scripts / ledgers / notes...")
    echo("")

    if not project_root.exists():
        raise FileNotFoundError(f"Project root does not exist: {project_root}")

    paths = []
    for p in project_root.rglob("*"):
        if p.is_file() and not should_skip(p):
            paths.append(p)

    echo(f"Candidate text/script files scanned: {len(paths)}")

    candidates: List[Candidate] = []
    for p in paths:
        try:
            cand = make_candidate(project_root, p)
        except Exception as exc:
            echo(f"[WARN] failed to scan {p}: {exc}")
            continue
        if cand.rank_score > 0:
            candidates.append(cand)

    candidates.sort(key=lambda c: (c.rank_score, c.role), reverse=True)

    out_dir = write_outputs(project_root, candidates)
    echo("")
    echo("Outputs written:")
    echo(f"  {out_dir / 'section6_script_candidate_audit.csv'}")
    echo(f"  {out_dir / 'section6_script_candidate_audit.json'}")
    echo(f"  {out_dir / 'section6_script_candidate_audit_notes.txt'}")
    echo(f"  {out_dir / 'section6_top_candidate_snippets.txt'}")
    echo("")
    echo("Top candidates:")
    for i, c in enumerate(candidates[:10], start=1):
        echo(f"  {i:02d}. score={c.rank_score:5d} role={c.role} :: {c.relative_path}")
    echo("")
    echo("Recommended minimal set for Section 6 math:")
    echo("  1) Stage-6P_two_lobe_universality_test_on_v5_candidate_v6.py")
    echo("  2) Stage-6Q_canonical_law_extraction_v1.py")
    echo("  3) Stage-6N_canonical_two_lobe_law_v1a.py  [support only]")
    echo("")
    echo("Done.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
