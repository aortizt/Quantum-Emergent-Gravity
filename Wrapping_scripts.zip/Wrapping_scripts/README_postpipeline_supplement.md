## Canonical pipeline and post-pipeline manuscript-support layer

The repository distinguishes the **canonical QEG computational pipeline**
from a later **post-pipeline manuscript-support and external-validation
layer**.

The canonical pipeline comprises the lineage-preserving mathematical and
computational sequence culminating in the frozen run sequence and result
spine recorded by `Stage-7E-v2_canonical_run_sequence_builder.py` and
`Stage-7E-v3_result_spine_audit.py`. Those records identify the calculations
that generate the principal scientific results.

After that freeze, a smaller curated set of scripts was used to construct and
audit the Physica D manuscript. These later scripts did not redefine the
canonical pipeline. Their functions were to:

1. extract a manuscript-facing method and result map;
2. recover and verify section-level numerical invariants;
3. reconstruct provenance for cosmology-proximity bookkeeping;
4. audit guarded physical analogies and the Friedmann appendix;
5. perform an external temporal holdout against later NuFIT data; and
6. harden that holdout with bootstrap envelopes, corrected Monte Carlo
   comparisons, ordering arrows, PCA-loading attribution, coordinate-semantic
   and phase nulls, and a predeclared combined stability statistic.

For GitHub, the supplemental directory contains the curated scripts and their
manifest. The complete generated tables, figures, JSON summaries, and run
reports are deposited with the corresponding Zenodo release.

The distinction is therefore:

```text
canonical pipeline
    = generation and freezing of the scientific result spine

post-pipeline manuscript-support layer
    = manuscript extraction, provenance verification, guarded appendix
      tracing, and external temporal validation
```

This separation prevents later manuscript-facing audits from being mistaken
for additional fitted stages of the emergence pipeline.
