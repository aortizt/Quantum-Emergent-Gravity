#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
QEG external-atlas stability v2 — final temporal holdout audit
==============================================================

Purpose
-------
Convert the NuFIT 6.0 temporal holdout into a compact, proposition-ready
external stability test without inserting the holdout into the proof of the
QEG theorem/conjecture.

This script supersedes the first source-atlas holdout script.  It preserves the
frozen-development logic while adding:

1. uncertainty-symmetric parametric bootstrap envelopes;
2. a corrected Monte Carlo comparison in which temporal and cross-family
   displacements are sampled on the same footing;
3. NO-to-IO arrows in all frozen PCA projections;
4. PCA loading attribution and dominance diagnostics;
5. exact semantic-coordinate permutation nulls;
6. phase-randomization nulls;
7. a predeclared combined source-stability statistic;
8. proposition-ready CSV, JSON, TXT, and LaTeX outputs;
9. deterministic single-threaded execution and restartable bootstrap files.

Scientific claim ceiling
------------------------
The output tests EXTERNAL SOURCE-ATLAS STABILITY only.

It does not:
- enter the proof of the QEG theorem/conjecture;
- establish external validation of the downstream two-sector operator law;
- identify any source coordinate as a physical cosmological parameter;
- turn NuFIT 6.0 into a fourth independent global-fit family.

NuFIT 6.0 is treated as a temporal, development-external update.

Primary and sensitivity atlases
-------------------------------
Primary:
    zscore__signeddm
    zscore__absdm

Sensitivity:
    robust__signeddm
    robust__absdm

The robust atlases are retained as sensitivity diagnostics.  Their very small
training IQR in sin^2(theta_23) can make PC1 nearly one-coordinate dominated.

Combined source-stability statistic
-----------------------------------
For each holdout variant, four predeclared components are placed in [0,1]:

E = uncertainty-symmetric envelope retention probability
O = ordering stability, defined as the geometric mean of
    (i) the central primary-atlas ordering cosine and
    (ii) the uncertainty-bootstrap probability that the ordering cosine
         remains positive.
N = fraction of primary semantic/phase null tests with p <= 0.05
T = probability that the temporal update is no larger than the symmetric
    historical cross-family displacement reference

The combined statistic is the equal-weight geometric mean

    S = (E O N T)^(1/4).

This is an audit-summary statistic, not a physical invariant.

Predeclared interpretation:
    STRONG_EXTERNAL_SOURCE_STABILITY
        S >= 0.80, E >= 0.90, O >= 0.90, N >= 0.75, T >= 0.67

    SUPPORTED_EXTERNAL_SOURCE_STABILITY
        S >= 0.65, E >= 0.80, O >= 0.80, N >= 0.50, T >= 0.50

    COMPATIBLE_EXTERNAL_STRESS_TEST
        E >= 0.80 and O >= 0.80

    EXTERNAL_STRESS_OR_FAILURE
        otherwise

Input policy
------------
Preferred input files are the exact source-panel CSVs written by v1:

    training_PDG2024_source_panel.csv
    holdout_NuFIT6_source_panel.csv

The script searches:
1. paths supplied by QEG_TRAINING_CSV and QEG_HOLDOUT_CSV;
2. the previous v1 output directory;
3. the project root;
4. the script directory.

If they cannot be found, the exact v1 values are reconstructed from the
built-in fallback table and this is recorded in the source manifest.

Run in Spyder
-------------
Open this file and press Run.

Environment-variable overrides are optional:

    QEG_ROOT=/home/dakini/Downloads/010-Quantum_Emergent_Gravity
    QEG_BOOTSTRAP_REPS=5000
    QEG_PHASE_NULL_REPS=10000
    QEG_FAST_TEST=1

QEG_FAST_TEST=1 uses small iteration counts only for a syntax/runtime check.
Do not use fast-test outputs in the manuscript.

Default output directory
------------------------
<ROOT>/metric_stage_7E_outputs/external_atlas_stability_v2_final/

The script is single-threaded.
"""

from __future__ import annotations

import ast
import hashlib
import itertools
import json
import math
import os
import platform
import sys
import traceback
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


# =============================================================================
# USER SETTINGS
# =============================================================================

ROOT = Path(
    os.environ.get(
        "QEG_ROOT",
        "/home/dakini/Downloads/010-Quantum_Emergent_Gravity",
    )
).expanduser()

OUTPUT_DIR = Path(
    os.environ.get(
        "QEG_EXTERNAL_ATLAS_V2_OUTPUT",
        str(
            ROOT
            / "metric_stage_7E_outputs"
            / "external_atlas_stability_v2_final"
        ),
    )
).expanduser()

SCRIPT_DIR = Path(__file__).resolve().parent if "__file__" in globals() else Path.cwd()

FAST_TEST = os.environ.get("QEG_FAST_TEST", "0").strip() == "1"
N_BOOTSTRAP = int(
    os.environ.get("QEG_BOOTSTRAP_REPS", "120" if FAST_TEST else "5000")
)
N_PHASE_NULL = int(
    os.environ.get("QEG_PHASE_NULL_REPS", "300" if FAST_TEST else "10000")
)
CHECKPOINT_EVERY = int(
    os.environ.get("QEG_CHECKPOINT_EVERY", "50" if FAST_TEST else "250")
)

RANDOM_SEED = 20260622
SCRIPT_VERSION = "external_atlas_stability_v2_final_2026-06-22"

PRIMARY_ATLASES = ("zscore__signeddm", "zscore__absdm")
SENSITIVITY_ATLASES = ("robust__signeddm", "robust__absdm")
ALL_ATLASES = PRIMARY_ATLASES + SENSITIVITY_ATLASES

NN_ENVELOPE_FACTOR = 1.25
ORDERING_COSINE_MIN = 0.80
NULL_ALPHA = 0.05

# Ridge-Mahalanobis is reported only as a review diagnostic.
RIDGE_SHRINKAGE = 0.20
MAHALANOBIS_ENVELOPE_FACTOR = 1.25

# Combined-score thresholds.
STRONG_SCORE_MIN = 0.80
SUPPORTED_SCORE_MIN = 0.65
COMPATIBLE_COMPONENT_MIN = 0.80

SAVE_FULL_PHASE_NULL_DRAWS = True
SAVE_FULL_BOOTSTRAP_DRAWS = True

EPS = 1.0e-12

FEATURE_NAMES = (
    "sin2_theta12",
    "sin2_theta23",
    "sin2_theta13",
    "cos_delta_cp",
    "sin_delta_cp",
    "dm21_mev2",
    "dm32_mev2",
)

FEATURE_LABELS = {
    "sin2_theta12": r"$\sin^2\theta_{12}$",
    "sin2_theta23": r"$\sin^2\theta_{23}$",
    "sin2_theta13": r"$\sin^2\theta_{13}$",
    "cos_delta_cp": r"$\cos\delta_{\rm CP}$",
    "sin_delta_cp": r"$\sin\delta_{\rm CP}$",
    "dm21_mev2": r"$\Delta m^2_{21}$",
    "dm32_mev2": r"$\Delta m^2_{32}$",
}


# =============================================================================
# DATA STRUCTURES
# =============================================================================

@dataclass(frozen=True)
class OscillationRecord:
    label: str
    family: str
    variant: str
    ordering: str
    sin2_theta12: float
    sin2_theta23: float
    sin2_theta13: float
    delta_cp_deg: float
    dm21_mev2: float
    dm32_mev2: float
    err_minus: Tuple[float, float, float, float, float, float]
    err_plus: Tuple[float, float, float, float, float, float]
    source: str


@dataclass(frozen=True)
class AtlasSpec:
    name: str
    scaler_mode: str
    absolute_atmospheric: bool
    role: str


ATLAS_SPECS: Tuple[AtlasSpec, ...] = (
    AtlasSpec("zscore__signeddm", "zscore", False, "primary"),
    AtlasSpec("zscore__absdm", "zscore", True, "primary"),
    AtlasSpec("robust__signeddm", "robust", False, "sensitivity"),
    AtlasSpec("robust__absdm", "robust", True, "sensitivity"),
)


# =============================================================================
# LOGGING AND FILE UTILITIES
# =============================================================================

def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def log(message: str) -> None:
    print(message, flush=True)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_json(path: Path, obj: Mapping) -> None:
    path.write_text(json.dumps(obj, indent=2, sort_keys=True), encoding="utf-8")


def atomic_write_csv(df: pd.DataFrame, path: Path) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    df.to_csv(tmp, index=False)
    tmp.replace(path)


def append_csv(df: pd.DataFrame, path: Path) -> None:
    if df.empty:
        return
    header = not path.exists()
    df.to_csv(path, mode="a", header=header, index=False)


def seed_for(*parts: object) -> int:
    payload = "::".join(str(x) for x in parts).encode("utf-8")
    digest = hashlib.sha256(payload).digest()
    return (RANDOM_SEED + int.from_bytes(digest[:4], "little")) % (2**32 - 1)


# =============================================================================
# INPUT LOADING
# =============================================================================

def parse_tuple6(value: object) -> Tuple[float, float, float, float, float, float]:
    if isinstance(value, (tuple, list, np.ndarray)):
        seq = value
    elif pd.isna(value):
        raise ValueError("Missing uncertainty tuple.")
    else:
        seq = ast.literal_eval(str(value))
    if len(seq) != 6:
        raise ValueError(f"Expected six uncertainty values, got {seq!r}")
    return tuple(float(x) for x in seq)


def dataframe_to_records(df: pd.DataFrame) -> Tuple[OscillationRecord, ...]:
    required = {
        "label",
        "family",
        "variant",
        "ordering",
        "sin2_theta12",
        "sin2_theta23",
        "sin2_theta13",
        "delta_cp_deg",
        "dm21_mev2",
        "dm32_mev2",
        "err_minus",
        "err_plus",
        "source",
    }
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Source panel missing columns: {sorted(missing)}")

    records: List[OscillationRecord] = []
    for _, row in df.iterrows():
        ordering = str(row["ordering"]).strip().upper()
        if ordering not in {"NO", "IO"}:
            raise ValueError(f"Unexpected ordering {ordering!r}")
        records.append(
            OscillationRecord(
                label=str(row["label"]),
                family=str(row["family"]),
                variant=str(row["variant"]),
                ordering=ordering,
                sin2_theta12=float(row["sin2_theta12"]),
                sin2_theta23=float(row["sin2_theta23"]),
                sin2_theta13=float(row["sin2_theta13"]),
                delta_cp_deg=float(row["delta_cp_deg"]),
                dm21_mev2=float(row["dm21_mev2"]),
                dm32_mev2=float(row["dm32_mev2"]),
                err_minus=parse_tuple6(row["err_minus"]),
                err_plus=parse_tuple6(row["err_plus"]),
                source=str(row["source"]),
            )
        )
    return tuple(records)


def records_to_dataframe(records: Sequence[OscillationRecord]) -> pd.DataFrame:
    rows = []
    for record in records:
        row = asdict(record)
        row["err_minus"] = repr(record.err_minus)
        row["err_plus"] = repr(record.err_plus)
        rows.append(row)
    return pd.DataFrame(rows)


def fallback_records() -> Tuple[
    Tuple[OscillationRecord, ...],
    Tuple[OscillationRecord, ...],
]:
    def rec(
        label: str,
        family: str,
        variant: str,
        ordering: str,
        values: Sequence[float],
        minus: Sequence[float],
        plus: Sequence[float],
        source: str,
    ) -> OscillationRecord:
        return OscillationRecord(
            label=label,
            family=family,
            variant=variant,
            ordering=ordering,
            sin2_theta12=float(values[0]),
            sin2_theta23=float(values[1]),
            sin2_theta13=float(values[2]),
            delta_cp_deg=float(values[3]),
            dm21_mev2=float(values[4]),
            dm32_mev2=float(values[5]),
            err_minus=tuple(float(x) for x in minus),
            err_plus=tuple(float(x) for x in plus),
            source=source,
        )

    training = (
        rec(
            "NUFIT5p2_NO", "NUFIT", "PDG2024_without_SK_atm", "NO",
            [0.303, 0.572, 0.02203, 197.0, 74.1, 2437.0],
            [0.011, 0.023, 0.00059, 25.0, 2.0, 27.0],
            [0.012, 0.018, 0.00056, 42.0, 2.1, 28.0],
            "PDG2024_Table14.7",
        ),
        rec(
            "NUFIT5p2_IO", "NUFIT", "PDG2024_without_SK_atm", "IO",
            [0.303, 0.578, 0.02219, 286.0, 74.1, -2498.0],
            [0.011, 0.021, 0.00057, 32.0, 2.0, 25.0],
            [0.012, 0.016, 0.00060, 27.0, 2.1, 32.0],
            "PDG2024_Table14.7",
        ),
        rec(
            "BARI_NO", "BARI", "PDG2024", "NO",
            [0.303, 0.455, 0.02230, 223.0, 73.6, 2448.0],
            [0.013, 0.015, 0.00060, 23.0, 1.5, 31.0],
            [0.013, 0.018, 0.00070, 32.0, 1.6, 23.0],
            "PDG2024_Table14.7",
        ),
        rec(
            "BARI_IO", "BARI", "PDG2024", "IO",
            [0.303, 0.569, 0.02230, 274.0, 73.6, -2492.0],
            [0.013, 0.021, 0.00060, 27.0, 1.5, 30.0],
            [0.013, 0.013, 0.00060, 25.0, 1.6, 25.0],
            "PDG2024_Table14.7",
        ),
        rec(
            "VALENCIA_NO", "VALENCIA", "PDG2024", "NO",
            [0.318, 0.574, 0.02200, 194.0, 75.0, 2470.0],
            [0.016, 0.014, 0.00062, 22.0, 2.0, 30.0],
            [0.016, 0.014, 0.00069, 24.0, 2.2, 20.0],
            "PDG2024_Table14.7",
        ),
        rec(
            "VALENCIA_IO", "VALENCIA", "PDG2024", "IO",
            [0.318, 0.578, 0.02225, 284.0, 75.0, -2520.0],
            [0.016, 0.017, 0.00070, 28.0, 2.0, 20.0],
            [0.016, 0.010, 0.00064, 26.0, 2.2, 30.0],
            "PDG2024_Table14.7",
        ),
    )

    holdout = (
        rec(
            "NUFIT6_IC19_NO", "NUFIT6", "IC19_without_SK_atm", "NO",
            [0.307, 0.561, 0.02195, 177.0, 74.9, 2534.0 - 74.9],
            [0.011, 0.015, 0.00058, 20.0, 1.9, math.hypot(23.0, 1.9)],
            [0.012, 0.012, 0.00054, 19.0, 1.9, math.hypot(25.0, 1.9)],
            "NuFIT6_Table1_IC19",
        ),
        rec(
            "NUFIT6_IC19_IO", "NUFIT6", "IC19_without_SK_atm", "IO",
            [0.308, 0.562, 0.02224, 285.0, 74.9, -2510.0],
            [0.011, 0.015, 0.00057, 28.0, 1.9, 25.0],
            [0.012, 0.012, 0.00056, 25.0, 1.9, 24.0],
            "NuFIT6_Table1_IC19",
        ),
        rec(
            "NUFIT6_IC24SK_NO", "NUFIT6", "IC24_with_SK_atm", "NO",
            [0.308, 0.470, 0.02215, 212.0, 74.9, 2513.0 - 74.9],
            [0.011, 0.013, 0.00058, 41.0, 1.9, math.hypot(19.0, 1.9)],
            [0.012, 0.017, 0.00056, 26.0, 1.9, math.hypot(21.0, 1.9)],
            "NuFIT6_Table1_IC24_SK",
        ),
        rec(
            "NUFIT6_IC24SK_IO", "NUFIT6", "IC24_with_SK_atm", "IO",
            [0.308, 0.550, 0.02231, 274.0, 74.9, -2484.0],
            [0.011, 0.015, 0.00056, 25.0, 1.9, 20.0],
            [0.012, 0.012, 0.00056, 22.0, 1.9, 20.0],
            "NuFIT6_Table1_IC24_SK",
        ),
    )
    return training, holdout


def candidate_source_paths(filename: str, env_name: str) -> List[Path]:
    candidates: List[Path] = []
    override = os.environ.get(env_name)
    if override:
        candidates.append(Path(override).expanduser())

    candidates.extend(
        [
            ROOT / "external_holdout_nufit6_outputs" / filename,
            ROOT / "metric_stage_7E_outputs" / "external_holdout_nufit6_outputs" / filename,
            ROOT / filename,
            SCRIPT_DIR / filename,
            Path.cwd() / filename,
        ]
    )
    # Preserve order, remove duplicates.
    unique: List[Path] = []
    seen = set()
    for path in candidates:
        key = str(path.resolve()) if path.exists() else str(path)
        if key not in seen:
            unique.append(path)
            seen.add(key)
    return unique


def first_existing(paths: Iterable[Path]) -> Optional[Path]:
    for path in paths:
        if path.exists() and path.is_file():
            return path
    return None


def load_source_panels() -> Tuple[
    Tuple[OscillationRecord, ...],
    Tuple[OscillationRecord, ...],
    Dict[str, object],
]:
    training_path = first_existing(
        candidate_source_paths(
            "training_PDG2024_source_panel.csv",
            "QEG_TRAINING_CSV",
        )
    )
    holdout_path = first_existing(
        candidate_source_paths(
            "holdout_NuFIT6_source_panel.csv",
            "QEG_HOLDOUT_CSV",
        )
    )

    manifest: Dict[str, object] = {
        "script_version": SCRIPT_VERSION,
        "loaded_at_utc": utc_now(),
        "training_candidates": [
            str(p)
            for p in candidate_source_paths(
                "training_PDG2024_source_panel.csv",
                "QEG_TRAINING_CSV",
            )
        ],
        "holdout_candidates": [
            str(p)
            for p in candidate_source_paths(
                "holdout_NuFIT6_source_panel.csv",
                "QEG_HOLDOUT_CSV",
            )
        ],
    }

    if training_path is not None and holdout_path is not None:
        training_df = pd.read_csv(training_path)
        holdout_df = pd.read_csv(holdout_path)
        training = dataframe_to_records(training_df)
        holdout = dataframe_to_records(holdout_df)
        manifest.update(
            {
                "source_mode": "loaded_v1_source_panel_csv",
                "training_path": str(training_path.resolve()),
                "holdout_path": str(holdout_path.resolve()),
                "training_sha256": sha256_file(training_path),
                "holdout_sha256": sha256_file(holdout_path),
            }
        )
    else:
        training, holdout = fallback_records()
        manifest.update(
            {
                "source_mode": "built_in_exact_v1_fallback",
                "training_path": None,
                "holdout_path": None,
                "training_sha256": None,
                "holdout_sha256": None,
            }
        )

    validate_source_panels(training, holdout)
    manifest["training_labels"] = [r.label for r in training]
    manifest["holdout_labels"] = [r.label for r in holdout]
    return training, holdout, manifest


def validate_source_panels(
    training: Sequence[OscillationRecord],
    holdout: Sequence[OscillationRecord],
) -> None:
    if len(training) != 6:
        raise ValueError(f"Expected six training rows; got {len(training)}.")
    if len(holdout) != 4:
        raise ValueError(f"Expected four holdout rows; got {len(holdout)}.")

    training_families = {r.family for r in training}
    if training_families != {"BARI", "NUFIT", "VALENCIA"}:
        raise ValueError(
            f"Unexpected training families: {sorted(training_families)}"
        )

    for records, name in ((training, "training"), (holdout, "holdout")):
        labels = [r.label for r in records]
        if len(labels) != len(set(labels)):
            raise ValueError(f"Duplicate {name} labels.")
        for record in records:
            if record.ordering not in {"NO", "IO"}:
                raise ValueError(
                    f"Invalid ordering {record.ordering} for {record.label}"
                )


# =============================================================================
# GEOMETRY UTILITIES
# =============================================================================

def record_vector(
    record: OscillationRecord,
    absolute_atmospheric: bool,
) -> np.ndarray:
    phase = np.deg2rad(record.delta_cp_deg % 360.0)
    dm32 = (
        abs(record.dm32_mev2)
        if absolute_atmospheric
        else record.dm32_mev2
    )
    return np.asarray(
        [
            record.sin2_theta12,
            record.sin2_theta23,
            record.sin2_theta13,
            np.cos(phase),
            np.sin(phase),
            record.dm21_mev2,
            dm32,
        ],
        dtype=float,
    )


def records_matrix(
    records: Sequence[OscillationRecord],
    absolute_atmospheric: bool,
) -> np.ndarray:
    return np.vstack(
        [record_vector(r, absolute_atmospheric) for r in records]
    )


def fit_scaler(x: np.ndarray, mode: str) -> Tuple[np.ndarray, np.ndarray]:
    if mode == "zscore":
        center = np.mean(x, axis=0)
        scale = np.std(x, axis=0, ddof=1)
    elif mode == "robust":
        center = np.median(x, axis=0)
        q75, q25 = np.percentile(x, [75, 25], axis=0)
        scale = (q75 - q25) / 1.349
    else:
        raise ValueError(f"Unknown scaler mode: {mode}")

    scale = np.where(np.abs(scale) < EPS, 1.0, scale)
    return center, scale


def standardize(
    x: np.ndarray,
    center: np.ndarray,
    scale: np.ndarray,
) -> np.ndarray:
    return (x - center) / scale


def pairwise_distances(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    diff = a[:, None, :] - b[None, :, :]
    return np.sqrt(np.sum(diff * diff, axis=2))


def nearest_neighbor_distances(z: np.ndarray) -> np.ndarray:
    distances = pairwise_distances(z, z)
    np.fill_diagonal(distances, np.inf)
    return np.min(distances, axis=1)


def ridge_mahalanobis_scores(
    z_train: np.ndarray,
    z_query: np.ndarray,
    ridge: float = RIDGE_SHRINKAGE,
) -> Tuple[np.ndarray, np.ndarray]:
    mean = np.mean(z_train, axis=0)
    covariance = np.cov(z_train, rowvar=False, ddof=1)
    trace = float(np.trace(covariance))
    target = (trace / covariance.shape[0]) * np.eye(covariance.shape[0])
    shrunk = (
        (1.0 - ridge) * covariance
        + ridge * target
        + EPS * np.eye(covariance.shape[0])
    )
    inverse = np.linalg.pinv(shrunk)

    def score(rows: np.ndarray) -> np.ndarray:
        displacement = rows - mean
        return np.sqrt(
            np.einsum(
                "ij,jk,ik->i",
                displacement,
                inverse,
                displacement,
            )
        )

    return score(z_train), score(z_query)


def pca_fit(
    z_train: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    mean = np.mean(z_train, axis=0)
    centered = z_train - mean
    _, singular_values, vt = np.linalg.svd(
        centered,
        full_matrices=False,
    )
    explained = singular_values**2
    explained = explained / max(float(np.sum(explained)), EPS)
    return mean, vt, explained


def pca_transform(
    z: np.ndarray,
    mean: np.ndarray,
    components: np.ndarray,
    n_components: int = 2,
) -> np.ndarray:
    return (z - mean) @ components[:n_components].T


def cosine_similarity(a: np.ndarray, b: np.ndarray) -> float:
    denominator = np.linalg.norm(a) * np.linalg.norm(b)
    if denominator < EPS:
        return float("nan")
    return float(np.dot(a, b) / denominator)


def record_pairs(
    records: Sequence[OscillationRecord],
) -> Dict[str, Dict[str, OscillationRecord]]:
    result: Dict[str, Dict[str, OscillationRecord]] = {}
    for record in records:
        key = f"{record.family}::{record.variant}"
        result.setdefault(key, {})[record.ordering] = record
    return {
        key: pair
        for key, pair in result.items()
        if {"NO", "IO"} <= set(pair)
    }


def array_pairs(
    records: Sequence[OscillationRecord],
    z: np.ndarray,
) -> Dict[str, Dict[str, np.ndarray]]:
    result: Dict[str, Dict[str, np.ndarray]] = {}
    for index, record in enumerate(records):
        key = f"{record.family}::{record.variant}"
        result.setdefault(key, {})[record.ordering] = z[index]
    return {
        key: pair
        for key, pair in result.items()
        if {"NO", "IO"} <= set(pair)
    }


# =============================================================================
# UNCERTAINTY SAMPLING
# =============================================================================

def asymmetric_draw(
    rng: np.random.Generator,
    center: float,
    err_minus: float,
    err_plus: float,
) -> float:
    z = float(rng.normal())
    sigma = err_minus if z < 0.0 else err_plus
    return center + z * sigma


def sample_record_vector(
    rng: np.random.Generator,
    record: OscillationRecord,
    absolute_atmospheric: bool,
) -> np.ndarray:
    theta12 = asymmetric_draw(
        rng,
        record.sin2_theta12,
        record.err_minus[0],
        record.err_plus[0],
    )
    theta23 = asymmetric_draw(
        rng,
        record.sin2_theta23,
        record.err_minus[1],
        record.err_plus[1],
    )
    theta13 = asymmetric_draw(
        rng,
        record.sin2_theta13,
        record.err_minus[2],
        record.err_plus[2],
    )
    delta_cp = asymmetric_draw(
        rng,
        record.delta_cp_deg,
        record.err_minus[3],
        record.err_plus[3],
    ) % 360.0
    dm21 = asymmetric_draw(
        rng,
        record.dm21_mev2,
        record.err_minus[4],
        record.err_plus[4],
    )
    dm32 = asymmetric_draw(
        rng,
        record.dm32_mev2,
        record.err_minus[5],
        record.err_plus[5],
    )
    if absolute_atmospheric:
        dm32 = abs(dm32)

    phase = np.deg2rad(delta_cp)
    return np.asarray(
        [
            theta12,
            theta23,
            theta13,
            np.cos(phase),
            np.sin(phase),
            dm21,
            dm32,
        ],
        dtype=float,
    )


def sampled_matrix(
    rng: np.random.Generator,
    records: Sequence[OscillationRecord],
    absolute_atmospheric: bool,
) -> np.ndarray:
    return np.vstack(
        [
            sample_record_vector(
                rng,
                record,
                absolute_atmospheric,
            )
            for record in records
        ]
    )


# =============================================================================
# ANALYSIS CONTRACT
# =============================================================================

def analysis_contract() -> Dict[str, object]:
    return {
        "script_version": SCRIPT_VERSION,
        "created_utc": utc_now(),
        "claim_ceiling": "external_source_atlas_stability_only",
        "primary_atlases": list(PRIMARY_ATLASES),
        "sensitivity_atlases": list(SENSITIVITY_ATLASES),
        "thresholds": {
            "nn_envelope_factor": NN_ENVELOPE_FACTOR,
            "ordering_cosine_min": ORDERING_COSINE_MIN,
            "null_alpha": NULL_ALPHA,
            "mahalanobis_envelope_factor_review_only": (
                MAHALANOBIS_ENVELOPE_FACTOR
            ),
        },
        "combined_statistic": {
            "components": {
                "E": (
                    "mean primary-atlas bootstrap probability that each "
                    "holdout row remains below the NN envelope ceiling"
                ),
                "O": (
                    "geometric mean of the mean central primary-atlas "
                    "ordering cosine and the mean uncertainty-bootstrap "
                    "probability that the ordering cosine remains positive; "
                    "the stricter probability cosine>=0.8 is reported "
                    "separately"
                ),
                "N": (
                    "fraction of primary semantic/phase null tests with "
                    "p <= alpha"
                ),
                "T": (
                    "mean primary-atlas bootstrap probability that the "
                    "temporal NuFIT update is no larger than the symmetric "
                    "historical cross-family displacement reference"
                ),
            },
            "formula": "S=(E*O*N*T)^(1/4)",
            "weights": {
                "E": 0.25,
                "O": 0.25,
                "N": 0.25,
                "T": 0.25,
            },
            "interpretation": {
                "STRONG_EXTERNAL_SOURCE_STABILITY": {
                    "S_min": STRONG_SCORE_MIN,
                    "E_min": 0.90,
                    "O_min": 0.90,
                    "N_min": 0.75,
                    "T_min": 0.67,
                },
                "SUPPORTED_EXTERNAL_SOURCE_STABILITY": {
                    "S_min": SUPPORTED_SCORE_MIN,
                    "E_min": 0.80,
                    "O_min": 0.80,
                    "N_min": 0.50,
                    "T_min": 0.50,
                },
                "COMPATIBLE_EXTERNAL_STRESS_TEST": {
                    "E_min": COMPATIBLE_COMPONENT_MIN,
                    "O_min": COMPATIBLE_COMPONENT_MIN,
                },
            },
        },
        "bootstrap": {
            "n_replicates": N_BOOTSTRAP,
            "type": "parametric_asymmetric_uncertainty_symmetric",
            "training_and_holdout_sampled": True,
            "scaler_refit_on_training_only_each_replicate": True,
            "holdout_never_used_to_fit_scaler": True,
        },
        "semantic_null": {
            "type": "exact_coordinate_permutation",
            "permutations_total": math.factorial(len(FEATURE_NAMES)),
            "identity_excluded_from_null": True,
        },
        "phase_null": {
            "type": "uniform_phase_randomization",
            "n_replicates": N_PHASE_NULL,
        },
        "fast_test": FAST_TEST,
    }


# =============================================================================
# CENTRAL-VALUE ATLAS ANALYSIS
# =============================================================================

def central_atlas_analysis(
    training: Sequence[OscillationRecord],
    holdout: Sequence[OscillationRecord],
    spec: AtlasSpec,
) -> Tuple[
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    Dict[str, object],
]:
    x_train = records_matrix(training, spec.absolute_atmospheric)
    x_hold = records_matrix(holdout, spec.absolute_atmospheric)

    center, scale = fit_scaler(x_train, spec.scaler_mode)
    z_train = standardize(x_train, center, scale)
    z_hold = standardize(x_hold, center, scale)

    train_nn = nearest_neighbor_distances(z_train)
    distance_hold = pairwise_distances(z_hold, z_train)
    hold_nn = np.min(distance_hold, axis=1)
    nearest_index = np.argmin(distance_hold, axis=1)

    train_maha, hold_maha = ridge_mahalanobis_scores(z_train, z_hold)

    pca_mean, pca_components, explained = pca_fit(z_train)
    train_scores = pca_transform(z_train, pca_mean, pca_components, 2)
    hold_scores = pca_transform(z_hold, pca_mean, pca_components, 2)

    train_rows: List[Dict[str, object]] = []
    for index, record in enumerate(training):
        train_rows.append(
            {
                "atlas": spec.name,
                "atlas_role": spec.role,
                "label": record.label,
                "family": record.family,
                "variant": record.variant,
                "ordering": record.ordering,
                "nearest_neighbor_distance": float(train_nn[index]),
                "ridge_mahalanobis": float(train_maha[index]),
                "pc1": float(train_scores[index, 0]),
                "pc2": float(train_scores[index, 1]),
            }
        )

    max_train_nn = float(np.max(train_nn))
    max_train_maha = float(np.max(train_maha))

    hold_rows: List[Dict[str, object]] = []
    for index, record in enumerate(holdout):
        nearest = training[int(nearest_index[index])]
        hold_rows.append(
            {
                "atlas": spec.name,
                "atlas_role": spec.role,
                "label": record.label,
                "family": record.family,
                "variant": record.variant,
                "ordering": record.ordering,
                "nearest_training_label": nearest.label,
                "nearest_training_family": nearest.family,
                "nearest_neighbor_distance": float(hold_nn[index]),
                "training_nn_max": max_train_nn,
                "nn_envelope_ratio": float(
                    hold_nn[index] / max(max_train_nn, EPS)
                ),
                "nn_pass": bool(
                    hold_nn[index]
                    <= NN_ENVELOPE_FACTOR * max_train_nn
                ),
                "ridge_mahalanobis": float(hold_maha[index]),
                "training_mahalanobis_max": max_train_maha,
                "mahalanobis_envelope_ratio": float(
                    hold_maha[index] / max(max_train_maha, EPS)
                ),
                "mahalanobis_pass_review_only": bool(
                    hold_maha[index]
                    <= MAHALANOBIS_ENVELOPE_FACTOR * max_train_maha
                ),
                "pc1": float(hold_scores[index, 0]),
                "pc2": float(hold_scores[index, 1]),
            }
        )

    train_pair_map = array_pairs(training, z_train)
    hold_pair_map = array_pairs(holdout, z_hold)
    training_vectors = [
        pair["IO"] - pair["NO"]
        for pair in train_pair_map.values()
    ]
    mean_training_vector = np.mean(training_vectors, axis=0)

    ordering_rows: List[Dict[str, object]] = []
    for source_type, pair_map in (
        ("training", train_pair_map),
        ("holdout", hold_pair_map),
    ):
        for pair_name, pair in pair_map.items():
            displacement = pair["IO"] - pair["NO"]
            ordering_rows.append(
                {
                    "atlas": spec.name,
                    "atlas_role": spec.role,
                    "source_type": source_type,
                    "pair": pair_name,
                    "displacement_norm": float(
                        np.linalg.norm(displacement)
                    ),
                    "cosine_to_training_mean": cosine_similarity(
                        displacement,
                        mean_training_vector,
                    ),
                    "ordering_alignment_pass": bool(
                        cosine_similarity(
                            displacement,
                            mean_training_vector,
                        )
                        >= ORDERING_COSINE_MIN
                    ),
                }
            )

    loading_rows: List[Dict[str, object]] = []
    for pc_index in range(min(2, pca_components.shape[0])):
        squared = pca_components[pc_index] ** 2
        total = max(float(np.sum(squared)), EPS)
        for feature_index, feature in enumerate(FEATURE_NAMES):
            loading_rows.append(
                {
                    "atlas": spec.name,
                    "atlas_role": spec.role,
                    "pc": pc_index + 1,
                    "feature": feature,
                    "loading": float(
                        pca_components[pc_index, feature_index]
                    ),
                    "absolute_loading": float(
                        abs(pca_components[pc_index, feature_index])
                    ),
                    "squared_loading_fraction": float(
                        squared[feature_index] / total
                    ),
                    "explained_variance_ratio": float(
                        explained[pc_index]
                    ),
                }
            )

    metadata = {
        "atlas": spec.name,
        "atlas_role": spec.role,
        "scaler_mode": spec.scaler_mode,
        "absolute_atmospheric": spec.absolute_atmospheric,
        "center": center.tolist(),
        "scale": scale.tolist(),
        "training_nn_max": max_train_nn,
        "training_mahalanobis_max": max_train_maha,
        "pca_explained_variance_ratio": explained.tolist(),
    }

    return (
        pd.DataFrame(train_rows),
        pd.DataFrame(hold_rows),
        pd.DataFrame(ordering_rows),
        pd.DataFrame(loading_rows),
        metadata,
    )


# =============================================================================
# RESTARTABLE UNCERTAINTY-SYMMETRIC BOOTSTRAP
# =============================================================================

def bootstrap_paths(atlas: str) -> Tuple[Path, Path]:
    record_path = OUTPUT_DIR / f"bootstrap_record_draws_{atlas}.csv"
    ordering_path = OUTPUT_DIR / f"bootstrap_ordering_draws_{atlas}.csv"
    return record_path, ordering_path


def completed_bootstrap_replicates(
    record_path: Path,
    ordering_path: Path,
) -> int:
    if not record_path.exists() or not ordering_path.exists():
        return 0
    try:
        record_df = pd.read_csv(record_path, usecols=["replicate"])
        ordering_df = pd.read_csv(ordering_path, usecols=["replicate"])
    except Exception:
        return 0
    if record_df.empty or ordering_df.empty:
        return 0
    return int(
        min(
            record_df["replicate"].max(),
            ordering_df["replicate"].max(),
        )
        + 1
    )


def bootstrap_atlas(
    training: Sequence[OscillationRecord],
    holdout: Sequence[OscillationRecord],
    spec: AtlasSpec,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    record_path, ordering_path = bootstrap_paths(spec.name)

    completed = completed_bootstrap_replicates(
        record_path,
        ordering_path,
    )
    if completed >= N_BOOTSTRAP:
        log(
            f"[bootstrap] {spec.name}: loading {completed} completed "
            "replicates."
        )
        record_df = pd.read_csv(record_path)
        ordering_df = pd.read_csv(ordering_path)
        return (
            record_df[record_df["replicate"] < N_BOOTSTRAP].copy(),
            ordering_df[
                ordering_df["replicate"] < N_BOOTSTRAP
            ].copy(),
        )

    if completed > 0:
        log(
            f"[bootstrap] {spec.name}: resuming at replicate {completed}."
        )
    else:
        for path in (record_path, ordering_path):
            if path.exists():
                path.unlink()
        log(
            f"[bootstrap] {spec.name}: starting {N_BOOTSTRAP} replicates."
        )

    old_nufit_by_ordering = {
        record.ordering: record
        for record in training
        if record.family == "NUFIT"
    }
    cross_family_by_ordering = {
        ordering: [
            record
            for record in training
            if record.ordering == ordering
            and record.family in {"BARI", "VALENCIA"}
        ]
        for ordering in ("NO", "IO")
    }

    training_index = {
        record.label: index
        for index, record in enumerate(training)
    }

    record_chunk: List[Dict[str, object]] = []
    ordering_chunk: List[Dict[str, object]] = []

    for replicate in range(completed, N_BOOTSTRAP):
        rng = np.random.default_rng(
            seed_for("bootstrap", spec.name, replicate)
        )

        x_train = sampled_matrix(
            rng,
            training,
            spec.absolute_atmospheric,
        )
        x_hold = sampled_matrix(
            rng,
            holdout,
            spec.absolute_atmospheric,
        )

        center, scale = fit_scaler(x_train, spec.scaler_mode)
        z_train = standardize(x_train, center, scale)
        z_hold = standardize(x_hold, center, scale)

        train_nn = nearest_neighbor_distances(z_train)
        train_envelope = float(np.max(train_nn))
        hold_nn = np.min(
            pairwise_distances(z_hold, z_train),
            axis=1,
        )

        train_pair_map = array_pairs(training, z_train)
        hold_pair_map = array_pairs(holdout, z_hold)
        mean_training_vector = np.mean(
            [
                pair["IO"] - pair["NO"]
                for pair in train_pair_map.values()
            ],
            axis=0,
        )

        for pair_name, pair in hold_pair_map.items():
            displacement = pair["IO"] - pair["NO"]
            similarity = cosine_similarity(
                displacement,
                mean_training_vector,
            )
            variant = pair_name.split("::", 1)[1]
            ordering_chunk.append(
                {
                    "replicate": replicate,
                    "atlas": spec.name,
                    "atlas_role": spec.role,
                    "variant": variant,
                    "ordering_cosine": similarity,
                    "ordering_pass": bool(
                        similarity >= ORDERING_COSINE_MIN
                    ),
                }
            )

        for hold_index, hold_record in enumerate(holdout):
            ratio = float(
                hold_nn[hold_index]
                / max(train_envelope, EPS)
            )

            old_record = old_nufit_by_ordering[
                hold_record.ordering
            ]
            old_index = training_index[old_record.label]
            old_vector = z_train[old_index]

            temporal_distance = float(
                np.linalg.norm(z_hold[hold_index] - old_vector)
            )

            cross_distances: List[float] = []
            for cross_record in cross_family_by_ordering[
                hold_record.ordering
            ]:
                cross_index = training_index[cross_record.label]
                cross_distances.append(
                    float(
                        np.linalg.norm(
                            z_train[cross_index] - old_vector
                        )
                    )
                )

            cross_reference = float(np.median(cross_distances))
            temporal_ratio = float(
                temporal_distance / max(cross_reference, EPS)
            )

            record_chunk.append(
                {
                    "replicate": replicate,
                    "atlas": spec.name,
                    "atlas_role": spec.role,
                    "label": hold_record.label,
                    "variant": hold_record.variant,
                    "ordering": hold_record.ordering,
                    "training_nn_max": train_envelope,
                    "holdout_nn_distance": float(
                        hold_nn[hold_index]
                    ),
                    "nn_envelope_ratio": ratio,
                    "nn_pass": bool(
                        ratio <= NN_ENVELOPE_FACTOR
                    ),
                    "temporal_distance_to_historical_nufit": (
                        temporal_distance
                    ),
                    "symmetric_cross_family_reference": (
                        cross_reference
                    ),
                    "temporal_to_cross_family_ratio": (
                        temporal_ratio
                    ),
                    "temporal_no_larger_than_cross_family": bool(
                        temporal_ratio <= 1.0
                    ),
                }
            )

        if (
            (replicate + 1) % CHECKPOINT_EVERY == 0
            or replicate + 1 == N_BOOTSTRAP
        ):
            append_csv(pd.DataFrame(record_chunk), record_path)
            append_csv(
                pd.DataFrame(ordering_chunk),
                ordering_path,
            )
            record_chunk.clear()
            ordering_chunk.clear()
            log(
                f"[bootstrap] {spec.name}: "
                f"{replicate + 1}/{N_BOOTSTRAP}"
            )

    return pd.read_csv(record_path), pd.read_csv(ordering_path)


def summarize_bootstrap_records(
    record_draws: pd.DataFrame,
) -> pd.DataFrame:
    rows: List[Dict[str, object]] = []
    grouping = [
        "atlas",
        "atlas_role",
        "label",
        "variant",
        "ordering",
    ]
    for keys, group in record_draws.groupby(grouping):
        atlas, role, label, variant, ordering = keys
        ratio = group["nn_envelope_ratio"].to_numpy(float)
        temporal_ratio = group[
            "temporal_to_cross_family_ratio"
        ].to_numpy(float)
        rows.append(
            {
                "atlas": atlas,
                "atlas_role": role,
                "label": label,
                "variant": variant,
                "ordering": ordering,
                "bootstrap_n": int(len(group)),
                "nn_ratio_q05": float(
                    np.quantile(ratio, 0.05)
                ),
                "nn_ratio_median": float(
                    np.median(ratio)
                ),
                "nn_ratio_q95": float(
                    np.quantile(ratio, 0.95)
                ),
                "nn_pass_probability": float(
                    np.mean(ratio <= NN_ENVELOPE_FACTOR)
                ),
                "nn_inside_training_max_probability": float(
                    np.mean(ratio <= 1.0)
                ),
                "temporal_ratio_q05": float(
                    np.quantile(temporal_ratio, 0.05)
                ),
                "temporal_ratio_median": float(
                    np.median(temporal_ratio)
                ),
                "temporal_ratio_q95": float(
                    np.quantile(temporal_ratio, 0.95)
                ),
                "temporal_no_larger_than_cross_family_probability": float(
                    np.mean(temporal_ratio <= 1.0)
                ),
            }
        )
    return pd.DataFrame(rows)


def summarize_bootstrap_ordering(
    ordering_draws: pd.DataFrame,
) -> pd.DataFrame:
    rows: List[Dict[str, object]] = []
    grouping = ["atlas", "atlas_role", "variant"]
    for keys, group in ordering_draws.groupby(grouping):
        atlas, role, variant = keys
        cosine = group["ordering_cosine"].to_numpy(float)
        rows.append(
            {
                "atlas": atlas,
                "atlas_role": role,
                "variant": variant,
                "bootstrap_n": int(len(group)),
                "ordering_cosine_q05": float(
                    np.quantile(cosine, 0.05)
                ),
                "ordering_cosine_median": float(
                    np.median(cosine)
                ),
                "ordering_cosine_q95": float(
                    np.quantile(cosine, 0.95)
                ),
                "ordering_positive_probability": float(
                    np.mean(cosine > 0.0)
                ),
                "ordering_moderate_probability": float(
                    np.mean(cosine >= 0.50)
                ),
                "ordering_strict_probability": float(
                    np.mean(cosine >= ORDERING_COSINE_MIN)
                ),
            }
        )
    return pd.DataFrame(rows)


# =============================================================================
# EXACT SEMANTIC AND PHASE NULLS
# =============================================================================

def null_paths(atlas: str) -> Tuple[Path, Path]:
    summary_path = OUTPUT_DIR / f"null_summary_{atlas}.csv"
    draws_path = OUTPUT_DIR / f"phase_null_draws_{atlas}.csv"
    return summary_path, draws_path


def exact_semantic_permutation_null(
    z_variant: np.ndarray,
    z_train: np.ndarray,
) -> Tuple[float, np.ndarray, float]:
    real = float(
        np.mean(
            np.min(
                pairwise_distances(z_variant, z_train),
                axis=1,
            )
        )
    )
    identity = tuple(range(z_variant.shape[1]))
    values: List[float] = []
    for permutation in itertools.permutations(
        range(z_variant.shape[1])
    ):
        if permutation == identity:
            continue
        shuffled = z_variant[:, permutation]
        values.append(
            float(
                np.mean(
                    np.min(
                        pairwise_distances(
                            shuffled,
                            z_train,
                        ),
                        axis=1,
                    )
                )
            )
        )
    null = np.asarray(values, dtype=float)
    # Exact lower-tail p against all non-identity coordinate permutations.
    p_value = float(
        (1.0 + np.sum(null <= real))
        / (len(null) + 1.0)
    )
    return real, null, p_value


def phase_randomization_null(
    hold_records: Sequence[OscillationRecord],
    z_train: np.ndarray,
    center: np.ndarray,
    scale: np.ndarray,
    absolute_atmospheric: bool,
    seed: int,
) -> Tuple[np.ndarray, float]:
    rng = np.random.default_rng(seed)
    central = records_matrix(
        hold_records,
        absolute_atmospheric,
    )
    values = np.empty(N_PHASE_NULL, dtype=float)

    for replicate in range(N_PHASE_NULL):
        randomized = central.copy()
        phase = rng.uniform(
            0.0,
            2.0 * np.pi,
            size=len(hold_records),
        )
        randomized[:, 3] = np.cos(phase)
        randomized[:, 4] = np.sin(phase)
        z_random = standardize(randomized, center, scale)
        values[replicate] = float(
            np.mean(
                np.min(
                    pairwise_distances(z_random, z_train),
                    axis=1,
                )
            )
        )
    return values


def run_nulls(
    training: Sequence[OscillationRecord],
    holdout: Sequence[OscillationRecord],
    spec: AtlasSpec,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    summary_path, phase_draw_path = null_paths(spec.name)

    if summary_path.exists():
        summary = pd.read_csv(summary_path)
        expected_rows = 2 * len(
            {record.variant for record in holdout}
        )
        if (
            len(summary) == expected_rows
            and int(summary["phase_null_n"].max())
            == N_PHASE_NULL
        ):
            log(f"[nulls] {spec.name}: loading completed nulls.")
            phase_draws = (
                pd.read_csv(phase_draw_path)
                if phase_draw_path.exists()
                else pd.DataFrame()
            )
            return summary, phase_draws

    x_train = records_matrix(
        training,
        spec.absolute_atmospheric,
    )
    x_hold = records_matrix(
        holdout,
        spec.absolute_atmospheric,
    )
    center, scale = fit_scaler(x_train, spec.scaler_mode)
    z_train = standardize(x_train, center, scale)
    z_hold = standardize(x_hold, center, scale)

    variants = sorted({record.variant for record in holdout})
    summary_rows: List[Dict[str, object]] = []
    phase_rows: List[Dict[str, object]] = []

    for variant in variants:
        indices = [
            index
            for index, record in enumerate(holdout)
            if record.variant == variant
        ]
        variant_records = [holdout[index] for index in indices]
        z_variant = z_hold[indices]

        real, semantic_null, semantic_p = (
            exact_semantic_permutation_null(
                z_variant,
                z_train,
            )
        )
        summary_rows.append(
            {
                "atlas": spec.name,
                "atlas_role": spec.role,
                "variant": variant,
                "null_type": "exact_semantic_coordinate_permutation",
                "real_mean_nn": real,
                "null_n": int(len(semantic_null)),
                "phase_null_n": N_PHASE_NULL,
                "null_q05": float(
                    np.quantile(semantic_null, 0.05)
                ),
                "null_median": float(
                    np.median(semantic_null)
                ),
                "null_q95": float(
                    np.quantile(semantic_null, 0.95)
                ),
                "lower_tail_p": semantic_p,
                "pass_p_le_alpha": bool(
                    semantic_p <= NULL_ALPHA
                ),
            }
        )

        phase_null = phase_randomization_null(
            variant_records,
            z_train,
            center,
            scale,
            spec.absolute_atmospheric,
            seed_for("phase_null", spec.name, variant),
        )
        phase_p = float(
            (1.0 + np.sum(phase_null <= real))
            / (len(phase_null) + 1.0)
        )
        summary_rows.append(
            {
                "atlas": spec.name,
                "atlas_role": spec.role,
                "variant": variant,
                "null_type": "phase_randomization",
                "real_mean_nn": real,
                "null_n": int(len(phase_null)),
                "phase_null_n": N_PHASE_NULL,
                "null_q05": float(
                    np.quantile(phase_null, 0.05)
                ),
                "null_median": float(
                    np.median(phase_null)
                ),
                "null_q95": float(
                    np.quantile(phase_null, 0.95)
                ),
                "lower_tail_p": phase_p,
                "pass_p_le_alpha": bool(
                    phase_p <= NULL_ALPHA
                ),
            }
        )

        if SAVE_FULL_PHASE_NULL_DRAWS:
            for replicate, value in enumerate(phase_null):
                phase_rows.append(
                    {
                        "atlas": spec.name,
                        "variant": variant,
                        "replicate": replicate,
                        "phase_null_mean_nn": float(value),
                    }
                )

    summary_df = pd.DataFrame(summary_rows)
    phase_df = pd.DataFrame(phase_rows)
    atomic_write_csv(summary_df, summary_path)
    if SAVE_FULL_PHASE_NULL_DRAWS:
        atomic_write_csv(phase_df, phase_draw_path)
    return summary_df, phase_df


# =============================================================================
# LEAVE-ONE-FAMILY-OUT DIAGNOSTIC
# =============================================================================

def leave_one_family_out(
    training: Sequence[OscillationRecord],
    spec: AtlasSpec,
) -> pd.DataFrame:
    rows: List[Dict[str, object]] = []
    for family in sorted({record.family for record in training}):
        fit_records = [
            record
            for record in training
            if record.family != family
        ]
        test_records = [
            record
            for record in training
            if record.family == family
        ]
        x_fit = records_matrix(
            fit_records,
            spec.absolute_atmospheric,
        )
        x_test = records_matrix(
            test_records,
            spec.absolute_atmospheric,
        )
        center, scale = fit_scaler(
            x_fit,
            spec.scaler_mode,
        )
        z_fit = standardize(x_fit, center, scale)
        z_test = standardize(x_test, center, scale)

        fit_nn = nearest_neighbor_distances(z_fit)
        envelope = float(np.max(fit_nn))
        test_nn = np.min(
            pairwise_distances(z_test, z_fit),
            axis=1,
        )
        for record, distance in zip(test_records, test_nn):
            ratio = float(distance / max(envelope, EPS))
            rows.append(
                {
                    "atlas": spec.name,
                    "atlas_role": spec.role,
                    "held_family": family,
                    "label": record.label,
                    "ordering": record.ordering,
                    "heldout_nn_distance": float(distance),
                    "training_nn_max": envelope,
                    "envelope_ratio": ratio,
                    "pass_review_only": bool(
                        ratio <= NN_ENVELOPE_FACTOR
                    ),
                    "diagnostic_status": "review_only_not_combined_score",
                }
            )
    return pd.DataFrame(rows)


# =============================================================================
# PCA LOADING ATTRIBUTION AND FIGURES
# =============================================================================

def loading_diagnostics(
    loading_df: pd.DataFrame,
) -> pd.DataFrame:
    rows: List[Dict[str, object]] = []
    for (atlas, pc), group in loading_df.groupby(
        ["atlas", "pc"]
    ):
        ordered = group.sort_values(
            "squared_loading_fraction",
            ascending=False,
        )
        top = ordered.iloc[0]
        rows.append(
            {
                "atlas": atlas,
                "pc": int(pc),
                "explained_variance_ratio": float(
                    top["explained_variance_ratio"]
                ),
                "dominant_feature": str(top["feature"]),
                "dominant_squared_loading_fraction": float(
                    top["squared_loading_fraction"]
                ),
                "single_feature_dominance_flag": bool(
                    top["squared_loading_fraction"] >= 0.50
                ),
                "near_one_dimensional_pc1_flag": bool(
                    int(pc) == 1
                    and float(
                        top["explained_variance_ratio"]
                    )
                    >= 0.90
                ),
            }
        )
    return pd.DataFrame(rows)


def make_pca_arrow_figure(
    train_scores: pd.DataFrame,
    hold_scores: pd.DataFrame,
    atlas: str,
) -> None:
    train = train_scores[train_scores["atlas"] == atlas]
    hold = hold_scores[hold_scores["atlas"] == atlas]

    fig, ax = plt.subplots(figsize=(9.2, 6.4))

    family_styles = {
        "BARI": "o",
        "NUFIT": "s",
        "VALENCIA": "^",
    }
    for family, group in train.groupby("family"):
        ax.scatter(
            group["pc1"],
            group["pc2"],
            marker=family_styles.get(family, "o"),
            s=65,
            label=f"training {family}",
        )
        pair = {
            row["ordering"]: row
            for _, row in group.iterrows()
        }
        if {"NO", "IO"} <= set(pair):
            no = pair["NO"]
            io = pair["IO"]
            ax.annotate(
                "",
                xy=(io["pc1"], io["pc2"]),
                xytext=(no["pc1"], no["pc2"]),
                arrowprops={
                    "arrowstyle": "->",
                    "linewidth": 1.2,
                },
            )
        for _, row in group.iterrows():
            ax.annotate(
                row["ordering"],
                (row["pc1"], row["pc2"]),
                xytext=(4, 4),
                textcoords="offset points",
                fontsize=8,
            )

    for variant, group in hold.groupby("variant"):
        ax.scatter(
            group["pc1"],
            group["pc2"],
            marker="X",
            s=110,
            label=f"holdout {variant}",
        )
        pair = {
            row["ordering"]: row
            for _, row in group.iterrows()
        }
        if {"NO", "IO"} <= set(pair):
            no = pair["NO"]
            io = pair["IO"]
            ax.annotate(
                "",
                xy=(io["pc1"], io["pc2"]),
                xytext=(no["pc1"], no["pc2"]),
                arrowprops={
                    "arrowstyle": "->",
                    "linewidth": 2.0,
                },
            )
        for _, row in group.iterrows():
            ax.annotate(
                row["ordering"],
                (row["pc1"], row["pc2"]),
                xytext=(5, 5),
                textcoords="offset points",
                fontsize=9,
                fontweight="bold",
            )

    ax.set_xlabel("frozen PC1")
    ax.set_ylabel("frozen PC2")
    ax.set_title(
        "NuFIT 6.0 temporal holdout with NO-to-IO arrows\n"
        f"{atlas}"
    )
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(
        OUTPUT_DIR / f"pca_arrows_{atlas}.pdf",
        bbox_inches="tight",
    )
    fig.savefig(
        OUTPUT_DIR / f"pca_arrows_{atlas}.png",
        dpi=220,
        bbox_inches="tight",
    )
    plt.close(fig)


def make_loading_figure(
    loading_df: pd.DataFrame,
    atlas: str,
    pc: int,
) -> None:
    data = loading_df[
        (loading_df["atlas"] == atlas)
        & (loading_df["pc"] == pc)
    ].copy()
    if data.empty:
        return
    data["feature_label"] = data["feature"].map(
        FEATURE_LABELS
    )

    fig, ax = plt.subplots(figsize=(8.8, 5.2))
    ax.bar(
        data["feature_label"],
        data["squared_loading_fraction"],
    )
    explained = float(
        data["explained_variance_ratio"].iloc[0]
    )
    ax.set_ylabel("squared loading fraction")
    ax.set_title(
        f"PCA loading attribution: {atlas}, PC{pc}\n"
        f"explained variance ratio = {explained:.4f}"
    )
    ax.tick_params(axis="x", rotation=35)
    fig.tight_layout()
    fig.savefig(
        OUTPUT_DIR / f"pca_loading_{atlas}_pc{pc}.pdf",
        bbox_inches="tight",
    )
    fig.savefig(
        OUTPUT_DIR / f"pca_loading_{atlas}_pc{pc}.png",
        dpi=220,
        bbox_inches="tight",
    )
    plt.close(fig)


def make_primary_bootstrap_envelope_figure(
    central_hold: pd.DataFrame,
    bootstrap_summary: pd.DataFrame,
) -> None:
    primary = bootstrap_summary[
        bootstrap_summary["atlas"].isin(PRIMARY_ATLASES)
    ].copy()
    central = central_hold[
        central_hold["atlas"].isin(PRIMARY_ATLASES)
    ][
        ["atlas", "label", "nn_envelope_ratio"]
    ].rename(
        columns={
            "nn_envelope_ratio": "central_nn_ratio"
        }
    )
    merged = primary.merge(
        central,
        on=["atlas", "label"],
        how="left",
    )

    labels = [
        "NUFIT6_IC19_IO",
        "NUFIT6_IC19_NO",
        "NUFIT6_IC24SK_IO",
        "NUFIT6_IC24SK_NO",
    ]
    atlases = list(PRIMARY_ATLASES)

    x = np.arange(len(labels), dtype=float)
    width = 0.34

    fig, ax = plt.subplots(figsize=(11.5, 6.2))
    for atlas_index, atlas in enumerate(atlases):
        subset = (
            merged[merged["atlas"] == atlas]
            .set_index("label")
            .reindex(labels)
        )
        positions = x + (
            atlas_index - (len(atlases) - 1) / 2.0
        ) * width
        median = subset["nn_ratio_median"].to_numpy(float)
        low = median - subset["nn_ratio_q05"].to_numpy(float)
        high = subset["nn_ratio_q95"].to_numpy(float) - median
        ax.errorbar(
            positions,
            median,
            yerr=np.vstack([low, high]),
            fmt="o",
            capsize=4,
            label=f"{atlas}: bootstrap 90% interval",
        )
        ax.scatter(
            positions,
            subset["central_nn_ratio"].to_numpy(float),
            marker="x",
            s=55,
            label=f"{atlas}: central value",
        )

    ax.axhline(
        NN_ENVELOPE_FACTOR,
        linestyle="--",
        label="predeclared ceiling",
    )
    ax.axhline(
        1.0,
        linestyle=":",
        label="maximum internal training NN",
    )
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=35, ha="right")
    ax.set_ylabel(
        "holdout NN distance / maximum training NN distance"
    )
    ax.set_title(
        "Uncertainty-symmetric frozen source-atlas envelopes"
    )
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(
        OUTPUT_DIR
        / "primary_bootstrap_source_atlas_envelopes.pdf",
        bbox_inches="tight",
    )
    fig.savefig(
        OUTPUT_DIR
        / "primary_bootstrap_source_atlas_envelopes.png",
        dpi=220,
        bbox_inches="tight",
    )
    plt.close(fig)


# =============================================================================
# COMBINED SOURCE-STABILITY STATISTIC
# =============================================================================

def classify_combined_score(
    score: float,
    envelope: float,
    ordering: float,
    null_fraction: float,
    temporal: float,
) -> str:
    if (
        score >= STRONG_SCORE_MIN
        and envelope >= 0.90
        and ordering >= 0.90
        and null_fraction >= 0.75
        and temporal >= 0.67
    ):
        return "STRONG_EXTERNAL_SOURCE_STABILITY"

    if (
        score >= SUPPORTED_SCORE_MIN
        and envelope >= 0.80
        and ordering >= 0.80
        and null_fraction >= 0.50
        and temporal >= 0.50
    ):
        return "SUPPORTED_EXTERNAL_SOURCE_STABILITY"

    if (
        envelope >= COMPATIBLE_COMPONENT_MIN
        and ordering >= COMPATIBLE_COMPONENT_MIN
    ):
        return "COMPATIBLE_EXTERNAL_STRESS_TEST"

    return "EXTERNAL_STRESS_OR_FAILURE"


def combined_components(
    bootstrap_record_summary: pd.DataFrame,
    bootstrap_ordering_summary: pd.DataFrame,
    null_summary: pd.DataFrame,
    central_ordering: pd.DataFrame,
) -> pd.DataFrame:
    variants = sorted(
        set(bootstrap_record_summary["variant"])
    )
    rows: List[Dict[str, object]] = []

    for variant in variants:
        record_primary = bootstrap_record_summary[
            (
                bootstrap_record_summary["variant"]
                == variant
            )
            & (
                bootstrap_record_summary["atlas"].isin(
                    PRIMARY_ATLASES
                )
            )
        ]
        ordering_primary = bootstrap_ordering_summary[
            (
                bootstrap_ordering_summary["variant"]
                == variant
            )
            & (
                bootstrap_ordering_summary["atlas"].isin(
                    PRIMARY_ATLASES
                )
            )
        ]
        null_primary = null_summary[
            (null_summary["variant"] == variant)
            & null_summary["atlas"].isin(PRIMARY_ATLASES)
        ]

        envelope_component = float(
            record_primary["nn_pass_probability"].mean()
        )
        central_primary = central_ordering[
            (central_ordering["source_type"] == "holdout")
            & (central_ordering["pair"].str.contains(variant, regex=False))
            & (central_ordering["atlas"].isin(PRIMARY_ATLASES))
        ]
        central_ordering_strength = float(
            np.clip(
                central_primary["cosine_to_training_mean"].mean(),
                0.0,
                1.0,
            )
        )
        bootstrap_directional_consistency = float(
            ordering_primary[
                "ordering_positive_probability"
            ].mean()
        )
        ordering_component = float(
            math.sqrt(
                max(central_ordering_strength, EPS)
                * max(bootstrap_directional_consistency, EPS)
            )
        )
        null_component = float(
            null_primary["pass_p_le_alpha"].mean()
        )
        temporal_component = float(
            record_primary[
                "temporal_no_larger_than_cross_family_probability"
            ].mean()
        )

        product = (
            max(envelope_component, EPS)
            * max(ordering_component, EPS)
            * max(null_component, EPS)
            * max(temporal_component, EPS)
        )
        geometric = float(product ** 0.25)
        arithmetic = float(
            np.mean(
                [
                    envelope_component,
                    ordering_component,
                    null_component,
                    temporal_component,
                ]
            )
        )
        conservative = float(
            min(
                envelope_component,
                ordering_component,
                null_component,
                temporal_component,
            )
        )

        rows.append(
            {
                "variant": variant,
                "E_envelope_retention_probability": (
                    envelope_component
                ),
                "O_ordering_stability_component": ordering_component,
                "O_central_ordering_strength": central_ordering_strength,
                "O_bootstrap_directional_consistency": (
                    bootstrap_directional_consistency
                ),
                "O_bootstrap_strict_probability_review_only": float(
                    ordering_primary[
                        "ordering_strict_probability"
                    ].mean()
                ),
                "N_primary_null_pass_fraction": null_component,
                "T_temporal_vs_cross_family_probability": (
                    temporal_component
                ),
                "combined_geometric_score": geometric,
                "combined_arithmetic_score": arithmetic,
                "combined_conservative_minimum": conservative,
                "classification": classify_combined_score(
                    geometric,
                    envelope_component,
                    ordering_component,
                    null_component,
                    temporal_component,
                ),
            }
        )

    return pd.DataFrame(rows)


def combined_bootstrap_draws(
    record_draws: pd.DataFrame,
    ordering_draws: pd.DataFrame,
    null_summary: pd.DataFrame,
    central_ordering: pd.DataFrame,
) -> pd.DataFrame:
    record_primary = record_draws[
        record_draws["atlas"].isin(PRIMARY_ATLASES)
    ].copy()
    ordering_primary = ordering_draws[
        ordering_draws["atlas"].isin(PRIMARY_ATLASES)
    ].copy()

    rows: List[Dict[str, object]] = []
    variants = sorted(record_primary["variant"].unique())

    for variant in variants:
        null_fraction = float(
            null_summary[
                (null_summary["variant"] == variant)
                & null_summary["atlas"].isin(PRIMARY_ATLASES)
            ]["pass_p_le_alpha"].mean()
        )

        rec = record_primary[
            record_primary["variant"] == variant
        ]
        order = ordering_primary[
            ordering_primary["variant"] == variant
        ]

        rec_group = rec.groupby("replicate").agg(
            E=("nn_pass", "mean"),
            T=("temporal_no_larger_than_cross_family", "mean"),
        )
        central_primary = central_ordering[
            (central_ordering["source_type"] == "holdout")
            & (central_ordering["pair"].str.contains(variant, regex=False))
            & (central_ordering["atlas"].isin(PRIMARY_ATLASES))
        ]
        central_ordering_strength = float(
            np.clip(
                central_primary["cosine_to_training_mean"].mean(),
                0.0,
                1.0,
            )
        )

        order_group = order.groupby("replicate").agg(
            directional_consistency=("ordering_cosine", lambda x: np.mean(x > 0.0))
        )
        merged = rec_group.join(order_group, how="inner")

        for replicate, row in merged.iterrows():
            e = float(row["E"])
            directional = float(row["directional_consistency"])
            o = float(
                math.sqrt(
                    max(central_ordering_strength, EPS)
                    * max(directional, EPS)
                )
            )
            t = float(row["T"])
            score = float(
                (
                    max(e, EPS)
                    * max(o, EPS)
                    * max(null_fraction, EPS)
                    * max(t, EPS)
                )
                ** 0.25
            )
            rows.append(
                {
                    "replicate": int(replicate),
                    "variant": variant,
                    "E": e,
                    "O": o,
                    "O_central_ordering_strength_fixed": central_ordering_strength,
                    "O_bootstrap_directional_consistency": directional,
                    "N_fixed_null_fraction": null_fraction,
                    "T": t,
                    "combined_geometric_score": score,
                }
            )
    return pd.DataFrame(rows)


def summarize_combined_bootstrap(
    combined_draws: pd.DataFrame,
) -> pd.DataFrame:
    rows: List[Dict[str, object]] = []
    for variant, group in combined_draws.groupby("variant"):
        scores = group["combined_geometric_score"].to_numpy(
            float
        )
        rows.append(
            {
                "variant": variant,
                "bootstrap_n": int(len(group)),
                "combined_score_q05": float(
                    np.quantile(scores, 0.05)
                ),
                "combined_score_median": float(
                    np.median(scores)
                ),
                "combined_score_q95": float(
                    np.quantile(scores, 0.95)
                ),
                "probability_score_ge_supported_threshold": float(
                    np.mean(scores >= SUPPORTED_SCORE_MIN)
                ),
                "probability_score_ge_strong_threshold": float(
                    np.mean(scores >= STRONG_SCORE_MIN)
                ),
            }
        )
    return pd.DataFrame(rows)


def make_combined_score_figure(
    combined_df: pd.DataFrame,
) -> None:
    components = [
        "E_envelope_retention_probability",
        "O_ordering_stability_component",
        "N_primary_null_pass_fraction",
        "T_temporal_vs_cross_family_probability",
        "combined_geometric_score",
    ]
    labels = ["E", "O", "N", "T", "S"]

    x = np.arange(len(components), dtype=float)
    width = 0.36
    variants = list(combined_df["variant"])

    fig, ax = plt.subplots(figsize=(9.2, 5.7))
    for index, variant in enumerate(variants):
        row = combined_df[
            combined_df["variant"] == variant
        ].iloc[0]
        values = [float(row[column]) for column in components]
        positions = x + (
            index - (len(variants) - 1) / 2.0
        ) * width
        ax.bar(
            positions,
            values,
            width=width,
            label=variant,
        )

    ax.axhline(
        SUPPORTED_SCORE_MIN,
        linestyle="--",
        label="supported-score threshold",
    )
    ax.axhline(
        STRONG_SCORE_MIN,
        linestyle=":",
        label="strong-score threshold",
    )
    ax.set_xticks(x)
    ax.set_xticklabels(labels)
    ax.set_ylim(0.0, 1.05)
    ax.set_ylabel("predeclared component or combined score")
    ax.set_title(
        "External source-atlas stability components"
    )
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(
        OUTPUT_DIR / "combined_source_stability_statistic.pdf",
        bbox_inches="tight",
    )
    fig.savefig(
        OUTPUT_DIR / "combined_source_stability_statistic.png",
        dpi=220,
        bbox_inches="tight",
    )
    plt.close(fig)


# =============================================================================
# MANUSCRIPT-FACING OUTPUTS
# =============================================================================

def format_float(value: float, digits: int = 3) -> str:
    if pd.isna(value):
        return "NA"
    return f"{value:.{digits}f}"


def write_latex_snippet(
    combined_df: pd.DataFrame,
    combined_bootstrap_summary: pd.DataFrame,
    bootstrap_record_summary: pd.DataFrame,
    bootstrap_ordering_summary: pd.DataFrame,
    null_summary: pd.DataFrame,
) -> None:
    rows = []
    for _, result in combined_df.iterrows():
        variant = str(result["variant"])
        boot = combined_bootstrap_summary[
            combined_bootstrap_summary["variant"] == variant
        ].iloc[0]
        rec = bootstrap_record_summary[
            (bootstrap_record_summary["variant"] == variant)
            & bootstrap_record_summary["atlas"].isin(
                PRIMARY_ATLASES
            )
        ]
        order = bootstrap_ordering_summary[
            (bootstrap_ordering_summary["variant"] == variant)
            & bootstrap_ordering_summary["atlas"].isin(
                PRIMARY_ATLASES
            )
        ]
        null = null_summary[
            (null_summary["variant"] == variant)
            & null_summary["atlas"].isin(PRIMARY_ATLASES)
        ]

        label = (
            "IC19 without SK-atm"
            if "IC19" in variant
            else "IC24 with SK-atm"
        )
        rows.append(
            {
                "variant": variant,
                "label": label,
                "classification": result["classification"],
                "score": float(
                    result["combined_geometric_score"]
                ),
                "score_q05": float(
                    boot["combined_score_q05"]
                ),
                "score_q95": float(
                    boot["combined_score_q95"]
                ),
                "max_nn_q95": float(rec["nn_ratio_q95"].max()),
                "min_order_q05": float(
                    order["ordering_cosine_q05"].min()
                ),
                "null_passes": int(
                    null["pass_p_le_alpha"].sum()
                ),
                "null_total": int(len(null)),
                "temporal_probability": float(
                    result[
                        "T_temporal_vs_cross_family_probability"
                    ]
                ),
            }
        )

    first = next(
        row for row in rows if "IC19" in row["variant"]
    )
    second = next(
        row for row in rows if "IC24" in row["variant"]
    )

    latex = rf"""\paragraph{{External temporal stability test.}}
A later NuFIT update, unavailable during development of the construction,
was projected into the frozen BARI--NUFIT--VALENCIA source atlas without
refitting to the holdout.  Uncertainty was propagated symmetrically by
sampling both the development panel and the temporal holdout, while each
replicate continued to estimate its normalization from the development
panel alone.  For {first['label']}, the 95th percentile of the primary
nearest-neighbour envelope ratio was
\({first['max_nn_q95']:.3f}\), the 5th percentile of the
normal-to-inverted ordering cosine was
\({first['min_order_q05']:.3f}\), and
\({first['null_passes']}/{first['null_total']}\) primary
semantic/phase null tests were rejected at \(p\leq0.05\).
The predeclared combined source-stability statistic was
\(S={first['score']:.3f}\)
(90\% bootstrap interval
\([{first['score_q05']:.3f},{first['score_q95']:.3f}]\)),
yielding the classification
\texttt{{{first['classification']}}}.
For the stronger {second['label']} stress test, the corresponding
combined statistic was \(S={second['score']:.3f}\)
(90\% interval
\([{second['score_q05']:.3f},{second['score_q95']:.3f}]\)),
with classification
\texttt{{{second['classification']}}}.
These results are external source-atlas consistency tests; they are not
used in the proof and do not constitute held-out validation of the
downstream two-sector operator law.
"""
    (
        OUTPUT_DIR
        / "external_temporal_stability_test_snippet.tex"
    ).write_text(latex, encoding="utf-8")


def write_report(
    source_manifest: Mapping[str, object],
    central_hold: pd.DataFrame,
    central_ordering: pd.DataFrame,
    bootstrap_record_summary: pd.DataFrame,
    bootstrap_ordering_summary: pd.DataFrame,
    null_summary: pd.DataFrame,
    loading_diagnostic_df: pd.DataFrame,
    combined_df: pd.DataFrame,
    combined_bootstrap_summary: pd.DataFrame,
    lofo_df: pd.DataFrame,
) -> None:
    lines: List[str] = [
        "=" * 88,
        "QEG EXTERNAL-ATLAS STABILITY v2 — FINAL TEMPORAL HOLDOUT AUDIT",
        "=" * 88,
        "",
        f"Script version: {SCRIPT_VERSION}",
        f"Generated UTC: {utc_now()}",
        f"Fast-test mode: {FAST_TEST}",
        f"Bootstrap replicates: {N_BOOTSTRAP}",
        f"Phase-null replicates: {N_PHASE_NULL}",
        "",
        "SOURCE MODE",
        "-----------",
        str(source_manifest.get("source_mode")),
        "",
        "CLAIM CEILING",
        "-------------",
        "External source-atlas stability only.  The holdout is not part of the",
        "proof and does not validate the downstream two-sector operator law.",
        "",
        "PREDECLARED COMBINED STATISTIC",
        "------------------------------",
        "S = (E O N T)^(1/4)",
        "E: bootstrap envelope retention probability",
        "O: central ordering strength x bootstrap directional consistency",
        "N: primary semantic/phase null pass fraction",
        "T: symmetric temporal-vs-cross-family probability",
        "",
        "FINAL VARIANT RESULTS",
        "---------------------",
    ]

    merged = combined_df.merge(
        combined_bootstrap_summary,
        on="variant",
        how="left",
    )
    for _, row in merged.iterrows():
        lines.extend(
            [
                f"{row['variant']}: {row['classification']}",
                f"  E = {row['E_envelope_retention_probability']:.6f}",
                f"  O = {row['O_ordering_stability_component']:.6f}",
                f"  N = {row['N_primary_null_pass_fraction']:.6f}",
                f"  T = {row['T_temporal_vs_cross_family_probability']:.6f}",
                f"  S = {row['combined_geometric_score']:.6f}",
                f"  S bootstrap q05/median/q95 = "
                f"{row['combined_score_q05']:.6f} / "
                f"{row['combined_score_median']:.6f} / "
                f"{row['combined_score_q95']:.6f}",
                "",
            ]
        )

    lines.extend(
        [
            "PRIMARY CENTRAL-VALUE HOLDOUT SCORES",
            "------------------------------------",
            central_hold[
                central_hold["atlas"].isin(PRIMARY_ATLASES)
            ].to_string(index=False),
            "",
            "UNCERTAINTY-SYMMETRIC ENVELOPE SUMMARY",
            "--------------------------------------",
            bootstrap_record_summary[
                bootstrap_record_summary["atlas"].isin(
                    PRIMARY_ATLASES
                )
            ].to_string(index=False),
            "",
            "UNCERTAINTY-SYMMETRIC ORDERING SUMMARY",
            "--------------------------------------",
            bootstrap_ordering_summary[
                bootstrap_ordering_summary["atlas"].isin(
                    PRIMARY_ATLASES
                )
            ].to_string(index=False),
            "",
            "CENTRAL ORDERING ALIGNMENT",
            "--------------------------",
            central_ordering[
                (central_ordering["source_type"] == "holdout")
                & central_ordering["atlas"].isin(PRIMARY_ATLASES)
            ].to_string(index=False),
            "",
            "NULL SUMMARY",
            "------------",
            null_summary.to_string(index=False),
            "",
            "PCA LOADING DIAGNOSTICS",
            "-----------------------",
            loading_diagnostic_df.to_string(index=False),
            "",
            "LEAVE-ONE-FAMILY-OUT DIAGNOSTIC",
            "--------------------------------",
            "This remains review-only and is not part of the combined score.",
            lofo_df.to_string(index=False),
            "",
            "INTERPRETATION RULE",
            "-------------------",
            "A holdout may pass the external source-atlas test without passing",
            "every one-class or full semantic-null criterion.  Ridge-Mahalanobis",
            "and robust-scaling outputs remain review diagnostics because the",
            "development panel has six rows in a seven-dimensional circular",
            "embedding.",
        ]
    )

    (
        OUTPUT_DIR
        / "QEG_external_atlas_stability_v2_report.txt"
    ).write_text("\n".join(lines), encoding="utf-8")


# =============================================================================
# MAIN
# =============================================================================

def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    log("=" * 88)
    log("QEG EXTERNAL-ATLAS STABILITY v2 — FINAL TEMPORAL HOLDOUT AUDIT")
    log("=" * 88)
    log(f"ROOT: {ROOT}")
    log(f"OUTPUT_DIR: {OUTPUT_DIR}")
    log(f"FAST_TEST: {FAST_TEST}")
    log(f"N_BOOTSTRAP: {N_BOOTSTRAP}")
    log(f"N_PHASE_NULL: {N_PHASE_NULL}")

    contract = analysis_contract()
    write_json(OUTPUT_DIR / "analysis_contract.json", contract)

    training, holdout, source_manifest = load_source_panels()
    write_json(
        OUTPUT_DIR / "source_manifest.json",
        source_manifest,
    )
    records_to_dataframe(training).to_csv(
        OUTPUT_DIR / "training_source_panel_frozen.csv",
        index=False,
    )
    records_to_dataframe(holdout).to_csv(
        OUTPUT_DIR / "holdout_source_panel_temporal.csv",
        index=False,
    )

    run_manifest = {
        "script_version": SCRIPT_VERSION,
        "started_utc": utc_now(),
        "python_version": sys.version,
        "platform": platform.platform(),
        "numpy_version": np.__version__,
        "pandas_version": pd.__version__,
        "matplotlib_version": plt.matplotlib.__version__,
        "root": str(ROOT),
        "output_dir": str(OUTPUT_DIR),
        "fast_test": FAST_TEST,
        "n_bootstrap": N_BOOTSTRAP,
        "n_phase_null": N_PHASE_NULL,
    }
    write_json(OUTPUT_DIR / "run_manifest.json", run_manifest)

    central_train_parts: List[pd.DataFrame] = []
    central_hold_parts: List[pd.DataFrame] = []
    central_ordering_parts: List[pd.DataFrame] = []
    loading_parts: List[pd.DataFrame] = []
    atlas_metadata: List[Dict[str, object]] = []

    bootstrap_record_parts: List[pd.DataFrame] = []
    bootstrap_ordering_parts: List[pd.DataFrame] = []
    null_parts: List[pd.DataFrame] = []
    phase_draw_parts: List[pd.DataFrame] = []
    lofo_parts: List[pd.DataFrame] = []

    for spec in ATLAS_SPECS:
        log(f"\n[central] {spec.name}")
        (
            train_df,
            hold_df,
            ordering_df,
            loading_df,
            metadata,
        ) = central_atlas_analysis(
            training,
            holdout,
            spec,
        )
        central_train_parts.append(train_df)
        central_hold_parts.append(hold_df)
        central_ordering_parts.append(ordering_df)
        loading_parts.append(loading_df)
        atlas_metadata.append(metadata)

        record_draws, ordering_draws = bootstrap_atlas(
            training,
            holdout,
            spec,
        )
        bootstrap_record_parts.append(record_draws)
        bootstrap_ordering_parts.append(ordering_draws)

        null_summary, phase_draws = run_nulls(
            training,
            holdout,
            spec,
        )
        null_parts.append(null_summary)
        if not phase_draws.empty:
            phase_draw_parts.append(phase_draws)

        lofo_parts.append(
            leave_one_family_out(training, spec)
        )

    central_train = pd.concat(
        central_train_parts,
        ignore_index=True,
    )
    central_hold = pd.concat(
        central_hold_parts,
        ignore_index=True,
    )
    central_ordering = pd.concat(
        central_ordering_parts,
        ignore_index=True,
    )
    loading_df = pd.concat(
        loading_parts,
        ignore_index=True,
    )
    bootstrap_record_draws = pd.concat(
        bootstrap_record_parts,
        ignore_index=True,
    )
    bootstrap_ordering_draws = pd.concat(
        bootstrap_ordering_parts,
        ignore_index=True,
    )
    null_summary = pd.concat(
        null_parts,
        ignore_index=True,
    )
    phase_draws_all = (
        pd.concat(phase_draw_parts, ignore_index=True)
        if phase_draw_parts
        else pd.DataFrame()
    )
    lofo_df = pd.concat(
        lofo_parts,
        ignore_index=True,
    )

    bootstrap_record_summary = summarize_bootstrap_records(
        bootstrap_record_draws
    )
    bootstrap_ordering_summary = summarize_bootstrap_ordering(
        bootstrap_ordering_draws
    )
    loading_diagnostic_df = loading_diagnostics(loading_df)

    combined_df = combined_components(
        bootstrap_record_summary,
        bootstrap_ordering_summary,
        null_summary,
        central_ordering,
    )
    combined_draws = combined_bootstrap_draws(
        bootstrap_record_draws,
        bootstrap_ordering_draws,
        null_summary,
        central_ordering,
    )
    combined_bootstrap_summary = summarize_combined_bootstrap(
        combined_draws
    )

    # Canonical outputs.
    atomic_write_csv(
        central_train,
        OUTPUT_DIR / "central_training_atlas_scores.csv",
    )
    atomic_write_csv(
        central_hold,
        OUTPUT_DIR / "central_holdout_atlas_scores.csv",
    )
    atomic_write_csv(
        central_ordering,
        OUTPUT_DIR / "central_ordering_alignment.csv",
    )
    atomic_write_csv(
        loading_df,
        OUTPUT_DIR / "pca_loading_attribution.csv",
    )
    atomic_write_csv(
        loading_diagnostic_df,
        OUTPUT_DIR / "pca_loading_diagnostics.csv",
    )
    atomic_write_csv(
        bootstrap_record_summary,
        OUTPUT_DIR / "bootstrap_envelope_temporal_summary.csv",
    )
    atomic_write_csv(
        bootstrap_ordering_summary,
        OUTPUT_DIR / "bootstrap_ordering_summary.csv",
    )
    atomic_write_csv(
        null_summary,
        OUTPUT_DIR / "semantic_and_phase_null_summary.csv",
    )
    if SAVE_FULL_PHASE_NULL_DRAWS and not phase_draws_all.empty:
        atomic_write_csv(
            phase_draws_all,
            OUTPUT_DIR / "phase_null_draws_all_atlases.csv",
        )
    atomic_write_csv(
        lofo_df,
        OUTPUT_DIR / "leave_one_family_out_diagnostic.csv",
    )
    atomic_write_csv(
        combined_df,
        OUTPUT_DIR / "combined_source_stability_statistic.csv",
    )
    atomic_write_csv(
        combined_draws,
        OUTPUT_DIR / "combined_source_stability_bootstrap_draws.csv",
    )
    atomic_write_csv(
        combined_bootstrap_summary,
        OUTPUT_DIR / "combined_source_stability_bootstrap_summary.csv",
    )
    write_json(
        OUTPUT_DIR / "atlas_metadata.json",
        {"atlases": atlas_metadata},
    )

    verdict = {
        "script_version": SCRIPT_VERSION,
        "generated_utc": utc_now(),
        "claim_ceiling": (
            "external source-atlas stability only; not part of proof; "
            "not downstream two-sector validation"
        ),
        "combined_results": combined_df.to_dict(
            orient="records"
        ),
        "combined_bootstrap_summary": (
            combined_bootstrap_summary.to_dict(
                orient="records"
            )
        ),
        "primary_atlases": list(PRIMARY_ATLASES),
        "sensitivity_atlases": list(
            SENSITIVITY_ATLASES
        ),
        "fast_test": FAST_TEST,
    }
    write_json(OUTPUT_DIR / "verdict.json", verdict)

    # Figures.
    for atlas in ALL_ATLASES:
        make_pca_arrow_figure(
            central_train,
            central_hold,
            atlas,
        )
        make_loading_figure(loading_df, atlas, 1)
        make_loading_figure(loading_df, atlas, 2)

    make_primary_bootstrap_envelope_figure(
        central_hold,
        bootstrap_record_summary,
    )
    make_combined_score_figure(combined_df)

    # Manuscript and human-readable outputs.
    write_latex_snippet(
        combined_df,
        combined_bootstrap_summary,
        bootstrap_record_summary,
        bootstrap_ordering_summary,
        null_summary,
    )
    write_report(
        source_manifest,
        central_hold,
        central_ordering,
        bootstrap_record_summary,
        bootstrap_ordering_summary,
        null_summary,
        loading_diagnostic_df,
        combined_df,
        combined_bootstrap_summary,
        lofo_df,
    )

    completion = {
        **run_manifest,
        "completed_utc": utc_now(),
        "status": "COMPLETE",
        "output_files": sorted(
            path.name
            for path in OUTPUT_DIR.iterdir()
            if path.is_file()
        ),
    }
    write_json(
        OUTPUT_DIR / "completion_manifest.json",
        completion,
    )

    log("\n" + "=" * 88)
    log("FINAL VARIANT VERDICTS")
    log("=" * 88)
    for _, row in combined_df.iterrows():
        log(
            f"{row['variant']}: "
            f"{row['classification']} "
            f"(S={row['combined_geometric_score']:.6f})"
        )
    log(f"\nOutputs: {OUTPUT_DIR}")
    if FAST_TEST:
        log(
            "WARNING: FAST_TEST outputs are runtime checks only "
            "and must not enter the manuscript."
        )


if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
        raise
