#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
============================================================
Project: Quantum-Emergent Gravity
Stage: 6S
Author: Arturo Ortiz-Tapia
Build Date: 2026-05-05
Script: Stage-6S_mechanism_stability_operator_probes_v1.py
============================================================

WORKING TITLE
-------------
Mechanism Stability & Operator Probes

WHY THIS STAGE EXISTS
---------------------
Stage-6Q froze the canonical two-lobe law

    rho(s) ~= E(s) + C(s)

with a hard early anchor near s ~= 0.15, a softer central bulk response,
and a stable mass partition. Stage-6R narrowed the mechanism class:

NOT preferred:
    - simple local PDE closure
    - simple translation-invariant Green kernel
    - pure rank-1 operator as a universal explanation

Still plausible:
    - low-rank/few-mode response operators
    - asymmetric boundary-to-bulk kernels
    - source-probe-dependent stability
    - non-translation-invariant Green-like operators

Stage-6S asks the sharper question:

    Which source probes make the low-rank operator stable?

DISCIPLINE RULES
----------------
- Do NOT refit the canonical rho(s) law.
- Do NOT alter Stage-6Q invariants.
- Do NOT make cosmology or spacetime claims.
- Do test perturbations, operator rank, family amplitudes, and
  non-translation-invariant Green candidates.

EXPECTED OUTPUTS
----------------
metric_stage_6S_outputs/
    stage6S_source_perturbation_tests.csv
    stage6S_operator_rank_stability.csv
    stage6S_family_amplitude_analysis.csv
    stage6S_nonlocal_kernel_tests.csv
    stage6S_rank1_refined_tests.csv
    stage6S_operator_summary.json
    stage6S_interpretation_notes.txt

Optional figures:
    stage6S_kernel_comparison.png
    stage6S_probe_response_overlay.png
    stage6S_rank_energy_plot.png

This script is intentionally defensive about input schemas. It attempts to
locate Stage-6Q/6R outputs first, then falls back to later canonical/family
outputs when needed. It records all fallbacks in the notes.
============================================================
"""

from __future__ import annotations

import json
import math
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd

try:
    import matplotlib.pyplot as plt
    MATPLOTLIB_AVAILABLE = True
except Exception:
    MATPLOTLIB_AVAILABLE = False

try:
    from scipy.ndimage import gaussian_filter1d
    from scipy.optimize import nnls
    SCIPY_AVAILABLE = True
except Exception:
    SCIPY_AVAILABLE = False


# -----------------------------------------------------------------------------
# Configuration
# -----------------------------------------------------------------------------

PROJECT_ROOT_CANDIDATES = [
    Path.cwd(),
    Path("/home/dakini/Downloads/010-Quantum_Emergent_Gravity"),
]

STAGE_NAME = "6S"
SCRIPT_NAME = Path(__file__).name if "__file__" in globals() else "Stage-6S_mechanism_stability_operator_probes_v1.py"

CANONICAL_CONSTANTS = {
    "mu_early": 0.150000000,
    "mu_central": 0.537000000,
    "early_mass_fraction": 0.267000000,
    "central_mass_fraction": 0.733000000,
}

RNG_SEED = 6019
EPS = 1.0e-12


# -----------------------------------------------------------------------------
# Utilities
# -----------------------------------------------------------------------------


def banner(title: str) -> None:
    print("=" * 72)
    print(title)
    print("=" * 72)


def find_project_root() -> Path:
    for p in PROJECT_ROOT_CANDIDATES:
        if (p / "metric_stage_6Q_outputs").exists() or (p / "metric_stage_6R_outputs").exists():
            return p.resolve()
    # If run from a subfolder, walk upward.
    here = Path.cwd().resolve()
    for p in [here] + list(here.parents):
        if (p / "metric_stage_6Q_outputs").exists() or (p / "metric_stage_6R_outputs").exists():
            return p
    return Path.cwd().resolve()


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def safe_read_csv(path: Path) -> Optional[pd.DataFrame]:
    try:
        if path.exists():
            return pd.read_csv(path)
    except Exception as exc:
        print(f"[WARN] Could not read CSV {path}: {exc}")
    return None


def safe_read_json(path: Path) -> Optional[dict]:
    try:
        if path.exists():
            with path.open("r", encoding="utf-8") as f:
                return json.load(f)
    except Exception as exc:
        print(f"[WARN] Could not read JSON {path}: {exc}")
    return None


def first_existing(root: Path, rel_paths: Iterable[str]) -> Optional[Path]:
    for rel in rel_paths:
        p = root / rel
        if p.exists():
            return p
    return None


def find_column(df: pd.DataFrame, candidates: Iterable[str]) -> Optional[str]:
    lower_map = {c.lower(): c for c in df.columns}
    for c in candidates:
        if c in df.columns:
            return c
        if c.lower() in lower_map:
            return lower_map[c.lower()]
    # fuzzy containment, conservative
    for cand in candidates:
        cl = cand.lower()
        for col in df.columns:
            if cl == col.lower() or cl in col.lower():
                return col
    return None


def normalize_vector(x: np.ndarray, positive: bool = True) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    x = np.nan_to_num(x, nan=0.0, posinf=0.0, neginf=0.0)
    if positive:
        x = x - np.nanmin(x)
    area = np.trapz(x, dx=1.0 / max(len(x) - 1, 1)) if len(x) > 1 else np.sum(x)
    if abs(area) < EPS:
        norm = np.linalg.norm(x)
        return x / norm if norm > EPS else x
    return x / area


def zscore(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    s = np.std(x)
    if s < EPS:
        return x * 0.0
    return (x - np.mean(x)) / s


def corrcoef(a: np.ndarray, b: np.ndarray) -> float:
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    if len(a) != len(b) or len(a) < 2:
        return float("nan")
    if np.std(a) < EPS or np.std(b) < EPS:
        return float("nan")
    return float(np.corrcoef(a, b)[0, 1])


def r2_score(y: np.ndarray, yhat: np.ndarray) -> float:
    y = np.asarray(y, dtype=float)
    yhat = np.asarray(yhat, dtype=float)
    ss_res = float(np.sum((y - yhat) ** 2))
    ss_tot = float(np.sum((y - np.mean(y)) ** 2))
    return float(1.0 - ss_res / ss_tot) if ss_tot > EPS else float("nan")


def rmse(y: np.ndarray, yhat: np.ndarray) -> float:
    return float(np.sqrt(np.mean((np.asarray(y) - np.asarray(yhat)) ** 2)))


def effective_rank_from_singular_values(svals: np.ndarray) -> float:
    svals = np.asarray(svals, dtype=float)
    if np.sum(svals) < EPS:
        return 0.0
    p = svals / np.sum(svals)
    entropy = -float(np.sum(p[p > EPS] * np.log(p[p > EPS])))
    return float(np.exp(entropy))


def svd_rank_metrics(G: np.ndarray, label: str) -> Dict[str, float]:
    try:
        svals = np.linalg.svd(G, compute_uv=False)
    except Exception:
        svals = np.array([], dtype=float)
    if len(svals) == 0:
        return {
            "operator_label": label,
            "energy_rank1": float("nan"),
            "energy_rank2": float("nan"),
            "effective_rank": float("nan"),
            "singular_gap_1_2": float("nan"),
            "numerical_rank": 0,
        }
    energy = svals ** 2
    total = float(np.sum(energy))
    e1 = float(energy[0] / total) if total > EPS else float("nan")
    e2 = float(np.sum(energy[:2]) / total) if total > EPS else float("nan")
    gap = float(svals[0] / svals[1]) if len(svals) > 1 and svals[1] > EPS else float("inf")
    return {
        "operator_label": label,
        "energy_rank1": e1,
        "energy_rank2": e2,
        "effective_rank": effective_rank_from_singular_values(svals),
        "singular_gap_1_2": gap,
        "numerical_rank": int(np.sum(svals > max(svals[0] * 1e-10, 1e-12))),
    }


def resample_to_grid(s_src: np.ndarray, y_src: np.ndarray, s_new: np.ndarray) -> np.ndarray:
    order = np.argsort(s_src)
    s_src = np.asarray(s_src)[order]
    y_src = np.asarray(y_src)[order]
    # remove duplicate s values by averaging
    df = pd.DataFrame({"s": s_src, "y": y_src}).groupby("s", as_index=False).mean()
    return np.interp(s_new, df["s"].to_numpy(), df["y"].to_numpy())


def gaussian_template(s: np.ndarray, mu: float, sigma: float) -> np.ndarray:
    sigma = max(float(sigma), 1e-4)
    return np.exp(-0.5 * ((s - mu) / sigma) ** 2)


def skewed_central_template(s: np.ndarray, mu: float, sigma: float, skew: float = -0.20) -> np.ndarray:
    base = gaussian_template(s, mu, sigma)
    modifier = 1.0 + skew * (s - mu) / max(sigma, 1e-4)
    return np.clip(base * modifier, 0.0, None)


def finite_difference(y: np.ndarray, s: np.ndarray) -> np.ndarray:
    if len(y) < 3:
        return np.zeros_like(y)
    return np.gradient(y, s)


@dataclass
class CanonicalData:
    s: np.ndarray
    rho: np.ndarray
    kappa: np.ndarray
    family_df: Optional[pd.DataFrame]
    source_notes: List[str]


# -----------------------------------------------------------------------------
# Input loading and fallback reconstruction
# -----------------------------------------------------------------------------


def load_canonical_data(root: Path) -> CanonicalData:
    notes: List[str] = []
    n_grid = 361
    s_grid = np.linspace(0.0, 1.0, n_grid)

    curve_candidates = [
        "metric_stage_6Q_outputs/stage6Q_canonical_curve.csv",
        "metric_stage_6R_outputs/stage6R_canonical_curve.csv",
        "metric_stage_6P_outputs/stage6P_v6_canonical_family_reference.csv",
        "metric_stage_6N_outputs/stage6N_v1b_family_recovered_two_lobe_profile.csv",
        "metric_stage_6M_outputs/stage6M_targeted_v2c_profile.csv",
    ]
    curve_path = first_existing(root, curve_candidates)
    s = s_grid.copy()
    rho = None

    if curve_path is not None:
        df = safe_read_csv(curve_path)
        if df is not None and len(df) >= 5:
            s_col = find_column(df, ["s", "s_normalized", "s_grid", "intrinsic_s", "stage6_s"])
            rho_col = find_column(df, ["rho", "rho_like", "rho_canonical", "density", "observed", "target", "y"])
            if s_col and rho_col:
                s_raw = pd.to_numeric(df[s_col], errors="coerce").to_numpy()
                rho_raw = pd.to_numeric(df[rho_col], errors="coerce").to_numpy()
                mask = np.isfinite(s_raw) & np.isfinite(rho_raw)
                if np.sum(mask) >= 5:
                    s = s_grid.copy()
                    rho = resample_to_grid(s_raw[mask], rho_raw[mask], s)
                    notes.append(f"Loaded canonical curve from {curve_path.relative_to(root)} using columns {s_col}, {rho_col}.")

    if rho is None:
        # Frozen analytic fallback from the canonical structure; this is not refitting.
        E = gaussian_template(s, CANONICAL_CONSTANTS["mu_early"], 0.035)
        C = skewed_central_template(s, CANONICAL_CONSTANTS["mu_central"], 0.095, skew=-0.15)
        E = normalize_vector(E)
        C = normalize_vector(C)
        rho = CANONICAL_CONSTANTS["early_mass_fraction"] * E + CANONICAL_CONSTANTS["central_mass_fraction"] * C
        notes.append("No canonical curve file found; used frozen analytic canonical fallback from Stage-6Q constants.")
    else:
        rho = normalize_vector(rho)

    # kappa/source candidates: prefer Stage-6R/6J/6K profiles if available.
    kappa = None
    source_candidates = [
        "metric_stage_6R_outputs/stage6R_source_probe_profile.csv",
        "metric_stage_6R_outputs/stage6R_operator_probe_profile.csv",
        "metric_stage_6K_outputs/stage6K_canonical_operator_profile.csv",
        "metric_stage_6J_outputs/stage6J_nonlocal_operator_profile.csv",
        "metric_stage_6H_outputs/stage6H_distributional_profile.csv",
    ]
    source_path = first_existing(root, source_candidates)
    if source_path is not None:
        df = safe_read_csv(source_path)
        if df is not None and len(df) >= 5:
            s_col = find_column(df, ["s", "s_normalized", "intrinsic_s", "stage6_s"])
            k_col = find_column(df, ["kappa", "abs_kappa", "source", "source_mode", "v1", "dominant_source_mode", "curvature", "curvature_like"])
            if s_col and k_col:
                s_raw = pd.to_numeric(df[s_col], errors="coerce").to_numpy()
                k_raw = pd.to_numeric(df[k_col], errors="coerce").to_numpy()
                mask = np.isfinite(s_raw) & np.isfinite(k_raw)
                if np.sum(mask) >= 5:
                    kappa = resample_to_grid(s_raw[mask], k_raw[mask], s)
                    notes.append(f"Loaded source probe from {source_path.relative_to(root)} using columns {s_col}, {k_col}.")

    if kappa is None:
        # Construct a canonical source probe from boundary sensitivity + curvature of rho.
        # This is a controlled probe, not a physical identification.
        boundary = np.exp(-s / 0.10)
        curvature_proxy = -finite_difference(finite_difference(rho, s), s)
        kappa = zscore(0.65 * boundary + 0.35 * zscore(curvature_proxy))
        notes.append("No explicit kappa/source profile found; built controlled baseline source from boundary layer + rho curvature proxy.")
    else:
        kappa = zscore(kappa)

    # Family-aware profile candidate for amplitude tests.
    family_df = None
    family_candidates = [
        "metric_stage_6P_outputs/stage6P_v6_family_two_lobe_fit_table.csv",
        "metric_stage_6P_outputs/stage6P_v6_two_lobe_universality_table.csv",
        "metric_stage_6P_outputs/stage6P_v6_family_profile_48bins.csv",
        "metric_stage_6O_outputs/provenance_branch_family_aware_rebuild_from_6D/stage6O_family_aware_profile_48bins_from_6D.csv",
        "metric_stage_6O_outputs/provenance_branch_family_aware_rebuild_from_6D/stage6O_family_aware_profile_361bins_from_6D.csv",
    ]
    family_path = first_existing(root, family_candidates)
    if family_path is not None:
        fdf = safe_read_csv(family_path)
        if fdf is not None and len(fdf) > 0:
            family_df = fdf
            notes.append(f"Loaded optional family table from {family_path.relative_to(root)}.")
    else:
        notes.append("No family-aware table found; family amplitude test will use synthetic no-claim placeholders from canonical components only.")

    return CanonicalData(s=s, rho=rho, kappa=kappa, family_df=family_df, source_notes=notes)


# -----------------------------------------------------------------------------
# Operator constructions
# -----------------------------------------------------------------------------


def local_translation_kernel(s: np.ndarray, length: float) -> np.ndarray:
    D = np.abs(s[:, None] - s[None, :])
    G = np.exp(-D / max(length, 1e-4))
    G /= np.maximum(np.sum(G, axis=1, keepdims=True), EPS)
    return G


def boundary_forced_kernel(s: np.ndarray, target_mu: float = 0.54, length_source: float = 0.12, width_target: float = 0.12) -> np.ndarray:
    # Non-translation-invariant: source is read near boundary; response emitted near central/bulk sector.
    source_read = np.exp(-s / max(length_source, 1e-4))
    target_emit = gaussian_template(s, target_mu, width_target)
    G = np.outer(target_emit, source_read)
    G /= np.linalg.norm(G) + EPS
    return G


def position_dependent_diffusion_kernel(s: np.ndarray, base_length: float = 0.06, gradient: float = 0.20) -> np.ndarray:
    # Length scale grows with target coordinate: boundary reads narrowly, bulk redistributes more broadly.
    G = np.zeros((len(s), len(s)))
    for i, si in enumerate(s):
        L = max(base_length + gradient * si, 1e-4)
        G[i, :] = np.exp(-0.5 * ((si - s) / L) ** 2)
    G /= np.maximum(np.sum(G, axis=1, keepdims=True), EPS)
    return G


def anisotropic_boundary_bulk_kernel(s: np.ndarray, early_mu: float = 0.15, central_mu: float = 0.537) -> np.ndarray:
    # Two-channel non-translation-invariant kernel: early injection + central redistribution.
    source_boundary = np.exp(-s / 0.10)
    source_edges = np.exp(-s / 0.08) + np.exp(-(1 - s) / 0.12)
    target_early = gaussian_template(s, early_mu, 0.040)
    target_central = skewed_central_template(s, central_mu, 0.110, skew=-0.15)
    G = 0.35 * np.outer(target_early, source_boundary) + 0.65 * np.outer(target_central, source_edges)
    G /= np.linalg.norm(G) + EPS
    return G


def fit_linear_scale(y: np.ndarray, x: np.ndarray) -> Tuple[float, np.ndarray]:
    denom = float(np.dot(x, x))
    a = float(np.dot(y, x) / denom) if denom > EPS else 0.0
    return a, a * x


def evaluate_kernel(label: str, G: np.ndarray, kappa: np.ndarray, rho: np.ndarray) -> Dict[str, float]:
    pred_raw = G @ kappa
    _, pred = fit_linear_scale(rho, pred_raw)
    row = {
        "kernel_label": label,
        "corr": corrcoef(rho, pred),
        "r2": r2_score(rho, pred),
        "rmse": rmse(rho, pred),
        "asymmetry_score": float(np.linalg.norm(G - G.T) / (np.linalg.norm(G) + EPS)) if G.shape[0] == G.shape[1] else float("nan"),
        "toeplitz_deviation": toeplitz_deviation(G),
    }
    row.update(svd_rank_metrics(G, label))
    return row


def toeplitz_deviation(G: np.ndarray) -> float:
    n, m = G.shape
    if n != m:
        return float("nan")
    T = np.zeros_like(G)
    for offset in range(-(n - 1), n):
        vals = np.diag(G, k=offset)
        if len(vals) == 0:
            continue
        T += np.diag(np.full(len(vals), np.mean(vals)), k=offset)
    return float(np.linalg.norm(G - T) / (np.linalg.norm(G) + EPS))


# -----------------------------------------------------------------------------
# Stage-6S tasks
# -----------------------------------------------------------------------------


def build_source_variants(s: np.ndarray, kappa: np.ndarray, rho: np.ndarray) -> Dict[str, np.ndarray]:
    rng = np.random.default_rng(RNG_SEED)
    smooth_noise = rng.normal(0.0, 1.0, size=len(s))
    if SCIPY_AVAILABLE:
        smooth_noise = gaussian_filter1d(smooth_noise, sigma=max(2, len(s) // 80))
    else:
        smooth_noise = np.convolve(smooth_noise, np.ones(7) / 7.0, mode="same")

    boundary_weight = np.exp(-s / 0.12)
    central_window = gaussian_template(s, CANONICAL_CONSTANTS["mu_central"], 0.16)
    rho_curv = -finite_difference(finite_difference(rho, s), s)

    variants = {
        "baseline_canonical_source": zscore(kappa),
        "noise_perturbed_source": zscore(kappa + 0.10 * zscore(smooth_noise)),
        "boundary_amplified_source": zscore(kappa * (1.0 + 1.25 * boundary_weight)),
        "boundary_suppressed_source": zscore(kappa * (1.0 - 0.65 * boundary_weight)),
        "central_only_source": zscore(kappa * central_window),
        "random_smooth_source": zscore(smooth_noise),
        "rho_curvature_proxy_source": zscore(rho_curv),
    }
    return variants


def source_perturbation_tests(s: np.ndarray, rho: np.ndarray, kappa: np.ndarray) -> Tuple[pd.DataFrame, pd.DataFrame]:
    variants = build_source_variants(s, kappa, rho)
    # A fixed non-translation-invariant reference operator used to test response stability.
    G_ref = anisotropic_boundary_bulk_kernel(s)

    rows = []
    rank_rows = []
    for label, source in variants.items():
        pred_raw = G_ref @ source
        scale, pred = fit_linear_scale(rho, pred_raw)
        rows.append({
            "source_probe": label,
            "scale_to_rho": scale,
            "corr_with_canonical_rho": corrcoef(rho, pred),
            "r2_against_canonical_rho": r2_score(rho, pred),
            "rmse_against_canonical_rho": rmse(rho, pred),
            "source_boundary_mass_proxy": float(np.trapz(np.abs(source) * np.exp(-s / 0.15), s)),
            "source_central_mass_proxy": float(np.trapz(np.abs(source) * gaussian_template(s, CANONICAL_CONSTANTS["mu_central"], 0.18), s)),
        })
        # Source-dependent induced rank-1 operator using this probe as the read vector.
        u = normalize_vector(rho, positive=True)
        v = zscore(source)
        G_induced = np.outer(u, v)
        rr = svd_rank_metrics(G_induced, f"rank1_induced_by_{label}")
        rr["source_probe"] = label
        rank_rows.append(rr)
    return pd.DataFrame(rows), pd.DataFrame(rank_rows)


def family_amplitude_analysis(s: np.ndarray, rho: np.ndarray, family_df: Optional[pd.DataFrame]) -> pd.DataFrame:
    E = normalize_vector(gaussian_template(s, CANONICAL_CONSTANTS["mu_early"], 0.045))
    C = normalize_vector(skewed_central_template(s, CANONICAL_CONSTANTS["mu_central"], 0.110, skew=-0.15))
    basis = np.vstack([E, C]).T

    rows: List[Dict[str, object]] = []

    if family_df is not None:
        fam_col = find_column(family_df, ["family", "FIT", "FIT_id", "stage6O_family", "source_family"])
        s_col = find_column(family_df, ["s", "s_normalized", "s_bin_center", "bin_center", "intrinsic_s"])
        rho_col = find_column(family_df, ["rho", "rho_like", "density", "profile_value", "value", "amplitude"])
        # If file is already a fit table, read amplitudes/centers directly where possible.
        ae_col = find_column(family_df, ["early_amplitude", "amp_early", "A_early", "early_mass_fraction"])
        ac_col = find_column(family_df, ["central_amplitude", "amp_central", "A_central", "central_mass_fraction"])
        me_col = find_column(family_df, ["mu_early", "early_mu"])
        mc_col = find_column(family_df, ["mu_central", "central_mu"])

        if fam_col and ae_col and ac_col:
            for fam, g in family_df.groupby(fam_col):
                rows.append({
                    "family": str(fam),
                    "mode": "reported_fit_table",
                    "early_amplitude": float(pd.to_numeric(g[ae_col], errors="coerce").mean()),
                    "central_amplitude": float(pd.to_numeric(g[ac_col], errors="coerce").mean()),
                    "amplitude_ratio_E_over_C": float(pd.to_numeric(g[ae_col], errors="coerce").mean() / (pd.to_numeric(g[ac_col], errors="coerce").mean() + EPS)),
                    "mu_early": float(pd.to_numeric(g[me_col], errors="coerce").mean()) if me_col else CANONICAL_CONSTANTS["mu_early"],
                    "mu_central": float(pd.to_numeric(g[mc_col], errors="coerce").mean()) if mc_col else CANONICAL_CONSTANTS["mu_central"],
                    "fit_r2": float("nan"),
                    "notes": "Read amplitudes from existing family fit table; no refit of canonical law.",
                })
            return pd.DataFrame(rows)

        if fam_col and s_col and rho_col:
            for fam, g in family_df.groupby(fam_col):
                sr = pd.to_numeric(g[s_col], errors="coerce").to_numpy()
                yr = pd.to_numeric(g[rho_col], errors="coerce").to_numpy()
                mask = np.isfinite(sr) & np.isfinite(yr)
                if np.sum(mask) < 5:
                    continue
                y = normalize_vector(resample_to_grid(sr[mask], yr[mask], s), positive=True)
                # Nonnegative amplitude readout only; this is amplitude projection, not center refitting.
                if SCIPY_AVAILABLE:
                    coeff, _ = nnls(basis, y)
                else:
                    coeff, *_ = np.linalg.lstsq(basis, y, rcond=None)
                    coeff = np.clip(coeff, 0.0, None)
                pred = basis @ coeff
                rows.append({
                    "family": str(fam),
                    "mode": "projected_to_frozen_E_C_basis",
                    "early_amplitude": float(coeff[0]),
                    "central_amplitude": float(coeff[1]),
                    "amplitude_ratio_E_over_C": float(coeff[0] / (coeff[1] + EPS)),
                    "mu_early": CANONICAL_CONSTANTS["mu_early"],
                    "mu_central": CANONICAL_CONSTANTS["mu_central"],
                    "fit_r2": r2_score(y, pred),
                    "notes": "Projected family profile onto frozen Stage-6Q E/C templates; centers not refit.",
                })
            if rows:
                return pd.DataFrame(rows)

    # Fallback: canonical amplitude projection only.
    if SCIPY_AVAILABLE:
        coeff, _ = nnls(basis, rho)
    else:
        coeff, *_ = np.linalg.lstsq(basis, rho, rcond=None)
        coeff = np.clip(coeff, 0.0, None)
    pred = basis @ coeff
    rows.append({
        "family": "POOLED_CANONICAL_FALLBACK",
        "mode": "projected_to_frozen_E_C_basis",
        "early_amplitude": float(coeff[0]),
        "central_amplitude": float(coeff[1]),
        "amplitude_ratio_E_over_C": float(coeff[0] / (coeff[1] + EPS)),
        "mu_early": CANONICAL_CONSTANTS["mu_early"],
        "mu_central": CANONICAL_CONSTANTS["mu_central"],
        "fit_r2": r2_score(rho, pred),
        "notes": "No family table available; pooled fallback only. Do not use for universality claim.",
    })
    return pd.DataFrame(rows)


def nonlocal_kernel_tests(s: np.ndarray, rho: np.ndarray, kappa: np.ndarray) -> pd.DataFrame:
    kernels = {
        "local_translation_exp_L_0p06": local_translation_kernel(s, 0.06),
        "local_translation_exp_L_0p15": local_translation_kernel(s, 0.15),
        "boundary_forced_green_like": boundary_forced_kernel(s),
        "position_dependent_diffusion": position_dependent_diffusion_kernel(s),
        "anisotropic_boundary_bulk": anisotropic_boundary_bulk_kernel(s),
    }
    rows = [evaluate_kernel(label, G, kappa, rho) for label, G in kernels.items()]
    return pd.DataFrame(rows)


def rank1_refined_tests(s: np.ndarray, rho: np.ndarray, kappa: np.ndarray) -> pd.DataFrame:
    E = normalize_vector(gaussian_template(s, CANONICAL_CONSTANTS["mu_early"], 0.045))
    C = normalize_vector(skewed_central_template(s, CANONICAL_CONSTANTS["mu_central"], 0.110, skew=-0.15))
    u_candidates = {
        "u_rho_canonical": normalize_vector(rho, positive=True),
        "u_early_template": E,
        "u_central_template": C,
        "u_two_lobe_template": normalize_vector(CANONICAL_CONSTANTS["early_mass_fraction"] * E + CANONICAL_CONSTANTS["central_mass_fraction"] * C),
    }
    v_candidates = {
        "v_baseline_kappa": zscore(kappa),
        "v_boundary_read": zscore(np.exp(-s / 0.10)),
        "v_edge_read": zscore(np.exp(-s / 0.08) + np.exp(-(1.0 - s) / 0.12)),
        "v_kappa_boundary_weighted": zscore(kappa * (1.0 + np.exp(-s / 0.12))),
        "v_rho_curvature_proxy": zscore(-finite_difference(finite_difference(rho, s), s)),
    }

    rows = []
    for u_label, u in u_candidates.items():
        for v_label, v in v_candidates.items():
            alpha = float(np.dot(v, kappa) / (np.dot(v, v) + EPS))
            response_raw = u * alpha
            scale, response = fit_linear_scale(rho, response_raw)
            G = np.outer(u, v)
            row = {
                "u_candidate": u_label,
                "v_candidate": v_label,
                "projection_alpha": alpha,
                "scale_to_rho": scale,
                "corr": corrcoef(rho, response),
                "r2": r2_score(rho, response),
                "rmse": rmse(rho, response),
            }
            row.update(svd_rank_metrics(G, f"{u_label}__{v_label}"))
            rows.append(row)
    return pd.DataFrame(rows).sort_values(["r2", "corr"], ascending=False)


def make_figures(outdir: Path, s: np.ndarray, rho: np.ndarray, kappa: np.ndarray, kernel_table: pd.DataFrame, rank_table: pd.DataFrame) -> None:
    if not MATPLOTLIB_AVAILABLE:
        return

    # Probe/response overlay using the best nonlocal kernel.
    try:
        best_label = str(kernel_table.sort_values("r2", ascending=False).iloc[0]["kernel_label"])
        kernels = {
            "local_translation_exp_L_0p06": local_translation_kernel(s, 0.06),
            "local_translation_exp_L_0p15": local_translation_kernel(s, 0.15),
            "boundary_forced_green_like": boundary_forced_kernel(s),
            "position_dependent_diffusion": position_dependent_diffusion_kernel(s),
            "anisotropic_boundary_bulk": anisotropic_boundary_bulk_kernel(s),
        }
        G = kernels[best_label]
        _, pred = fit_linear_scale(rho, G @ kappa)
        plt.figure(figsize=(10, 5))
        plt.plot(s, rho, label="canonical rho")
        plt.plot(s, pred, label=f"best kernel response: {best_label}")
        plt.plot(s, zscore(kappa) * np.std(rho) + np.mean(rho), label="scaled source probe", alpha=0.6)
        plt.xlabel("s")
        plt.ylabel("profile value")
        plt.title("Stage-6S Probe Response Overlay")
        plt.legend()
        plt.tight_layout()
        plt.savefig(outdir / "stage6S_probe_response_overlay.png", dpi=160)
        plt.close()

        plt.figure(figsize=(7, 6))
        plt.imshow(G, origin="lower", aspect="auto", extent=[0, 1, 0, 1])
        plt.xlabel("source coordinate sigma")
        plt.ylabel("target coordinate s")
        plt.title(f"Stage-6S Kernel Heatmap: {best_label}")
        plt.colorbar(label="kernel weight")
        plt.tight_layout()
        plt.savefig(outdir / "stage6S_kernel_comparison.png", dpi=160)
        plt.close()
    except Exception as exc:
        print(f"[WARN] Could not create kernel figures: {exc}")

    try:
        rt = rank_table.copy()
        rt = rt.sort_values("energy_rank1", ascending=False)
        plt.figure(figsize=(10, 5))
        plt.bar(range(len(rt)), rt["energy_rank1"].to_numpy())
        plt.xticks(range(len(rt)), rt["source_probe"].astype(str).to_list(), rotation=45, ha="right")
        plt.ylim(0, 1.05)
        plt.ylabel("rank-1 energy fraction")
        plt.title("Stage-6S Rank-1 Energy by Source Probe")
        plt.tight_layout()
        plt.savefig(outdir / "stage6S_rank_energy_plot.png", dpi=160)
        plt.close()
    except Exception as exc:
        print(f"[WARN] Could not create rank figure: {exc}")


def build_summary(
    source_tests: pd.DataFrame,
    rank_stability: pd.DataFrame,
    family_amp: pd.DataFrame,
    kernel_tests: pd.DataFrame,
    rank1_tests: pd.DataFrame,
    notes: List[str],
) -> Dict[str, object]:
    best_source = source_tests.sort_values("r2_against_canonical_rho", ascending=False).iloc[0].to_dict()
    best_kernel = kernel_tests.sort_values("r2", ascending=False).iloc[0].to_dict()
    best_rank1 = rank1_tests.sort_values("r2", ascending=False).iloc[0].to_dict()

    low_rank_persistent = bool((rank_stability["energy_rank1"] > 0.99).mean() >= 0.75) if len(rank_stability) else False
    nonlocal_beats_local = False
    try:
        local_best = kernel_tests[kernel_tests["kernel_label"].str.contains("local_translation", na=False)]["r2"].max()
        nonlocal_best = kernel_tests[~kernel_tests["kernel_label"].str.contains("local_translation", na=False)]["r2"].max()
        nonlocal_beats_local = bool(nonlocal_best > local_best)
    except Exception:
        pass

    if nonlocal_beats_local and low_rank_persistent and best_rank1.get("r2", -999) > 0.70:
        verdict = "B_PROMISING_MECHANISM_STABILITY_LOW_RANK_NONLOCAL"
    elif nonlocal_beats_local and low_rank_persistent:
        verdict = "B_MINUS_LOW_RANK_STABLE_NONLOCAL_REVIEW_RANK1"
    elif nonlocal_beats_local:
        verdict = "C_REVIEW_REQUIRED_NONLOCAL_BETTER_BUT_RANK_UNSTABLE"
    else:
        verdict = "C_INCOMPLETE_OR_REVIEW_REQUIRED"

    return {
        "stage": "6S",
        "script": SCRIPT_NAME,
        "verdict": verdict,
        "discipline": {
            "canonical_rho_refit": False,
            "canonical_constants_modified": False,
            "physics_claims_made": False,
        },
        "best_source_probe": best_source,
        "best_kernel_candidate": best_kernel,
        "best_rank1_refined_test": best_rank1,
        "low_rank_persistent_across_source_probes": low_rank_persistent,
        "non_translation_invariant_beats_local_translation_kernel": nonlocal_beats_local,
        "family_amplitude_rows": int(len(family_amp)),
        "input_notes": notes,
        "physics_trigger_status": {
            "invariants_stabilized_across_perturbations": bool(best_source.get("r2_against_canonical_rho", -999) > 0.85),
            "operator_form_uniquely_identified": False,
            "recommend_introduce_PDG_spacetime_now": False,
            "reason": "Stage-6S can support Green/operator refinement, but PDG/spacetime interpretation should wait for unique operator identification.",
        },
    }


def write_notes(path: Path, summary: Dict[str, object]) -> None:
    lines = []
    lines.append("============================================================")
    lines.append("STAGE-6S INTERPRETATION NOTES")
    lines.append("Project: Quantum-Emergent Gravity")
    lines.append("============================================================")
    lines.append("")
    lines.append(f"Verdict: {summary['verdict']}")
    lines.append("")
    lines.append("What this stage tested:")
    lines.append("- source-probe perturbation stability")
    lines.append("- family-resolved amplitude projection where available")
    lines.append("- non-translation-invariant Green-like kernels")
    lines.append("- rank stability under induced operators")
    lines.append("- refined explicit rank-1 reconstruction")
    lines.append("")
    lines.append("Discipline:")
    lines.append("- canonical rho(s) was not refit")
    lines.append("- Stage-6Q constants were not modified")
    lines.append("- no cosmology or spacetime claim is made")
    lines.append("")
    lines.append("Best source probe:")
    lines.append(json.dumps(summary["best_source_probe"], indent=2, default=str))
    lines.append("")
    lines.append("Best kernel candidate:")
    lines.append(json.dumps(summary["best_kernel_candidate"], indent=2, default=str))
    lines.append("")
    lines.append("Best rank-1 refined test:")
    lines.append(json.dumps(summary["best_rank1_refined_test"], indent=2, default=str))
    lines.append("")
    lines.append("Physics trigger status:")
    lines.append(json.dumps(summary["physics_trigger_status"], indent=2, default=str))
    lines.append("")
    lines.append("Next recommended interpretation:")
    lines.append("If the non-translation-invariant kernels beat local kernels and the")
    lines.append("same low-rank modes persist under source perturbations, move toward")
    lines.append("Stage-6T: Physical Interpretation Layer. Until operator uniqueness")
    lines.append("is stronger, keep PDG/spacetime comparisons as logged review-only")
    lines.append("bookkeeping.")
    lines.append("============================================================")
    path.write_text("\n".join(lines), encoding="utf-8")


# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------


def main() -> int:
    banner("Stage-6S: Mechanism Stability & Operator Probes")
    root = find_project_root()
    outdir = ensure_dir(root / "metric_stage_6S_outputs")

    print(f"[Stage-6S] Python executable : {sys.executable}")
    print(f"[Stage-6S] Script name       : {SCRIPT_NAME}")
    print(f"[Stage-6S] Project root      : {root}")
    print(f"[Stage-6S] Output directory  : {outdir}")
    print("[Stage-6S] Rule              : probe stability only; no canonical refit; no physics claims.")

    data = load_canonical_data(root)
    for note in data.source_notes:
        print(f"[Stage-6S INPUT] {note}")

    s, rho, kappa = data.s, data.rho, data.kappa
    print(f"[Stage-6S] Grid size          : {len(s)}")
    print(f"[Stage-6S] rho norm/integral  : {np.linalg.norm(rho):.6g} / {np.trapz(rho, s):.6g}")
    print(f"[Stage-6S] kappa mean/std     : {np.mean(kappa):.6g} / {np.std(kappa):.6g}")

    banner("Task 1: Source perturbation tests")
    source_tests, induced_rank = source_perturbation_tests(s, rho, kappa)
    source_tests.to_csv(outdir / "stage6S_source_perturbation_tests.csv", index=False)
    print(source_tests.sort_values("r2_against_canonical_rho", ascending=False).head(8).to_string(index=False))

    banner("Task 2: Family-resolved amplitude analysis")
    family_amp = family_amplitude_analysis(s, rho, data.family_df)
    family_amp.to_csv(outdir / "stage6S_family_amplitude_analysis.csv", index=False)
    print(family_amp.head(12).to_string(index=False))

    banner("Task 3: Non-translation-invariant Green/kernel tests")
    kernel_tests = nonlocal_kernel_tests(s, rho, kappa)
    kernel_tests.to_csv(outdir / "stage6S_nonlocal_kernel_tests.csv", index=False)
    print(kernel_tests.sort_values("r2", ascending=False).to_string(index=False))

    banner("Task 4: Rank-stability analysis")
    # Combine induced probe-rank rows with kernel-rank rows into one table.
    kernel_rank_rows = []
    for _, row in kernel_tests.iterrows():
        kernel_rank_rows.append({
            "source_probe": "kernel_candidate",
            "operator_label": row["kernel_label"],
            "energy_rank1": row["energy_rank1"],
            "energy_rank2": row["energy_rank2"],
            "effective_rank": row["effective_rank"],
            "singular_gap_1_2": row["singular_gap_1_2"],
            "numerical_rank": row["numerical_rank"],
        })
    rank_stability = pd.concat([induced_rank, pd.DataFrame(kernel_rank_rows)], ignore_index=True, sort=False)
    rank_stability.to_csv(outdir / "stage6S_operator_rank_stability.csv", index=False)
    print(rank_stability.head(20).to_string(index=False))

    banner("Task 5: Explicit rank-1 reconstruction, refined")
    rank1_tests = rank1_refined_tests(s, rho, kappa)
    rank1_tests.to_csv(outdir / "stage6S_rank1_refined_tests.csv", index=False)
    print(rank1_tests.head(10).to_string(index=False))

    summary = build_summary(source_tests, rank_stability, family_amp, kernel_tests, rank1_tests, data.source_notes)
    with (outdir / "stage6S_operator_summary.json").open("w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, default=str)
    write_notes(outdir / "stage6S_interpretation_notes.txt", summary)

    make_figures(outdir, s, rho, kappa, kernel_tests, induced_rank)

    banner("Stage-6S complete")
    print(f"[Stage-6S] Verdict: {summary['verdict']}")
    print("[Stage-6S] Required outputs written:")
    for name in [
        "stage6S_source_perturbation_tests.csv",
        "stage6S_operator_rank_stability.csv",
        "stage6S_family_amplitude_analysis.csv",
        "stage6S_nonlocal_kernel_tests.csv",
        "stage6S_rank1_refined_tests.csv",
        "stage6S_operator_summary.json",
        "stage6S_interpretation_notes.txt",
    ]:
        print(f"  - {outdir / name}")
    if MATPLOTLIB_AVAILABLE:
        print("[Stage-6S] Optional figures attempted.")
    print("[Stage-6S] Physics trigger: NOT YET unless operator uniqueness is confirmed downstream.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
