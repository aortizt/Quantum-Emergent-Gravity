#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
===============================================================================
Stage-6Yi_publication_hardening_cross_evidence_audit_v1a.py
Project: Quantum-Emergent Gravity
Stage: 6Yi v1a corrective hardening
Working title: Strict Publication-Hardening Panel Correction
Author: Arturo Ortiz-Tapia / QEG pipeline support
Build date: 2026-05-25
Python target: /home/dakini/python_envs/python3.11/bin/python3.11
===============================================================================

PURPOSE
-------
Corrective v1a script for Stage-6Yi. This is NOT a new scientific stage and NOT
an expanded null suite. It reads the already-produced Stage-6Yi v1 outputs and
rebuilds the publication-facing scoring panels with stricter rules.

The correction target is surgical:

1) Add a strict scored cosmology panel that excludes unknown comparators and
   rows without external values.
2) Preserve all raw v1 cosmology rows, but mark unscored rows explicitly.
3) Tier the Omega_K / curvature panel into:
      TIER_1_EXPLICIT_OMEGAK_OR_CURVATURE
      TIER_2_PRINCIPLED_CURVATURE_PROXY
      TIER_3_EXPLORATORY_HEURISTIC_UNSCORED
4) Replace raw-only evidence-axis support counts with raw + qualified counts.
5) Rebuild multiplicity and discrepancy audits using canonical comparator and
   trust-tier discipline, while preserving all rows for transparency.

NON-NEGOTIABLE RULES
--------------------
No fitting to Omega_m.
No optimization against cosmological constants.
No new broad null suite.
No Stage-6Yf reopening.
No row-index family assignment.
No physical identification claim.
No hiding feature multiplicity.

INPUT DIRECTORY
---------------
metric_stage_6Yi_outputs/      (Stage-6Yi v1 outputs)

OUTPUT DIRECTORY
----------------
metric_stage_6Yi_v1a_outputs/  (corrected v1a outputs)
===============================================================================
"""

from __future__ import annotations

import json
import math
import os
import shutil
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd


# =============================================================================
# Configuration
# =============================================================================

PROJECT_ROOT = Path(os.environ.get(
    "QEG_PROJECT_ROOT",
    "/home/dakini/Downloads/010-Quantum_Emergent_Gravity"
)).expanduser()

V1_DIR = Path(os.environ.get(
    "QEG_STAGE6YI_V1_DIR",
    str(PROJECT_ROOT / "metric_stage_6Yi_outputs")
)).expanduser()

OUTPUT_DIR = Path(os.environ.get(
    "QEG_STAGE6YI_V1A_DIR",
    str(PROJECT_ROOT / "metric_stage_6Yi_v1a_outputs")
)).expanduser()

SCRIPT_NAME = Path(__file__).name
RUN_UTC = datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")

CANONICAL_BENCHMARKS: Dict[str, Dict[str, Any]] = {
    "Omega_m": {"value": 0.315, "sigma": 0.007, "kind": "density_sector"},
    "Omega_b": {"value": 0.0493, "sigma": 0.0006, "kind": "density_sector"},
    "Omega_c": {"value": 0.265, "sigma": 0.007, "kind": "density_sector"},
    "Omega_Lambda": {"value": 0.685, "sigma": 0.007, "kind": "density_sector"},
    "sigma8": {"value": 0.811, "sigma": 0.006, "kind": "structure_amplitude"},
    "S8": {"value": 0.832, "sigma": 0.013, "kind": "structure_amplitude"},
    "Omega_K": {"value": 0.0007, "sigma": 0.0019, "kind": "near_zero_curvature"},
    "Lambda": {"value": 1.088e-56, "sigma": 0.030e-56, "kind": "vacuum_sector"},
    "rho_Lambda": {"value": 5.83e-30, "sigma": 0.16e-30, "kind": "vacuum_sector"},
}
CANONICAL_BENCHMARKS["Omega_b/Omega_m"] = {
    "value": CANONICAL_BENCHMARKS["Omega_b"]["value"] / CANONICAL_BENCHMARKS["Omega_m"]["value"],
    "sigma": None,
    "kind": "derived_ratio",
}
CANONICAL_BENCHMARKS["Omega_c/Omega_m"] = {
    "value": CANONICAL_BENCHMARKS["Omega_c"]["value"] / CANONICAL_BENCHMARKS["Omega_m"]["value"],
    "sigma": None,
    "kind": "derived_ratio",
}
CANONICAL_BENCHMARKS["Omega_m/Omega_Lambda"] = {
    "value": CANONICAL_BENCHMARKS["Omega_m"]["value"] / CANONICAL_BENCHMARKS["Omega_Lambda"]["value"],
    "sigma": None,
    "kind": "derived_ratio",
}

CANONICAL_COMPARATORS = set(CANONICAL_BENCHMARKS)

# Canonical trust ordering for discrepancy candidates.
TRUST_TIER_LABELS = {
    1: "TIER_1_FROZEN_PRINCIPLED_PRIMARY_CORRECTED",
    2: "TIER_2_HISTORICAL_AMBIGUITY_PERIOD_NOT_PRIMARY",
    3: "TIER_3_KNOWN_PRIOR_OR_HANDOFF_BENCHMARK",
    4: "TIER_4_EXTRACTED_REVIEW_NEEDED",
    5: "TIER_5_EXPLORATORY_AGGREGATE_PRE_REGISTRATION_NEEDED",
    9: "TIER_9_UNSCORED_OR_NONCANONICAL",
}

AXIS_RULES: Dict[str, Dict[str, List[str]]] = {
    "lineage_provenance": {
        "required_any": ["stage4", "stage-4", "stage5", "stage-5", "stage6d", "stage-6d", "stage6o", "stage-6o", "stage6p", "stage-6p", "provenance", "lineage", "family"],
        "preferred_any": ["bari", "nufit", "valencia", "fit_id", "stage-4a", "stage4a", "stage-5a", "stage5a"],
    },
    "canonical_two_lobe_universality": {
        "required_any": ["stage6m", "stage-6m", "stage6n", "stage-6n", "stage6o", "stage-6o", "stage6p", "stage-6p", "stage6q", "stage-6q", "two_lobe", "two-lobe", "canonical"],
        "preferred_any": ["mu_early", "mu_central", "two_lobe", "two-lobe", "canonical", "family_universality", "v6"],
    },
    "operator_nonlocal_lowrank": {
        "required_any": ["stage6j", "stage-6j", "stage6k", "stage-6k", "stage6l", "stage-6l", "stage6r", "stage-6r", "stage6s", "stage-6s", "stage6t", "stage-6t", "stage6x", "stage-6x", "operator", "kernel", "lowrank", "low-rank"],
        "preferred_any": ["nonlocal", "kernel", "operator", "rank", "green", "toeplitz", "source_response"],
    },
    "recursive_transport_stability": {
        "required_any": ["stage6y", "stage-6y", "stage6ya", "stage6yb", "stage6yc", "stage6yd", "stage6ye", "stage6yf", "stage6yg", "recursive", "recursion", "transport"],
        "preferred_any": ["recursive", "transport", "attractor", "lowk", "low-k", "null", "branch"],
    },
    "null_repair_hardening": {
        "required_any": ["stage6yf", "stage-6yf", "stage6yg", "stage-6yg", "stage6yh", "stage-6yh", "repair", "repaired", "lowk", "low-k", "column_locked", "column-locked"],
        "preferred_any": ["repaired", "lowk", "low-k", "alias", "unique_vector", "column_locked", "corridor", "caveat"],
    },
    "cosmology_bookkeeping": {
        "required_any": ["cosmology", "omega", "benchmark", "stage6yh", "stage-6yh", "stage6yi", "stage-6yi"],
        "preferred_any": ["omega_m", "omega_k", "omega_lambda", "sigma8", "s8", "benchmark", "bookkeeping"],
    },
    "information_geometry": {
        "required_any": ["information", "fisher", "kl", "kullback", "divergence", "ncd", "geometry"],
        "preferred_any": ["information_geometry", "information-geometry", "fisher", "kl", "kullback", "divergence", "entropy"],
    },
    "publication_readiness": {
        "required_any": ["publication", "physica", "manuscript", "readiness", "stage6yi", "stage-6yi", "figure", "table", "claim"],
        "preferred_any": ["publication", "physica", "manuscript", "readiness", "claims", "figure", "table"],
    },
}

RAW_V1_FILES = [
    "stage6Yi_cosmology_benchmark_panel.csv",
    "stage6Yi_curvature_benchmark_panel.csv",
    "stage6Yi_feature_multiplicity_audit.csv",
    "stage6Yi_discrepancy_reduction_candidates.csv",
    "stage6Yi_evidence_axis_inventory.csv",
    "stage6Yi_axis_strength_scorecard.csv",
    "stage6Yi_prior_stage_locator.csv",
    "stage6Yi_omega_m_discrepancy_audit.csv",
    "stage6Yi_publication_claims_matrix.csv",
    "stage6Yi_physicaD_readiness_panel.csv",
    "stage6Yi_summary.json",
    "Stage-6Yi_publication_hardening_notes.txt",
]


# =============================================================================
# Utility functions
# =============================================================================

def echo(msg: str = "") -> None:
    print(msg, flush=True)


def banner(title: str) -> None:
    echo("\n" + "=" * 79)
    echo(title)
    echo("=" * 79)


def section(title: str) -> None:
    echo("\n" + "-" * 79)
    echo(title)
    echo("-" * 79)


def rel_pct(q: Optional[float], e: Optional[float]) -> Optional[float]:
    if q is None or e is None or not math.isfinite(q) or not math.isfinite(e) or abs(e) < 1e-15:
        return None
    return abs(q - e) / abs(e) * 100.0


def as_float(x: Any) -> Optional[float]:
    if x is None:
        return None
    if isinstance(x, (int, float, np.number)):
        v = float(x)
        return v if math.isfinite(v) else None
    s = str(x).strip().replace("%", "").replace(",", "")
    if not s or s.lower() in {"nan", "none", "null", "na"}:
        return None
    try:
        v = float(s)
        return v if math.isfinite(v) else None
    except Exception:
        return None


def boolish(x: Any) -> bool:
    if isinstance(x, bool):
        return x
    return str(x).strip().lower() in {"true", "1", "yes", "y"}


def score_class(pct: Optional[float]) -> str:
    if pct is None:
        return "not_scored"
    if pct <= 1.0:
        return "within_1_percent"
    if pct <= 5.0:
        return "within_5_percent"
    if pct <= 10.0:
        return "within_10_percent"
    return "outside_10_percent"


def safe_read_csv(path: Path, required: bool = True) -> pd.DataFrame:
    if not path.exists():
        if required:
            raise FileNotFoundError(f"Required input missing: {path}")
        return pd.DataFrame()
    try:
        return pd.read_csv(path)
    except UnicodeDecodeError:
        return pd.read_csv(path, encoding="latin-1")


def safe_read_json(path: Path, required: bool = False) -> Dict[str, Any]:
    if not path.exists():
        if required:
            raise FileNotFoundError(f"Required input missing: {path}")
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def write_csv(name: str, df: pd.DataFrame) -> None:
    df.to_csv(OUTPUT_DIR / name, index=False)


def write_json(name: str, obj: Dict[str, Any]) -> None:
    (OUTPUT_DIR / name).write_text(json.dumps(obj, indent=2, sort_keys=True, default=str), encoding="utf-8")


def copy_raw_inputs() -> List[Dict[str, Any]]:
    archive = OUTPUT_DIR / "raw_v1_snapshot"
    archive.mkdir(parents=True, exist_ok=True)
    rows = []
    for name in RAW_V1_FILES:
        src = V1_DIR / name
        record = {
            "file": name,
            "source_path": src.as_posix(),
            "archived_path": "",
            "exists": src.exists(),
            "size_bytes": src.stat().st_size if src.exists() else None,
        }
        if src.exists():
            dst = archive / name
            shutil.copy2(src, dst)
            record["archived_path"] = dst.as_posix()
        rows.append(record)
    return rows


def recompute_canonical_relative(row: pd.Series) -> Tuple[Optional[float], Optional[float]]:
    comp = str(row.get("external_comparator", "")).strip()
    q = as_float(row.get("qeg_value"))
    external = as_float(row.get("external_value"))
    if comp in CANONICAL_BENCHMARKS:
        external = CANONICAL_BENCHMARKS[comp]["value"]
    return external, rel_pct(q, external)


# =============================================================================
# Strict cosmology and multiplicity
# =============================================================================

def strict_cosmology_panel(raw: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    df = raw.copy()
    if df.empty:
        return df, df

    strict_cols = []
    for _, row in df.iterrows():
        comp = str(row.get("external_comparator", "")).strip()
        q = as_float(row.get("qeg_value"))
        external, pct = recompute_canonical_relative(row)
        canonical = comp in CANONICAL_COMPARATORS
        has_external = external is not None
        has_qeg = q is not None
        eligible = canonical and has_external and has_qeg and pct is not None

        reasons = []
        if not canonical:
            reasons.append("noncanonical_or_unknown_comparator")
        if not has_external:
            reasons.append("missing_external_value")
        if not has_qeg:
            reasons.append("missing_qeg_value")
        if pct is None:
            reasons.append("relative_difference_unscorable")

        strict_cols.append({
            "canonical_comparator": comp if canonical else "",
            "canonical_external_value": external,
            "strict_relative_difference_percent": pct,
            "strict_score_class": score_class(pct) if eligible else "unscored",
            "strict_score_eligible": bool(eligible),
            "strict_exclusion_reason": ";".join(reasons) if reasons else "strict_scored",
            "strict_interpretation_status": (
                "strict_canonical_benchmark_bookkeeping_only" if eligible else
                "raw_v1_row_preserved_unscored"
            ),
        })

    out = pd.concat([df.reset_index(drop=True), pd.DataFrame(strict_cols)], axis=1)
    scored = out[out["strict_score_eligible"] == True].copy()
    scored = scored.sort_values(
        by=["external_comparator", "strict_relative_difference_percent", "source_kind", "qeg_feature"],
        na_position="last",
    ).reset_index(drop=True)
    return out, scored


def strict_multiplicity(strict_panel: pd.DataFrame) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    if strict_panel.empty:
        return pd.DataFrame(rows)

    for comp, sub in strict_panel.groupby("external_comparator", dropna=False):
        sub_all = sub.copy()
        sub_scored = sub_all[sub_all["strict_score_eligible"] == True].copy()
        sub_scored = sub_scored.sort_values("strict_relative_difference_percent", na_position="last")
        best = sub_scored.iloc[0].to_dict() if not sub_scored.empty else {}
        rows.append({
            "external_comparator": comp,
            "canonical_scored": comp in CANONICAL_COMPARATORS,
            "raw_rows_preserved": len(sub_all),
            "strict_scored_rows": len(sub_scored),
            "strict_unscored_rows": len(sub_all) - len(sub_scored),
            "within_1_percent_count": int((sub_scored["strict_relative_difference_percent"] <= 1.0).sum()) if not sub_scored.empty else 0,
            "within_5_percent_count": int((sub_scored["strict_relative_difference_percent"] <= 5.0).sum()) if not sub_scored.empty else 0,
            "within_10_percent_count": int((sub_scored["strict_relative_difference_percent"] <= 10.0).sum()) if not sub_scored.empty else 0,
            "best_qeg_feature": best.get("qeg_feature", ""),
            "best_qeg_value": best.get("qeg_value", ""),
            "best_strict_relative_difference_percent": best.get("strict_relative_difference_percent", ""),
            "best_source_kind": best.get("source_kind", ""),
            "best_source_file": best.get("source_file", ""),
            "multiplicity_status": (
                "strict_canonical_multiplicity_logged" if comp in CANONICAL_COMPARATORS else
                "noncanonical_rows_preserved_unscored"
            ),
        })

    scored_all = strict_panel[strict_panel["strict_score_eligible"] == True].copy()
    best_all = {}
    if not scored_all.empty:
        scored_all = scored_all.sort_values("strict_relative_difference_percent", na_position="last")
        best_all = scored_all.iloc[0].to_dict()
    rows.append({
        "external_comparator": "ALL_CANONICAL_COMPARATORS_STRICT",
        "canonical_scored": True,
        "raw_rows_preserved": len(strict_panel),
        "strict_scored_rows": len(scored_all),
        "strict_unscored_rows": len(strict_panel) - len(scored_all),
        "within_1_percent_count": int((scored_all["strict_relative_difference_percent"] <= 1.0).sum()) if not scored_all.empty else 0,
        "within_5_percent_count": int((scored_all["strict_relative_difference_percent"] <= 5.0).sum()) if not scored_all.empty else 0,
        "within_10_percent_count": int((scored_all["strict_relative_difference_percent"] <= 10.0).sum()) if not scored_all.empty else 0,
        "best_qeg_feature": best_all.get("qeg_feature", ""),
        "best_qeg_value": best_all.get("qeg_value", ""),
        "best_strict_relative_difference_percent": best_all.get("strict_relative_difference_percent", ""),
        "best_source_kind": best_all.get("source_kind", ""),
        "best_source_file": best_all.get("source_file", ""),
        "multiplicity_status": "global_strict_canonical_transparency_row_not_a_claim",
    })
    return pd.DataFrame(rows)


# =============================================================================
# Curvature tiers
# =============================================================================

def classify_curvature_tier(row: pd.Series) -> Dict[str, Any]:
    feature = str(row.get("qeg_feature", "")).lower()
    source = str(row.get("source_file", "")).lower()
    source_kind = str(row.get("source_kind", "")).lower()
    notes = str(row.get("notes", "")).lower()

    explicit_markers = ["explicit_omegak", "omega_k", "omegak"]
    principled_markers = ["kappa", "curvature", "flatness", "ricci", "sector_curvature"]
    exploratory_markers = [
        "residual", "signed_min_abs_value", ".min", ".max", "drift", "imbalance",
        "asymmetry", "median", "mean_abs", "candidate curvature-like statistic",
    ]

    if "explicit_omegak_or_curvature_row" in str(row.get("feature_type", "")).lower():
        tier = 1
        label = "TIER_1_EXPLICIT_OMEGAK_OR_CURVATURE"
        eligible = True
        reason = "explicit_OmegaK_or_curvature_row_from_v1_panel"
    elif any(m in feature or m in source for m in explicit_markers):
        tier = 1
        label = "TIER_1_EXPLICIT_OMEGAK_OR_CURVATURE"
        eligible = True
        reason = "explicit_OmegaK_marker"
    elif any(m in feature or m in source for m in principled_markers) and not any(m in feature or m in notes for m in exploratory_markers):
        tier = 2
        label = "TIER_2_PRINCIPLED_CURVATURE_PROXY"
        eligible = True
        reason = "principled_curvature_or_kappa_proxy"
    elif any(m in feature or m in source for m in principled_markers):
        tier = 2
        label = "TIER_2_PRINCIPLED_CURVATURE_PROXY_REVIEW"
        eligible = True
        reason = "curvature_or_kappa_proxy_but_summary_statistic_review"
    else:
        tier = 3
        label = "TIER_3_EXPLORATORY_HEURISTIC_UNSCORED"
        eligible = False
        reason = "heuristic_column_statistic_not_publication_scored"

    # Residual and signed-min-abs rows are useful diagnostics but too post-hoc for
    # publication scoring, unless explicitly marked Omega_K upstream.
    if tier != 1 and any(m in feature or m in notes for m in ["residual", "signed_min_abs_value"]):
        tier = 3
        label = "TIER_3_EXPLORATORY_HEURISTIC_UNSCORED"
        eligible = False
        reason = "residual_or_signed_min_abs_value_is_exploratory_unscored"

    return {
        "curvature_tier_num": tier,
        "curvature_tier": label,
        "curvature_strict_score_eligible": bool(eligible),
        "curvature_tier_reason": reason,
    }


def tiered_curvature_panel(raw: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    if raw.empty:
        return raw, raw
    tiers = pd.DataFrame([classify_curvature_tier(row) for _, row in raw.iterrows()])
    out = pd.concat([raw.reset_index(drop=True), tiers], axis=1)
    # Near-zero curvature: absolute error/window remains the primary score. Tier 3 is preserved but unscored.
    principled = out[out["curvature_strict_score_eligible"] == True].copy()
    sort_col = "absolute_error_to_Omega_K" if "absolute_error_to_Omega_K" in principled.columns else None
    if sort_col:
        principled = principled.sort_values(["curvature_tier_num", sort_col], na_position="last")
    else:
        principled = principled.sort_values(["curvature_tier_num"], na_position="last")
    return out, principled.reset_index(drop=True)


def curvature_multiplicity(tiered: pd.DataFrame) -> pd.DataFrame:
    if tiered.empty:
        return pd.DataFrame()
    rows = []
    for tier, sub in tiered.groupby("curvature_tier", dropna=False):
        eligible = sub[sub["curvature_strict_score_eligible"] == True]
        rows.append({
            "curvature_tier": tier,
            "raw_rows_preserved": len(sub),
            "strict_scored_rows": len(eligible),
            "unscored_rows": len(sub) - len(eligible),
            "within_1sigma_count": int(eligible.get("within_1sigma_window", pd.Series(dtype=bool)).fillna(False).astype(bool).sum()) if not eligible.empty else 0,
            "within_2sigma_count": int(eligible.get("within_2sigma_window", pd.Series(dtype=bool)).fillna(False).astype(bool).sum()) if not eligible.empty else 0,
            "best_absolute_error_to_OmegaK": as_float(eligible.get("absolute_error_to_Omega_K", pd.Series([np.nan])).min()) if not eligible.empty else None,
            "status": "publication_scored_tier" if not eligible.empty else "preserved_unscored_tier",
        })
    rows.append({
        "curvature_tier": "ALL_TIERS",
        "raw_rows_preserved": len(tiered),
        "strict_scored_rows": int((tiered["curvature_strict_score_eligible"] == True).sum()),
        "unscored_rows": int((tiered["curvature_strict_score_eligible"] != True).sum()),
        "within_1sigma_count": int(tiered.loc[tiered["curvature_strict_score_eligible"] == True, "within_1sigma_window"].fillna(False).astype(bool).sum()) if "within_1sigma_window" in tiered else 0,
        "within_2sigma_count": int(tiered.loc[tiered["curvature_strict_score_eligible"] == True, "within_2sigma_window"].fillna(False).astype(bool).sum()) if "within_2sigma_window" in tiered else 0,
        "best_absolute_error_to_OmegaK": as_float(tiered.loc[tiered["curvature_strict_score_eligible"] == True, "absolute_error_to_Omega_K"].min()) if "absolute_error_to_Omega_K" in tiered else None,
        "status": "global_curvature_tier_transparency_row",
    })
    return pd.DataFrame(rows)


# =============================================================================
# Evidence-axis qualification
# =============================================================================

def contains_any(text: str, pats: Iterable[str]) -> bool:
    low = text.lower()
    return any(p.lower() in low for p in pats)


def qualify_axis_file(axis: str, row: pd.Series) -> Tuple[bool, str]:
    matched_axes = str(row.get("matched_axes", ""))
    if axis not in matched_axes.split(";"):
        return False, "axis_not_in_raw_matched_axes"

    file_text = str(row.get("file", "")).lower()
    theme_text = str(row.get("matched_themes", "")).lower()
    verdict_text = str(row.get("verdict_or_status", "")).lower()
    hay = "\n".join([file_text, theme_text, verdict_text])
    rules = AXIS_RULES.get(axis, {"required_any": [], "preferred_any": []})

    required = contains_any(hay, rules.get("required_any", []))
    preferred = contains_any(hay, rules.get("preferred_any", []))

    # Strong evidence packages and transition packages can qualify when axis terms
    # appear in theme/verdict even if the file name is generic.
    evidence_package = "__qeg_evidence__" in file_text or "transition package" in file_text
    stage6_file = "stage6" in file_text or "stage-6" in file_text or "metric_stage_6" in file_text

    if required and preferred:
        return True, "required_and_preferred_axis_terms_present"
    if required and stage6_file:
        return True, "required_axis_terms_in_stage6_file"
    if preferred and evidence_package:
        return True, "preferred_terms_in_evidence_package"

    return False, "raw_keyword_hit_not_qualified"


def qualified_evidence_axes(raw_inv: pd.DataFrame, raw_score: pd.DataFrame, locator: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    rows = []
    score_rows = []
    axes = list(raw_inv["axis"]) if "axis" in raw_inv.columns else list(AXIS_RULES)

    for axis in axes:
        raw_count = 0
        qualified_records = []
        if not locator.empty:
            for _, loc_row in locator.iterrows():
                matched_axes = str(loc_row.get("matched_axes", "")).split(";")
                if axis in matched_axes:
                    raw_count += 1
                ok, reason = qualify_axis_file(axis, loc_row)
                if ok:
                    d = loc_row.to_dict()
                    d["qualification_reason"] = reason
                    qualified_records.append(d)

        q_count = len(qualified_records)
        top_files = ";".join(str(r.get("file", "")) for r in qualified_records[:8])
        raw_row = raw_inv[raw_inv["axis"] == axis].iloc[0].to_dict() if not raw_inv.empty and (raw_inv["axis"] == axis).any() else {}
        rows.append({
            "axis": axis,
            "raw_status_v1": raw_row.get("status", ""),
            "raw_supporting_file_count_v1": raw_row.get("supporting_file_count", raw_count),
            "qualified_supporting_file_count_v1a": q_count,
            "qualification_status_v1a": "QUALIFIED_FOUND" if q_count > 0 else "RAW_ONLY_REVIEW",
            "qualified_supporting_files": top_files,
            "paper_role": raw_row.get("paper_role", ""),
            "known_caveat": raw_row.get("known_caveat", ""),
            "qualification_rule": "requires axis-specific stage/theme relevance, not mere keyword hit",
        })

        # Conservative score: q_count, plus known project status. Keep operator/recursive caveats capped.
        if q_count >= 8:
            q_score = 3
        elif q_count >= 3:
            q_score = 2
        elif q_count >= 1:
            q_score = 1
        else:
            q_score = 0
        if axis in {"operator_nonlocal_lowrank", "recursive_transport_stability", "cosmology_bookkeeping"}:
            q_score = min(q_score, 2)
        if axis == "publication_readiness" and q_score >= 1:
            q_score = min(3, q_score + 1)
        if axis == "null_repair_hardening" and q_score >= 1:
            q_score = max(q_score, 2)

        strength = (
            "STRONG_QUALIFIED" if q_score >= 3 else
            "MODERATE_WITH_CAVEAT_QUALIFIED" if q_score == 2 else
            "PRESENT_REVIEW_QUALIFIED" if q_score == 1 else
            "RAW_KEYWORD_ONLY_OR_MISSING"
        )
        score_rows.append({
            "axis": axis,
            "raw_supporting_file_count_v1": raw_row.get("supporting_file_count", raw_count),
            "qualified_supporting_file_count_v1a": q_count,
            "qualified_numeric_strength_score_0_to_3": q_score,
            "qualified_strength_class_v1a": strength,
            "recommended_manuscript_role_v1a": raw_row.get("paper_role", "") if q_score > 0 else "Do not use without direct source citation.",
            "principal_caveat": raw_row.get("known_caveat", ""),
        })
    return pd.DataFrame(rows), pd.DataFrame(score_rows)


# =============================================================================
# Discrepancy trust-tier ranking and Omega_m audit
# =============================================================================

def discrepancy_tier(row: pd.Series) -> Tuple[int, str, bool, str]:
    status = str(row.get("candidate_status", "")).lower()
    source = str(row.get("source_file", "")).lower()
    feature = str(row.get("candidate_feature", "")).lower()
    comp = str(row.get("compared_to", "")).strip()
    q = as_float(row.get("candidate_value"))
    ext = as_float(row.get("external_value"))

    canonical = comp in CANONICAL_COMPARATORS
    has_values = q is not None and ext is not None

    if "frozen_principled_primary_corrected" in status:
        tier = 1
        reason = "primary corrected column-locked value"
    elif "historical_ambiguity" in status:
        tier = 2
        reason = "historical ambiguity-period value retained but downgraded"
    elif "stage-6yi_authorization_handoff" in source or "known_prior" in status or feature in {
        "bulk_fraction_0_20_to_0_80", "central_mass_fraction"
    }:
        tier = 3
        reason = "known prior or handoff benchmark row"
    elif "derived_or_extracted" in status:
        tier = 4
        reason = "extracted review-needed row"
    elif "pre_registration" in status or "derived_but_needs" in status:
        tier = 5
        reason = "exploratory aggregate statistic requires pre-registration"
    else:
        tier = 9
        reason = "unrecognized or unscored candidate status"

    scored = canonical and has_values and tier < 9
    if not canonical:
        reason += "; noncanonical comparator"
    if not has_values:
        reason += "; missing candidate/external value"
    return tier, TRUST_TIER_LABELS[tier], scored, reason


def ranked_discrepancy_candidates(raw: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    if raw.empty:
        return raw, raw
    rows = []
    for _, row in raw.iterrows():
        tier_num, tier_label, scored, reason = discrepancy_tier(row)
        pct = as_float(row.get("relative_difference_percent"))
        rows.append({
            "trust_tier_num": tier_num,
            "trust_tier": tier_label,
            "strict_candidate_scored": scored,
            "trust_tier_reason": reason,
            "strict_score_class": score_class(pct) if scored else "unscored",
        })
    out = pd.concat([raw.reset_index(drop=True), pd.DataFrame(rows)], axis=1)
    out = out.sort_values(
        by=["trust_tier_num", "relative_difference_percent", "source_file", "candidate_feature"],
        na_position="last",
    ).reset_index(drop=True)
    scored = out[out["strict_candidate_scored"] == True].copy()
    return out, scored.reset_index(drop=True)


def strict_omega_m_audit(strict_panel: pd.DataFrame, ranked_candidates: pd.DataFrame) -> pd.DataFrame:
    rows = []
    omega_panel = strict_panel[
        (strict_panel.get("external_comparator", pd.Series(dtype=str)).astype(str) == "Omega_m") &
        (strict_panel.get("strict_score_eligible", pd.Series(dtype=bool)) == True)
    ].copy()
    if not omega_panel.empty:
        omega_panel = omega_panel.sort_values("strict_relative_difference_percent", na_position="last")
        for rank, (_, r) in enumerate(omega_panel.iterrows(), 1):
            rows.append({
                "audit_rank": rank,
                "audit_source": "strict_cosmology_panel",
                "source_file": r.get("source_file", ""),
                "qeg_feature": r.get("qeg_feature", ""),
                "qeg_value": r.get("qeg_value", ""),
                "external_value": r.get("canonical_external_value", ""),
                "strict_relative_difference_percent": r.get("strict_relative_difference_percent", ""),
                "trust_status": r.get("interpretation_status", ""),
                "v1a_status": (
                    "primary_corrected_if_global_mu_column_locked" if str(r.get("source_kind", "")) == "corrected_column_locked" else
                    "historical_downgraded_if_ambiguity_period" if str(r.get("source_kind", "")) == "historical_ambiguity_period" else
                    "strict_scored_but_review_for_pre_registration"
                ),
                "manuscript_use": "Only use with multiplicity disclosure and upstream freezing status.",
            })

    # Ensure two contract rows are always explicit, even if raw v1 panel changes.
    contract_rows = [
        ("historical_ambiguity_period", "early_central_separation", 0.317696, 0.315,
         "downgraded_historical_bookkeeping", "Stage-6Yh v1 was not column-locked."),
        ("corrected_column_locked", "global_mu", 0.327995, 0.315,
         "primary_corrected_benchmark", "Stage-6Yh v1a column-locked value; below 5%, not below 1%."),
    ]
    prepend = []
    for source_kind, feat, q, ext, status, explanation in contract_rows:
        prepend.append({
            "audit_rank": 0 if source_kind == "corrected_column_locked" else -1,
            "audit_source": "contract_anchor",
            "source_file": "Stage-6Yi_authorization_handoff",
            "qeg_feature": feat,
            "qeg_value": q,
            "external_value": ext,
            "strict_relative_difference_percent": rel_pct(q, ext),
            "trust_status": status,
            "v1a_status": status,
            "manuscript_use": explanation,
        })
    out = pd.DataFrame(prepend + rows)
    out = out.sort_values(["audit_rank", "strict_relative_difference_percent"], na_position="last").reset_index(drop=True)
    return out


# =============================================================================
# Notes, readiness, summary
# =============================================================================

def make_summary(
    v1_summary: Dict[str, Any],
    raw_cosmo: pd.DataFrame,
    strict_cosmo: pd.DataFrame,
    strict_scored: pd.DataFrame,
    strict_mult: pd.DataFrame,
    raw_curv: pd.DataFrame,
    tiered_curv: pd.DataFrame,
    principled_curv: pd.DataFrame,
    qualified_score: pd.DataFrame,
    ranked_candidates: pd.DataFrame,
) -> Dict[str, Any]:
    global_mult = strict_mult[strict_mult["external_comparator"] == "ALL_CANONICAL_COMPARATORS_STRICT"]
    gm = global_mult.iloc[0].to_dict() if not global_mult.empty else {}

    qualified_core = {
        r["axis"]: int(r["qualified_numeric_strength_score_0_to_3"])
        for _, r in qualified_score.iterrows()
    } if not qualified_score.empty else {}

    # The corrective task is successful if strict panels were generated and core axes still survive qualification.
    core_ok = (
        qualified_core.get("lineage_provenance", 0) >= 1 and
        qualified_core.get("canonical_two_lobe_universality", 0) >= 1 and
        qualified_core.get("null_repair_hardening", 0) >= 1
    )
    strict_ok = len(strict_scored) > 0 and len(strict_cosmo) == len(raw_cosmo)
    curv_ok = len(tiered_curv) == len(raw_curv)

    if core_ok and strict_ok and curv_ok:
        verdict = "A_MINUS_PUBLICATION_HARDENING_READY_AFTER_STRICT_MULTIPLICITY_AND_TIERING"
        recommendation = "Stage-6Yi final ledger, then Stage-6Yj manuscript-axis synthesis / figure-table freeze"
    elif strict_ok and curv_ok:
        verdict = "B_PLUS_CORRECTIVE_PANELS_READY_CORE_AXIS_QUALIFICATION_REVIEW"
        recommendation = "Review qualified axis support before Stage-6Yj"
    else:
        verdict = "C_REVIEW_REQUIRED_V1A_STRICT_PANEL_INCOMPLETE"
        recommendation = "Repair v1a panel generation before ledgering Stage-6Yi"

    return {
        "stage": "6Yi",
        "script_name": SCRIPT_NAME,
        "run_utc": RUN_UTC,
        "project_root": PROJECT_ROOT.as_posix(),
        "v1_input_dir": V1_DIR.as_posix(),
        "output_dir": OUTPUT_DIR.as_posix(),
        "v1_verdict": v1_summary.get("verdict", ""),
        "v1a_verdict": verdict,
        "raw_v1_cosmology_rows_preserved": int(len(raw_cosmo)),
        "strict_canonical_cosmology_rows_scored": int(len(strict_scored)),
        "strict_canonical_cosmology_rows_unscored": int(len(strict_cosmo) - len(strict_scored)),
        "strict_within_1_percent_count": int(gm.get("within_1_percent_count", 0) or 0),
        "strict_within_5_percent_count": int(gm.get("within_5_percent_count", 0) or 0),
        "strict_within_10_percent_count": int(gm.get("within_10_percent_count", 0) or 0),
        "raw_v1_curvature_rows_preserved": int(len(raw_curv)),
        "principled_curvature_rows_scored": int(len(principled_curv)),
        "exploratory_curvature_rows_preserved_unscored": int((tiered_curv.get("curvature_strict_score_eligible", pd.Series(dtype=bool)) != True).sum()) if not tiered_curv.empty else 0,
        "strict_omega_m_corrected_column_locked_percent": rel_pct(0.327995, 0.315),
        "strict_omega_m_historical_ambiguity_percent": rel_pct(0.317696, 0.315),
        "qualified_axis_scores": qualified_core,
        "ranked_discrepancy_candidate_rows": int(len(ranked_candidates)),
        "rule_enforcement": {
            "no_cosmology_fitting_performed": True,
            "no_broad_new_null_suite_performed": True,
            "no_stage_6Yf_reopened": True,
            "no_row_index_family_assignment": True,
            "near_zero_curvature_relative_error_not_primary": True,
            "physical_identification_claimed": False,
            "raw_rows_preserved_for_transparency": True,
        },
        "safe_interpretation": "Corrected Stage-6Yi scoring/tiering only; cosmology comparisons remain external benchmark bookkeeping.",
        "recommended_next_step": recommendation,
    }


def write_notes(summary: Dict[str, Any], strict_mult: pd.DataFrame, curv_mult: pd.DataFrame, qscore: pd.DataFrame) -> None:
    gm = strict_mult[strict_mult["external_comparator"] == "ALL_CANONICAL_COMPARATORS_STRICT"]
    gm_row = gm.iloc[0].to_dict() if not gm.empty else {}

    lines = [
        "=" * 79,
        "STAGE-6Yi v1a STRICT PUBLICATION-HARDENING NOTES",
        f"Run UTC: {RUN_UTC}",
        "=" * 79,
        "",
        "FINAL v1a VERDICT",
        "-----------------",
        str(summary["v1a_verdict"]),
        "",
        "CORRECTION SCOPE",
        "----------------",
        "Stage-6Yi v1a is a surgical correction of scoring and tiering only.",
        "It does not introduce a new scientific stage, does not reopen Stage-6Yf,",
        "does not perform a broad null suite, and does not fit QEG quantities to cosmology.",
        "",
        "STRICT COSMOLOGY PANEL",
        "----------------------",
        f"Raw v1 cosmology rows preserved: {summary['raw_v1_cosmology_rows_preserved']}",
        f"Strict canonical scored rows: {summary['strict_canonical_cosmology_rows_scored']}",
        f"Rows preserved but unscored: {summary['strict_canonical_cosmology_rows_unscored']}",
        f"Strict rows within 1 percent: {gm_row.get('within_1_percent_count', 'unknown')}",
        f"Strict rows within 5 percent: {gm_row.get('within_5_percent_count', 'unknown')}",
        f"Strict rows within 10 percent: {gm_row.get('within_10_percent_count', 'unknown')}",
        "",
        "The v1 problem was not scientific overclaiming; it was scoring permissiveness.",
        "Unknown comparators and rows without external values are now preserved as raw transparency rows,",
        "but excluded from strict multiplicity counts.",
        "",
        "OMEGA_m CONTRACT ANCHORS",
        "------------------------",
        f"Historical ambiguity-period discrepancy: {summary['strict_omega_m_historical_ambiguity_percent']:.6f} percent",
        f"Corrected column-locked discrepancy: {summary['strict_omega_m_corrected_column_locked_percent']:.6f} percent",
        "",
        "The corrected column-locked row remains the primary external benchmark.",
        "The historical <1% row is retained only as downgraded ambiguity-period bookkeeping.",
        "",
        "OMEGA_K / CURVATURE TIERING",
        "--------------------------",
        f"Raw v1 curvature rows preserved: {summary['raw_v1_curvature_rows_preserved']}",
        f"Principled/explicit curvature rows scored: {summary['principled_curvature_rows_scored']}",
        f"Exploratory curvature rows preserved unscored: {summary['exploratory_curvature_rows_preserved_unscored']}",
        "",
        "Omega_K is near zero. Absolute error and uncertainty-window tests remain primary;",
        "relative error is not used as the primary curvature score.",
        "",
        "QUALIFIED EVIDENCE AXES",
        "-----------------------",
    ]
    if not qscore.empty:
        for _, r in qscore.iterrows():
            lines.append(
                f"- {r['axis']}: {r['qualified_strength_class_v1a']} "
                f"| qualified={r['qualified_supporting_file_count_v1a']} "
                f"| raw={r['raw_supporting_file_count_v1']}"
            )
    lines.extend([
        "",
        "PUBLICATION-SAFE CLAIM",
        "----------------------",
        "QEG currently supports a documented emergence-program claim:",
        "a lineage-preserved pipeline produces a stable two-sector/operator geometry",
        "that survives family separation, repair history, and recursive validation audits.",
        "",
        "UNSAFE CLAIM",
        "------------",
        "QEG derives spacetime, quantum gravity, Omega_m, or Omega_K from the Standard Model.",
        "",
        "NEXT RECOMMENDATION",
        "-------------------",
        str(summary["recommended_next_step"]),
        "",
        "=" * 79,
        "END NOTES",
        "=" * 79,
        "",
    ])
    (OUTPUT_DIR / "Stage-6Yi_v1a_strict_publication_hardening_notes.txt").write_text("\n".join(lines), encoding="utf-8")


# =============================================================================
# Main
# =============================================================================

def main() -> int:
    banner("QEG Stage-6Yi v1a Strict Publication-Hardening Correction")
    echo(f"Script: {SCRIPT_NAME}")
    echo(f"Run UTC: {RUN_UTC}")
    echo(f"Project root: {PROJECT_ROOT}")
    echo(f"Stage-6Yi v1 input directory: {V1_DIR}")
    echo(f"v1a output directory: {OUTPUT_DIR}")
    echo("Rules: no cosmology fitting; no broad new nulls; no Stage-6Yf reopening; no physical-identification claim.")

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    try:
        section("Archiving raw v1 inputs")
        archive_manifest = copy_raw_inputs()
        archive_df = pd.DataFrame(archive_manifest)
        write_csv("stage6Yi_v1a_raw_v1_snapshot_manifest.csv", archive_df)

        section("Reading v1 panels")
        raw_cosmo = safe_read_csv(V1_DIR / "stage6Yi_cosmology_benchmark_panel.csv")
        raw_curv = safe_read_csv(V1_DIR / "stage6Yi_curvature_benchmark_panel.csv")
        raw_locator = safe_read_csv(V1_DIR / "stage6Yi_prior_stage_locator.csv")
        raw_axis_inv = safe_read_csv(V1_DIR / "stage6Yi_evidence_axis_inventory.csv")
        raw_axis_score = safe_read_csv(V1_DIR / "stage6Yi_axis_strength_scorecard.csv")
        raw_candidates = safe_read_csv(V1_DIR / "stage6Yi_discrepancy_reduction_candidates.csv")
        v1_summary = safe_read_json(V1_DIR / "stage6Yi_summary.json", required=False)

        section("Building strict cosmology panel")
        strict_cosmo, strict_scored = strict_cosmology_panel(raw_cosmo)
        strict_mult = strict_multiplicity(strict_cosmo)
        write_csv("stage6Yi_v1a_cosmology_benchmark_panel_strict.csv", strict_cosmo)
        write_csv("stage6Yi_v1a_cosmology_benchmark_panel_strict_scored_only.csv", strict_scored)
        write_csv("stage6Yi_v1a_feature_multiplicity_audit_strict.csv", strict_mult)

        section("Tiering curvature panel")
        tiered_curv, principled_curv = tiered_curvature_panel(raw_curv)
        curv_mult = curvature_multiplicity(tiered_curv)
        write_csv("stage6Yi_v1a_curvature_benchmark_panel_tiered.csv", tiered_curv)
        write_csv("stage6Yi_v1a_curvature_benchmark_panel_principled_scored_only.csv", principled_curv)
        write_csv("stage6Yi_v1a_curvature_tier_multiplicity_audit.csv", curv_mult)

        section("Qualifying evidence axes")
        qinv, qscore = qualified_evidence_axes(raw_axis_inv, raw_axis_score, raw_locator)
        write_csv("stage6Yi_v1a_evidence_axis_inventory_qualified.csv", qinv)
        write_csv("stage6Yi_v1a_axis_strength_scorecard_qualified.csv", qscore)

        section("Ranking discrepancy candidates by trust tier")
        ranked_candidates, scored_candidates = ranked_discrepancy_candidates(raw_candidates)
        write_csv("stage6Yi_v1a_discrepancy_reduction_candidates_ranked.csv", ranked_candidates)
        write_csv("stage6Yi_v1a_discrepancy_reduction_candidates_strict_scored.csv", scored_candidates)

        section("Rebuilding strict Omega_m audit")
        omega_strict = strict_omega_m_audit(strict_cosmo, ranked_candidates)
        write_csv("stage6Yi_v1a_omega_m_discrepancy_audit_strict.csv", omega_strict)

        section("Writing summary and notes")
        summary = make_summary(
            v1_summary=v1_summary,
            raw_cosmo=raw_cosmo,
            strict_cosmo=strict_cosmo,
            strict_scored=strict_scored,
            strict_mult=strict_mult,
            raw_curv=raw_curv,
            tiered_curv=tiered_curv,
            principled_curv=principled_curv,
            qualified_score=qscore,
            ranked_candidates=ranked_candidates,
        )
        write_json("stage6Yi_v1a_summary.json", summary)
        write_notes(summary, strict_mult, curv_mult, qscore)

        try:
            src = Path(__file__).resolve()
            dst = OUTPUT_DIR / SCRIPT_NAME
            if src.exists() and src != dst:
                shutil.copy2(src, dst)
        except Exception as exc:
            echo(f"Script archive warning: {exc}")

        section("Stage-6Yi v1a complete")
        echo(f"v1a verdict: {summary['v1a_verdict']}")
        echo(f"Strict scored cosmology rows: {summary['strict_canonical_cosmology_rows_scored']}")
        echo(f"Strict within 1/5/10 percent: {summary['strict_within_1_percent_count']}/{summary['strict_within_5_percent_count']}/{summary['strict_within_10_percent_count']}")
        echo(f"Output directory: {OUTPUT_DIR}")
        echo("All cosmology rows remain benchmark bookkeeping only, not physical identification.")
        return 0

    except Exception as exc:
        OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        error = {
            "stage": "6Yi",
            "script_name": SCRIPT_NAME,
            "run_utc": RUN_UTC,
            "v1a_verdict": "D_V1A_CORRECTION_SCRIPT_ERROR",
            "error_type": type(exc).__name__,
            "error_message": str(exc),
            "traceback": traceback.format_exc(),
            "rule_enforcement": {
                "no_cosmology_fitting_performed": True,
                "no_broad_new_null_suite_performed": True,
                "no_stage_6Yf_reopened": True,
                "physical_identification_claimed": False,
            },
        }
        write_json("stage6Yi_v1a_summary.json", error)
        (OUTPUT_DIR / "Stage-6Yi_v1a_strict_publication_hardening_notes.txt").write_text(
            "Stage-6Yi v1a crashed before completion. See stage6Yi_v1a_summary.json for traceback.\n"
            "No cosmology fitting or physical-identification claim was performed.\n",
            encoding="utf-8",
        )
        echo("ERROR: Stage-6Yi v1a crashed.")
        echo(str(exc))
        echo(traceback.format_exc())
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
