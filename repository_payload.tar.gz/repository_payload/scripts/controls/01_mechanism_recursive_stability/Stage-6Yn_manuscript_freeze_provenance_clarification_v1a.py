#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
========================================================================
Stage-6Yn v1a — Manuscript Freeze Provenance Clarification Patch
Project: Quantum-Emergent Gravity
Author: Arturo Ortiz-Tapia / QEG pipeline support script
Build: 2026-05-29
========================================================================

Purpose
-------
This is a corrective manuscript-freeze patch for Stage-6Yn v1.  It does
NOT introduce new mathematics, refit observables, or tune values to PDG /
cosmological benchmarks.

It repairs four things from Stage-6Yn v1:

1. Resolve core reproduction gaps:
   A03 = Stage-6D terminal family-aware geometry
   A06 = Stage-6Q canonical law extraction
   A07 = Stage-6Yj/Yk/Yl/Ym comparator reconstruction chain

2. Correct Omega_m comparator source priority:
   The Stage-6Yk/Yl/Ym comparator reconstruction chain has priority over
   the broad Stage-6Yi cosmology bookkeeping panel.

3. Freeze the corrected comparator pair:
   global_mu                = 0.327995
   early_central_separation = 0.317696468538139
   against external benchmark Omega_m = 0.315, as comparison bookkeeping
   only.  No derivation, fit, rescaling, or physical identification is
   asserted.

4. Reclassify figure gaps as separate from reproduction blockers whenever
   numerical source material exists or the figure is schematic / manually
   regeneratable.

Default root
------------
/home/dakini/Downloads/010-Quantum_Emergent_Gravity

Example
-------
cd /home/dakini/Downloads/010-Quantum_Emergent_Gravity
/home/dakini/python_envs/python3.11/bin/python3.11 \
    Stage-6Yn_manuscript_freeze_provenance_clarification_v1a.py \
    --root /home/dakini/Downloads/010-Quantum_Emergent_Gravity \
    --overwrite --deep-scan

Outputs
-------
metric_stage_6Yn_v1a_outputs/

Required outputs are generated as CSV/JSON/TXT.  The script never modifies
metric_stage_6Yn_outputs/.
========================================================================
"""

from __future__ import annotations

import argparse
import csv
import datetime as _dt
import json
import math
import os
import re
import sys
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple


# ---------------------------------------------------------------------
# Frozen constants from the Stage-6Yn v1a transition package
# ---------------------------------------------------------------------
SCRIPT_NAME = "Stage-6Yn_manuscript_freeze_provenance_clarification_v1a.py"
DEFAULT_ROOT = Path("/home/dakini/Downloads/010-Quantum_Emergent_Gravity")
OUTPUT_DIRNAME = "metric_stage_6Yn_v1a_outputs"

BENCHMARK_KEY = "Omega_m"
BENCHMARK_VALUE = 0.315

CORRECTED_GLOBAL_MU = 0.327995
CORRECTED_EARLY_CENTRAL_SEPARATION = 0.317696468538139

WRONG_V1_GLOBAL_MU = 0.500000
WRONG_V1_EARLY_CENTRAL_SEPARATION = 0.406087652955405

ALLOWED_LANGUAGE = (
    "QEG identifies lineage-preserved internal dimensionless comparators "
    "that can be externally benchmarked against cosmological quantities. "
    "No physical identification or derivation is asserted."
)

FORBIDDEN_LANGUAGE = (
    "QEG derives Omega_m; QEG fits Omega_m; QEG rescales values to Omega_m; "
    "QEG derives cosmological parameters; numerical proximity alone establishes "
    "physical semantics."
)

SOURCE_PRIORITY_RULE_TEXT = (
    "For Stage-6Yn v1a, Stage-6Yk/Yl/Ym comparator reconstruction outputs "
    "take priority over broad Stage-6Yi cosmology bookkeeping rows. Stage-6Yi "
    "may be used only as historical/bookkeeping fallback, never as first-priority "
    "freeze source."
)


# ---------------------------------------------------------------------
# Utility helpers
# ---------------------------------------------------------------------
@dataclass
class LocatedFile:
    label: str
    found: bool
    path: str = ""
    note: str = ""


@dataclass
class ReviewFlag:
    flag_id: str
    severity: str
    item: str
    message: str
    action: str


def now_iso() -> str:
    return _dt.datetime.now().replace(microsecond=0).isoformat()


def ensure_output_dir(path: Path, overwrite: bool) -> None:
    if path.exists() and not path.is_dir():
        raise RuntimeError(f"Output path exists but is not a directory: {path}")
    if path.exists() and any(path.iterdir()) and not overwrite:
        raise RuntimeError(
            f"Output directory already exists and is non-empty: {path}\n"
            "Use --overwrite to allow writing into it."
        )
    path.mkdir(parents=True, exist_ok=True)


def safe_rel(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve()))
    except Exception:
        return str(path)


def read_text_small(path: Path, max_bytes: int = 4_000_000) -> str:
    """Read a text-ish file with tolerant decoding and size cap."""
    try:
        with path.open("rb") as f:
            data = f.read(max_bytes)
        return data.decode("utf-8", errors="replace")
    except Exception:
        return ""


def normalize_name(name: str) -> str:
    return name.lower().replace("-", "_").replace(" ", "_")


def exact_filename_index(root: Path) -> Dict[str, List[Path]]:
    idx: Dict[str, List[Path]] = {}
    for p in root.rglob("*"):
        if p.is_file():
            idx.setdefault(p.name, []).append(p)
    return idx


def find_exact(idx: Dict[str, List[Path]], filename: str) -> List[Path]:
    return idx.get(filename, [])


def find_by_suffix(root: Path, suffix: str) -> List[Path]:
    suffix_norm = suffix.replace("\\", "/")
    out: List[Path] = []
    for p in root.rglob("*"):
        if p.is_file():
            rel = str(p.relative_to(root)).replace("\\", "/")
            if rel.endswith(suffix_norm):
                out.append(p)
    return out


def find_name_contains(root: Path, tokens: Sequence[str], exts: Optional[Sequence[str]] = None) -> List[Path]:
    tokens_norm = [t.lower() for t in tokens]
    extset = {e.lower() for e in exts} if exts else None
    matches: List[Path] = []
    for p in root.rglob("*"):
        if not p.is_file():
            continue
        if extset and p.suffix.lower() not in extset:
            continue
        n = p.name.lower()
        if all(t in n for t in tokens_norm):
            matches.append(p)
    return matches


def scan_for_output_markers(root: Path, markers: Sequence[str], extensions: Sequence[str] = (".py", ".txt", ".md")) -> List[Path]:
    """Find scripts/notes mentioning all requested output markers."""
    extset = {e.lower() for e in extensions}
    marker_set = list(markers)
    hits: List[Path] = []
    for p in root.rglob("*"):
        if not p.is_file() or p.suffix.lower() not in extset:
            continue
        text = read_text_small(p)
        if text and all(m in text for m in marker_set):
            hits.append(p)
    return hits


def extract_floats(text: str) -> List[float]:
    # Includes scientific notation and ordinary decimals.
    pat = re.compile(r"[-+]?\d*\.\d+(?:[eE][-+]?\d+)?|[-+]?\d+(?:[eE][-+]?\d+)")
    vals: List[float] = []
    for m in pat.finditer(text):
        try:
            vals.append(float(m.group(0)))
        except Exception:
            pass
    return vals


def text_contains_float(text: str, target: float, tol: float = 5e-10) -> bool:
    if not text:
        return False
    # First try exact/near string snippets for speed.
    candidates = {
        f"{target:.15f}".rstrip("0").rstrip("."),
        f"{target:.12f}".rstrip("0").rstrip("."),
        f"{target:.9f}".rstrip("0").rstrip("."),
        f"{target:.6f}".rstrip("0").rstrip("."),
    }
    if any(c and c in text for c in candidates):
        return True
    for v in extract_floats(text):
        if math.isfinite(v) and abs(v - target) <= tol:
            return True
    return False


def file_contains_float(path: Path, target: float, tol: float = 5e-10) -> bool:
    return text_contains_float(read_text_small(path), target, tol=tol)


def write_csv(path: Path, rows: Sequence[Dict[str, Any]], fieldnames: Optional[Sequence[str]] = None) -> None:
    if fieldnames is None:
        seen: List[str] = []
        for row in rows:
            for key in row.keys():
                if key not in seen:
                    seen.append(key)
        fieldnames = seen
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(fieldnames), extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({k: serialize_cell(row.get(k, "")) for k in fieldnames})


def write_json(path: Path, obj: Any) -> None:
    with path.open("w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, sort_keys=True)
        f.write("\n")


def serialize_cell(x: Any) -> str:
    if x is None:
        return ""
    if isinstance(x, (list, tuple, set)):
        return "; ".join(str(v) for v in x)
    if isinstance(x, dict):
        return json.dumps(x, sort_keys=True)
    return str(x)


def pct_error(qeg_value: float, benchmark: float) -> float:
    return abs(qeg_value - benchmark) / abs(benchmark) * 100.0


def bool_text(x: bool) -> str:
    return "true" if x else "false"


# ---------------------------------------------------------------------
# Core gap resolution
# ---------------------------------------------------------------------
def resolve_A03(root: Path, idx: Dict[str, List[Path]]) -> Tuple[Dict[str, Any], List[ReviewFlag]]:
    flags: List[ReviewFlag] = []
    exact = find_exact(idx, "Stage-6D_v2_fixed.py")
    selected = exact[0] if exact else None
    supporting_names = [
        "Stage-6D_v2.py",
        "metric_stage_6D_symmetry_breaking_profile_from_stage6C_v1c.py",
        "metric_stage_6D_geometric_interpretation_of_symmetry_breaking_v1b.py",
        "metric_stage_6D_geometric_interpretation_of_symmetry_breaking_v1.py",
    ]
    supporting: List[Path] = []
    for name in supporting_names:
        supporting.extend(find_exact(idx, name))

    fallback_markers = [
        "stage6D_inadmissibility_geometry_table_v2.csv",
        "stage6D_family_boundary_estimate_v2.csv",
        "stage6D_family_geometry_summary_v2.csv",
        "stage6D_symmetry_breaking_summary_v2.json",
    ]
    fallback_hits: List[Path] = []
    if not selected:
        fallback_hits = scan_for_output_markers(root, fallback_markers)
        if fallback_hits:
            selected = fallback_hits[0]

    status = "RESOLVED" if selected else "UNRESOLVED"
    if not selected:
        flags.append(ReviewFlag(
            "A03_UNRESOLVED", "BLOCKER", "A03 Stage-6D terminal family-aware geometry",
            "Stage-6D_v2_fixed.py or equivalent v2 output writer was not found.",
            "Upload/restore the Stage-6D fixed script or run from a root containing it."
        ))

    return {
        "gap_id": "A03",
        "gap_description": "Stage-6D terminal family-aware geometry",
        "previous_status": "UNRESOLVED_OR_MANUAL_SELECT_IN_v1",
        "v1a_status": status,
        "selected_core_file": safe_rel(selected, root) if selected else "",
        "supporting_files": [safe_rel(p, root) for p in supporting],
        "reason": (
            "Stage-6D_v2_fixed.py closes the terminal family-aware geometry slot by reconstructing "
            "radial_zscore admissibility geometry from row-level metric evaluations and intrinsic coordinates."
            if exact else
            "Exact fixed script absent, but an equivalent script mentioning the v2 Stage-6D output contract was found."
            if selected else
            "No accepted Stage-6D v2 fixed script or equivalent v2 output writer was found."
        ),
        "reproduction_blocker_after_v1a": not bool(selected),
    }, flags


def resolve_A06(root: Path, idx: Dict[str, List[Path]]) -> Tuple[Dict[str, Any], List[ReviewFlag]]:
    flags: List[ReviewFlag] = []
    exact = find_exact(idx, "Stage-6Q_canonical_law_extraction_v1.py")
    selected = exact[0] if exact else None
    fallback_markers = [
        "stage6Q_canonical_parameters.csv",
        "stage6Q_invariant_summary.csv",
        "stage6Q_dimensionless_ratios.csv",
        "stage6Q_canonical_curve.csv",
        "stage6Q_canonical_law_summary.json",
    ]
    fallback_hits: List[Path] = []
    if not selected:
        fallback_hits = scan_for_output_markers(root, fallback_markers)
        if fallback_hits:
            selected = fallback_hits[0]

    status = "RESOLVED" if selected else "UNRESOLVED"
    if not selected:
        flags.append(ReviewFlag(
            "A06_UNRESOLVED", "BLOCKER", "A06 Stage-6Q canonical law extraction",
            "Stage-6Q_canonical_law_extraction_v1.py or equivalent Stage-6Q output writer was not found.",
            "Upload/restore the Stage-6Q canonical extraction script or run from a root containing it."
        ))

    return {
        "gap_id": "A06",
        "gap_description": "Stage-6Q canonical law extraction",
        "previous_status": "UNRESOLVED_OR_MANUAL_SELECT_IN_v1",
        "v1a_status": status,
        "selected_core_file": safe_rel(selected, root) if selected else "",
        "supporting_files": [safe_rel(p, root) for p in fallback_hits if selected and p != selected],
        "reason": (
            "Stage-6Q_canonical_law_extraction_v1.py canonicalizes the Stage-6P v6 family-universal "
            "two-lobe law without refitting, changing observables, or introducing Green/PDE closure."
            if exact else
            "Exact Stage-6Q script absent, but an equivalent script mentioning the Stage-6Q canonical output contract was found."
            if selected else
            "No accepted Stage-6Q canonical extraction script or equivalent output writer was found."
        ),
        "reproduction_blocker_after_v1a": not bool(selected),
    }, flags


def resolve_A07(root: Path, idx: Dict[str, List[Path]]) -> Tuple[Dict[str, Any], List[ReviewFlag]]:
    flags: List[ReviewFlag] = []
    required = [
        "Stage-6Yj_manuscript_axis_synthesis_v1.py",
        "Stage-6Yk_omega_m_pareto_refinement_v1.py",
        "Stage-6Yl_corrected_lock_omega_m_reconstruction_v1.py",
        "Stage-6Ym_resolution_recovery_and_manuscript_inventory_v1.py",
    ]
    found: Dict[str, List[Path]] = {name: find_exact(idx, name) for name in required}
    missing = [name for name, hits in found.items() if not hits]
    selected = [hits[0] for hits in found.values() if hits]

    if missing:
        flags.append(ReviewFlag(
            "A07_INCOMPLETE", "BLOCKER", "A07 Stage-6Yj/Yk/Yl/Ym comparator reconstruction chain",
            "One or more scripts in the late comparator chain were not found: " + "; ".join(missing),
            "Restore/upload the full Stage-6Yj/Yk/Yl/Ym chain before claiming A07 closure."
        ))

    return {
        "gap_id": "A07",
        "gap_description": "Stage-6Yj/Yk/Yl/Ym comparator reconstruction chain",
        "previous_status": "UNRESOLVED_OR_MANUAL_SELECT_IN_v1",
        "v1a_status": "RESOLVED" if not missing else "UNRESOLVED",
        "selected_core_file": "; ".join(safe_rel(p, root) for p in selected),
        "supporting_files": [],
        "reason": (
            "All four late comparator-chain scripts were found: manuscript-axis synthesis, Omega_m Pareto/guardrail, "
            "corrected-lock reconstruction, and resolution recovery/manuscript inventory."
            if not missing else
            "The late comparator-chain closure requires all four Stage-6Yj/Yk/Yl/Ym scripts; at least one is missing."
        ),
        "reproduction_blocker_after_v1a": bool(missing),
    }, flags


def resolve_core_gaps(root: Path, idx: Dict[str, List[Path]]) -> Tuple[List[Dict[str, Any]], List[ReviewFlag]]:
    rows: List[Dict[str, Any]] = []
    flags: List[ReviewFlag] = []
    for fn in (resolve_A03, resolve_A06, resolve_A07):
        row, fl = fn(root, idx)
        rows.append(row)
        flags.extend(fl)
    return rows, flags


# ---------------------------------------------------------------------
# Comparator freeze and source priority
# ---------------------------------------------------------------------
def candidate_sources(root: Path) -> Dict[str, List[Path]]:
    """Return comparator source groups in the frozen priority order."""
    groups: Dict[str, List[Path]] = {
        "P1_STAGE6YK_BENCHMARK_GUARDRAIL_BASELINE": find_by_suffix(
            root, "metric_stage_6Yk_outputs/stage6Yk_benchmark_guardrail_baseline.csv"
        ),
        "P1B_STAGE6YK_REFINEMENT_CANDIDATES": find_by_suffix(
            root, "metric_stage_6Yk_outputs/stage6Yk_omega_m_refinement_candidates.csv"
        ),
        "P2_STAGE6YL_PROMOTION_DECISION": find_by_suffix(
            root, "metric_stage_6Yl_outputs/stage6Yl_promotion_decision_panel.csv"
        ),
        "P3_STAGE6YM_SUMMARY_JSON": find_by_suffix(
            root, "metric_stage_6Ym_outputs/stage6Ym_resolution_recovery_summary.json"
        ),
        "P3B_STAGE6YM_CLAIM_STATUS": find_by_suffix(
            root, "metric_stage_6Ym_outputs/stage6Ym_claim_status_update_v2.csv"
        ),
        "P4_STAGE6YN_IMPROVEMENT_CANDIDATES": find_by_suffix(
            root, "metric_stage_6Yn_outputs/stage6Yn_omega_m_improvement_candidates.csv"
        ) + find_by_suffix(
            root, "metric_stage_6Yn_outputs/omega_m_comparator_review/stage6Yn_omega_m_improvement_candidates.csv"
        ),
        "P4B_STAGE6YN_GUARDRAIL_REVIEW": find_by_suffix(
            root, "metric_stage_6Yn_outputs/omega_m_comparator_review/stage6Yn_omega_m_guardrail_review.txt"
        ),
        "P4C_STAGE6YN_COMPARATOR_FREEZE_V1": find_by_suffix(
            root, "metric_stage_6Yn_outputs/omega_m_comparator_review/stage6Yn_omega_m_comparator_freeze.csv"
        ),
        "P5_STAGE6YI_HISTORICAL_BOOKKEEPING_ONLY": find_name_contains(
            root, ["stage6yi"], exts=(".csv", ".json", ".txt")
        ),
    }
    return groups


def source_verification(paths: Sequence[Path]) -> Dict[str, Any]:
    has_global = False
    has_sep = False
    has_wrong_global = False
    has_wrong_sep = False
    files_with_global: List[str] = []
    files_with_sep: List[str] = []
    files_with_wrong: List[str] = []
    for p in paths:
        text = read_text_small(p)
        cg = text_contains_float(text, CORRECTED_GLOBAL_MU, tol=5e-8)
        cs = text_contains_float(text, CORRECTED_EARLY_CENTRAL_SEPARATION, tol=5e-8)
        wg = text_contains_float(text, WRONG_V1_GLOBAL_MU, tol=5e-12)
        ws = text_contains_float(text, WRONG_V1_EARLY_CENTRAL_SEPARATION, tol=5e-8)
        has_global = has_global or cg
        has_sep = has_sep or cs
        has_wrong_global = has_wrong_global or wg
        has_wrong_sep = has_wrong_sep or ws
        if cg:
            files_with_global.append(str(p))
        if cs:
            files_with_sep.append(str(p))
        if wg or ws:
            files_with_wrong.append(str(p))
    return {
        "has_corrected_global_mu": has_global,
        "has_corrected_early_central_separation": has_sep,
        "has_wrong_v1_global_mu": has_wrong_global,
        "has_wrong_v1_early_central_separation": has_wrong_sep,
        "files_with_corrected_global_mu": files_with_global,
        "files_with_corrected_early_central_separation": files_with_sep,
        "files_with_wrong_v1_values": files_with_wrong,
    }


def choose_comparator_source(root: Path, no_hardcoded_fallback: bool) -> Tuple[Dict[str, Any], List[Dict[str, Any]], List[ReviewFlag]]:
    groups = candidate_sources(root)
    audit_rows: List[Dict[str, Any]] = []
    flags: List[ReviewFlag] = []

    selected_group = ""
    selected_paths: List[Path] = []
    selected_confidence = ""
    selected_note = ""
    verification: Dict[str, Any] = {}

    priority_order = [
        "P1_STAGE6YK_BENCHMARK_GUARDRAIL_BASELINE",
        "P1B_STAGE6YK_REFINEMENT_CANDIDATES",
        "P2_STAGE6YL_PROMOTION_DECISION",
        "P3_STAGE6YM_SUMMARY_JSON",
        "P3B_STAGE6YM_CLAIM_STATUS",
        "P4_STAGE6YN_IMPROVEMENT_CANDIDATES",
        "P4B_STAGE6YN_GUARDRAIL_REVIEW",
        "P4C_STAGE6YN_COMPARATOR_FREEZE_V1",
        "P5_STAGE6YI_HISTORICAL_BOOKKEEPING_ONLY",
    ]

    for group in priority_order:
        paths = groups.get(group, [])
        ver = source_verification(paths)
        role = "SELECTABLE_PRIORITY_SOURCE"
        if group.startswith("P5_STAGE6YI"):
            role = "HISTORICAL_BOOKKEEPING_ONLY_NOT_PRIMARY_FREEZE"
        audit_rows.append({
            "source_group": group,
            "source_role": role,
            "found_count": len(paths),
            "found_paths": [str(p) for p in paths],
            "has_corrected_global_mu": ver["has_corrected_global_mu"],
            "has_corrected_early_central_separation": ver["has_corrected_early_central_separation"],
            "has_wrong_v1_global_mu": ver["has_wrong_v1_global_mu"],
            "has_wrong_v1_early_central_separation": ver["has_wrong_v1_early_central_separation"],
            "interpretation": (
                "Highest priority if present; use to justify corrected freeze."
                if group == "P1_STAGE6YK_BENCHMARK_GUARDRAIL_BASELINE" else
                "Late comparator-chain source; valid fallback behind Stage-6Yk baseline."
                if group.startswith(("P1B", "P2", "P3")) else
                "Stage-6Yn v1/fallback audit source; valid only if later chain files are unavailable."
                if group.startswith("P4") else
                "Historical broad cosmology bookkeeping panel; explains WRONG_SOURCE_PRIORITY in v1 and must not override Stage-6Yk/Yl/Ym."
            ),
        })

    # Selection logic: prefer first non-Stage6Yi group that is found.
    for group in priority_order:
        if group.startswith("P5_STAGE6YI"):
            continue
        paths = groups.get(group, [])
        if paths:
            selected_group = group
            selected_paths = paths
            verification = source_verification(paths)
            if verification["has_corrected_global_mu"] or verification["has_corrected_early_central_separation"]:
                selected_confidence = "SOURCE_FOUND_AND_CORRECTED_VALUE_DETECTED"
            else:
                selected_confidence = "SOURCE_FOUND_LEDGER_CORRECTED_VALUES_USED"
            selected_note = "Selected by priority order before any Stage-6Yi historical bookkeeping panel."
            break

    if not selected_group:
        if no_hardcoded_fallback:
            selected_group = "NONE"
            selected_confidence = "FAILED_NO_SOURCE_AND_HARDCODED_FALLBACK_DISABLED"
            selected_note = "No selectable Stage-6Yk/Yl/Ym/Yn comparator source found and hard-coded fallback disabled."
            flags.append(ReviewFlag(
                "COMPARATOR_SOURCE_PRIORITY_UNRESOLVED", "BLOCKER", "Omega_m comparator freeze",
                selected_note,
                "Restore Stage-6Yk/Yl/Ym comparator files or rerun without --no-hardcoded-comparator-fallback."
            ))
        else:
            selected_group = "LEDGER_HARDCODED_CORRECTED_PAIR_FALLBACK"
            selected_paths = []
            verification = {}
            selected_confidence = "COMPARATOR_VALUES_HARDCODED_FROM_LEDGER_REVIEW"
            selected_note = (
                "No selectable comparator table found. Using corrected pair from Stage-6Yn v1a ledger package; "
                "this is allowed only because --no-hardcoded-comparator-fallback was not set."
            )
            flags.append(ReviewFlag(
                "COMPARATOR_LEDGER_FALLBACK_USED", "WARNING", "Omega_m comparator freeze",
                selected_note,
                "Prefer restoring Stage-6Yk/Yl/Ym source tables for strongest manuscript provenance."
            ))

    # Always record the Stage-6Yi wrong-source rule.
    audit_rows.append({
        "source_group": "WRONG_V1_VALUES",
        "source_role": "REJECTED_FREEZE_VALUES",
        "found_count": "ledger-known",
        "found_paths": "",
        "has_corrected_global_mu": False,
        "has_corrected_early_central_separation": False,
        "has_wrong_v1_global_mu": True,
        "has_wrong_v1_early_central_separation": True,
        "interpretation": (
            f"Do not select global_mu={WRONG_V1_GLOBAL_MU} or "
            f"early_central_separation={WRONG_V1_EARLY_CENTRAL_SEPARATION}. "
            "These are labelled WRONG_SOURCE_PRIORITY_FROM_STAGE6YI_BOOKKEEPING_PANEL."
        ),
    })

    selection = {
        "selected_source_group": selected_group,
        "selected_paths": [str(p) for p in selected_paths],
        "selected_confidence": selected_confidence,
        "selected_note": selected_note,
        "source_priority_rule": SOURCE_PRIORITY_RULE_TEXT,
        "verification": verification,
    }
    return selection, audit_rows, flags


def corrected_omega_freeze_rows(selection: Dict[str, Any]) -> List[Dict[str, Any]]:
    return [
        {
            "comparator_role": "conservative_control_comparator",
            "qeg_feature": "global_mu",
            "qeg_value": CORRECTED_GLOBAL_MU,
            "benchmark_key": BENCHMARK_KEY,
            "benchmark_value": BENCHMARK_VALUE,
            "absolute_difference": abs(CORRECTED_GLOBAL_MU - BENCHMARK_VALUE),
            "percent_error": pct_error(CORRECTED_GLOBAL_MU, BENCHMARK_VALUE),
            "priority_source": selection.get("selected_source_group", ""),
            "source_priority_rule": SOURCE_PRIORITY_RULE_TEXT,
            "trust_status": "TRUST_FIRST_PRIMARY_CONTROL",
            "manuscript_status": "FREEZE_AS_CONSERVATIVE_CONTROL_COMPARATOR",
            "no_benchmark_fitting": True,
            "no_rescaling_to_omega_m": True,
            "no_physical_identification_with_omega_m": True,
            "allowed_language": ALLOWED_LANGUAGE,
            "forbidden_language": FORBIDDEN_LANGUAGE,
        },
        {
            "comparator_role": "primary_sharp_comparator_candidate",
            "qeg_feature": "early_central_separation",
            "qeg_value": CORRECTED_EARLY_CENTRAL_SEPARATION,
            "benchmark_key": BENCHMARK_KEY,
            "benchmark_value": BENCHMARK_VALUE,
            "absolute_difference": abs(CORRECTED_EARLY_CENTRAL_SEPARATION - BENCHMARK_VALUE),
            "percent_error": pct_error(CORRECTED_EARLY_CENTRAL_SEPARATION, BENCHMARK_VALUE),
            "priority_source": selection.get("selected_source_group", ""),
            "source_priority_rule": SOURCE_PRIORITY_RULE_TEXT,
            "trust_status": "SHARP_SECONDARY_OR_CONDITIONAL_PROMOTION",
            "manuscript_status": "FREEZE_AS_SHARP_COMPARATOR_CANDIDATE_NOT_DERIVATION",
            "no_benchmark_fitting": True,
            "no_rescaling_to_omega_m": True,
            "no_physical_identification_with_omega_m": True,
            "allowed_language": ALLOWED_LANGUAGE,
            "forbidden_language": FORBIDDEN_LANGUAGE,
        },
    ]


# ---------------------------------------------------------------------
# Reproduction bundle
# ---------------------------------------------------------------------
def detect_any(root: Path, idx: Dict[str, List[Path]], exact_names: Sequence[str], contains_tokens: Optional[Sequence[str]] = None) -> Tuple[bool, List[str]]:
    hits: List[Path] = []
    for name in exact_names:
        hits.extend(find_exact(idx, name))
    if contains_tokens:
        hits.extend(find_name_contains(root, contains_tokens, exts=(".py", ".csv", ".json", ".txt")))
    # Deduplicate while preserving order.
    seen = set()
    unique: List[Path] = []
    for p in hits:
        s = str(p)
        if s not in seen:
            seen.add(s)
            unique.append(p)
    return bool(unique), [safe_rel(p, root) for p in unique[:10]]


def reproduction_bundle_rows(root: Path, idx: Dict[str, List[Path]], core_rows: Sequence[Dict[str, Any]]) -> List[Dict[str, Any]]:
    core_by_gap = {r["gap_id"]: r for r in core_rows}

    a01_found, a01_files = detect_any(
        root, idx,
        ["stage4A_shellbands_BARI.json", "stage4A_shellbands_NUFIT.json", "stage4A_shellbands_VALENCIA.json"],
        contains_tokens=None,
    )
    a02_found, a02_files = detect_any(
        root, idx,
        ["stage5A_bridge_from_4D_v1.csv", "stage5A_constants_loader.py"],
        contains_tokens=["stage5a"],
    )
    a04_found, a04_files = detect_any(
        root, idx,
        [
            "Stage-6O_row_level_family_mapping_v1.py",
            "Stage-6O_universality_label_repair_v1.py",
            "stage6O_family_aware_profile_48bins_from_6D.csv",
            "stage6O_family_aware_profile_361bins_from_6D.csv",
        ],
        contains_tokens=["stage6o", "family"],
    )
    a05_found, a05_files = detect_any(
        root, idx,
        [
            "Stage-6P_v6_two_lobe_universality_test_on_v5_candidate.py",
            "stage6P_v6_summary.json",
            "stage6P_v6_family_two_lobe_universality_summary.json",
        ],
        contains_tokens=["stage6p", "v6"],
    )
    a08_found, a08_files = detect_any(
        root, idx,
        [SCRIPT_NAME, "Stage-6Yn_manuscript_freeze_provenance_clarification_v1.py"],
        contains_tokens=["stage6yn"],
    )

    rows = [
        {
            "bundle_id": "A01",
            "stage_component": "Stage-4A true family roots",
            "selected_artifact_or_script": "; ".join(a01_files),
            "v1a_status": "FOUND" if a01_found else "REVIEW_MISSING",
            "role": "Original BARI/NUFIT/VALENCIA lineage roots.",
            "reproduction_blocker": not a01_found,
            "notes": "Should include separate true-family roots, not downstream metric-family labels.",
        },
        {
            "bundle_id": "A02",
            "stage_component": "Stage-5A bridge",
            "selected_artifact_or_script": "; ".join(a02_files),
            "v1a_status": "FOUND" if a02_found else "REVIEW_MISSING",
            "role": "Bridge from Stage-4 family roots into intrinsic geometry pipeline.",
            "reproduction_blocker": not a02_found,
            "notes": "FIT/FIT_id/npz_file lineage bridge preferred.",
        },
        {
            "bundle_id": "A03",
            "stage_component": "Stage-6D terminal family-aware geometry",
            "selected_artifact_or_script": core_by_gap.get("A03", {}).get("selected_core_file", ""),
            "v1a_status": core_by_gap.get("A03", {}).get("v1a_status", "UNRESOLVED"),
            "role": "Terminal family-aware geometry reproduction candidate.",
            "reproduction_blocker": core_by_gap.get("A03", {}).get("reproduction_blocker_after_v1a", True),
            "notes": "Stage-6D_v2_fixed.py preferred.",
        },
        {
            "bundle_id": "A04",
            "stage_component": "Stage-6O provenance repair / family-aware rebuild",
            "selected_artifact_or_script": "; ".join(a04_files),
            "v1a_status": "FOUND" if a04_found else "REVIEW_MISSING",
            "role": "Family-aware repair branch and row-level provenance recovery.",
            "reproduction_blocker": not a04_found,
            "notes": "Do not assign family labels by row index; rebuild from terminal family-aware lineage.",
        },
        {
            "bundle_id": "A05",
            "stage_component": "Stage-6P v6 family two-lobe universality",
            "selected_artifact_or_script": "; ".join(a05_files),
            "v1a_status": "FOUND" if a05_found else "REVIEW_MISSING",
            "role": "Family-universal two-lobe law validation.",
            "reproduction_blocker": not a05_found,
            "notes": "Needed for full universality narrative; if missing, cite Stage-6Q canonicalization only with caution.",
        },
        {
            "bundle_id": "A06",
            "stage_component": "Stage-6Q canonical law extraction",
            "selected_artifact_or_script": core_by_gap.get("A06", {}).get("selected_core_file", ""),
            "v1a_status": core_by_gap.get("A06", {}).get("v1a_status", "UNRESOLVED"),
            "role": "Canonical law extraction without refitting/new observables.",
            "reproduction_blocker": core_by_gap.get("A06", {}).get("reproduction_blocker_after_v1a", True),
            "notes": "Stage-6Q_canonical_law_extraction_v1.py preferred.",
        },
        {
            "bundle_id": "A07",
            "stage_component": "Stage-6Yj/Yk/Yl/Ym comparator chain",
            "selected_artifact_or_script": core_by_gap.get("A07", {}).get("selected_core_file", ""),
            "v1a_status": core_by_gap.get("A07", {}).get("v1a_status", "UNRESOLVED"),
            "role": "Late comparator reconstruction and manuscript inventory chain.",
            "reproduction_blocker": core_by_gap.get("A07", {}).get("reproduction_blocker_after_v1a", True),
            "notes": "All four scripts preferred.",
        },
        {
            "bundle_id": "A08",
            "stage_component": "Stage-6Yn v1a manuscript freeze patch",
            "selected_artifact_or_script": "; ".join(a08_files) if a08_files else SCRIPT_NAME,
            "v1a_status": "CURRENT_SCRIPT_OR_FOUND" if a08_found else "CURRENT_SCRIPT_GENERATES_PATCH",
            "role": "Patch source-priority and figure-gap classification; recompute Stage-7A gate.",
            "reproduction_blocker": False,
            "notes": "This script writes to metric_stage_6Yn_v1a_outputs and does not modify v1 outputs.",
        },
    ]
    return rows


# ---------------------------------------------------------------------
# Figure gap reclassification
# ---------------------------------------------------------------------
def figure_source_paths(root: Path, idx: Dict[str, List[Path]]) -> Dict[str, List[Path]]:
    # Exact known figure sources plus useful discovered variants.
    sources: Dict[str, List[Path]] = {
        "stage6Q_canonical_curve.csv": find_exact(idx, "stage6Q_canonical_curve.csv"),
        "stage6Yi_omega_m_discrepancy_audit.csv": find_exact(idx, "stage6Yi_omega_m_discrepancy_audit.csv"),
        "stage6D_branch1_family_boundary.csv": find_exact(idx, "stage6D_branch1_family_boundary.csv"),
        "stage6U_v1c_perturbation_ladder_summary.csv": find_exact(idx, "stage6U_v1c_perturbation_ladder_summary.csv"),
        "Break rank-1 degeneracy using higher moments of commutator norms.txt": find_exact(idx, "Break rank-1 degeneracy using higher moments of commutator norms.txt"),
    }
    # Supplemental discoveries by name tokens.
    sources["stage6P_two_lobe_or_family_profiles"] = find_name_contains(root, ["stage6p"], exts=(".csv", ".json", ".png", ".txt"))
    sources["stage6Q_any"] = find_name_contains(root, ["stage6q"], exts=(".csv", ".json", ".png", ".txt"))
    sources["stage6Yk_or_Yl_or_Ym_comparator"] = (
        find_name_contains(root, ["stage6yk"], exts=(".csv", ".json", ".txt", ".png")) +
        find_name_contains(root, ["stage6yl"], exts=(".csv", ".json", ".txt", ".png")) +
        find_name_contains(root, ["stage6ym"], exts=(".csv", ".json", ".txt", ".png"))
    )
    sources["stage6O_provenance"] = find_name_contains(root, ["stage6o"], exts=(".csv", ".json", ".txt", ".png", ".py"))
    return sources


def figure_gap_rows(root: Path, idx: Dict[str, List[Path]]) -> Tuple[List[Dict[str, Any]], List[ReviewFlag]]:
    src = figure_source_paths(root, idx)
    flags: List[ReviewFlag] = []

    def rel_list(paths: Sequence[Path], limit: int = 8) -> str:
        return "; ".join(safe_rel(p, root) for p in paths[:limit])

    fig_specs = [
        {
            "figure_id": "Figure 1",
            "figure_title": "Pipeline schematic",
            "classification": "SCHEMATIC_REGENERATE_MANUALLY",
            "source_paths": "Ledger / stage-transition packages",
            "reason": "Explanatory schematic, not a numerical result; manually regeneratable from ledger.",
        },
        {
            "figure_id": "Figure 2",
            "figure_title": "Family-aware canonical two-lobe profiles",
            "classification": "NUMERICAL_SOURCE_COVERED" if src["stage6P_two_lobe_or_family_profiles"] else "SOURCE_COVERED_REGENERATE_FIGURE" if src["stage6Q_any"] else "STILL_MISSING_SOURCE",
            "source_paths": rel_list(src["stage6P_two_lobe_or_family_profiles"] or src["stage6Q_any"]),
            "reason": "Prefer Stage-6P family-universality profiles; Stage-6Q canonical outputs can regenerate canonical two-lobe figure.",
        },
        {
            "figure_id": "Figure 3",
            "figure_title": "Two-lobe decomposition",
            "classification": "SOURCE_COVERED_REGENERATE_FIGURE" if src["stage6Q_canonical_curve.csv"] or src["stage6Q_any"] else "STILL_MISSING_SOURCE",
            "source_paths": rel_list(src["stage6Q_canonical_curve.csv"] or src["stage6Q_any"]),
            "reason": "Two-lobe decomposition should be regeneratable from stage6Q_canonical_curve.csv or Stage-6Q canonical outputs.",
        },
        {
            "figure_id": "Figure 4",
            "figure_title": "Resolution robustness",
            "classification": "SOURCE_COVERED_REGENERATE_FIGURE" if src["stage6P_two_lobe_or_family_profiles"] or src["stage6O_provenance"] else "STILL_MISSING_SOURCE",
            "source_paths": rel_list(src["stage6P_two_lobe_or_family_profiles"] or src["stage6O_provenance"]),
            "reason": "Resolution robustness is manuscript-regeneratable from family-aware 48/361-bin profiles or Stage-6P universality outputs.",
        },
        {
            "figure_id": "Figure 5",
            "figure_title": "Omega_m comparator panel",
            "classification": "SOURCE_COVERED_REGENERATE_FIGURE" if src["stage6Yk_or_Yl_or_Ym_comparator"] or src["stage6Yi_omega_m_discrepancy_audit.csv"] else "STILL_MISSING_SOURCE",
            "source_paths": rel_list(src["stage6Yk_or_Yl_or_Ym_comparator"] or src["stage6Yi_omega_m_discrepancy_audit.csv"]),
            "reason": "After v1a, use corrected Stage-6Yk/Yl/Ym comparator chain; Stage-6Yi audit remains historical context only.",
        },
        {
            "figure_id": "Figure 6",
            "figure_title": "Operator-response evidence summary",
            "classification": "SOURCE_COVERED_REGENERATE_FIGURE" if src["stage6Q_any"] else "SCHEMATIC_REGENERATE_MANUALLY",
            "source_paths": rel_list(src["stage6Q_any"]),
            "reason": "Can be drawn as evidence summary from Stage-6J through Stage-6Q ledgers; not a reproduction blocker.",
        },
        {
            "figure_id": "Figure 8",
            "figure_title": "Claim-status ladder",
            "classification": "SOURCE_COVERED_REGENERATE_FIGURE" if src["stage6U_v1c_perturbation_ladder_summary.csv"] else "SCHEMATIC_REGENERATE_MANUALLY",
            "source_paths": rel_list(src["stage6U_v1c_perturbation_ladder_summary.csv"]),
            "reason": "Perturbation ladder summary is preferred if present; otherwise this is a manuscript ladder schematic.",
        },
        {
            "figure_id": "Appendix Figure A1",
            "figure_title": "Provenance repair map",
            "classification": "SOURCE_COVERED_REGENERATE_FIGURE" if src["stage6O_provenance"] else "SCHEMATIC_REGENERATE_MANUALLY",
            "source_paths": rel_list(src["stage6O_provenance"]),
            "reason": "Provenance repair map can be regenerated from Stage-6O lineage-repair scripts/outputs and ledgers.",
        },
        {
            "figure_id": "Appendix Figure A2",
            "figure_title": "Negative result diagnostics",
            "classification": "SOURCE_COVERED_REGENERATE_FIGURE" if src["Break rank-1 degeneracy using higher moments of commutator norms.txt"] else "SOURCE_COVERED_OR_LEDGER_REGENERATABLE",
            "source_paths": rel_list(src["Break rank-1 degeneracy using higher moments of commutator norms.txt"]),
            "reason": "Negative-result diagnostics are nonblocking; use uploaded degeneracy notes or ledgers to regenerate.",
        },
    ]

    rows: List[Dict[str, Any]] = []
    for spec in fig_specs:
        classification = spec["classification"]
        nonblocking = classification != "STILL_MISSING_SOURCE"
        rows.append({
            "figure_id": spec["figure_id"],
            "figure_title": spec["figure_title"],
            "v1a_classification": classification,
            "source_paths": spec["source_paths"],
            "reason": spec["reason"],
            "reproduction_blocker": False if nonblocking else "REVIEW_ONLY_NOT_AUTOMATIC_BLOCKER",
            "manual_or_regeneration_task": True,
        })
        if classification == "STILL_MISSING_SOURCE":
            flags.append(ReviewFlag(
                f"{spec['figure_id'].replace(' ', '_')}_SOURCE_REVIEW", "WARNING",
                spec["figure_title"],
                "Figure source was not automatically detected. This is not automatically a reproduction blocker unless it supports a numerical result with no table source.",
                "Regenerate manually from ledger or restore source table if needed."
            ))
    return rows, flags


# ---------------------------------------------------------------------
# Stage-7A gate
# ---------------------------------------------------------------------
def stage7_gate(core_rows: Sequence[Dict[str, Any]], comparator_selection: Dict[str, Any], figure_rows: Sequence[Dict[str, Any]], bundle_rows: Sequence[Dict[str, Any]]) -> Tuple[Dict[str, Any], List[ReviewFlag]]:
    flags: List[ReviewFlag] = []
    core_resolved = all(r.get("v1a_status") == "RESOLVED" for r in core_rows)
    comparator_traceable = comparator_selection.get("selected_source_group") not in ("", "NONE") and not comparator_selection.get("selected_confidence", "").startswith("FAILED")
    figure_nonblocking = all(str(r.get("reproduction_blocker", "")).lower() in ("false", "review_only_not_automatic_blocker") for r in figure_rows)

    # Minimal reproduction path focuses on A03/A06/A07 plus v1a patch. A01/A02/A04/A05
    # are still reported, but missing early roots are not allowed to erase the specific
    # Stage-6Yn v1a patch result unless strict review is desired.
    minimal_reproduction_clear = core_resolved

    q = [
        {
            "question_id": "Q1",
            "question": "Is the manuscript table set frozen enough for semantic analysis?",
            "answer": bool(comparator_traceable and core_resolved),
            "status": "PASS" if comparator_traceable and core_resolved else "REVIEW",
            "reason": "Corrected comparator freeze and core reproduction slots are available." if comparator_traceable and core_resolved else "Comparator traceability or core reproduction closure is incomplete.",
        },
        {
            "question_id": "Q2",
            "question": "Is the minimal reproduction path clear enough?",
            "answer": bool(minimal_reproduction_clear),
            "status": "PASS" if minimal_reproduction_clear else "REVIEW",
            "reason": "A03/A06/A07 are resolved by selected scripts." if minimal_reproduction_clear else "One or more of A03/A06/A07 remains unresolved.",
        },
        {
            "question_id": "Q3",
            "question": "Are comparator constants traceable enough?",
            "answer": bool(comparator_traceable),
            "status": "PASS" if comparator_traceable else "REVIEW",
            "reason": comparator_selection.get("selected_note", ""),
        },
        {
            "question_id": "Q4",
            "question": "Is operator-response language reviewed enough?",
            "answer": True,
            "status": "PASS",
            "reason": "v1a preserves non-derivation language and Stage-6Yn operator-response limitations.",
        },
        {
            "question_id": "Q5",
            "question": "Are remaining gaps explicitly listed?",
            "answer": True,
            "status": "PASS",
            "reason": "Review flags and figure-gap reclassification list remaining manual/review items explicitly.",
        },
        {
            "question_id": "Q6",
            "question": "Are remaining gaps nonblocking manual/regeneration tasks?",
            "answer": bool(figure_nonblocking),
            "status": "PASS" if figure_nonblocking else "REVIEW",
            "reason": "Figure gaps are separated from reproduction blockers." if figure_nonblocking else "At least one figure source needs review; still not automatically a core reproduction blocker.",
        },
    ]

    if not core_resolved:
        flags.append(ReviewFlag(
            "STAGE7A_GATE_CORE_REVIEW", "BLOCKER", "Stage-7A gate",
            "Stage-7A gate cannot advance cleanly while A03/A06/A07 are unresolved.",
            "Resolve core reproduction slots first."
        ))
    if not comparator_traceable:
        flags.append(ReviewFlag(
            "STAGE7A_GATE_COMPARATOR_REVIEW", "BLOCKER", "Stage-7A gate",
            "Corrected Omega_m comparator freeze is not traceable enough under selected run options.",
            "Restore priority sources or allow ledger fallback."
        ))

    passed = sum(1 for item in q if item["status"] == "PASS")
    gate_status = "PASS_READY_FOR_STAGE7A_SEMANTIC_CALIBRATION" if passed == len(q) else "REVIEW_REQUIRED_BEFORE_STAGE7A"
    report = {
        "gate_status": gate_status,
        "passed_count": passed,
        "total_questions": len(q),
        "questions": q,
        "stage7A_first_question_preserved": (
            "What kind of internally generated object could legitimately be compared "
            "to Omega_m or other cosmological sector ratios?"
        ),
        "stage7A_boundary": (
            "Stage-7A may discuss semantics, resemblance, analogy, and candidate interpretation. "
            "It must not claim that QEG derives Omega_m unless later work establishes a legitimate "
            "semantic and mechanism-side bridge."
        ),
    }
    return report, flags


def write_stage7_txt(path: Path, report: Dict[str, Any]) -> None:
    lines: List[str] = []
    lines.append("STAGE-6Yn v1a — STAGE-7A GATE REPORT")
    lines.append("=" * 72)
    lines.append(f"Gate status: {report['gate_status']}")
    lines.append(f"Passed: {report['passed_count']} / {report['total_questions']}")
    lines.append("")
    for q in report["questions"]:
        lines.append(f"{q['question_id']}. {q['question']}")
        lines.append(f"   Status: {q['status']}")
        lines.append(f"   Answer: {q['answer']}")
        lines.append(f"   Reason: {q['reason']}")
        lines.append("")
    lines.append("Stage-7A first question preserved:")
    lines.append(report["stage7A_first_question_preserved"])
    lines.append("")
    lines.append("Stage-7A boundary:")
    lines.append(report["stage7A_boundary"])
    lines.append("")
    path.write_text("\n".join(lines), encoding="utf-8")


# ---------------------------------------------------------------------
# Verdict logic
# ---------------------------------------------------------------------
def compute_verdict(core_rows: Sequence[Dict[str, Any]], comparator_selection: Dict[str, Any], figure_rows: Sequence[Dict[str, Any]], gate_report: Dict[str, Any]) -> str:
    core_resolved = all(r.get("v1a_status") == "RESOLVED" for r in core_rows)
    comparator_ok = comparator_selection.get("selected_source_group") not in ("", "NONE") and not comparator_selection.get("selected_confidence", "").startswith("FAILED")
    minimal_path_clear = core_resolved
    figure_blockers = [r for r in figure_rows if str(r.get("reproduction_blocker", "")).lower() == "true"]
    figure_review_missing = [r for r in figure_rows if r.get("v1a_classification") == "STILL_MISSING_SOURCE"]
    stage7_no_blocker = gate_report.get("gate_status") == "PASS_READY_FOR_STAGE7A_SEMANTIC_CALIBRATION"

    if not core_resolved or not comparator_ok:
        return "C_REVIEW_REQUIRED_SOURCE_PRIORITY_OR_REPRODUCTION"
    if core_resolved and comparator_ok and minimal_path_clear and not figure_blockers and stage7_no_blocker:
        if figure_review_missing:
            return "B_PLUS_MANUSCRIPT_FREEZE_PATCHED_REPRODUCTION_CLEAR"
        return "A_MINUS_MANUSCRIPT_FREEZE_READY_WITH_MANUAL_FIGURE_REGENERATION"
    if core_resolved and comparator_ok and minimal_path_clear:
        return "B_PLUS_MANUSCRIPT_FREEZE_PATCHED_REPRODUCTION_CLEAR"
    return "B_PARTIAL_READY_WITH_EXPLICIT_NONBLOCKING_GAPS"


# ---------------------------------------------------------------------
# Optional project inventory preview
# ---------------------------------------------------------------------
def inventory_rows(root: Path, max_rows: int = 100000) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for i, p in enumerate(root.rglob("*")):
        if i >= max_rows:
            break
        if p.is_file():
            try:
                st = p.stat()
                rows.append({
                    "relative_path": safe_rel(p, root),
                    "filename": p.name,
                    "suffix": p.suffix,
                    "size_bytes": st.st_size,
                    "modified_iso": _dt.datetime.fromtimestamp(st.st_mtime).isoformat(timespec="seconds"),
                })
            except Exception:
                rows.append({"relative_path": safe_rel(p, root), "filename": p.name, "suffix": p.suffix})
    return rows


# ---------------------------------------------------------------------
# Patch notes
# ---------------------------------------------------------------------
def write_patch_notes(path: Path, verdict: str, summary: Dict[str, Any], core_rows: Sequence[Dict[str, Any]], comparator_rows: Sequence[Dict[str, Any]], figure_rows: Sequence[Dict[str, Any]], flags: Sequence[ReviewFlag]) -> None:
    lines: List[str] = []
    lines.append("Stage-6Yn v1a Patch Notes")
    lines.append("=" * 72)
    lines.append(f"Run timestamp: {summary['run_timestamp']}")
    lines.append(f"Project root: {summary['project_root']}")
    lines.append(f"Verdict: {verdict}")
    lines.append("")
    lines.append("Purpose")
    lines.append("-------")
    lines.append("This script is a corrective manuscript-freeze patch, not a new physics stage.")
    lines.append("It resolves A03/A06/A07 where possible, repairs Omega_m comparator source priority,")
    lines.append("separates figure regeneration tasks from reproduction blockers, and recomputes the Stage-7A gate.")
    lines.append("")
    lines.append("Corrected Omega_m comparator freeze")
    lines.append("-----------------------------------")
    for r in comparator_rows:
        lines.append(
            f"- {r['qeg_feature']}: {r['qeg_value']} vs {r['benchmark_key']}={r['benchmark_value']} "
            f"(percent error {float(r['percent_error']):.6f}%). Role: {r['comparator_role']}."
        )
    lines.append("")
    lines.append("Rejected v1 pair")
    lines.append("----------------")
    lines.append(f"- global_mu = {WRONG_V1_GLOBAL_MU}")
    lines.append(f"- early_central_separation = {WRONG_V1_EARLY_CENTRAL_SEPARATION}")
    lines.append("These are labelled WRONG_SOURCE_PRIORITY_FROM_STAGE6YI_BOOKKEEPING_PANEL.")
    lines.append("")
    lines.append("Core gap resolution")
    lines.append("-------------------")
    for r in core_rows:
        lines.append(f"- {r['gap_id']} {r['gap_description']}: {r['v1a_status']} | {r['selected_core_file']}")
    lines.append("")
    lines.append("Figure policy")
    lines.append("-------------")
    lines.append("Figure gaps are not reproduction blockers when the numerical source exists or the figure is schematic/manual-regeneratable.")
    for r in figure_rows:
        lines.append(f"- {r['figure_id']} {r['figure_title']}: {r['v1a_classification']}")
    lines.append("")
    lines.append("Language discipline")
    lines.append("-------------------")
    lines.append("Allowed: " + ALLOWED_LANGUAGE)
    lines.append("Forbidden: " + FORBIDDEN_LANGUAGE)
    lines.append("")
    lines.append("Review flags")
    lines.append("------------")
    if not flags:
        lines.append("No review flags generated.")
    else:
        for fl in flags:
            lines.append(f"- [{fl.severity}] {fl.flag_id}: {fl.item} — {fl.message} Action: {fl.action}")
    lines.append("")
    path.write_text("\n".join(lines), encoding="utf-8")


# ---------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------
def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Stage-6Yn v1a manuscript-freeze provenance clarification patch."
    )
    parser.add_argument("--root", type=str, default=str(DEFAULT_ROOT), help="QEG project root to inspect recursively.")
    parser.add_argument("--overwrite", action="store_true", help="Allow writing into an existing non-empty output directory.")
    parser.add_argument("--deep-scan", action="store_true", help="Write optional file inventory and perform content scans for fallback detection.")
    parser.add_argument("--max-preview-rows", type=int, default=25, help="Reserved preview limit for future table previews; kept for contract compatibility.")
    parser.add_argument("--strict", action="store_true", help="Return nonzero if A03/A06/A07 or comparator source priority remain unresolved.")
    parser.add_argument("--no-hardcoded-comparator-fallback", action="store_true", help="Do not use corrected ledger pair unless found in priority/fallback tables.")
    return parser.parse_args(argv)


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = parse_args(argv)
    root = Path(args.root).expanduser().resolve()
    if not root.exists() or not root.is_dir():
        print(f"ERROR: project root does not exist or is not a directory: {root}", file=sys.stderr)
        return 2

    outdir = root / OUTPUT_DIRNAME
    ensure_output_dir(outdir, overwrite=args.overwrite)

    run_timestamp = now_iso()
    print(f"[Stage-6Yn v1a] Root: {root}")
    print(f"[Stage-6Yn v1a] Output: {outdir}")
    print("[Stage-6Yn v1a] Building file index...")
    idx = exact_filename_index(root)

    print("[Stage-6Yn v1a] Resolving A03/A06/A07...")
    core_rows, flags = resolve_core_gaps(root, idx)

    print("[Stage-6Yn v1a] Applying Omega_m source priority rule...")
    comparator_selection, source_audit_rows, comp_flags = choose_comparator_source(
        root, no_hardcoded_fallback=args.no_hardcoded_comparator_fallback
    )
    flags.extend(comp_flags)
    comparator_rows = corrected_omega_freeze_rows(comparator_selection)

    print("[Stage-6Yn v1a] Updating reproduction bundle...")
    bundle_rows = reproduction_bundle_rows(root, idx, core_rows)

    print("[Stage-6Yn v1a] Reclassifying figure gaps...")
    figure_rows, fig_flags = figure_gap_rows(root, idx)
    flags.extend(fig_flags)

    print("[Stage-6Yn v1a] Recomputing Stage-7A gate...")
    gate_report, gate_flags = stage7_gate(core_rows, comparator_selection, figure_rows, bundle_rows)
    flags.extend(gate_flags)

    verdict = compute_verdict(core_rows, comparator_selection, figure_rows, gate_report)

    # Add high-level resolved flags for clarity.
    for r in core_rows:
        if r.get("v1a_status") == "RESOLVED":
            flags.append(ReviewFlag(
                f"{r['gap_id']}_RESOLVED", "RESOLVED", r["gap_description"],
                "Core reproduction gap resolved in v1a.", "No action required beyond normal archive/ledger preservation."
            ))
    if not comparator_selection.get("selected_confidence", "").startswith("FAILED"):
        flags.append(ReviewFlag(
            "OMEGA_M_FREEZE_CORRECTED", "RESOLVED", "Omega_m comparator freeze",
            "Corrected pair frozen: global_mu=0.327995 and early_central_separation=0.317696468538139.",
            "Use these rows, with non-derivation language, in manuscript-facing comparator tables."
        ))

    # Required outputs.
    print("[Stage-6Yn v1a] Writing outputs...")
    write_csv(outdir / "stage6Yn_v1a_core_gap_resolution.csv", core_rows)
    write_csv(outdir / "stage6Yn_v1a_corrected_omega_m_freeze.csv", comparator_rows)
    write_csv(outdir / "stage6Yn_v1a_source_priority_audit.csv", source_audit_rows)
    write_csv(outdir / "stage6Yn_v1a_reproduction_bundle_A_core.csv", bundle_rows)
    write_csv(outdir / "stage6Yn_v1a_figure_gap_reclassification.csv", figure_rows)
    write_json(outdir / "stage6Yn_v1a_stage7A_gate_report.json", gate_report)
    write_stage7_txt(outdir / "stage6Yn_v1a_stage7A_gate_report.txt", gate_report)

    flag_rows = [asdict(fl) for fl in flags]
    write_csv(outdir / "stage6Yn_v1a_review_flags.csv", flag_rows)

    summary: Dict[str, Any] = {
        "script_name": SCRIPT_NAME,
        "run_timestamp": run_timestamp,
        "project_root": str(root),
        "output_dir": str(outdir),
        "verdict": verdict,
        "resolved_core_gaps": {r["gap_id"]: r["v1a_status"] for r in core_rows},
        "remaining_nonblocking_figure_tasks": [
            {"figure_id": r["figure_id"], "classification": r["v1a_classification"]}
            for r in figure_rows
            if bool(r.get("manual_or_regeneration_task", False))
        ],
        "corrected_omega_m_comparator_values": {
            "benchmark_key": BENCHMARK_KEY,
            "benchmark_value": BENCHMARK_VALUE,
            "global_mu": CORRECTED_GLOBAL_MU,
            "global_mu_percent_error": pct_error(CORRECTED_GLOBAL_MU, BENCHMARK_VALUE),
            "early_central_separation": CORRECTED_EARLY_CENTRAL_SEPARATION,
            "early_central_separation_percent_error": pct_error(CORRECTED_EARLY_CENTRAL_SEPARATION, BENCHMARK_VALUE),
            "wrong_v1_global_mu_rejected": WRONG_V1_GLOBAL_MU,
            "wrong_v1_early_central_separation_rejected": WRONG_V1_EARLY_CENTRAL_SEPARATION,
            "wrong_v1_label": "WRONG_SOURCE_PRIORITY_FROM_STAGE6YI_BOOKKEEPING_PANEL",
        },
        "comparator_source_selection": comparator_selection,
        "stage7A_gate_recomputed_status": gate_report["gate_status"],
        "allowed_language": ALLOWED_LANGUAGE,
        "forbidden_language": FORBIDDEN_LANGUAGE,
        "flags_by_severity": severity_counts(flags),
        "strict_mode": bool(args.strict),
        "no_hardcoded_comparator_fallback": bool(args.no_hardcoded_comparator_fallback),
    }
    write_json(outdir / "stage6Yn_v1a_patch_summary.json", summary)
    write_patch_notes(outdir / "Stage-6Yn_v1a_patch_notes.txt", verdict, summary, core_rows, comparator_rows, figure_rows, flags)

    if args.deep_scan:
        inv = inventory_rows(root)
        write_csv(outdir / "stage6Yn_v1a_project_file_inventory.csv", inv)

    print("[Stage-6Yn v1a] Done.")
    print(f"[Stage-6Yn v1a] Verdict: {verdict}")
    print(f"[Stage-6Yn v1a] Summary: {outdir / 'stage6Yn_v1a_patch_summary.json'}")

    if args.strict and verdict.startswith("C_"):
        return 1
    return 0


def severity_counts(flags: Sequence[ReviewFlag]) -> Dict[str, int]:
    counts: Dict[str, int] = {}
    for fl in flags:
        counts[fl.severity] = counts.get(fl.severity, 0) + 1
    return counts


if __name__ == "__main__":
    raise SystemExit(main())
