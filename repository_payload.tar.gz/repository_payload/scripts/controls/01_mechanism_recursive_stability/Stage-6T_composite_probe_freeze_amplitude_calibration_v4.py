#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
========================================================================
Quantum-Emergent Gravity
Stage-6T: Composite Probe Freeze + Amplitude Calibration — v4
Author: Arturo Ortiz-Tapia / generated support script
Build date: 2026-05-06
========================================================================

Purpose
-------
Stage-6T v4 is a narrow verification/refinement pass after v3.
It does NOT broaden the theory and does NOT introduce new response modes.

It specifically tests whether the promising v3 composite signal survives when:

1) the best v3 composite probe PAIRS are frozen;
2) suspicious downstream-predicted fields are removed, especially rho_predicted;
3) only true upstream/provenance source fields are admitted;
4) global scale/offset calibration is performed explicitly and reported;
5) promotion requires positive calibrated R^2 AND family-stable amplitudes.

Core discipline
---------------
- rho(s) is used only as a frozen evaluation/calibration reference.
- rho(s) is NEVER used as an admissible target basis mode.
- E(s), C(s) remain frozen from Stage-6Q; centers are not refit.
- v4 freezes source probes selected from v3; it is not an unrestricted search.
- downstream predicted fields are excluded by name/path audit.
- no cosmology/spacetime interpretation is performed.

Expected v3 input
-----------------
metric_stage_6T_outputs/source_observable_audit_probe_construction_v3/
    composite_probe_tests.csv
    source_observable_audit.csv
    stage6T_summary.json

Main outputs
------------
metric_stage_6T_outputs/composite_probe_freeze_amplitude_calibration_v4/
    v4_frozen_composite_calibration_tests.csv
    v4_family_amplitude_stability.csv
    v4_candidate_freeze_list.csv
    v4_exclusion_audit.csv
    stage6T_v4_summary.json
    stage6T_v4_interpretation_notes.txt

Plots
-----
By default v4 produces no plots. If the verdict improves to B, it writes one
single confirmation plot:
    plot_v4_best_calibrated_composite.png

Spyder usage
------------
%runfile /home/dakini/Downloads/010-Quantum_Emergent_Gravity/metric_stage_6T_scripts/Stage-6T_composite_probe_freeze_amplitude_calibration_v4.py --wdir
"""

from __future__ import annotations

import json
import os
import re
import sys
import glob
import warnings
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

try:
    from scipy.interpolate import interp1d
    from scipy.ndimage import gaussian_filter1d
except Exception:  # pragma: no cover
    interp1d = None
    gaussian_filter1d = None

EPS = 1.0e-12
STAGE = "6T"
RUN_NAME = "composite_probe_freeze_amplitude_calibration_v4"
V3_RUN_NAME = "source_observable_audit_probe_construction_v3"


# ---------------------------------------------------------------------
# Small numerical utilities
# ---------------------------------------------------------------------

def discover_project_root() -> Path:
    env_root = os.environ.get("QEG_PROJECT_ROOT", "").strip()
    candidates = []
    if env_root:
        candidates.append(Path(env_root).expanduser())
    candidates += [
        Path.cwd(),
        Path(__file__).resolve().parent,
        Path("/home/dakini/Downloads/010-Quantum_Emergent_Gravity"),
    ]
    markers = ["metric_stage_6Q_outputs", "metric_stage_6T_outputs", "metric_stage_6O_outputs"]
    for base in candidates:
        for p in [base] + list(base.parents):
            if any((p / m).exists() for m in markers):
                return p
    return Path.cwd()


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def read_csv_safe(path: Path) -> Optional[pd.DataFrame]:
    try:
        return pd.read_csv(path)
    except Exception:
        return None


def safe_float(x, default=np.nan) -> float:
    try:
        if pd.isna(x):
            return default
        return float(x)
    except Exception:
        return default


def normalize_grid(s: np.ndarray) -> np.ndarray:
    s = np.asarray(s, dtype=float)
    mask = np.isfinite(s)
    if not mask.any():
        return np.linspace(0.0, 1.0, len(s))
    mn = np.nanmin(s)
    mx = np.nanmax(s)
    if abs(mx - mn) < EPS:
        return np.linspace(0.0, 1.0, len(s))
    return (s - mn) / (mx - mn)


def zscore(y: np.ndarray) -> np.ndarray:
    y = np.asarray(y, dtype=float)
    y = np.where(np.isfinite(y), y, 0.0)
    return (y - np.mean(y)) / (np.std(y) + EPS)


def l2_normalize(y: np.ndarray) -> np.ndarray:
    y = np.asarray(y, dtype=float)
    y = np.where(np.isfinite(y), y, 0.0)
    return y / (np.sqrt(np.sum(y * y)) + EPS)


def mass_normalize(y: np.ndarray) -> np.ndarray:
    y = np.asarray(y, dtype=float)
    y = np.where(np.isfinite(y), y, 0.0)
    return y / (np.sum(np.abs(y)) + EPS)


def corrcoef(a: np.ndarray, b: np.ndarray) -> float:
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    mask = np.isfinite(a) & np.isfinite(b)
    if mask.sum() < 3:
        return np.nan
    aa = a[mask]
    bb = b[mask]
    if np.std(aa) < EPS or np.std(bb) < EPS:
        return np.nan
    return float(np.corrcoef(aa, bb)[0, 1])


def r2_score(y: np.ndarray, yhat: np.ndarray) -> float:
    y = np.asarray(y, dtype=float)
    yhat = np.asarray(yhat, dtype=float)
    mask = np.isfinite(y) & np.isfinite(yhat)
    if mask.sum() < 3:
        return np.nan
    yy = y[mask]
    pp = yhat[mask]
    denom = np.sum((yy - np.mean(yy)) ** 2)
    if denom < EPS:
        return np.nan
    return float(1.0 - np.sum((yy - pp) ** 2) / denom)


def rmse(y: np.ndarray, yhat: np.ndarray) -> float:
    y = np.asarray(y, dtype=float)
    yhat = np.asarray(yhat, dtype=float)
    mask = np.isfinite(y) & np.isfinite(yhat)
    if mask.sum() == 0:
        return np.nan
    return float(np.sqrt(np.mean((y[mask] - yhat[mask]) ** 2)))


def interp_to_grid(s_old: np.ndarray, y_old: np.ndarray, s_new: np.ndarray) -> np.ndarray:
    s_old = normalize_grid(np.asarray(s_old, dtype=float))
    y_old = np.asarray(y_old, dtype=float)
    good = np.isfinite(s_old) & np.isfinite(y_old)
    if good.sum() < 3:
        return np.zeros_like(s_new, dtype=float)
    order = np.argsort(s_old[good])
    xs = s_old[good][order]
    ys = y_old[good][order]
    ux, idx = np.unique(xs, return_index=True)
    uy = ys[idx]
    if len(ux) < 3:
        return np.zeros_like(s_new, dtype=float)
    if interp1d is not None:
        f = interp1d(ux, uy, kind="linear", bounds_error=False, fill_value=(uy[0], uy[-1]))
        return np.asarray(f(s_new), dtype=float)
    return np.interp(s_new, ux, uy)


def gaussian(s: np.ndarray, mu: float, sigma: float) -> np.ndarray:
    return np.exp(-0.5 * ((s - mu) / max(float(sigma), 1.0e-6)) ** 2)


def skewed_central(s: np.ndarray, mu: float, sigma: float, skew: float = -0.25) -> np.ndarray:
    base = gaussian(s, mu, sigma)
    skew_factor = np.clip(1.0 + skew * (s - mu) / max(float(sigma), 1.0e-6), 0.0, None)
    return base * skew_factor


def smooth(y: np.ndarray, sigma: float = 1.0) -> np.ndarray:
    y = np.asarray(y, dtype=float)
    if gaussian_filter1d is not None:
        return gaussian_filter1d(y, sigma=sigma, mode="nearest")
    k = max(3, int(2 * sigma + 1))
    kernel = np.ones(k) / k
    return np.convolve(y, kernel, mode="same")


def deriv(y: np.ndarray, s: np.ndarray) -> np.ndarray:
    if len(y) < 3:
        return np.zeros_like(y)
    return np.gradient(np.asarray(y, dtype=float), np.asarray(s, dtype=float) + EPS)


def second_deriv(y: np.ndarray, s: np.ndarray) -> np.ndarray:
    return deriv(deriv(y, s), s)


def positive_part(y: np.ndarray) -> np.ndarray:
    return np.maximum(np.asarray(y, dtype=float), 0.0)


def negative_part_abs(y: np.ndarray) -> np.ndarray:
    return np.maximum(-np.asarray(y, dtype=float), 0.0)


# ---------------------------------------------------------------------
# Canonical basis and source fields
# ---------------------------------------------------------------------

@dataclass
class CanonicalBasis:
    s: np.ndarray
    E: np.ndarray
    C: np.ndarray
    rho_reference: np.ndarray
    source: str
    params: Dict[str, float]


@dataclass
class SourceField:
    name: str
    family: str
    s: np.ndarray
    values: np.ndarray
    origin: str
    constructed: bool = False


def find_first_existing(root: Path, patterns: List[str]) -> Optional[Path]:
    hits: List[str] = []
    for pat in patterns:
        hits.extend(glob.glob(str(root / pat), recursive=True))
    hits = sorted(set(hits))
    return Path(hits[0]) if hits else None


def load_canonical_basis(root: Path, n_default: int = 361) -> CanonicalBasis:
    curve_path = find_first_existing(root, [
        "metric_stage_6Q_outputs/**/stage6Q_canonical_curve.csv",
        "metric_stage_6Q_outputs/**/canonical_curve*.csv",
        "metric_stage_6Q_outputs/**/*.csv",
    ])
    params = {
        "mu_early": 0.150,
        "sigma_early": 0.040,
        "mu_central": 0.536,
        "sigma_central": 0.120,
        "central_skew": -0.25,
        "early_mass_fraction": 0.27,
        "central_mass_fraction": 0.73,
    }
    # Optional parameter upgrade from Stage-6Q summaries.
    for hit in glob.glob(str(root / "metric_stage_6Q_outputs/**/*.csv"), recursive=True):
        df = read_csv_safe(Path(hit))
        if df is None or df.empty:
            continue
        lower = {c.lower(): c for c in df.columns}
        for key in list(params):
            if key.lower() in lower:
                val = safe_float(df[lower[key.lower()]].iloc[0])
                if np.isfinite(val):
                    params[key] = val
        if {"parameter", "value"}.issubset(set(lower)):
            for _, row in df.iterrows():
                k = str(row[lower["parameter"]]).strip().lower()
                v = safe_float(row[lower["value"]])
                for key in params:
                    if k == key.lower() and np.isfinite(v):
                        params[key] = v

    if curve_path is not None:
        df = read_csv_safe(curve_path)
        if df is not None and len(df) >= 12:
            lower = {c.lower(): c for c in df.columns}
            s_col = next((lower[c] for c in ["s", "s_normalized", "s_norm", "intrinsic_s"] if c in lower), None)
            s = normalize_grid(df[s_col].to_numpy()) if s_col else np.linspace(0.0, 1.0, len(df))
            E_col = next((c for c in df.columns if c.lower() in ["e", "e_s", "early", "early_component", "e_component"]), None)
            C_col = next((c for c in df.columns if c.lower() in ["c", "c_s", "central", "central_component", "c_component"]), None)
            rho_col = next((c for c in df.columns if c.lower() in ["rho", "rho_s", "rho_canonical", "canonical_rho", "rho_reference", "fit"]), None)
            if E_col is not None and C_col is not None:
                E = np.asarray(df[E_col], dtype=float)
                C = np.asarray(df[C_col], dtype=float)
                rho = np.asarray(df[rho_col], dtype=float) if rho_col else E + C
                return CanonicalBasis(s=s, E=l2_normalize(E), C=l2_normalize(C), rho_reference=rho,
                                      source=str(curve_path), params=params)
            if rho_col is not None:
                rho = np.asarray(df[rho_col], dtype=float)
                E = gaussian(s, params["mu_early"], params["sigma_early"])
                C = skewed_central(s, params["mu_central"], params["sigma_central"], params["central_skew"])
                return CanonicalBasis(s=s, E=l2_normalize(E), C=l2_normalize(C), rho_reference=rho,
                                      source=str(curve_path) + " [rho evaluation only]", params=params)

    s = np.linspace(0.0, 1.0, n_default)
    E = gaussian(s, params["mu_early"], params["sigma_early"])
    C = skewed_central(s, params["mu_central"], params["sigma_central"], params["central_skew"])
    rho = params["early_mass_fraction"] * mass_normalize(E) + params["central_mass_fraction"] * mass_normalize(C)
    return CanonicalBasis(s=s, E=l2_normalize(E), C=l2_normalize(C), rho_reference=rho,
                          source="fallback_frozen_stage6Q_constants", params=params)


def infer_s_col(df: pd.DataFrame) -> Optional[str]:
    lower = {c.lower(): c for c in df.columns}
    for name in ["s", "s_normalized", "s_norm", "intrinsic_s", "arc_length_s", "stage6_s"]:
        if name in lower:
            return lower[name]
    return None


def infer_family_col(df: pd.DataFrame) -> Optional[str]:
    for c in df.columns:
        if c.lower() in ["family", "fit", "fit_id", "pdg_family", "stage6_family"]:
            return c
    return None


def canonical_family_name(x) -> str:
    txt = str(x).upper()
    for fam in ["BARI", "NUFIT", "VALENCIA"]:
        if fam in txt:
            return fam
    return "POOLED"


def is_suspicious_path_or_name(text: str) -> Tuple[bool, str]:
    """Return whether a source should be excluded from v4 and why."""
    t = str(text).lower()
    suspicious_tokens = [
        "rho_predicted",
        "predicted",
        "prediction",
        "canonical_rho",
        "rho_canonical",
        "stage6q_canonical",
        "canonical_law_extraction",
        "synthetic",
        "internal_control",
        "metric_stage_6t_outputs",
    ]
    for tok in suspicious_tokens:
        if tok in t:
            return True, f"excluded_token:{tok}"
    # v4 is intentionally conservative: predictions from universality tests are not source data.
    if "family_universality_predictions" in t:
        return True, "excluded_downstream_family_universality_predictions"
    return False, "admitted"


def is_allowed_upstream_path(path: Path) -> bool:
    p = str(path).lower()
    allowed = [
        "metric_stage_6h_outputs",
        "metric_stage_6o_outputs",
        "provenance_branch",
        "family_profile_rebuild",
        "family_aware_profile",
        "label_repair",
    ]
    # Exclude current/future mechanism stages as source reservoirs.
    disallowed = [
        "metric_stage_6t_outputs",
        "metric_stage_6q_outputs",
        "metric_stage_6r_outputs",
        "metric_stage_6s_outputs",
        "metric_stage_6p_outputs/family_universality_two_lobe_test",
    ]
    if any(tok in p for tok in disallowed):
        return False
    return any(tok in p for tok in allowed)


def infer_value_cols_v4(df: pd.DataFrame) -> List[str]:
    """Conservative source columns only. Exclude explicit predictions/canonical fits."""
    tokens = ["kappa", "source", "count", "rho_like", "density", "curvature", "observable", "value"]
    out: List[str] = []
    for c in df.columns:
        lc = c.lower()
        if lc in ["s", "s_normalized", "s_norm", "family", "fit", "fit_id", "npz_file", "stage", "label"]:
            continue
        bad, _ = is_suspicious_path_or_name(lc)
        if bad:
            continue
        if not pd.api.types.is_numeric_dtype(df[c]):
            continue
        if any(tok in lc for tok in tokens):
            out.append(c)
    return out


def load_raw_source_fields_v4(root: Path, basis: CanonicalBasis) -> Tuple[List[SourceField], pd.DataFrame]:
    """Load only conservative upstream/provenance source fields."""
    patterns = [
        "metric_stage_6H_outputs/**/*.csv",
        "metric_stage_6O_outputs/**/*.csv",
    ]
    candidates: List[Path] = []
    for pat in patterns:
        candidates.extend(Path(p) for p in glob.glob(str(root / pat), recursive=True))
    candidates = sorted(set(candidates))

    fields: List[SourceField] = []
    audit_rows = []
    for path in candidates:
        if not is_allowed_upstream_path(path):
            audit_rows.append({"path": str(path), "status": "excluded", "reason": "not_allowed_upstream_or_provenance_path"})
            continue
        bad_path, reason_path = is_suspicious_path_or_name(str(path))
        if bad_path:
            audit_rows.append({"path": str(path), "status": "excluded", "reason": reason_path})
            continue
        df = read_csv_safe(path)
        if df is None or df.empty or len(df) < 8:
            audit_rows.append({"path": str(path), "status": "excluded", "reason": "unreadable_or_too_short"})
            continue
        s_col = infer_s_col(df)
        fam_col = infer_family_col(df)
        val_cols = infer_value_cols_v4(df)
        if s_col is None or not val_cols:
            audit_rows.append({"path": str(path), "status": "excluded", "reason": "missing_s_or_source_value_columns"})
            continue
        admitted_cols = []
        for vc in val_cols:
            bad_col, reason_col = is_suspicious_path_or_name(vc)
            if bad_col:
                continue
            admitted_cols.append(vc)
        if not admitted_cols:
            audit_rows.append({"path": str(path), "status": "excluded", "reason": "all_value_columns_suspicious"})
            continue
        for vc in admitted_cols:
            if fam_col:
                for fam_value, g in df.groupby(fam_col):
                    fam = canonical_family_name(fam_value)
                    if len(g) < 8:
                        continue
                    y = interp_to_grid(g[s_col].to_numpy(), g[vc].to_numpy(), basis.s)
                    if np.std(y) > EPS:
                        fields.append(SourceField(
                            name=f"constructed_v4/{path.parent.name}/{path.stem}:{vc}::raw_z",
                            family=fam,
                            s=basis.s.copy(),
                            values=zscore(y),
                            origin=str(path),
                            constructed=False,
                        ))
            else:
                y = interp_to_grid(df[s_col].to_numpy(), df[vc].to_numpy(), basis.s)
                if np.std(y) > EPS:
                    fields.append(SourceField(
                        name=f"constructed_v4/{path.parent.name}/{path.stem}:{vc}::raw_z",
                        family="POOLED",
                        s=basis.s.copy(),
                        values=zscore(y),
                        origin=str(path),
                        constructed=False,
                    ))
        audit_rows.append({
            "path": str(path),
            "status": "admitted",
            "reason": "upstream_provenance_source",
            "s_col": s_col,
            "family_col": fam_col,
            "value_cols": ";".join(admitted_cols),
        })

    # Deduplicate.
    seen = set()
    unique = []
    for f in fields:
        key = (f.name, f.family)
        if key not in seen:
            seen.add(key)
            unique.append(f)
    return unique, pd.DataFrame(audit_rows)


def base_name_v3_to_v4(name: str) -> str:
    """Map v3 constructed names to v4 naming convention for lookup."""
    n = str(name)
    # v3: constructed_v3/<parent>/<stem>:<col>::<variant>
    # v4 uses constructed_v4/<parent>/<stem>:<col>::<variant>
    n = n.replace("constructed_v3/", "constructed_v4/")
    return n


def constructed_probe_variants_v4(field: SourceField, basis: CanonicalBasis) -> List[SourceField]:
    """Construct only the v3 families that v4 needs to freeze/evaluate."""
    s = basis.s
    x0 = zscore(field.values)
    dx = zscore(deriv(smooth(x0, 1.0), s))
    ddx = zscore(second_deriv(smooth(x0, 1.2), s))
    edge_gate = np.exp(-s / 0.12)
    early_shell = ((s >= 0.08) & (s <= 0.23)).astype(float)
    bulk_shell = ((s >= 0.35) & (s <= 0.72)).astype(float)
    center_gate = gaussian(s, basis.params["mu_central"], max(0.10, basis.params["sigma_central"]))
    right_gate = np.exp(-(1.0 - s) / 0.12)
    absx = zscore(np.abs(x0))
    signed_log = zscore(np.sign(x0) * np.log1p(np.abs(x0)))

    variants: Dict[str, np.ndarray] = {
        "raw_z": x0,
        "abs": absx,
        "positive_part": zscore(positive_part(x0)),
        "negative_part_abs": zscore(negative_part_abs(x0)),
        "gradient": dx,
        "abs_gradient": zscore(np.abs(dx)),
        "curvature_abs": zscore(np.abs(ddx)),
        "edge_gated": zscore(x0 * edge_gate),
        "center_gated": zscore(x0 * center_gate),
        "edge_minus_center": zscore(x0 * edge_gate - x0 * center_gate),
        "left_right_difference": zscore(x0 * edge_gate - x0 * right_gate),
        "gradient_edge_gated": zscore(dx * edge_gate),
        "gradient_center_gated": zscore(dx * center_gate),
        "abs_times_edge": zscore(absx * edge_gate),
        "abs_times_center": zscore(absx * center_gate),
        # v3 additions.
        "signed_log": signed_log,
        "signed_log_gradient": zscore(deriv(smooth(signed_log, 1.0), s)),
        "early_shell_gated": zscore(x0 * early_shell),
        "bulk_shell_gated": zscore(x0 * bulk_shell),
        "early_minus_bulk_shell": zscore(x0 * early_shell - x0 * bulk_shell),
        "smooth_sigma_2": zscore(smooth(x0, 2.0)),
        "smooth_sigma_5": zscore(smooth(x0, 5.0)),
        "smooth_sigma_9": zscore(smooth(x0, 9.0)),
    }
    # Build names by stripping ::raw_z from raw field.
    prefix = field.name.rsplit("::", 1)[0]
    out: List[SourceField] = []
    for suffix, arr in variants.items():
        arr = np.asarray(arr, dtype=float)
        if np.isfinite(arr).sum() >= 8 and np.std(arr[np.isfinite(arr)]) > EPS:
            out.append(SourceField(
                name=f"{prefix}::{suffix}",
                family=field.family,
                s=s.copy(),
                values=zscore(arr),
                origin=field.origin + " [constructed_source_probe_v4]",
                constructed=(suffix != "raw_z"),
            ))
    return out


# ---------------------------------------------------------------------
# v3 freeze list and v4 evaluation
# ---------------------------------------------------------------------

def load_v3_composite_candidates(root: Path) -> Tuple[pd.DataFrame, Dict[str, object]]:
    v3_dir = root / "metric_stage_6T_outputs" / V3_RUN_NAME
    comp_path = v3_dir / "composite_probe_tests.csv"
    summary_path = v3_dir / "stage6T_summary.json"
    comp = read_csv_safe(comp_path)
    if comp is None:
        comp = pd.DataFrame()
    summary: Dict[str, object] = {}
    if summary_path.exists():
        try:
            summary = json.loads(summary_path.read_text(encoding="utf-8"))
        except Exception:
            summary = {}
    return comp, summary


def filter_v3_candidates(comp: pd.DataFrame, max_keep: int = 60) -> pd.DataFrame:
    if comp.empty:
        return comp.copy()
    rows = []
    for _, row in comp.sort_values("corr_to_rho_eval_only", ascending=False).iterrows():
        ep = str(row.get("early_probe", ""))
        cp = str(row.get("central_probe", ""))
        bad_e, reason_e = is_suspicious_path_or_name(ep)
        bad_c, reason_c = is_suspicious_path_or_name(cp)
        if bad_e or bad_c:
            status = "excluded"
            reason = reason_e if bad_e else reason_c
        else:
            status = "frozen_candidate"
            reason = "passed_v4_exclusion_filter"
        rr = dict(row)
        rr["v4_freeze_status"] = status
        rr["v4_filter_reason"] = reason
        rr["early_probe_v4_lookup"] = base_name_v3_to_v4(ep)
        rr["central_probe_v4_lookup"] = base_name_v3_to_v4(cp)
        rows.append(rr)
    out = pd.DataFrame(rows)
    frozen = out[out["v4_freeze_status"] == "frozen_candidate"].head(max_keep).copy()
    excluded = out[out["v4_freeze_status"] != "frozen_candidate"].copy()
    # Return frozen first, but keep excluded rows for audit downstream by attaching attrs-like? Simpler: caller saves all.
    frozen.attrs["full_filter_table"] = out
    frozen.attrs["excluded_table"] = excluded
    return frozen


def fit_channel_amplitudes_and_calibrate(rho_ref: np.ndarray, E: np.ndarray, C: np.ndarray,
                                         early_probe: np.ndarray,
                                         central_probe: np.ndarray) -> Dict[str, np.ndarray | float]:
    """Fit source-gated E/C amplitudes, then fit global scale/offset explicitly."""
    ch1 = E * zscore(early_probe)
    ch2 = C * zscore(central_probe)
    X = np.vstack([ch1, ch2]).T
    beta, *_ = np.linalg.lstsq(X, rho_ref, rcond=None)
    raw_pred = X @ beta

    # Global scale + offset calibration. This is explicitly recorded as calibration,
    # not as a new shape mode. It cannot move centers or alter source probes.
    Xcal = np.vstack([np.ones_like(raw_pred), raw_pred]).T
    cal, *_ = np.linalg.lstsq(Xcal, rho_ref, rcond=None)
    calibrated = Xcal @ cal

    return {
        "beta_early_channel": float(beta[0]),
        "beta_central_channel": float(beta[1]),
        "amp_ratio_central_to_early": float(beta[1] / (beta[0] + EPS)),
        "global_offset": float(cal[0]),
        "global_scale": float(cal[1]),
        "raw_pred": raw_pred,
        "calibrated_pred": calibrated,
        "corr_raw": corrcoef(rho_ref, raw_pred),
        "r2_raw": r2_score(rho_ref, raw_pred),
        "rmse_raw": rmse(rho_ref, raw_pred),
        "corr_calibrated": corrcoef(rho_ref, calibrated),
        "r2_calibrated": r2_score(rho_ref, calibrated),
        "rmse_calibrated": rmse(rho_ref, calibrated),
    }


def lobe_window_masses(pred: np.ndarray, basis: CanonicalBasis) -> Dict[str, float]:
    s = basis.s
    e_mask = np.abs(s - basis.params["mu_early"]) <= max(2.0 * basis.params["sigma_early"], 0.06)
    c_mask = np.abs(s - basis.params["mu_central"]) <= max(2.0 * basis.params["sigma_central"], 0.12)
    total = np.sum(np.abs(pred)) + EPS
    return {
        "early_window_mass": float(np.sum(np.abs(pred[e_mask])) / total),
        "central_window_mass": float(np.sum(np.abs(pred[c_mask])) / total),
        "abs_mass_center": float(np.sum(s * np.abs(pred)) / total),
    }


def evaluate_v4(root: Path, out_dir: Path) -> Dict[str, object]:
    basis = load_canonical_basis(root)
    rho_ref = zscore(basis.rho_reference) if np.std(basis.rho_reference) > EPS else zscore(basis.E + basis.C)
    E, C = basis.E, basis.C

    raw_fields, exclusion_audit = load_raw_source_fields_v4(root, basis)
    constructed: List[SourceField] = []
    for f in raw_fields:
        constructed.extend(constructed_probe_variants_v4(f, basis))

    # Lookup. raw_z appears twice if constructed variants include raw_z; last one is okay.
    fields = raw_fields + constructed
    lookup: Dict[Tuple[str, str], SourceField] = {(f.name, f.family): f for f in fields}

    v3_comp, v3_summary = load_v3_composite_candidates(root)
    frozen = filter_v3_candidates(v3_comp, max_keep=80)
    full_filter_table = frozen.attrs.get("full_filter_table", pd.DataFrame())

    candidate_rows = []
    calibration_rows = []
    missing_rows = []

    for _, row in frozen.iterrows():
        ep_v4 = str(row.get("early_probe_v4_lookup", ""))
        cp_v4 = str(row.get("central_probe_v4_lookup", ""))
        efam = str(row.get("early_family", "POOLED"))
        cfam = str(row.get("central_family", "POOLED"))
        fe = lookup.get((ep_v4, efam))
        fc = lookup.get((cp_v4, cfam))
        candidate_record = {
            "early_probe_v3": row.get("early_probe", ""),
            "central_probe_v3": row.get("central_probe", ""),
            "early_probe_v4": ep_v4,
            "central_probe_v4": cp_v4,
            "early_family": efam,
            "central_family": cfam,
            "v3_corr": safe_float(row.get("corr_to_rho_eval_only")),
            "v3_r2": safe_float(row.get("r2_to_rho_eval_only")),
            "lookup_status": "found" if fe is not None and fc is not None else "missing_after_v4_restriction",
        }
        candidate_rows.append(candidate_record)
        if fe is None or fc is None:
            missing_rows.append(candidate_record)
            continue
        fit = fit_channel_amplitudes_and_calibrate(rho_ref, E, C, fe.values, fc.values)
        lobes = lobe_window_masses(np.asarray(fit["calibrated_pred"], dtype=float), basis)
        calibration_rows.append({
            **candidate_record,
            "early_origin": fe.origin,
            "central_origin": fc.origin,
            "early_constructed": fe.constructed,
            "central_constructed": fc.constructed,
            "beta_early_channel": fit["beta_early_channel"],
            "beta_central_channel": fit["beta_central_channel"],
            "amp_ratio_central_to_early": fit["amp_ratio_central_to_early"],
            "global_offset": fit["global_offset"],
            "global_scale": fit["global_scale"],
            "corr_raw": fit["corr_raw"],
            "r2_raw": fit["r2_raw"],
            "rmse_raw": fit["rmse_raw"],
            "corr_calibrated": fit["corr_calibrated"],
            "r2_calibrated": fit["r2_calibrated"],
            "rmse_calibrated": fit["rmse_calibrated"],
            **lobes,
        })

    cal_df = pd.DataFrame(calibration_rows)
    cand_df = pd.DataFrame(candidate_rows)
    if not cal_df.empty:
        cal_df = cal_df.sort_values(["r2_calibrated", "corr_calibrated"], ascending=False)

    # Family stability: group same probe pair across BARI/NUFIT/VALENCIA.
    fam_rows = []
    if not cal_df.empty:
        group_cols = ["early_probe_v4", "central_probe_v4"]
        for key, g in cal_df.groupby(group_cols):
            families = sorted(set(g["early_family"]) | set(g["central_family"]))
            true_fams = sorted([f for f in families if f in ["BARI", "NUFIT", "VALENCIA"]])
            eamps = g["beta_early_channel"].to_numpy(dtype=float)
            camps = g["beta_central_channel"].to_numpy(dtype=float)
            ratios = g["amp_ratio_central_to_early"].to_numpy(dtype=float)
            r2s = g["r2_calibrated"].to_numpy(dtype=float)
            corr = g["corr_calibrated"].to_numpy(dtype=float)
            sign_stable_e = len(set(np.sign(eamps[np.isfinite(eamps)]))) <= 1 if len(eamps) else False
            sign_stable_c = len(set(np.sign(camps[np.isfinite(camps)]))) <= 1 if len(camps) else False
            e_cv = float(np.nanstd(eamps) / (abs(np.nanmean(eamps)) + EPS)) if len(eamps) else np.nan
            c_cv = float(np.nanstd(camps) / (abs(np.nanmean(camps)) + EPS)) if len(camps) else np.nan
            ratio_cv = float(np.nanstd(ratios) / (abs(np.nanmean(ratios)) + EPS)) if len(ratios) else np.nan
            family_stability_score = float(np.nanmean([
                1.0 / (1.0 + e_cv),
                1.0 / (1.0 + c_cv),
                1.0 / (1.0 + ratio_cv),
                1.0 if sign_stable_e else 0.0,
                1.0 if sign_stable_c else 0.0,
                max(0.0, np.nanmean(r2s)),
            ]))
            fam_rows.append({
                "early_probe_v4": key[0],
                "central_probe_v4": key[1],
                "n_rows": int(len(g)),
                "families_present": ";".join(true_fams),
                "has_all_true_families": set(["BARI", "NUFIT", "VALENCIA"]).issubset(set(true_fams)),
                "mean_corr_calibrated": float(np.nanmean(corr)),
                "mean_r2_calibrated": float(np.nanmean(r2s)),
                "min_r2_calibrated": float(np.nanmin(r2s)) if len(r2s) else np.nan,
                "early_amp_mean": float(np.nanmean(eamps)) if len(eamps) else np.nan,
                "central_amp_mean": float(np.nanmean(camps)) if len(camps) else np.nan,
                "early_amp_cv": e_cv,
                "central_amp_cv": c_cv,
                "ratio_cv": ratio_cv,
                "early_amp_sign_stable": bool(sign_stable_e),
                "central_amp_sign_stable": bool(sign_stable_c),
                "family_stability_score": family_stability_score,
            })
    fam_df = pd.DataFrame(fam_rows)
    if not fam_df.empty:
        fam_df = fam_df.sort_values(["has_all_true_families", "family_stability_score", "mean_r2_calibrated"], ascending=False)

    # Save tables.
    cal_df.to_csv(out_dir / "v4_frozen_composite_calibration_tests.csv", index=False)
    fam_df.to_csv(out_dir / "v4_family_amplitude_stability.csv", index=False)
    cand_df.to_csv(out_dir / "v4_candidate_freeze_list.csv", index=False)
    exclusion_audit.to_csv(out_dir / "v4_exclusion_audit.csv", index=False)
    if not full_filter_table.empty:
        full_filter_table.to_csv(out_dir / "v4_v3_candidate_filter_audit.csv", index=False)
    pd.DataFrame(missing_rows).to_csv(out_dir / "v4_missing_after_restriction.csv", index=False)

    best = cal_df.iloc[0].to_dict() if not cal_df.empty else {}
    best_family = fam_df.iloc[0].to_dict() if not fam_df.empty else {}

    best_r2 = safe_float(best.get("r2_calibrated"))
    best_corr = safe_float(best.get("corr_calibrated"))
    best_raw_r2 = safe_float(best.get("r2_raw"))
    best_scale = safe_float(best.get("global_scale"))
    best_offset = safe_float(best.get("global_offset"))

    # Promotion conditions: strong calibrated fit + non-pathological scale + family stability.
    family_stable = bool(best_family.get("has_all_true_families", False)) and \
        safe_float(best_family.get("min_r2_calibrated"), -np.inf) > 0.0 and \
        safe_float(best_family.get("family_stability_score"), 0.0) >= 0.55 and \
        bool(best_family.get("early_amp_sign_stable", False)) and \
        bool(best_family.get("central_amp_sign_stable", False))

    if cal_df.empty:
        verdict = "C_REVIEW_REQUIRED_NO_V3_COMPOSITES_SURVIVED_RESTRICTION"
    elif best_r2 > 0.45 and best_corr >= 0.85 and family_stable:
        verdict = "B_FROZEN_COMPOSITE_SOURCE_WITH_CALIBRATED_FAMILY_STABILITY"
    elif best_r2 > 0.0 and best_corr >= 0.80:
        verdict = "C_REVIEW_REQUIRED_CALIBRATED_COMPOSITE_SHAPE_SURVIVES_BUT_FAMILY_STABILITY_PENDING"
    elif best_corr >= 0.70:
        verdict = "C_REVIEW_REQUIRED_SHAPE_ONLY_AMPLITUDE_CALIBRATION_WEAK"
    else:
        verdict = "C_REVIEW_REQUIRED_V3_SIGNAL_DID_NOT_SURVIVE_STRICT_FREEZE"

    # If verdict improves, produce exactly one plot.
    plot_path = None
    if verdict.startswith("B") and not cal_df.empty:
        plot_path = out_dir / "plot_v4_best_calibrated_composite.png"
        # Rebuild best prediction for plot.
        fe = lookup.get((best["early_probe_v4"], best["early_family"]))
        fc = lookup.get((best["central_probe_v4"], best["central_family"]))
        if fe is not None and fc is not None:
            fit = fit_channel_amplitudes_and_calibrate(rho_ref, E, C, fe.values, fc.values)
            plt.figure(figsize=(9, 5))
            plt.plot(basis.s, rho_ref, label="rho reference for evaluation only", linewidth=2)
            plt.plot(basis.s, zscore(np.asarray(fit["raw_pred"], dtype=float)), label="raw frozen composite", linestyle="--")
            plt.plot(basis.s, zscore(np.asarray(fit["calibrated_pred"], dtype=float)), label="calibrated frozen composite", linewidth=2)
            plt.xlabel("intrinsic coordinate s")
            plt.ylabel("z-scored profile")
            plt.title("Stage-6T v4: best calibrated frozen composite")
            plt.legend(fontsize=8)
            plt.tight_layout()
            plt.savefig(plot_path, dpi=180)
            plt.close()

    summary = {
        "project": "Quantum-Emergent Gravity",
        "stage": "6T",
        "run_name": RUN_NAME,
        "verdict": verdict,
        "project_root": str(root),
        "output_dir": str(out_dir),
        "canonical_basis_source": basis.source,
        "v3_run_used": str(root / "metric_stage_6T_outputs" / V3_RUN_NAME),
        "discipline_rules": {
            "rho_used_as_target_mode": False,
            "rho_used_as_evaluation_reference": True,
            "global_scale_offset_calibration_explicitly_reported": True,
            "canonical_constants_refit": False,
            "downstream_predicted_fields_excluded": True,
            "cosmology_interpretation_performed": False,
            "plots_created_only_if_B_verdict": bool(plot_path),
        },
        "n_raw_upstream_provenance_fields": int(len(raw_fields)),
        "n_constructed_v4_fields": int(len(constructed)),
        "n_v3_composites_total": int(len(v3_comp)),
        "n_v3_composites_after_filter": int(len(frozen)),
        "n_v4_composites_evaluated": int(len(cal_df)),
        "best_corr_calibrated": best_corr,
        "best_r2_calibrated": best_r2,
        "best_r2_raw": best_raw_r2,
        "best_global_scale": best_scale,
        "best_global_offset": best_offset,
        "best_early_probe": best.get("early_probe_v4"),
        "best_central_probe": best.get("central_probe_v4"),
        "best_early_family": best.get("early_family"),
        "best_central_family": best.get("central_family"),
        "best_family_stability_score": safe_float(best_family.get("family_stability_score")),
        "best_family_has_all_true_families": bool(best_family.get("has_all_true_families", False)),
        "best_family_min_r2_calibrated": safe_float(best_family.get("min_r2_calibrated")),
        "interpretation": "v4 freezes v3 composite probes and tests whether the signal survives strict source filtering plus explicit amplitude calibration.",
    }
    (out_dir / "stage6T_v4_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    write_notes(out_dir, summary, cal_df, fam_df, exclusion_audit, v3_summary)
    return summary


def write_notes(out_dir: Path, summary: Dict[str, object], cal_df: pd.DataFrame,
                fam_df: pd.DataFrame, exclusion_audit: pd.DataFrame,
                v3_summary: Dict[str, object]) -> None:
    lines: List[str] = []
    lines.append("============================================================")
    lines.append("STAGE-6T v4 INTERPRETATION NOTES")
    lines.append("Project: Quantum-Emergent Gravity")
    lines.append("Stage: 6T v4 — Composite Probe Freeze + Amplitude Calibration")
    lines.append("============================================================")
    lines.append("")
    lines.append(f"VERDICT: {summary['verdict']}")
    lines.append("")
    lines.append("WHY v4 EXISTS")
    lines.append("-------------")
    lines.append("Stage-6T v3 found that single source probes were weak, but composite probes were much stronger.")
    lines.append(f"v3 best composite corr: {v3_summary.get('best_composite_corr_to_rho_eval_only')}")
    lines.append(f"v3 best composite R^2 : {v3_summary.get('best_composite_r2_to_rho_eval_only')}")
    lines.append("v4 freezes those composite candidates and asks whether they survive stricter provenance filtering.")
    lines.append("")
    lines.append("DISCIPLINE CHECK")
    lines.append("----------------")
    lines.append("rho(s) was used only as frozen evaluation/calibration reference.")
    lines.append("rho(s) was NOT used as a target mode.")
    lines.append("E(s), C(s) were frozen; centers were not refit.")
    lines.append("Fields containing rho_predicted / predicted / canonical_rho / Stage-6T outputs were excluded.")
    lines.append("Only upstream/provenance source fields were admitted.")
    lines.append("Global scale and offset calibration were fitted explicitly and reported.")
    lines.append("No cosmology/spacetime interpretation was performed.")
    lines.append("")
    lines.append("BEST CALIBRATED FROZEN COMPOSITE")
    lines.append("---------------------------------")
    lines.append(f"early probe   : {summary.get('best_early_probe')}")
    lines.append(f"central probe : {summary.get('best_central_probe')}")
    lines.append(f"families      : {summary.get('best_early_family')} / {summary.get('best_central_family')}")
    lines.append(f"raw R^2       : {summary.get('best_r2_raw')}")
    lines.append(f"calibrated corr: {summary.get('best_corr_calibrated')}")
    lines.append(f"calibrated R^2 : {summary.get('best_r2_calibrated')}")
    lines.append(f"global scale   : {summary.get('best_global_scale')}")
    lines.append(f"global offset  : {summary.get('best_global_offset')}")
    lines.append("")
    lines.append("FAMILY STABILITY")
    lines.append("----------------")
    if fam_df.empty:
        lines.append("No family-stability groups were evaluable after v4 restriction.")
    else:
        for _, row in fam_df.head(5).iterrows():
            lines.append(
                f"- all_families={row['has_all_true_families']}, "
                f"score={row['family_stability_score']:.4f}, "
                f"mean_R2={row['mean_r2_calibrated']:.4f}, "
                f"min_R2={row['min_r2_calibrated']:.4f}, "
                f"E_cv={row['early_amp_cv']:.4f}, C_cv={row['central_amp_cv']:.4f}, "
                f"E_sign={row['early_amp_sign_stable']}, C_sign={row['central_amp_sign_stable']}"
            )
    lines.append("")
    lines.append("EXCLUSION AUDIT SUMMARY")
    lines.append("-----------------------")
    if exclusion_audit.empty:
        lines.append("No exclusion audit rows were produced.")
    else:
        counts = exclusion_audit["status"].value_counts().to_dict()
        lines.append(f"admission counts: {counts}")
    lines.append("")
    lines.append("RECOMMENDED READING")
    lines.append("-------------------")
    lines.append("If v4 returns B, freeze the composite source form and move to perturbation/operator-stability validation.")
    lines.append("If v4 remains C but calibrated R^2 is positive, the composite source idea survives but family amplitude stability still blocks interpretation.")
    lines.append("If v4 collapses, then the v3 gain probably depended on downstream or predicted fields and should not be used as mechanism evidence.")
    lines.append("============================================================")
    (out_dir / "stage6T_v4_interpretation_notes.txt").write_text("\n".join(lines), encoding="utf-8")


# ---------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------

def main() -> None:
    warnings.filterwarnings("ignore", category=RuntimeWarning)
    root = discover_project_root()
    out_dir = ensure_dir(root / "metric_stage_6T_outputs" / RUN_NAME)
    script_dir = ensure_dir(root / "metric_stage_6T_scripts")

    print("========================================================================")
    print("Stage-6T: Composite Probe Freeze + Amplitude Calibration — v4")
    print("========================================================================")
    print(f"[Stage-6T] Python executable : {sys.executable}")
    print(f"[Stage-6T] Script path       : {Path(__file__).resolve()}")
    print(f"[Stage-6T] Working directory : {Path.cwd()}")
    print(f"[Stage-6T] Project root      : {root}")
    print(f"[Stage-6T] Output dir        : {out_dir}")
    print("[Stage-6T] Rule              : do NOT use canonical rho as target mode.")
    print("[Stage-6T] Rule              : freeze E(s), C(s); do not refit centers.")
    print("[Stage-6T] Rule              : remove rho_predicted / predicted / downstream fields.")
    print("[Stage-6T] v4 addition       : freeze v3 composites + explicit scale/offset calibration.")
    print("------------------------------------------------------------------------")

    summary = evaluate_v4(root, out_dir)

    try:
        src = Path(__file__).resolve()
        dst = script_dir / src.name
        if src != dst:
            dst.write_text(src.read_text(encoding="utf-8"), encoding="utf-8")
            print(f"[Stage-6T] Script copy saved : {dst}")
    except Exception as exc:
        print(f"[Stage-6T] Script copy warning: {exc}")

    print("------------------------------------------------------------------------")
    print(f"[Stage-6T] VERDICT: {summary['verdict']}")
    print(f"[Stage-6T] Best calibrated corr : {summary.get('best_corr_calibrated')}")
    print(f"[Stage-6T] Best calibrated R^2  : {summary.get('best_r2_calibrated')}")
    print(f"[Stage-6T] Family stable score  : {summary.get('best_family_stability_score')}")
    print(f"[Stage-6T] Best early probe     : {summary.get('best_early_probe')}")
    print(f"[Stage-6T] Best central probe   : {summary.get('best_central_probe')}")
    print("[Stage-6T] Done.")
    print("========================================================================")


if __name__ == "__main__":
    main()
