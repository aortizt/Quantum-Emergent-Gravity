#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
========================================================================
Project : Quantum-Emergent Gravity
Stage   : 6R
Title   : Operator Interpretation Layer — Rank-1 Refinement
Author  : Arturo Ortiz-Tapia / QEG pipeline assistant
Build   : 2026-05-04 / v2 refinement
========================================================================

Stage-6R exists because Stage-6Q froze a canonical two-lobe law

    rho(s) ~= E(s) + C(s)

with a hard early anchor near s ~= 0.15, a central bulk response near
s ~= 0.54, and a stable mass partition near 27% / 73%.

This script does NOT refit Stage-6P/6Q observables.  It treats the
canonical values as frozen input and performs an interpretation-layer
analysis:

1. Analytic canonicalization of E(s), C(s)
2. Candidate Green/operator kernel construction
3. Dimensionless cosmology-panel comparison
4. Explicit rank-1 operator tests
5. Synthesis into operator hypotheses

The goal is classification, not physical claim-making.
========================================================================
"""

from __future__ import annotations

import json
import math
import os
import sys
import traceback
from dataclasses import dataclass, asdict
from datetime import datetime
from glob import glob
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    HAVE_MPL = True
except Exception:
    HAVE_MPL = False

try:
    from scipy.special import erf
    HAVE_SCIPY = True
except Exception:
    HAVE_SCIPY = False


# ---------------------------------------------------------------------
# Project conventions
# ---------------------------------------------------------------------
STAGE = "6R"
SCRIPT_NAME = "Stage-6R_operator_interpretation_layer_v2.py"
DEFAULT_PROJECT_ROOT = "/home/dakini/Downloads/010-Quantum_Emergent_Gravity"
OUTPUT_SUBDIR = "metric_stage_6R_outputs/operator_interpretation_layer_v2_rank1_refinement"


# Frozen canonical Stage-6Q invariants from the Stage-6R transition package.
# These are fallback values if Stage-6Q files are not found locally.
FROZEN_DEFAULTS = {
    "mu_early": 0.150000000,
    "mu_central": 0.537000000,
    "early_mass_fraction": 0.267000000,
    "central_mass_fraction": 0.733000000,
    # Widths were listed as soft invariants rather than frozen numbers.
    # These default widths are deliberately conservative interpretation
    # scales, not claims. They are overwritten if Stage-6Q provides them.
    "sigma_early": 0.045000000,
    "sigma_central": 0.135000000,
}

COSMOLOGY_PANEL = {
    # PDG/Planck-like values used only as dimensionless comparison targets.
    # No physical identification is inferred from numerical proximity.
    "Omega_b": 0.0493,
    "Omega_c": 0.2650,
    "Omega_m": 0.3150,
    "Omega_Lambda": 0.6850,
    "Omega_b_over_Omega_m": 0.0493 / 0.3150,
    "Omega_c_over_Omega_m": 0.2650 / 0.3150,
    "Omega_m_over_Omega_Lambda": 0.3150 / 0.6850,
    "Omega_Lambda_over_Omega_m": 0.6850 / 0.3150,
}


@dataclass
class CanonicalParams:
    mu_early: float
    sigma_early: float
    early_mass_fraction: float
    mu_central: float
    sigma_central: float
    central_mass_fraction: float
    source: str = "fallback_transition_package"

    @property
    def mass_ratio_early_to_central(self) -> float:
        return safe_div(self.early_mass_fraction, self.central_mass_fraction)

    @property
    def mass_ratio_central_to_early(self) -> float:
        return safe_div(self.central_mass_fraction, self.early_mass_fraction)

    @property
    def center_separation(self) -> float:
        return abs(self.mu_central - self.mu_early)

    @property
    def sigma_ratio_early_to_central(self) -> float:
        return safe_div(self.sigma_early, self.sigma_central)


def safe_div(a: float, b: float, default: float = np.nan) -> float:
    try:
        if abs(b) < 1e-15:
            return default
        return float(a / b)
    except Exception:
        return default


def trapz_compat(y: np.ndarray, x: np.ndarray) -> float:
    """
    Compatibility wrapper for trapezoidal integration.
    Stage-6R v2 uses np.trapezoid rather than the older NumPy integration alias.
    """
    return float(np.trapezoid(y, x))


def project_root_from_args() -> Path:
    if len(sys.argv) >= 2 and sys.argv[1].strip():
        return Path(sys.argv[1]).expanduser().resolve()
    env_root = os.environ.get("QEG_PROJECT_ROOT", "").strip()
    if env_root:
        return Path(env_root).expanduser().resolve()
    return Path(DEFAULT_PROJECT_ROOT).expanduser().resolve()


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def echo_header(project_root: Path, outdir: Path) -> None:
    print("========================================================================")
    print("Stage-6R: Operator Interpretation Layer — v2 Rank-1 Refinement")
    print("========================================================================")
    print(f"[Stage-6R] Python executable : {sys.executable}")
    print(f"[Stage-6R] Script name       : {SCRIPT_NAME}")
    print(f"[Stage-6R] Working directory : {Path.cwd()}")
    print(f"[Stage-6R] Project root      : {project_root}")
    print(f"[Stage-6R] Output dir        : {outdir}")
    print("[Stage-6R] Rule              : interpret frozen Stage-6Q law; do not refit upstream observables.")
    print("========================================================================")


def find_stage6q_files(project_root: Path) -> Dict[str, Optional[Path]]:
    candidates = {
        "canonical_parameters": None,
        "invariant_summary": None,
        "dimensionless_ratios": None,
        "canonical_curve": None,
        "summary_json": None,
    }
    patterns = {
        "canonical_parameters": ["**/stage6Q*canonical*parameters*.csv", "**/*6Q*canonical*parameters*.csv"],
        "invariant_summary": ["**/stage6Q*invariant*summary*.csv", "**/*6Q*invariant*summary*.csv"],
        "dimensionless_ratios": ["**/stage6Q*dimensionless*ratios*.csv", "**/*6Q*dimensionless*ratios*.csv"],
        "canonical_curve": ["**/stage6Q*canonical*curve*.csv", "**/*6Q*canonical*curve*.csv"],
        "summary_json": ["**/stage6Q*canonical*law*summary*.json", "**/*6Q*summary*.json"],
    }
    for key, pats in patterns.items():
        found: List[str] = []
        for pat in pats:
            found.extend(glob(str(project_root / pat), recursive=True))
        if found:
            # Prefer shortest path and most recent modified file among close candidates.
            found_paths = sorted([Path(f) for f in found if Path(f).is_file()], key=lambda p: (-p.stat().st_mtime, len(str(p))))
            candidates[key] = found_paths[0]
    return candidates


def normalize_key(k: str) -> str:
    return str(k).strip().lower().replace(" ", "_").replace("-", "_")


def extract_numeric_from_frame(df: pd.DataFrame) -> Dict[str, float]:
    values: Dict[str, float] = {}
    if df.empty:
        return values

    # Case 1: columns are named directly.
    for col in df.columns:
        ncol = normalize_key(col)
        if ncol in FROZEN_DEFAULTS:
            nums = pd.to_numeric(df[col], errors="coerce").dropna()
            if len(nums):
                values[ncol] = float(nums.iloc[0])

    # Case 2: long table with key/value columns.
    key_candidates = [c for c in df.columns if normalize_key(c) in {"parameter", "name", "key", "quantity", "metric"}]
    value_candidates = [c for c in df.columns if normalize_key(c) in {"value", "estimate", "mean", "canonical_value"}]
    for kc in key_candidates:
        for vc in value_candidates:
            for _, row in df.iterrows():
                k = normalize_key(row.get(kc, ""))
                if k in FROZEN_DEFAULTS:
                    val = pd.to_numeric(pd.Series([row.get(vc)]), errors="coerce").iloc[0]
                    if pd.notna(val):
                        values[k] = float(val)
    return values


def load_canonical_params(files: Dict[str, Optional[Path]]) -> CanonicalParams:
    vals = dict(FROZEN_DEFAULTS)
    sources: List[str] = []

    for key in ["canonical_parameters", "invariant_summary", "dimensionless_ratios"]:
        path = files.get(key)
        if path and path.exists():
            try:
                df = pd.read_csv(path)
                new_vals = extract_numeric_from_frame(df)
                if new_vals:
                    vals.update(new_vals)
                    sources.append(str(path))
            except Exception as exc:
                print(f"[Stage-6R warning] Could not read {path}: {exc}")

    path = files.get("summary_json")
    if path and path.exists():
        try:
            with open(path, "r", encoding="utf-8") as f:
                obj = json.load(f)
            flat = flatten_dict(obj)
            for k, v in flat.items():
                nk = normalize_key(k)
                if nk in vals:
                    try:
                        vals[nk] = float(v)
                    except Exception:
                        pass
            sources.append(str(path))
        except Exception as exc:
            print(f"[Stage-6R warning] Could not read {path}: {exc}")

    # Normalize masses if they drift due to input precision.
    total_mass = vals["early_mass_fraction"] + vals["central_mass_fraction"]
    if total_mass > 0:
        vals["early_mass_fraction"] = float(vals["early_mass_fraction"] / total_mass)
        vals["central_mass_fraction"] = float(vals["central_mass_fraction"] / total_mass)

    return CanonicalParams(
        mu_early=float(vals["mu_early"]),
        sigma_early=max(float(vals["sigma_early"]), 1e-6),
        early_mass_fraction=float(vals["early_mass_fraction"]),
        mu_central=float(vals["mu_central"]),
        sigma_central=max(float(vals["sigma_central"]), 1e-6),
        central_mass_fraction=float(vals["central_mass_fraction"]),
        source=";".join(sources) if sources else "fallback_transition_package",
    )


def flatten_dict(obj, prefix="") -> Dict[str, object]:
    out = {}
    if isinstance(obj, dict):
        for k, v in obj.items():
            nk = f"{prefix}.{k}" if prefix else str(k)
            out.update(flatten_dict(v, nk))
    else:
        out[prefix] = obj
    return out


def load_or_build_curve(files: Dict[str, Optional[Path]], p: CanonicalParams, n: int = 361) -> pd.DataFrame:
    path = files.get("canonical_curve")
    if path and path.exists():
        try:
            df = pd.read_csv(path)
            # Find s and rho columns flexibly.
            s_col = pick_column(df, ["s", "s_normalized", "intrinsic_s", "s_bin", "bin_center"])
            rho_col = pick_column(df, ["rho", "rho_like", "density", "canonical_rho", "value"])
            if s_col and rho_col:
                out = df[[s_col, rho_col]].copy()
                out.columns = ["s", "rho_canonical"]
                out["s"] = pd.to_numeric(out["s"], errors="coerce")
                out["rho_canonical"] = pd.to_numeric(out["rho_canonical"], errors="coerce")
                out = out.dropna().sort_values("s")
                if len(out) >= 10:
                    out["source"] = str(path)
                    return out
        except Exception as exc:
            print(f"[Stage-6R warning] Could not read curve {path}: {exc}")

    s = np.linspace(0.0, 1.0, n)
    E, C, rho = canonical_components(s, p, family="gaussian_plus_skewed_central")
    return pd.DataFrame({"s": s, "E_frozen": E, "C_frozen": C, "rho_canonical": rho, "source": "constructed_from_frozen_parameters"})


def pick_column(df: pd.DataFrame, names: List[str]) -> Optional[str]:
    norm = {normalize_key(c): c for c in df.columns}
    for name in names:
        if normalize_key(name) in norm:
            return norm[normalize_key(name)]
    # partial match fallback
    for c in df.columns:
        nc = normalize_key(c)
        if any(normalize_key(name) in nc for name in names):
            return c
    return None


def gaussian_pdf(s: np.ndarray, mu: float, sigma: float) -> np.ndarray:
    z = (s - mu) / max(sigma, 1e-12)
    y = np.exp(-0.5 * z * z)
    area = trapz_compat(y, s)
    return y / area if area > 0 else y


def exponential_left_pdf(s: np.ndarray, mu: float, scale: float) -> np.ndarray:
    # A left-localized exponential-like candidate centered near mu.
    y = np.exp(-np.abs(s - mu) / max(scale, 1e-12))
    area = trapz_compat(y, s)
    return y / area if area > 0 else y


def compact_bump_pdf(s: np.ndarray, mu: float, width: float) -> np.ndarray:
    x = (s - mu) / max(width, 1e-12)
    y = np.zeros_like(s, dtype=float)
    mask = np.abs(x) < 1.0
    y[mask] = np.exp(-1.0 / (1.0 - x[mask] ** 2))
    area = trapz_compat(y, s)
    return y / area if area > 0 else y


def skew_normal_like_pdf(s: np.ndarray, mu: float, sigma: float, alpha: float = -1.25) -> np.ndarray:
    z = (s - mu) / max(sigma, 1e-12)
    base = np.exp(-0.5 * z * z)
    if HAVE_SCIPY:
        Phi = 0.5 * (1.0 + erf(alpha * z / math.sqrt(2.0)))
    else:
        # Smooth logistic approximation to normal CDF.
        Phi = 1.0 / (1.0 + np.exp(-1.702 * alpha * z))
    y = 2.0 * base * Phi
    area = trapz_compat(y, s)
    return y / area if area > 0 else y


def canonical_components(s: np.ndarray, p: CanonicalParams, family: str) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    if family == "gaussian_gaussian":
        E = p.early_mass_fraction * gaussian_pdf(s, p.mu_early, p.sigma_early)
        C = p.central_mass_fraction * gaussian_pdf(s, p.mu_central, p.sigma_central)
    elif family == "compact_early_plus_skewed_central":
        E = p.early_mass_fraction * compact_bump_pdf(s, p.mu_early, 2.2 * p.sigma_early)
        C = p.central_mass_fraction * skew_normal_like_pdf(s, p.mu_central, p.sigma_central, alpha=-1.25)
    elif family == "exponential_early_plus_gaussian_central":
        E = p.early_mass_fraction * exponential_left_pdf(s, p.mu_early, p.sigma_early)
        C = p.central_mass_fraction * gaussian_pdf(s, p.mu_central, p.sigma_central)
    else:
        E = p.early_mass_fraction * gaussian_pdf(s, p.mu_early, p.sigma_early)
        C = p.central_mass_fraction * skew_normal_like_pdf(s, p.mu_central, p.sigma_central, alpha=-1.25)
    return E, C, E + C


def score_prediction(y: np.ndarray, yhat: np.ndarray) -> Dict[str, float]:
    y = np.asarray(y, dtype=float)
    yhat = np.asarray(yhat, dtype=float)
    mask = np.isfinite(y) & np.isfinite(yhat)
    if mask.sum() < 3:
        return {"corr": np.nan, "r2": np.nan, "rmse": np.nan, "mae": np.nan}
    yy = y[mask]
    pp = yhat[mask]
    ss_res = float(np.sum((yy - pp) ** 2))
    ss_tot = float(np.sum((yy - np.mean(yy)) ** 2))
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 1e-15 else np.nan
    corr = float(np.corrcoef(yy, pp)[0, 1]) if np.std(yy) > 1e-15 and np.std(pp) > 1e-15 else np.nan
    rmse = float(np.sqrt(np.mean((yy - pp) ** 2)))
    mae = float(np.mean(np.abs(yy - pp)))
    return {"corr": corr, "r2": r2, "rmse": rmse, "mae": mae}


def analytic_canonicalization(curve: pd.DataFrame, p: CanonicalParams) -> pd.DataFrame:
    s = curve["s"].to_numpy(dtype=float)
    y = curve["rho_canonical"].to_numpy(dtype=float)
    rows = []
    families = [
        ("gaussian_plus_skewed_central", 7, "minimal canonical two-lobe with central skew"),
        ("gaussian_gaussian", 6, "symmetric two-Gaussian control"),
        ("compact_early_plus_skewed_central", 7, "localized early bump plus skewed bulk"),
        ("exponential_early_plus_gaussian_central", 6, "injection/decay early sector plus bulk Gaussian"),
    ]
    for name, k_params, description in families:
        E, C, rho = canonical_components(s, p, name)
        scores = score_prediction(y, rho)
        rows.append({
            "analytic_family": name,
            "description": description,
            "parameter_count_interpretive": k_params,
            "mu_early": p.mu_early,
            "sigma_early": p.sigma_early,
            "mass_early": p.early_mass_fraction,
            "mu_central": p.mu_central,
            "sigma_central": p.sigma_central,
            "mass_central": p.central_mass_fraction,
            "mass_ratio_early_to_central": p.mass_ratio_early_to_central,
            "center_separation": p.center_separation,
            **scores,
            "interpretation": classify_analytic(scores, k_params),
        })
    return pd.DataFrame(rows).sort_values(["r2", "parameter_count_interpretive"], ascending=[False, True])


def classify_analytic(scores: Dict[str, float], k_params: int) -> str:
    r2 = scores.get("r2", np.nan)
    if np.isfinite(r2) and r2 > 0.95 and k_params <= 7:
        return "compact_analytic_form_supported"
    if np.isfinite(r2) and r2 > 0.80:
        return "useful_surrogate_not_decisive"
    return "weak_surrogate_or_curve_mismatch"


def build_kernel_candidates(s: np.ndarray, p: CanonicalParams) -> Dict[str, np.ndarray]:
    E, C, rho = canonical_components(s, p, "gaussian_plus_skewed_central")
    source_early = gaussian_pdf(s, p.mu_early, max(p.sigma_early, 1e-6))
    source_central = gaussian_pdf(s, p.mu_central, max(p.sigma_central, 1e-6))
    source_edge = exponential_left_pdf(s, 0.0, max(p.mu_early, 0.03))

    # Separable operator motifs: target response mode times source-reading mode.
    G_sep_two_channel = np.outer(E, source_edge) + np.outer(C, source_central)
    G_rank1_collective = np.outer(E + C, p.early_mass_fraction * source_edge + p.central_mass_fraction * source_central)

    # Translation-invariant screened/local Green surrogate.
    S, T = np.meshgrid(s, s, indexing="ij")
    L = max(0.5 * (p.sigma_early + p.sigma_central), 1e-6)
    G_screened = np.exp(-np.abs(S - T) / L)
    G_screened = normalize_kernel_columns(s, G_screened)

    # Boundary-to-bulk asymmetric kernel: source near boundary projects into both lobes.
    asym_weight = 1.0 + 0.75 * (T < p.mu_early + p.sigma_early)
    G_boundary_bulk = (np.outer(E + 0.45 * C, source_edge) + 0.35 * np.outer(C, source_central)) * asym_weight

    return {
        "rank1_collective_separable": G_rank1_collective,
        "two_channel_separable": G_sep_two_channel,
        "screened_translation_invariant_control": G_screened,
        "boundary_to_bulk_asymmetric": G_boundary_bulk,
    }


def normalize_kernel_columns(s: np.ndarray, G: np.ndarray) -> np.ndarray:
    out = np.asarray(G, dtype=float).copy()
    for j in range(out.shape[1]):
        area = trapz_compat(np.abs(out[:, j]), s)
        if area > 1e-15:
            out[:, j] /= area
    return out


def project_kernel(s: np.ndarray, G: np.ndarray, source: np.ndarray) -> np.ndarray:
    y = G @ source
    # Matrix product approximates sum; multiply by ds to approximate integral.
    ds = float(np.mean(np.diff(s))) if len(s) > 1 else 1.0
    y = y * ds
    area = trapz_compat(np.maximum(y, 0), s)
    if area > 1e-15:
        y = y / area
    return y


def kernel_reconstruction(curve: pd.DataFrame, p: CanonicalParams, outdir: Path) -> pd.DataFrame:
    s = curve["s"].to_numpy(dtype=float)
    y = curve["rho_canonical"].to_numpy(dtype=float)
    kernels = build_kernel_candidates(s, p)
    source = p.early_mass_fraction * gaussian_pdf(s, p.mu_early, p.sigma_early) + p.central_mass_fraction * gaussian_pdf(s, p.mu_central, p.sigma_central)

    rows = []
    for name, G in kernels.items():
        yhat = project_kernel(s, G, source)
        scores = score_prediction(y, yhat)
        asym = kernel_asymmetry(G)
        diag = diagonal_concentration(s, G)
        rank_energy = singular_energy(G)
        rows.append({
            "kernel_candidate": name,
            "operator_class": classify_kernel(name, asym, diag, rank_energy),
            "kernel_asymmetry_l1": asym,
            "diagonal_concentration": diag,
            "svd_energy_rank1": rank_energy.get("rank1", np.nan),
            "svd_energy_rank2": rank_energy.get("rank2", np.nan),
            "effective_rank_99pct": rank_energy.get("rank99", np.nan),
            **scores,
            "interpretation": interpret_kernel(scores, asym, diag, rank_energy),
        })
        if HAVE_MPL:
            plot_kernel(s, G, name, outdir)
    return pd.DataFrame(rows).sort_values(["r2", "svd_energy_rank1"], ascending=[False, False])


def kernel_asymmetry(G: np.ndarray) -> float:
    if G.shape[0] != G.shape[1]:
        return np.nan
    denom = np.sum(np.abs(G)) + 1e-15
    return float(np.sum(np.abs(G - G.T)) / denom)


def diagonal_concentration(s: np.ndarray, G: np.ndarray) -> float:
    S, T = np.meshgrid(s, s, indexing="ij")
    width = 0.08
    mask = np.abs(S - T) <= width
    denom = np.sum(np.abs(G)) + 1e-15
    return float(np.sum(np.abs(G[mask])) / denom)


def singular_energy(G: np.ndarray) -> Dict[str, float]:
    try:
        _, sv, _ = np.linalg.svd(G, full_matrices=False)
        e = sv ** 2
        total = float(np.sum(e))
        if total <= 1e-15:
            return {"rank1": np.nan, "rank2": np.nan, "rank99": np.nan}
        cum = np.cumsum(e) / total
        return {
            "rank1": float(cum[0]),
            "rank2": float(cum[min(1, len(cum) - 1)]),
            "rank99": int(np.searchsorted(cum, 0.99) + 1),
        }
    except Exception:
        return {"rank1": np.nan, "rank2": np.nan, "rank99": np.nan}


def classify_kernel(name: str, asym: float, diag: float, energy: Dict[str, float]) -> str:
    if "screened" in name:
        return "local_green_control"
    if energy.get("rank1", 0) > 0.95 and asym > 0.25:
        return "asymmetric_low_rank_operator"
    if energy.get("rank2", 0) > 0.95:
        return "two_channel_low_rank_operator"
    if diag > 0.65:
        return "local_or_near_local_kernel"
    return "distributed_nonlocal_kernel"


def interpret_kernel(scores: Dict[str, float], asym: float, diag: float, energy: Dict[str, float]) -> str:
    r2 = scores.get("r2", np.nan)
    if np.isfinite(r2) and r2 > 0.85 and energy.get("rank1", 0) > 0.9:
        return "strong_low_rank_operator_candidate"
    if np.isfinite(r2) and r2 > 0.7 and asym > 0.2:
        return "plausible_asymmetric_operator_candidate"
    if diag > 0.65:
        return "mostly_local_green_surrogate_control"
    return "weak_or_control_candidate"


def first_rank_k_approx(G: np.ndarray, k: int = 1) -> Tuple[np.ndarray, Dict[str, float]]:
    """Return rank-k SVD reconstruction and diagnostic singular data."""
    U, sv, Vt = np.linalg.svd(G, full_matrices=False)
    kk = max(1, min(int(k), len(sv)))
    Gk = (U[:, :kk] * sv[:kk]) @ Vt[:kk, :]
    e = sv ** 2
    total = float(np.sum(e))
    cum = np.cumsum(e) / total if total > 1e-15 else np.full_like(e, np.nan, dtype=float)
    diag = {
        "singular_value_1": float(sv[0]) if len(sv) else np.nan,
        "singular_value_2": float(sv[1]) if len(sv) > 1 else np.nan,
        "singular_gap_s1_over_s2": safe_div(float(sv[0]), float(sv[1])) if len(sv) > 1 else np.nan,
        "energy_rank1": float(cum[0]) if len(cum) else np.nan,
        "energy_rank2": float(cum[min(1, len(cum)-1)]) if len(cum) else np.nan,
        "rank99": int(np.searchsorted(cum, 0.99) + 1) if len(cum) and np.isfinite(cum).any() else -1,
    }
    return Gk, diag


def normalize_density(s: np.ndarray, y: np.ndarray, nonnegative: bool = True) -> np.ndarray:
    yy = np.asarray(y, dtype=float).copy()
    if nonnegative:
        yy = np.maximum(yy, 0.0)
    area = trapz_compat(yy, s)
    return yy / area if area > 1e-15 else yy


def explicit_rank1_operator_tests(curve: pd.DataFrame, p: CanonicalParams, outdir: Path) -> pd.DataFrame:
    """
    Stage-6R v2 refinement: explicitly test rank-1 structure.

    For every candidate kernel G, compare the full candidate projection against
    rank-1 and rank-2 SVD projections. Then add constructive separable probes
    of the form G(s, sigma) = u(s) v(sigma). These constructive probes are
    mechanism hypotheses / upper bounds, not new fits of Stage-6Q observables.
    """
    s = curve["s"].to_numpy(dtype=float)
    y = curve["rho_canonical"].to_numpy(dtype=float)
    y_norm = normalize_density(s, y)

    E, C, rho = canonical_components(s, p, "gaussian_plus_skewed_central")
    edge_reader = exponential_left_pdf(s, 0.0, max(p.mu_early, 0.03))
    early_reader = gaussian_pdf(s, p.mu_early, p.sigma_early)
    central_reader = gaussian_pdf(s, p.mu_central, p.sigma_central)
    mixed_reader = normalize_density(s, p.early_mass_fraction * edge_reader + p.central_mass_fraction * central_reader)
    source = normalize_density(s, p.early_mass_fraction * early_reader + p.central_mass_fraction * central_reader)

    kernels = build_kernel_candidates(s, p)
    rows: List[Dict[str, object]] = []

    for name, G in kernels.items():
        G1, svd_diag = first_rank_k_approx(G, 1)
        G2, _ = first_rank_k_approx(G, 2)
        for approx_name, GG in [
            ("full_candidate", G),
            ("rank1_svd_projection", G1),
            ("rank2_svd_projection", G2),
        ]:
            yhat = project_kernel(s, GG, source)
            scores = score_prediction(y_norm, yhat)
            rows.append({
                "test_family": "candidate_svd_rank_test",
                "kernel_candidate": name,
                "rank_test": approx_name,
                "source_probe": "frozen_early_plus_central_source",
                "target_mode": "projected_by_kernel",
                **svd_diag,
                **scores,
                "rank1_interpretation": classify_rank1_result(scores, svd_diag, approx_name),
            })

    constructive_specs = [
        ("constructive_rank1_canonical_upper_bound", rho, mixed_reader,
         "u=rho_frozen_two_lobe", "v=edge_plus_central_reader"),
        ("constructive_rank1_boundary_to_bulk", rho, edge_reader,
         "u=rho_frozen_two_lobe", "v=left_boundary_reader"),
        ("constructive_rank1_early_channel", E, edge_reader,
         "u=early_lobe_only", "v=left_boundary_reader"),
        ("constructive_rank1_central_channel", C, central_reader,
         "u=central_lobe_only", "v=central_reader"),
    ]

    for name, u, v, target_label, source_label in constructive_specs:
        u_norm = normalize_density(s, u)
        v_norm = normalize_density(s, v)
        G = np.outer(u_norm, v_norm)
        yhat = project_kernel(s, G, source)
        scores = score_prediction(y_norm, yhat)
        _, svd_diag = first_rank_k_approx(G, 1)
        rows.append({
            "test_family": "constructive_rank1_separable_probe",
            "kernel_candidate": name,
            "rank_test": "exact_rank1_outer_product",
            "source_probe": source_label,
            "target_mode": target_label,
            **svd_diag,
            **scores,
            "rank1_interpretation": classify_rank1_result(scores, svd_diag, "exact_rank1_outer_product"),
        })

        if HAVE_MPL:
            plot_rank1_modes(s, u_norm, v_norm, y_norm, yhat, name, outdir)

    out = pd.DataFrame(rows)
    if len(out):
        out = out.sort_values(["r2", "energy_rank1"], ascending=[False, False])
    return out


def classify_rank1_result(scores: Dict[str, float], svd_diag: Dict[str, float], rank_test: str) -> str:
    r2 = scores.get("r2", np.nan)
    e1 = svd_diag.get("energy_rank1", np.nan)
    if rank_test == "exact_rank1_outer_product" and np.isfinite(r2) and r2 > 0.95:
        return "rank1_constructive_upper_bound_matches_frozen_law"
    if np.isfinite(r2) and r2 > 0.85 and np.isfinite(e1) and e1 > 0.90:
        return "rank1_mechanism_strongly_supported_for_this_probe"
    if np.isfinite(r2) and r2 > 0.65 and np.isfinite(e1) and e1 > 0.70:
        return "rank1_mechanism_plausible_but_not_decisive"
    if "rank1" in rank_test:
        return "rank1_projection_insufficient_or_source_mismatch"
    return "control_or_multimode_candidate"


def plot_rank1_modes(s: np.ndarray, u: np.ndarray, v: np.ndarray, y: np.ndarray, yhat: np.ndarray, name: str, outdir: Path) -> None:
    if not HAVE_MPL:
        return
    safe = "".join(ch if ch.isalnum() or ch in "_-" else "_" for ch in name)
    plt.figure(figsize=(9, 5))
    plt.plot(s, y, label="canonical rho(s)", linewidth=2)
    plt.plot(s, yhat, label="rank-1 projected response", linestyle="--", linewidth=2)
    plt.plot(s, u, label="target mode u(s)", linestyle=":")
    plt.plot(s, v, label="source reader v(sigma)", linestyle="-.")
    plt.xlabel("intrinsic coordinate")
    plt.ylabel("normalized profile / mode")
    plt.title(f"Stage-6R v2 explicit rank-1 probe: {name}")
    plt.legend()
    plt.tight_layout()
    plt.savefig(outdir / f"stage6R_rank1_probe_{safe}.png", dpi=180)
    plt.close()


def cosmology_comparison(p: CanonicalParams) -> pd.DataFrame:
    invariants = {
        "early_mass_fraction": p.early_mass_fraction,
        "central_mass_fraction": p.central_mass_fraction,
        "mass_ratio_early_to_central": p.mass_ratio_early_to_central,
        "mass_ratio_central_to_early": p.mass_ratio_central_to_early,
        "mu_early": p.mu_early,
        "mu_central": p.mu_central,
        "center_separation": p.center_separation,
        "sigma_ratio_early_to_central": p.sigma_ratio_early_to_central,
    }
    rows = []
    for inv_name, inv_val in invariants.items():
        for cos_name, cos_val in COSMOLOGY_PANEL.items():
            absdiff = abs(inv_val - cos_val)
            reldiff = safe_div(absdiff, abs(cos_val))
            rows.append({
                "qeg_invariant": inv_name,
                "qeg_value": inv_val,
                "cosmology_target": cos_name,
                "cosmology_value": cos_val,
                "absolute_difference": absdiff,
                "relative_difference": reldiff,
                "review_flag": proximity_flag(absdiff, reldiff),
                "claim_status": "dimensionless_comparison_only_no_physical_claim",
            })
    return pd.DataFrame(rows).sort_values(["absolute_difference", "relative_difference"])


def proximity_flag(absdiff: float, reldiff: float) -> str:
    if absdiff < 0.01 or reldiff < 0.05:
        return "CLOSE_NUMERICAL_PROXIMITY_REVIEW_ONLY"
    if absdiff < 0.03 or reldiff < 0.15:
        return "MODERATE_PROXIMITY_LOG_ONLY"
    return "NO_SPECIAL_PROXIMITY"


def synthesize(p: CanonicalParams, analytic: pd.DataFrame, kernels: pd.DataFrame, rank1_tests: pd.DataFrame, cosmology: pd.DataFrame) -> Dict[str, object]:
    best_analytic = analytic.iloc[0].to_dict() if len(analytic) else {}
    best_kernel = kernels.iloc[0].to_dict() if len(kernels) else {}
    best_rank1 = rank1_tests.iloc[0].to_dict() if len(rank1_tests) else {}
    candidate_rank1 = rank1_tests[rank1_tests.get("test_family", pd.Series(dtype=str)).eq("candidate_svd_rank_test")] if len(rank1_tests) else pd.DataFrame()
    constructive_rank1 = rank1_tests[rank1_tests.get("test_family", pd.Series(dtype=str)).eq("constructive_rank1_separable_probe")] if len(rank1_tests) else pd.DataFrame()
    best_candidate_rank1 = candidate_rank1.sort_values(["r2", "energy_rank1"], ascending=[False, False]).iloc[0].to_dict() if len(candidate_rank1) else {}
    best_constructive_rank1 = constructive_rank1.sort_values(["r2", "energy_rank1"], ascending=[False, False]).iloc[0].to_dict() if len(constructive_rank1) else {}
    close_cosmo = cosmology[cosmology["review_flag"] != "NO_SPECIAL_PROXIMITY"].head(12)

    kernel_class = best_kernel.get("operator_class", "unknown")
    analytic_supported = str(best_analytic.get("interpretation", "")).startswith("compact")
    kernel_supported = str(best_kernel.get("interpretation", "")).startswith("strong") or str(best_kernel.get("interpretation", "")).startswith("plausible")
    candidate_rank1_supported = str(best_candidate_rank1.get("rank1_interpretation", "")).startswith("rank1_mechanism_strongly") or str(best_candidate_rank1.get("rank1_interpretation", "")).startswith("rank1_mechanism_plausible")
    constructive_rank1_supported = str(best_constructive_rank1.get("rank1_interpretation", "")).startswith("rank1_constructive")
    rank1_supported = candidate_rank1_supported or constructive_rank1_supported

    if candidate_rank1_supported:
        verdict = "RANK1_OPERATOR_REFINEMENT_SUPPORTED_READY_FOR_6S_STABILITY_TESTS"
    elif constructive_rank1_supported:
        verdict = "RANK1_CONSTRUCTIVE_UPPER_BOUND_CONFIRMED_CANDIDATE_SOURCE_TESTS_REQUIRED"
    elif analytic_supported and kernel_supported:
        verdict = "INTERPRETATION_LAYER_SUPPORTED_LOW_RANK_ASYMMETRIC_OPERATOR_CANDIDATE"
    elif analytic_supported:
        verdict = "ANALYTIC_CANONICALIZATION_SUPPORTED_OPERATOR_INTERPRETATION_PENDING"
    elif kernel_supported:
        verdict = "OPERATOR_CANDIDATE_SUPPORTED_ANALYTIC_FORM_REVIEW_REQUIRED"
    else:
        verdict = "C_INCOMPLETE_OR_REVIEW_REQUIRED"

    return {
        "stage": STAGE,
        "script": SCRIPT_NAME,
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "canonical_params": asdict(p),
        "derived_invariants": {
            "mass_ratio_early_to_central": p.mass_ratio_early_to_central,
            "mass_ratio_central_to_early": p.mass_ratio_central_to_early,
            "center_separation": p.center_separation,
            "sigma_ratio_early_to_central": p.sigma_ratio_early_to_central,
        },
        "best_analytic_family": best_analytic,
        "best_kernel_candidate": best_kernel,
        "best_rank1_test": best_rank1,
        "best_candidate_rank1_svd_test": best_candidate_rank1,
        "best_constructive_rank1_test": best_constructive_rank1,
        "operator_hypothesis": {
            "primary_classification": kernel_class,
            "physical_motif_candidate": "rank-1/separable boundary-reading operator plus central bulk redistribution",
            "green_function_status": "not a claim; tested as operator/Green surrogate family",
            "cosmology_status": "dimensionless comparison only; no physical identification",
        },
        "cosmology_review_hits": close_cosmo.to_dict(orient="records"),
        "verdict": verdict,
        "rules_preserved": [
            "Stage-6P/6Q observables not refit",
            "canonical parameters treated as frozen inputs",
            "cosmology proximity logged without physical claim",
            "operator candidates classified as interpretation hypotheses",
            "explicit rank-1 tests are mechanism probes / upper bounds, not upstream refits",
        ],
    }


def write_notes(outdir: Path, summary: Dict[str, object], files: Dict[str, Optional[Path]]) -> None:
    p = summary["canonical_params"]
    lines = []
    lines.append("============================================================")
    lines.append("STAGE-6R INTERPRETATION NOTES")
    lines.append("============================================================")
    lines.append("")
    lines.append(f"Verdict: {summary['verdict']}")
    lines.append("")
    lines.append("Frozen canonical inputs used:")
    for k, v in p.items():
        lines.append(f"- {k}: {v}")
    lines.append("")
    lines.append("Stage-6Q files discovered:")
    for k, v in files.items():
        lines.append(f"- {k}: {v if v else 'not found'}")
    lines.append("")
    lines.append("Interpretive reading:")
    lines.append("- The law is treated as E(s) + C(s), not refit from raw Stage-6P/6Q data.")
    lines.append("- Candidate kernels are probes of mechanism: separable, two-channel, local Green control, asymmetric boundary-to-bulk response, and explicit rank-1 projections.")
    lines.append("- A strong low-rank/asymmetric/rank-1 candidate should be read as a mechanism hypothesis, not as proof of physical identity.")
    lines.append("- Cosmology-panel hits are logged only as dimensionless proximity checks.")
    lines.append("")
    lines.append("Next-stage recommendation:")
    lines.append("- If Stage-6R v2 supports an explicit rank-1 operator, Stage-6S should test stability under perturbations, family-resolved amplitudes, and alternative source probes.")
    lines.append("- If local Green controls underperform relative to separable kernels, keep Green functions but shift emphasis to non-translation-invariant / boundary-forced Green operators.")
    lines.append("")
    lines.append("============================================================")
    (outdir / "stage6R_interpretation_notes.txt").write_text("\n".join(lines), encoding="utf-8")


def plot_analytic_overlay(curve: pd.DataFrame, p: CanonicalParams, outdir: Path) -> None:
    if not HAVE_MPL:
        return
    s = curve["s"].to_numpy(dtype=float)
    y = curve["rho_canonical"].to_numpy(dtype=float)
    E, C, rho = canonical_components(s, p, "gaussian_plus_skewed_central")
    plt.figure(figsize=(9, 5))
    plt.plot(s, y, label="canonical rho(s)", linewidth=2)
    plt.plot(s, E, label="E(s) early component", linestyle="--")
    plt.plot(s, C, label="C(s) central component", linestyle="--")
    plt.plot(s, rho, label="E(s)+C(s) analytic candidate", linestyle=":", linewidth=2)
    plt.xlabel("intrinsic coordinate s")
    plt.ylabel("density / rho-like response")
    plt.title("Stage-6R analytic canonicalization")
    plt.legend()
    plt.tight_layout()
    plt.savefig(outdir / "stage6R_analytic_overlay.png", dpi=180)
    plt.close()


def plot_kernel(s: np.ndarray, G: np.ndarray, name: str, outdir: Path) -> None:
    if not HAVE_MPL:
        return
    safe = "".join(ch if ch.isalnum() or ch in "_-" else "_" for ch in name)
    plt.figure(figsize=(6, 5))
    plt.imshow(G, origin="lower", aspect="auto", extent=[s.min(), s.max(), s.min(), s.max()])
    plt.xlabel("source coordinate sigma")
    plt.ylabel("target coordinate s")
    plt.title(f"Stage-6R kernel: {name}")
    plt.colorbar(label="kernel weight")
    plt.tight_layout()
    plt.savefig(outdir / f"stage6R_kernel_{safe}.png", dpi=180)
    plt.close()


def main() -> int:
    project_root = project_root_from_args()
    outdir = ensure_dir(project_root / OUTPUT_SUBDIR)
    echo_header(project_root, outdir)

    files = find_stage6q_files(project_root)
    print("[Stage-6R] Stage-6Q file discovery:")
    for k, v in files.items():
        print(f"  - {k}: {v if v else 'not found'}")

    params = load_canonical_params(files)
    print("[Stage-6R] Frozen canonical parameters:")
    for k, v in asdict(params).items():
        print(f"  - {k}: {v}")

    curve = load_or_build_curve(files, params)
    curve.to_csv(outdir / "stage6R_canonical_curve_used.csv", index=False)

    analytic = analytic_canonicalization(curve, params)
    analytic.to_csv(outdir / "stage6R_analytic_forms.csv", index=False)
    print(f"[Stage-6R] Wrote analytic forms: {outdir / 'stage6R_analytic_forms.csv'}")

    kernels = kernel_reconstruction(curve, params, outdir)
    kernels.to_csv(outdir / "stage6R_kernel_candidates.csv", index=False)
    print(f"[Stage-6R] Wrote kernel candidates: {outdir / 'stage6R_kernel_candidates.csv'}")

    rank1_tests = explicit_rank1_operator_tests(curve, params, outdir)
    rank1_tests.to_csv(outdir / "stage6R_rank1_operator_tests.csv", index=False)
    print(f"[Stage-6R] Wrote explicit rank-1 tests: {outdir / 'stage6R_rank1_operator_tests.csv'}")

    cosmo = cosmology_comparison(params)
    cosmo.to_csv(outdir / "stage6R_cosmology_comparison.csv", index=False)
    print(f"[Stage-6R] Wrote cosmology comparison: {outdir / 'stage6R_cosmology_comparison.csv'}")

    summary = synthesize(params, analytic, kernels, rank1_tests, cosmo)
    with open(outdir / "stage6R_operator_hypotheses.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)
    write_notes(outdir, summary, files)
    plot_analytic_overlay(curve, params, outdir)

    print("------------------------------------------------------------------------")
    print(f"[Stage-6R] VERDICT: {summary['verdict']}")
    print("[Stage-6R] Required outputs written:")
    for fname in [
        "stage6R_analytic_forms.csv",
        "stage6R_kernel_candidates.csv",
        "stage6R_rank1_operator_tests.csv",
        "stage6R_cosmology_comparison.csv",
        "stage6R_operator_hypotheses.json",
        "stage6R_interpretation_notes.txt",
        "stage6R_canonical_curve_used.csv",
    ]:
        print(f"  - {outdir / fname}")
    if HAVE_MPL:
        print("[Stage-6R] Optional plots written as PNG files.")
    print("========================================================================")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print("========================================================================")
        print("[Stage-6R ERROR] Script failed.")
        print(f"[Stage-6R ERROR] {exc}")
        traceback.print_exc()
        print("========================================================================")
        raise
