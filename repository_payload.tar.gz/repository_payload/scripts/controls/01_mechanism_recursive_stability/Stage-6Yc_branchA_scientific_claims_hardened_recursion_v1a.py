#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
========================================================================
Stage-6Yc: Branch-A Scientific-Claims Hardened Recursion — v1a
Project: Quantum-Emergent Gravity
Author: Arturo Ortiz-Tapia + ChatGPT
Build date: 2026-05-12
========================================================================

Purpose
-------
This script continues the Stage-6Y recursive program, but ONLY through
Branch A: the branch that can support scientific claims if it survives.

Branch A asks whether the recovered canonical two-sector law can be
stabilized by a non-tautological, lineage-preserving, source-driven recursive
operator rather than by generic low-k smoothing.

Targeted mechanisms tested here
-------------------------------
1) Source-operator geometry:
   boundary-to-bulk, edge-reading, asymmetric nonlocal transport.

2) Spectral gate:
   suppress generic low-k smoothing while preserving the two-sector modes.

3) Leakage law:
   do not merely preserve sectors; regulate mass transfer between early and
   central sectors.

4) Saturation / nonlinearity:
   prevent recursion from drifting toward the known undesired 57/43 type
   equilibrium when the canonical target is the historical ~27/73 split.

5) Annealing schedule:
   alpha / lambda / gamma vary through recursion time instead of staying
   constant.

6) Null-hardening:
   compare Branch A against matched-smoothness low-k nulls, not weak nulls.

Scientific discipline
---------------------
- No PDG injection.
- No spacetime/cosmology identification claim.
- No row-index family assignment.
- No canonical-rho-as-target-mode tautology.
- All recursive inputs must remain downstream of recovered BARI/NUFIT/VALENCIA
  lineage whenever such labels are available.
- If labels are absent, the script reports that family claims are not audited.

Expected runtime
----------------
The default grid is moderately heavy but practical. Increase N_REPEATS,
N_NULLS, parameter grids, or N_STEPS if you want a multi-hour/days audit.

Run in Spyder
-------------
%runfile /home/dakini/Downloads/010-Quantum_Emergent_Gravity/metric_stage_6Y_scripts/Stage-6Yc_branchA_scientific_claims_hardened_recursion_v1.py --wdir

Or place anywhere and run. The script auto-discovers the project root when
possible.
========================================================================
"""

from __future__ import annotations

import json
import math
import os
import sys
import time
import traceback
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd

try:
    import matplotlib.pyplot as plt
except Exception as exc:  # pragma: no cover
    plt = None
    print("[WARN] matplotlib unavailable; plots disabled:", exc)

try:
    from scipy.optimize import nnls
    from scipy.ndimage import gaussian_filter1d
    from scipy.interpolate import interp1d
except Exception as exc:  # pragma: no cover
    raise RuntimeError(
        "This script requires scipy. Please run inside the QEG Python env."
    ) from exc

# ---------------------------------------------------------------------
# User-adjustable configuration
# ---------------------------------------------------------------------
PROJECT_ROOT_CANDIDATES = [
    Path.cwd(),
    Path("/home/dakini/Downloads/010-Quantum_Emergent_Gravity"),
    Path("/mnt/data"),
]

STAGE_NAME = "Stage-6Yc"
OUTPUT_SUBDIR = "metric_stage_6Yc_outputs"
OUTPUT_PREFIX = "stage6Yc_branchA_scientific_claims_hardened_recursion_v1"

# Canonical target defaults inherited from the repaired universal law.
# If a canonical parameter file is discovered, these may be replaced.
DEFAULT_MU_EARLY = 0.150
DEFAULT_MU_CENTRAL = 0.536
DEFAULT_SIGMA_EARLY = 0.040
DEFAULT_SIGMA_CENTRAL = 0.115
DEFAULT_EARLY_MASS = 0.270
DEFAULT_CENTRAL_MASS = 0.730
KNOWN_BAD_EARLY_MASS = 0.570  # undesired drift reference mentioned upstream

# Numerical resolution and recursion sizes.
N_GRID = 361
N_STEPS = 180
N_REPEATS = 4
N_NULLS = 80
RANDOM_SEED = 61026

# Heavy-mode switch: set True for a longer run.
HEAVY_AUDIT = False
if HEAVY_AUDIT:
    N_STEPS = 360
    N_REPEATS = 8
    N_NULLS = 240

# Branch-A parameter grid. Increase for a much heavier search.
ALPHA0_GRID = [0.08, 0.12, 0.18]
LAMBDA0_GRID = [0.08, 0.14, 0.22]
GAMMA0_GRID = [0.20, 0.35, 0.55]
LEAK_GRID = [0.015, 0.035, 0.065]
SAT_GRID = [1.5, 2.5, 4.0]
EDGE_BIAS_GRID = [0.8, 1.2, 1.8]
TRANSPORT_WIDTH_GRID = [0.070, 0.110, 0.160]

# Null grid. These are matched-smoothness controls, not weak nulls.
NULL_LOWK_LIST = [2, 3, 4, 5, 6]
NULL_SMOOTH_SIGMA_LIST = [1.5, 2.5, 4.0, 6.0]

# Acceptance thresholds. These are intentionally conservative.
MIN_FINAL_R2 = 0.70
MIN_TWO_SECTOR_SCORE = 0.70
MIN_NULL_Z = 2.0
MAX_BAD_SPLIT_PROXIMITY = 0.20
MAX_MASS_DRIFT = 0.10

FAMILY_NAMES = ["BARI", "NUFIT", "VALENCIA"]

# ---------------------------------------------------------------------
# Utility functions
# ---------------------------------------------------------------------

def now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def safe_mkdir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def find_project_root() -> Path:
    for root in PROJECT_ROOT_CANDIDATES:
        if not root.exists():
            continue
        markers = [
            root / "metric_stage_6P_outputs",
            root / "metric_stage_6O_outputs",
            root / "metric_stage_6Y_outputs",
            root / "metrics_stage_6Y_outputs",
        ]
        if any(m.exists() for m in markers):
            return root
    return Path.cwd()


def robust_zscore(x: np.ndarray, eps: float = 1e-12) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    med = np.nanmedian(x)
    mad = np.nanmedian(np.abs(x - med))
    if not np.isfinite(mad) or mad < eps:
        sd = np.nanstd(x)
        return (x - np.nanmean(x)) / (sd + eps)
    return (x - med) / (1.4826 * mad + eps)


def normalize_nonnegative_mass(y: np.ndarray, eps: float = 1e-12) -> np.ndarray:
    y = np.asarray(y, dtype=float)
    y = np.nan_to_num(y, nan=0.0, posinf=0.0, neginf=0.0)
    y = y - np.min(y)
    s = np.sum(y)
    if s <= eps:
        return np.ones_like(y) / len(y)
    return y / s


def normalize_unit_l2(y: np.ndarray, eps: float = 1e-12) -> np.ndarray:
    y = np.asarray(y, dtype=float)
    y = np.nan_to_num(y, nan=0.0, posinf=0.0, neginf=0.0)
    n = np.linalg.norm(y)
    if n <= eps:
        return y * 0.0
    return y / n


def corrcoef(a: np.ndarray, b: np.ndarray) -> float:
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    mask = np.isfinite(a) & np.isfinite(b)
    if mask.sum() < 3:
        return float("nan")
    aa = a[mask]
    bb = b[mask]
    if np.std(aa) < 1e-14 or np.std(bb) < 1e-14:
        return float("nan")
    return float(np.corrcoef(aa, bb)[0, 1])


def r2_score(y: np.ndarray, pred: np.ndarray) -> float:
    y = np.asarray(y, dtype=float)
    pred = np.asarray(pred, dtype=float)
    mask = np.isfinite(y) & np.isfinite(pred)
    if mask.sum() < 3:
        return float("nan")
    yy = y[mask]
    pp = pred[mask]
    denom = np.sum((yy - yy.mean()) ** 2)
    if denom < 1e-14:
        return float("nan")
    return float(1.0 - np.sum((yy - pp) ** 2) / denom)


def rmse(y: np.ndarray, pred: np.ndarray) -> float:
    y = np.asarray(y, dtype=float)
    pred = np.asarray(pred, dtype=float)
    mask = np.isfinite(y) & np.isfinite(pred)
    if mask.sum() < 1:
        return float("nan")
    return float(np.sqrt(np.mean((y[mask] - pred[mask]) ** 2)))


def resample_to_grid(s: np.ndarray, y: np.ndarray, grid: np.ndarray) -> np.ndarray:
    s = np.asarray(s, dtype=float)
    y = np.asarray(y, dtype=float)
    mask = np.isfinite(s) & np.isfinite(y)
    s = s[mask]
    y = y[mask]
    if len(s) < 2:
        return np.zeros_like(grid)
    order = np.argsort(s)
    s = s[order]
    y = y[order]
    # Collapse duplicate s values by averaging.
    df = pd.DataFrame({"s": s, "y": y}).groupby("s", as_index=False)["y"].mean()
    s2 = df["s"].to_numpy()
    y2 = df["y"].to_numpy()
    if len(s2) < 2:
        return np.zeros_like(grid)
    f = interp1d(s2, y2, bounds_error=False, fill_value=(y2[0], y2[-1]))
    return np.asarray(f(grid), dtype=float)


def gaussian_template(grid: np.ndarray, mu: float, sigma: float) -> np.ndarray:
    sigma = max(float(sigma), 1e-4)
    y = np.exp(-0.5 * ((grid - mu) / sigma) ** 2)
    return normalize_nonnegative_mass(y)


def skewed_central_template(grid: np.ndarray, mu: float, sigma: float, skew: float = -0.20) -> np.ndarray:
    base = gaussian_template(grid, mu, sigma)
    skew_factor = 1.0 + skew * (grid - mu) / max(sigma, 1e-4)
    y = np.maximum(0.0, base * np.maximum(0.0, skew_factor))
    return normalize_nonnegative_mass(y)


def sector_masks(grid: np.ndarray) -> Dict[str, np.ndarray]:
    return {
        "early": grid <= 0.28,
        "transition": (grid > 0.28) & (grid < 0.40),
        "central": (grid >= 0.40) & (grid <= 0.72),
        "right_tail": grid > 0.72,
        "boundary": (grid <= 0.18) | (grid >= 0.82),
        "bulk": (grid >= 0.35) & (grid <= 0.70),
    }


def mass_in_mask(y_mass: np.ndarray, mask: np.ndarray) -> float:
    y = normalize_nonnegative_mass(y_mass)
    return float(np.sum(y[mask]))


def fft_lowpass(y: np.ndarray, k_keep: int) -> np.ndarray:
    y = np.asarray(y, dtype=float)
    coeff = np.fft.rfft(y)
    out = np.zeros_like(coeff)
    out[: max(1, min(k_keep + 1, len(coeff)))] = coeff[: max(1, min(k_keep + 1, len(coeff)))]
    return np.fft.irfft(out, n=len(y))


def spectral_energy_fraction(y: np.ndarray, k_keep: int) -> float:
    coeff = np.fft.rfft(np.asarray(y, dtype=float))
    p = np.abs(coeff) ** 2
    if p.sum() <= 1e-14:
        return 0.0
    return float(p[: min(k_keep + 1, len(p))].sum() / p.sum())


def spectral_gate(y: np.ndarray, e_mode: np.ndarray, c_mode: np.ndarray, lowk: int = 8, preserve: float = 0.85) -> np.ndarray:
    """Suppress generic low-k smoothness but explicitly preserve E/C modal content.

    This is the anti-null core: low-k content alone is not allowed to explain
    success. We keep the E/C sector modes and attenuate the rest of the low-k
    envelope.
    """
    y = np.asarray(y, dtype=float)
    e = normalize_unit_l2(e_mode)
    c = normalize_unit_l2(c_mode)
    ec = np.column_stack([e, c])
    coeff, *_ = np.linalg.lstsq(ec, y, rcond=None)
    modal = ec @ coeff
    low = fft_lowpass(y, lowk)
    residual = y - modal
    generic_low = fft_lowpass(residual, lowk)
    gated = modal + preserve * (residual - generic_low) + (1.0 - preserve) * residual
    return gated


def fit_ec_amplitudes(y: np.ndarray, e_mode: np.ndarray, c_mode: np.ndarray) -> Tuple[float, float, np.ndarray]:
    A = np.column_stack([normalize_nonnegative_mass(e_mode), normalize_nonnegative_mass(c_mode)])
    coeff, _ = nnls(A, np.maximum(0.0, np.asarray(y, dtype=float)))
    pred = A @ coeff
    return float(coeff[0]), float(coeff[1]), pred


def two_sector_score(y: np.ndarray, target: np.ndarray, e_mode: np.ndarray, c_mode: np.ndarray) -> Dict[str, float]:
    y_mass = normalize_nonnegative_mass(y)
    target_mass = normalize_nonnegative_mass(target)
    masks = sector_masks(np.linspace(0, 1, len(y)))
    Ae, Ac, fit = fit_ec_amplitudes(y_mass, e_mode, c_mode)
    early = mass_in_mask(y_mass, masks["early"])
    central = mass_in_mask(y_mass, masks["central"])
    ratio = early / (central + 1e-12)
    target_early = mass_in_mask(target_mass, masks["early"])
    target_central = mass_in_mask(target_mass, masks["central"])
    target_ratio = target_early / (target_central + 1e-12)
    split_error = abs(early - target_early) + abs(central - target_central)
    bad_proximity = abs(early - KNOWN_BAD_EARLY_MASS)
    return {
        "ec_r2": r2_score(target_mass, fit),
        "ec_corr": corrcoef(target_mass, fit),
        "early_mass": early,
        "central_mass": central,
        "early_central_ratio": ratio,
        "target_early_mass": target_early,
        "target_central_mass": target_central,
        "target_ratio": target_ratio,
        "split_abs_error": split_error,
        "bad_57_43_proximity": bad_proximity,
        "A_early": Ae,
        "A_central": Ac,
    }

# ---------------------------------------------------------------------
# Data discovery
# ---------------------------------------------------------------------

S_CANDIDATES = ["s", "s_normalized", "s_norm", "intrinsic_s", "arc_s", "grid_s", "x"]
RHO_CANDIDATES = ["rho", "rho_like", "density", "target", "rho_mass", "canonical_rho", "modal_rho", "y"]
KAPPA_CANDIDATES = ["kappa", "abs_kappa", "curvature", "kappa_like", "source", "source_like", "curvature_mass"]
FAMILY_CANDIDATES = ["family", "FIT", "FIT_id", "pdg_family", "source_family", "lineage_family"]


def list_csvs(root: Path) -> List[Path]:
    out = []
    for p in root.rglob("*.csv"):
        if any(skip in str(p) for skip in [".git", "__pycache__"]):
            continue
        out.append(p)
    return sorted(out)


def choose_col(cols: Iterable[str], candidates: List[str]) -> Optional[str]:
    lower = {c.lower(): c for c in cols}
    for cand in candidates:
        if cand.lower() in lower:
            return lower[cand.lower()]
    for c in cols:
        lc = c.lower()
        if any(cand.lower() in lc for cand in candidates):
            return c
    return None


def family_from_value(x: Any) -> Optional[str]:
    s = str(x).upper()
    for fam in FAMILY_NAMES:
        if fam in s:
            return fam
    return None


def score_csv_candidate(path: Path) -> Tuple[int, Dict[str, Optional[str]], int]:
    """Score only genuine row-level profile tables.

    v1 failure mode:
        stage6P_v5_candidate_rebuild_scores.csv was selected because its
        metadata columns looked superficially profile-like.  This function now
        rejects score/summary/inventory/audit tables and verifies that the
        candidate s column contains at least two finite, varying numeric values.
    """
    name = str(path).lower()

    # Hard reject known non-profile products.  These may contain words like
    # family/profile/rho/kappa but they are not intrinsic-coordinate rows.
    reject_tokens = [
        "score", "scores", "summary", "inventory", "ledger", "notes",
        "audit", "comparison", "cosmology", "null", "verdict", "metadata",
        "candidate_rebuild_scores", "input_candidate_inventory",
    ]
    if any(tok in name for tok in reject_tokens):
        return -999, {}, 0

    try:
        df = pd.read_csv(path, nrows=200)
    except Exception:
        return -999, {}, 0

    cols = list(df.columns)
    s_col = choose_col(cols, S_CANDIDATES)
    rho_col = choose_col(cols, RHO_CANDIDATES)
    kappa_col = choose_col(cols, KAPPA_CANDIDATES)
    family_col = choose_col(cols, FAMILY_CANDIDATES)

    # Must have a plausible intrinsic coordinate and target field.
    if not s_col or not rho_col:
        return -999, {"s": s_col, "rho": rho_col, "kappa": kappa_col, "family": family_col}, 0

    s_test = pd.to_numeric(df[s_col], errors="coerce").to_numpy()
    rho_test = pd.to_numeric(df[rho_col], errors="coerce").to_numpy()
    finite_s = np.isfinite(s_test)
    finite_rho = np.isfinite(rho_test)
    if finite_s.sum() < 4 or finite_rho.sum() < 4:
        return -999, {"s": s_col, "rho": rho_col, "kappa": kappa_col, "family": family_col}, 0
    if np.nanmax(s_test[finite_s]) - np.nanmin(s_test[finite_s]) <= 1e-12:
        return -999, {"s": s_col, "rho": rho_col, "kappa": kappa_col, "family": family_col}, 0

    score = 0
    score += 10  # valid s + rho numeric table
    if kappa_col: score += 5
    if family_col: score += 3

    # Prefer actual profile-like, family-aware, repaired/canonical row tables.
    for tag, val in [
        ("stage6p", 5), ("stage6q", 4), ("stage6x", 4), ("stage6y", 6),
        ("family", 4), ("repaired", 3), ("canonical", 3), ("profile", 5),
        ("observable", 3), ("rho", 2), ("kappa", 2),
        ("48bins", 4), ("361bins", 3),
    ]:
        if tag in name:
            score += val

    # De-prefer generic tables even if they passed numeric validation.
    for tag, val in [("fit", -4), ("parameter", -3), ("result", -2)]:
        if tag in name:
            score += val

    try:
        nrows = sum(1 for _ in open(path, "r", errors="ignore")) - 1
    except Exception:
        nrows = 0
    if nrows >= 40:
        score += 2
    if nrows >= 100:
        score += 2
    return score, {"s": s_col, "rho": rho_col, "kappa": kappa_col, "family": family_col}, nrows


def load_best_profiles(root: Path, grid: np.ndarray) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    csvs = list_csvs(root)
    rows = []
    for p in csvs:
        score, cols, nrows = score_csv_candidate(p)
        if score > 0:
            rows.append({"path": str(p), "score": score, "nrows": nrows, **cols})
    inv = pd.DataFrame(rows).sort_values(["score", "nrows"], ascending=False)
    if inv.empty:
        raise FileNotFoundError("No usable CSV candidates found under project root.")

    # Prefer candidates with s + rho + kappa. If no kappa, accept s + rho and derive source from rho gradient.
    usable = inv[(inv["s"].notna()) & (inv["rho"].notna())].copy()
    if usable.empty:
        raise FileNotFoundError("No CSV with recognizable s and rho-like columns found.")

    # Select the first candidate that remains valid when fully loaded.
    best = None
    df = None
    path = None
    for _, cand in usable.iterrows():
        cand = cand.to_dict()
        cand_path = Path(cand["path"])
        try:
            cand_df = pd.read_csv(cand_path)
            cand_s = pd.to_numeric(cand_df[cand["s"]], errors="coerce").to_numpy()
            if np.isfinite(cand_s).sum() >= 4 and (np.nanmax(cand_s) - np.nanmin(cand_s) > 1e-12):
                best = cand
                df = cand_df
                path = cand_path
                break
        except Exception:
            continue
    if best is None or df is None or path is None:
        raise FileNotFoundError("No fully usable row-profile CSV survived validation.")

    s_col = best["s"]
    rho_col = best["rho"]
    kappa_col = best.get("kappa")
    fam_col = best.get("family")

    s_raw = pd.to_numeric(df[s_col], errors="coerce").to_numpy()
    # Normalize s into [0, 1] if needed.
    finite = np.isfinite(s_raw)
    if finite.sum() < 2:
        raise ValueError(f"Selected file has unusable s column after validation: {path}")
    s_min, s_max = np.nanmin(s_raw), np.nanmax(s_raw)
    if s_max - s_min > 1e-12:
        s_norm = (s_raw - s_min) / (s_max - s_min)
    else:
        s_norm = s_raw

    rho_raw = pd.to_numeric(df[rho_col], errors="coerce").to_numpy()
    if kappa_col and kappa_col in df.columns:
        kappa_raw = pd.to_numeric(df[kappa_col], errors="coerce").to_numpy()
    else:
        # Non-tautological fallback: use curvature-like derivative structure, not rho itself.
        rr = resample_to_grid(s_norm, rho_raw, grid)
        kk = np.gradient(np.gradient(robust_zscore(rr), grid), grid)
        kappa_raw = np.interp(s_norm, grid, kk)
        kappa_col = "DERIVED_second_derivative_of_rho_for_source_audit"

    fam_values = None
    if fam_col and fam_col in df.columns:
        fam_values = df[fam_col].map(family_from_value).to_numpy()

    # Build pooled profile.
    rho_grid = resample_to_grid(s_norm, rho_raw, grid)
    kappa_grid = resample_to_grid(s_norm, kappa_raw, grid)

    out_rows = []
    out_rows.append({
        "family": "POOLED",
        "s": grid,
        "rho": normalize_nonnegative_mass(rho_grid),
        "kappa": robust_zscore(kappa_grid),
    })

    if fam_values is not None and pd.Series(fam_values).notna().sum() > 0:
        temp = pd.DataFrame({"s": s_norm, "rho": rho_raw, "kappa": kappa_raw, "family": fam_values})
        for fam in FAMILY_NAMES:
            sub = temp[temp["family"] == fam]
            if len(sub) >= 4:
                out_rows.append({
                    "family": fam,
                    "s": grid,
                    "rho": normalize_nonnegative_mass(resample_to_grid(sub["s"], sub["rho"], grid)),
                    "kappa": robust_zscore(resample_to_grid(sub["s"], sub["kappa"], grid)),
                })

    prof = pd.concat([
        pd.DataFrame({"family": r["family"], "s": r["s"], "rho": r["rho"], "kappa": r["kappa"]})
        for r in out_rows
    ], ignore_index=True)

    meta = {
        "selected_input": str(path),
        "selected_columns": {"s": s_col, "rho": rho_col, "kappa": kappa_col, "family": fam_col},
        "candidate_inventory_rows": len(inv),
        "family_profiles_found": sorted([x for x in prof["family"].unique() if x != "POOLED"]),
    }
    return prof, {"meta": meta, "inventory": inv}


def load_canonical_parameters(root: Path) -> Dict[str, float]:
    params = {
        "mu_early": DEFAULT_MU_EARLY,
        "mu_central": DEFAULT_MU_CENTRAL,
        "sigma_early": DEFAULT_SIGMA_EARLY,
        "sigma_central": DEFAULT_SIGMA_CENTRAL,
        "early_mass": DEFAULT_EARLY_MASS,
        "central_mass": DEFAULT_CENTRAL_MASS,
        "source": "defaults",
    }
    candidate_files = []
    for p in root.rglob("*.csv"):
        name = p.name.lower()
        if any(tag in name for tag in ["canonical", "lobe", "parameter", "invariant", "stage6q", "stage6p_v6"]):
            candidate_files.append(p)
    for p in candidate_files:
        try:
            df = pd.read_csv(p)
        except Exception:
            continue
        cols = {c.lower(): c for c in df.columns}
        text = " ".join(df.columns).lower()
        if not any(k in text for k in ["early", "central", "mu", "mass"]):
            continue
        try:
            for key, aliases in {
                "mu_early": ["mu_early", "early_mu", "early_center", "center_early"],
                "mu_central": ["mu_central", "central_mu", "central_center", "center_central"],
                "sigma_early": ["sigma_early", "early_sigma", "early_width"],
                "sigma_central": ["sigma_central", "central_sigma", "central_width"],
                "early_mass": ["early_mass", "early_mass_fraction", "mass_early"],
                "central_mass": ["central_mass", "central_mass_fraction", "mass_central"],
            }.items():
                for a in aliases:
                    if a in cols:
                        vals = pd.to_numeric(df[cols[a]], errors="coerce").dropna()
                        if len(vals):
                            params[key] = float(vals.iloc[0])
                            params["source"] = str(p)
                            break
        except Exception:
            continue
    # sanity clamp
    params["mu_early"] = float(np.clip(params["mu_early"], 0.01, 0.30))
    params["mu_central"] = float(np.clip(params["mu_central"], 0.35, 0.75))
    params["sigma_early"] = float(np.clip(params["sigma_early"], 0.015, 0.12))
    params["sigma_central"] = float(np.clip(params["sigma_central"], 0.04, 0.22))
    em = max(1e-6, params["early_mass"])
    cm = max(1e-6, params["central_mass"])
    total = em + cm
    params["early_mass"] = em / total
    params["central_mass"] = cm / total
    return params

# ---------------------------------------------------------------------
# Branch-A operator construction
# ---------------------------------------------------------------------

@dataclass
class BranchAParams:
    alpha0: float
    lambda0: float
    gamma0: float
    leak: float
    sat: float
    edge_bias: float
    transport_width: float
    lowk_gate: int = 8
    preserve_two_sector: float = 0.88


def anneal(t: int, T: int, alpha0: float, lambda0: float, gamma0: float) -> Tuple[float, float, float]:
    tau = t / max(1, T - 1)
    # early: stronger source reading; late: stronger leakage regulation/saturation.
    alpha = alpha0 * (0.55 + 0.90 * math.exp(-2.2 * tau))
    lam = lambda0 * (0.65 + 0.85 * tau)
    gamma = gamma0 * (0.45 + 1.25 * tau)
    return float(alpha), float(lam), float(gamma)


def make_asymmetric_transport_kernel(grid: np.ndarray, params: BranchAParams) -> np.ndarray:
    """Kernel K[target, source] reading edges and transporting to bulk.

    The kernel is intentionally non-translation-invariant. It is not a simple
    convolution and therefore directly tests Branch-A geometry.
    """
    s_t = grid[:, None]
    s_src = grid[None, :]

    left_edge = np.exp(-0.5 * (s_src / 0.16) ** 2)
    right_edge = 0.35 * np.exp(-0.5 * ((1 - s_src) / 0.20) ** 2)
    edge_reader = params.edge_bias * (left_edge + right_edge)

    central_receiver = np.exp(-0.5 * ((s_t - DEFAULT_MU_CENTRAL) / params.transport_width) ** 2)
    early_receiver = 0.55 * np.exp(-0.5 * ((s_t - DEFAULT_MU_EARLY) / max(0.035, 0.55 * params.transport_width)) ** 2)

    # Asymmetric boundary-to-bulk term.
    K1 = central_receiver * edge_reader

    # Mild early self-read term to preserve early sector without letting it dominate.
    early_source = np.exp(-0.5 * ((s_src - DEFAULT_MU_EARLY) / 0.10) ** 2)
    K2 = early_receiver * early_source

    # Anti-generic smoothing: subtract weak broad low-k background.
    broad = np.exp(-0.5 * ((s_t - s_src) / 0.35) ** 2)
    K = K1 + K2 - 0.08 * broad

    # Row normalize absolute mass conservatively.
    K = np.nan_to_num(K)
    row_norm = np.sum(np.abs(K), axis=1, keepdims=True) + 1e-12
    K = K / row_norm
    return K


def leakage_regulator(y: np.ndarray, target: np.ndarray, e_mode: np.ndarray, c_mode: np.ndarray, leak: float) -> np.ndarray:
    """Regulate early <-> central mass exchange toward canonical split."""
    y_mass = normalize_nonnegative_mass(y)
    target_mass = normalize_nonnegative_mass(target)
    masks = sector_masks(np.linspace(0, 1, len(y_mass)))
    early = mass_in_mask(y_mass, masks["early"])
    target_early = mass_in_mask(target_mass, masks["early"])
    delta = target_early - early
    # Positive delta injects into early mode and removes from central; negative does reverse.
    e = normalize_nonnegative_mass(e_mode)
    c = normalize_nonnegative_mass(c_mode)
    update = leak * delta * (e - c)
    return normalize_nonnegative_mass(y_mass + update)


def saturation_guard(y: np.ndarray, target: np.ndarray, sat: float) -> np.ndarray:
    """Nonlinear guard against drift to wrong split, especially around 57/43."""
    y_mass = normalize_nonnegative_mass(y)
    target_mass = normalize_nonnegative_mass(target)
    masks = sector_masks(np.linspace(0, 1, len(y_mass)))
    early = mass_in_mask(y_mass, masks["early"])
    target_early = mass_in_mask(target_mass, masks["early"])
    bad_pull = np.exp(-sat * (early - KNOWN_BAD_EARLY_MASS) ** 2)
    canonical_pull = np.tanh(sat * (target_early - early))
    # If near bad split, amplify correction away from it.
    strength = 0.010 * (1.0 + bad_pull)
    correction = strength * canonical_pull
    e = normalize_nonnegative_mass(gaussian_template(np.linspace(0, 1, len(y_mass)), DEFAULT_MU_EARLY, DEFAULT_SIGMA_EARLY))
    c = normalize_nonnegative_mass(gaussian_template(np.linspace(0, 1, len(y_mass)), DEFAULT_MU_CENTRAL, DEFAULT_SIGMA_CENTRAL))
    return normalize_nonnegative_mass(y_mass + correction * (e - c))


def branch_a_step(
    y: np.ndarray,
    source: np.ndarray,
    target: np.ndarray,
    e_mode: np.ndarray,
    c_mode: np.ndarray,
    K: np.ndarray,
    t: int,
    T: int,
    params: BranchAParams,
) -> np.ndarray:
    alpha, lam, gamma = anneal(t, T, params.alpha0, params.lambda0, params.gamma0)
    source_z = robust_zscore(source)
    response = K @ source_z
    response = robust_zscore(response)
    response = normalize_nonnegative_mass(response)

    # Branch-A update: source-driven nonlocal response + spectral-gated two-sector preservation.
    y0 = normalize_nonnegative_mass(y)
    y_mix = normalize_nonnegative_mass((1.0 - alpha) * y0 + alpha * response)
    y_gate = spectral_gate(y_mix, e_mode, c_mode, lowk=params.lowk_gate, preserve=params.preserve_two_sector)
    y_gate = normalize_nonnegative_mass(y_gate)

    # Leakage law and saturation/nonlinear stabilization.
    y_leak = leakage_regulator(y_gate, target, e_mode, c_mode, leak=lam * params.leak)
    y_sat = saturation_guard(y_leak, target, sat=gamma * params.sat)

    # Small damping to avoid numerical oscillation while not allowing pure smoothing.
    y_next = normalize_nonnegative_mass(0.96 * y_sat + 0.04 * y0)
    return y_next


def run_branch_a(
    source: np.ndarray,
    initial: np.ndarray,
    target: np.ndarray,
    e_mode: np.ndarray,
    c_mode: np.ndarray,
    params: BranchAParams,
    n_steps: int,
) -> Dict[str, Any]:
    grid = np.linspace(0, 1, len(source))
    K = make_asymmetric_transport_kernel(grid, params)
    y = normalize_nonnegative_mass(initial)
    history = []
    for t in range(n_steps):
        y = branch_a_step(y, source, target, e_mode, c_mode, K, t, n_steps, params)
        if t % max(1, n_steps // 30) == 0 or t == n_steps - 1:
            metrics = two_sector_score(y, target, e_mode, c_mode)
            metrics.update({
                "t": t,
                "r2": r2_score(target, y),
                "corr": corrcoef(target, y),
                "rmse": rmse(target, y),
                "lowk_energy_k3": spectral_energy_fraction(y, 3),
            })
            history.append(metrics)
    final_metrics = two_sector_score(y, target, e_mode, c_mode)
    final_metrics.update({
        "r2": r2_score(target, y),
        "corr": corrcoef(target, y),
        "rmse": rmse(target, y),
        "operator_effective_rank": effective_rank(K),
        "operator_asymmetry": matrix_asymmetry(K),
        "operator_toeplitz_deviation": toeplitz_deviation(K),
        "params": asdict(params),
    })
    return {"final": y, "history": pd.DataFrame(history), "metrics": final_metrics, "kernel": K}

# ---------------------------------------------------------------------
# Null hardening
# ---------------------------------------------------------------------

def matched_lowk_null(source: np.ndarray, rng: np.random.Generator, lowk: int, smooth_sigma: float) -> np.ndarray:
    """Create a null with matched low-k energy/smoothness but phase-randomized structure."""
    x = robust_zscore(source)
    coeff = np.fft.rfft(x)
    mag = np.abs(coeff)
    phase = rng.uniform(0, 2 * np.pi, size=len(coeff))
    phase[0] = 0.0
    # Preserve low-k magnitudes, randomize phases; attenuate high-k similarly.
    new_coeff = mag * np.exp(1j * phase)
    y = np.fft.irfft(new_coeff, n=len(x))
    y = gaussian_filter1d(y, sigma=smooth_sigma, mode="nearest")
    # Match source variance and low-k envelope roughly.
    y_low = fft_lowpass(y, lowk)
    x_low = fft_lowpass(x, lowk)
    scale = (np.std(x_low) + 1e-12) / (np.std(y_low) + 1e-12)
    return robust_zscore(scale * y)


def generic_lowk_smoother_null(initial: np.ndarray, target: np.ndarray, k_keep: int, n_steps: int) -> np.ndarray:
    """A strong low-k null: repeated low-pass relaxation toward own smooth envelope.

    This is intentionally not weak. It tests whether low-k smoothing alone can mimic
    Branch A without source-operator geometry and leakage regulation.
    """
    y = normalize_nonnegative_mass(initial)
    for _ in range(n_steps):
        smooth = normalize_nonnegative_mass(fft_lowpass(y, k_keep))
        y = normalize_nonnegative_mass(0.88 * y + 0.12 * smooth)
    return y

# ---------------------------------------------------------------------
# Operator diagnostics
# ---------------------------------------------------------------------

def effective_rank(M: np.ndarray, eps: float = 1e-14) -> float:
    s = np.linalg.svd(M, compute_uv=False)
    p = s / (s.sum() + eps)
    H = -np.sum(p * np.log(p + eps))
    return float(np.exp(H))


def matrix_asymmetry(M: np.ndarray) -> float:
    if M.shape[0] != M.shape[1]:
        return float("nan")
    return float(np.linalg.norm(M - M.T) / (np.linalg.norm(M) + 1e-12))


def toeplitz_deviation(M: np.ndarray) -> float:
    """Deviation from translation-invariant Toeplitz structure."""
    n, m = M.shape
    vals = {}
    counts = {}
    for i in range(n):
        for j in range(m):
            d = i - j
            vals[d] = vals.get(d, 0.0) + M[i, j]
            counts[d] = counts.get(d, 0) + 1
    T = np.zeros_like(M)
    for i in range(n):
        for j in range(m):
            d = i - j
            T[i, j] = vals[d] / counts[d]
    return float(np.linalg.norm(M - T) / (np.linalg.norm(M) + 1e-12))

# ---------------------------------------------------------------------
# Full audit
# ---------------------------------------------------------------------

def build_canonical_target(grid: np.ndarray, params: Dict[str, float]) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    E = gaussian_template(grid, params["mu_early"], params["sigma_early"])
    C = skewed_central_template(grid, params["mu_central"], params["sigma_central"], skew=-0.18)
    target = normalize_nonnegative_mass(params["early_mass"] * E + params["central_mass"] * C)
    return target, E, C


def evaluate_profile_family(
    family: str,
    prof: pd.DataFrame,
    target: np.ndarray,
    E: np.ndarray,
    C: np.ndarray,
    rng: np.random.Generator,
    outdir: Path,
) -> Dict[str, Any]:
    sub = prof[prof["family"] == family].sort_values("s")
    source = sub["kappa"].to_numpy(dtype=float)
    rho_obs = normalize_nonnegative_mass(sub["rho"].to_numpy(dtype=float))

    # Initial condition: observed rho lightly mixed with uniform mass, avoiding target insertion.
    initial = normalize_nonnegative_mass(0.80 * rho_obs + 0.20 * np.ones_like(rho_obs) / len(rho_obs))

    records = []
    best: Optional[Dict[str, Any]] = None
    total = len(ALPHA0_GRID) * len(LAMBDA0_GRID) * len(GAMMA0_GRID) * len(LEAK_GRID) * len(SAT_GRID) * len(EDGE_BIAS_GRID) * len(TRANSPORT_WIDTH_GRID)
    idx = 0
    for alpha0 in ALPHA0_GRID:
        for lambda0 in LAMBDA0_GRID:
            for gamma0 in GAMMA0_GRID:
                for leak in LEAK_GRID:
                    for sat in SAT_GRID:
                        for edge_bias in EDGE_BIAS_GRID:
                            for tw in TRANSPORT_WIDTH_GRID:
                                idx += 1
                                params = BranchAParams(alpha0, lambda0, gamma0, leak, sat, edge_bias, tw)
                                run = run_branch_a(source, initial, target, E, C, params, N_STEPS)
                                m = dict(run["metrics"])
                                m.update({"family": family, "grid_index": idx, "grid_total": total})
                                records.append(flatten_metrics(m))
                                score = branch_a_claim_score(m)
                                if best is None or score > best["score"]:
                                    best = {"score": score, "run": run, "metrics": m, "params": params}
    rec_df = pd.DataFrame(records)
    rec_df.to_csv(outdir / f"{OUTPUT_PREFIX}_{family}_branchA_grid.csv", index=False)

    assert best is not None
    best_run = best["run"]
    best_final = best_run["final"]

    # Strong nulls: parameterized matched smoothness + low-k relaxation.
    null_rows = []
    for i in range(N_NULLS):
        lowk = int(rng.choice(NULL_LOWK_LIST))
        sig = float(rng.choice(NULL_SMOOTH_SIGMA_LIST))
        null_source = matched_lowk_null(source, rng, lowk=lowk, smooth_sigma=sig)
        # Use best Branch-A params but null source: this isolates geometry dependence.
        null_run = run_branch_a(null_source, initial, target, E, C, best["params"], max(40, N_STEPS // 2))
        nm = dict(null_run["metrics"])
        nm.update({"family": family, "null_type": "matched_lowk_source_phase_randomized", "null_id": i, "lowk": lowk, "smooth_sigma": sig})
        null_rows.append(flatten_metrics(nm))

    for k in NULL_LOWK_LIST:
        y_null = generic_lowk_smoother_null(initial, target, k_keep=k, n_steps=N_STEPS)
        nm = two_sector_score(y_null, target, E, C)
        nm.update({"r2": r2_score(target, y_null), "corr": corrcoef(target, y_null), "rmse": rmse(target, y_null)})
        nm.update({"family": family, "null_type": "generic_lowk_smoothing_only", "null_id": f"lowk{k}", "lowk": k, "smooth_sigma": np.nan})
        null_rows.append(flatten_metrics(nm))

    null_df = pd.DataFrame(null_rows)
    null_df.to_csv(outdir / f"{OUTPUT_PREFIX}_{family}_null_hardening.csv", index=False)

    # Null z-score against Branch-A best.
    null_r2 = pd.to_numeric(null_df["r2"], errors="coerce").dropna()
    best_r2 = float(best["metrics"].get("r2", np.nan))
    z = float((best_r2 - null_r2.mean()) / (null_r2.std(ddof=1) + 1e-12)) if len(null_r2) > 2 else float("nan")
    p_emp = float((1 + np.sum(null_r2 >= best_r2)) / (len(null_r2) + 1)) if len(null_r2) else float("nan")

    # Save curves.
    curve_df = pd.DataFrame({
        "family": family,
        "s": sub["s"].to_numpy(dtype=float),
        "source_kappa": source,
        "rho_observed": rho_obs,
        "canonical_target": target,
        "E_mode": E,
        "C_mode": C,
        "branchA_final": best_final,
    })
    curve_df.to_csv(outdir / f"{OUTPUT_PREFIX}_{family}_best_curves.csv", index=False)
    best_run["history"].to_csv(outdir / f"{OUTPUT_PREFIX}_{family}_best_history.csv", index=False)
    pd.DataFrame(best_run["kernel"]).to_csv(outdir / f"{OUTPUT_PREFIX}_{family}_best_kernel.csv", index=False)

    plot_family_result(family, curve_df, best_run["history"], null_df, outdir)

    result = dict(best["metrics"])
    result.update({
        "family": family,
        "branchA_score": best["score"],
        "null_r2_mean": float(null_r2.mean()) if len(null_r2) else float("nan"),
        "null_r2_std": float(null_r2.std(ddof=1)) if len(null_r2) > 1 else float("nan"),
        "null_r2_z": z,
        "null_empirical_p_ge_best": p_emp,
        "best_params": asdict(best["params"]),
        "n_nulls": int(len(null_df)),
    })
    return result


def flatten_metrics(m: Dict[str, Any]) -> Dict[str, Any]:
    out = {}
    for k, v in m.items():
        if isinstance(v, dict):
            for kk, vv in v.items():
                out[f"{k}_{kk}"] = vv
        elif isinstance(v, (list, tuple, np.ndarray)):
            continue
        else:
            out[k] = v
    return out


def branch_a_claim_score(m: Dict[str, Any]) -> float:
    r2 = float(m.get("r2", -999) if np.isfinite(m.get("r2", np.nan)) else -999)
    ec = float(m.get("ec_r2", -999) if np.isfinite(m.get("ec_r2", np.nan)) else -999)
    split_err = float(m.get("split_abs_error", 9))
    bad_prox = float(m.get("bad_57_43_proximity", 0))
    asym = float(m.get("operator_asymmetry", 0) if np.isfinite(m.get("operator_asymmetry", np.nan)) else 0)
    toe = float(m.get("operator_toeplitz_deviation", 0) if np.isfinite(m.get("operator_toeplitz_deviation", np.nan)) else 0)
    # Reward fit, two-sector preservation, non-Toeplitz/asymmetric geometry, and distance from bad split.
    return 2.2 * r2 + 1.4 * ec - 1.8 * split_err + 0.20 * asym + 0.15 * toe + 0.35 * min(1.0, bad_prox)


def classify_result(summary: pd.DataFrame) -> str:
    if summary.empty:
        return "D_NO_RESULTS"
    fam_rows = summary[summary["family"].isin(FAMILY_NAMES)]
    use_rows = fam_rows if not fam_rows.empty else summary
    min_r2 = pd.to_numeric(use_rows["r2"], errors="coerce").min()
    min_ec = pd.to_numeric(use_rows["ec_r2"], errors="coerce").min()
    max_drift = pd.to_numeric(use_rows["split_abs_error"], errors="coerce").max()
    min_z = pd.to_numeric(use_rows["null_r2_z"], errors="coerce").min()
    max_bad_prox = pd.to_numeric(use_rows["bad_57_43_proximity"], errors="coerce").max()

    if min_r2 >= MIN_FINAL_R2 and min_ec >= MIN_TWO_SECTOR_SCORE and max_drift <= MAX_MASS_DRIFT and min_z >= MIN_NULL_Z:
        return "A_BRANCH_A_SURVIVES_HARDENED_NULLS_SCIENTIFIC_EVIDENCE_SUPPORTED"
    if min_r2 >= 0.50 and min_ec >= 0.50 and min_z >= 1.0:
        return "B_BRANCH_A_PARTIALLY_SUPPORTED_REVIEW_REQUIRED"
    if min_r2 >= 0.35 or min_ec >= 0.45:
        return "C_SIGNAL_PRESENT_BUT_NOT_CLAIM_GRADE"
    return "D_BRANCH_A_NOT_SUPPORTED_UNDER_CURRENT_AUDIT"

# ---------------------------------------------------------------------
# Plotting
# ---------------------------------------------------------------------

def plot_family_result(family: str, curve_df: pd.DataFrame, hist_df: pd.DataFrame, null_df: pd.DataFrame, outdir: Path) -> None:
    if plt is None:
        return
    s = curve_df["s"].to_numpy()

    fig = plt.figure(figsize=(11, 7))
    ax = fig.add_subplot(111)
    ax.plot(s, curve_df["rho_observed"], label="rho observed / loaded")
    ax.plot(s, curve_df["canonical_target"], label="canonical E+C target")
    ax.plot(s, curve_df["branchA_final"], label="Branch A final")
    ax.plot(s, curve_df["E_mode"], label="E mode", alpha=0.55)
    ax.plot(s, curve_df["C_mode"], label="C mode", alpha=0.55)
    ax.set_title(f"{STAGE_NAME} Branch A final recursion — {family}")
    ax.set_xlabel("intrinsic s")
    ax.set_ylabel("normalized mass / mode")
    ax.legend(loc="best")
    fig.tight_layout()
    fig.savefig(outdir / f"{OUTPUT_PREFIX}_{family}_branchA_final_overlay.png", dpi=160)
    plt.close(fig)

    if not hist_df.empty:
        fig = plt.figure(figsize=(10, 6))
        ax = fig.add_subplot(111)
        ax.plot(hist_df["t"], hist_df["r2"], label="R²")
        ax.plot(hist_df["t"], hist_df["early_mass"], label="early mass")
        ax.plot(hist_df["t"], hist_df["central_mass"], label="central mass")
        ax.axhline(DEFAULT_EARLY_MASS, linestyle="--", label="canonical early mass")
        ax.axhline(KNOWN_BAD_EARLY_MASS, linestyle=":", label="undesired 57/43 early")
        ax.set_title(f"{STAGE_NAME} recursion history — {family}")
        ax.set_xlabel("recursion step")
        ax.legend(loc="best")
        fig.tight_layout()
        fig.savefig(outdir / f"{OUTPUT_PREFIX}_{family}_recursion_history.png", dpi=160)
        plt.close(fig)

    if not null_df.empty:
        fig = plt.figure(figsize=(10, 6))
        ax = fig.add_subplot(111)
        vals = pd.to_numeric(null_df["r2"], errors="coerce").dropna().to_numpy()
        if len(vals):
            ax.hist(vals, bins=24, alpha=0.8, label="matched null R²")
            best_r2 = r2_score(curve_df["canonical_target"].to_numpy(), curve_df["branchA_final"].to_numpy())
            ax.axvline(best_r2, linewidth=2, label="Branch A best R²")
        ax.set_title(f"{STAGE_NAME} null-hardening — {family}")
        ax.set_xlabel("R² vs canonical target")
        ax.set_ylabel("count")
        ax.legend(loc="best")
        fig.tight_layout()
        fig.savefig(outdir / f"{OUTPUT_PREFIX}_{family}_null_hardening_hist.png", dpi=160)
        plt.close(fig)

# ---------------------------------------------------------------------
# Notes and main
# ---------------------------------------------------------------------

def write_notes(outdir: Path, verdict: str, meta: Dict[str, Any], canonical: Dict[str, float], summary: pd.DataFrame) -> None:
    notes = []
    notes.append("=" * 72)
    notes.append(f"{STAGE_NAME}: Branch-A Scientific-Claims Hardened Recursion — v1")
    notes.append("=" * 72)
    notes.append(f"Generated: {now()}")
    notes.append("")
    notes.append("VERDICT")
    notes.append("-------")
    notes.append(verdict)
    notes.append("")
    notes.append("LINEAGE PRESERVATION RULE")
    notes.append("-------------------------")
    notes.append("Stage-6Yc recursive experiments are NOT independent synthetic systems.")
    notes.append("They are downstream dynamical probes of the recovered BARI / NUFIT / VALENCIA lineage when labels are available.")
    notes.append("No row-index family assignment is performed.")
    notes.append("")
    notes.append("BRANCH-A CLAIM DISCIPLINE")
    notes.append("-------------------------")
    notes.append("This script evaluates only the branch intended to support scientific claims:")
    notes.append("source-operator geometry + spectral gate + leakage regulation + saturation + annealing + hard nulls.")
    notes.append("Branch A must beat matched-smoothness low-k nulls, not merely weak random nulls.")
    notes.append("")
    notes.append("CANONICAL PARAMETERS")
    notes.append("--------------------")
    for k, v in canonical.items():
        notes.append(f"{k}: {v}")
    notes.append("")
    notes.append("INPUT META")
    notes.append("----------")
    notes.append(json.dumps(meta, indent=2, default=str))
    notes.append("")
    notes.append("SUMMARY")
    notes.append("-------")
    if summary.empty:
        notes.append("No summary rows produced.")
    else:
        notes.append(summary.to_string(index=False))
    notes.append("")
    notes.append("INTERPRETATION GUIDE")
    notes.append("--------------------")
    notes.append("A verdict means Branch A survived the hardened audit and can be logged as scientific evidence.")
    notes.append("B means promising but review-required.")
    notes.append("C means signal exists but is not claim-grade.")
    notes.append("D means the current Branch-A construction failed under the audit.")
    notes.append("")
    notes.append("NO PHYSICAL CLAIMS")
    notes.append("------------------")
    notes.append("Any cosmology/QEG spacetime comparison remains external bookkeeping only.")
    notes.append("=" * 72)
    (outdir / f"{OUTPUT_PREFIX}_notes.txt").write_text("\n".join(notes), encoding="utf-8")


def main() -> None:
    print("=" * 72)
    print(f"{STAGE_NAME}: Branch-A Scientific-Claims Hardened Recursion — v1")
    print("=" * 72)
    print("[INFO] Python executable:", sys.executable)
    print("[INFO] Working directory:", Path.cwd())
    print("[INFO] Started:", now())

    root = find_project_root()
    outdir = root / OUTPUT_SUBDIR
    safe_mkdir(outdir)
    print("[INFO] Project root:", root)
    print("[INFO] Output directory:", outdir)

    rng = np.random.default_rng(RANDOM_SEED)
    grid = np.linspace(0.0, 1.0, N_GRID)

    canonical = load_canonical_parameters(root)
    target, E, C = build_canonical_target(grid, canonical)
    print("[INFO] Canonical parameter source:", canonical.get("source"))
    print("[INFO] Canonical early/central masses:", canonical["early_mass"], canonical["central_mass"])

    profiles, discovery = load_best_profiles(root, grid)
    meta = discovery["meta"]
    inv = discovery["inventory"]
    inv.to_csv(outdir / f"{OUTPUT_PREFIX}_input_candidate_inventory.csv", index=False)
    profiles.to_csv(outdir / f"{OUTPUT_PREFIX}_loaded_profiles.csv", index=False)
    print("[INFO] Selected input:", meta["selected_input"])
    print("[INFO] Selected columns:", meta["selected_columns"])
    print("[INFO] Profiles:", sorted(profiles["family"].unique()))

    families = ["POOLED"] + [fam for fam in FAMILY_NAMES if fam in set(profiles["family"].unique())]
    if families == ["POOLED"]:
        print("[WARN] No row-level BARI/NUFIT/VALENCIA labels found in selected input.")
        print("[WARN] The script will audit pooled Branch A only; family-universality claims remain unavailable.")

    summary_rows = []
    for fam in families:
        print("-" * 72)
        print(f"[RUN] Family/profile: {fam}")
        try:
            result = evaluate_profile_family(fam, profiles, target, E, C, rng, outdir)
            summary_rows.append(flatten_metrics(result))
            print(f"[DONE] {fam}: R2={result.get('r2'):.4f}, EC_R2={result.get('ec_r2'):.4f}, null_z={result.get('null_r2_z'):.3f}")
        except Exception as exc:
            print(f"[ERROR] {fam} failed: {exc}")
            traceback.print_exc()
            summary_rows.append({"family": fam, "error": str(exc)})

    summary = pd.DataFrame(summary_rows)
    verdict = classify_result(summary)
    summary.to_csv(outdir / f"{OUTPUT_PREFIX}_summary.csv", index=False)

    audit = {
        "stage": STAGE_NAME,
        "version": "v1",
        "created": now(),
        "verdict": verdict,
        "project_root": str(root),
        "output_dir": str(outdir),
        "canonical_parameters": canonical,
        "input_meta": meta,
        "config": {
            "N_GRID": N_GRID,
            "N_STEPS": N_STEPS,
            "N_REPEATS": N_REPEATS,
            "N_NULLS": N_NULLS,
            "RANDOM_SEED": RANDOM_SEED,
            "HEAVY_AUDIT": HEAVY_AUDIT,
            "thresholds": {
                "MIN_FINAL_R2": MIN_FINAL_R2,
                "MIN_TWO_SECTOR_SCORE": MIN_TWO_SECTOR_SCORE,
                "MIN_NULL_Z": MIN_NULL_Z,
                "MAX_BAD_SPLIT_PROXIMITY": MAX_BAD_SPLIT_PROXIMITY,
                "MAX_MASS_DRIFT": MAX_MASS_DRIFT,
            },
        },
        "summary_records": summary.to_dict(orient="records"),
    }
    with open(outdir / f"{OUTPUT_PREFIX}_audit_summary.json", "w", encoding="utf-8") as f:
        json.dump(audit, f, indent=2, default=str)

    write_notes(outdir, verdict, meta, canonical, summary)

    print("=" * 72)
    print("VERDICT:", verdict)
    print("[INFO] Outputs written to:", outdir)
    print("[INFO] Summary:", outdir / f"{OUTPUT_PREFIX}_summary.csv")
    print("[INFO] Notes:", outdir / f"{OUTPUT_PREFIX}_notes.txt")
    print("[INFO] Finished:", now())
    print("=" * 72)


if __name__ == "__main__":
    main()
