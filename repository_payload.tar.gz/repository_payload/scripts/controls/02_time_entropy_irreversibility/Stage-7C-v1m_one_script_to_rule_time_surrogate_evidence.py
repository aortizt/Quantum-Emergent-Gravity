#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
===============================================================================
Quantum-Emergent Gravity
Stage-7C-v1m
One Script to Rule Time-Surrogate Evidence
Contemporary Regeneration + Retrospective Provenance Audit
===============================================================================
Author: Arturo Ortiz-Tapia / QEG pipeline support
Build date: 2026-06-02

Purpose
-------
This script is the Stage-7C-v1m synthesis stage requested after v1l.
It deliberately combines BOTH necessary routes:

1) Contemporary regeneration / recomputation route
   - Do NOT blindly rerun old upstream scripts under their old purpose.
   - Treat upstream scripts and old outputs as source material.
   - Recover or reconstruct forward/reverse numeric vectors under a NEW
     Stage-7C identity.
   - Recompute low-k metrics and null tests into a NEW Stage-7C output folder.

2) Retrospective evidence audit route
   - Inspect prior JSON summaries and CSV evidence tables.
   - Record exactly which stages/scripts produced entropy, time-surrogate,
     operator-directionality, forward/reverse, inverse/adjoint, low-k,
     partial-reversibility, and related evidence.
   - Preserve earlier positive entropy evidence as an independent channel.
   - Make the provenance transparent enough for a Physica D methods/results
     narrative.

This is NOT a physical-time derivation.  It is an evidence-synthesis and
provenance-hardening script.

Forbidden use of external physics constants
-------------------------------------------
No PDG / Planck / LambdaCDM / Friedmann / GR / cosmological constants may be
used to select, orient, fit, score, or upgrade low-k witnesses.  External
physics may only be logged as frozen comparison bookkeeping after internal QEG
quantities are generated and locked.

Run from Spyder
---------------
Open this file in Spyder and run it.  If needed, set PROJECT_ROOT manually below.
The default path is the Dakini QEG root.

Primary outputs
---------------
metric_stage_7C_outputs/one_script_to_rule_time_surrogate_evidence_v1m/

    stage7C_v1m_file_inventory.csv
    stage7C_v1m_prior_json_summary_audit.csv
    stage7C_v1m_prior_csv_evidence_audit.csv
    stage7C_v1m_prior_time_surrogate_channel_ledger.csv
    stage7C_v1m_source_script_rework_plan.csv
    stage7C_v1m_candidate_vector_exports.csv
    stage7C_v1m_recomputed_lowk_metrics.csv
    stage7C_v1m_null_ablation.csv
    stage7C_v1m_source_family_ablation.csv
    stage7C_v1m_v1l_comparison_summary.csv
    stage7C_v1m_final_adjudication_table.csv
    stage7C_v1m_summary.json
    stage7C_v1m_ledger_note.txt
    stage7C_v1m_inspection_errors.txt

Interpretive status
-------------------
- Low-k remains review-only unless all semantic, null, source, family, and
  ablation conditions survive.
- Entropy remains an independent evidence channel.
- Operator directionality remains an independent evidence channel.
- Partial reversibility is a sandbox diagnostic, not an automatic downgrade.
===============================================================================
"""

from __future__ import annotations

import ast
import csv
import hashlib
import json
import math
import os
import re
import sys
import traceback
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

try:
    import pandas as pd
except Exception as exc:  # pragma: no cover - Spyder should have pandas, but fail clearly.
    raise RuntimeError("Stage-7C-v1m requires pandas. Install pandas or run inside the QEG Python environment.") from exc


# =============================================================================
# CONFIGURATION
# =============================================================================

PROJECT_ROOT = Path("/home/dakini/Downloads/010-Quantum_Emergent_Gravity")
STAGE_NAME = "Stage-7C-v1m"
RUN_LABEL = "one_script_to_rule_time_surrogate_evidence_v1m"
OUTPUT_RELATIVE = Path("metric_stage_7C_outputs") / RUN_LABEL

# If the default project root does not exist, the script will fall back to the
# nearest plausible root containing metric_stage_* folders, then to cwd.
AUTO_DETECT_PROJECT_ROOT = True

# Discovery limits.  These keep the script useful but safe on a large project tree.
MAX_CSV_ROWS_FOR_AUDIT = 250_000
MAX_VECTOR_CANDIDATES_TO_SCORE = 350
MAX_NULL_CANDIDATES = 175
MIN_VECTOR_LEN = 12
MAX_VECTOR_LEN_FOR_DIRECT_DCT = 4096
K_VALUES = [3, 5, 8, 12]
N_NULL = 300
RANDOM_SEED = 761702
SAVE_CANDIDATE_NPZ = True
MAX_NPZ_EXPORTS = 350

# We do not patch or rerun old scripts in this v1m script.  Instead, we produce a
# rework plan for contemporary derivative scripts.
CREATE_DERIVATIVE_SCRIPT_STUBS = False

# File extensions to inspect.
DISCOVERY_EXTENSIONS = {".csv", ".json", ".txt", ".md", ".py"}
OUTPUT_SCAN_EXTENSIONS = {".csv", ".json"}
SCRIPT_EXTENSIONS = {".py"}

# External constants are only flagged for guardrail auditing, never used for scoring.
FORBIDDEN_EXTERNAL_TERMS = [
    "PDG", "Planck", "LambdaCDM", "ΛCDM", "Friedmann", "Einstein",
    "Omega_m", "Omega_Lambda", "Omega_K", "cosmological constant", "H0",
    "GR", "general relativity", "LCDM", "CMB", "BAO",
]

CHANNEL_KEYWORDS = {
    "entropy_state_space_arrow": [
        "entropy", "entropic", "kl", "kullback", "state_space", "state-space",
        "arrow", "monotone", "irreversibility", "irreversible",
    ],
    "operator_directionality": [
        "operator", "directionality", "kappa", "rho", "forward_reverse",
        "forward/reverse", "ordering", "semigroup", "group-like", "group_like",
        "inverse", "adjoint", "reconstruction", "nonlocal",
    ],
    "low_k_spectral_vector": [
        "lowk", "low-k", "low_k", "spectral", "fft", "dct", "rfft",
        "retention", "coefficient", "mode", "low mode",
    ],
    "forward_reverse_recursion": [
        "forward", "reverse", "recursion", "recursive", "trajectory",
        "branch-a", "brancha", "iteration", "time_surrogate", "time-surrogate",
    ],
    "partial_reversibility_sandbox": [
        "partial reversibility", "reversibility", "reversible", "reversal",
        "inverse", "adjoint", "group-like", "group_like", "sandbox",
    ],
    "family_lineage": [
        "bari", "nufit", "valencia", "family", "fit_id", "fit", "lineage",
        "stage-4a", "stage4a", "stage-5a", "stage5a",
    ],
    "external_comparison_bookkeeping": [
        "omega", "friedmann", "lambda", "lcdm", "planck", "pdg", "hubble",
        "cosmology", "cosmological", "curvature", "dark energy", "matter",
    ],
}

STATUS_COLUMNS = [
    "status", "verdict", "decision", "final_decision", "claim_status",
    "interpretation", "rationale", "stage", "lowk_channel_status",
    "entropy_channel_status", "operator_directionality_channel_status",
]

METRIC_NAME_HINTS = [
    "r2", "R2", "corr", "correlation", "rmse", "p", "p_value", "p_upper",
    "z", "score", "gap", "distance", "retention", "survival", "stability",
    "entropy", "irrevers", "arrow", "lowk", "low_k", "forward", "reverse",
]

# These are meta/audit tables.  They may contain boolean or bookkeeping columns
# named forward/reverse, but they are not trajectory vectors and must not become
# low-k witnesses.
META_TABLE_NAME_PATTERNS = [
    "script_inventory",
    "variable_map",
    "patch_plan",
    "export_hook_patch_plan",
    "final_adjudication",
    "ledger_note",
    "inspection_errors",
    "summary",
    "file_inventory",
    "source_script_rework_plan",
]

ROBUST_NULL_FAMILIES_FOR_PROMOTION = {"permutation", "circular_shift"}


# =============================================================================
# DATA CLASSES
# =============================================================================

@dataclass
class VectorCandidate:
    candidate_id: str
    family: str
    source_file: str
    source_kind: str
    channel_tags: str
    forward_vector_name: str
    reverse_vector_name: str
    vector_length: int
    semantic_tier: str
    admissibility: str
    generation_notes: str
    exported_npz: str = ""


# =============================================================================
# BASIC UTILITIES
# =============================================================================

def now_timestamp() -> str:
    from datetime import datetime
    return datetime.now().isoformat(timespec="seconds")


def safe_rel(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve()))
    except Exception:
        return str(path)


def sha16(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8", errors="ignore")).hexdigest()[:16]


def file_sha16(path: Path) -> str:
    try:
        h = hashlib.sha256()
        with path.open("rb") as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b""):
                h.update(chunk)
        return h.hexdigest()[:16]
    except Exception:
        return "UNREADABLE"


def read_text_limited(path: Path, max_chars: int = 500_000) -> str:
    try:
        txt = path.read_text(encoding="utf-8", errors="ignore")
        return txt[:max_chars]
    except Exception:
        try:
            txt = path.read_text(errors="ignore")
            return txt[:max_chars]
        except Exception:
            return ""


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def detect_project_root() -> Path:
    root = PROJECT_ROOT
    if root.exists():
        return root.resolve()
    cwd = Path.cwd().resolve()
    if not AUTO_DETECT_PROJECT_ROOT:
        return cwd
    # Walk upward looking for project-ish folders.
    for candidate in [cwd] + list(cwd.parents):
        try:
            if any(p.name.startswith("metric_stage_") for p in candidate.iterdir() if p.is_dir()):
                return candidate.resolve()
        except Exception:
            pass
    # Search /home/dakini/Downloads shallowly if available.
    downloads = Path("/home/dakini/Downloads")
    if downloads.exists():
        for p in downloads.glob("*Quantum*Emergent*Gravity*"):
            if p.is_dir():
                return p.resolve()
    return cwd


def stage_from_path(path: Path) -> str:
    s = str(path).replace("\\", "/")
    patterns = [
        r"stage[-_ ]?(\d+[A-Za-z]+)",
        r"Stage[-_ ]?(\d+[A-Za-z]+)",
        r"metric_stage_(\d+[A-Za-z]+)",
        r"stage(\d+[A-Za-z]+)",
    ]
    for pat in patterns:
        m = re.search(pat, s, flags=re.IGNORECASE)
        if m:
            return "Stage-" + m.group(1).upper()
    return "UNKNOWN"


def keyword_hits(text: str, keywords: Sequence[str]) -> List[str]:
    low = text.lower()
    hits = []
    for k in keywords:
        if k.lower() in low:
            hits.append(k)
    return hits


def channel_tags_for_text(text: str) -> List[str]:
    tags = []
    low = text.lower()
    for channel, keys in CHANNEL_KEYWORDS.items():
        if any(k.lower() in low for k in keys):
            tags.append(channel)
    return tags


def classify_family(text: str) -> str:
    low = text.lower()
    fams = []
    for fam in ["BARI", "NUFIT", "VALENCIA", "POOLED"]:
        if fam.lower() in low:
            fams.append(fam)
    return "+".join(fams) if fams else "UNKNOWN"


def flatten_json(obj: Any, prefix: str = "") -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    if isinstance(obj, dict):
        for k, v in obj.items():
            key = f"{prefix}.{k}" if prefix else str(k)
            out.update(flatten_json(v, key))
    elif isinstance(obj, list):
        # Avoid exploding huge arrays: summarize lists, but flatten short lists of simple values.
        if len(obj) <= 12 and all(not isinstance(x, (dict, list)) for x in obj):
            out[prefix] = obj
        else:
            out[prefix + ".__len__"] = len(obj)
            for i, v in enumerate(obj[:5]):
                if isinstance(v, (dict, list)):
                    out.update(flatten_json(v, f"{prefix}[{i}]"))
                else:
                    out[f"{prefix}[{i}]"] = v
    else:
        out[prefix] = obj
    return out


def is_scalar_like(x: Any) -> bool:
    return isinstance(x, (str, int, float, bool, type(None), np.integer, np.floating, np.bool_))


def value_to_str(x: Any, max_len: int = 500) -> str:
    if isinstance(x, (list, tuple)):
        s = ";".join(map(str, x[:20]))
    elif isinstance(x, dict):
        s = json.dumps(x, ensure_ascii=False)[:max_len]
    else:
        s = str(x)
    return s[:max_len]


def try_float(x: Any) -> Optional[float]:
    try:
        if isinstance(x, bool):
            return float(x)
        if x is None:
            return None
        if isinstance(x, (int, float, np.integer, np.floating)):
            y = float(x)
            return y if math.isfinite(y) else None
        s = str(x).strip()
        if not s or len(s) > 80:
            return None
        # avoid converting verdict-like strings
        if re.search(r"[A-Za-z_]", s) and not re.fullmatch(r"[-+0-9.eE]+", s):
            return None
        y = float(s)
        return y if math.isfinite(y) else None
    except Exception:
        return None


def clean_vector(values: Sequence[Any]) -> np.ndarray:
    arr = pd.to_numeric(pd.Series(values), errors="coerce").to_numpy(dtype=float)
    arr = arr[np.isfinite(arr)]
    return arr


def is_vector_like_series(series: pd.Series) -> bool:
    """Reject boolean/meta columns and near-constant bookkeeping columns."""
    # Boolean flags such as explicit_forward_loop vs explicit_reverse_loop are
    # not trajectories.  This guard prevents audit metadata from becoming fake
    # low-k evidence.
    if pd.api.types.is_bool_dtype(series):
        return False
    vals = pd.to_numeric(series, errors="coerce").dropna()
    if len(vals) < MIN_VECTOR_LEN:
        return False
    unique_vals = vals.nunique(dropna=True)
    if unique_vals < 6:
        return False
    if float(vals.std()) < 1e-15:
        return False
    return True


def is_meta_table_path(path: Path) -> bool:
    name = path.name.lower()
    return any(pat in name for pat in META_TABLE_NAME_PATTERNS)


def zscore_l2(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    if x.size == 0:
        return x
    x = x[np.isfinite(x)]
    if x.size == 0:
        return x
    x = x - float(np.nanmean(x))
    sd = float(np.nanstd(x))
    if sd > 1e-15:
        x = x / sd
    norm = float(np.linalg.norm(x))
    if norm > 1e-15:
        x = x / norm
    return x


def pearson_corr(a: np.ndarray, b: np.ndarray) -> float:
    n = min(len(a), len(b))
    if n < 3:
        return float("nan")
    a = np.asarray(a[:n], dtype=float)
    b = np.asarray(b[:n], dtype=float)
    mask = np.isfinite(a) & np.isfinite(b)
    a = a[mask]
    b = b[mask]
    if len(a) < 3 or np.std(a) < 1e-15 or np.std(b) < 1e-15:
        return float("nan")
    return float(np.corrcoef(a, b)[0, 1])


def r2_score(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    n = min(len(y_true), len(y_pred))
    if n < 3:
        return float("nan")
    y = np.asarray(y_true[:n], dtype=float)
    p = np.asarray(y_pred[:n], dtype=float)
    mask = np.isfinite(y) & np.isfinite(p)
    y = y[mask]
    p = p[mask]
    if len(y) < 3:
        return float("nan")
    ss_res = float(np.sum((y - p) ** 2))
    ss_tot = float(np.sum((y - np.mean(y)) ** 2))
    if ss_tot < 1e-15:
        return float("nan")
    return 1.0 - ss_res / ss_tot


# =============================================================================
# DISCOVERY AND AUDIT
# =============================================================================

def discover_files(root: Path) -> List[Path]:
    files: List[Path] = []
    skip_parts = {
        ".git", "__pycache__", ".ipynb_checkpoints", "venv", ".venv",
        "node_modules",
    }
    for dirpath, dirnames, filenames in os.walk(root):
        # prune hidden/heavy folders
        dirnames[:] = [d for d in dirnames if d not in skip_parts and not d.startswith(".")]
        for fn in filenames:
            p = Path(dirpath) / fn
            if p.suffix.lower() in DISCOVERY_EXTENSIONS:
                files.append(p)
    return sorted(files)


def file_inventory(files: List[Path], root: Path) -> pd.DataFrame:
    rows = []
    for p in files:
        rel = safe_rel(p, root)
        text_basis = f"{rel} {p.name}"
        if p.suffix.lower() in {".txt", ".md", ".py", ".json"}:
            text_basis += " " + read_text_limited(p, max_chars=50_000)
        tags = channel_tags_for_text(text_basis)
        forbidden_hits = keyword_hits(text_basis, FORBIDDEN_EXTERNAL_TERMS)
        rows.append({
            "path": str(p),
            "relative_path": rel,
            "stage": stage_from_path(p),
            "extension": p.suffix.lower(),
            "size_bytes": p.stat().st_size if p.exists() else None,
            "sha16": file_sha16(p) if p.suffix.lower() in {".csv", ".json", ".py", ".txt", ".md"} else "",
            "family_hint": classify_family(text_basis),
            "channel_tags": ";".join(tags),
            "forbidden_external_constant_hits": ";".join(forbidden_hits),
            "is_output_table": p.suffix.lower() in OUTPUT_SCAN_EXTENSIONS,
            "is_script": p.suffix.lower() in SCRIPT_EXTENSIONS,
        })
    return pd.DataFrame(rows)


def audit_json_files(json_files: List[Path], root: Path, errors: List[str]) -> pd.DataFrame:
    rows = []
    for p in json_files:
        try:
            obj = json.loads(read_text_limited(p, max_chars=5_000_000))
            flat = flatten_json(obj)
            rel = safe_rel(p, root)
            base_tags = channel_tags_for_text(rel + " " + json.dumps(flat, ensure_ascii=False)[:50_000])
            for k, v in flat.items():
                keylow = k.lower()
                vstr = value_to_str(v)
                combined = f"{rel} {k} {vstr}"
                tags = sorted(set(base_tags + channel_tags_for_text(combined)))
                include = False
                if any(h.lower() in keylow for h in METRIC_NAME_HINTS):
                    include = True
                if any(col in keylow for col in ["status", "verdict", "decision", "stage", "claim", "summary"]):
                    include = True
                if channel_tags_for_text(combined):
                    include = True
                if not include:
                    continue
                rows.append({
                    "source_file": str(p),
                    "relative_path": rel,
                    "stage": stage_from_path(p),
                    "family_hint": classify_family(combined),
                    "channel_tags": ";".join(tags),
                    "json_key": k,
                    "value": vstr,
                    "numeric_value": try_float(v),
                    "evidence_kind": "json_summary_key",
                })
        except Exception as exc:
            errors.append(f"JSON audit failed for {p}: {repr(exc)}")
    return pd.DataFrame(rows)


def audit_csv_file(path: Path, root: Path, errors: List[str]) -> Tuple[Dict[str, Any], pd.DataFrame]:
    summary: Dict[str, Any] = {}
    evidence_rows: List[Dict[str, Any]] = []
    rel = safe_rel(path, root)
    try:
        # Count rows quickly and read with pandas.  Reading all rows is helpful for evidence tables,
        # but cap huge files.
        try:
            row_count = sum(1 for _ in path.open("r", encoding="utf-8", errors="ignore")) - 1
        except Exception:
            row_count = None
        nrows = None
        if row_count is not None and row_count > MAX_CSV_ROWS_FOR_AUDIT:
            nrows = MAX_CSV_ROWS_FOR_AUDIT
        df = pd.read_csv(path, nrows=nrows, low_memory=False)
        cols = list(df.columns)
        col_text = " ".join(map(str, cols))
        text_basis = f"{rel} {path.name} {col_text}"
        tags = channel_tags_for_text(text_basis)
        forbidden_hits = keyword_hits(text_basis, FORBIDDEN_EXTERNAL_TERMS)
        numeric_cols = [c for c in cols if pd.api.types.is_numeric_dtype(df[c])]
        object_cols = [c for c in cols if c not in numeric_cols]
        status_like_cols = [c for c in cols if any(s in c.lower() for s in STATUS_COLUMNS)]
        fr_cols = [c for c in cols if re.search(r"forward|reverse|fwd|rev", c, flags=re.I)]

        summary = {
            "source_file": str(path),
            "relative_path": rel,
            "stage": stage_from_path(path),
            "family_hint": classify_family(text_basis),
            "channel_tags": ";".join(tags),
            "row_count_actual_or_estimated": row_count,
            "rows_read": len(df),
            "column_count": len(cols),
            "numeric_column_count": len(numeric_cols),
            "status_like_column_count": len(status_like_cols),
            "forward_reverse_column_count": len(fr_cols),
            "columns": ";".join(map(str, cols[:200])),
            "status_like_columns": ";".join(map(str, status_like_cols)),
            "forward_reverse_columns": ";".join(map(str, fr_cols)),
            "forbidden_external_constant_hits": ";".join(forbidden_hits),
            "read_note": "TRUNCATED" if nrows is not None else "FULL",
        }

        # Extract status/verdict/decision values and important numeric summaries.
        for c in status_like_cols[:25]:
            vals = df[c].dropna().astype(str).value_counts().head(12)
            for value, count in vals.items():
                combined = f"{rel} {c} {value}"
                evidence_rows.append({
                    "source_file": str(path),
                    "relative_path": rel,
                    "stage": stage_from_path(path),
                    "family_hint": classify_family(combined),
                    "channel_tags": ";".join(sorted(set(tags + channel_tags_for_text(combined)))),
                    "evidence_kind": "csv_status_value",
                    "field": c,
                    "value": str(value)[:500],
                    "numeric_value": try_float(value),
                    "row_count": int(count),
                })

        important_numeric_cols = []
        for c in numeric_cols:
            clow = str(c).lower()
            if any(h.lower() in clow for h in METRIC_NAME_HINTS):
                important_numeric_cols.append(c)
        for c in important_numeric_cols[:60]:
            s = pd.to_numeric(df[c], errors="coerce").dropna()
            if len(s) == 0:
                continue
            combined = f"{rel} {c}"
            evidence_rows.append({
                "source_file": str(path),
                "relative_path": rel,
                "stage": stage_from_path(path),
                "family_hint": classify_family(combined),
                "channel_tags": ";".join(sorted(set(tags + channel_tags_for_text(combined)))),
                "evidence_kind": "csv_numeric_summary",
                "field": c,
                "value": f"mean={s.mean():.8g}; median={s.median():.8g}; min={s.min():.8g}; max={s.max():.8g}; n={len(s)}",
                "numeric_value": float(s.mean()),
                "row_count": int(len(s)),
            })

    except Exception as exc:
        errors.append(f"CSV audit failed for {path}: {repr(exc)}")
        summary = {
            "source_file": str(path),
            "relative_path": rel,
            "stage": stage_from_path(path),
            "family_hint": classify_family(rel),
            "channel_tags": ";".join(channel_tags_for_text(rel)),
            "row_count_actual_or_estimated": None,
            "rows_read": 0,
            "column_count": 0,
            "numeric_column_count": 0,
            "status_like_column_count": 0,
            "forward_reverse_column_count": 0,
            "columns": "",
            "status_like_columns": "",
            "forward_reverse_columns": "",
            "forbidden_external_constant_hits": "",
            "read_note": f"ERROR: {repr(exc)}",
        }
    return summary, pd.DataFrame(evidence_rows)


def audit_csv_files(csv_files: List[Path], root: Path, errors: List[str]) -> Tuple[pd.DataFrame, pd.DataFrame]:
    summaries = []
    evidence_frames = []
    for p in csv_files:
        summary, evidence = audit_csv_file(p, root, errors)
        summaries.append(summary)
        if not evidence.empty:
            evidence_frames.append(evidence)
    summary_df = pd.DataFrame(summaries)
    evidence_df = pd.concat(evidence_frames, ignore_index=True) if evidence_frames else pd.DataFrame()
    return summary_df, evidence_df


# =============================================================================
# SCRIPT REWORK PLAN
# =============================================================================

def inspect_python_script(path: Path, root: Path, errors: List[str]) -> Dict[str, Any]:
    rel = safe_rel(path, root)
    txt = read_text_limited(path, max_chars=2_000_000)
    lower = txt.lower()
    try:
        tree = ast.parse(txt)
        functions = [n.name for n in ast.walk(tree) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
        assigns = [n for n in ast.walk(tree) if isinstance(n, (ast.Assign, ast.AnnAssign, ast.AugAssign))]
        parse_status = "OK"
    except Exception as exc:
        functions = []
        assigns = []
        parse_status = f"PARSE_ERROR: {repr(exc)}"

    flags = {
        "has_forward_terms": bool(re.search(r"forward|fwd", lower)),
        "has_reverse_terms": bool(re.search(r"reverse|rev", lower)),
        "has_entropy_terms": "entropy" in lower or "entropic" in lower,
        "has_recursion_terms": "recursion" in lower or "recursive" in lower or "iteration" in lower,
        "has_operator_terms": "operator" in lower or "adjoint" in lower or "inverse" in lower,
        "has_lowk_terms": "lowk" in lower or "low-k" in lower or "fft" in lower or "dct" in lower,
        "has_null_terms": "null" in lower or "shuffle" in lower or "permutation" in lower,
        "writes_outputs": bool(re.search(r"to_csv|json.dump|savefig|np\.save|np\.savez|open\(", lower)),
    }
    score = 0.0
    score += 2.0 if flags["has_forward_terms"] and flags["has_reverse_terms"] else 0.0
    score += 1.2 if flags["has_entropy_terms"] else 0.0
    score += 1.0 if flags["has_recursion_terms"] else 0.0
    score += 1.0 if flags["has_operator_terms"] else 0.0
    score += 0.7 if flags["has_lowk_terms"] else 0.0
    score += 0.7 if flags["has_null_terms"] else 0.0
    score += 0.4 if flags["writes_outputs"] else 0.0

    tags = channel_tags_for_text(rel + " " + txt[:100_000])
    forbidden_hits = keyword_hits(rel + " " + txt[:100_000], FORBIDDEN_EXTERNAL_TERMS)

    if score >= 4.5:
        priority = "TIER_1_CONTEMPORARY_REWORK_CANDIDATE"
        recommended_action = "Fork relevant logic into a new Stage-7C derivative script; export raw trajectories before scalar reduction."
    elif score >= 2.5:
        priority = "TIER_2_REVIEW_REWORK_CANDIDATE"
        recommended_action = "Inspect for reusable forward/reverse or entropy/operator code paths; do not rerun historical script directly."
    elif score >= 1.0:
        priority = "TIER_3_CONTEXT_ONLY"
        recommended_action = "Use as provenance/context only unless a specific variable map is needed."
    else:
        priority = "LOW_PRIORITY"
        recommended_action = "No immediate rework."

    return {
        "script_path": str(path),
        "relative_path": rel,
        "stage": stage_from_path(path),
        "sha16": file_sha16(path),
        "parse_status": parse_status,
        "function_count": len(functions),
        "assignment_count": len(assigns),
        "function_names_preview": ";".join(functions[:35]),
        "channel_tags": ";".join(tags),
        "has_forward_terms": flags["has_forward_terms"],
        "has_reverse_terms": flags["has_reverse_terms"],
        "has_entropy_terms": flags["has_entropy_terms"],
        "has_recursion_terms": flags["has_recursion_terms"],
        "has_operator_terms": flags["has_operator_terms"],
        "has_lowk_terms": flags["has_lowk_terms"],
        "has_null_terms": flags["has_null_terms"],
        "writes_outputs": flags["writes_outputs"],
        "forbidden_external_constant_hits": ";".join(forbidden_hits),
        "rework_priority_score": score,
        "priority_tier": priority,
        "recommended_action": recommended_action,
        "contemporary_output_rule": "Write only to metric_stage_7C_outputs/one_script_to_rule_time_surrogate_evidence_v1m or later Stage-7C derivative directories.",
    }


def source_script_rework_plan(script_files: List[Path], root: Path, errors: List[str]) -> pd.DataFrame:
    rows = [inspect_python_script(p, root, errors) for p in script_files]
    df = pd.DataFrame(rows)
    if not df.empty:
        df = df.sort_values(["rework_priority_score", "relative_path"], ascending=[False, True]).reset_index(drop=True)
    return df


# =============================================================================
# VECTOR CANDIDATE EXTRACTION
# =============================================================================

def find_forward_reverse_column_pairs(columns: Sequence[str]) -> List[Tuple[str, str, str]]:
    cols = list(columns)
    colset = {c: c for c in cols}
    lower_to_col = {c.lower(): c for c in cols}
    pairs: List[Tuple[str, str, str]] = []

    replacements = [
        ("forward", "reverse"),
        ("fwd", "rev"),
        ("forwards", "reverse"),
        ("for", "rev"),
    ]
    for c in cols:
        cl = c.lower()
        for a, b in replacements:
            if a in cl:
                target = re.sub(a, b, cl, flags=re.IGNORECASE)
                if target in lower_to_col:
                    pairs.append((c, lower_to_col[target], f"name_replace_{a}_to_{b}"))
        # patterns such as x_forward and x_reverse are covered above, but also common pairs:
        if cl.endswith("_f"):
            target = cl[:-2] + "_r"
            if target in lower_to_col:
                pairs.append((c, lower_to_col[target], "suffix_f_to_r"))
    # remove dupes preserving order
    seen = set()
    out = []
    for f, r, rule in pairs:
        key = (f, r)
        if f == r or key in seen:
            continue
        seen.add(key)
        out.append((f, r, rule))
    return out


def semantic_tier_for_pair(path: Path, forward_col: str, reverse_col: str, channel_tags: List[str]) -> Tuple[str, str]:
    text = f"{safe_rel(path, path.parent)} {path.name} {forward_col} {reverse_col}".lower()
    if any(k in text for k in ["p_value", "p_upper", "null", "verdict", "status", "possible", "candidate_tier"]):
        return "DERIVED_SUMMARY_REVIEW", "REVIEW_DERIVED_SCORE_COLUMNS"
    if any(k in text for k in ["lowk", "low_k", "retention", "coefficient", "fft", "dct"]):
        return "LOWK_DERIVED_REVIEW", "REVIEW_LOWK_SUMMARY_COLUMNS"
    if any(k in text for k in ["trajectory", "trace", "state", "series", "history", "evolution", "entropy"]):
        return "PRIMARY_CANDIDATE_REVIEW", "PRIMARY_CANDIDATE_REVIEW"
    if "forward_reverse_recursion" in channel_tags or "entropy_state_space_arrow" in channel_tags:
        return "PRIMARY_CANDIDATE_REVIEW", "PRIMARY_CANDIDATE_REVIEW"
    return "REVIEW_CANDIDATE", "REVIEW_SEMANTICS_UNKNOWN"


def extract_csv_vector_candidates(csv_files: List[Path], root: Path, out_dir: Path, errors: List[str]) -> Tuple[pd.DataFrame, Dict[str, Tuple[np.ndarray, np.ndarray]]]:
    rows: List[Dict[str, Any]] = []
    vectors: Dict[str, Tuple[np.ndarray, np.ndarray]] = {}
    npz_dir = out_dir / "contemporary_regenerated_vectors"
    ensure_dir(npz_dir)
    export_count = 0

    for p in csv_files:
        try:
            # Meta/audit tables are important for provenance, but they are not
            # numerical trajectory sources.  They remain in the retrospective
            # ledger, not in low-k candidate extraction.
            if is_meta_table_path(p):
                continue
            # Read full file unless huge; for vector columns, truncation is acceptable but recorded.
            row_count = None
            try:
                row_count = sum(1 for _ in p.open("r", encoding="utf-8", errors="ignore")) - 1
            except Exception:
                pass
            nrows = None
            if row_count is not None and row_count > MAX_CSV_ROWS_FOR_AUDIT:
                nrows = MAX_CSV_ROWS_FOR_AUDIT
            df = pd.read_csv(p, nrows=nrows, low_memory=False)
            pairs = find_forward_reverse_column_pairs(df.columns)
            if not pairs:
                continue
            rel = safe_rel(p, root)
            text_basis = f"{rel} {' '.join(map(str, df.columns))}"
            tags = channel_tags_for_text(text_basis)
            family = classify_family(text_basis)
            for fcol, rcol, rule in pairs:
                if not is_vector_like_series(df[fcol]) or not is_vector_like_series(df[rcol]):
                    continue
                f = clean_vector(df[fcol])
                r = clean_vector(df[rcol])
                n = min(len(f), len(r))
                if n < MIN_VECTOR_LEN:
                    continue
                f = f[:n]
                r = r[:n]
                cid = f"stage7C_v1m_{Path(p).stem}_{fcol}_VS_{rcol}_{sha16(rel + fcol + rcol)}"
                semantic_tier, admissibility = semantic_tier_for_pair(p, fcol, rcol, tags)
                notes = f"extracted contemporaneously from CSV columns using {rule}; rows_read={len(df)}"
                exported_npz = ""
                if SAVE_CANDIDATE_NPZ and export_count < MAX_NPZ_EXPORTS:
                    npz_path = npz_dir / f"{cid}.npz"
                    try:
                        np.savez_compressed(
                            npz_path,
                            forward_vector=f,
                            reverse_vector=r,
                            source_file=str(p),
                            forward_vector_name=fcol,
                            reverse_vector_name=rcol,
                            generation_notes=notes,
                        )
                        exported_npz = str(npz_path)
                        export_count += 1
                    except Exception as exc:
                        errors.append(f"Could not save npz for {cid}: {repr(exc)}")
                vectors[cid] = (f, r)
                rows.append(asdict(VectorCandidate(
                    candidate_id=cid,
                    family=family,
                    source_file=str(p),
                    source_kind="csv_column_pair",
                    channel_tags=";".join(tags),
                    forward_vector_name=fcol,
                    reverse_vector_name=rcol,
                    vector_length=n,
                    semantic_tier=semantic_tier,
                    admissibility=admissibility,
                    generation_notes=notes,
                    exported_npz=exported_npz,
                )))
        except Exception as exc:
            errors.append(f"CSV vector extraction failed for {p}: {repr(exc)}")
    cand_df = pd.DataFrame(rows)
    if not cand_df.empty:
        # Put better candidates first.
        tier_order = {
            "PRIMARY_CANDIDATE_REVIEW": 0,
            "REVIEW_CANDIDATE": 1,
            "LOWK_DERIVED_REVIEW": 2,
            "DERIVED_SUMMARY_REVIEW": 3,
        }
        cand_df["tier_order"] = cand_df["semantic_tier"].map(tier_order).fillna(9)
        cand_df = cand_df.sort_values(["tier_order", "vector_length"], ascending=[True, False]).drop(columns=["tier_order"]).reset_index(drop=True)
    return cand_df, vectors


def load_npz_vector_pair(npz_path: Path) -> Optional[Tuple[np.ndarray, np.ndarray]]:
    try:
        data = np.load(npz_path, allow_pickle=True)
        keys = list(data.keys())
        fkey = None
        rkey = None
        for k in keys:
            lk = k.lower()
            if fkey is None and ("forward" in lk or lk in {"f", "fwd"}):
                fkey = k
            if rkey is None and ("reverse" in lk or lk in {"r", "rev"}):
                rkey = k
        if fkey and rkey:
            f = np.asarray(data[fkey], dtype=float).ravel()
            r = np.asarray(data[rkey], dtype=float).ravel()
            return f[np.isfinite(f)], r[np.isfinite(r)]
        # fallback: first two numeric arrays of same-ish shape
        numeric = []
        for k in keys:
            try:
                arr = np.asarray(data[k], dtype=float).ravel()
                if arr.size >= MIN_VECTOR_LEN and np.isfinite(arr).sum() >= MIN_VECTOR_LEN:
                    numeric.append((k, arr[np.isfinite(arr)]))
            except Exception:
                pass
        if len(numeric) >= 2:
            return numeric[0][1], numeric[1][1]
    except Exception:
        return None
    return None


def extract_v1l_npz_candidates(root: Path, out_dir: Path, errors: List[str]) -> Tuple[pd.DataFrame, Dict[str, Tuple[np.ndarray, np.ndarray]]]:
    rows: List[Dict[str, Any]] = []
    vectors: Dict[str, Tuple[np.ndarray, np.ndarray]] = {}
    # Search canonical v1l export table locations.
    candidates = list(root.glob("**/stage7C_v1l_regenerated_primary_vector_exports.csv"))
    # Include current folder if script is run near uploaded files.
    local = Path.cwd() / "stage7C_v1l_regenerated_primary_vector_exports.csv"
    if local.exists() and local not in candidates:
        candidates.append(local)
    for table in candidates:
        try:
            df = pd.read_csv(table)
            if "exported_npz" not in df.columns:
                continue
            for _, row in df.iterrows():
                npz_s = str(row.get("exported_npz", ""))
                if not npz_s or npz_s.lower() == "nan":
                    continue
                npz_path = Path(npz_s)
                if not npz_path.exists():
                    # Try resolving relative to project root or v1l output table dir.
                    alt1 = root / npz_s
                    alt2 = table.parent / Path(npz_s).name
                    alt3 = table.parent / "regenerated_primary_vectors" / Path(npz_s).name
                    for alt in [alt1, alt2, alt3]:
                        if alt.exists():
                            npz_path = alt
                            break
                pair = load_npz_vector_pair(npz_path)
                if pair is None:
                    continue
                f, r = pair
                n = min(len(f), len(r))
                if n < MIN_VECTOR_LEN:
                    continue
                f = f[:n]
                r = r[:n]
                cid0 = str(row.get("candidate_id", Path(npz_path).stem))
                cid = f"stage7C_v1m_from_v1l_npz_{cid0}_{sha16(str(npz_path))}"
                family = str(row.get("family", "UNKNOWN"))
                source_file = str(row.get("source_file", npz_path))
                semantic_tier = str(row.get("semantic_tier", "V1L_IMPORTED_REVIEW"))
                admissibility = str(row.get("primary_admissibility", "V1L_IMPORTED_REVIEW"))
                vectors[cid] = (f, r)
                rows.append(asdict(VectorCandidate(
                    candidate_id=cid,
                    family=family if family and family != "nan" else classify_family(source_file),
                    source_file=source_file,
                    source_kind="v1l_npz_import_contemporary_recompute",
                    channel_tags="low_k_spectral_vector;forward_reverse_recursion",
                    forward_vector_name=str(row.get("forward_vector_name", "forward_vector")),
                    reverse_vector_name=str(row.get("reverse_vector_name", "reverse_vector")),
                    vector_length=n,
                    semantic_tier=semantic_tier,
                    admissibility=admissibility,
                    generation_notes="Imported v1l vector npz only for contemporary v1m recomputation; v1l itself remains historical evidence.",
                    exported_npz=str(npz_path),
                )))
        except Exception as exc:
            errors.append(f"v1l npz extraction failed for {table}: {repr(exc)}")
    return pd.DataFrame(rows), vectors


# =============================================================================
# LOW-K METRICS AND NULL TESTS
# =============================================================================

def fft_lowk_coefficients(x: np.ndarray, k: int, complex_fft: bool = True) -> np.ndarray:
    x = zscore_l2(x)
    if x.size < MIN_VECTOR_LEN:
        return np.array([], dtype=complex)
    coeff = np.fft.rfft(x)
    kk = min(k, len(coeff))
    return coeff[:kk] if complex_fft else coeff[:kk].real.astype(float)


def dct2_coefficients(x: np.ndarray, k: int) -> np.ndarray:
    x = zscore_l2(x)
    n = x.size
    if n < MIN_VECTOR_LEN:
        return np.array([], dtype=float)
    kk = min(k, n)
    if n <= MAX_VECTOR_LEN_FOR_DIRECT_DCT:
        j = np.arange(n)
        coeffs = []
        for m in range(kk):
            coeffs.append(np.sum(x * np.cos(np.pi * (j + 0.5) * m / n)))
        return np.asarray(coeffs, dtype=float)
    # fallback for very long vectors: downsample before DCT-like transform
    idx = np.linspace(0, n - 1, MAX_VECTOR_LEN_FOR_DIRECT_DCT).astype(int)
    return dct2_coefficients(x[idx], k)


def energy_retention(coeff: np.ndarray) -> float:
    if coeff.size == 0:
        return float("nan")
    e = np.abs(coeff) ** 2
    total = float(np.sum(e))
    if total < 1e-15:
        return float("nan")
    # Include all retained low-k coeffs in numerator because coeff is already low-k.
    return float(np.sum(e) / total)


def normalized_coeff_distance(cf: np.ndarray, cr: np.ndarray) -> float:
    n = min(len(cf), len(cr))
    if n == 0:
        return float("nan")
    a = np.asarray(cf[:n])
    b = np.asarray(cr[:n])
    denom = float(np.linalg.norm(a) + np.linalg.norm(b))
    if denom < 1e-15:
        return 0.0
    return float(np.linalg.norm(a - b) / denom)


def lowk_metrics_for_candidate(candidate: Dict[str, Any], f: np.ndarray, r: np.ndarray) -> List[Dict[str, Any]]:
    rows = []
    n = min(len(f), len(r))
    f = f[:n]
    r = r[:n]
    corr = pearson_corr(f, r)
    near_identical = bool(np.allclose(zscore_l2(f), zscore_l2(r), rtol=1e-7, atol=1e-9)) if n >= MIN_VECTOR_LEN else False
    methods = [
        ("FFT_RFFT_COMPLEX", lambda x, k: fft_lowk_coefficients(x, k, complex_fft=True)),
        ("FFT_RFFT_REAL", lambda x, k: fft_lowk_coefficients(x, k, complex_fft=False)),
        ("DCT2_REAL", lambda x, k: dct2_coefficients(x, k)),
    ]
    for method, func in methods:
        for k in K_VALUES:
            cf = func(f, k)
            cr = func(r, k)
            fd = normalized_coeff_distance(cf, cr)
            # For retention, compare low-k energy to total energy from full transform of each method.
            # Here compute full enough transform separately to avoid the v1l ambiguity.
            if method.startswith("FFT"):
                fullf = np.fft.rfft(zscore_l2(f))
                fullr = np.fft.rfft(zscore_l2(r))
                e_f_total = float(np.sum(np.abs(fullf) ** 2))
                e_r_total = float(np.sum(np.abs(fullr) ** 2))
                e_f_low = float(np.sum(np.abs(cf) ** 2))
                e_r_low = float(np.sum(np.abs(cr) ** 2))
            else:
                fullf = dct2_coefficients(f, min(MAX_VECTOR_LEN_FOR_DIRECT_DCT, len(f)))
                fullr = dct2_coefficients(r, min(MAX_VECTOR_LEN_FOR_DIRECT_DCT, len(r)))
                e_f_total = float(np.sum(np.abs(fullf) ** 2))
                e_r_total = float(np.sum(np.abs(fullr) ** 2))
                e_f_low = float(np.sum(np.abs(cf) ** 2))
                e_r_low = float(np.sum(np.abs(cr) ** 2))
            f_ret = e_f_low / e_f_total if e_f_total > 1e-15 else float("nan")
            r_ret = e_r_low / e_r_total if e_r_total > 1e-15 else float("nan")
            signed_gap = f_ret - r_ret if math.isfinite(f_ret) and math.isfinite(r_ret) else float("nan")
            abs_gap = abs(signed_gap) if math.isfinite(signed_gap) else float("nan")
            nontrivial = bool(math.isfinite(fd) and fd > 0.05 and (not near_identical))
            rows.append({
                "candidate_id": candidate["candidate_id"],
                "family": candidate.get("family", "UNKNOWN"),
                "source_file": candidate.get("source_file", ""),
                "source_kind": candidate.get("source_kind", ""),
                "channel_tags": candidate.get("channel_tags", ""),
                "semantic_tier": candidate.get("semantic_tier", ""),
                "admissibility": candidate.get("admissibility", ""),
                "method": method,
                "k": k,
                "vector_length": n,
                "forward_lowk_retention": f_ret,
                "reverse_lowk_retention": r_ret,
                "signed_forward_minus_reverse_retention_gap": signed_gap,
                "abs_retention_gap": abs_gap,
                "normalized_lowk_coefficient_distance": fd,
                "forward_reverse_pearson_corr": corr,
                "near_identical_vectors": near_identical,
                "nontrivial_lowk_gap": nontrivial,
            })
    return rows


def recompute_lowk_metrics(cand_df: pd.DataFrame, vectors: Dict[str, Tuple[np.ndarray, np.ndarray]], errors: List[str]) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    if cand_df.empty:
        return pd.DataFrame()
    # Score only the first N candidates after sorting.
    for _, cand in cand_df.head(MAX_VECTOR_CANDIDATES_TO_SCORE).iterrows():
        cid = cand["candidate_id"]
        pair = vectors.get(cid)
        if pair is None:
            continue
        try:
            rows.extend(lowk_metrics_for_candidate(cand.to_dict(), pair[0], pair[1]))
        except Exception as exc:
            errors.append(f"Low-k recompute failed for {cid}: {repr(exc)}")
    return pd.DataFrame(rows)


def null_distance_for_pair(f: np.ndarray, r: np.ndarray, method: str, k: int) -> float:
    if method == "FFT_RFFT_COMPLEX":
        cf = fft_lowk_coefficients(f, k, complex_fft=True)
        cr = fft_lowk_coefficients(r, k, complex_fft=True)
    elif method == "FFT_RFFT_REAL":
        cf = fft_lowk_coefficients(f, k, complex_fft=False)
        cr = fft_lowk_coefficients(r, k, complex_fft=False)
    else:
        cf = dct2_coefficients(f, k)
        cr = dct2_coefficients(r, k)
    return normalized_coeff_distance(cf, cr)


def run_null_tests(lowk_df: pd.DataFrame, vectors: Dict[str, Tuple[np.ndarray, np.ndarray]], errors: List[str]) -> pd.DataFrame:
    if lowk_df.empty:
        return pd.DataFrame()
    rng = np.random.default_rng(RANDOM_SEED)
    rows = []
    # Candidate-method-k rows with nontrivial gaps first, limited.
    df = lowk_df.copy()
    df["score_for_null_priority"] = pd.to_numeric(df["normalized_lowk_coefficient_distance"], errors="coerce").fillna(0)
    df = df.sort_values(["nontrivial_lowk_gap", "score_for_null_priority"], ascending=[False, False]).head(MAX_NULL_CANDIDATES)
    for _, row in df.iterrows():
        cid = row["candidate_id"]
        pair = vectors.get(cid)
        if pair is None:
            continue
        try:
            f, r = pair
            n = min(len(f), len(r))
            f = f[:n]
            r = r[:n]
            method = str(row["method"])
            k = int(row["k"])
            obs = null_distance_for_pair(f, r, method, k)
            if not math.isfinite(obs):
                continue
            null_families = ["permutation", "circular_shift", "orientation_reverse", "sign_flip"]
            for nf in null_families:
                vals = []
                for _ in range(N_NULL):
                    if nf == "permutation":
                        rr = r[rng.permutation(n)]
                    elif nf == "circular_shift":
                        shift = int(rng.integers(1, max(2, n)))
                        rr = np.roll(r, shift)
                    elif nf == "orientation_reverse":
                        rr = r[::-1]
                    elif nf == "sign_flip":
                        rr = -r
                    else:
                        rr = r
                    vals.append(null_distance_for_pair(f, rr, method, k))
                vals_arr = np.asarray(vals, dtype=float)
                vals_arr = vals_arr[np.isfinite(vals_arr)]
                if vals_arr.size == 0:
                    continue
                null_mean = float(np.mean(vals_arr))
                null_std = float(np.std(vals_arr))
                z = (obs - null_mean) / null_std if null_std > 1e-15 else float("nan")
                # Upper-tail p: observed distance is unusually large relative to null.
                p_upper = float((1 + np.sum(vals_arr >= obs)) / (len(vals_arr) + 1))
                rows.append({
                    "candidate_id": cid,
                    "family": row.get("family", "UNKNOWN"),
                    "source_file": row.get("source_file", ""),
                    "semantic_tier": row.get("semantic_tier", ""),
                    "method": method,
                    "k": k,
                    "null_family": nf,
                    "n_null": int(len(vals_arr)),
                    "observed_lowk_coeff_distance": obs,
                    "null_mean": null_mean,
                    "null_std": null_std,
                    "null_z": z,
                    "p_upper_large_distance": p_upper,
                    "survives_p05": bool(p_upper < 0.05),
                    "survives_p10_review": bool(p_upper < 0.10),
                })
        except Exception as exc:
            errors.append(f"Null test failed for {cid}: {repr(exc)}")
    return pd.DataFrame(rows)


def source_family_ablation(lowk_df: pd.DataFrame, null_df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    if lowk_df.empty:
        return pd.DataFrame()
    # Combine survival flags by candidate/method/k.
    surv = pd.DataFrame()
    if not null_df.empty:
        surv = null_df.groupby(["candidate_id", "method", "k"], as_index=False).agg(
            any_p05=("survives_p05", "any"),
            any_p10=("survives_p10_review", "any"),
            min_p=("p_upper_large_distance", "min"),
        )
    merged = lowk_df.merge(surv, on=["candidate_id", "method", "k"], how="left") if not surv.empty else lowk_df.copy()
    for group_col in ["family", "source_kind", "semantic_tier", "source_file"]:
        if group_col not in merged.columns:
            continue
        g = merged.groupby(group_col, dropna=False)
        for key, sub in g:
            rows.append({
                "ablation_axis": group_col,
                "axis_value": str(key),
                "lowk_rows": int(len(sub)),
                "unique_candidates": int(sub["candidate_id"].nunique()),
                "nontrivial_lowk_rows": int(sub.get("nontrivial_lowk_gap", pd.Series(dtype=bool)).fillna(False).sum()),
                "mean_abs_retention_gap": float(pd.to_numeric(sub.get("abs_retention_gap", pd.Series(dtype=float)), errors="coerce").mean()),
                "mean_coeff_distance": float(pd.to_numeric(sub.get("normalized_lowk_coefficient_distance", pd.Series(dtype=float)), errors="coerce").mean()),
                "p05_surviving_rows": int(sub.get("any_p05", pd.Series(dtype=bool)).fillna(False).sum()) if "any_p05" in sub.columns else 0,
                "p10_review_rows": int(sub.get("any_p10", pd.Series(dtype=bool)).fillna(False).sum()) if "any_p10" in sub.columns else 0,
                "min_p_upper": float(pd.to_numeric(sub.get("min_p", pd.Series(dtype=float)), errors="coerce").min()) if "min_p" in sub.columns else float("nan"),
            })
    return pd.DataFrame(rows)


# =============================================================================
# PRIOR CHANNEL LEDGER AND V1L COMPARISON
# =============================================================================

def build_prior_channel_ledger(json_df: pd.DataFrame, csv_evidence_df: pd.DataFrame) -> pd.DataFrame:
    frames = []
    if json_df is not None and not json_df.empty:
        j = json_df.rename(columns={"json_key": "field"}).copy()
        j["evidence_source_type"] = "json"
        if "row_count" not in j.columns:
            j["row_count"] = 1
        frames.append(j[[
            "source_file", "relative_path", "stage", "family_hint", "channel_tags",
            "evidence_source_type", "evidence_kind", "field", "value", "numeric_value", "row_count"
        ]])
    if csv_evidence_df is not None and not csv_evidence_df.empty:
        c = csv_evidence_df.copy()
        c["evidence_source_type"] = "csv"
        frames.append(c[[
            "source_file", "relative_path", "stage", "family_hint", "channel_tags",
            "evidence_source_type", "evidence_kind", "field", "value", "numeric_value", "row_count"
        ]])
    if not frames:
        return pd.DataFrame()
    ledger = pd.concat(frames, ignore_index=True)
    # Assign a principal channel.  Keep all tags, but choose first priority for summary.
    priority = [
        "entropy_state_space_arrow",
        "operator_directionality",
        "forward_reverse_recursion",
        "low_k_spectral_vector",
        "partial_reversibility_sandbox",
        "family_lineage",
        "external_comparison_bookkeeping",
    ]
    def principal(tags: Any) -> str:
        tagset = set(str(tags).split(";"))
        for p in priority:
            if p in tagset:
                return p
        return "uncategorized_time_surrogate_context"
    ledger["principal_channel"] = ledger["channel_tags"].map(principal)
    # Evidence posture.
    def posture(row: pd.Series) -> str:
        text = f"{row.get('field','')} {row.get('value','')}".lower()
        if any(x in text for x in ["a_", "success", "supported", "survived", "present", "accepted", "positive"]):
            return "positive_or_supportive_prior_record"
        if any(x in text for x in ["review", "incomplete", "c_", "not claim", "sandbox", "ambig"]):
            return "review_or_sandbox_prior_record"
        if any(x in text for x in ["failed", "rejected", "not recovered", "negative"]):
            return "negative_or_failed_prior_record"
        return "context_or_metric_record"
    ledger["evidence_posture"] = ledger.apply(posture, axis=1)
    ledger["physica_d_trace_note"] = ledger.apply(
        lambda r: f"{r['principal_channel']} evidence from {r['stage']} via {Path(str(r['source_file'])).name}: {r['field']}", axis=1
    )
    return ledger


def compare_with_v1l(root: Path, errors: List[str]) -> pd.DataFrame:
    rows = []
    # Find v1l summary/adjudication in project tree and cwd/mnt-data style locations.
    patterns = [
        "**/stage7C_v1l_summary.json",
        "**/stage7C_v1l_final_adjudication_table.csv",
        "**/stage7C_v1l_ledger_note.txt",
    ]
    seen = set()
    for pat in patterns:
        for p in list(root.glob(pat)) + list(Path.cwd().glob(pat.replace("**/", ""))):
            if p in seen or not p.exists():
                continue
            seen.add(p)
            try:
                if p.suffix.lower() == ".json":
                    obj = json.loads(read_text_limited(p, max_chars=5_000_000))
                    for key in [
                        "final_decision", "lowk_channel_status", "entropy_channel_status",
                        "operator_directionality_channel_status", "partial_reversibility_channel_status",
                        "vector_exports_collected", "primary_candidate_count", "review_candidate_count",
                        "lowk_metric_rows", "null_ablation_rows", "null_p05_surviving_rows",
                        "patch_candidate_rows", "rerun_hooked_scripts", "vector_collection_errors",
                        "metric_errors", "external_constants_rule",
                    ]:
                        if key in obj:
                            rows.append({
                                "v1l_source_file": str(p),
                                "v1l_field": key,
                                "v1l_value": value_to_str(obj[key]),
                                "numeric_value": try_float(obj[key]),
                                "v1m_interpretation": "historical_v1l_baseline_for_comparison",
                            })
                elif p.suffix.lower() == ".csv":
                    df = pd.read_csv(p)
                    for _, r in df.iterrows():
                        rows.append({
                            "v1l_source_file": str(p),
                            "v1l_field": str(r.get("adjudication_channel", "row")),
                            "v1l_value": str(r.get("status", ""))[:500],
                            "numeric_value": try_float(r.get("evidence_count", None)),
                            "v1m_interpretation": str(r.get("final_decision", "historical_v1l_adjudication"))[:500],
                        })
                else:
                    txt = read_text_limited(p, max_chars=100_000)
                    for label in ["FINAL DECISION", "LOW-K CHANNEL STATUS", "ENTROPY-PRESERVATION RULE", "COUNTS"]:
                        if label in txt:
                            rows.append({
                                "v1l_source_file": str(p),
                                "v1l_field": label,
                                "v1l_value": "present_in_ledger_note",
                                "numeric_value": None,
                                "v1m_interpretation": "v1l ledger confirms this section exists",
                            })
            except Exception as exc:
                errors.append(f"v1l comparison failed for {p}: {repr(exc)}")
    return pd.DataFrame(rows)


# =============================================================================
# FINAL ADJUDICATION AND LEDGER
# =============================================================================

def final_adjudication(prior_ledger: pd.DataFrame, cand_df: pd.DataFrame, lowk_df: pd.DataFrame, null_df: pd.DataFrame, rework_df: pd.DataFrame) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    def count_channel(channel: str, posture_contains: Optional[str] = None) -> int:
        if prior_ledger.empty:
            return 0
        sub = prior_ledger[prior_ledger["principal_channel"] == channel]
        if posture_contains:
            sub = sub[sub["evidence_posture"].astype(str).str.contains(posture_contains, case=False, na=False)]
        return int(len(sub))

    lowk_rows = int(len(lowk_df)) if lowk_df is not None else 0
    nontrivial_lowk = int(lowk_df.get("nontrivial_lowk_gap", pd.Series(dtype=bool)).fillna(False).sum()) if lowk_df is not None and not lowk_df.empty else 0
    if null_df is not None and not null_df.empty:
        robust_null_df = null_df[null_df["null_family"].astype(str).isin(ROBUST_NULL_FAMILIES_FOR_PROMOTION)].copy()
        p05 = int(robust_null_df.get("survives_p05", pd.Series(dtype=bool)).fillna(False).sum())
        p10 = int(robust_null_df.get("survives_p10_review", pd.Series(dtype=bool)).fillna(False).sum())
    else:
        p05 = 0
        p10 = 0
    primary_candidates = int(cand_df["semantic_tier"].astype(str).str.contains("PRIMARY", case=False, na=False).sum()) if cand_df is not None and not cand_df.empty else 0
    tier1_rework = int(rework_df["priority_tier"].astype(str).str.contains("TIER_1", case=False, na=False).sum()) if rework_df is not None and not rework_df.empty else 0

    if p05 > 0 and primary_candidates > 0:
        lowk_decision = "A_INTERNAL_REVIEW_LOWK_WITNESS_RECOMPUTED_WITH_NULL_SURVIVAL"
        lowk_status = "LOWK_REVIEW_WITNESS_PRESENT_NOT_CLAIM_GRADE"
    elif nontrivial_lowk > 0:
        lowk_decision = "B_LOWK_NONTRIVIAL_BUT_NULL_OR_SEMANTIC_REVIEW_REQUIRED"
        lowk_status = "LOWK_REVIEW_ONLY"
    else:
        lowk_decision = "C_LOWK_NOT_CONFIRMED_IN_CONTEMPORARY_RECOMPUTE"
        lowk_status = "LOWK_NOT_PROMOTED"

    entropy_count = count_channel("entropy_state_space_arrow")
    entropy_positive = count_channel("entropy_state_space_arrow", "positive")
    if entropy_count > 0:
        entropy_status = "ENTROPY_PRIOR_EVIDENCE_PRESERVED_AND_AUDITED_SEPARATELY"
        entropy_decision = "KEEP_AS_INDEPENDENT_ARROW_SUPPORT_CHANNEL"
    else:
        entropy_status = "NO_ENTROPY_PRIOR_RECORDS_FOUND_BY_AUDIT"
        entropy_decision = "REQUIRES_MANUAL_ENTROPY_SOURCE_CHECK"

    operator_count = count_channel("operator_directionality") + count_channel("forward_reverse_recursion")
    if operator_count > 0:
        operator_status = "OPERATOR_DIRECTIONALITY_AND_FORWARD_REVERSE_RECORDS_AUDITED"
        operator_decision = "KEEP_SEPARATE_FROM_ENTROPY_AND_LOWK"
    else:
        operator_status = "NO_OPERATOR_DIRECTIONALITY_PRIOR_RECORDS_FOUND_BY_AUDIT"
        operator_decision = "REQUIRES_MANUAL_OPERATOR_SOURCE_CHECK"

    rework_status = "CONTEMPORARY_DERIVATIVE_REWORK_PLAN_BUILT" if tier1_rework > 0 else "REWORK_PLAN_BUILT_NO_TIER1_SCRIPT_FOUND"

    rows = [
        {
            "adjudication_channel": "low_k_spectral_vector_channel",
            "status": lowk_status,
            "final_decision": lowk_decision,
            "rationale": "Low-k metrics were recomputed under v1m identity from discovered forward/reverse vectors; promotion remains forbidden without manual semantic/source/family ablation review.",
            "evidence_count": int(len(cand_df)) if cand_df is not None else 0,
            "primary_candidate_count": primary_candidates,
            "lowk_metric_rows": lowk_rows,
            "nontrivial_lowk_rows": nontrivial_lowk,
            "null_p05_surviving_rows": p05,
            "null_p10_review_rows": p10,
            "claim_guardrail": "REVIEW_ONLY_UNLESS_TRUE_PRIMARY_INDEPENDENT_SHARED_IDENTITY_K_STABLE_NULL_SOURCE_AND_FAMILY_ABLATION_SURVIVAL",
        },
        {
            "adjudication_channel": "entropy_state_space_arrow_channel",
            "status": entropy_status,
            "final_decision": entropy_decision,
            "rationale": "Earlier entropy evidence is audited as its own channel and is not collapsed into partial reversibility or low-k weakness.",
            "evidence_count": entropy_count,
            "primary_candidate_count": None,
            "lowk_metric_rows": None,
            "nontrivial_lowk_rows": None,
            "null_p05_surviving_rows": None,
            "null_p10_review_rows": None,
            "claim_guardrail": "DO_NOT_MIX_ENTROPY_RESULTS_WITH_LOWK_OR_REVERSIBILITY_SANDBOX",
        },
        {
            "adjudication_channel": "operator_directionality_channel",
            "status": operator_status,
            "final_decision": operator_decision,
            "rationale": "Operator directionality, recursion, inverse/adjoint, and semigroup/group-like behavior must be adjudicated independently.",
            "evidence_count": operator_count,
            "primary_candidate_count": None,
            "lowk_metric_rows": None,
            "nontrivial_lowk_rows": None,
            "null_p05_surviving_rows": None,
            "null_p10_review_rows": None,
            "claim_guardrail": "NO_PHYSICAL_TIME_OR_SPACETIME_CLAIM_FROM_OPERATOR_CHANNEL_ALONE",
        },
        {
            "adjudication_channel": "partial_reversibility_sandbox",
            "status": "SANDBOX_DIAGNOSTIC_AUDITED_NOT_AUTOMATIC_DOWNGRADE",
            "final_decision": "KEEP_AS_AMBIGUITY_AND_FALSE_POSITIVE_CONTROL",
            "rationale": "Partial reversibility may explain residual ambiguity, but does not erase entropy or operator evidence unless those channels fail their own tests.",
            "evidence_count": count_channel("partial_reversibility_sandbox"),
            "primary_candidate_count": None,
            "lowk_metric_rows": None,
            "nontrivial_lowk_rows": None,
            "null_p05_surviving_rows": None,
            "null_p10_review_rows": None,
            "claim_guardrail": "NO_TIME_TRAVEL_NO_CTC_NO_MACROSCOPIC_TIME_REVERSAL_NO_THERMODYNAMICS_VIOLATION",
        },
        {
            "adjudication_channel": "contemporary_source_rework_plan",
            "status": rework_status,
            "final_decision": "DO_NOT_RERUN_OLD_SCRIPTS_BLINDLY_CREATE_STAGE7C_DERIVATIVES",
            "rationale": "v1m inventories old scripts as source material and recommends new Stage-7C-purpose derivative scripts with new output names.",
            "evidence_count": int(len(rework_df)) if rework_df is not None else 0,
            "primary_candidate_count": tier1_rework,
            "lowk_metric_rows": None,
            "nontrivial_lowk_rows": None,
            "null_p05_surviving_rows": None,
            "null_p10_review_rows": None,
            "claim_guardrail": "OLD_SCRIPT_OUTPUT_NAMES_ARE_HISTORICAL_DO_NOT_OVERWRITE",
        },
    ]
    summary = {
        "stage": STAGE_NAME,
        "run_label": RUN_LABEL,
        "final_decision": "A_INTERNAL_SYNTHESIS_SCRIPT_CREATED_EVIDENCE_CHANNELS_AUDITED_AND_RECOMPUTED",
        "lowk_decision": lowk_decision,
        "entropy_status": entropy_status,
        "operator_status": operator_status,
        "candidate_vectors_found": int(len(cand_df)) if cand_df is not None else 0,
        "primary_candidate_count": primary_candidates,
        "lowk_metric_rows": lowk_rows,
        "nontrivial_lowk_rows": nontrivial_lowk,
        "null_rows": int(len(null_df)) if null_df is not None else 0,
        "null_p05_surviving_rows": p05,
        "prior_entropy_records": entropy_count,
        "prior_entropy_positive_or_supportive_records": entropy_positive,
        "prior_operator_or_forward_reverse_records": operator_count,
        "tier1_rework_script_candidates": tier1_rework,
        "forbidden_claims": [
            "physical time derived",
            "spacetime derived",
            "thermodynamic arrow proven",
            "entropy production proven",
            "cosmic age derived",
            "Friedmann equations derived",
            "Einstein gravity derived",
            "Omega_m derived",
            "dark energy derived",
            "curvature of the universe derived",
            "quantum gravity proven",
            "quantum-mechanical interpretation confirmed",
        ],
        "external_constants_rule": "No PDG/Planck/LambdaCDM/Friedmann/GR/cosmological constants may select, orient, fit, score, or upgrade low-k witnesses.",
        "robust_null_promotion_rule": "Only permutation and circular_shift null survival counts toward low-k promotion; orientation_reverse/sign_flip are diagnostic controls only.",
    }
    return pd.DataFrame(rows), summary


def write_ledger_note(out_path: Path, summary: Dict[str, Any], outputs: Dict[str, Path], errors_count: int) -> None:
    lines = []
    lines.append("=" * 60)
    lines.append("ASCII LEDGER NOTE")
    lines.append("Project: Quantum-Emergent Gravity")
    lines.append(f"Stage: {STAGE_NAME}")
    lines.append("Working Title: One Script to Rule Time-Surrogate Evidence")
    lines.append(f"Run Timestamp: {summary.get('run_timestamp', now_timestamp())}")
    lines.append("=" * 60)
    lines.append("")
    lines.append("FINAL DECISION")
    lines.append("--------------")
    lines.append(str(summary.get("final_decision")))
    lines.append("")
    lines.append("PURPOSE")
    lines.append("-------")
    lines.append("v1m combines contemporary Stage-7C recomputation with retrospective JSON/CSV evidence auditing.")
    lines.append("It does not rerun old scripts under their old purpose and does not overwrite historical outputs.")
    lines.append("")
    lines.append("LOW-K CHANNEL")
    lines.append("-------------")
    lines.append(str(summary.get("lowk_decision")))
    lines.append(f"Candidate vectors found: {summary.get('candidate_vectors_found')}")
    lines.append(f"Primary/review candidate count: {summary.get('primary_candidate_count')}")
    lines.append(f"Low-k metric rows: {summary.get('lowk_metric_rows')}")
    lines.append(f"Nontrivial low-k rows: {summary.get('nontrivial_lowk_rows')}")
    lines.append(f"Null p<0.05 rows: {summary.get('null_p05_surviving_rows')}")
    lines.append("")
    lines.append("ENTROPY-PRESERVATION RULE")
    lines.append("-------------------------")
    lines.append("Earlier Stage-7 entropy results are preserved as an independent arrow-support channel.")
    lines.append("They are not collapsed into the partial-reversibility sandbox and are not downgraded by low-k weakness.")
    lines.append(f"Prior entropy records found: {summary.get('prior_entropy_records')}")
    lines.append("")
    lines.append("OPERATOR-DIRECTIONALITY CHANNEL")
    lines.append("-------------------------------")
    lines.append("Operator directionality remains separate from entropy and low-k evidence.")
    lines.append(f"Prior operator/forward-reverse records found: {summary.get('prior_operator_or_forward_reverse_records')}")
    lines.append("")
    lines.append("CONTEMPORARY REWORK RULE")
    lines.append("------------------------")
    lines.append("Old upstream scripts are source material.  New Stage-7C-purpose derivative scripts should have new names and new output folders.")
    lines.append(f"Tier-1 rework candidates found: {summary.get('tier1_rework_script_candidates')}")
    lines.append("")
    lines.append("EXTERNAL CONSTANTS RULE")
    lines.append("-----------------------")
    lines.append(str(summary.get("external_constants_rule")))
    lines.append("")
    lines.append("FORBIDDEN CLAIMS")
    lines.append("----------------")
    for c in summary.get("forbidden_claims", []):
        lines.append(f"- {c}")
    lines.append("")
    lines.append("OUTPUTS")
    lines.append("-------")
    for name, path in outputs.items():
        lines.append(f"{name}: {path}")
    lines.append("")
    lines.append("INSPECTION ERRORS")
    lines.append("-----------------")
    lines.append(f"Errors/warnings recorded: {errors_count}")
    lines.append("")
    lines.append("=" * 60)
    lines.append("END LEDGER NOTE")
    lines.append("=" * 60)
    out_path.write_text("\n".join(lines), encoding="utf-8")


# =============================================================================
# MAIN
# =============================================================================

def main() -> None:
    root = detect_project_root()
    out_dir = root / OUTPUT_RELATIVE
    ensure_dir(out_dir)
    errors: List[str] = []

    print("=" * 72)
    print(f"{STAGE_NAME}: {RUN_LABEL}")
    print("=" * 72)
    print(f"Project root: {root}")
    print(f"Output dir  : {out_dir}")
    print("Discovering files...")

    all_files = discover_files(root)
    inventory_df = file_inventory(all_files, root)
    csv_files = [p for p in all_files if p.suffix.lower() == ".csv"]
    json_files = [p for p in all_files if p.suffix.lower() == ".json"]
    script_files = [p for p in all_files if p.suffix.lower() == ".py"]

    print(f"Files discovered: {len(all_files)}")
    print(f"CSV files       : {len(csv_files)}")
    print(f"JSON files      : {len(json_files)}")
    print(f"Python scripts  : {len(script_files)}")

    print("Auditing JSON summaries...")
    json_audit_df = audit_json_files(json_files, root, errors)

    print("Auditing CSV evidence tables...")
    csv_audit_df, csv_evidence_df = audit_csv_files(csv_files, root, errors)

    print("Building prior time-surrogate channel ledger...")
    prior_ledger_df = build_prior_channel_ledger(json_audit_df, csv_evidence_df)

    print("Inspecting source scripts for contemporary rework plan...")
    rework_df = source_script_rework_plan(script_files, root, errors)

    print("Extracting contemporary forward/reverse vector candidates from CSV tables...")
    csv_cand_df, csv_vectors = extract_csv_vector_candidates(csv_files, root, out_dir, errors)

    print("Importing v1l npz vector pairs, if present, for contemporary recomputation...")
    v1l_cand_df, v1l_vectors = extract_v1l_npz_candidates(root, out_dir, errors)

    cand_frames = [df for df in [csv_cand_df, v1l_cand_df] if df is not None and not df.empty]
    cand_df = pd.concat(cand_frames, ignore_index=True) if cand_frames else pd.DataFrame()
    vectors: Dict[str, Tuple[np.ndarray, np.ndarray]] = {}
    vectors.update(csv_vectors)
    vectors.update(v1l_vectors)
    if not cand_df.empty:
        cand_df = cand_df.drop_duplicates(subset=["candidate_id"]).reset_index(drop=True)
        cand_df = cand_df.head(MAX_VECTOR_CANDIDATES_TO_SCORE).copy()

    print(f"Vector candidates retained for scoring: {len(cand_df)}")
    print("Recomputing low-k metrics...")
    lowk_df = recompute_lowk_metrics(cand_df, vectors, errors)

    print("Running null tests on prioritized low-k rows...")
    null_df = run_null_tests(lowk_df, vectors, errors)

    print("Building source/family ablation summary...")
    ablation_df = source_family_ablation(lowk_df, null_df)

    print("Comparing against v1l outputs, if present...")
    v1l_comparison_df = compare_with_v1l(root, errors)

    print("Final adjudication...")
    adjudication_df, summary = final_adjudication(prior_ledger_df, cand_df, lowk_df, null_df, rework_df)
    summary.update({
        "run_timestamp": now_timestamp(),
        "project_root": str(root),
        "output_dir": str(out_dir),
        "files_discovered": len(all_files),
        "csv_files_found": len(csv_files),
        "json_files_found": len(json_files),
        "scripts_found": len(script_files),
        "json_audit_rows": int(len(json_audit_df)),
        "csv_audit_rows": int(len(csv_audit_df)),
        "prior_channel_ledger_rows": int(len(prior_ledger_df)),
        "source_rework_plan_rows": int(len(rework_df)),
        "v1l_comparison_rows": int(len(v1l_comparison_df)),
        "inspection_error_count": len(errors),
        "random_seed": RANDOM_SEED,
        "k_values": K_VALUES,
        "n_null": N_NULL,
        "create_derivative_script_stubs": CREATE_DERIVATIVE_SCRIPT_STUBS,
        "old_script_rerun_policy": "DO_NOT_RERUN_OLD_SCRIPTS_BLINDLY; FORK_REWORK_RELEVANT_LOGIC_INTO_NEW_STAGE7C_DERIVATIVE_SCRIPTS",
    })

    # Output paths
    outputs = {
        "file_inventory": out_dir / "stage7C_v1m_file_inventory.csv",
        "prior_json_summary_audit": out_dir / "stage7C_v1m_prior_json_summary_audit.csv",
        "prior_csv_evidence_audit": out_dir / "stage7C_v1m_prior_csv_evidence_audit.csv",
        "prior_time_surrogate_channel_ledger": out_dir / "stage7C_v1m_prior_time_surrogate_channel_ledger.csv",
        "source_script_rework_plan": out_dir / "stage7C_v1m_source_script_rework_plan.csv",
        "candidate_vector_exports": out_dir / "stage7C_v1m_candidate_vector_exports.csv",
        "recomputed_lowk_metrics": out_dir / "stage7C_v1m_recomputed_lowk_metrics.csv",
        "null_ablation": out_dir / "stage7C_v1m_null_ablation.csv",
        "source_family_ablation": out_dir / "stage7C_v1m_source_family_ablation.csv",
        "v1l_comparison_summary": out_dir / "stage7C_v1m_v1l_comparison_summary.csv",
        "final_adjudication_table": out_dir / "stage7C_v1m_final_adjudication_table.csv",
        "summary": out_dir / "stage7C_v1m_summary.json",
        "ledger_note": out_dir / "stage7C_v1m_ledger_note.txt",
        "inspection_errors": out_dir / "stage7C_v1m_inspection_errors.txt",
    }

    inventory_df.to_csv(outputs["file_inventory"], index=False)
    json_audit_df.to_csv(outputs["prior_json_summary_audit"], index=False)
    csv_audit_df.to_csv(outputs["prior_csv_evidence_audit"], index=False)
    prior_ledger_df.to_csv(outputs["prior_time_surrogate_channel_ledger"], index=False)
    rework_df.to_csv(outputs["source_script_rework_plan"], index=False)
    cand_df.to_csv(outputs["candidate_vector_exports"], index=False)
    lowk_df.to_csv(outputs["recomputed_lowk_metrics"], index=False)
    null_df.to_csv(outputs["null_ablation"], index=False)
    ablation_df.to_csv(outputs["source_family_ablation"], index=False)
    v1l_comparison_df.to_csv(outputs["v1l_comparison_summary"], index=False)
    adjudication_df.to_csv(outputs["final_adjudication_table"], index=False)
    outputs["summary"].write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    outputs["inspection_errors"].write_text("\n".join(errors), encoding="utf-8")
    write_ledger_note(outputs["ledger_note"], summary, outputs, len(errors))

    print("=" * 72)
    print("Stage-7C-v1m complete")
    print(f"Final decision: {summary['final_decision']}")
    print(f"Low-k decision: {summary['lowk_decision']}")
    print(f"Entropy status: {summary['entropy_status']}")
    print(f"Operator status: {summary['operator_status']}")
    print(f"Output dir    : {out_dir}")
    print("=" * 72)


if __name__ == "__main__":
    try:
        main()
    except Exception:
        print("FATAL ERROR IN STAGE-7C-v1m")
        traceback.print_exc()
        raise
