#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Quantum-Emergent Gravity
Stage-7C-v1a: Witness-Class Reconstruction and Valid-Denominator Adjudication
Author: Arturo Ortiz-Tapia / QEG pipeline assistant
Build date: 2026-05-31

Purpose
-------
Repair the Stage-7C-v1 adjudication machinery without adding new physical
claims.  This script separates admissible witness classes by evidence channel,
uses valid evidence denominators rather than a single overbroad Tier-1 bucket,
audits sign conventions, completes entropy state-space bookkeeping where
possible, and preserves physical-semantics / Friedmann / GR material as
tracker-only.

Run mode
--------
Expected on Dakini from:
    /home/dakini/Downloads/010-Quantum_Emergent_Gravity/metric_stage_7C_scripts

Example:
    python3 Stage-7C_witness_class_reconstruction_valid_denominator_v1a.py

Optional:
    python3 Stage-7C_witness_class_reconstruction_valid_denominator_v1a.py \
        --root /home/dakini/Downloads/010-Quantum_Emergent_Gravity

Outputs
-------
    metric_stage_7C_outputs/witness_class_reconstruction_valid_denominator_v1a/

Guardrail
---------
This script may produce internal time-surrogate and operator-irreversibility
verdicts only.  It must not claim physical time, spacetime, Friedmann equations,
Einstein gravity, Omega_m, dark energy, entropy production, or quantum gravity.
"""

from __future__ import annotations

import argparse
import json
import math
import re
import sys
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

try:
    import matplotlib.pyplot as plt
    HAS_MATPLOTLIB = True
except Exception:
    HAS_MATPLOTLIB = False


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

STAGE_NAME = "Stage-7C-v1a"
SCRIPT_NAME = "Stage-7C_witness_class_reconstruction_valid_denominator_v1a.py"
OUTPUT_SUBDIR = "witness_class_reconstruction_valid_denominator_v1a"

PRIMARY_V1_DIR_CANDIDATES = [
    "metric_stage_7C_outputs/admissible_witness_physical_semantics_bridge_v1",
    "metric_stage_7C_outputs/admissible_witness_physical_semantics_bridge_v1a",
]

FALLBACK_7B_DIR_CANDIDATES = [
    "metric_stage_7B_outputs/time_surrogate_robustness_operator_irreversibility_v1",
]

PRIMARY_EXPECTED_FILES = [
    "stage7C_candidate_tier_classification.csv",
    "stage7C_admissible_witness_table.csv",
    "stage7C_tier1_directionality_table.csv",
    "stage7C_tier1_null_survival_table.csv",
    "stage7C_tier1_family_stability_table.csv",
    "stage7C_lowk_operator_coupling_table.csv",
    "stage7C_entropy_semantics_audit.csv",
    "stage7C_entropy_state_space_dependence.csv",
    "stage7C_time_reversibility_sandbox_summary.json",
    "stage7C_forward_reverse_reversibility_table.csv",
    "stage7C_lowk_forward_backward_reconstruction.csv",
    "stage7C_operator_inverse_adjoint_recovery.csv",
    "stage7C_shuffled_temporal_label_nulls.csv",
    "stage7C_verdict_criteria_table.csv",
    "stage7C_stage7B_input_presence_audit.csv",
    "stage7C_stage7B_expected_pattern_audit.csv",
]

FALLBACK_EXPECTED_FILES = [
    "stage7B_forward_reverse_directionality_table.csv",
    "stage7B_recursion_directionality_summary.json",
    "stage7B_null_survival_scores.csv",
    "stage7B_null_control_results.csv",
    "stage7B_family_perturbation_audit.csv",
    "stage7B_family_stability_summary.json",
    "stage7B_entropy_trajectory_tests.csv",
    "stage7B_entropy_state_space_audit.csv",
    "stage7B_spacetime_surrogate_coupling_table.csv",
    "stage7B_spacetime_surrogate_coupling_summary.json",
    "stage7B_summary.json",
]

FAMILY_VALUES = {"BARI", "NUFIT", "VALENCIA", "POOLED"}
TRUE_FAMILIES = {"BARI", "NUFIT", "VALENCIA"}

FORBIDDEN_CLAIMS = [
    "physical time derived",
    "spacetime derived",
    "thermodynamic arrow proven",
    "entropy production proven",
    "cosmic age derived",
    "Friedmann equations derived",
    "Einstein gravity derived",
    "Omega_m derived",
    "dark energy derived",
    "curvature of the universe derived",
    "quantum gravity proven",
    "quantum-mechanical interpretation confirmed",
]

ALLOWED_INTERNAL_TERMS = [
    "internal time surrogate candidate",
    "admissible time-surrogate witness class",
    "intrinsic ordering variable",
    "recursive directionality",
    "operator irreversibility",
    "low-k structural retention arrow",
    "information-flow asymmetry",
    "entropy-like statistical ordering diagnostic",
    "entropy-state-space declared diagnostic",
    "space-time surrogate coupling, internal only",
    "physical semantics bridge tracker",
    "Friedmann-style semantic audit",
    "cosmic-time benchmark audit",
    "effective interval precheck",
]


# ---------------------------------------------------------------------------
# Utility functions
# ---------------------------------------------------------------------------


def now_iso() -> str:
    return datetime.now().replace(microsecond=0).isoformat()


def norm_name(name: Any) -> str:
    """Normalize a column/file key to a lowercase alphanumeric token."""
    s = str(name).strip().lower()
    s = re.sub(r"[^a-z0-9]+", "_", s)
    s = re.sub(r"_+", "_", s).strip("_")
    return s


def safe_float(x: Any) -> float:
    if x is None:
        return np.nan
    try:
        if isinstance(x, str):
            xs = x.strip().replace("%", "")
            if xs == "" or xs.lower() in {"nan", "none", "null", "not_tested", "missing"}:
                return np.nan
            return float(xs)
        return float(x)
    except Exception:
        return np.nan


def to_serializable(obj: Any) -> Any:
    """Convert numpy/pandas types for json.dump."""
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        val = float(obj)
        return None if math.isnan(val) or math.isinf(val) else val
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    if isinstance(obj, Path):
        return str(obj)
    if isinstance(obj, pd.Timestamp):
        return obj.isoformat()
    if isinstance(obj, dict):
        return {str(k): to_serializable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple, set)):
        return [to_serializable(v) for v in obj]
    if obj is pd.NA:
        return None
    if isinstance(obj, float) and (math.isnan(obj) or math.isinf(obj)):
        return None
    return obj


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def infer_project_root(explicit_root: Optional[str] = None) -> Path:
    if explicit_root:
        return Path(explicit_root).expanduser().resolve()

    cwd = Path.cwd().resolve()
    if cwd.name == "metric_stage_7C_scripts":
        return cwd.parent

    for candidate in [cwd] + list(cwd.parents):
        if candidate.name == "010-Quantum_Emergent_Gravity":
            return candidate
        if (candidate / "metric_stage_7C_scripts").exists():
            return candidate
        if (candidate / "metric_stage_7C_outputs").exists() or (candidate / "metric_stage_7B_outputs").exists():
            return candidate

    # Safe fallback: current directory. The run will remain non-destructive and
    # produce an E_NOT_ADJUDICABLE verdict if inputs are absent.
    return cwd


def read_csv_flex(path: Path) -> pd.DataFrame:
    for kwargs in [
        dict(),
        dict(encoding="utf-8-sig"),
        dict(encoding="latin1"),
        dict(sep=None, engine="python"),
    ]:
        try:
            return pd.read_csv(path, **kwargs)
        except Exception:
            continue
    raise RuntimeError(f"Could not read CSV: {path}")


def read_json_flex(path: Path) -> Any:
    text = path.read_text(encoding="utf-8", errors="replace")
    return json.loads(text)


def write_json(path: Path, obj: Dict[str, Any]) -> None:
    path.write_text(json.dumps(to_serializable(obj), indent=2, sort_keys=False), encoding="utf-8")


def find_column(df: pd.DataFrame, patterns: Sequence[str], exclude: Sequence[str] = ()) -> Optional[str]:
    """Return first column whose normalized name matches any regex pattern."""
    if df is None or df.empty:
        return None
    norm_cols = {c: norm_name(c) for c in df.columns}
    for pat in patterns:
        rx = re.compile(pat)
        for original, normalized in norm_cols.items():
            if any(re.search(ex, normalized) for ex in exclude):
                continue
            if rx.search(normalized):
                return original
    return None


def find_columns(df: pd.DataFrame, patterns: Sequence[str], exclude: Sequence[str] = ()) -> List[str]:
    if df is None or df.empty:
        return []
    out: List[str] = []
    norm_cols = {c: norm_name(c) for c in df.columns}
    for pat in patterns:
        rx = re.compile(pat)
        for original, normalized in norm_cols.items():
            if original in out:
                continue
            if any(re.search(ex, normalized) for ex in exclude):
                continue
            if rx.search(normalized):
                out.append(original)
    return out


def numeric_col(df: pd.DataFrame, col: Optional[str]) -> pd.Series:
    if col is None or col not in df.columns:
        return pd.Series([np.nan] * len(df), index=df.index, dtype="float64")
    return pd.to_numeric(df[col].map(safe_float), errors="coerce")


def as_string_series(df: pd.DataFrame, col: Optional[str], default: str = "") -> pd.Series:
    if col is None or col not in df.columns:
        return pd.Series([default] * len(df), index=df.index, dtype="object")
    return df[col].astype(str).fillna(default)


def boolish_series(df: pd.DataFrame, col: Optional[str]) -> pd.Series:
    if col is None or col not in df.columns:
        return pd.Series([False] * len(df), index=df.index, dtype="bool")
    def one(v: Any) -> bool:
        s = str(v).strip().lower()
        return s in {"1", "true", "yes", "y", "admissible", "valid", "tier1", "tier_1", "tier-1"}
    return df[col].map(one).fillna(False)


def fraction(num: float, den: float) -> float:
    if den is None or den == 0 or pd.isna(den):
        return np.nan
    return float(num) / float(den)


def simple_status_from_bool(value: bool, true_label: str, false_label: str) -> str:
    return true_label if bool(value) else false_label


# ---------------------------------------------------------------------------
# Data discovery and load
# ---------------------------------------------------------------------------

@dataclass
class LoadedTable:
    key: str
    path: Path
    source_stage: str
    source_channel: str
    dataframe: Optional[pd.DataFrame] = None
    json_obj: Optional[Any] = None
    load_status: str = "NOT_LOADED"
    row_count: int = 0
    column_count: int = 0


def expected_channel(filename: str) -> str:
    n = norm_name(filename)
    if "direction" in n or "forward_reverse" in n or "recursion_directionality" in n:
        return "directionality"
    if "null" in n or "shuffle" in n:
        return "null_survival"
    if "family" in n:
        return "family_stability"
    if "lowk" in n or "low_k" in n or "operator" in n:
        if "inverse" in n or "adjoint" in n:
            return "reversibility"
        return "lowk_operator"
    if "entropy" in n:
        return "entropy_state_space"
    if "revers" in n or "inverse" in n or "adjoint" in n:
        return "reversibility"
    if "semantic" in n or "friedmann" in n or "cosmic" in n or "interval" in n or "bridge" in n:
        return "semantic_tracker"
    if "input_presence" in n or "expected_pattern" in n:
        return "input_audit"
    return "general"


def discover_expected_files(root: Path) -> Dict[str, List[Path]]:
    """Locate expected Stage-7C-v1 and Stage-7B files without crawling unrelated assets."""
    search_roots: List[Path] = []
    for rel in PRIMARY_V1_DIR_CANDIDATES + FALLBACK_7B_DIR_CANDIDATES:
        p = root / rel
        if p.exists():
            search_roots.append(p)

    # Add near-match output subdirectories under Stage-7C/7B outputs.
    for parent_rel in ["metric_stage_7C_outputs", "metric_stage_7B_outputs"]:
        parent = root / parent_rel
        if parent.exists():
            for child in parent.iterdir():
                if child.is_dir():
                    cn = norm_name(child.name)
                    if any(tok in cn for tok in ["admissible", "semantic", "irreversibility", "time_surrogate", "stage7c", "stage7b"]):
                        search_roots.append(child)

    # Deduplicate while preserving order.
    unique_roots: List[Path] = []
    seen = set()
    for p in search_roots:
        rp = p.resolve()
        if rp not in seen:
            unique_roots.append(rp)
            seen.add(rp)

    expected = PRIMARY_EXPECTED_FILES + FALLBACK_EXPECTED_FILES
    found: Dict[str, List[Path]] = {name: [] for name in expected}

    for name in expected:
        for d in unique_roots:
            candidate = d / name
            if candidate.exists():
                found[name].append(candidate)
        # Last-resort limited recursive lookup within Stage-7B/7C outputs.
        if not found[name]:
            for parent_rel in ["metric_stage_7C_outputs", "metric_stage_7B_outputs"]:
                parent = root / parent_rel
                if parent.exists():
                    found[name].extend(sorted(parent.rglob(name)))

    return found


def load_all_inputs(root: Path) -> Tuple[List[LoadedTable], pd.DataFrame]:
    found = discover_expected_files(root)
    loaded: List[LoadedTable] = []
    audit_rows: List[Dict[str, Any]] = []

    for name, paths in found.items():
        source_stage = "Stage-7C-v1" if name.startswith("stage7C") else "Stage-7B"
        channel = expected_channel(name)
        if not paths:
            audit_rows.append({
                "expected_file": name,
                "source_stage": source_stage,
                "source_channel": channel,
                "exists": False,
                "path": "",
                "load_status": "MISSING",
                "row_count": 0,
                "column_count": 0,
                "key_fields_found": "",
            })
            continue

        # Load all matching paths, but prefer exact files in expected directories.
        for path in paths:
            table = LoadedTable(key=name, path=path, source_stage=source_stage, source_channel=channel)
            try:
                if path.suffix.lower() == ".csv":
                    df = read_csv_flex(path)
                    table.dataframe = df
                    table.load_status = "LOADED_CSV"
                    table.row_count = len(df)
                    table.column_count = len(df.columns)
                elif path.suffix.lower() == ".json":
                    obj = read_json_flex(path)
                    table.json_obj = obj
                    table.load_status = "LOADED_JSON"
                    if isinstance(obj, list):
                        table.row_count = len(obj)
                    elif isinstance(obj, dict):
                        table.row_count = 1
                        table.column_count = len(obj.keys())
                    else:
                        table.row_count = 1
                else:
                    table.load_status = "UNSUPPORTED_EXTENSION"
            except Exception as exc:
                table.load_status = f"LOAD_ERROR: {exc}"

            loaded.append(table)
            key_fields = []
            if table.dataframe is not None:
                for pats, label in [
                    ([r"family"], "family"),
                    ([r"forward"], "forward"),
                    ([r"reverse|backward"], "reverse"),
                    ([r"gap"], "gap"),
                    ([r"null|shuffle"], "null"),
                    ([r"entropy"], "entropy"),
                    ([r"state.*space|space.*state"], "state_space"),
                    ([r"low_?k"], "lowk"),
                    ([r"inverse|adjoint"], "inverse_adjoint"),
                ]:
                    if find_column(table.dataframe, pats):
                        key_fields.append(label)
            elif table.json_obj is not None:
                keys = table.json_obj.keys() if isinstance(table.json_obj, dict) else []
                nk = [norm_name(k) for k in keys]
                for label, toks in {
                    "family": ["family"],
                    "directionality": ["direction", "gap", "forward", "reverse"],
                    "null": ["null", "shuffle"],
                    "entropy": ["entropy", "state_space"],
                    "lowk": ["lowk", "low_k"],
                    "inverse_adjoint": ["inverse", "adjoint"],
                }.items():
                    if any(any(tok in k for tok in toks) for k in nk):
                        key_fields.append(label)

            audit_rows.append({
                "expected_file": name,
                "source_stage": source_stage,
                "source_channel": channel,
                "exists": True,
                "path": str(path),
                "load_status": table.load_status,
                "row_count": table.row_count,
                "column_count": table.column_count,
                "key_fields_found": ";".join(sorted(set(key_fields))),
            })

    audit_df = pd.DataFrame(audit_rows)
    return loaded, audit_df


# ---------------------------------------------------------------------------
# Witness extraction
# ---------------------------------------------------------------------------


def detect_candidate_id(df: pd.DataFrame, source_key: str) -> pd.Series:
    id_col = find_column(df, [
        r"^(candidate|witness|metric|row|record|object)_?id$",
        r"^id$",
        r"candidate",
        r"witness",
        r"metric_id",
    ])
    if id_col:
        return df[id_col].astype(str).fillna("")
    return pd.Series([f"{source_key}::row_{i:06d}" for i in range(len(df))], index=df.index)


def detect_family(df: pd.DataFrame, path: Path) -> pd.Series:
    fam_col = find_column(df, [r"^family$", r"family", r"fit_id", r"fit$", r"npz_file", r"lineage"])
    if fam_col is not None:
        raw = df[fam_col].astype(str).str.upper()
    else:
        raw = pd.Series([path.name.upper()] * len(df), index=df.index)

    def parse_family(v: str) -> str:
        up = str(v).upper()
        for fam in ["BARI", "NUFIT", "VALENCIA", "POOLED"]:
            if fam in up:
                return fam
        return "UNKNOWN"

    return raw.map(parse_family)


def detect_tier(df: pd.DataFrame) -> Tuple[pd.Series, pd.Series]:
    tier_col = find_column(df, [r"tier", r"class", r"admissible"])
    if tier_col is None:
        tier = pd.Series(["UNKNOWN"] * len(df), index=df.index)
    else:
        tier = df[tier_col].astype(str).fillna("UNKNOWN")

    admiss_col = find_column(df, [r"admissible", r"valid_witness", r"tier_?1", r"claim_grade"])
    admiss = boolish_series(df, admiss_col)

    tier_norm = tier.map(norm_name)
    tier1_by_text = tier_norm.str.contains(r"tier_?1|tier1|t1|admissible|valid", regex=True, na=False)
    return tier, (admiss | tier1_by_text)


def source_is_semantic_tracker(path: Path, channel: str) -> bool:
    n = norm_name(path.name)
    return channel == "semantic_tracker" or any(tok in n for tok in [
        "semantic", "friedmann", "cosmic", "age", "interval", "bridge", "physical_semantics"
    ])


def row_excluded_unsafe(row: pd.Series) -> bool:
    # Conservative leakage / benchmark-injection detector.  Missing data is not
    # unsafe; it becomes NOT_TESTED elsewhere.
    joined = " ".join(str(v).lower() for v in row.values if pd.notna(v))
    unsafe_tokens = [
        "target_as_source", "target as source", "leakage", "benchmark injection",
        "pdg injection", "planck injection", "lambda_cdm injection", "unsafe",
        "excluded", "reject_leak", "tautological"
    ]
    return any(tok in joined for tok in unsafe_tokens)


def extract_directionality_fields(df: pd.DataFrame) -> Tuple[Optional[str], Optional[str], Optional[str]]:
    # Exclude low-k specific columns when searching generic directionality.
    exclude_lowk = [r"low_?k", r"retention"]
    fwd = find_column(df, [
        r"^forward(_score|_metric|_value|_directionality|_irreversibility)?$",
        r"forward.*(score|metric|value|direction|irrevers|corr|r2)",
        r"fwd.*(score|metric|value|direction|irrevers|corr|r2)",
    ], exclude=exclude_lowk)
    rev = find_column(df, [
        r"^reverse(_score|_metric|_value|_directionality|_irreversibility)?$",
        r"reverse.*(score|metric|value|direction|irrevers|corr|r2)",
        r"backward.*(score|metric|value|direction|irrevers|corr|r2)",
        r"rev.*(score|metric|value|direction|irrevers|corr|r2)",
    ], exclude=exclude_lowk)
    gap = find_column(df, [
        r"forward.*reverse.*gap",
        r"reverse.*forward.*gap",
        r"direction.*gap",
        r"operator.*gap",
        r"^gap$",
        r"delta.*forward.*reverse",
    ], exclude=exclude_lowk)
    return fwd, rev, gap


def extract_null_fields(df: pd.DataFrame) -> Tuple[Optional[str], Optional[str], Optional[str]]:
    score = find_column(df, [
        r"strict.*null.*survival",
        r"null.*survival.*fraction",
        r"null.*survival.*score",
        r"survival.*null",
        r"null_score",
        r"against.*null",
    ])
    null_type = find_column(df, [r"null.*type", r"null.*model", r"shuffled", r"shuffle.*type", r"control.*type"])
    shuffled = find_column(df, [r"shuffl.*score", r"temporal.*null", r"label.*null", r"reverse.*null"])
    return score, null_type, shuffled


def extract_lowk_fields(df: pd.DataFrame) -> Tuple[Optional[str], Optional[str], Optional[str]]:
    fwd_lowk = find_column(df, [r"forward.*low_?k.*retention", r"low_?k.*forward", r"forward_lowk", r"fwd.*low_?k"])
    rev_lowk = find_column(df, [r"reverse.*low_?k.*retention", r"backward.*low_?k.*retention", r"low_?k.*reverse", r"low_?k.*backward", r"reverse_lowk", r"backward_lowk"])
    op_diag = find_column(df, [r"operator.*asym", r"asymmetry", r"rank", r"low_?rank", r"toeplitz", r"sector.*preserv", r"low_?k.*coupling"])
    return fwd_lowk, rev_lowk, op_diag


def extract_entropy_fields(df: pd.DataFrame) -> Tuple[Optional[str], Optional[str], Optional[str], Optional[str]]:
    slope = find_column(df, [r"entropy.*slope", r"entropy_like_slope", r"slope.*entropy", r"entropy.*trend"])
    state_space = find_column(df, [r"entropy.*state.*space", r"state.*space", r"space.*state", r"entropy_space"])
    inherited_source = find_column(df, [r"inherit.*source", r"state.*source", r"source.*state", r"registry", r"declared.*source"])
    agreement = find_column(df, [r"operator.*agreement", r"gap.*agreement", r"entropy.*agreement", r"sign.*agreement"])
    return slope, state_space, inherited_source, agreement


def extract_reversibility_fields(df: pd.DataFrame) -> Dict[str, Optional[str]]:
    return {
        "reverse_compatibility": find_column(df, [r"reverse.*compat", r"compat.*reverse", r"reversible.*compat"]),
        "reverse_null_equivalence": find_column(df, [r"reverse.*null", r"null.*equiv", r"shuffl", r"temporal.*null"]),
        "inverse_recovery": find_column(df, [r"inverse.*recover", r"recover.*inverse", r"inverse_like", r"inverse"]),
        "adjoint_recovery": find_column(df, [r"adjoint.*recover", r"recover.*adjoint", r"adjoint_like", r"adjoint"]),
        "reversible_sector": find_column(df, [r"reversible.*sector", r"sector.*reversible", r"grouplike", r"semigroup"]),
    }


def build_witness_class_table(loaded: List[LoadedTable]) -> pd.DataFrame:
    rows: List[pd.DataFrame] = []

    for table in loaded:
        if table.dataframe is None or table.dataframe.empty:
            continue
        df = table.dataframe.copy()
        source_file = str(table.path)
        source_name = table.path.name

        candidate_id = detect_candidate_id(df, source_name)
        family = detect_family(df, table.path)
        tier, tier1 = detect_tier(df)

        fwd_col, rev_col, gap_col = extract_directionality_fields(df)
        forward = numeric_col(df, fwd_col)
        reverse = numeric_col(df, rev_col)
        raw_gap = numeric_col(df, gap_col)
        computed_gap = forward - reverse
        gap = raw_gap.where(raw_gap.notna(), computed_gap)
        valid_directionality = gap.notna() | (forward.notna() & reverse.notna())

        null_score_col, null_type_col, shuffled_col = extract_null_fields(df)
        null_score = numeric_col(df, null_score_col)
        shuffled_score = numeric_col(df, shuffled_col)
        valid_null = null_score.notna() | shuffled_score.notna()

        fam_score_col = find_column(df, [
            r"family.*score", r"family.*stability", r"stability.*score", r"family.*gap",
            r"spread", r"family.*mean", r"family.*fraction"
        ])
        family_score = numeric_col(df, fam_score_col)
        valid_family = family.isin(FAMILY_VALUES) | family_score.notna()

        fwd_lowk_col, rev_lowk_col, op_diag_col = extract_lowk_fields(df)
        fwd_lowk = numeric_col(df, fwd_lowk_col)
        rev_lowk = numeric_col(df, rev_lowk_col)
        op_diag = numeric_col(df, op_diag_col)
        valid_lowk = fwd_lowk.notna() & rev_lowk.notna()
        lowk_forward_only = fwd_lowk.notna() & rev_lowk.isna()

        ent_slope_col, state_space_col, inherited_col, ent_agree_col = extract_entropy_fields(df)
        ent_slope = numeric_col(df, ent_slope_col)
        state_space = as_string_series(df, state_space_col, default="")
        inherited_source = as_string_series(df, inherited_col, default="")
        ent_agreement = numeric_col(df, ent_agree_col)
        has_entropy = ent_slope.notna() | state_space.str.strip().ne("") | ent_agreement.notna()
        has_declared_or_inherited_state = state_space.str.strip().ne("") | inherited_source.str.strip().ne("")
        valid_entropy = has_entropy & has_declared_or_inherited_state

        rev_fields = extract_reversibility_fields(df)
        reverse_compat = numeric_col(df, rev_fields["reverse_compatibility"])
        reverse_null = numeric_col(df, rev_fields["reverse_null_equivalence"])
        inverse_recovery = numeric_col(df, rev_fields["inverse_recovery"])
        adjoint_recovery = numeric_col(df, rev_fields["adjoint_recovery"])
        reversible_sector = as_string_series(df, rev_fields["reversible_sector"], default="")
        valid_reversibility = reverse_compat.notna() | reverse_null.notna() | inverse_recovery.notna() | adjoint_recovery.notna() | reversible_sector.str.strip().ne("")

        semantic_tracker = pd.Series([source_is_semantic_tracker(table.path, table.source_channel)] * len(df), index=df.index)
        excluded = df.apply(row_excluded_unsafe, axis=1)

        out = pd.DataFrame({
            "candidate_id": candidate_id,
            "source_file": source_file,
            "source_name": source_name,
            "source_stage": table.source_stage,
            "source_channel": table.source_channel,
            "source_row": np.arange(len(df)),
            "family": family,
            "tier_original": tier,
            "tier1_original_or_admissible": tier1,
            "valid_directionality_witness": valid_directionality & ~excluded & ~semantic_tracker,
            "valid_null_witness": valid_null & ~excluded & ~semantic_tracker,
            "valid_family_witness": valid_family & ~excluded & ~semantic_tracker,
            "valid_lowk_operator_witness": valid_lowk & ~excluded & ~semantic_tracker,
            "lowk_forward_only_reverse_missing": lowk_forward_only,
            "valid_entropy_state_space_witness": valid_entropy & ~excluded & ~semantic_tracker,
            "entropy_present_but_state_space_missing": has_entropy & ~has_declared_or_inherited_state,
            "valid_reversibility_witness": valid_reversibility & ~excluded & ~semantic_tracker,
            "semantic_tracker_only": semantic_tracker,
            "excluded_unsafe": excluded,
            # Numeric fields used downstream.
            "forward_score": forward,
            "reverse_score": reverse,
            "gap_original": gap,
            "null_survival_score": null_score.where(null_score.notna(), shuffled_score),
            "null_type": as_string_series(df, null_type_col, default="UNKNOWN"),
            "family_score": family_score,
            "forward_lowk_retention": fwd_lowk,
            "reverse_lowk_retention": rev_lowk,
            "operator_diagnostic": op_diag,
            "entropy_like_slope": ent_slope,
            "entropy_state_space": state_space,
            "entropy_inherited_source": inherited_source,
            "entropy_operator_agreement": ent_agreement,
            "reverse_compatibility": reverse_compat,
            "reverse_null_equivalence": reverse_null,
            "inverse_recovery": inverse_recovery,
            "adjoint_recovery": adjoint_recovery,
            "reversible_sector_text": reversible_sector,
        })
        rows.append(out)

    if not rows:
        return pd.DataFrame(columns=[
            "candidate_id", "source_file", "source_name", "source_stage", "source_channel", "source_row",
            "family", "tier_original", "tier1_original_or_admissible",
            "valid_directionality_witness", "valid_null_witness", "valid_family_witness",
            "valid_lowk_operator_witness", "valid_entropy_state_space_witness",
            "valid_reversibility_witness", "semantic_tracker_only", "excluded_unsafe"
        ])

    return pd.concat(rows, ignore_index=True)


# ---------------------------------------------------------------------------
# Repairs and audits
# ---------------------------------------------------------------------------


def sign_convention_status(direction_df: pd.DataFrame) -> Dict[str, Any]:
    if direction_df.empty or "gap_original" not in direction_df:
        return {
            "status": "NOT_TESTED_DIRECTIONALITY_FIELDS_MISSING",
            "valid_n": 0,
            "positive_gap_fraction_forward_sign": np.nan,
            "positive_gap_fraction_reverse_sign": np.nan,
            "mean_gap_forward_sign": np.nan,
            "median_gap_forward_sign": np.nan,
            "mean_gap_reverse_sign": np.nan,
            "median_gap_reverse_sign": np.nan,
        }
    gaps = pd.to_numeric(direction_df["gap_original"], errors="coerce").dropna()
    if gaps.empty:
        return {
            "status": "NOT_TESTED_DIRECTIONALITY_FIELDS_MISSING",
            "valid_n": 0,
            "positive_gap_fraction_forward_sign": np.nan,
            "positive_gap_fraction_reverse_sign": np.nan,
            "mean_gap_forward_sign": np.nan,
            "median_gap_forward_sign": np.nan,
            "mean_gap_reverse_sign": np.nan,
            "median_gap_reverse_sign": np.nan,
        }
    pos_forward = float((gaps > 0).mean())
    pos_reverse = float((-gaps > 0).mean())
    mean_f = float(gaps.mean())
    median_f = float(gaps.median())
    mean_r = float((-gaps).mean())
    median_r = float((-gaps).median())

    if pos_forward >= 0.60 and mean_f > 0:
        status = "SIGN_CONVENTION_STABLE_FORWARD_POSITIVE"
    elif pos_reverse >= 0.60 and mean_f < 0:
        status = "SIGN_CONVENTION_INVERTED_POSSIBLE"
    else:
        status = "SIGN_CONVENTION_MIXED_REVIEW"

    return {
        "status": status,
        "valid_n": int(len(gaps)),
        "positive_gap_fraction_forward_sign": pos_forward,
        "positive_gap_fraction_reverse_sign": pos_reverse,
        "mean_gap_forward_sign": mean_f,
        "median_gap_forward_sign": median_f,
        "mean_gap_reverse_sign": mean_r,
        "median_gap_reverse_sign": median_r,
    }


def build_directionality_repaired_table(witness_df: pd.DataFrame) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    if witness_df.empty:
        return pd.DataFrame(), sign_convention_status(pd.DataFrame())

    df = witness_df[witness_df.get("valid_directionality_witness", False)].copy()
    if df.empty:
        return df, sign_convention_status(df)

    audit = sign_convention_status(df)
    status = audit["status"]
    if status == "SIGN_CONVENTION_STABLE_FORWARD_POSITIVE":
        df["gap_sign_audited"] = df["gap_original"]
    elif status == "SIGN_CONVENTION_INVERTED_POSSIBLE":
        # Provide reverse-signed comparison, but do not automatically upgrade
        # final scientific verdict solely from this inversion.
        df["gap_sign_audited"] = -pd.to_numeric(df["gap_original"], errors="coerce")
    else:
        df["gap_sign_audited"] = pd.to_numeric(df["gap_original"], errors="coerce")

    df["gap_forward_minus_reverse"] = pd.to_numeric(df["gap_original"], errors="coerce")
    df["gap_reverse_minus_forward"] = -pd.to_numeric(df["gap_original"], errors="coerce")
    df["positive_gap_forward_sign"] = df["gap_forward_minus_reverse"] > 0
    df["positive_gap_reverse_sign"] = df["gap_reverse_minus_forward"] > 0
    df["positive_gap"] = df["gap_sign_audited"] > 0
    df["sign_convention_status"] = status

    keep = [
        "candidate_id", "source_file", "source_name", "source_row", "family",
        "forward_score", "reverse_score", "gap_original", "gap_forward_minus_reverse",
        "gap_reverse_minus_forward", "gap_sign_audited", "positive_gap",
        "positive_gap_forward_sign", "positive_gap_reverse_sign", "sign_convention_status"
    ]
    return df[[c for c in keep if c in df.columns]], audit


def build_null_survival_table(witness_df: pd.DataFrame) -> pd.DataFrame:
    if witness_df.empty:
        return pd.DataFrame()
    df = witness_df[witness_df.get("valid_null_witness", False)].copy()
    if df.empty:
        return df
    score = pd.to_numeric(df["null_survival_score"], errors="coerce")
    df["null_survival_valid"] = score.notna()
    df["null_survival_pass_0_50"] = score >= 0.50
    df["null_survival_pass_0_80"] = score >= 0.80
    df["valid_denominator_status"] = np.where(df["null_survival_valid"], "VALID_NULL_DENOMINATOR", "NOT_TESTED_FIELD_MISSING")
    keep = [
        "candidate_id", "source_file", "source_name", "source_row", "family",
        "null_survival_score", "null_type", "null_survival_pass_0_50", "null_survival_pass_0_80",
        "valid_denominator_status"
    ]
    return df[[c for c in keep if c in df.columns]]


def build_family_stability_table(witness_df: pd.DataFrame, direction_df: pd.DataFrame) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    if witness_df.empty:
        return pd.DataFrame(rows)

    base = witness_df[witness_df["family"].isin(FAMILY_VALUES)].copy()
    families_present = sorted(set(base["family"]).intersection(TRUE_FAMILIES))
    all_true_present = TRUE_FAMILIES.issubset(set(families_present))

    # Use directionality if available, otherwise family_score.
    if direction_df is not None and not direction_df.empty and "gap_original" in direction_df:
        d = direction_df.copy()
        d["gap_numeric"] = pd.to_numeric(d["gap_original"], errors="coerce")
        for fam, g in d.groupby("family"):
            if fam not in FAMILY_VALUES:
                continue
            gaps = g["gap_numeric"].dropna()
            rows.append({
                "family": fam,
                "true_family_present": fam in TRUE_FAMILIES,
                "all_true_families_present_in_run": all_true_present,
                "family_row_count": len(g),
                "family_valid_gap_count": len(gaps),
                "family_mean_gap": float(gaps.mean()) if len(gaps) else np.nan,
                "family_median_gap": float(gaps.median()) if len(gaps) else np.nan,
                "family_positive_gap_valid_fraction": float((gaps > 0).mean()) if len(gaps) else np.nan,
                "family_score_claim_status": "FAMILY_DIRECTIONALITY_COMPUTED" if len(gaps) else "NOT_TESTED_FAMILY_GAP_MISSING",
            })
    else:
        f = base.copy()
        f["family_score_numeric"] = pd.to_numeric(f.get("family_score", np.nan), errors="coerce")
        for fam, g in f.groupby("family"):
            vals = g["family_score_numeric"].dropna()
            rows.append({
                "family": fam,
                "true_family_present": fam in TRUE_FAMILIES,
                "all_true_families_present_in_run": all_true_present,
                "family_row_count": len(g),
                "family_valid_gap_count": 0,
                "family_mean_gap": np.nan,
                "family_median_gap": np.nan,
                "family_positive_gap_valid_fraction": np.nan,
                "family_score_mean": float(vals.mean()) if len(vals) else np.nan,
                "family_score_claim_status": "FAMILY_SCORE_ONLY" if len(vals) else "NOT_TESTED_FAMILY_FIELDS_MISSING",
            })

    out = pd.DataFrame(rows)
    if out.empty:
        return out

    if "family_mean_gap" in out.columns and out["family_mean_gap"].notna().any():
        spread = out["family_mean_gap"].max() - out["family_mean_gap"].min()
        out["family_spread"] = spread
        out["family_spread_small"] = spread <= max(0.10, abs(out["family_mean_gap"].mean()) * 0.25) if pd.notna(spread) else False
        out["family_directionality_positive"] = out["family_mean_gap"] > 0
    else:
        out["family_spread"] = np.nan
        out["family_spread_small"] = False
        out["family_directionality_positive"] = False

    return out


def build_lowk_audit_table(witness_df: pd.DataFrame) -> pd.DataFrame:
    if witness_df.empty:
        return pd.DataFrame()
    relevant = witness_df[
        witness_df["valid_lowk_operator_witness"] |
        witness_df["lowk_forward_only_reverse_missing"] |
        witness_df["forward_lowk_retention"].notna() |
        witness_df["operator_diagnostic"].notna()
    ].copy()
    if relevant.empty:
        return relevant

    fwd = pd.to_numeric(relevant["forward_lowk_retention"], errors="coerce")
    rev = pd.to_numeric(relevant["reverse_lowk_retention"], errors="coerce")
    relevant["lowk_reverse_evidence_status"] = np.select(
        [fwd.notna() & rev.notna(), fwd.notna() & rev.isna(), fwd.isna() & rev.notna()],
        ["PRESENT_FORWARD_AND_REVERSE", "NOT_TESTED_REVERSE_LOWK_MISSING", "REVERSE_PRESENT_FORWARD_MISSING"],
        default="NOT_TESTED_LOWK_FIELDS_MISSING"
    )
    relevant["lowk_gap_forward_minus_reverse"] = fwd - rev
    relevant["lowk_arrow_positive"] = relevant["lowk_gap_forward_minus_reverse"] > 0
    keep = [
        "candidate_id", "source_file", "source_name", "source_row", "family",
        "forward_lowk_retention", "reverse_lowk_retention", "operator_diagnostic",
        "lowk_reverse_evidence_status", "lowk_gap_forward_minus_reverse", "lowk_arrow_positive"
    ]
    return relevant[[c for c in keep if c in relevant.columns]]


def build_entropy_state_space_completion(witness_df: pd.DataFrame) -> pd.DataFrame:
    if witness_df.empty:
        return pd.DataFrame()
    relevant = witness_df[
        witness_df["entropy_like_slope"].notna() |
        witness_df["entropy_state_space"].astype(str).str.strip().ne("") |
        witness_df["entropy_inherited_source"].astype(str).str.strip().ne("") |
        witness_df["entropy_operator_agreement"].notna() |
        witness_df["entropy_present_but_state_space_missing"]
    ].copy()
    if relevant.empty:
        return relevant

    state = relevant["entropy_state_space"].astype(str).str.strip()
    source = relevant["entropy_inherited_source"].astype(str).str.strip()
    slope = pd.to_numeric(relevant["entropy_like_slope"], errors="coerce")

    def classify(row: pd.Series) -> str:
        ss = str(row.get("entropy_state_space", "")).strip()
        src = str(row.get("entropy_inherited_source", "")).strip()
        if ss and ss.lower() not in {"nan", "none", "missing", "ambiguous", "unknown"}:
            return "DECLARED"
        if src and src.lower() not in {"nan", "none", "missing", "ambiguous", "unknown"}:
            return "INHERITED_WITH_SOURCE"
        if str(ss).lower() in {"ambiguous", "unknown", "unclear"}:
            return "AMBIGUOUS"
        return "MISSING"

    relevant["entropy_state_space_status"] = relevant.apply(classify, axis=1)
    relevant["entropy_state_space_valid"] = relevant["entropy_state_space_status"].isin(["DECLARED", "INHERITED_WITH_SOURCE"])
    relevant["entropy_slope_valid"] = slope.notna()
    relevant["entropy_interpretation"] = np.where(
        relevant["entropy_state_space_valid"],
        "ENTROPY_LIKE_ORDERING_DIAGNOSTIC_INTERNAL_ONLY",
        "NOT_TESTED_STATE_SPACE_MISSING"
    )
    keep = [
        "candidate_id", "source_file", "source_name", "source_row", "family",
        "entropy_like_slope", "entropy_state_space", "entropy_inherited_source",
        "entropy_operator_agreement", "entropy_state_space_status",
        "entropy_state_space_valid", "entropy_slope_valid", "entropy_interpretation"
    ]
    return relevant[[c for c in keep if c in relevant.columns]]


def build_reversibility_sandbox_repaired(witness_df: pd.DataFrame) -> pd.DataFrame:
    if witness_df.empty:
        return pd.DataFrame()
    relevant = witness_df[
        witness_df["valid_reversibility_witness"] |
        witness_df["reverse_compatibility"].notna() |
        witness_df["reverse_null_equivalence"].notna() |
        witness_df["inverse_recovery"].notna() |
        witness_df["adjoint_recovery"].notna() |
        witness_df["reversible_sector_text"].astype(str).str.strip().ne("")
    ].copy()
    if relevant.empty:
        return relevant

    inv = pd.to_numeric(relevant["inverse_recovery"], errors="coerce")
    adj = pd.to_numeric(relevant["adjoint_recovery"], errors="coerce")
    revcomp = pd.to_numeric(relevant["reverse_compatibility"], errors="coerce")
    revnull = pd.to_numeric(relevant["reverse_null_equivalence"], errors="coerce")

    relevant["inverse_recovery_status"] = np.where(inv.notna(), "TESTED", "NOT_TESTED_INVERSE_MISSING")
    relevant["adjoint_recovery_status"] = np.where(adj.notna(), "TESTED", "NOT_TESTED_ADJOINT_MISSING")
    relevant["reverse_compatibility_status"] = np.where(revcomp.notna(), "TESTED", "NOT_TESTED_REVERSE_COMPATIBILITY_MISSING")
    relevant["reverse_null_equivalence_status"] = np.where(revnull.notna(), "TESTED", "NOT_TESTED_REVERSE_NULL_MISSING")

    # Interpretation tags remain cautious by design.
    def tag(row: pd.Series) -> str:
        txt = str(row.get("reversible_sector_text", "")).lower()
        if "reversible" in txt and "candidate" in txt:
            return "REVERSIBLE_SECTOR_CANDIDATE"
        if pd.notna(row.get("inverse_recovery")) or pd.notna(row.get("adjoint_recovery")):
            return "INVERSE_ADJOINT_TESTED_REVIEW"
        if pd.notna(row.get("reverse_compatibility")) or pd.notna(row.get("reverse_null_equivalence")):
            return "NO_STRUCTURED_REVERSIBLE_SECTOR_OR_REVIEW"
        return "NOT_TESTED_INVERSE_ADJOINT_MISSING"

    relevant["reversibility_interpretation_tag"] = relevant.apply(tag, axis=1)
    keep = [
        "candidate_id", "source_file", "source_name", "source_row", "family",
        "reverse_compatibility", "reverse_null_equivalence", "inverse_recovery", "adjoint_recovery",
        "reversible_sector_text", "reverse_compatibility_status", "reverse_null_equivalence_status",
        "inverse_recovery_status", "adjoint_recovery_status", "reversibility_interpretation_tag"
    ]
    return relevant[[c for c in keep if c in relevant.columns]]


# ---------------------------------------------------------------------------
# Denominator audit and verdicts
# ---------------------------------------------------------------------------


def count_all_tier1(witness_df: pd.DataFrame) -> int:
    if witness_df.empty or "tier1_original_or_admissible" not in witness_df:
        return 0
    return int(witness_df["tier1_original_or_admissible"].fillna(False).sum())


def add_denominator_metric(rows: List[Dict[str, Any]], metric: str, numerator: int,
                           all_candidates: int, all_tier1: int, valid_denominator: int,
                           notes: str = "") -> None:
    rows.append({
        "metric": metric,
        "numerator": int(numerator) if pd.notna(numerator) else 0,
        "all_candidate_denominator": int(all_candidates),
        "all_tier1_denominator": int(all_tier1),
        "valid_evidence_denominator": int(valid_denominator),
        "fraction_all_candidates": fraction(numerator, all_candidates),
        "all_tier1_fraction": fraction(numerator, all_tier1),
        "valid_evidence_fraction": fraction(numerator, valid_denominator),
        "interpretation_delta": fraction(numerator, valid_denominator) - fraction(numerator, all_tier1) if all_tier1 and valid_denominator else np.nan,
        "notes": notes,
    })


def build_valid_denominator_audit(witness_df: pd.DataFrame,
                                  direction_df: pd.DataFrame,
                                  null_df: pd.DataFrame,
                                  family_df: pd.DataFrame,
                                  lowk_df: pd.DataFrame,
                                  entropy_df: pd.DataFrame,
                                  reversibility_df: pd.DataFrame) -> pd.DataFrame:
    all_candidates = len(witness_df)
    all_tier1 = count_all_tier1(witness_df)
    rows: List[Dict[str, Any]] = []

    if direction_df is not None and not direction_df.empty:
        add_denominator_metric(
            rows,
            "directionality_positive_gap_forward_sign",
            int(direction_df["positive_gap_forward_sign"].sum()) if "positive_gap_forward_sign" in direction_df else 0,
            all_candidates,
            all_tier1,
            int(direction_df["gap_original"].notna().sum()) if "gap_original" in direction_df else len(direction_df),
            "Positive gap using forward-minus-reverse sign; missing rows are not counted as failures."
        )
        add_denominator_metric(
            rows,
            "directionality_positive_gap_reverse_sign",
            int(direction_df["positive_gap_reverse_sign"].sum()) if "positive_gap_reverse_sign" in direction_df else 0,
            all_candidates,
            all_tier1,
            int(direction_df["gap_original"].notna().sum()) if "gap_original" in direction_df else len(direction_df),
            "Positive gap under reverse-minus-forward sign for sign-convention audit."
        )
    else:
        add_denominator_metric(rows, "directionality_positive_gap_forward_sign", 0, all_candidates, all_tier1, 0, "NOT_TESTED_FIELD_MISSING")

    if null_df is not None and not null_df.empty:
        add_denominator_metric(
            rows,
            "strict_null_survival_pass_0_80",
            int(null_df["null_survival_pass_0_80"].sum()) if "null_survival_pass_0_80" in null_df else 0,
            all_candidates,
            all_tier1,
            int(null_df["null_survival_valid"].sum()) if "null_survival_valid" in null_df else len(null_df),
            "Threshold 0.80 used for claim-grade null survival; 0.50 also preserved in repaired table."
        )
    else:
        add_denominator_metric(rows, "strict_null_survival_pass_0_80", 0, all_candidates, all_tier1, 0, "NOT_TESTED_FIELD_MISSING")

    if family_df is not None and not family_df.empty:
        add_denominator_metric(
            rows,
            "true_family_presence_BARI_NUFIT_VALENCIA",
            3 if TRUE_FAMILIES.issubset(set(family_df["family"])) else len(set(family_df["family"]).intersection(TRUE_FAMILIES)),
            all_candidates,
            all_tier1,
            3,
            "Counts true family presence only; does not imply family-stable directionality."
        )
        if "family_directionality_positive" in family_df:
            valid_fam = family_df[family_df["family"].isin(TRUE_FAMILIES)]
            add_denominator_metric(
                rows,
                "family_directionality_positive_true_families",
                int(valid_fam["family_directionality_positive"].sum()),
                all_candidates,
                all_tier1,
                len(valid_fam),
                "Positive family mean gap among true families only."
            )
    else:
        add_denominator_metric(rows, "true_family_presence_BARI_NUFIT_VALENCIA", 0, all_candidates, all_tier1, 3, "NOT_TESTED_FAMILY_FIELDS_MISSING")

    if lowk_df is not None and not lowk_df.empty:
        pair = lowk_df["lowk_reverse_evidence_status"].eq("PRESENT_FORWARD_AND_REVERSE") if "lowk_reverse_evidence_status" in lowk_df else pd.Series([], dtype=bool)
        add_denominator_metric(
            rows,
            "lowk_forward_reverse_pair_available",
            int(pair.sum()),
            all_candidates,
            all_tier1,
            len(lowk_df),
            "Low-k arrow is not adjudicated unless forward and reverse/backward fields are present or reconstructed."
        )
        if "lowk_arrow_positive" in lowk_df:
            add_denominator_metric(
                rows,
                "lowk_arrow_positive_among_available_pairs",
                int(lowk_df.loc[pair, "lowk_arrow_positive"].sum()) if pair.any() else 0,
                all_candidates,
                all_tier1,
                int(pair.sum()),
                "Computed only where forward and reverse low-k are both available."
            )
    else:
        add_denominator_metric(rows, "lowk_forward_reverse_pair_available", 0, all_candidates, all_tier1, 0, "NOT_TESTED_LOWK_FIELDS_MISSING")

    if entropy_df is not None and not entropy_df.empty:
        valid_entropy = entropy_df["entropy_state_space_valid"] if "entropy_state_space_valid" in entropy_df else pd.Series([], dtype=bool)
        add_denominator_metric(
            rows,
            "entropy_state_space_declared_or_inherited",
            int(valid_entropy.sum()),
            all_candidates,
            all_tier1,
            len(entropy_df),
            "Entropy-like diagnostics require declared or inherited state space; missing state-space rows are not failures of directionality."
        )
    else:
        add_denominator_metric(rows, "entropy_state_space_declared_or_inherited", 0, all_candidates, all_tier1, 0, "NOT_TESTED_STATE_SPACE_MISSING")

    if reversibility_df is not None and not reversibility_df.empty:
        inv_tested = reversibility_df["inverse_recovery_status"].eq("TESTED") if "inverse_recovery_status" in reversibility_df else pd.Series([], dtype=bool)
        adj_tested = reversibility_df["adjoint_recovery_status"].eq("TESTED") if "adjoint_recovery_status" in reversibility_df else pd.Series([], dtype=bool)
        add_denominator_metric(
            rows,
            "inverse_or_adjoint_recovery_tested",
            int((inv_tested | adj_tested).sum()),
            all_candidates,
            all_tier1,
            len(reversibility_df),
            "If inverse/adjoint fields are absent, the sandbox branch is NOT_TESTED rather than FAILED."
        )
    else:
        add_denominator_metric(rows, "inverse_or_adjoint_recovery_tested", 0, all_candidates, all_tier1, 0, "NOT_TESTED_INVERSE_ADJOINT_MISSING")

    return pd.DataFrame(rows)


def verdict_directionality(direction_df: pd.DataFrame, sign_audit: Dict[str, Any]) -> Tuple[str, str]:
    if direction_df is None or direction_df.empty:
        return "NOT_TESTED_DIRECTIONALITY_FIELDS_MISSING", "No valid forward/reverse or gap fields were found."
    gaps = pd.to_numeric(direction_df["gap_original"], errors="coerce").dropna()
    if gaps.empty:
        return "NOT_TESTED_DIRECTIONALITY_FIELDS_MISSING", "Directionality table exists but contains no valid numeric gaps."
    pos_frac = float((gaps > 0).mean())
    mean_gap = float(gaps.mean())
    median_gap = float(gaps.median())
    sign_status = sign_audit.get("status", "SIGN_CONVENTION_UNKNOWN")

    if sign_status == "SIGN_CONVENTION_INVERTED_POSSIBLE":
        # Do not reward possible inversion as support; keep it review-grade.
        return "C_DIRECTIONALITY_SIGN_CONVENTION_REVIEW", f"Forward sign is negative/mixed; reverse sign may be intended. mean_gap={mean_gap:.6g}, pos_frac={pos_frac:.3f}."
    if pos_frac >= 0.80 and mean_gap > 0 and median_gap > 0:
        return "A_DIRECTIONALITY_SUPPORTED", f"Valid positive gap fraction={pos_frac:.3f}; mean and median gaps positive."
    if pos_frac >= 0.60 and mean_gap > 0:
        return "B_DIRECTIONALITY_PARTIAL", f"Valid positive gap fraction={pos_frac:.3f}; mean positive but not universal."
    if pos_frac >= 0.40 or mean_gap > 0 or median_gap > 0:
        return "C_DIRECTIONALITY_WEAK_OR_MIXED", f"Valid positive gap fraction={pos_frac:.3f}; mean={mean_gap:.6g}; median={median_gap:.6g}."
    return "D_DIRECTIONALITY_NOT_SUPPORTED", f"Valid positive gap fraction={pos_frac:.3f}; mean={mean_gap:.6g}; median={median_gap:.6g}."


def verdict_null(null_df: pd.DataFrame) -> Tuple[str, str]:
    if null_df is None or null_df.empty:
        return "NOT_TESTED_NULL_FIELDS_MISSING", "No valid null-survival fields were found."
    scores = pd.to_numeric(null_df["null_survival_score"], errors="coerce").dropna()
    if scores.empty:
        return "NOT_TESTED_NULL_FIELDS_MISSING", "Null table exists but has no numeric null-survival scores."
    pass80 = float((scores >= 0.80).mean())
    mean_score = float(scores.mean())
    if pass80 >= 0.80:
        return "A_NULL_SURVIVAL_SUPPORTED", f"Claim-grade null survival fraction={pass80:.3f}; mean score={mean_score:.3f}."
    if pass80 >= 0.60 or mean_score >= 0.70:
        return "B_NULL_SURVIVAL_PARTIAL", f"Null survival meaningful but not universal; pass80={pass80:.3f}, mean={mean_score:.3f}."
    if pass80 >= 0.30 or mean_score >= 0.50:
        return "C_NULL_SURVIVAL_HETEROGENEOUS", f"Null survival heterogeneous; pass80={pass80:.3f}, mean={mean_score:.3f}."
    return "D_NULL_SURVIVAL_NOT_SUPPORTED", f"Null survival weak; pass80={pass80:.3f}, mean={mean_score:.3f}."


def verdict_family(family_df: pd.DataFrame) -> Tuple[str, str]:
    if family_df is None or family_df.empty:
        return "NOT_TESTED_FAMILY_FIELDS_MISSING", "No family-conditioned evidence was found."
    present = set(family_df.get("family", pd.Series(dtype=str)).astype(str))
    true_present = TRUE_FAMILIES.issubset(present)
    if "family_directionality_positive" in family_df and family_df["family_directionality_positive"].notna().any():
        true_rows = family_df[family_df["family"].isin(TRUE_FAMILIES)]
        positive_count = int(true_rows["family_directionality_positive"].sum())
        spread_small = bool(true_rows["family_spread_small"].fillna(False).all()) if "family_spread_small" in true_rows else False
        if true_present and positive_count == 3 and spread_small:
            return "A_FAMILY_STABLE", "All true families present, positive, and small spread."
        if true_present and positive_count >= 2:
            return "B_FAMILY_PARTIAL", f"All true families present; {positive_count}/3 positive."
        if true_present:
            return "C_FAMILY_PRESENT_BUT_WEAK", f"True families present, but positive directionality in {positive_count}/3 families."
        return "D_FAMILY_UNSTABLE", "True family coverage incomplete or contradictory."
    if true_present:
        return "C_FAMILY_PRESENT_BUT_WEAK", "True families are present, but family-conditioned directionality is not adjudicated."
    return "NOT_TESTED_FAMILY_FIELDS_MISSING", "True family columns not sufficiently recovered."


def verdict_lowk(lowk_df: pd.DataFrame) -> Tuple[str, str]:
    if lowk_df is None or lowk_df.empty:
        return "NOT_TESTED_REVERSE_LOWK_MISSING", "No low-k/operator rows were found."
    if "lowk_reverse_evidence_status" not in lowk_df:
        return "NOT_TESTED_REVERSE_LOWK_MISSING", "Low-k rows found but reverse/backward evidence status cannot be determined."
    pairs = lowk_df[lowk_df["lowk_reverse_evidence_status"].eq("PRESENT_FORWARD_AND_REVERSE")]
    if pairs.empty:
        return "NOT_TESTED_REVERSE_LOWK_MISSING", "Forward low-k may exist, but reverse/backward low-k evidence is missing or unreconstructed."
    pos = float(pairs.get("lowk_arrow_positive", pd.Series(dtype=bool)).mean())
    gaps = pd.to_numeric(pairs.get("lowk_gap_forward_minus_reverse", pd.Series(dtype=float)), errors="coerce").dropna()
    mean_gap = float(gaps.mean()) if len(gaps) else np.nan
    if pos >= 0.80 and pd.notna(mean_gap) and mean_gap > 0:
        return "A_LOWK_OPERATOR_ARROW_SUPPORTED", f"Low-k forward/backward arrow supported among available pairs; pos={pos:.3f}."
    if pos >= 0.60:
        return "B_LOWK_OPERATOR_ARROW_PARTIAL", f"Low-k arrow partial; pos={pos:.3f}."
    if pos >= 0.40 or (pd.notna(mean_gap) and mean_gap > 0):
        return "C_LOWK_OPERATOR_COUPLING_ONLY", f"Low-k coupling exists but arrow is mixed; pos={pos:.3f}, mean_gap={mean_gap}."
    return "D_LOWK_OPERATOR_ARROW_NOT_SUPPORTED", f"Low-k arrow not supported among valid pairs; pos={pos:.3f}."


def verdict_entropy(entropy_df: pd.DataFrame) -> Tuple[str, str]:
    if entropy_df is None or entropy_df.empty:
        return "NOT_TESTED_STATE_SPACE_MISSING", "No entropy-like rows were found."
    if "entropy_state_space_valid" not in entropy_df:
        return "NOT_TESTED_STATE_SPACE_MISSING", "Entropy rows found but state-space status could not be classified."
    valid_frac = float(entropy_df["entropy_state_space_valid"].mean()) if len(entropy_df) else 0.0
    slopes = pd.to_numeric(entropy_df.get("entropy_like_slope", pd.Series(dtype=float)), errors="coerce").dropna()
    has_slope = len(slopes) > 0
    if valid_frac >= 0.90 and has_slope:
        return "A_ENTROPY_LIKE_ORDERING_SUPPORTED_INTERNAL", f"Entropy state spaces declared/inherited for {valid_frac:.3f} of entropy rows; internal diagnostic only."
    if valid_frac >= 0.60 and has_slope:
        return "B_ENTROPY_LIKE_ORDERING_PARTIAL", f"Entropy state-space coverage partial ({valid_frac:.3f}); diagnostic only."
    if valid_frac > 0:
        return "C_ENTROPY_DIAGNOSTIC_ONLY", f"Entropy rows exist but state-space coverage is incomplete ({valid_frac:.3f})."
    return "NOT_TESTED_STATE_SPACE_MISSING", "Entropy-like rows lack declared or inherited state spaces."


def verdict_reversibility(rev_df: pd.DataFrame) -> Tuple[str, str]:
    if rev_df is None or rev_df.empty:
        return "NOT_TESTED_INVERSE_ADJOINT_MISSING", "No reversibility-sandbox rows were found."
    tags = set(rev_df.get("reversibility_interpretation_tag", pd.Series(dtype=str)).astype(str))
    if "REVERSIBLE_SECTOR_CANDIDATE" in tags:
        return "REVERSIBLE_SECTOR_CANDIDATE", "A structured reversible-sector candidate was flagged; review required."
    tested = False
    for col in ["inverse_recovery_status", "adjoint_recovery_status", "reverse_compatibility_status", "reverse_null_equivalence_status"]:
        if col in rev_df and rev_df[col].eq("TESTED").any():
            tested = True
    if tested:
        return "NO_STRUCTURED_REVERSIBLE_SECTOR", "Reversibility sandbox has tested rows but no structured reversible sector was isolated."
    return "NOT_TESTED_INVERSE_ADJOINT_MISSING", "Reversibility table exists, but inverse/adjoint/reverse-null fields are missing."


def final_verdict(layered: pd.DataFrame, input_audit: pd.DataFrame) -> Tuple[str, str]:
    loaded_files = int(input_audit["load_status"].astype(str).str.startswith("LOADED").sum()) if not input_audit.empty else 0
    if loaded_files == 0:
        return "E_NOT_ADJUDICABLE_INPUTS_INSUFFICIENT", "No required Stage-7B/Stage-7C evidence tables were loaded."

    verdict_map = dict(zip(layered["layer"], layered["verdict"])) if not layered.empty else {}
    d = verdict_map.get("directionality")
    n = verdict_map.get("null_survival")
    f = verdict_map.get("family_stability")
    l = verdict_map.get("lowk_operator")
    e = verdict_map.get("entropy_state_space")

    def starts(v: Optional[str], prefix: str) -> bool:
        return isinstance(v, str) and v.startswith(prefix)

    if starts(d, "A_") and starts(n, "A_") and starts(f, "A_") and (starts(l, "A_") or starts(l, "B_")) and not str(e).startswith("NOT_TESTED"):
        return "A_INTERNAL_TIME_SURROGATE_SUPPORTED_AFTER_REPAIR", "All major internal witness channels are claim-grade after denominator repair. Physical semantics remain tracker-only."

    if (starts(d, "A_") or starts(d, "B_")) and (starts(n, "A_") or starts(n, "B_")) and (starts(f, "A_") or starts(f, "B_") or starts(f, "C_")):
        return "A_MINUS_OPERATOR_IRREVERSIBILITY_SUPPORTED_TIME_SURROGATE_PARTIAL", "Operator directionality/null survival are meaningful but not sufficient for physical-time claims."

    if (starts(d, "B_") or starts(d, "C_")) and (starts(n, "B_") or starts(n, "C_") or starts(n, "A_")):
        return "B_OPERATOR_IRREVERSIBILITY_SUPPORTED_TIME_SURROGATE_PARTIAL" if starts(d, "B_") else "C_REPAIR_REQUIRED_DIRECTIONALITY_WEAK_OR_MIXED", "Denominator repair produces nonzero/internal evidence but directionality is not cleanly claim-grade."

    if starts(d, "D_") and (starts(n, "D_") or str(n).startswith("NOT_TESTED")):
        return "D_NOT_SUPPORTED_AFTER_REPAIRED_WITNESS_FILTER", "After valid-row denominators and sign audit, directionality/null evidence remains weak or negative."

    if str(d).startswith("NOT_TESTED"):
        return "E_NOT_ADJUDICABLE_INPUTS_INSUFFICIENT", "Directionality fields are missing; Stage-7C-v1a cannot adjudicate the target claim."

    return "C_REPAIR_REQUIRED_DIRECTIONALITY_WEAK_OR_MIXED", "Layered evidence remains mixed or incomplete after repair."


def build_layered_verdict_table(direction_df: pd.DataFrame, null_df: pd.DataFrame,
                                family_df: pd.DataFrame, lowk_df: pd.DataFrame,
                                entropy_df: pd.DataFrame, rev_df: pd.DataFrame,
                                sign_audit: Dict[str, Any]) -> pd.DataFrame:
    entries = []
    for layer, func, args in [
        ("directionality", verdict_directionality, (direction_df, sign_audit)),
        ("null_survival", verdict_null, (null_df,)),
        ("family_stability", verdict_family, (family_df,)),
        ("lowk_operator", verdict_lowk, (lowk_df,)),
        ("entropy_state_space", verdict_entropy, (entropy_df,)),
        ("reversibility_sandbox", verdict_reversibility, (rev_df,)),
    ]:
        verdict, rationale = func(*args)
        entries.append({"layer": layer, "verdict": verdict, "rationale": rationale})

    entries.append({
        "layer": "physical_semantics_bridge",
        "verdict": "TRACKER_ONLY_NO_VERDICT_UPGRADE",
        "rationale": "Effective interval, cosmic-age, Friedmann-style, and physical-semantics bridge material is preserved only as tracker material."
    })
    return pd.DataFrame(entries)


# ---------------------------------------------------------------------------
# Output helpers
# ---------------------------------------------------------------------------


def write_guardrails(out_dir: Path) -> None:
    text = f"""# {STAGE_NAME} Claim Guardrails

Generated: {now_iso()}

## Allowed internal language

"""
    for term in ALLOWED_INTERNAL_TERMS:
        text += f"- {term}\n"
    text += "\n## Forbidden claims\n\n"
    for claim in FORBIDDEN_CLAIMS:
        text += f"- {claim}\n"
    text += """
## Friedmann / GR-adjacent guardrail

The no-Friedmann-derivation guardrail remains active in Stage-7C-v1a.
This script may preserve future relaxation criteria, but it must not use
PDG, Planck, LambdaCDM, Friedmann, GR, or cosmological constants to fit,
select, or upgrade internal QEG witness verdicts.

Possible future tag, not a Stage-7C-v1a claim unless separately earned:
`FRIEDMANN_GUARDRAIL_ELIGIBLE_FOR_RELAXATION`.

## Entropy language

Entropy rows are treated as entropy-like statistical ordering diagnostics.
They are not thermodynamic entropy-production claims unless a declared state
space, dynamics, conservation structure, and physical interpretation are
established in a later stage.
"""
    (out_dir / "stage7C_v1a_claim_guardrails.md").write_text(text, encoding="utf-8")


def write_repair_notes(out_dir: Path, summary: Dict[str, Any]) -> None:
    text = f"""
{STAGE_NAME} REPAIR NOTES
Generated: {now_iso()}

What Stage-7C-v1 got right
--------------------------
- It enforced the main physical-claim guardrails.
- It kept the physical-semantics bridge as tracker material.
- It made the reversibility sandbox visible as a useful control branch.
- It found broad Stage-7B/Stage-7C inputs rather than failing from total input absence.

What Stage-7C-v1 got wrong or left unresolved
---------------------------------------------
- It used an overbroad Tier-1 admissible witness bucket.
- It allowed all Tier-1 rows to become denominators for evidence channels
  that existed only on smaller valid subsets.
- It risked counting missing/inapplicable rows as evidence failures.
- It did not fully audit sign convention for forward/reverse gaps.
- It did not complete entropy state-space declaration/inheritance.
- It could not claim low-k arrow evidence when reverse/backward low-k was absent.
- It could not claim inverse/adjoint recovery if inverse/adjoint fields were empty.

What v1a repaired
-----------------
- Channel-specific witness classes were built.
- Valid evidence denominators were separated from all-candidate and all-Tier-1 denominators.
- Directionality sign convention was audited with both forward-minus-reverse and reverse-minus-forward signs.
- Null survival, family stability, low-k/operator, entropy, and reversibility tables were repaired separately.
- Physical semantics remained tracker-only and cannot upgrade the verdict.

Final implementation verdict
----------------------------
{summary.get('final_stage7C_v1a_verdict', 'UNKNOWN')}

Scientific review verdict
-------------------------
{summary.get('scientific_review_verdict', 'UNKNOWN')}

Remaining unresolved items
--------------------------
- Any NOT_TESTED layer in the layered verdict table requires upstream field reconstruction.
- A D verdict is only final if valid denominators, sign convention, and channel-specific witnesses were actually available.
- A future Friedmann/GR bridge remains prohibited until an internal time/evolution surrogate is much stronger and null-resistant.
""".strip() + "\n"
    (out_dir / "stage7C_v1a_repair_notes.txt").write_text(text, encoding="utf-8")


def make_figures(out_dir: Path, denom_df: pd.DataFrame, direction_df: pd.DataFrame,
                 entropy_df: pd.DataFrame, lowk_df: pd.DataFrame,
                 layered_df: pd.DataFrame) -> List[str]:
    made: List[str] = []
    if not HAS_MATPLOTLIB:
        return made

    fig_dir = ensure_dir(out_dir / "figures")

    try:
        if denom_df is not None and not denom_df.empty:
            plot_df = denom_df.copy()
            x = np.arange(len(plot_df))
            plt.figure(figsize=(max(8, len(plot_df) * 0.7), 5))
            plt.bar(x - 0.2, plot_df["all_tier1_fraction"].fillna(0), width=0.4, label="all Tier-1 fraction")
            plt.bar(x + 0.2, plot_df["valid_evidence_fraction"].fillna(0), width=0.4, label="valid evidence fraction")
            plt.xticks(x, plot_df["metric"], rotation=75, ha="right")
            plt.ylabel("fraction")
            plt.title("Stage-7C-v1a valid vs all-denominator audit")
            plt.legend()
            plt.tight_layout()
            p = fig_dir / "stage7C_v1a_valid_vs_all_denominator_comparison.png"
            plt.savefig(p, dpi=160)
            plt.close()
            made.append(str(p))
    except Exception:
        plt.close()

    try:
        if direction_df is not None and not direction_df.empty and "gap_original" in direction_df:
            gaps = pd.to_numeric(direction_df["gap_original"], errors="coerce").dropna().sort_values().reset_index(drop=True)
            if len(gaps):
                plt.figure(figsize=(8, 5))
                plt.plot(np.arange(len(gaps)), gaps.values, marker="o", linewidth=1)
                plt.axhline(0, linestyle="--", linewidth=1)
                plt.xlabel("valid directionality witness (sorted)")
                plt.ylabel("forward - reverse gap")
                plt.title("Stage-7C-v1a repaired directionality gaps")
                plt.tight_layout()
                p = fig_dir / "stage7C_v1a_repaired_directionality_gap_plot.png"
                plt.savefig(p, dpi=160)
                plt.close()
                made.append(str(p))
    except Exception:
        plt.close()

    try:
        if entropy_df is not None and not entropy_df.empty and "entropy_state_space_status" in entropy_df:
            counts = entropy_df["entropy_state_space_status"].value_counts()
            plt.figure(figsize=(7, 5))
            plt.bar(np.arange(len(counts)), counts.values)
            plt.xticks(np.arange(len(counts)), counts.index, rotation=45, ha="right")
            plt.ylabel("row count")
            plt.title("Entropy state-space declaration status")
            plt.tight_layout()
            p = fig_dir / "stage7C_v1a_entropy_state_space_declaration_plot.png"
            plt.savefig(p, dpi=160)
            plt.close()
            made.append(str(p))
    except Exception:
        plt.close()

    try:
        if lowk_df is not None and not lowk_df.empty and "lowk_reverse_evidence_status" in lowk_df:
            counts = lowk_df["lowk_reverse_evidence_status"].value_counts()
            plt.figure(figsize=(7, 5))
            plt.bar(np.arange(len(counts)), counts.values)
            plt.xticks(np.arange(len(counts)), counts.index, rotation=45, ha="right")
            plt.ylabel("row count")
            plt.title("Low-k forward/backward availability")
            plt.tight_layout()
            p = fig_dir / "stage7C_v1a_lowk_availability_plot.png"
            plt.savefig(p, dpi=160)
            plt.close()
            made.append(str(p))
    except Exception:
        plt.close()

    try:
        if layered_df is not None and not layered_df.empty:
            # Encode verdict tiers for a simple visual summary.
            def score(v: str) -> int:
                if str(v).startswith("A"):
                    return 4
                if str(v).startswith("B"):
                    return 3
                if str(v).startswith("C"):
                    return 2
                if str(v).startswith("D"):
                    return 1
                return 0
            vals = layered_df["verdict"].map(score)
            plt.figure(figsize=(8, 5))
            plt.bar(np.arange(len(layered_df)), vals.values)
            plt.xticks(np.arange(len(layered_df)), layered_df["layer"], rotation=45, ha="right")
            plt.yticks([0, 1, 2, 3, 4], ["NOT_TESTED", "D", "C", "B", "A"])
            plt.title("Stage-7C-v1a layered verdict plot")
            plt.tight_layout()
            p = fig_dir / "stage7C_v1a_layered_verdict_plot.png"
            plt.savefig(p, dpi=160)
            plt.close()
            made.append(str(p))
    except Exception:
        plt.close()

    return made


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Stage-7C-v1a witness-class repair script")
    parser.add_argument("--root", type=str, default=None, help="Project root; inferred if omitted")
    parser.add_argument("--no-figures", action="store_true", help="Skip optional PNG figures")
    args = parser.parse_args(argv)

    root = infer_project_root(args.root)
    out_dir = ensure_dir(root / "metric_stage_7C_outputs" / OUTPUT_SUBDIR)

    print(f"[{STAGE_NAME}] project root: {root}")
    print(f"[{STAGE_NAME}] output dir  : {out_dir}")

    loaded, input_audit = load_all_inputs(root)
    input_audit.to_csv(out_dir / "stage7C_v1a_input_presence_audit.csv", index=False)

    witness_df = build_witness_class_table(loaded)
    witness_df.to_csv(out_dir / "stage7C_v1a_witness_class_table.csv", index=False)

    direction_df, sign_audit = build_directionality_repaired_table(witness_df)
    direction_df.to_csv(out_dir / "stage7C_v1a_directionality_repaired_table.csv", index=False)

    null_df = build_null_survival_table(witness_df)
    null_df.to_csv(out_dir / "stage7C_v1a_null_survival_repaired_table.csv", index=False)

    family_df = build_family_stability_table(witness_df, direction_df)
    family_df.to_csv(out_dir / "stage7C_v1a_family_stability_repaired_table.csv", index=False)

    lowk_df = build_lowk_audit_table(witness_df)
    lowk_df.to_csv(out_dir / "stage7C_v1a_lowk_reconstruction_audit.csv", index=False)

    entropy_df = build_entropy_state_space_completion(witness_df)
    entropy_df.to_csv(out_dir / "stage7C_v1a_entropy_state_space_completion.csv", index=False)

    rev_df = build_reversibility_sandbox_repaired(witness_df)
    rev_df.to_csv(out_dir / "stage7C_v1a_reversibility_sandbox_repaired.csv", index=False)

    denom_df = build_valid_denominator_audit(
        witness_df=witness_df,
        direction_df=direction_df,
        null_df=null_df,
        family_df=family_df,
        lowk_df=lowk_df,
        entropy_df=entropy_df,
        reversibility_df=rev_df,
    )
    denom_df.to_csv(out_dir / "stage7C_v1a_valid_denominator_audit.csv", index=False)

    layered_df = build_layered_verdict_table(direction_df, null_df, family_df, lowk_df, entropy_df, rev_df, sign_audit)
    final, final_rationale = final_verdict(layered_df, input_audit)
    layered_df = pd.concat([
        layered_df,
        pd.DataFrame([{
            "layer": "final_stage7C_v1a",
            "verdict": final,
            "rationale": final_rationale,
        }])
    ], ignore_index=True)
    layered_df.to_csv(out_dir / "stage7C_v1a_layered_verdict_table.csv", index=False)

    figures = [] if args.no_figures else make_figures(out_dir, denom_df, direction_df, entropy_df, lowk_df, layered_df)

    # Scientific review verdict is intentionally no stronger than the final implementation verdict.
    if final.startswith("A_INTERNAL"):
        scientific_review = "A_INTERNAL_REVIEW_ONLY_NO_PHYSICAL_TIME_CLAIM"
    elif final.startswith("A_MINUS") or final.startswith("B_"):
        scientific_review = "B_OR_A_MINUS_INTERNAL_OPERATOR_TIME_SURROGATE_PARTIAL_TRACKER_ONLY"
    elif final.startswith("C_"):
        scientific_review = "C_REPAIR_REQUIRED_NOT_FINAL_SCIENTIFIC_FAILURE"
    elif final.startswith("D_"):
        scientific_review = "D_NOT_SUPPORTED_AFTER_REPAIRED_WITNESS_FILTER"
    else:
        scientific_review = "E_NOT_ADJUDICABLE_INPUTS_INSUFFICIENT"

    counts_by_witness_class = {
        "all_candidate_rows": int(len(witness_df)),
        "all_tier1_original_or_admissible": int(count_all_tier1(witness_df)),
        "valid_directionality_witnesses": int(witness_df.get("valid_directionality_witness", pd.Series(dtype=bool)).sum()) if not witness_df.empty else 0,
        "valid_null_witnesses": int(witness_df.get("valid_null_witness", pd.Series(dtype=bool)).sum()) if not witness_df.empty else 0,
        "valid_family_witnesses": int(witness_df.get("valid_family_witness", pd.Series(dtype=bool)).sum()) if not witness_df.empty else 0,
        "valid_lowk_operator_witnesses": int(witness_df.get("valid_lowk_operator_witness", pd.Series(dtype=bool)).sum()) if not witness_df.empty else 0,
        "valid_entropy_state_space_witnesses": int(witness_df.get("valid_entropy_state_space_witness", pd.Series(dtype=bool)).sum()) if not witness_df.empty else 0,
        "valid_reversibility_witnesses": int(witness_df.get("valid_reversibility_witness", pd.Series(dtype=bool)).sum()) if not witness_df.empty else 0,
        "semantic_tracker_only_rows": int(witness_df.get("semantic_tracker_only", pd.Series(dtype=bool)).sum()) if not witness_df.empty else 0,
        "excluded_unsafe_rows": int(witness_df.get("excluded_unsafe", pd.Series(dtype=bool)).sum()) if not witness_df.empty else 0,
    }

    valid_denominators = {
        row["metric"]: {
            "numerator": row["numerator"],
            "all_candidate_denominator": row["all_candidate_denominator"],
            "all_tier1_denominator": row["all_tier1_denominator"],
            "valid_evidence_denominator": row["valid_evidence_denominator"],
            "all_tier1_fraction": row["all_tier1_fraction"],
            "valid_evidence_fraction": row["valid_evidence_fraction"],
            "interpretation_delta": row["interpretation_delta"],
        }
        for _, row in denom_df.iterrows()
    } if not denom_df.empty else {}

    summary: Dict[str, Any] = {
        "project": "Quantum-Emergent Gravity",
        "stage": STAGE_NAME,
        "script": SCRIPT_NAME,
        "generated_at": now_iso(),
        "project_root": str(root),
        "output_directory": str(out_dir),
        "implementation_verdict": final,
        "final_stage7C_v1a_verdict": final,
        "final_rationale": final_rationale,
        "scientific_review_verdict": scientific_review,
        "claim_guardrail_status": "PHYSICAL_SEMANTICS_TRACKER_ONLY_NO_PHYSICAL_CLAIMS",
        "loaded_file_count": int(input_audit["load_status"].astype(str).str.startswith("LOADED").sum()) if not input_audit.empty else 0,
        "input_presence_audit_file": "stage7C_v1a_input_presence_audit.csv",
        "counts_by_witness_class": counts_by_witness_class,
        "sign_convention_audit": sign_audit,
        "valid_denominators_by_metric": valid_denominators,
        "layered_verdicts": layered_df.to_dict(orient="records") if not layered_df.empty else [],
        "figures_generated": figures,
        "outputs": {
            "summary": "stage7C_v1a_summary.json",
            "witness_class_table": "stage7C_v1a_witness_class_table.csv",
            "valid_denominator_audit": "stage7C_v1a_valid_denominator_audit.csv",
            "directionality_repaired_table": "stage7C_v1a_directionality_repaired_table.csv",
            "null_survival_repaired_table": "stage7C_v1a_null_survival_repaired_table.csv",
            "family_stability_repaired_table": "stage7C_v1a_family_stability_repaired_table.csv",
            "lowk_reconstruction_audit": "stage7C_v1a_lowk_reconstruction_audit.csv",
            "entropy_state_space_completion": "stage7C_v1a_entropy_state_space_completion.csv",
            "reversibility_sandbox_repaired": "stage7C_v1a_reversibility_sandbox_repaired.csv",
            "layered_verdict_table": "stage7C_v1a_layered_verdict_table.csv",
            "claim_guardrails": "stage7C_v1a_claim_guardrails.md",
            "repair_notes": "stage7C_v1a_repair_notes.txt",
        },
        "forbidden_claims_preserved": FORBIDDEN_CLAIMS,
        "allowed_internal_terms": ALLOWED_INTERNAL_TERMS,
    }

    write_guardrails(out_dir)
    write_repair_notes(out_dir, summary)
    write_json(out_dir / "stage7C_v1a_summary.json", summary)

    # Also write a compact console summary for Spyder.
    print("\n=== Stage-7C-v1a summary ===")
    print(f"Loaded files: {summary['loaded_file_count']}")
    print(f"Witness rows: {counts_by_witness_class['all_candidate_rows']}")
    print(f"Directionality valid rows: {counts_by_witness_class['valid_directionality_witnesses']}")
    print(f"Sign audit: {sign_audit.get('status')}")
    print(f"Final verdict: {final}")
    print(f"Scientific review: {scientific_review}")
    print(f"Output directory: {out_dir}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
