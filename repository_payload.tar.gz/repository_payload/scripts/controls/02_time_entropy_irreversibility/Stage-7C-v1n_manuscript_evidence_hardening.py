#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
============================================================
Quantum-Emergent Gravity (QEG)
Stage-7C-v1n: Manuscript Evidence and Provenance Hardening
============================================================
Author: Arturo Ortiz-Tapia / ChatGPT assistant
Build date: 2026-06-02

Purpose
-------
Stage-7C-v1m produced an A-level internal synthesis:
  - prior time-surrogate evidence audited,
  - entropy preserved as an independent channel,
  - low-k witnesses recomputed under a contemporary Stage-7C identity,
  - old scripts treated as source material rather than blindly rerun.

Stage-7C-v1n is NOT a new physics-claim stage.  It is a paper-hardening
stage for Physica D / GitHub / Zenodo transparency.

Primary jobs
------------
1. Trace p<0.05 low-k survivors that were labeled UNKNOWN in v1m.
2. Distinguish genuinely independent witnesses from duplicated/derived variants.
3. Produce a manuscript-facing evidence table with one row per evidence channel.
4. Produce a reviewer-risk table and explicit claim/guardrail table.
5. Optionally run a higher-N robust-null recomputation on v1m survivor candidates.
6. Create a title/abstract-framing aid that is evidence-forward but avoids overclaiming.

Non-goals / forbidden claims
----------------------------
This script does not claim:
  - physical time derived,
  - spacetime derived,
  - quantum gravity proven,
  - Friedmann equations derived,
  - cosmological constants derived,
  - thermodynamic arrow proven.

Evidence may point toward physical objects and dimensionless cosmological /
space-time analogues, but promotion is always separated from comparison-only
bookkeeping.  External constants may be cited for comparison only, never for
selection, scoring, orientation, fitting, or upgrading internal witnesses.

Run from Spyder or terminal.  It auto-detects the QEG project root when run
inside /home/dakini/Downloads/010-Quantum_Emergent_Gravity or any subfolder.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import re
import sys
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

# =============================================================================
# CONFIGURATION
# =============================================================================

STAGE = "Stage-7C-v1n"
RUN_LABEL = "manuscript_evidence_and_provenance_hardening_v1n"

DEFAULT_PROJECT_ROOT = Path("/home/dakini/Downloads/010-Quantum_Emergent_Gravity")
V1M_RUN_LABEL = "one_script_to_rule_time_surrogate_evidence_v1m"
V1L_RUN_LABEL = "primary_trajectory_regeneration_export_hooks_v1l"

ROBUST_NULL_FAMILIES = {"permutation", "circular_shift"}
DIAGNOSTIC_NULL_FAMILIES = {"orientation_reverse", "sign_flip"}

# Set True if you want v1n to recompute a higher-N robust-null audit for only
# the survivor witnesses.  This can be slower but is limited to a small table.
DO_HARDENED_NULL_RECOMPUTE_DEFAULT = True
N_HARDENED_NULL_DEFAULT = 2000
K_HARDEN_DEFAULT = [3, 5, 8, 12]
METHODS_HARDEN_DEFAULT = ["FFT_RFFT_COMPLEX", "FFT_RFFT_REAL", "DCT2_REAL"]
RANDOM_SEED_DEFAULT = 761703

P_VALUE_FLOOR_NOTE = (
    "Finite null ensemble imposes a p-value resolution floor; use review-witness "
    "language unless independently replicated under larger null ensembles and "
    "source/family/semantic ablations."
)

FORBIDDEN_CLAIMS = [
    "physical time derived",
    "spacetime derived",
    "thermodynamic arrow proven",
    "entropy production proven",
    "cosmic age derived",
    "Friedmann equations derived",
    "Einstein gravity derived",
    "Omega_m derived",
    "dark energy derived",
    "curvature of the universe derived",
    "quantum gravity proven",
    "quantum-mechanical interpretation confirmed",
]

# =============================================================================
# UTILITIES
# =============================================================================

def echo(msg: str = "") -> None:
    print(msg, flush=True)


def sha16(s: str) -> str:
    return hashlib.sha256(str(s).encode("utf-8", errors="ignore")).hexdigest()[:16]


def ensure_dir(p: Path) -> Path:
    p.mkdir(parents=True, exist_ok=True)
    return p


def safe_rel(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve()))
    except Exception:
        return str(path)


def safe_read_csv(path: Path, **kwargs) -> pd.DataFrame:
    try:
        return pd.read_csv(path, low_memory=False, **kwargs)
    except pd.errors.EmptyDataError:
        return pd.DataFrame()


def safe_float(x: Any, default: float = np.nan) -> float:
    try:
        if isinstance(x, str):
            s = x.strip()
            if not s or s.lower() in {"nan", "none", "null"}:
                return default
            # strip np.float64(...) style wrappers if they occur
            m = re.match(r"(?:np\.)?(?:float64|float32|str_)\(['\"]?([^'\")]+)['\"]?\)", s)
            if m:
                s = m.group(1)
            return float(s)
        return float(x)
    except Exception:
        return default


def infer_stage(text: str) -> str:
    m = re.search(r"(?:metric_)?stage[_-]?([0-9]+[A-Za-z]+(?:[-_]?v[0-9A-Za-z]+)?)", text, flags=re.I)
    if m:
        return "Stage-" + m.group(1).replace("_", "-")
    m = re.search(r"Stage[-_ ]?([0-9]+[A-Za-z]+(?:[-_]?v[0-9A-Za-z]+)?)", text, flags=re.I)
    if m:
        return "Stage-" + m.group(1).replace("_", "-")
    return "UNKNOWN"


def classify_family(text: str) -> str:
    t = str(text).upper()
    hits = []
    for fam in ["BARI", "NUFIT", "VALENCIA", "POOLED"]:
        if fam in t:
            hits.append(fam)
    return ";".join(hits) if hits else "UNKNOWN"


def normalize_family_series(s: pd.Series) -> pd.Series:
    def norm(x: Any) -> str:
        t = str(x).upper()
        if "BARI" in t:
            return "BARI"
        if "NUFIT" in t:
            return "NUFIT"
        if "VALENCIA" in t:
            return "VALENCIA"
        if "POOLED" in t:
            return "POOLED"
        return "UNKNOWN"
    return s.map(norm)


def zscore_l2(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    if x.size == 0:
        return x
    x = x - np.nanmean(x)
    sd = np.nanstd(x)
    if not np.isfinite(sd) or sd <= 1e-15:
        y = x.copy()
    else:
        y = x / sd
    nrm = np.linalg.norm(y)
    if nrm > 1e-15:
        y = y / nrm
    return y


def clean_vector_like(arr: Sequence[Any]) -> np.ndarray:
    vals = [safe_float(v) for v in arr]
    a = np.asarray(vals, dtype=float)
    return a[np.isfinite(a)]

# =============================================================================
# PATH DISCOVERY
# =============================================================================

def find_project_root(start: Optional[Path] = None) -> Path:
    if start is None:
        start = Path.cwd()
    start = start.resolve()
    candidates = [start] + list(start.parents)
    for c in candidates:
        if (c / "metric_stage_7C_outputs").exists() or c.name == "010-Quantum_Emergent_Gravity":
            return c
    if DEFAULT_PROJECT_ROOT.exists():
        return DEFAULT_PROJECT_ROOT
    return start


def find_v1m_dir(root: Path) -> Optional[Path]:
    paths = list((root / "metric_stage_7C_outputs").glob(f"*{V1M_RUN_LABEL}*"))
    paths += list(root.glob(f"**/*{V1M_RUN_LABEL}*"))
    paths = [p for p in paths if p.is_dir()]
    if paths:
        return sorted(paths, key=lambda p: len(str(p)))[0]
    return None


def first_existing(paths: Sequence[Path]) -> Optional[Path]:
    for p in paths:
        if p.exists():
            return p
    return None


def locate_v1m_files(root: Path, v1m_dir: Optional[Path]) -> Dict[str, Optional[Path]]:
    search_dirs = []
    if v1m_dir:
        search_dirs.append(v1m_dir)
    search_dirs.append(root / "metric_stage_7C_outputs" / V1M_RUN_LABEL)
    search_dirs.append(root)
    search_dirs.append(Path.cwd())

    names = {
        "summary": "stage7C_v1m_summary.json",
        "ledger_note": "stage7C_v1m_ledger_note.txt",
        "candidate_exports": "stage7C_v1m_candidate_vector_exports.csv",
        "lowk_metrics": "stage7C_v1m_recomputed_lowk_metrics.csv",
        "null_ablation": "stage7C_v1m_null_ablation.csv",
        "source_family_ablation": "stage7C_v1m_source_family_ablation.csv",
        "final_adjudication": "stage7C_v1m_final_adjudication_table.csv",
        "prior_channel_ledger": "stage7C_v1m_prior_time_surrogate_channel_ledger.csv",
        "prior_csv_audit": "stage7C_v1m_prior_csv_evidence_audit.csv",
        "prior_json_audit": "stage7C_v1m_prior_json_summary_audit.csv",
        "file_inventory": "stage7C_v1m_file_inventory.csv",
        "source_script_rework": "stage7C_v1m_source_script_rework_plan.csv",
        "v1l_comparison": "stage7C_v1m_v1l_comparison_summary.csv",
        "inspection_errors": "stage7C_v1m_inspection_errors.txt",
    }
    out: Dict[str, Optional[Path]] = {}
    for key, name in names.items():
        candidates = [d / name for d in search_dirs]
        candidates += list(root.glob(f"**/{name}"))
        existing = []
        seen = set()
        for c in candidates:
            try:
                cc = c.resolve()
                if cc.exists() and str(cc) not in seen:
                    existing.append(cc)
                    seen.add(str(cc))
            except Exception:
                pass
        # Prefer the largest copy when multiple copies exist.  This avoids a
        # sandbox smoke-test output shadowing a full Dakini run artifact.
        out[key] = sorted(existing, key=lambda p: p.stat().st_size if p.exists() else -1, reverse=True)[0] if existing else None
    return out

# =============================================================================
# LOW-K / NULL FUNCTIONS
# =============================================================================

def load_npz_vector_pair(path: Path) -> Optional[Tuple[np.ndarray, np.ndarray]]:
    try:
        data = np.load(path, allow_pickle=True)
        # Standard v1l/v1m keys
        if "forward_vector" in data and "reverse_vector" in data:
            return clean_vector_like(data["forward_vector"]), clean_vector_like(data["reverse_vector"])
        if "f" in data and "r" in data:
            return clean_vector_like(data["f"]), clean_vector_like(data["r"])
        # Fallback: first two numeric arrays
        arrays = []
        for k in data.files:
            try:
                arr = clean_vector_like(data[k])
                if arr.size >= 8:
                    arrays.append(arr)
            except Exception:
                pass
        if len(arrays) >= 2:
            return arrays[0], arrays[1]
    except Exception:
        return None
    return None


def fft_lowk_coefficients(x: np.ndarray, k: int, complex_fft: bool = True) -> np.ndarray:
    x = zscore_l2(x)
    if x.size < 4:
        return np.array([], dtype=complex)
    coeff = np.fft.rfft(x)
    if not complex_fft:
        coeff = coeff.real.astype(float)
    kk = max(1, min(k, coeff.size))
    return coeff[:kk]


def dct2_lowk_coefficients(x: np.ndarray, k: int) -> np.ndarray:
    # Lightweight orthonormal-ish DCT-II without scipy dependency.
    x = zscore_l2(x)
    n = x.size
    if n < 4:
        return np.array([], dtype=float)
    kk = max(1, min(k, n))
    idx = np.arange(n)
    coeff = []
    for m in range(kk):
        basis = np.cos(np.pi * (idx + 0.5) * m / n)
        c = float(np.dot(x, basis))
        coeff.append(c)
    return np.asarray(coeff, dtype=float)


def lowk_coeffs(x: np.ndarray, k: int, method: str) -> np.ndarray:
    if method == "FFT_RFFT_COMPLEX":
        return fft_lowk_coefficients(x, k, complex_fft=True)
    if method == "FFT_RFFT_REAL":
        return fft_lowk_coefficients(x, k, complex_fft=False)
    if method == "DCT2_REAL":
        return dct2_lowk_coefficients(x, k)
    return fft_lowk_coefficients(x, k, complex_fft=True)


def coeff_distance(a: np.ndarray, b: np.ndarray) -> float:
    n = min(a.size, b.size)
    if n == 0:
        return np.nan
    aa = np.asarray(a[:n])
    bb = np.asarray(b[:n])
    denom = np.linalg.norm(aa) + np.linalg.norm(bb)
    if denom <= 1e-15:
        return 0.0
    return float(np.linalg.norm(aa - bb) / denom)


def lowk_distance_pair(f: np.ndarray, r: np.ndarray, k: int, method: str) -> float:
    n = min(f.size, r.size)
    f = f[:n]
    r = r[:n]
    return coeff_distance(lowk_coeffs(f, k, method), lowk_coeffs(r, k, method))


def make_null_reverse(r: np.ndarray, null_family: str, rng: np.random.Generator) -> np.ndarray:
    r = np.asarray(r, dtype=float)
    if null_family == "permutation":
        return rng.permutation(r)
    if null_family == "circular_shift":
        if r.size <= 1:
            return r.copy()
        shift = int(rng.integers(1, r.size))
        return np.roll(r, shift)
    if null_family == "orientation_reverse":
        return r[::-1]
    if null_family == "sign_flip":
        return -r
    return rng.permutation(r)


def hardened_null_for_pair(
    candidate_id: str,
    family: str,
    source_file: str,
    source_kind: str,
    forward_name: str,
    reverse_name: str,
    f: np.ndarray,
    r: np.ndarray,
    k_values: Sequence[int],
    methods: Sequence[str],
    n_null: int,
    rng: np.random.Generator,
) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    n = min(f.size, r.size)
    f = f[:n]
    r = r[:n]
    for method in methods:
        for k in k_values:
            observed = lowk_distance_pair(f, r, k, method)
            for nfam in sorted(ROBUST_NULL_FAMILIES):
                vals = []
                for _ in range(n_null):
                    rn = make_null_reverse(r, nfam, rng)
                    vals.append(lowk_distance_pair(f, rn, k, method))
                vals = np.asarray(vals, dtype=float)
                vals = vals[np.isfinite(vals)]
                if vals.size == 0 or not np.isfinite(observed):
                    p_upper = np.nan
                    z = np.nan
                    mean = np.nan
                    std = np.nan
                else:
                    # p_upper asks: how often is the null as large as or larger than observed?
                    # +1 smoothing gives explicit finite-resolution floor.
                    p_upper = (1.0 + float(np.sum(vals >= observed))) / (1.0 + float(vals.size))
                    mean = float(np.mean(vals))
                    std = float(np.std(vals, ddof=0))
                    z = float((observed - mean) / std) if std > 1e-15 else np.nan
                rows.append({
                    "candidate_id": candidate_id,
                    "family": family,
                    "source_file": source_file,
                    "source_kind": source_kind,
                    "forward_vector_name": forward_name,
                    "reverse_vector_name": reverse_name,
                    "vector_length": int(n),
                    "method": method,
                    "k": int(k),
                    "null_family": nfam,
                    "n_null": int(n_null),
                    "observed_lowk_coeff_distance": observed,
                    "null_mean": mean,
                    "null_std": std,
                    "null_z": z,
                    "p_upper_large_distance": p_upper,
                    "survives_p05": bool(np.isfinite(p_upper) and p_upper < 0.05),
                    "survives_p10_review": bool(np.isfinite(p_upper) and p_upper < 0.10),
                    "finite_null_floor": 1.0 / (1.0 + float(n_null)),
                    "promotion_scope": "ROBUST_NULL_ONLY",
                })
    return rows

# =============================================================================
# PROVENANCE RESOLUTION
# =============================================================================

def source_exists_on_disk(source_file: str) -> bool:
    try:
        return Path(source_file).exists()
    except Exception:
        return False


def inspect_source_family_lineage(source_file: str, candidate_forward: str = "", candidate_reverse: str = "") -> Dict[str, Any]:
    path = Path(str(source_file))
    out: Dict[str, Any] = {
        "source_file_exists": path.exists(),
        "family_hint_from_path": classify_family(str(source_file)),
        "family_resolution_status": "UNRESOLVED_NOT_INSPECTED",
        "family_columns": "",
        "family_values_detected": "",
        "family_row_counts": "",
        "forward_reverse_columns_present": "",
        "source_column_count": np.nan,
        "source_rows_read": np.nan,
    }
    if not path.exists():
        out["family_resolution_status"] = "UNRESOLVED_SOURCE_FILE_NOT_FOUND_ON_THIS_MACHINE"
        return out
    if path.suffix.lower() != ".csv":
        out["family_resolution_status"] = "UNRESOLVED_SOURCE_NOT_CSV"
        return out
    try:
        df = pd.read_csv(path, low_memory=False)
    except Exception as exc:
        out["family_resolution_status"] = f"UNRESOLVED_CSV_READ_ERROR:{repr(exc)[:120]}"
        return out
    out["source_column_count"] = int(len(df.columns))
    out["source_rows_read"] = int(len(df))
    cols = [str(c) for c in df.columns]
    fam_cols = [c for c in cols if re.search(r"family|fit|source|label|dataset|origin|lineage", c, flags=re.I)]
    direct_fam_cols = []
    fam_counter: Counter = Counter()
    for c in fam_cols:
        try:
            vals = normalize_family_series(df[c])
            vc = Counter(v for v in vals if v != "UNKNOWN")
            if vc:
                direct_fam_cols.append(c)
                fam_counter.update(vc)
        except Exception:
            pass
    out["family_columns"] = ";".join(direct_fam_cols)
    out["family_values_detected"] = ";".join(sorted(fam_counter.keys()))
    out["family_row_counts"] = ";".join([f"{k}:{v}" for k, v in sorted(fam_counter.items())])
    present_cols = []
    for c in [candidate_forward, candidate_reverse]:
        if c and c in cols:
            present_cols.append(c)
    out["forward_reverse_columns_present"] = ";".join(present_cols)

    if fam_counter:
        if len(fam_counter) == 1:
            out["family_resolution_status"] = "RESOLVED_SINGLE_FAMILY_IN_SOURCE_TABLE"
        else:
            out["family_resolution_status"] = "SOURCE_CONTAINS_MULTI_FAMILY_LINEAGE_BUT_CANDIDATE_VECTOR_AGGREGATED"
    else:
        if classify_family(str(source_file)) != "UNKNOWN":
            out["family_resolution_status"] = "RESOLVED_FROM_PATH_ONLY"
        else:
            out["family_resolution_status"] = "UNRESOLVED_NO_ROW_LEVEL_FAMILY_COLUMN_DETECTED"
    return out


def load_json(path: Optional[Path]) -> Dict[str, Any]:
    if not path or not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception:
        return {}

# =============================================================================
# TABLE BUILDERS
# =============================================================================

def build_survivor_provenance(
    null_df: pd.DataFrame,
    export_df: pd.DataFrame,
    prior_ledger: pd.DataFrame,
    root: Path,
    output_dir: Path,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    if null_df.empty:
        return pd.DataFrame(), pd.DataFrame()
    pcol = "p_upper_large_distance"
    nd = null_df.copy()
    nd[pcol] = pd.to_numeric(nd[pcol], errors="coerce") if pcol in nd.columns else np.nan
    # Robust promotion only uses permutation and circular_shift.
    robust = nd[nd.get("null_family", "").isin(ROBUST_NULL_FAMILIES)].copy()
    robust_p05 = robust[robust[pcol] < 0.05].copy()
    detail = robust_p05.copy()
    if not detail.empty:
        # add source-kind/vector metadata from exports
        meta_cols = [
            "candidate_id", "source_kind", "channel_tags", "forward_vector_name", "reverse_vector_name",
            "vector_length", "generation_notes", "exported_npz", "semantic_tier", "admissibility"
        ]
        meta = export_df[[c for c in meta_cols if c in export_df.columns]].drop_duplicates("candidate_id") if not export_df.empty else pd.DataFrame()
        if not meta.empty:
            detail = detail.merge(meta, on="candidate_id", how="left", suffixes=("", "_export"))
    rows: List[Dict[str, Any]] = []
    if detail.empty:
        return detail, pd.DataFrame()

    for cid, g in detail.groupby("candidate_id", dropna=False):
        src = str(g["source_file"].iloc[0]) if "source_file" in g.columns else ""
        fam = str(g["family"].iloc[0]) if "family" in g.columns else "UNKNOWN"
        forward_name = str(g.get("forward_vector_name", pd.Series([""])).iloc[0])
        reverse_name = str(g.get("reverse_vector_name", pd.Series([""])).iloc[0])
        lineage = inspect_source_family_lineage(src, forward_name, reverse_name)
        source_stage = infer_stage(src)
        source_hash = sha16(src)
        vector_pair_signature = sha16(src + "::" + forward_name + "::" + reverse_name)
        origin_kind = str(g.get("source_kind", pd.Series([""])).iloc[0])
        is_v1l_import = origin_kind == "v1l_npz_import_contemporary_recompute" or "from_v1l" in str(cid)
        # Prior ledger matches for source_file.
        prior_matches = 0
        prior_channels = ""
        prior_positive = 0
        if not prior_ledger.empty and "source_file" in prior_ledger.columns:
            pm = prior_ledger[prior_ledger["source_file"].astype(str) == src]
            prior_matches = int(len(pm))
            if not pm.empty and "principal_channel" in pm.columns:
                prior_channels = ";".join(sorted(set(pm["principal_channel"].astype(str))))[:500]
            if not pm.empty and "evidence_posture" in pm.columns:
                prior_positive = int(pm["evidence_posture"].astype(str).str.contains("positive|support|arrow|survive|A_|B_", case=False, na=False).sum())
        rows.append({
            "candidate_id": cid,
            "source_stage": source_stage,
            "family_v1m": fam,
            "resolved_family_hint": lineage.get("family_values_detected") or lineage.get("family_hint_from_path") or "UNKNOWN",
            "family_resolution_status": lineage.get("family_resolution_status"),
            "source_file": src,
            "source_file_sha16": source_hash,
            "source_kind": origin_kind,
            "is_v1l_import": bool(is_v1l_import),
            "forward_vector_name": forward_name,
            "reverse_vector_name": reverse_name,
            "vector_pair_signature": vector_pair_signature,
            "robust_p05_rows": int(len(g)),
            "robust_null_families_survived": ";".join(sorted(set(g["null_family"].astype(str)))) if "null_family" in g.columns else "",
            "methods_survived": ";".join(sorted(set(g["method"].astype(str)))) if "method" in g.columns else "",
            "k_values_survived": ";".join(map(str, sorted(set(g["k"].astype(int))))) if "k" in g.columns else "",
            "min_p_upper": float(pd.to_numeric(g[pcol], errors="coerce").min()),
            "max_observed_distance": float(pd.to_numeric(g.get("observed_lowk_coeff_distance", pd.Series(dtype=float)), errors="coerce").max()),
            "prior_ledger_rows_same_source": prior_matches,
            "prior_positive_or_supportive_rows_same_source": prior_positive,
            "prior_channels_same_source": prior_channels,
            "family_columns_in_source": lineage.get("family_columns"),
            "family_row_counts_in_source": lineage.get("family_row_counts"),
            "source_rows_read": lineage.get("source_rows_read"),
            "source_column_count": lineage.get("source_column_count"),
            "provenance_conclusion": provenance_conclusion(fam, lineage, source_stage, origin_kind),
        })
    prov = pd.DataFrame(rows)
    # Add independence group after rows are built.
    if not prov.empty:
        prov["independence_group_id"] = prov.apply(
            lambda r: sha16(str(r["source_file"]) + "::" + str(r["forward_vector_name"]) + "::" + str(r["reverse_vector_name"])), axis=1
        )
        counts = prov.groupby("independence_group_id")["candidate_id"].transform("count")
        prov["candidate_variants_in_independence_group"] = counts.astype(int)
        prov["independence_status"] = np.where(counts > 1, "DUPLICATE_OR_DERIVED_VARIANT_SAME_SOURCE_PAIR", "UNIQUE_SOURCE_PAIR_WITHIN_V1M_SURVIVORS")
    return detail, prov


def provenance_conclusion(fam: str, lineage: Dict[str, Any], stage: str, origin_kind: str) -> str:
    status = str(lineage.get("family_resolution_status", ""))
    if fam != "UNKNOWN":
        return "FAMILY_ALREADY_LABELED_IN_V1M"
    if status.startswith("SOURCE_CONTAINS_MULTI_FAMILY"):
        return "UNKNOWN_RESOLVED_TO_AGGREGATED_MULTI_FAMILY_SOURCE_NOT_ROW_LEVEL_ASSIGNED"
    if status.startswith("RESOLVED"):
        return "UNKNOWN_RESOLVED_BY_SOURCE_LINEAGE_INSPECTION"
    if stage.startswith("Stage-7B"):
        return "UNKNOWN_IS_STAGE7B_TIME_SURROGATE_AGGREGATE; TRACEABLE_STAGE_AND_SOURCE_BUT_NO_BARI_NUFIT_VALENCIA_ROW_LABEL"
    if stage.startswith("Stage-7C"):
        return "UNKNOWN_IS_STAGE7C_DERIVED_VECTOR_EXPORT; TRACE_BACK_TO_UPSTREAM_EXPORT_REQUIRED"
    return "UNKNOWN_REMAINS_UNRESOLVED_AFTER_SOURCE_INSPECTION"


def build_independence_audit(prov: pd.DataFrame) -> pd.DataFrame:
    if prov.empty:
        return pd.DataFrame()
    rows = []
    for gid, g in prov.groupby("independence_group_id"):
        rows.append({
            "independence_group_id": gid,
            "source_file": g["source_file"].iloc[0],
            "source_stage": g["source_stage"].iloc[0],
            "forward_vector_name": g["forward_vector_name"].iloc[0],
            "reverse_vector_name": g["reverse_vector_name"].iloc[0],
            "candidate_count": int(len(g)),
            "candidate_ids": ";".join(g["candidate_id"].astype(str)),
            "source_kinds": ";".join(sorted(set(g["source_kind"].astype(str)))),
            "robust_p05_rows_total": int(pd.to_numeric(g["robust_p05_rows"], errors="coerce").sum()),
            "min_p_upper": float(pd.to_numeric(g["min_p_upper"], errors="coerce").min()),
            "resolved_family_hints": ";".join(sorted(set(g["resolved_family_hint"].astype(str))))[:300],
            "independence_assessment": "ONE_EVIDENCE_WITNESS_WITH_MULTIPLE_DERIVED_VARIANTS" if len(g) > 1 else "ONE_DISTINCT_EVIDENCE_WITNESS",
            "paper_role": "corroborating_lowk_witness" if len(g) > 1 else "candidate_independent_lowk_witness",
        })
    return pd.DataFrame(rows).sort_values(["paper_role", "robust_p05_rows_total"], ascending=[True, False])


def summarize_prior_channels(prior_ledger: pd.DataFrame) -> pd.DataFrame:
    if prior_ledger.empty:
        return pd.DataFrame()
    rows = []
    channel_col = "principal_channel" if "principal_channel" in prior_ledger.columns else "channel_tags"
    for channel, g in prior_ledger.groupby(channel_col, dropna=False):
        posture = g["evidence_posture"].astype(str) if "evidence_posture" in g.columns else pd.Series([], dtype=str)
        positive = int(posture.str.contains("positive|support|survive|arrow|A_|B_", case=False, na=False).sum()) if not posture.empty else 0
        stages = ";".join(sorted(set(g.get("stage", pd.Series(dtype=str)).astype(str))))[:500]
        fams = ";".join(sorted(set(g.get("family_hint", pd.Series(dtype=str)).astype(str))))[:300]
        rows.append({
            "principal_channel": channel,
            "record_count": int(len(g)),
            "positive_or_supportive_record_count": positive,
            "stage_coverage": stages,
            "family_hint_coverage": fams,
            "paper_use": channel_paper_use(str(channel)),
            "evidence_status": channel_status(str(channel), int(len(g)), positive),
        })
    return pd.DataFrame(rows).sort_values("record_count", ascending=False)


def channel_paper_use(channel: str) -> str:
    c = channel.lower()
    if "entropy" in c:
        return "independent_primary_arrow_support_channel"
    if "operator" in c or "forward" in c or "reverse" in c:
        return "independent_operator_directionality_support_channel"
    if "low" in c:
        return "corroborating_spectral_review_channel"
    if "partial" in c or "revers" in c:
        return "diagnostic_control_sandbox"
    if "external" in c:
        return "comparison_only_appendix_bookkeeping"
    if "family" in c:
        return "lineage_context_and_universality_support"
    return "context_or_auxiliary_record"


def channel_status(channel: str, count: int, positive: int) -> str:
    c = channel.lower()
    if "entropy" in c and positive > 0:
        return "PRESERVED_INDEPENDENT_POSITIVE_EVIDENCE"
    if ("operator" in c or "forward" in c or "reverse" in c) and count > 0:
        return "AUDITED_DIRECTIONALITY_EVIDENCE"
    if "low" in c:
        return "REVIEW_WITNESS_SUPPORT_NOT_STANDALONE_PROOF"
    if "partial" in c:
        return "AMBIGUITY_CONTROL_NOT_DOWNGRADE"
    if "external" in c:
        return "COMPARISON_ONLY_NOT_SELECTION_OR_SCORING"
    return "CONTEXTUAL_EVIDENCE"


def build_manuscript_evidence_table(
    summary: Dict[str, Any],
    prior_summary: pd.DataFrame,
    prov: pd.DataFrame,
    independence: pd.DataFrame,
    final_adj: pd.DataFrame,
) -> pd.DataFrame:
    # Pull counts from summary when available.
    s = summary
    distinct_lowk_witnesses = int(independence["independence_group_id"].nunique()) if not independence.empty else 0
    unique_survivor_candidates = int(prov["candidate_id"].nunique()) if not prov.empty else 0
    robust_rows = int(prov["robust_p05_rows"].sum()) if not prov.empty else 0

    rows = [
        {
            "evidence_channel": "Entropy state-space arrow",
            "manuscript_role": "independent primary evidence",
            "current_status": "preserved and audited separately",
            "evidence_count": s.get("prior_entropy_records", np.nan),
            "supportive_count": s.get("prior_entropy_positive_or_supportive_records", np.nan),
            "independence_label": "independent from low-k and partial-reversibility sandbox",
            "main_claim_allowed": "supports existence of internal arrow/time-surrogate evidence channel",
            "claim_not_allowed": "does not prove thermodynamic entropy production or physical time",
            "needed_for_80pct_target": "compress strongest entropy records into a manuscript table with source/stage provenance",
        },
        {
            "evidence_channel": "Operator directionality and forward/reverse records",
            "manuscript_role": "independent primary/corroborating evidence",
            "current_status": "audited separately from entropy and low-k",
            "evidence_count": s.get("prior_operator_or_forward_reverse_records", np.nan),
            "supportive_count": np.nan,
            "independence_label": "partly independent; must be separated by source family and script stage",
            "main_claim_allowed": "supports directional asymmetry in emergent operator geometry",
            "claim_not_allowed": "does not prove macroscopic irreversibility by itself",
            "needed_for_80pct_target": "summarize source-side vs target-side directionality and duplicate controls",
        },
        {
            "evidence_channel": "Low-k spectral witness",
            "manuscript_role": "corroborating review evidence",
            "current_status": "recomputed with robust-null survival but not standalone claim-grade",
            "evidence_count": s.get("lowk_metric_rows", np.nan),
            "supportive_count": s.get("null_p05_surviving_rows", np.nan),
            "independence_label": f"{distinct_lowk_witnesses} distinct source-pair groups among robust survivors; {unique_survivor_candidates} candidate variants",
            "main_claim_allowed": "corroborates arrow/directionality in low-mode spectral representation",
            "claim_not_allowed": "not a theorem and not independent of entropy if same Stage-7B slope source dominates",
            "needed_for_80pct_target": "trace UNKNOWN family/source labels and optionally run higher-N nulls on survivor groups",
        },
        {
            "evidence_channel": "Forward/reverse recursion",
            "manuscript_role": "mechanism-facing support",
            "current_status": "audited through prior records and source rework plan",
            "evidence_count": s.get("prior_operator_or_forward_reverse_records", np.nan),
            "supportive_count": np.nan,
            "independence_label": "overlaps operator directionality but should be tabulated separately",
            "main_claim_allowed": "supports semigroup-like or direction-sensitive recursion diagnostics",
            "claim_not_allowed": "does not prove physical time evolution",
            "needed_for_80pct_target": "select 3-5 cleanest prior recursion records and match to null/ablation history",
        },
        {
            "evidence_channel": "Partial-reversibility sandbox",
            "manuscript_role": "diagnostic control",
            "current_status": "ambiguity/control channel, not an automatic downgrade",
            "evidence_count": np.nan,
            "supportive_count": np.nan,
            "independence_label": "not primary evidence; checks whether residual ambiguity is noise or reversible sector",
            "main_claim_allowed": "helps classify ambiguity in arrow evidence",
            "claim_not_allowed": "no time travel, no CTCs, no macroscopic reversal, no thermodynamic violation",
            "needed_for_80pct_target": "keep in methods/results as control, not as headline",
        },
        {
            "evidence_channel": "Dimensionless cosmology / space-time bookkeeping",
            "manuscript_role": "comparison-only appendix or restrained results section",
            "current_status": "allowed only as internally generated invariant comparison",
            "evidence_count": np.nan,
            "supportive_count": np.nan,
            "independence_label": "not used to select, orient, score, fit, or upgrade witnesses",
            "main_claim_allowed": "reports numerical proximity of QEG invariants to physical-sector ratios as comparison bookkeeping",
            "claim_not_allowed": "does not derive Omega_m, dark energy, curvature, Friedmann dynamics, or spacetime",
            "needed_for_80pct_target": "state external-constants rule explicitly in abstract/methods and tables",
        },
        {
            "evidence_channel": "Green-function / nonlocal geometry thread",
            "manuscript_role": "conceptual and methodological bridge",
            "current_status": "supported as nonlocal/operator framing; not necessarily a local Green kernel",
            "evidence_count": np.nan,
            "supportive_count": np.nan,
            "independence_label": "connects QEG operator geometry to nonlocal response methods; do not over-identify with local PDE Green functions",
            "main_claim_allowed": "frames QEG as emergent nonlocal operator geometry with potential Green-function-inspired diagnostics",
            "claim_not_allowed": "does not claim a closed GR Green-function derivation",
            "needed_for_80pct_target": "title can include Green functions only if paper contains a dedicated, accurate section/table",
        },
    ]
    return pd.DataFrame(rows)


def build_reviewer_risk_table() -> pd.DataFrame:
    rows = [
        {
            "reviewer_question_or_risk": "Are the strongest low-k survivors independent, or variants of the same source channel?",
            "current_answer": "v1n groups survivors by source file and forward/reverse vector-pair signature; duplicate v1l imports are counted as variants, not new independent evidence.",
            "paper_action": "Report distinct witness groups separately from candidate-row counts.",
            "risk_level_after_action": "moderate_to_low",
        },
        {
            "reviewer_question_or_risk": "Why are p<0.05 low-k survivors labeled UNKNOWN family?",
            "current_answer": "v1n traces each survivor back to its source CSV/NPZ, inspects source columns, and distinguishes unresolved aggregation from true missing provenance.",
            "paper_action": "Include survivor provenance table and label unresolved family status transparently.",
            "risk_level_after_action": "moderate",
        },
        {
            "reviewer_question_or_risk": "Is the p-value evidence limited by a finite null ensemble?",
            "current_answer": P_VALUE_FLOOR_NOTE,
            "paper_action": "Use review-witness wording and, where possible, provide hardened null recomputation with larger N.",
            "risk_level_after_action": "low",
        },
        {
            "reviewer_question_or_risk": "Were external cosmological constants used to tune the results?",
            "current_answer": "No. External constants are forbidden from selecting, orienting, fitting, scoring, or upgrading internal witnesses.",
            "paper_action": "State this in methods and repeat in evidence tables.",
            "risk_level_after_action": "low",
        },
        {
            "reviewer_question_or_risk": "Is the work claiming to derive spacetime or physical time?",
            "current_answer": "No. The paper reports emergent operator-geometric and time-surrogate evidence, with physical interpretation framed as evidence-forward but claim-disciplined.",
            "paper_action": "Use restrained title/abstract; list forbidden claims explicitly in supplement.",
            "risk_level_after_action": "moderate_to_low",
        },
        {
            "reviewer_question_or_risk": "Could the bimodal/two-lobed distribution be a fit artifact?",
            "current_answer": "Earlier stages showed single-template mismatch, constrained two-lobe correction, family-aware survival, and recursive/operator consistency; these should be summarized rather than re-proved in v1n.",
            "paper_action": "Provide a compact historical evidence chain: single-mode failure -> constrained two-lobe success -> family/recursion audits.",
            "risk_level_after_action": "moderate_to_low",
        },
        {
            "reviewer_question_or_risk": "Are rho-kappa/kappa-rho results local PDE claims?",
            "current_answer": "No. The strongest supported formulation is nonlocal/operator-modal; local PDE and translation-invariant Green kernels were not promoted as primary closure.",
            "paper_action": "Frame rho-kappa evidence as nonlocal constitutive geometry, not a solved field equation.",
            "risk_level_after_action": "low",
        },
        {
            "reviewer_question_or_risk": "Is the manuscript too broad?",
            "current_answer": "Risk remains if all physics analogies are placed in the main claim. Channel separation solves this.",
            "paper_action": "Make main text about evidence channels and put cosmology/GR-adjacent comparisons in restrained results or appendix.",
            "risk_level_after_action": "moderate",
        },
    ]
    return pd.DataFrame(rows)


def build_claim_guardrail_table() -> pd.DataFrame:
    rows = []
    allowed = [
        ("QEG identifies auditable, internally generated time-surrogate evidence channels.", "main"),
        ("Entropy, operator directionality, and low-k spectral witnesses are separated and cross-audited.", "main"),
        ("Low-k evidence is a review-level corroborating witness unless strengthened by independence and family/source provenance.", "main"),
        ("Dimensionless cosmological/space-time comparisons are bookkeeping/proximity results, not derivations.", "appendix_or_restrained_results"),
        ("Green-function language may be used as nonlocal-response/geometric methodology if not overstated as local PDE closure.", "main_or_methods"),
    ]
    for claim, placement in allowed:
        rows.append({"claim_type": "allowed_claim", "claim": claim, "recommended_placement": placement})
    for claim in FORBIDDEN_CLAIMS:
        rows.append({"claim_type": "forbidden_claim", "claim": claim, "recommended_placement": "state_as_not_claimed_in_guardrails"})
    return pd.DataFrame(rows)


def build_title_candidates() -> pd.DataFrame:
    rows = [
        {
            "title_candidate": "Green-Function-Inspired Evidence Channels for Emergent Operator Geometry in Neutrino-Family Data",
            "risk": "moderate",
            "notes": "Includes Green functions, neutrino families, and emergent operator geometry; safe only if Green functions are treated as methodological inspiration/nonlocal response diagnostics.",
        },
        {
            "title_candidate": "Dimensionless Cosmological Proximities from Emergent Operator Geometry of Neutrino-Family Distributions",
            "risk": "moderate_high",
            "notes": "Strong and attractive, but may sound too close to deriving cosmological constants. Use only with careful abstract guardrails.",
        },
        {
            "title_candidate": "Auditable Time-Surrogate Evidence in an Emergent Operator Geometry Built from Neutrino-Family Data",
            "risk": "low_moderate",
            "notes": "Best Physica D posture: technical, evidence-forward, and not bombastic.",
        },
        {
            "title_candidate": "Channel-Separated Evidence for Directionality in a Neutrino-Family Operator-Geometry Pipeline",
            "risk": "low",
            "notes": "Safest title, but less exciting. Good for conservative submission.",
        },
        {
            "title_candidate": "From Neutrino-Family Geometry to Time-Surrogate Evidence: A Data-Driven Nonlocal Operator Approach",
            "risk": "low_moderate",
            "notes": "Balanced: it names the physical input and time-surrogate target without claiming derivation of physical time.",
        },
        {
            "title_candidate": "Emergent Dimensionless Space-Time Signatures from Geometric Structure in Neutrino-Family Data",
            "risk": "high",
            "notes": "Powerful but closest to overreach. Better as internal working title than first submission title.",
        },
    ]
    return pd.DataFrame(rows)

# =============================================================================
# MAIN
# =============================================================================

def main() -> None:
    parser = argparse.ArgumentParser(description="Stage-7C-v1n manuscript evidence and provenance hardening")
    parser.add_argument("project_root", nargs="?", default=None)
    parser.add_argument("--no-hardened-null", action="store_true", help="Skip higher-N robust-null recomputation")
    parser.add_argument("--n-null", type=int, default=N_HARDENED_NULL_DEFAULT)
    parser.add_argument("--seed", type=int, default=RANDOM_SEED_DEFAULT)
    args = parser.parse_args()

    root = Path(args.project_root).expanduser().resolve() if args.project_root else find_project_root()
    outdir = ensure_dir(root / "metric_stage_7C_outputs" / RUN_LABEL)
    echo("============================================================")
    echo(f"{STAGE}: Manuscript Evidence and Provenance Hardening")
    echo("============================================================")
    echo(f"Project root: {root}")
    echo(f"Output dir  : {outdir}")

    v1m_dir = find_v1m_dir(root)
    echo(f"v1m dir     : {v1m_dir if v1m_dir else 'NOT FOUND; using recursive file search'}")
    files = locate_v1m_files(root, v1m_dir)
    for key, path in files.items():
        echo(f"  {key:24s}: {path if path else 'MISSING'}")

    summary = load_json(files.get("summary"))
    export_df = safe_read_csv(files["candidate_exports"]) if files.get("candidate_exports") else pd.DataFrame()
    null_df = safe_read_csv(files["null_ablation"]) if files.get("null_ablation") else pd.DataFrame()
    lowk_df = safe_read_csv(files["lowk_metrics"]) if files.get("lowk_metrics") else pd.DataFrame()
    prior_ledger = safe_read_csv(files["prior_channel_ledger"]) if files.get("prior_channel_ledger") else pd.DataFrame()
    final_adj = safe_read_csv(files["final_adjudication"]) if files.get("final_adjudication") else pd.DataFrame()
    source_rework = safe_read_csv(files["source_script_rework"]) if files.get("source_script_rework") else pd.DataFrame()

    # Core provenance tables.
    robust_detail, survivor_prov = build_survivor_provenance(null_df, export_df, prior_ledger, root, outdir)
    independence = build_independence_audit(survivor_prov)
    prior_channel_summary = summarize_prior_channels(prior_ledger)
    evidence_table = build_manuscript_evidence_table(summary, prior_channel_summary, survivor_prov, independence, final_adj)
    risk_table = build_reviewer_risk_table()
    guardrail_table = build_claim_guardrail_table()
    title_table = build_title_candidates()

    # Hardened null recompute for distinct survivor source-pair groups.
    hard_rows: List[Dict[str, Any]] = []
    hard_errors: List[str] = []
    do_harden = (not args.no_hardened_null) and DO_HARDENED_NULL_RECOMPUTE_DEFAULT
    if do_harden and not survivor_prov.empty:
        rng = np.random.default_rng(args.seed)
        # Recompute only one representative per independence group.
        reps = survivor_prov.sort_values(["independence_group_id", "min_p_upper"]).groupby("independence_group_id").head(1)
        echo(f"Running hardened null recomputation for {len(reps)} survivor source-pair groups with n_null={args.n_null}...")
        for _, row in reps.iterrows():
            cid = str(row["candidate_id"])
            # Find export metadata and npz path.
            ed = export_df[export_df.get("candidate_id", pd.Series(dtype=str)).astype(str) == cid] if not export_df.empty else pd.DataFrame()
            if ed.empty:
                hard_errors.append(f"No export row for survivor candidate {cid}")
                continue
            exported_npz = str(ed.get("exported_npz", pd.Series([""])).iloc[0])
            npz_path = Path(exported_npz)
            if not npz_path.exists():
                # Try v1m dir relative fallbacks.
                candidates = []
                if v1m_dir:
                    candidates.extend([
                        v1m_dir / "contemporary_regenerated_vectors" / npz_path.name,
                        v1m_dir / npz_path.name,
                    ])
                candidates.append(root / exported_npz)
                npz_path = next((p for p in candidates if p.exists()), Path(exported_npz))
            pair = load_npz_vector_pair(npz_path)
            if pair is None:
                hard_errors.append(f"Could not load npz vector pair for {cid}: {npz_path}")
                continue
            f, r = pair
            hard_rows.extend(hardened_null_for_pair(
                candidate_id=cid,
                family=str(row.get("resolved_family_hint", row.get("family_v1m", "UNKNOWN"))),
                source_file=str(row.get("source_file", "")),
                source_kind=str(row.get("source_kind", "")),
                forward_name=str(row.get("forward_vector_name", "")),
                reverse_name=str(row.get("reverse_vector_name", "")),
                f=f,
                r=r,
                k_values=K_HARDEN_DEFAULT,
                methods=METHODS_HARDEN_DEFAULT,
                n_null=args.n_null,
                rng=rng,
            ))
    hard_df = pd.DataFrame(hard_rows)
    if hard_df.empty:
        hard_df = pd.DataFrame(columns=[
            "candidate_id", "family", "source_file", "source_kind", "forward_vector_name",
            "reverse_vector_name", "vector_length", "method", "k", "null_family", "n_null",
            "observed_lowk_coeff_distance", "null_mean", "null_std", "null_z",
            "p_upper_large_distance", "survives_p05", "survives_p10_review",
            "finite_null_floor", "promotion_scope"
        ])

    # Summary of hardened nulls.
    hard_summary_rows = []
    if not hard_df.empty:
        for cid, g in hard_df.groupby("candidate_id"):
            hard_summary_rows.append({
                "candidate_id": cid,
                "source_file": g["source_file"].iloc[0],
                "family": g["family"].iloc[0],
                "hard_null_rows": int(len(g)),
                "hard_p05_rows": int(g["survives_p05"].sum()),
                "hard_p10_rows": int(g["survives_p10_review"].sum()),
                "min_p_upper": float(pd.to_numeric(g["p_upper_large_distance"], errors="coerce").min()),
                "finite_null_floor": float(g["finite_null_floor"].iloc[0]),
                "methods_survived": ";".join(sorted(set(g.loc[g["survives_p05"], "method"].astype(str)))) if g["survives_p05"].any() else "",
                "k_values_survived": ";".join(map(str, sorted(set(g.loc[g["survives_p05"], "k"].astype(int))))) if g["survives_p05"].any() else "",
                "null_families_survived": ";".join(sorted(set(g.loc[g["survives_p05"], "null_family"].astype(str)))) if g["survives_p05"].any() else "",
                "hardening_interpretation": "SURVIVES_HIGHER_N_ROBUST_NULL_RECOMPUTE" if g["survives_p05"].any() else "DOES_NOT_SURVIVE_HIGHER_N_RECOMPUTE",
            })
    hard_summary = pd.DataFrame(hard_summary_rows)
    if hard_summary.empty:
        hard_summary = pd.DataFrame(columns=[
            "candidate_id", "source_file", "family", "hard_null_rows", "hard_p05_rows",
            "hard_p10_rows", "min_p_upper", "finite_null_floor", "methods_survived",
            "k_values_survived", "null_families_survived", "hardening_interpretation"
        ])

    # Prior source-script candidates summarized for manuscript.
    if not source_rework.empty:
        tier1 = source_rework[source_rework.get("priority_tier", "").astype(str).str.contains("TIER_1", case=False, na=False)].copy()
    else:
        tier1 = pd.DataFrame()

    # Verdict logic.
    unresolved_unknown = 0
    if not survivor_prov.empty:
        unresolved_unknown = int(survivor_prov["provenance_conclusion"].astype(str).str.contains("UNRESOLVED|AGGREGATED|TRACE_BACK", case=False, na=False).sum())
    distinct_groups = int(independence["independence_group_id"].nunique()) if not independence.empty else 0
    hard_survivors = int(hard_summary["hard_p05_rows"].gt(0).sum()) if not hard_summary.empty else 0

    if distinct_groups >= 2 and unresolved_unknown == 0 and (not do_harden or hard_survivors >= 1):
        final_decision = "A_MINUS_MANUSCRIPT_HARDENING_SUCCESS_PROVENANCE_AND_INDEPENDENCE_CLEAR"
    elif distinct_groups >= 1 and (not do_harden or hard_survivors >= 1):
        final_decision = "B_PLUS_MANUSCRIPT_HARDENING_USEFUL_REMAINING_PROVENANCE_OR_INDEPENDENCE_REVIEW"
    else:
        final_decision = "C_REVIEW_REQUIRED_LOWK_SURVIVOR_PROVENANCE_OR_HARDENING_INCOMPLETE"

    # Write outputs.
    robust_detail.to_csv(outdir / "stage7C_v1n_robust_lowk_survivor_detail.csv", index=False)
    survivor_prov.to_csv(outdir / "stage7C_v1n_lowk_survivor_provenance_trace.csv", index=False)
    independence.to_csv(outdir / "stage7C_v1n_independence_audit.csv", index=False)
    prior_channel_summary.to_csv(outdir / "stage7C_v1n_prior_channel_summary.csv", index=False)
    evidence_table.to_csv(outdir / "stage7C_v1n_manuscript_evidence_table.csv", index=False)
    risk_table.to_csv(outdir / "stage7C_v1n_reviewer_risk_table.csv", index=False)
    guardrail_table.to_csv(outdir / "stage7C_v1n_claim_guardrail_table.csv", index=False)
    title_table.to_csv(outdir / "stage7C_v1n_title_candidate_table.csv", index=False)
    hard_df.to_csv(outdir / "stage7C_v1n_hardened_null_recompute.csv", index=False)
    hard_summary.to_csv(outdir / "stage7C_v1n_hardened_null_summary.csv", index=False)
    if not tier1.empty:
        tier1.to_csv(outdir / "stage7C_v1n_tier1_rework_script_candidates.csv", index=False)
    else:
        pd.DataFrame().to_csv(outdir / "stage7C_v1n_tier1_rework_script_candidates.csv", index=False)

    summary_out = {
        "stage": STAGE,
        "run_label": RUN_LABEL,
        "final_decision": final_decision,
        "project_root": str(root),
        "output_dir": str(outdir),
        "v1m_dir": str(v1m_dir) if v1m_dir else None,
        "v1m_summary_file": str(files.get("summary")) if files.get("summary") else None,
        "v1m_final_decision": summary.get("final_decision"),
        "v1m_lowk_decision": summary.get("lowk_decision"),
        "v1m_candidate_vectors_found": summary.get("candidate_vectors_found"),
        "v1m_primary_candidate_count": summary.get("primary_candidate_count"),
        "v1m_lowk_metric_rows": summary.get("lowk_metric_rows"),
        "v1m_nontrivial_lowk_rows": summary.get("nontrivial_lowk_rows"),
        "v1m_null_p05_surviving_rows_summary": summary.get("null_p05_surviving_rows"),
        "robust_p05_detail_rows": int(len(robust_detail)),
        "robust_survivor_candidate_count": int(survivor_prov["candidate_id"].nunique()) if not survivor_prov.empty else 0,
        "distinct_lowk_independence_groups": distinct_groups,
        "unresolved_or_aggregated_unknown_survivor_rows": unresolved_unknown,
        "prior_entropy_records": summary.get("prior_entropy_records"),
        "prior_entropy_positive_or_supportive_records": summary.get("prior_entropy_positive_or_supportive_records"),
        "prior_operator_or_forward_reverse_records": summary.get("prior_operator_or_forward_reverse_records"),
        "tier1_rework_script_candidates_v1m": summary.get("tier1_rework_script_candidates"),
        "tier1_rework_script_candidates_loaded": int(len(tier1)) if not tier1.empty else 0,
        "hardened_null_recompute_requested": bool(do_harden),
        "hardened_null_n": int(args.n_null) if do_harden else 0,
        "hardened_null_rows": int(len(hard_df)),
        "hardened_null_candidate_summary_rows": int(len(hard_summary)),
        "hardened_null_candidates_surviving_p05": hard_survivors,
        "hardened_null_errors": hard_errors,
        "p_value_floor_note": P_VALUE_FLOOR_NOTE,
        "external_constants_rule": "No PDG/Planck/LambdaCDM/Friedmann/GR/cosmological constants may select, orient, fit, score, or upgrade internal witnesses.",
        "recommended_next_action": "Use v1n tables to write the manuscript evidence hierarchy; if unresolved survivor provenance remains, fork a targeted source-specific rework script for Stage-7B entropy trajectory and v1k primary vector exports.",
    }
    (outdir / "stage7C_v1n_summary.json").write_text(json.dumps(summary_out, indent=2), encoding="utf-8")

    ledger = []
    ledger.append("============================================================")
    ledger.append("ASCII LEDGER NOTE")
    ledger.append("Project: Quantum-Emergent Gravity")
    ledger.append(f"Stage: {STAGE}")
    ledger.append("Working Title: Manuscript Evidence and Provenance Hardening")
    ledger.append("============================================================")
    ledger.append("")
    ledger.append("FINAL DECISION")
    ledger.append("--------------")
    ledger.append(final_decision)
    ledger.append("")
    ledger.append("PURPOSE")
    ledger.append("-------")
    ledger.append("Trace v1m low-k survivor provenance, separate independent witnesses from duplicates,")
    ledger.append("build manuscript-facing evidence/risk/guardrail tables, and optionally run higher-N robust null recomputation.")
    ledger.append("")
    ledger.append("KEY COUNTS")
    ledger.append("----------")
    ledger.append(f"Robust p<0.05 survivor detail rows   : {len(robust_detail)}")
    ledger.append(f"Survivor candidate variants          : {summary_out['robust_survivor_candidate_count']}")
    ledger.append(f"Distinct low-k independence groups   : {distinct_groups}")
    ledger.append(f"Unresolved/aggregated survivor traces: {unresolved_unknown}")
    ledger.append(f"Hardened null recompute requested    : {do_harden}")
    ledger.append(f"Hardened null candidate survivors    : {hard_survivors}")
    ledger.append("")
    ledger.append("EVIDENCE POSTURE")
    ledger.append("----------------")
    ledger.append("The paper may expose substantial evidence pointing toward physical objects and dimensionless space-time/cosmological analogues,")
    ledger.append("but the main claim remains evidence-channel and operator-geometry focused, not direct derivation of spacetime or physical time.")
    ledger.append("")
    ledger.append("LOW-K SURVIVOR TRACE POLICY")
    ledger.append("---------------------------")
    ledger.append("UNKNOWN family labels are not accepted at face value. Each survivor is traced back to source file, stage, vector names,")
    ledger.append("family columns if present, source row counts, and prior ledger rows. Duplicated v1l imports are counted as variants,")
    ledger.append("not independent witnesses.")
    ledger.append("")
    ledger.append("OUTPUTS")
    ledger.append("-------")
    for fname in [
        "stage7C_v1n_lowk_survivor_provenance_trace.csv",
        "stage7C_v1n_independence_audit.csv",
        "stage7C_v1n_manuscript_evidence_table.csv",
        "stage7C_v1n_reviewer_risk_table.csv",
        "stage7C_v1n_claim_guardrail_table.csv",
        "stage7C_v1n_title_candidate_table.csv",
        "stage7C_v1n_hardened_null_summary.csv",
        "stage7C_v1n_summary.json",
    ]:
        ledger.append(f"{fname}: {outdir / fname}")
    ledger.append("")
    ledger.append("FORBIDDEN CLAIMS")
    ledger.append("----------------")
    for claim in FORBIDDEN_CLAIMS:
        ledger.append(f"- {claim}")
    ledger.append("")
    ledger.append("============================================================")
    ledger.append("END LEDGER NOTE")
    ledger.append("============================================================")
    (outdir / "stage7C_v1n_ledger_note.txt").write_text("\n".join(ledger), encoding="utf-8")

    if hard_errors:
        (outdir / "stage7C_v1n_hardened_null_errors.txt").write_text("\n".join(hard_errors), encoding="utf-8")
    else:
        (outdir / "stage7C_v1n_hardened_null_errors.txt").write_text("NO HARDENED NULL ERRORS\n", encoding="utf-8")

    echo("============================================================")
    echo("v1n complete")
    echo("============================================================")
    echo(f"Final decision                    : {final_decision}")
    echo(f"Robust survivor variants          : {summary_out['robust_survivor_candidate_count']}")
    echo(f"Distinct independence groups      : {distinct_groups}")
    echo(f"Unresolved/aggregated traces      : {unresolved_unknown}")
    echo(f"Hardened null survivors           : {hard_survivors}")
    echo(f"Output dir                        : {outdir}")


if __name__ == "__main__":
    main()
