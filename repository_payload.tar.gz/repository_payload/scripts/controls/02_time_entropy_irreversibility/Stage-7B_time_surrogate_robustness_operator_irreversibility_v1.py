#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
========================================================================
Project: Quantum-Emergent Gravity
Stage: 7B
Author: Arturo Ortiz-Tapia
Script: Stage-7B_time_surrogate_robustness_operator_irreversibility_v1.py
Build date: 2026-05-30
========================================================================

Stage-7B begins the first null-controlled test of whether QEG contains an
internal time surrogate. Stage-7A identified candidate semantic/time-
surrogate evidence and established strict claim guardrails, but it did not
confirm time. Stage-7B therefore tests the strongest candidates under
forward/reverse recursion, randomized and low-k matched nulls, family-
conditioned perturbations, entropy state-space declarations, and space-time
surrogate coupling diagnostics. The goal is not to derive physical time or
spacetime, but to decide whether QEG operator geometry contains a lineage-
preserved, family-stable, null-resistant intrinsic ordering variable.

NON-NEGOTIABLE RULES IMPLEMENTED HERE
-------------------------------------
- no Omega_m fitting
- no Omega_m rescaling
- no physical-time claim
- no physical-spacetime claim
- no QM interpretation claim
- no entropy claim without state-space declaration
- no synthetic detached recursion
- no tautological reconstruction using target as source
- preserve BARI / NUFIT / VALENCIA lineage when present
- preserve negative results
- preserve Stage-6 frozen comparators
- preserve Stage-7A semantic boundaries

DESIGN NOTE
-----------
This script is deliberately conservative. Textual Stage-7A evidence is used
only to select candidate files. It is never treated as empirical proof.
If inputs are missing or candidate tables do not contain usable recursive /
ordered numerical structure, the script returns E_REDESIGN_REQUIRED_INPUTS_
INSUFFICIENT rather than forcing a result.

Expected Dakini root:
    /home/dakini/Downloads/010-Quantum_Emergent_Gravity

Recommended output directory:
    metric_stage_7B_outputs/time_surrogate_robustness_operator_irreversibility_v1
========================================================================
"""

from __future__ import annotations

import argparse
import json
import math
import os
import re
import sys
import traceback
from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

# Matplotlib is optional at runtime. Tables and JSON are written first.
try:
    import matplotlib.pyplot as plt
except Exception:  # pragma: no cover
    plt = None


# ---------------------------------------------------------------------
# Frozen policy constants. These are recorded for guardrails only.
# They are NOT fitted, optimized, rescaled, refined, or promoted here.
# ---------------------------------------------------------------------
OMEGA_M_BENCHMARK_FROZEN = 0.315
QEG_GLOBAL_MU_CONSERVATIVE_FROZEN = 0.327995
QEG_EARLY_CENTRAL_SEPARATION_SHARP_CANDIDATE_FROZEN = 0.317696468538139
REJECTED_WRONG_SOURCE_VALUES = {
    "global_mu_wrong_source": 0.5,
    "early_central_separation_wrong_source": 0.406087652955405,
    "rejected_label": "WRONG_SOURCE_PRIORITY_FROM_STAGE6YI_BOOKKEEPING_PANEL",
}

TRUE_FAMILIES = ["BARI", "NUFIT", "VALENCIA"]
ALL_FAMILIES = TRUE_FAMILIES + ["POOLED"]
RNG_SEED = 7731
EPS = 1.0e-12

OUTPUT_FILES_REQUIRED = [
    "stage7B_candidate_file_queue.csv",
    "stage7B_source_role_bias_audit.csv",
    "stage7B_forward_reverse_directionality_table.csv",
    "stage7B_recursion_directionality_summary.json",
    "stage7B_null_control_results.csv",
    "stage7B_null_survival_scores.csv",
    "stage7B_family_perturbation_audit.csv",
    "stage7B_family_stability_summary.json",
    "stage7B_entropy_state_space_audit.csv",
    "stage7B_entropy_trajectory_tests.csv",
    "stage7B_spacetime_surrogate_coupling_table.csv",
    "stage7B_spacetime_surrogate_coupling_summary.json",
    "stage7B_claim_status_table.csv",
    "stage7B_final_verdict.txt",
    "stage7B_claim_guardrails.md",
    "stage7B_summary.json",
    "stage7C_recommendation.txt",
]

MANDATORY_7A_FILES = [
    "stage7A_summary.json",
    "stage7A_ledger_note.txt",
    "stage7A_claim_guardrails.md",
    "stage7A_recommended_stage7B_handoff.txt",
    "stage7A_semantic_object_registry.csv",
    "stage7A_external_benchmark_permission_table.csv",
    "stage7A_entropy_state_space_registry.csv",
    "stage7A_time_surrogate_evidence_inventory.csv",
    "stage7A_forward_reverse_recursion_audit.csv",
    "stage7A_spacetime_coupling_diagnostics.csv",
    "stage7A_claim_status_ladder.csv",
    "stage7A_retrospective_source_inventory.csv",
    "stage7A_discovered_scalar_pool_REVIEW_ONLY.csv",
]

PRIORITY_DIRS = [
    "metric_stage_7A_outputs/semantic_calibration_entropic_arrow_v1",
    "metric_stage_6Yd_outputs",
    "metric_stage_6Yf_outputs",
    "metric_stage_6Yi_outputs",
    "metric_stage_6Yn_v1c_figures_operator_response_outputs",
    "metric_stage_6U_outputs",
    "metric_stage_6T_outputs",
    "metric_stage_6S_outputs",
    "metric_stage_6Q_outputs",
    "metric_stage_6O_outputs",
    "metric_stage_6P_outputs",
]

VERDICT_ORDER = [
    "A_TIME_SURROGATE_SUPPORTED_INTERNAL_ONLY",
    "B_OPERATOR_IRREVERSIBILITY_SUPPORTED_TIME_SURROGATE_PARTIAL",
    "C_CANDIDATE_SIGNAL_PRESENT_NOT_CLAIM_GRADE",
    "D_NO_TIME_SURROGATE_RELAXATION_ARTIFACT",
    "E_REDESIGN_REQUIRED_INPUTS_INSUFFICIENT",
]


# ---------------------------------------------------------------------
# Console style helpers
# ---------------------------------------------------------------------
def echo(title: str, body: Optional[str] = None) -> None:
    line = "=" * 72
    print(f"\n{line}\n{title}\n{line}")
    if body:
        print(body)


def warn(msg: str) -> None:
    print(f"[WARN] {msg}")


def safe_mkdir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")


def json_dump(obj: Any, path: Path) -> None:
    with path.open("w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, sort_keys=True, default=str)


def write_text(path: Path, text: str) -> None:
    path.write_text(text, encoding="utf-8")


# ---------------------------------------------------------------------
# Root / path discovery
# ---------------------------------------------------------------------
def is_project_root(p: Path) -> bool:
    if not p.exists() or not p.is_dir():
        return False
    clues = [
        p / "metric_stage_7A_outputs",
        p / "metric_stage_6Yd_outputs",
        p / "metric_stage_6O_outputs",
        p / "metric_stage_6P_outputs",
        p / "metric_stage_6Q_outputs",
    ]
    return any(x.exists() for x in clues) or p.name == "010-Quantum_Emergent_Gravity"


def detect_project_root(user_root: Optional[str] = None) -> Path:
    if user_root:
        candidate = Path(user_root).expanduser().resolve()
        if candidate.exists():
            return candidate
        warn(f"Requested root does not exist: {candidate}. Falling back to autodetection.")

    expected = Path("/home/dakini/Downloads/010-Quantum_Emergent_Gravity")
    if expected.exists():
        return expected.resolve()

    cwd = Path.cwd().resolve()
    for p in [cwd] + list(cwd.parents):
        if is_project_root(p):
            return p

    # If launched from a scripts directory inside the project, parent promotion.
    if cwd.name.lower().endswith("scripts") or "metric_stage_7b_scripts" in cwd.name.lower():
        for p in cwd.parents:
            if is_project_root(p):
                return p

    # Conservative fallback: use cwd, but the final verdict will likely be E.
    warn("Could not detect canonical QEG root. Using current working directory.")
    return cwd


def relpath(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve()))
    except Exception:
        return str(path)


def build_file_index(root: Path, max_files: int = 20000) -> Dict[str, List[Path]]:
    index: Dict[str, List[Path]] = defaultdict(list)
    count = 0
    for dirpath, dirnames, filenames in os.walk(root):
        # Avoid obvious cache / venv / hidden detours.
        dirnames[:] = [d for d in dirnames if not d.startswith(".") and d not in {"__pycache__", "venv", "env", ".git"}]
        for fn in filenames:
            lower = fn.lower()
            if lower.endswith((".csv", ".json", ".txt", ".md")):
                p = Path(dirpath) / fn
                index[fn].append(p)
                index[lower].append(p)
                count += 1
                if count >= max_files:
                    warn(f"File index capped at {max_files} files.")
                    return index
    return index


def resolve_candidate_path(raw: Any, root: Path, file_index: Dict[str, List[Path]]) -> Tuple[Optional[Path], str]:
    if raw is None or (isinstance(raw, float) and not math.isfinite(raw)):
        return None, "empty"
    s = str(raw).strip().strip('"').strip("'")
    if not s or s.lower() in {"nan", "none", "null"}:
        return None, "empty"

    # Remove line/fragment suffixes that sometimes appear in inventories.
    s_clean = re.sub(r"[#?].*$", "", s).strip()
    p = Path(s_clean).expanduser()
    if p.is_absolute() and p.exists():
        return p.resolve(), "absolute"

    rp = root / s_clean
    if rp.exists():
        return rp.resolve(), "root_relative"

    # basename lookup.
    base = Path(s_clean).name
    if base in file_index:
        return file_index[base][0].resolve(), "basename_index"
    if base.lower() in file_index:
        return file_index[base.lower()][0].resolve(), "basename_index_lower"
    return None, "unresolved"


# ---------------------------------------------------------------------
# Robust table loading
# ---------------------------------------------------------------------
def try_read_csv(path: Path) -> Optional[pd.DataFrame]:
    try:
        return pd.read_csv(path)
    except UnicodeDecodeError:
        try:
            return pd.read_csv(path, encoding="latin-1")
        except Exception:
            return None
    except Exception:
        return None


def try_read_json(path: Path) -> Any:
    try:
        with path.open("r", encoding="utf-8") as f:
            return json.load(f)
    except UnicodeDecodeError:
        with path.open("r", encoding="latin-1") as f:
            return json.load(f)


def flatten_json_to_df(obj: Any, source_name: str) -> pd.DataFrame:
    if isinstance(obj, list):
        try:
            return pd.json_normalize(obj)
        except Exception:
            return pd.DataFrame({"value": [str(x) for x in obj], "source": source_name})
    if isinstance(obj, dict):
        rows = []
        for k, v in obj.items():
            if isinstance(v, (dict, list)):
                rows.append({"key": k, "value": json.dumps(v, default=str), "source": source_name})
            else:
                rows.append({"key": k, "value": v, "source": source_name})
        return pd.DataFrame(rows)
    return pd.DataFrame({"value": [str(obj)], "source": source_name})


def safe_read_table(path: Path) -> Optional[pd.DataFrame]:
    lower = path.name.lower()
    try:
        if lower.endswith(".csv"):
            return try_read_csv(path)
        if lower.endswith(".json"):
            return flatten_json_to_df(try_read_json(path), path.name)
        if lower.endswith((".txt", ".md")):
            txt = path.read_text(encoding="utf-8", errors="replace")
            lines = [ln.rstrip("\n") for ln in txt.splitlines()]
            return pd.DataFrame({"line_number": np.arange(1, len(lines) + 1), "text": lines})
    except Exception:
        return None
    return None


def find_col(df: pd.DataFrame, patterns: Sequence[str], prefer_numeric: Optional[bool] = None) -> Optional[str]:
    if df is None or df.empty:
        return None
    cols = list(df.columns)
    lower_map = {c: str(c).lower() for c in cols}
    for pat in patterns:
        rx = re.compile(pat, re.I)
        matches = [c for c in cols if rx.search(lower_map[c])]
        if prefer_numeric is not None:
            matches2 = [c for c in matches if pd.api.types.is_numeric_dtype(df[c]) == prefer_numeric]
            if matches2:
                return matches2[0]
        if matches:
            return matches[0]
    return None


def extract_stage_from_text(s: Any) -> str:
    txt = str(s)
    m = re.search(r"stage[_\- ]?(\d+[a-zA-Z]*|7A|7B|6Y[a-zA-Z]*)", txt, re.I)
    if m:
        return "Stage-" + m.group(1)
    m = re.search(r"metric_stage_([^/\\]+)", txt, re.I)
    if m:
        return "Stage-" + m.group(1)
    return "UNKNOWN"


def infer_role_from_text(s: Any) -> str:
    txt = str(s).lower()
    role_terms = [
        "operator", "recursion", "transport", "persistence", "convergence",
        "null", "perturbation", "entropy", "information", "ncd", "family",
        "spacetime", "coupling", "invariant", "cosmology", "curvature",
        "summary", "guardrail", "ledger", "figure", "source", "benchmark",
    ]
    hits = [t for t in role_terms if t in txt]
    return "+".join(hits[:4]) if hits else "unclassified"


def infer_family_values(df: pd.DataFrame) -> Tuple[Optional[str], List[str]]:
    if df is None or df.empty:
        return None, []
    for c in df.columns:
        vals = df[c].dropna().astype(str).str.upper()
        present = [fam for fam in TRUE_FAMILIES if vals.str.contains(fam, regex=False).any()]
        if present:
            return c, present
    return None, []


def numeric_matrix_from_df(
    df: pd.DataFrame,
    max_rows: int = 800,
    max_cols: int = 64,
    exclude_cols: Optional[Sequence[str]] = None,
) -> Tuple[Optional[np.ndarray], List[str], Dict[str, Any]]:
    meta: Dict[str, Any] = {"reason": ""}
    if df is None or df.empty:
        meta["reason"] = "empty_dataframe"
        return None, [], meta

    exclude = set(exclude_cols or [])
    num_cols = []
    for c in df.columns:
        if c in exclude:
            continue
        if pd.api.types.is_numeric_dtype(df[c]):
            s = pd.to_numeric(df[c], errors="coerce")
            if s.notna().sum() >= 4 and s.nunique(dropna=True) > 1:
                # Avoid obvious row identifiers as much as possible.
                lc = str(c).lower()
                if re.search(r"(^id$|row_id|index$|line_number|file_id)", lc):
                    continue
                num_cols.append(c)

    if len(num_cols) < 2:
        meta["reason"] = "fewer_than_two_numeric_columns"
        return None, [], meta

    Xdf = df[num_cols].copy()
    for c in list(Xdf.columns):
        Xdf[c] = pd.to_numeric(Xdf[c], errors="coerce")
    Xdf = Xdf.dropna(axis=0, how="all")
    if Xdf.shape[0] < 4:
        meta["reason"] = "fewer_than_four_numeric_rows"
        return None, [], meta

    Xdf = Xdf.fillna(Xdf.median(numeric_only=True)).fillna(0.0)

    # Reduce rows evenly if necessary.
    if Xdf.shape[0] > max_rows:
        idx = np.linspace(0, Xdf.shape[0] - 1, max_rows).astype(int)
        Xdf = Xdf.iloc[idx].reset_index(drop=True)
        meta["row_downsampled_to"] = max_rows

    # Keep highest-variance columns if necessary.
    if Xdf.shape[1] > max_cols:
        variances = Xdf.var(axis=0).sort_values(ascending=False)
        keep = list(variances.head(max_cols).index)
        Xdf = Xdf[keep]
        meta["column_downsampled_to"] = max_cols

    X = Xdf.to_numpy(dtype=float)
    finite_rows = np.isfinite(X).all(axis=1)
    X = X[finite_rows]
    if X.shape[0] < 4 or X.shape[1] < 2:
        meta["reason"] = "insufficient_finite_matrix"
        return None, [], meta

    meta["reason"] = "ok"
    meta["n_rows"] = int(X.shape[0])
    meta["n_cols"] = int(X.shape[1])
    return X, list(Xdf.columns), meta


def order_dataframe(df: pd.DataFrame) -> Tuple[pd.DataFrame, Optional[str]]:
    order_col = find_col(
        df,
        patterns=[r"(^|_)(step|iter|iteration|epoch|round|time|n|order|recursion|pass|generation)($|_)", r"sequence", r"rank"],
        prefer_numeric=True,
    )
    if order_col is not None:
        try:
            return df.sort_values(order_col, kind="mergesort").reset_index(drop=True), order_col
        except Exception:
            return df.reset_index(drop=True), None
    return df.reset_index(drop=True), None


# ---------------------------------------------------------------------
# Numerical primitives
# ---------------------------------------------------------------------
def zscore_columns(X: np.ndarray) -> np.ndarray:
    X = np.array(X, dtype=float)
    mu = np.nanmean(X, axis=0, keepdims=True)
    sd = np.nanstd(X, axis=0, keepdims=True)
    sd[sd < EPS] = 1.0
    Z = (X - mu) / sd
    Z[~np.isfinite(Z)] = 0.0
    return Z


def prob_rows(X: np.ndarray) -> np.ndarray:
    A = np.abs(np.array(X, dtype=float))
    A[~np.isfinite(A)] = 0.0
    row_sum = A.sum(axis=1, keepdims=True)
    bad = row_sum[:, 0] <= EPS
    if np.any(bad):
        A[bad, :] = 1.0
        row_sum = A.sum(axis=1, keepdims=True)
    return A / np.maximum(row_sum, EPS)


def entropy(p: np.ndarray) -> np.ndarray:
    p = np.maximum(np.array(p, dtype=float), EPS)
    h = -np.sum(p * np.log(p), axis=1)
    if p.shape[1] > 1:
        h = h / np.log(p.shape[1])
    return h


def js_distance(p: np.ndarray, q: np.ndarray) -> np.ndarray:
    p = np.maximum(np.array(p, dtype=float), EPS)
    q = np.maximum(np.array(q, dtype=float), EPS)
    p = p / np.maximum(p.sum(axis=-1, keepdims=True), EPS)
    q = q / np.maximum(q.sum(axis=-1, keepdims=True), EPS)
    m = 0.5 * (p + q)
    kl_pm = np.sum(p * (np.log(p) - np.log(m)), axis=-1)
    kl_qm = np.sum(q * (np.log(q) - np.log(m)), axis=-1)
    return np.sqrt(np.maximum(0.5 * (kl_pm + kl_qm), 0.0))


def safe_corr(a: Sequence[float], b: Sequence[float]) -> float:
    x = np.array(a, dtype=float)
    y = np.array(b, dtype=float)
    mask = np.isfinite(x) & np.isfinite(y)
    if mask.sum() < 3:
        return float("nan")
    x = x[mask]
    y = y[mask]
    if np.std(x) < EPS or np.std(y) < EPS:
        return float("nan")
    return float(np.corrcoef(x, y)[0, 1])


def linear_slope(y: Sequence[float]) -> float:
    yy = np.array(y, dtype=float)
    mask = np.isfinite(yy)
    if mask.sum() < 3:
        return float("nan")
    t = np.linspace(0.0, 1.0, mask.sum())
    return float(np.polyfit(t, yy[mask], 1)[0])


def monotone_fraction_decrease(y: Sequence[float]) -> float:
    yy = np.array(y, dtype=float)
    yy = yy[np.isfinite(yy)]
    if len(yy) < 2:
        return float("nan")
    return float(np.mean(np.diff(yy) <= EPS))


def lowk_energy_fraction(series: Sequence[float], keep_frac: float = 0.12) -> float:
    x = np.array(series, dtype=float)
    x = x[np.isfinite(x)]
    if len(x) < 4:
        return float("nan")
    x = x - np.mean(x)
    spec = np.abs(np.fft.rfft(x)) ** 2
    if len(spec) <= 1 or spec.sum() <= EPS:
        return 0.0
    k = max(1, int(math.ceil(keep_frac * len(spec))))
    return float(spec[:k].sum() / np.maximum(spec.sum(), EPS))


def effective_rank_from_singular_values(s: np.ndarray) -> float:
    ss = np.array(s, dtype=float)
    ss = ss[np.isfinite(ss) & (ss > EPS)]
    if len(ss) == 0:
        return float("nan")
    p = ss / ss.sum()
    return float(np.exp(-np.sum(p * np.log(np.maximum(p, EPS)))))


def operator_features(X: np.ndarray) -> Dict[str, float]:
    Z = zscore_columns(X)
    out: Dict[str, float] = {}
    try:
        _, s, _ = np.linalg.svd(Z, full_matrices=False)
        out["effective_rank"] = effective_rank_from_singular_values(s)
        if s.sum() > EPS:
            energy = s**2 / np.maximum(np.sum(s**2), EPS)
            out["energy_rank1"] = float(energy[0]) if len(energy) else float("nan")
            out["energy_rank2"] = float(np.sum(energy[:2])) if len(energy) >= 2 else out["energy_rank1"]
        else:
            out["energy_rank1"] = float("nan")
            out["energy_rank2"] = float("nan")
    except Exception:
        out["effective_rank"] = float("nan")
        out["energy_rank1"] = float("nan")
        out["energy_rank2"] = float("nan")

    if Z.shape[0] >= 2:
        C = Z[:-1].T @ Z[1:] / max(Z.shape[0] - 1, 1)
        normC = np.linalg.norm(C) + EPS
        out["operator_asymmetry"] = float(np.linalg.norm(C - C.T) / normC)
        # Toeplitz deviation: replace each diagonal by its mean.
        T = np.zeros_like(C)
        n = C.shape[0]
        for d in range(-n + 1, n):
            vals = np.diag(C, k=d)
            if len(vals):
                T += np.diag(np.full(len(vals), np.mean(vals)), k=d)
        out["toeplitz_deviation"] = float(np.linalg.norm(C - T) / normC)
    else:
        out["operator_asymmetry"] = float("nan")
        out["toeplitz_deviation"] = float("nan")

    row_signal = np.mean(Z, axis=1)
    out["lowk_retention"] = lowk_energy_fraction(row_signal)
    return out


def sector_features(X: np.ndarray) -> Dict[str, float]:
    P = prob_rows(X)
    m = P.shape[1]
    early_end = max(1, int(0.20 * m))
    central_start = int(0.40 * m)
    central_end = max(central_start + 1, int(0.62 * m))
    boundary_cols = list(range(early_end)) + list(range(max(central_end, int(0.80 * m)), m))
    bulk_cols = list(range(central_start, central_end))
    idx = np.arange(m, dtype=float)
    center_mass = P @ idx / max(m - 1, 1)
    early_mass = P[:, :early_end].sum(axis=1)
    central_mass = P[:, central_start:central_end].sum(axis=1)
    boundary_mass = P[:, boundary_cols].sum(axis=1) if boundary_cols else np.zeros(P.shape[0])
    bulk_mass = P[:, bulk_cols].sum(axis=1) if bulk_cols else np.zeros(P.shape[0])
    return {
        "early_mass_mean": float(np.mean(early_mass)),
        "central_mass_mean": float(np.mean(central_mass)),
        "boundary_mass_mean": float(np.mean(boundary_mass)),
        "bulk_mass_mean": float(np.mean(bulk_mass)),
        "early_mass_drift": float(np.std(early_mass)),
        "central_mass_drift": float(np.std(central_mass)),
        "center_of_mass_mean": float(np.mean(center_mass)),
        "center_of_mass_drift": float(np.std(center_mass)),
        "lobe_separation_proxy": float(max(0.0, np.mean(center_mass) - 0.15)),
        "early_central_mass_ratio": float(np.mean(early_mass) / np.maximum(np.mean(central_mass), EPS)),
    }


def directionality_metrics(X: np.ndarray, target: Optional[np.ndarray] = None) -> Dict[str, float]:
    if X is None or X.shape[0] < 4 or X.shape[1] < 2:
        return {"usable": 0.0, "directionality_score": float("nan")}

    Z = zscore_columns(X)
    P = prob_rows(Z)
    if target is None:
        target_vec = P[-1]
    else:
        target_vec = prob_rows(np.array(target, dtype=float).reshape(1, -1))[0]
        if target_vec.shape[0] != P.shape[1]:
            target_vec = P[-1]

    D = js_distance(P, target_vec.reshape(1, -1))
    t = np.linspace(0.0, 1.0, len(D))
    corr_to_terminal = safe_corr(t, -D)
    if not math.isfinite(corr_to_terminal):
        corr_scaled = 0.5
    else:
        corr_scaled = float(np.clip((corr_to_terminal + 1.0) / 2.0, 0.0, 1.0))

    monotone = monotone_fraction_decrease(D)
    if not math.isfinite(monotone):
        monotone = 0.0

    steps = np.diff(Z, axis=0)
    step_norm = np.linalg.norm(steps, axis=1)
    step_smoothness = 1.0 / (1.0 + float(np.nanmean(np.abs(np.diff(step_norm)))) if len(step_norm) > 1 else 1.0)
    step_smoothness = float(np.clip(step_smoothness, 0.0, 1.0))

    lowk = lowk_energy_fraction(D)
    if not math.isfinite(lowk):
        lowk = 0.0

    h = entropy(P)
    entropy_slope = linear_slope(h)
    distance_slope = linear_slope(D)

    # Score is intentionally conservative and purely internal.
    score = 0.45 * corr_scaled + 0.25 * monotone + 0.15 * step_smoothness + 0.15 * lowk
    score = float(np.clip(score, 0.0, 1.0))

    out = {
        "usable": 1.0,
        "directionality_score": score,
        "corr_time_to_terminal_contraction": float(corr_to_terminal) if math.isfinite(corr_to_terminal) else float("nan"),
        "terminal_contraction_scaled": corr_scaled,
        "monotone_terminal_distance_fraction": float(monotone),
        "step_smoothness": step_smoothness,
        "lowk_distance_retention": float(lowk),
        "entropy_slope": float(entropy_slope) if math.isfinite(entropy_slope) else float("nan"),
        "terminal_distance_slope": float(distance_slope) if math.isfinite(distance_slope) else float("nan"),
        "initial_terminal_js_distance": float(D[0]) if len(D) else float("nan"),
        "mean_terminal_js_distance": float(np.mean(D)) if len(D) else float("nan"),
    }
    out.update(operator_features(X))
    out.update(sector_features(X))
    return out


# ---------------------------------------------------------------------
# Nulls and perturbations
# ---------------------------------------------------------------------
def row_permutation_null(X: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    return X[rng.permutation(X.shape[0])]


def column_independent_shuffle_null(X: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    Y = np.array(X, copy=True)
    for j in range(Y.shape[1]):
        Y[:, j] = Y[rng.permutation(Y.shape[0]), j]
    return Y


def phase_randomized_null(X: np.ndarray, rng: np.random.Generator, preserve_lowk: int = 0) -> np.ndarray:
    X = np.array(X, dtype=float)
    Y = np.zeros_like(X)
    n = X.shape[0]
    for j in range(X.shape[1]):
        x = X[:, j]
        mu = np.mean(x)
        spec = np.fft.rfft(x - mu)
        amp = np.abs(spec)
        phase = np.angle(spec)
        random_phase = rng.uniform(0, 2 * np.pi, len(spec))
        if preserve_lowk > 0:
            random_phase[:preserve_lowk] = phase[:preserve_lowk]
        random_phase[0] = 0.0
        if n % 2 == 0 and len(random_phase) > 1:
            random_phase[-1] = 0.0
        spec2 = amp * np.exp(1j * random_phase)
        Y[:, j] = np.fft.irfft(spec2, n=n) + mu
    return Y


def lowk_matched_null(X: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    preserve = max(2, int(0.12 * (X.shape[0] // 2 + 1)))
    return phase_randomized_null(X, rng, preserve_lowk=preserve)


def transport_preserving_null(X: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    Y = np.array(X, copy=True)
    for j in range(Y.shape[1]):
        shift = int(rng.integers(0, max(1, Y.shape[0])))
        Y[:, j] = np.roll(Y[:, j], shift)
    return Y


def sector_mass_preserving_null(X: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    Y = np.array(X, copy=True)
    m = Y.shape[1]
    sectors = [range(0, max(1, int(0.2 * m))), range(int(0.2 * m), int(0.62 * m)), range(int(0.62 * m), m)]
    for rows in [slice(None)]:
        for sec in sectors:
            cols = list(sec)
            if len(cols) > 1:
                for i in range(Y.shape[0]):
                    Y[i, cols] = Y[i, rng.permutation(cols)]
    return Y


def symmetric_recursion_null(X: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    return 0.5 * (X + X[::-1])


def additive_noise(X: np.ndarray, rng: np.random.Generator, scale: float = 0.05) -> np.ndarray:
    sd = np.nanstd(X, axis=0, keepdims=True)
    sd[sd < EPS] = 1.0
    return X + rng.normal(0.0, scale, size=X.shape) * sd


def multiplicative_noise(X: np.ndarray, rng: np.random.Generator, scale: float = 0.05) -> np.ndarray:
    return X * (1.0 + rng.normal(0.0, scale, size=X.shape))


def local_bin_dropout(X: np.ndarray, rng: np.random.Generator, frac: float = 0.08) -> np.ndarray:
    Y = np.array(X, copy=True)
    n_drop = max(1, int(frac * Y.shape[0]))
    idx = rng.choice(Y.shape[0], size=n_drop, replace=False)
    med = np.median(Y, axis=0)
    Y[idx, :] = med
    return Y


def mask_columns(X: np.ndarray, sector: str) -> np.ndarray:
    Y = np.array(X, copy=True)
    m = Y.shape[1]
    if sector == "lobe_sector_mask":
        cols = list(range(0, max(1, int(0.20 * m))))
    elif sector == "boundary_sector_mask":
        cols = list(range(0, max(1, int(0.20 * m)))) + list(range(int(0.80 * m), m))
    elif sector == "bulk_sector_mask":
        cols = list(range(int(0.40 * m), max(int(0.40 * m) + 1, int(0.62 * m))))
    else:
        cols = []
    if cols:
        Y[:, cols] = np.median(Y[:, cols], axis=0)
    return Y


def lowk_truncation(X: np.ndarray, keep_frac: float = 0.15) -> np.ndarray:
    Y = np.zeros_like(X, dtype=float)
    n = X.shape[0]
    k_keep = max(1, int(keep_frac * (n // 2 + 1)))
    for j in range(X.shape[1]):
        spec = np.fft.rfft(X[:, j] - np.mean(X[:, j]))
        spec[k_keep:] = 0
        Y[:, j] = np.fft.irfft(spec, n=n) + np.mean(X[:, j])
    return Y


def highk_truncation(X: np.ndarray, drop_frac: float = 0.15) -> np.ndarray:
    # Remove lowest modes, retaining high-frequency contrast.
    Y = np.zeros_like(X, dtype=float)
    n = X.shape[0]
    k_drop = max(1, int(drop_frac * (n // 2 + 1)))
    for j in range(X.shape[1]):
        spec = np.fft.rfft(X[:, j] - np.mean(X[:, j]))
        spec[:k_drop] = 0
        Y[:, j] = np.fft.irfft(spec, n=n)
    return Y


def coordinate_remap(X: np.ndarray) -> np.ndarray:
    # Benign rank-uniformization along row order; preserves row count.
    n = X.shape[0]
    idx = np.linspace(0, n - 1, n)
    warp = np.linspace(0, 1, n) ** 1.2
    new_idx = warp * (n - 1)
    Y = np.zeros_like(X, dtype=float)
    for j in range(X.shape[1]):
        Y[:, j] = np.interp(idx, new_idx, X[:, j])
    return Y


NULL_GENERATORS = {
    "row_permutation_null": row_permutation_null,
    "time_order_permutation_null": row_permutation_null,
    "amplitude_matched_column_shuffle_null": column_independent_shuffle_null,
    "phase_randomization_null": phase_randomized_null,
    "low_k_matched_null": lowk_matched_null,
    "transport_preserving_circular_shift_null": transport_preserving_null,
    "sector_mass_preserving_null": sector_mass_preserving_null,
    "operator_spectrum_preserving_phase_null": phase_randomized_null,
    "symmetric_recursion_null": symmetric_recursion_null,
}

PERTURBATIONS = {
    "additive_noise_5pct": lambda X, rng: additive_noise(X, rng, 0.05),
    "multiplicative_noise_5pct": lambda X, rng: multiplicative_noise(X, rng, 0.05),
    "local_bin_dropout_8pct": lambda X, rng: local_bin_dropout(X, rng, 0.08),
    "coordinate_remapping_rank_warp": lambda X, rng: coordinate_remap(X),
    "lobe_sector_mask": lambda X, rng: mask_columns(X, "lobe_sector_mask"),
    "boundary_sector_mask": lambda X, rng: mask_columns(X, "boundary_sector_mask"),
    "bulk_sector_mask": lambda X, rng: mask_columns(X, "bulk_sector_mask"),
    "low_k_truncation": lambda X, rng: lowk_truncation(X, 0.15),
    "high_k_truncation": lambda X, rng: highk_truncation(X, 0.15),
}


@dataclass
class CandidateData:
    candidate_id: str
    source_path: Path
    display_path: str
    stage: str
    role: str
    dataframe: pd.DataFrame
    order_column: Optional[str]
    numeric_columns: List[str]
    X: np.ndarray
    family_column: Optional[str]
    families_present: List[str]


# ---------------------------------------------------------------------
# Stage-7A loading and candidate queue
# ---------------------------------------------------------------------
def locate_stage7a_dir(root: Path) -> Path:
    expected = root / "metric_stage_7A_outputs" / "semantic_calibration_entropic_arrow_v1"
    if expected.exists():
        return expected
    # Try to find a directory containing stage7A_summary.json.
    for p in root.rglob("stage7A_summary.json"):
        return p.parent
    return expected


def load_stage7a_inputs(root: Path, outdir: Path) -> Tuple[Path, Dict[str, Path], List[str]]:
    stage7a_dir = locate_stage7a_dir(root)
    found: Dict[str, Path] = {}
    missing: List[str] = []
    for fn in MANDATORY_7A_FILES:
        p = stage7a_dir / fn
        if p.exists():
            found[fn] = p
        else:
            missing.append(fn)
    audit = pd.DataFrame(
        [{"filename": fn, "status": "FOUND", "path": str(path)} for fn, path in found.items()]
        + [{"filename": fn, "status": "MISSING", "path": str(stage7a_dir / fn)} for fn in missing]
    )
    audit.to_csv(outdir / "stage7B_stage7A_input_presence_audit.csv", index=False)
    return stage7a_dir, found, missing


def add_candidates_from_df(
    rows: List[Dict[str, Any]],
    df: Optional[pd.DataFrame],
    source_label: str,
    root: Path,
    file_index: Dict[str, List[Path]],
) -> None:
    if df is None or df.empty:
        return
    path_col = find_col(df, [r"absolute.*path", r"source.*path", r"file.*path", r"path", r"source_file", r"filename", r"file", r"source"])
    score_col = find_col(df, [r"evidence.*score", r"priority", r"score", r"rank", r"weight"], prefer_numeric=True)
    role_col = find_col(df, [r"role", r"category", r"semantic", r"type", r"class"])
    stage_col = find_col(df, [r"stage", r"source_stage"])

    # Fallback: if there is no path column but text line contains filenames, inspect all object columns.
    candidate_cols = [path_col] if path_col else []
    if not candidate_cols:
        for c in df.columns:
            if df[c].dtype == object or str(df[c].dtype).startswith("string"):
                sample = " ".join(df[c].dropna().astype(str).head(20).tolist()).lower()
                if any(ext in sample for ext in [".csv", ".json", ".txt", ".md"]):
                    candidate_cols.append(c)
    if not candidate_cols:
        return

    for _, row in df.iterrows():
        raw_path = None
        for c in candidate_cols:
            val = row.get(c)
            if pd.notna(val) and str(val).strip():
                raw_path = val
                break
        resolved, resolution = resolve_candidate_path(raw_path, root, file_index)
        path_text = str(raw_path) if raw_path is not None else ""
        stage = str(row.get(stage_col, "")) if stage_col else extract_stage_from_text(path_text)
        if not stage or stage.lower() == "nan":
            stage = extract_stage_from_text(path_text)
        role = str(row.get(role_col, "")) if role_col else infer_role_from_text(path_text)
        if not role or role.lower() == "nan":
            role = infer_role_from_text(path_text)
        score = row.get(score_col, np.nan) if score_col else np.nan
        try:
            score = float(score)
        except Exception:
            score = np.nan
        rows.append({
            "source_inventory": source_label,
            "raw_path": path_text,
            "resolved_path": str(resolved) if resolved else "",
            "resolution_status": resolution,
            "exists": bool(resolved and resolved.exists()),
            "stage": stage,
            "role": role,
            "evidence_score": score,
            "keyword_evidence_only": True,
        })


def discover_priority_files(root: Path, file_index: Dict[str, List[Path]]) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for d in PRIORITY_DIRS:
        p = root / d
        if not p.exists():
            rows.append({
                "source_inventory": "priority_dir_scan",
                "raw_path": d,
                "resolved_path": "",
                "resolution_status": "missing_priority_dir",
                "exists": False,
                "stage": extract_stage_from_text(d),
                "role": infer_role_from_text(d),
                "evidence_score": np.nan,
                "keyword_evidence_only": False,
            })
            continue
        for fp in p.rglob("*"):
            if fp.is_file() and fp.name.lower().endswith((".csv", ".json")):
                rows.append({
                    "source_inventory": "priority_dir_scan",
                    "raw_path": relpath(fp, root),
                    "resolved_path": str(fp.resolve()),
                    "resolution_status": "priority_scan",
                    "exists": True,
                    "stage": extract_stage_from_text(str(fp)),
                    "role": infer_role_from_text(str(fp)),
                    "evidence_score": np.nan,
                    "keyword_evidence_only": False,
                })
    return rows


def build_candidate_queue(root: Path, stage7a_files: Dict[str, Path], outdir: Path, max_candidates: int = 180) -> pd.DataFrame:
    echo("TASK 1: Candidate source queue", "Loading Stage-7A inventories and scanning priority upstream folders.")
    file_index = build_file_index(root)
    rows: List[Dict[str, Any]] = []

    for fn in [
        "stage7A_time_surrogate_evidence_inventory.csv",
        "stage7A_retrospective_source_inventory.csv",
        "stage7A_forward_reverse_recursion_audit.csv",
        "stage7A_spacetime_coupling_diagnostics.csv",
        "stage7A_discovered_scalar_pool_REVIEW_ONLY.csv",
    ]:
        p = stage7a_files.get(fn)
        if p:
            df = safe_read_table(p)
            add_candidates_from_df(rows, df, fn, root, file_index)

    rows.extend(discover_priority_files(root, file_index))
    if not rows:
        q = pd.DataFrame(columns=["candidate_id", "resolved_path", "exists", "stage", "role", "evidence_score"])
        q.to_csv(outdir / "stage7B_candidate_file_queue.csv", index=False)
        return q

    q = pd.DataFrame(rows)
    # Deduplicate by resolved path if possible; otherwise raw path.
    q["dedupe_key"] = np.where(q["resolved_path"].astype(str).str.len() > 0, q["resolved_path"], q["raw_path"].astype(str))
    q["evidence_score_filled"] = pd.to_numeric(q["evidence_score"], errors="coerce").fillna(0.0)
    q["stage6Y_bias_flag"] = q["stage"].astype(str).str.contains("6Y", case=False, regex=False) | q["raw_path"].astype(str).str.contains("6Y", case=False, regex=False)
    q["priority_weight"] = q["evidence_score_filled"] + q["exists"].astype(int) * 2.0
    q = q.sort_values(["exists", "priority_weight"], ascending=[False, False])
    q = q.drop_duplicates("dedupe_key", keep="first").head(max_candidates).copy()
    q.insert(0, "candidate_id", [f"C{i:04d}" for i in range(1, len(q) + 1)])
    q = q.drop(columns=["dedupe_key"], errors="ignore")
    q.to_csv(outdir / "stage7B_candidate_file_queue.csv", index=False)

    # Source role bias audit.
    bias_rows = []
    if not q.empty:
        for key, g in q.groupby(["stage", "role"], dropna=False):
            stage, role = key
            bias_rows.append({
                "stage": stage,
                "role": role,
                "candidate_count": int(len(g)),
                "existing_count": int(g["exists"].sum()),
                "stage6Y_bias_count": int(g["stage6Y_bias_flag"].sum()),
                "mean_keyword_evidence_score": float(pd.to_numeric(g["evidence_score"], errors="coerce").mean()) if g["evidence_score"].notna().any() else float("nan"),
                "audit_note": "Candidate-selection evidence only; not empirical confirmation.",
            })
    pd.DataFrame(bias_rows).to_csv(outdir / "stage7B_source_role_bias_audit.csv", index=False)
    return q


def load_candidate_data(queue: pd.DataFrame, root: Path, max_candidates_to_test: int = 80) -> Tuple[List[CandidateData], List[Dict[str, Any]]]:
    candidates: List[CandidateData] = []
    failures: List[Dict[str, Any]] = []
    if queue is None or queue.empty:
        return candidates, failures
    q = queue[queue["exists"].astype(bool)].head(max_candidates_to_test).copy()
    for _, row in q.iterrows():
        cid = str(row.get("candidate_id"))
        p = Path(str(row.get("resolved_path")))
        if not p.exists():
            failures.append({"candidate_id": cid, "path": str(p), "reason": "path_missing"})
            continue
        df = safe_read_table(p)
        if df is None or df.empty:
            failures.append({"candidate_id": cid, "path": str(p), "reason": "unreadable_or_empty"})
            continue
        ordered, order_col = order_dataframe(df)
        family_col, fams = infer_family_values(ordered)
        X, cols, meta = numeric_matrix_from_df(ordered, exclude_cols=[order_col] if order_col else [])
        if X is None:
            failures.append({"candidate_id": cid, "path": str(p), "reason": meta.get("reason", "numeric_matrix_unavailable")})
            continue
        candidates.append(CandidateData(
            candidate_id=cid,
            source_path=p,
            display_path=relpath(p, root),
            stage=str(row.get("stage", extract_stage_from_text(str(p)))),
            role=str(row.get("role", infer_role_from_text(str(p)))),
            dataframe=ordered,
            order_column=order_col,
            numeric_columns=cols,
            X=X,
            family_column=family_col,
            families_present=fams,
        ))
    return candidates, failures


# ---------------------------------------------------------------------
# Core task implementations
# ---------------------------------------------------------------------
def task_forward_reverse(candidates: List[CandidateData], outdir: Path) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    echo("TASK 2: Forward/reverse recursion directionality", "Computing internal ordering metrics and reverse-control gaps.")
    rows = []
    for c in candidates:
        X = c.X
        target = X[-1]
        fwd = directionality_metrics(X, target=target)
        rev_to_forward_terminal = directionality_metrics(X[::-1], target=target)
        rev_self = directionality_metrics(X[::-1], target=X[0])
        gap = fwd.get("directionality_score", np.nan) - rev_to_forward_terminal.get("directionality_score", np.nan)
        rows.append({
            "candidate_id": c.candidate_id,
            "source_file": c.display_path,
            "stage": c.stage,
            "role": c.role,
            "order_column": c.order_column or "row_order",
            "n_rows": int(X.shape[0]),
            "n_numeric_columns": int(X.shape[1]),
            "family_column": c.family_column or "",
            "families_present": ";".join(c.families_present),
            "forward_directionality_score": fwd.get("directionality_score"),
            "reverse_against_forward_terminal_score": rev_to_forward_terminal.get("directionality_score"),
            "reverse_self_order_score": rev_self.get("directionality_score"),
            "forward_reverse_gap": gap,
            "forward_terminal_contraction_corr": fwd.get("corr_time_to_terminal_contraction"),
            "forward_entropy_slope": fwd.get("entropy_slope"),
            "forward_effective_rank": fwd.get("effective_rank"),
            "forward_operator_asymmetry": fwd.get("operator_asymmetry"),
            "forward_toeplitz_deviation": fwd.get("toeplitz_deviation"),
            "forward_lowk_retention": fwd.get("lowk_retention"),
            "early_mass_mean": fwd.get("early_mass_mean"),
            "central_mass_mean": fwd.get("central_mass_mean"),
            "boundary_mass_mean": fwd.get("boundary_mass_mean"),
            "bulk_mass_mean": fwd.get("bulk_mass_mean"),
            "lobe_separation_proxy": fwd.get("lobe_separation_proxy"),
            "interpretation_limit": "Internal ordering diagnostic only; not physical time.",
        })
    df = pd.DataFrame(rows)
    df.to_csv(outdir / "stage7B_forward_reverse_directionality_table.csv", index=False)

    summary: Dict[str, Any] = {
        "n_candidates_tested": int(len(candidates)),
        "n_directionality_rows": int(len(df)),
        "mean_forward_score": float(df["forward_directionality_score"].mean()) if not df.empty else float("nan"),
        "mean_forward_reverse_gap": float(df["forward_reverse_gap"].mean()) if not df.empty else float("nan"),
        "positive_gap_fraction": float((df["forward_reverse_gap"] > 0).mean()) if not df.empty else float("nan"),
        "claim_boundary": "Forward/reverse gap is internal recursion directionality only, not physical time.",
    }
    json_dump(summary, outdir / "stage7B_recursion_directionality_summary.json")
    return df, summary


def task_null_controls(candidates: List[CandidateData], outdir: Path, n_repeats: int = 6) -> Tuple[pd.DataFrame, pd.DataFrame]:
    echo("TASK 3: Null-control battery", "Testing directionality against randomized, low-k matched, spectrum-preserving, and transport-preserving controls.")
    rng = np.random.default_rng(RNG_SEED)
    result_rows = []
    survival_rows = []
    for c in candidates:
        X = c.X
        target = X[-1]
        base = directionality_metrics(X, target=target)
        base_score = base.get("directionality_score", np.nan)
        null_scores = []
        for null_name, gen in NULL_GENERATORS.items():
            for rep in range(n_repeats):
                try:
                    Y = gen(X, rng)
                    m = directionality_metrics(Y, target=target)
                    null_score = m.get("directionality_score", np.nan)
                    null_scores.append(null_score)
                    result_rows.append({
                        "candidate_id": c.candidate_id,
                        "source_file": c.display_path,
                        "null_type": null_name,
                        "repeat": rep + 1,
                        "base_forward_score": base_score,
                        "null_score": null_score,
                        "base_minus_null": base_score - null_score if math.isfinite(base_score) and math.isfinite(null_score) else np.nan,
                        "survives_this_null": bool(math.isfinite(base_score) and math.isfinite(null_score) and base_score > null_score),
                        "interpretation_limit": "Null comparison; not proof of physical time.",
                    })
                except Exception as exc:
                    result_rows.append({
                        "candidate_id": c.candidate_id,
                        "source_file": c.display_path,
                        "null_type": null_name,
                        "repeat": rep + 1,
                        "base_forward_score": base_score,
                        "null_score": np.nan,
                        "base_minus_null": np.nan,
                        "survives_this_null": False,
                        "error": str(exc),
                    })
        ns = np.array([x for x in null_scores if math.isfinite(float(x))], dtype=float)
        if len(ns):
            null_mean = float(np.mean(ns))
            null_std = float(np.std(ns))
            survival_fraction = float(np.mean(base_score > ns)) if math.isfinite(base_score) else float("nan")
            z = float((base_score - null_mean) / (null_std + EPS)) if math.isfinite(base_score) else float("nan")
            p_like = float((1 + np.sum(ns >= base_score)) / (len(ns) + 1)) if math.isfinite(base_score) else float("nan")
        else:
            null_mean = null_std = survival_fraction = z = p_like = float("nan")
        survival_rows.append({
            "candidate_id": c.candidate_id,
            "source_file": c.display_path,
            "base_forward_score": base_score,
            "null_mean_score": null_mean,
            "null_std_score": null_std,
            "base_minus_null_mean": base_score - null_mean if math.isfinite(base_score) and math.isfinite(null_mean) else np.nan,
            "survival_fraction": survival_fraction,
            "null_z_score": z,
            "empirical_p_like": p_like,
            "strict_survival": bool(math.isfinite(z) and z > 1.0 and math.isfinite(survival_fraction) and survival_fraction >= 0.75),
            "lowk_or_spectrum_warning": "Review individual low-k/spectrum-preserving null rows before any strong claim.",
        })
    results = pd.DataFrame(result_rows)
    survival = pd.DataFrame(survival_rows)
    results.to_csv(outdir / "stage7B_null_control_results.csv", index=False)
    survival.to_csv(outdir / "stage7B_null_survival_scores.csv", index=False)
    write_text(outdir / "stage7B_null_control_notes.txt", null_control_notes(results, survival))
    return results, survival


def null_control_notes(results: pd.DataFrame, survival: pd.DataFrame) -> str:
    if survival.empty:
        return "No usable null-control results were produced. Verdict must be E unless other tables contain valid evidence.\n"
    strict = int(survival.get("strict_survival", pd.Series(dtype=bool)).sum())
    total = len(survival)
    mean_surv = survival["survival_fraction"].mean() if "survival_fraction" in survival else np.nan
    return f"""Stage-7B null-control notes
===========================

Candidate directionality was tested against row/time permutation, phase
randomization, low-k matched, transport-preserving, sector-mass-preserving,
spectrum-preserving, and symmetric-recursion controls when possible.

Strict surviving candidates: {strict} / {total}
Mean survival fraction: {mean_surv}

Interpretation rule:
- A keyword inventory score never counts as confirmation.
- A candidate must survive strong nulls, especially low-k matched and
  spectrum-preserving nulls, before any internal time-surrogate language is
  permitted.
- Even a strict-surviving signal remains internal QEG ordering only, not
  physical time.
"""


def task_family_perturbation(candidates: List[CandidateData], outdir: Path) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    echo("TASK 4: Family-conditioned perturbation audit", "Testing survival under perturbations and family separation when lineage labels are present.")
    rng = np.random.default_rng(RNG_SEED + 17)
    rows = []
    family_seen = set()
    for c in candidates:
        df = c.dataframe
        family_col = c.family_column
        groups: List[Tuple[str, pd.DataFrame]] = [("POOLED", df)]
        if family_col:
            vals = df[family_col].astype(str).str.upper()
            for fam in TRUE_FAMILIES:
                sub = df[vals.str.contains(fam, regex=False, na=False)].copy()
                if len(sub) >= 4:
                    groups.append((fam, sub))
                    family_seen.add(fam)
        for fam, g in groups:
            ordered, order_col = order_dataframe(g)
            X, cols, meta = numeric_matrix_from_df(ordered, exclude_cols=[order_col] if order_col else [])
            if X is None:
                rows.append({
                    "candidate_id": c.candidate_id,
                    "source_file": c.display_path,
                    "family": fam,
                    "perturbation": "base",
                    "status": "INSUFFICIENT_NUMERIC_STRUCTURE",
                    "reason": meta.get("reason"),
                })
                continue
            base = directionality_metrics(X, target=X[-1])
            rows.append(family_perturbation_row(c, fam, "base", base, base, "BASE"))
            for pname, pfun in PERTURBATIONS.items():
                try:
                    Y = pfun(X, rng)
                    m = directionality_metrics(Y, target=X[-1])
                    rows.append(family_perturbation_row(c, fam, pname, base, m, "PERTURBED"))
                except Exception as exc:
                    rows.append({
                        "candidate_id": c.candidate_id,
                        "source_file": c.display_path,
                        "family": fam,
                        "perturbation": pname,
                        "status": "ERROR",
                        "error": str(exc),
                    })
    audit = pd.DataFrame(rows)
    audit.to_csv(outdir / "stage7B_family_perturbation_audit.csv", index=False)

    summary = summarize_family_perturbations(audit, family_seen)
    json_dump(summary, outdir / "stage7B_family_stability_summary.json")
    return audit, summary


def family_perturbation_row(c: CandidateData, fam: str, perturbation: str, base: Dict[str, float], m: Dict[str, float], status: str) -> Dict[str, Any]:
    b = base.get("directionality_score", np.nan)
    s = m.get("directionality_score", np.nan)
    return {
        "candidate_id": c.candidate_id,
        "source_file": c.display_path,
        "stage": c.stage,
        "role": c.role,
        "family": fam,
        "perturbation": perturbation,
        "status": status,
        "base_directionality_score": b,
        "perturbed_directionality_score": s,
        "directionality_score_drift": s - b if math.isfinite(b) and math.isfinite(s) else np.nan,
        "lobe_separation_drift": m.get("lobe_separation_proxy", np.nan) - base.get("lobe_separation_proxy", np.nan),
        "early_mass_drift_delta": m.get("early_mass_mean", np.nan) - base.get("early_mass_mean", np.nan),
        "central_mass_drift_delta": m.get("central_mass_mean", np.nan) - base.get("central_mass_mean", np.nan),
        "operator_rank_drift": m.get("effective_rank", np.nan) - base.get("effective_rank", np.nan),
        "asymmetry_drift": m.get("operator_asymmetry", np.nan) - base.get("operator_asymmetry", np.nan),
        "toeplitz_deviation_drift": m.get("toeplitz_deviation", np.nan) - base.get("toeplitz_deviation", np.nan),
        "kl_js_proxy_drift": m.get("mean_terminal_js_distance", np.nan) - base.get("mean_terminal_js_distance", np.nan),
        "survives_perturbation": bool(math.isfinite(b) and math.isfinite(s) and s >= 0.75 * b and s >= 0.35),
        "interpretation_limit": "Family/perturbation survival only; not physical time.",
    }


def summarize_family_perturbations(audit: pd.DataFrame, family_seen: Iterable[str]) -> Dict[str, Any]:
    if audit.empty:
        return {
            "families_seen": [],
            "all_true_families_present": False,
            "perturbation_survival_fraction": float("nan"),
            "family_stability_score": float("nan"),
            "summary": "No family perturbation audit rows were produced.",
        }
    pert = audit[audit.get("status", "") == "PERTURBED"].copy() if "status" in audit else pd.DataFrame()
    survival = float(pert["survives_perturbation"].mean()) if not pert.empty and "survives_perturbation" in pert else float("nan")
    families = sorted(set(family_seen))
    all_present = all(f in families for f in TRUE_FAMILIES)
    base = audit[(audit.get("status", "") == "BASE") & (audit.get("family", "") != "POOLED")].copy() if "family" in audit else pd.DataFrame()
    if not base.empty and "base_directionality_score" in base:
        fam_means = base.groupby("family")["base_directionality_score"].mean()
        spread = float(fam_means.max() - fam_means.min()) if len(fam_means) > 1 else float("nan")
        stability_score = float(np.clip(1.0 - spread, 0.0, 1.0)) if math.isfinite(spread) else float("nan")
    else:
        spread = float("nan")
        stability_score = float("nan")
    return {
        "families_seen": families,
        "all_true_families_present": all_present,
        "perturbation_survival_fraction": survival,
        "family_directionality_spread": spread,
        "family_stability_score": stability_score,
        "interpretation_limit": "A family-stable internal directionality result is not a physical-time claim.",
    }


def task_entropy_audit(candidates: List[CandidateData], outdir: Path, null_results: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    echo("TASK 5: Entropy/state-space audit", "Declaring state spaces before entropy-like trajectory tests.")
    rng = np.random.default_rng(RNG_SEED + 29)
    audit_rows = []
    traj_rows = []
    for c in candidates:
        X = c.X
        P = prob_rows(zscore_columns(X))
        H = entropy(P)
        base_slope = linear_slope(H)
        reversed_slope = linear_slope(entropy(P[::-1]))
        null_slopes = []
        for rep in range(8):
            Y = row_permutation_null(X, rng)
            PY = prob_rows(zscore_columns(Y))
            null_slopes.append(linear_slope(entropy(PY)))
        null_slopes_np = np.array([x for x in null_slopes if math.isfinite(x)])
        null_mean = float(null_slopes_np.mean()) if len(null_slopes_np) else float("nan")
        null_std = float(null_slopes_np.std()) if len(null_slopes_np) else float("nan")
        z = float((base_slope - null_mean) / (null_std + EPS)) if math.isfinite(base_slope) and math.isfinite(null_mean) else float("nan")
        audit_rows.append({
            "candidate_id": c.candidate_id,
            "source_file": c.display_path,
            "diagnostic": "row_probability_shannon_entropy",
            "state_space": "numeric observable columns selected from candidate table",
            "probability_vector": "abs(zscore(row_values)) / sum(abs(zscore(row_values)))",
            "normalization_rule": "row-wise L1 normalization after absolute z-scored observables",
            "coarse_graining_rule": "numeric columns retained after nonconstant filter and high-variance cap",
            "evolution_variable": c.order_column or "row_order",
            "null_controls": "row/order permutation; compare slope to null slopes",
            "interpretation_class": "recursive-state entropy-like diagnostic",
            "forbidden_interpretation": "physical entropy production or thermodynamic arrow",
            "permission": "entropy-like language permitted only with this row-level declaration",
        })
        traj_rows.append({
            "candidate_id": c.candidate_id,
            "source_file": c.display_path,
            "entropy_type": "declared_row_probability_shannon_entropy",
            "n_steps": int(len(H)),
            "forward_entropy_slope": base_slope,
            "reverse_entropy_slope": reversed_slope,
            "null_entropy_slope_mean": null_mean,
            "null_entropy_slope_std": null_std,
            "entropy_null_z_score": z,
            "entropy_directionality_supported": bool(math.isfinite(z) and abs(z) > 1.0),
            "trajectory_start_entropy": float(H[0]) if len(H) else np.nan,
            "trajectory_end_entropy": float(H[-1]) if len(H) else np.nan,
            "interpretation_limit": "Entropy-like internal diagnostic only; not thermodynamic entropy production.",
        })
    audit = pd.DataFrame(audit_rows)
    traj = pd.DataFrame(traj_rows)
    audit.to_csv(outdir / "stage7B_entropy_state_space_audit.csv", index=False)
    traj.to_csv(outdir / "stage7B_entropy_trajectory_tests.csv", index=False)
    write_text(outdir / "stage7B_entropy_claim_permissions.md", entropy_permission_text())
    return audit, traj


def entropy_permission_text() -> str:
    return """# Stage-7B entropy/state-space permissions

Permitted phrases:

- entropy-like diagnostic
- recursive-state entropy-like trend
- spectral entropy-like trend
- information-geometric divergence trajectory
- internal ordering diagnostic

Forbidden phrases:

- physical entropy production
- thermodynamic arrow proven
- physical time derived
- spacetime derived

Rule:

No entropy-like row may be interpreted unless the state space, probability
vector, normalization rule, coarse-graining rule, evolution variable, and null
controls are declared in `stage7B_entropy_state_space_audit.csv`.
"""


def task_spacetime_coupling(directionality: pd.DataFrame, null_survival: pd.DataFrame, entropy_traj: pd.DataFrame, outdir: Path) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    echo("TASK 6: Space-time surrogate coupling", "Testing whether spatial/geometric invariants constrain internal recursive ordering diagnostics.")
    if directionality.empty:
        coupling = pd.DataFrame()
        summary = {"n_pairs_tested": 0, "supported_pairs": 0, "summary": "No directionality table available."}
        coupling.to_csv(outdir / "stage7B_spacetime_surrogate_coupling_table.csv", index=False)
        json_dump(summary, outdir / "stage7B_spacetime_surrogate_coupling_summary.json")
        return coupling, summary

    df = directionality.copy()
    if not null_survival.empty:
        ns_cols = ["candidate_id", "survival_fraction", "base_minus_null_mean", "strict_survival"]
        df = df.merge(null_survival[[c for c in ns_cols if c in null_survival.columns]], on="candidate_id", how="left")
    if not entropy_traj.empty:
        e_cols = ["candidate_id", "forward_entropy_slope", "entropy_null_z_score", "entropy_directionality_supported"]
        df = df.merge(entropy_traj[[c for c in e_cols if c in entropy_traj.columns]], on="candidate_id", how="left", suffixes=("", "_entropy"))

    spatial_features = [
        "lobe_separation_proxy", "early_mass_mean", "central_mass_mean",
        "boundary_mass_mean", "bulk_mass_mean", "forward_effective_rank",
        "forward_operator_asymmetry", "forward_toeplitz_deviation",
        "forward_lowk_retention",
    ]
    temporal_features = [
        "forward_reverse_gap", "forward_directionality_score", "survival_fraction",
        "base_minus_null_mean", "forward_entropy_slope", "entropy_null_z_score",
    ]
    rows = []
    for sfeat in spatial_features:
        if sfeat not in df.columns:
            continue
        for tfeat in temporal_features:
            if tfeat not in df.columns:
                continue
            corr = safe_corr(df[sfeat], df[tfeat])
            n = int((pd.to_numeric(df[sfeat], errors="coerce").notna() & pd.to_numeric(df[tfeat], errors="coerce").notna()).sum())
            supported = bool(n >= 4 and math.isfinite(corr) and abs(corr) >= 0.45)
            rows.append({
                "spatial_invariant": sfeat,
                "temporal_surrogate_diagnostic": tfeat,
                "n_candidates": n,
                "pearson_correlation": corr,
                "absolute_correlation": abs(corr) if math.isfinite(corr) else np.nan,
                "coupling_supported_review_threshold": supported,
                "interpretation_limit": "space-time surrogate coupling means internal spatial invariant vs recursive-order diagnostic only",
            })
    coupling = pd.DataFrame(rows).sort_values("absolute_correlation", ascending=False) if rows else pd.DataFrame(rows)
    coupling.to_csv(outdir / "stage7B_spacetime_surrogate_coupling_table.csv", index=False)
    summary = {
        "n_pairs_tested": int(len(coupling)),
        "supported_pairs": int(coupling["coupling_supported_review_threshold"].sum()) if not coupling.empty else 0,
        "max_abs_correlation": float(coupling["absolute_correlation"].max()) if not coupling.empty else float("nan"),
        "claim_boundary": "Internal space-time surrogate coupling only; no physical spacetime claim.",
    }
    json_dump(summary, outdir / "stage7B_spacetime_surrogate_coupling_summary.json")
    return coupling, summary


def adjudicate_verdict(
    missing_7a: List[str],
    candidates: List[CandidateData],
    directionality_summary: Dict[str, Any],
    null_survival: pd.DataFrame,
    family_summary: Dict[str, Any],
    entropy_traj: pd.DataFrame,
    coupling_summary: Dict[str, Any],
    outdir: Path,
) -> Tuple[str, pd.DataFrame, Dict[str, Any]]:
    echo("TASK 7: Claim-status adjudication", "Assigning strongest permitted internal claim with guardrails.")
    n_candidates = len(candidates)
    if n_candidates == 0 or len(missing_7a) > len(MANDATORY_7A_FILES) // 2:
        verdict = "E_REDESIGN_REQUIRED_INPUTS_INSUFFICIENT"
    else:
        mean_forward = directionality_summary.get("mean_forward_score", np.nan)
        gap_frac = directionality_summary.get("positive_gap_fraction", np.nan)
        strict_survivors = int(null_survival.get("strict_survival", pd.Series(dtype=bool)).sum()) if not null_survival.empty else 0
        strict_fraction = strict_survivors / max(len(null_survival), 1)
        mean_survival = float(null_survival["survival_fraction"].mean()) if not null_survival.empty and "survival_fraction" in null_survival else float("nan")
        family_score = family_summary.get("family_stability_score", np.nan)
        family_survival = family_summary.get("perturbation_survival_fraction", np.nan)
        all_fams = bool(family_summary.get("all_true_families_present", False))
        entropy_support = float(entropy_traj.get("entropy_directionality_supported", pd.Series(dtype=bool)).mean()) if not entropy_traj.empty and "entropy_directionality_supported" in entropy_traj else float("nan")
        coupling_supported = int(coupling_summary.get("supported_pairs", 0))

        # Strict A needs several independent supports. Keep rare.
        if (
            math.isfinite(mean_forward) and mean_forward >= 0.62
            and math.isfinite(mean_survival) and mean_survival >= 0.72
            and strict_fraction >= 0.35
            and all_fams
            and math.isfinite(family_score) and family_score >= 0.70
            and math.isfinite(family_survival) and family_survival >= 0.60
            and coupling_supported >= 1
        ):
            verdict = "A_TIME_SURROGATE_SUPPORTED_INTERNAL_ONLY"
        elif (
            math.isfinite(mean_forward) and mean_forward >= 0.52
            and math.isfinite(mean_survival) and mean_survival >= 0.55
            and (all_fams or (math.isfinite(family_score) and family_score >= 0.55))
        ):
            verdict = "B_OPERATOR_IRREVERSIBILITY_SUPPORTED_TIME_SURROGATE_PARTIAL"
        elif (
            (math.isfinite(mean_forward) and mean_forward >= 0.40)
            or (math.isfinite(mean_survival) and mean_survival >= 0.40)
            or (math.isfinite(entropy_support) and entropy_support > 0.20)
            or coupling_supported > 0
        ):
            verdict = "C_CANDIDATE_SIGNAL_PRESENT_NOT_CLAIM_GRADE"
        else:
            verdict = "D_NO_TIME_SURROGATE_RELAXATION_ARTIFACT"

    rows = [
        {
            "claim_candidate": "internal_time_surrogate",
            "status": "PERMITTED_INTERNAL_ONLY" if verdict.startswith("A_") else "NOT_PERMITTED_OR_PARTIAL",
            "verdict_dependency": verdict,
            "forbidden_upgrade": "physical time derived",
        },
        {
            "claim_candidate": "operator_irreversibility",
            "status": "SUPPORTED_OR_PARTIAL" if verdict.startswith(("A_", "B_", "C_")) else "NOT_SUPPORTED_CURRENTLY",
            "verdict_dependency": verdict,
            "forbidden_upgrade": "thermodynamic irreversibility proven",
        },
        {
            "claim_candidate": "entropy_like_directionality",
            "status": "ONLY_WITH_DECLARED_STATE_SPACE_AND_NULLS",
            "verdict_dependency": verdict,
            "forbidden_upgrade": "physical entropy production",
        },
        {
            "claim_candidate": "space_time_surrogate_coupling",
            "status": "INTERNAL_BOOKKEEPING_ONLY",
            "verdict_dependency": verdict,
            "forbidden_upgrade": "physical spacetime derived",
        },
        {
            "claim_candidate": "Omega_m_or_cosmology_identification",
            "status": "FORBIDDEN_IN_STAGE_7B",
            "verdict_dependency": verdict,
            "forbidden_upgrade": "cosmological parameter derived",
        },
    ]
    claim_table = pd.DataFrame(rows)
    claim_table.to_csv(outdir / "stage7B_claim_status_table.csv", index=False)

    final_info = {
        "verdict": verdict,
        "n_candidates_tested": n_candidates,
        "missing_stage7A_inputs": missing_7a,
        "directionality_summary": directionality_summary,
        "family_summary": family_summary,
        "coupling_summary": coupling_summary,
        "guardrail": "Strongest permitted positive claim is internal QEG time surrogate or operator irreversibility. Physical time remains outside scope.",
    }
    write_text(outdir / "stage7B_final_verdict.txt", final_verdict_text(verdict, final_info))
    write_text(outdir / "stage7B_claim_guardrails.md", claim_guardrails_text())
    write_text(outdir / "stage7C_recommendation.txt", stage7c_recommendation_text(verdict))
    return verdict, claim_table, final_info


def final_verdict_text(verdict: str, info: Dict[str, Any]) -> str:
    return f"""Stage-7B final verdict
======================

VERDICT:
{verdict}

Meaning:
{verdict_explanation(verdict)}

Candidate tables tested: {info.get('n_candidates_tested')}

Guardrail:
The strongest permitted positive claim after Stage-7B is an internal QEG
time surrogate or operator irreversibility. Physical time remains outside
the claim scope.

Missing Stage-7A inputs:
{json.dumps(info.get('missing_stage7A_inputs', []), indent=2)}

Directionality summary:
{json.dumps(info.get('directionality_summary', {}), indent=2, default=str)}

Family summary:
{json.dumps(info.get('family_summary', {}), indent=2, default=str)}

Coupling summary:
{json.dumps(info.get('coupling_summary', {}), indent=2, default=str)}
"""


def verdict_explanation(verdict: str) -> str:
    if verdict.startswith("A_"):
        return "Strong evidence for a lineage-preserved, family-stable, null-resistant internal time surrogate. Physical time remains unclaimed."
    if verdict.startswith("B_"):
        return "Directionality exists, but evidence is better described as operator irreversibility than as a full time-surrogate claim."
    if verdict.startswith("C_"):
        return "Some signals survive, but not enough for claim-grade time-surrogate status. Preserve as candidate evidence."
    if verdict.startswith("D_"):
        return "Apparent time behavior is currently best explained by smoothing, relaxation, or null-equivalent structure. This is a valid negative result."
    return "Incomplete or inconsistent input structure prevents adjudication. Redesign or rebuild inputs before time-surrogate language."


def claim_guardrails_text() -> str:
    return f"""# Stage-7B claim guardrails

## Permitted language

- internal time surrogate
- intrinsic ordering variable
- recursive directionality
- operator irreversibility
- information-flow asymmetry
- entropy-like diagnostic with declared state space
- space-time surrogate coupling, internal bookkeeping only

## Forbidden language

- physical time derived
- spacetime derived
- thermodynamic arrow proven
- entropy production proven
- cosmological parameter derived
- Omega_m derived
- dark energy derived
- Einstein gravity derived
- quantum gravity proven
- quantum-mechanical interpretation confirmed

## Frozen benchmark policy

Recorded only for guardrails, not fitted here:

- Omega_m benchmark = {OMEGA_M_BENCHMARK_FROZEN}
- conservative QEG comparator global_mu = {QEG_GLOBAL_MU_CONSERVATIVE_FROZEN}
- sharp candidate comparator early_central_separation = {QEG_EARLY_CENTRAL_SEPARATION_SHARP_CANDIDATE_FROZEN}

Stage-7B does not refine, fit, rescale, promote, or reject these values.
It tests time-surrogate robustness and operator irreversibility only.
"""


def stage7c_recommendation_text(verdict: str) -> str:
    if verdict.startswith("A_"):
        rec = "Proceed to Stage-7C as a focused mechanism-identification and manuscript-facing internal-time-surrogate audit. Do not upgrade to physical time."
    elif verdict.startswith("B_"):
        rec = "Proceed to Stage-7C as operator-irreversibility mechanism isolation, with internal time-surrogate language kept partial."
    elif verdict.startswith("C_"):
        rec = "Proceed to Stage-7C only if it is a redesign/refinement of observables and stronger non-tautological source tests. Otherwise freeze as candidate evidence."
    elif verdict.startswith("D_"):
        rec = "Do not pursue time-surrogate claims next. Write a negative ledger and redirect to alternative observables or mechanism sources."
    else:
        rec = "Rebuild inputs before Stage-7C. Priority: restore lineage-preserved recursive tables with declared state spaces and family labels."
    return f"""Stage-7C recommendation
=======================

Input Stage-7B verdict:
{verdict}

Recommendation:
{rec}

Persistent guardrail:
Physical time and physical spacetime remain outside the claim scope unless a
future stage establishes a separate physical semantics bridge.
"""


# ---------------------------------------------------------------------
# Figure generation after tables are written
# ---------------------------------------------------------------------
def generate_figures(outdir: Path) -> List[str]:
    figures = []
    if plt is None:
        warn("matplotlib unavailable; skipping figures after tables.")
        return figures
    figdir = outdir / "figures"
    safe_mkdir(figdir)

    def save_bar(df: pd.DataFrame, xcol: str, ycol: str, title: str, filename: str, top: int = 25):
        if df.empty or xcol not in df or ycol not in df:
            return
        sub = df[[xcol, ycol]].dropna().head(top)
        if sub.empty:
            return
        plt.figure(figsize=(10, 5))
        plt.bar(range(len(sub)), sub[ycol].astype(float).values)
        plt.xticks(range(len(sub)), sub[xcol].astype(str).str.slice(0, 32), rotation=75, ha="right", fontsize=8)
        plt.ylabel(ycol)
        plt.title(title)
        plt.tight_layout()
        path = figdir / filename
        plt.savefig(path, dpi=160)
        plt.close()
        figures.append(str(path))

    try:
        d = pd.read_csv(outdir / "stage7B_forward_reverse_directionality_table.csv")
        save_bar(d, "candidate_id", "forward_reverse_gap", "Stage-7B forward/reverse gap", "forward_reverse_gap_panel.png")
    except Exception:
        pass
    try:
        n = pd.read_csv(outdir / "stage7B_null_survival_scores.csv")
        save_bar(n, "candidate_id", "survival_fraction", "Stage-7B null survival score", "null_survival_score_panel.png")
    except Exception:
        pass
    try:
        f = pd.read_csv(outdir / "stage7B_family_perturbation_audit.csv")
        if not f.empty and "family" in f and "perturbed_directionality_score" in f:
            agg = f[f.get("status", "") == "PERTURBED"].groupby("family", as_index=False)["perturbed_directionality_score"].mean()
            save_bar(agg, "family", "perturbed_directionality_score", "Stage-7B family-conditioned directionality", "family_conditioned_directionality_panel.png")
    except Exception:
        pass
    try:
        e = pd.read_csv(outdir / "stage7B_entropy_trajectory_tests.csv")
        save_bar(e, "candidate_id", "forward_entropy_slope", "Stage-7B entropy-like trajectory slopes", "entropy_state_space_trajectory_panel.png")
    except Exception:
        pass
    try:
        c = pd.read_csv(outdir / "stage7B_spacetime_surrogate_coupling_table.csv")
        save_bar(c, "spatial_invariant", "absolute_correlation", "Stage-7B space-time surrogate coupling screen", "spacetime_surrogate_coupling_panel.png")
    except Exception:
        pass
    try:
        cl = pd.read_csv(outdir / "stage7B_claim_status_table.csv")
        counts = cl.groupby("status", as_index=False).size().rename(columns={"size": "count"})
        save_bar(counts, "status", "count", "Stage-7B claim status after adjudication", "claim_status_after_7B.png")
    except Exception:
        pass
    return figures


# ---------------------------------------------------------------------
# Summary and manifest
# ---------------------------------------------------------------------
def write_summary(
    outdir: Path,
    root: Path,
    stage7a_dir: Path,
    missing_7a: List[str],
    candidate_failures: List[Dict[str, Any]],
    verdict: str,
    figures: List[str],
    final_info: Dict[str, Any],
) -> None:
    summary = {
        "project": "Quantum-Emergent Gravity",
        "stage": "7B",
        "script": Path(__file__).name,
        "timestamp": now_iso(),
        "project_root": str(root),
        "stage7A_input_dir": str(stage7a_dir),
        "output_dir": str(outdir),
        "verdict": verdict,
        "verdict_explanation": verdict_explanation(verdict),
        "missing_stage7A_inputs": missing_7a,
        "candidate_load_failures_count": len(candidate_failures),
        "candidate_load_failures_preview": candidate_failures[:25],
        "figures_generated": figures,
        "required_outputs": OUTPUT_FILES_REQUIRED,
        "frozen_policy_values_not_fitted": {
            "Omega_m_benchmark": OMEGA_M_BENCHMARK_FROZEN,
            "global_mu_conservative": QEG_GLOBAL_MU_CONSERVATIVE_FROZEN,
            "early_central_separation_sharp_candidate": QEG_EARLY_CENTRAL_SEPARATION_SHARP_CANDIDATE_FROZEN,
            "rejected_wrong_source_values": REJECTED_WRONG_SOURCE_VALUES,
        },
        "claim_boundary": "Internal QEG time surrogate/operator irreversibility only. No physical time or spacetime claim.",
        "final_info": final_info,
    }
    json_dump(summary, outdir / "stage7B_summary.json")

    manifest_rows = []
    for fn in sorted(os.listdir(outdir)):
        p = outdir / fn
        if p.is_file():
            manifest_rows.append({"file": fn, "size_bytes": p.stat().st_size})
    pd.DataFrame(manifest_rows).to_csv(outdir / "stage7B_output_manifest.csv", index=False)


def ensure_empty_required_outputs(outdir: Path) -> None:
    # In case of early failure, create placeholders for required outputs not already present.
    for fn in OUTPUT_FILES_REQUIRED:
        p = outdir / fn
        if p.exists():
            continue
        if fn.endswith(".csv"):
            pd.DataFrame([{"status": "NOT_PRODUCED", "reason": "early_failure_or_no_inputs"}]).to_csv(p, index=False)
        elif fn.endswith(".json"):
            json_dump({"status": "NOT_PRODUCED", "reason": "early_failure_or_no_inputs"}, p)
        else:
            write_text(p, "NOT PRODUCED: early failure or no usable inputs.\n")


# ---------------------------------------------------------------------
# Main execution
# ---------------------------------------------------------------------
def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Stage-7B Time-Surrogate Robustness and Operator Irreversibility")
    parser.add_argument("--root", default=None, help="Optional QEG project root. Default: autodetect.")
    parser.add_argument("--max-candidates", type=int, default=180, help="Maximum candidate queue rows to keep.")
    parser.add_argument("--max-candidates-to-test", type=int, default=80, help="Maximum existing candidate tables to test numerically.")
    parser.add_argument("--no-figures", action="store_true", help="Skip optional figure generation.")
    args = parser.parse_args(argv)

    echo("STAGE-7B START", "Time-Surrogate Robustness and Operator Irreversibility in QEG Emergent Operator Geometry")
    root = detect_project_root(args.root)
    outdir = root / "metric_stage_7B_outputs" / "time_surrogate_robustness_operator_irreversibility_v1"
    safe_mkdir(outdir)
    echo("Detected paths", f"Project root: {root}\nOutput dir:   {outdir}")

    try:
        stage7a_dir, stage7a_files, missing_7a = load_stage7a_inputs(root, outdir)
        if missing_7a:
            warn(f"Missing Stage-7A inputs: {len(missing_7a)} / {len(MANDATORY_7A_FILES)}. Missing files are recorded in the input audit.")

        queue = build_candidate_queue(root, stage7a_files, outdir, max_candidates=args.max_candidates)
        candidates, failures = load_candidate_data(queue, root, max_candidates_to_test=args.max_candidates_to_test)
        pd.DataFrame(failures).to_csv(outdir / "stage7B_candidate_load_failures.csv", index=False)
        echo("Candidate load summary", f"Usable numeric candidate tables: {len(candidates)}\nLoad failures: {len(failures)}")

        directionality, directionality_summary = task_forward_reverse(candidates, outdir)
        null_results, null_survival = task_null_controls(candidates, outdir)
        family_audit, family_summary = task_family_perturbation(candidates, outdir)
        entropy_audit, entropy_traj = task_entropy_audit(candidates, outdir, null_results)
        coupling, coupling_summary = task_spacetime_coupling(directionality, null_survival, entropy_traj, outdir)
        verdict, claim_table, final_info = adjudicate_verdict(
            missing_7a, candidates, directionality_summary, null_survival,
            family_summary, entropy_traj, coupling_summary, outdir,
        )

        # Tables first, figures last.
        figures: List[str] = []
        if not args.no_figures:
            figures = generate_figures(outdir)

        write_summary(outdir, root, stage7a_dir, missing_7a, failures, verdict, figures, final_info)
        ensure_empty_required_outputs(outdir)
        echo("STAGE-7B COMPLETE", f"Verdict: {verdict}\nOutput directory: {outdir}")
        return 0
    except Exception as exc:
        err = {
            "status": "SCRIPT_ERROR",
            "error": str(exc),
            "traceback": traceback.format_exc(),
            "timestamp": now_iso(),
        }
        json_dump(err, outdir / "stage7B_script_error.json")
        write_text(outdir / "stage7B_final_verdict.txt", "E_REDESIGN_REQUIRED_INPUTS_INSUFFICIENT\n\nScript error occurred. See stage7B_script_error.json.\n")
        write_text(outdir / "stage7C_recommendation.txt", "Rebuild or inspect inputs before Stage-7C. Script error occurred.\n")
        write_text(outdir / "stage7B_claim_guardrails.md", claim_guardrails_text())
        ensure_empty_required_outputs(outdir)
        echo("STAGE-7B ERROR", f"{exc}\nSee: {outdir / 'stage7B_script_error.json'}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
