#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Quantum-Emergent Gravity
Stage-7A: Semantic Calibration, Entropic Arrow, and Space-Time Coupling

Author: Arturo Ortiz-Tapia
Script build: 2026-05-30
Prepared for: Spyder / Dakini Linux MATE workflow

======================================================================
PURPOSE
======================================================================

Stage-7A begins the semantic layer of QEG.

Stage-6 established lineage-preserved internal operator geometry with:

    - intrinsic coordinate structure
    - nonlocal operator evidence
    - low-rank asymmetric transport organization
    - canonical two-sector / two-lobe law
    - family-aware universality
    - recursive stabilization behavior
    - external benchmark proximity to cosmological sector quantities

Stage-7A does NOT upgrade these findings into physical derivations.

Instead, this script asks:

    Q1. What kind of internally generated object could legitimately
        be compared to Omega_m or other cosmological sector ratios?

    Q2. Can recursive/operator evolution define a preferred intrinsic
        direction analogous to an arrow of time?

    Q3. Does the same information-geometric structure organize both
        intrinsic spatial geometry and recursive temporal-surrogate
        behavior?

======================================================================
STRICT CLAIM BOUNDARY
======================================================================

This script is forbidden to:

    1. fit to Omega_m
    2. rescale to Omega_m
    3. claim derivation of cosmological parameters
    4. treat monotone entropy as physical entropy
    5. use entropy without state-space definition
    6. introduce free synthetic recursion detached from QEG lineage
    7. overwrite Stage-6 frozen values
    8. reinterpret failed local PDE closures as successful
    9. erase negative results
   10. promote semantic candidates into physical identifications

Everything produced here is evidence bookkeeping, semantic calibration,
or manuscript guardrail material unless later stages prove otherwise.

======================================================================
SPYDER USAGE
======================================================================

Open this file in Spyder and run it.

Optional:
    Edit USER_SUPPLIED_ROOT below, or leave it as None.

The script auto-corrects the root if launched from a scripts folder such as:

    metric_stage_7A_scripts
    metric_stage_6Yn_scripts

and promotes to:

    /home/dakini/Downloads/010-Quantum_Emergent_Gravity

Outputs are written to:

    metric_stage_7A_outputs/semantic_calibration_entropic_arrow_v1

======================================================================
"""

from __future__ import annotations

import csv
import json
import math
import os
import re
import sys
import traceback
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

# Matplotlib is used only for optional diagnostic figures.
try:
    import matplotlib.pyplot as plt
    HAVE_MATPLOTLIB = True
except Exception:
    HAVE_MATPLOTLIB = False


# ----------------------------------------------------------------------
# USER CONFIGURATION
# ----------------------------------------------------------------------

USER_SUPPLIED_ROOT: Optional[str] = None

DEFAULT_PROJECT_ROOT = Path("/home/dakini/Downloads/010-Quantum_Emergent_Gravity")

STAGE_NAME = "Stage-7A"
STAGE_TITLE = "Semantic Calibration, Entropic Arrow, and Space-Time Coupling in QEG Operator Geometry"

OUTPUT_RELATIVE = Path("metric_stage_7A_outputs") / "semantic_calibration_entropic_arrow_v1"

# Frozen comparator values from Stage-7A transition package.
FROZEN_COMPARATORS = {
    "Omega_m_benchmark": 0.315,
    "global_mu_conservative_qeg": 0.327995,
    "early_central_separation_sharp_candidate": 0.317696468538139,
    "rejected_global_mu_wrong_source_priority": 0.5,
    "rejected_early_central_separation_wrong_source_priority": 0.406087652955405,
}

# Conservative benchmark panel for bookkeeping only.
# These are used only as external comparison labels, not fitted targets.
# If your local PDG/table source differs, adjust here or update in Stage-7B.
REFERENCE_BENCHMARKS = {
    "Omega_b": {
        "value": 0.0493,
        "source_note": "PDG/Planck-style benchmark recorded in prior QEG files; benchmark only.",
        "permission": "benchmark_only_no_identification",
    },
    "Omega_c": {
        "value": 0.265,
        "source_note": "PDG/Planck-style benchmark recorded in prior QEG files; benchmark only.",
        "permission": "benchmark_only_no_identification",
    },
    "Omega_m": {
        "value": 0.315,
        "source_note": "Frozen Stage-7A Omega_m benchmark.",
        "permission": "benchmark_only_no_identification",
    },
    "Omega_Lambda": {
        "value": 0.685,
        "source_note": "PDG/Planck-style benchmark recorded in prior QEG files; benchmark only.",
        "permission": "benchmark_only_no_identification",
    },
    "Omega_K": {
        "value": 0.0007,
        "source_note": "PDG/Planck-style curvature benchmark recorded in prior QEG files; benchmark only.",
        "permission": "benchmark_only_no_identification",
    },
    "h_Planck": {
        "value": 0.674,
        "source_note": "Reduced Hubble parameter benchmark recorded in prior QEG files; benchmark only.",
        "permission": "benchmark_only_no_identification",
    },
    "sigma8": {
        "value": 0.811,
        "source_note": "Structure-amplitude benchmark recorded in prior QEG files; benchmark only.",
        "permission": "benchmark_only_no_identification",
    },
    "Omega_b_over_Omega_m": {
        "value": 0.0493 / 0.315,
        "source_note": "Derived from benchmark panel; benchmark only.",
        "permission": "derived_benchmark_only_no_identification",
    },
    "Omega_c_over_Omega_m": {
        "value": 0.265 / 0.315,
        "source_note": "Derived from benchmark panel; benchmark only.",
        "permission": "derived_benchmark_only_no_identification",
    },
    "Omega_m_over_Omega_Lambda": {
        "value": 0.315 / 0.685,
        "source_note": "Derived from benchmark panel; benchmark only.",
        "permission": "derived_benchmark_only_no_identification",
    },
}

MANDATORY_INPUT_DIRS = [
    "metric_stage_6Yn_v1c_figures_operator_response_outputs",
    "metric_stage_6Yn_v1a_outputs",
    "metric_stage_6J_outputs",
    "metric_stage_6K_outputs",
    "metric_stage_6L_outputs",
    "metric_stage_6Q_outputs",
    "metric_stage_6S_outputs",
    "metric_stage_6T_outputs",
    "metric_stage_6U_outputs",
]

MANDATORY_GLOB_DIRS = [
    "metric_stage_6Y*",
    "metric_stage_6Ya*",
    "metric_stage_6Yb*",
    "metric_stage_6Yc*",
    "metric_stage_6Yd*",
    "metric_stage_6Ye*",
    "metric_stage_6Yf*",
    "metric_stage_6Yg*",
    "metric_stage_6Yh*",
    "metric_stage_6Yi*",
    "metric_stage_6Yj*",
    "metric_stage_6Yk*",
    "metric_stage_6Yl*",
    "metric_stage_6Ym*",
    "metric_stage_6Yn*",
]

SPECIAL_DESIGN_FILE_PATTERNS = [
    "*7A*Entropic*Arrow*Space*Time*QEG*Operator*Geometry*.txt",
    "*Entropic*Arrow*Space*Time*Coupling*.txt",
    "7A_transition_package.txt",
    "Quantum_interpretation.txt",
]

SOURCE_SUFFIXES = {".csv", ".json", ".txt", ".md", ".png", ".jpg", ".jpeg", ".pdf"}

TEXT_SUFFIXES = {".txt", ".md", ".json", ".csv"}

SPATIAL_KEYWORDS = [
    "rho", "kappa", "κ", "ρ", "lobe", "sector", "separation", "intrinsic",
    "geometry", "coordinate", "arc", "mass_fraction", "modal", "density",
    "curvature", "two-lobe", "two_sector", "operator"
]

TEMPORAL_KEYWORDS = [
    "recursion", "recursive", "forward", "reverse", "entropy", "arrow",
    "time", "attractor", "stabilization", "stability", "irreversibility",
    "asymmetry", "leakage", "saturation", "hysteresis", "evolution",
    "n+1", "directionality"
]

INFO_KEYWORDS = [
    "kl", "kullback", "fisher", "information", "mutual", "transport",
    "spectral", "low-k", "low_k", "entropy", "divergence", "contraction",
    "simplex", "wasserstein", "prokhorov"
]

QM_INTERPRETATION_KEYWORDS = [
    "relational", "consistent histories", "admissibility", "consistency",
    "everett", "copenhagen", "bohm", "qbism", "collapse", "transactional",
    "green-function", "kernel"
]

SCALAR_KEY_PATTERNS = [
    "global_mu", "early_central_separation", "mu_early", "mu_central",
    "separation", "mass_fraction", "mass_ratio", "omega", "Omega",
    "rank", "asymmetry", "toeplitz", "entropy", "kl", "fisher",
    "corr", "r2", "R2", "score", "stability", "leakage", "saturation",
    "low_k", "sigma", "width", "ratio"
]


# ----------------------------------------------------------------------
# BASIC UTILITIES
# ----------------------------------------------------------------------

def now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def safe_rel(path: Path, root: Path) -> str:
    try:
        return str(path.relative_to(root))
    except Exception:
        return str(path)


def sanitize_filename(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", name).strip("_")


def safe_float(x: Any) -> Optional[float]:
    try:
        if x is None:
            return None
        v = float(x)
        if math.isfinite(v):
            return v
        return None
    except Exception:
        return None


def safe_read_text(path: Path, max_chars: int = 300_000) -> str:
    try:
        raw = path.read_text(encoding="utf-8", errors="replace")
        if len(raw) > max_chars:
            return raw[:max_chars] + "\n\n[TRUNCATED BY SCRIPT FOR MEMORY SAFETY]\n"
        return raw
    except Exception:
        try:
            raw = path.read_text(encoding="latin-1", errors="replace")
            if len(raw) > max_chars:
                return raw[:max_chars] + "\n\n[TRUNCATED BY SCRIPT FOR MEMORY SAFETY]\n"
            return raw
        except Exception:
            return ""


def keyword_count(text: str, keywords: Sequence[str]) -> int:
    low = text.lower()
    total = 0
    for kw in keywords:
        total += low.count(kw.lower())
    return total


def write_json(path: Path, obj: Any) -> None:
    path.write_text(json.dumps(obj, indent=2, sort_keys=False, default=str), encoding="utf-8")


def write_csv(path: Path, rows: List[Dict[str, Any]], preferred_order: Optional[List[str]] = None) -> None:
    ensure_dir(path.parent)
    if rows:
        keys = []
        if preferred_order:
            keys.extend([k for k in preferred_order if k not in keys])
        for row in rows:
            for k in row.keys():
                if k not in keys:
                    keys.append(k)
    else:
        keys = preferred_order or ["status", "note"]
        rows = [{"status": "EMPTY", "note": "No rows produced."}]
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=keys, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def normalize_probability(x: Sequence[float], nonnegative: bool = True) -> np.ndarray:
    arr = np.asarray(x, dtype=float)
    arr = np.where(np.isfinite(arr), arr, 0.0)
    if nonnegative:
        arr = np.maximum(arr, 0.0)
    s = float(arr.sum())
    if s <= 0:
        if len(arr) == 0:
            return arr
        return np.ones_like(arr, dtype=float) / len(arr)
    return arr / s


def shannon_entropy(prob: Sequence[float], base: float = math.e) -> float:
    p = normalize_probability(prob, nonnegative=True)
    p = p[p > 0]
    if len(p) == 0:
        return 0.0
    ent = -float(np.sum(p * np.log(p)))
    if base != math.e:
        ent /= math.log(base)
    return ent


def normalized_entropy(prob: Sequence[float], base: float = math.e) -> float:
    p = normalize_probability(prob, nonnegative=True)
    n = len(p)
    if n <= 1:
        return 0.0
    return shannon_entropy(p, base=base) / (math.log(n) / (math.log(base) if base != math.e else 1.0))


def l2_distance(a: Sequence[float], b: Sequence[float]) -> float:
    aa = np.asarray(a, dtype=float)
    bb = np.asarray(b, dtype=float)
    n = min(len(aa), len(bb))
    if n == 0:
        return float("nan")
    return float(np.linalg.norm(aa[:n] - bb[:n]))


def pearson_corr(a: Sequence[float], b: Sequence[float]) -> float:
    aa = np.asarray(a, dtype=float)
    bb = np.asarray(b, dtype=float)
    n = min(len(aa), len(bb))
    if n < 3:
        return float("nan")
    aa = aa[:n]
    bb = bb[:n]
    if np.std(aa) == 0 or np.std(bb) == 0:
        return float("nan")
    return float(np.corrcoef(aa, bb)[0, 1])


def infer_claim_level(label: str, context: str = "") -> Tuple[int, str]:
    low = (label + " " + context).lower()
    if "rejected" in low or "wrong_source" in low:
        return 0, "raw/rejected numerical artifact or known-provenance failure"
    if "physical identification" in low or "derivation" in low:
        return 7, "physical identification/derivation: forbidden in Stage-7A"
    if "mechanism" in low and "operator" in low:
        return 6, "mechanism-supported analogy candidate"
    if "benchmark" in low or "omega" in low or "cosmolog" in low:
        return 5, "semantic candidate for external comparison"
    if "operator" in low or "nonlocal" in low or "low-rank" in low:
        return 4, "operator-supported internal invariant"
    if "family" in low or "universal" in low:
        return 3, "family-universal internal invariant"
    if "lineage" in low:
        return 2, "lineage-preserved invariant"
    if "invariant" in low or "stable" in low:
        return 1, "stable internal invariant"
    return 1, "candidate internal invariant or registry item"


# ----------------------------------------------------------------------
# ROOT RESOLUTION
# ----------------------------------------------------------------------

def resolve_project_root(user_supplied: Optional[str] = None) -> Tuple[Path, Dict[str, Any]]:
    supplied_root = Path(user_supplied).expanduser() if user_supplied else Path.cwd()
    supplied_root = supplied_root.resolve()

    notes = []
    effective = supplied_root
    root_auto_corrected = False

    if effective.is_file():
        notes.append("Supplied path was a file; using parent directory.")
        effective = effective.parent
        root_auto_corrected = True

    # Mandatory correction inherited from Stage-6Yn v1c.
    if effective.name in {"metric_stage_7A_scripts", "metric_stage_6Yn_scripts"}:
        notes.append(f"Launched from {effective.name}; promoted to parent QEG root.")
        effective = effective.parent
        root_auto_corrected = True

    # Generic correction: if current directory is any metric_stage_*_scripts folder.
    if re.match(r"metric_stage_.*_scripts$", effective.name):
        notes.append(f"Launched from scripts folder {effective.name}; promoted to parent QEG root.")
        effective = effective.parent
        root_auto_corrected = True

    # If the default root exists and supplied directory does not look like QEG root,
    # prefer the default project root. This is useful in Spyder if cwd is elsewhere.
    indicators = [
        effective / "metric_stage_6J_outputs",
        effective / "metric_stage_6K_outputs",
        effective / "metric_stage_6Yn_v1c_figures_operator_response_outputs",
    ]
    if not any(p.exists() for p in indicators) and DEFAULT_PROJECT_ROOT.exists():
        notes.append("Supplied/current directory did not contain expected QEG output indicators; using default project root.")
        effective = DEFAULT_PROJECT_ROOT.resolve()
        root_auto_corrected = True

    if not notes:
        notes.append("No root correction needed.")

    info = {
        "supplied_root": str(supplied_root),
        "effective_project_root": str(effective),
        "root_auto_corrected": root_auto_corrected,
        "root_resolution_notes": " | ".join(notes),
    }
    return effective, info


# ----------------------------------------------------------------------
# FILE DISCOVERY AND SOURCE INVENTORY
# ----------------------------------------------------------------------

def discover_candidate_dirs(root: Path) -> List[Path]:
    dirs: List[Path] = []

    for d in MANDATORY_INPUT_DIRS:
        p = root / d
        if p.exists() and p.is_dir():
            dirs.append(p)

    for pattern in MANDATORY_GLOB_DIRS:
        for p in root.glob(pattern):
            if p.exists() and p.is_dir():
                dirs.append(p)

    # Also include Stage-7A conceptual files if they live directly under root.
    for pattern in SPECIAL_DESIGN_FILE_PATTERNS:
        for p in root.glob(pattern):
            if p.exists():
                dirs.append(p.parent)

    # Deduplicate preserving order.
    seen = set()
    unique = []
    for d in dirs:
        r = d.resolve()
        if r not in seen:
            seen.add(r)
            unique.append(r)

    return unique


def discover_sources(root: Path) -> List[Path]:
    candidate_dirs = discover_candidate_dirs(root)

    files: List[Path] = []
    for d in candidate_dirs:
        if d.is_dir():
            for p in d.rglob("*"):
                if p.is_file() and p.suffix.lower() in SOURCE_SUFFIXES:
                    files.append(p)

    # Special files at root or nearby.
    for pattern in SPECIAL_DESIGN_FILE_PATTERNS:
        for p in root.rglob(pattern):
            if p.is_file() and p.suffix.lower() in SOURCE_SUFFIXES:
                files.append(p)

    # Deduplicate and sort.
    files = sorted(set([p.resolve() for p in files]), key=lambda x: str(x))
    return files


def classify_source(path: Path) -> str:
    s = str(path).lower()
    if "6yn" in s:
        return "stage6yn_closure_or_comparator_patch"
    if "6j" in s:
        return "stage6j_nonlocal_operator"
    if "6k" in s:
        return "stage6k_operator_reduction"
    if "6l" in s:
        return "stage6l_pde_green_falsification"
    if "6q" in s:
        return "stage6q_canonical_law"
    if "6s" in s:
        return "stage6s_mechanism_analysis"
    if "6t" in s:
        return "stage6t_non_tautological_probe"
    if "6u" in s:
        return "stage6u_perturbation_review"
    if "6y" in s:
        return "stage6y_recursive_or_cosmology_branch"
    if "quantum_interpretation" in s:
        return "mathematical_incubator_meta_interpretation"
    if "7a" in s or "entropic" in s:
        return "stage7a_conceptual_scaffold"
    return "other_qeg_source"


def sniff_csv(path: Path) -> Dict[str, Any]:
    info: Dict[str, Any] = {}
    try:
        df_head = pd.read_csv(path, nrows=5)
        info["columns"] = list(df_head.columns)
        info["n_columns"] = len(df_head.columns)
        # Full row count with low memory; if problematic, skip.
        try:
            n_rows = sum(1 for _ in path.open("r", encoding="utf-8", errors="replace")) - 1
            info["n_rows_estimate"] = max(n_rows, 0)
        except Exception:
            info["n_rows_estimate"] = None
    except Exception as e:
        info["csv_error"] = repr(e)
    return info


def collect_json_keys(obj: Any, prefix: str = "", depth: int = 0, max_depth: int = 3) -> List[str]:
    keys: List[str] = []
    if depth > max_depth:
        return keys
    if isinstance(obj, dict):
        for k, v in obj.items():
            full = f"{prefix}.{k}" if prefix else str(k)
            keys.append(full)
            keys.extend(collect_json_keys(v, full, depth + 1, max_depth))
    elif isinstance(obj, list):
        for i, v in enumerate(obj[:5]):
            full = f"{prefix}[{i}]"
            keys.extend(collect_json_keys(v, full, depth + 1, max_depth))
    return keys


def sniff_json(path: Path) -> Dict[str, Any]:
    info: Dict[str, Any] = {}
    try:
        obj = json.loads(safe_read_text(path, max_chars=2_000_000))
        keys = collect_json_keys(obj)
        info["top_type"] = type(obj).__name__
        info["json_keys_sample"] = keys[:80]
        info["n_json_keys_sampled"] = len(keys)
    except Exception as e:
        info["json_error"] = repr(e)
    return info


def build_source_inventory(root: Path, files: List[Path]) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for p in files:
        text_sample = ""
        if p.suffix.lower() in TEXT_SUFFIXES:
            text_sample = safe_read_text(p, max_chars=50_000)

        row: Dict[str, Any] = {
            "source_path": safe_rel(p, root),
            "absolute_path": str(p),
            "source_role": classify_source(p),
            "suffix": p.suffix.lower(),
            "size_bytes": p.stat().st_size if p.exists() else None,
            "spatial_keyword_count": keyword_count(text_sample, SPATIAL_KEYWORDS) if text_sample else 0,
            "temporal_keyword_count": keyword_count(text_sample, TEMPORAL_KEYWORDS) if text_sample else 0,
            "information_keyword_count": keyword_count(text_sample, INFO_KEYWORDS) if text_sample else 0,
            "qm_interpretation_keyword_count": keyword_count(text_sample, QM_INTERPRETATION_KEYWORDS) if text_sample else 0,
        }

        if p.suffix.lower() == ".csv":
            row.update(sniff_csv(p))
        elif p.suffix.lower() == ".json":
            row.update(sniff_json(p))
        elif p.suffix.lower() in {".txt", ".md"}:
            row["text_title_guess"] = text_sample.splitlines()[0][:200] if text_sample.splitlines() else ""
            row["text_chars_sampled"] = len(text_sample)

        # Convert complex objects to compact strings.
        for k, v in list(row.items()):
            if isinstance(v, (list, dict)):
                row[k] = json.dumps(v, ensure_ascii=False)[:5000]

        rows.append(row)
    return rows


# ----------------------------------------------------------------------
# NUMERIC SCALAR DISCOVERY
# ----------------------------------------------------------------------

def json_numeric_scalars(obj: Any, prefix: str = "", depth: int = 0, max_depth: int = 5) -> List[Tuple[str, float]]:
    out: List[Tuple[str, float]] = []
    if depth > max_depth:
        return out
    if isinstance(obj, dict):
        for k, v in obj.items():
            full = f"{prefix}.{k}" if prefix else str(k)
            if isinstance(v, (int, float)) and math.isfinite(float(v)):
                out.append((full, float(v)))
            else:
                out.extend(json_numeric_scalars(v, full, depth + 1, max_depth))
    elif isinstance(obj, list):
        for i, v in enumerate(obj[:100]):
            full = f"{prefix}[{i}]"
            if isinstance(v, (int, float)) and math.isfinite(float(v)):
                out.append((full, float(v)))
            else:
                out.extend(json_numeric_scalars(v, full, depth + 1, max_depth))
    return out


def key_is_relevant_scalar(key: str) -> bool:
    low = key.lower()
    return any(p.lower() in low for p in SCALAR_KEY_PATTERNS)


def collect_relevant_scalars(root: Path, files: List[Path], max_csv_files: int = 600) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []

    for p in files:
        suffix = p.suffix.lower()
        rel = safe_rel(p, root)

        if suffix == ".json":
            try:
                obj = json.loads(safe_read_text(p, max_chars=5_000_000))
                for key, value in json_numeric_scalars(obj):
                    if key_is_relevant_scalar(key):
                        rows.append({
                            "source_path": rel,
                            "source_role": classify_source(p),
                            "scalar_key": key,
                            "statistic": "json_scalar",
                            "value": value,
                            "claim_level_hint": infer_claim_level(key, rel)[0],
                            "claim_level_description": infer_claim_level(key, rel)[1],
                        })
            except Exception:
                pass

        elif suffix == ".csv" and max_csv_files > 0:
            max_csv_files -= 1
            try:
                df = pd.read_csv(p, low_memory=False)
                numeric_cols = []
                for c in df.columns:
                    if key_is_relevant_scalar(str(c)):
                        numeric_cols.append(c)
                for c in numeric_cols:
                    vals = pd.to_numeric(df[c], errors="coerce").dropna()
                    if len(vals) == 0:
                        continue
                    # Avoid huge unbounded quantities; keep mostly dimensionless-like ranges but do not discard all.
                    stats = {
                        "mean": float(vals.mean()),
                        "median": float(vals.median()),
                        "min": float(vals.min()),
                        "max": float(vals.max()),
                        "std": float(vals.std(ddof=0)) if len(vals) > 1 else 0.0,
                    }
                    for stat, value in stats.items():
                        if math.isfinite(value):
                            rows.append({
                                "source_path": rel,
                                "source_role": classify_source(p),
                                "scalar_key": str(c),
                                "statistic": f"csv_column_{stat}",
                                "value": value,
                                "n_nonnull": int(len(vals)),
                                "claim_level_hint": infer_claim_level(str(c), rel)[0],
                                "claim_level_description": infer_claim_level(str(c), rel)[1],
                            })
            except Exception:
                pass

    # Explicit frozen values always included.
    for key, value in FROZEN_COMPARATORS.items():
        rows.append({
            "source_path": "Stage-7A transition package / frozen value",
            "source_role": "frozen_comparator",
            "scalar_key": key,
            "statistic": "frozen_value",
            "value": value,
            "claim_level_hint": infer_claim_level(key, "omega benchmark comparator rejected")[0],
            "claim_level_description": infer_claim_level(key, "omega benchmark comparator rejected")[1],
        })

    return rows


# ----------------------------------------------------------------------
# OUTPUT BUILDERS
# ----------------------------------------------------------------------

def build_semantic_object_registry(scalar_rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []

    base_objects = [
        {
            "object_id": "canonical_two_lobe_law",
            "object_label": "rho(s) approx E(s)+C(s)",
            "internal_type": "lineage-preserved family-universal response geometry",
            "semantic_candidates": "modal-density fraction | response-sector ratio | transport occupancy | information-geometric partition | recursive attractor statistic",
            "allowed_claim_level": 6,
            "stage7a_status": "semantic_candidate_not_physical_identification",
            "evidence_basis": "Stage-6Q/6P canonical law and universality pipeline",
            "paper_use": "Core methods/results object; discuss as emergent operator geometry, not as spacetime derivation.",
        },
        {
            "object_id": "global_mu_conservative_qeg",
            "object_label": "global_mu = 0.327995",
            "internal_type": "frozen conservative dimensionless comparator",
            "semantic_candidates": "response-sector statistic | internal numerical benchmark",
            "allowed_claim_level": 5,
            "stage7a_status": "external_benchmark_allowed_no_identification",
            "evidence_basis": "Stage-6Yn frozen comparator rule",
            "paper_use": "May appear in comparison table with guardrail; never as fitted or derived Omega_m.",
        },
        {
            "object_id": "early_central_separation_sharp_candidate",
            "object_label": "early_central_separation = 0.317696468538139",
            "internal_type": "sharp QEG comparator candidate",
            "semantic_candidates": "two-sector separation statistic | response geometry partition",
            "allowed_claim_level": 5,
            "stage7a_status": "external_benchmark_allowed_with_stronger_provenance_caveat",
            "evidence_basis": "Stage-6Yn frozen sharp candidate rule",
            "paper_use": "May be listed as sharp candidate; provenance and reconstruction caveats must remain visible.",
        },
        {
            "object_id": "qm_interpretation_alignment_note",
            "object_label": "Relational + consistency/admissibility meta-hypothesis",
            "internal_type": "Mathematical Incubator / conceptual non-evidentiary note",
            "semantic_candidates": "interpretive lens only",
            "allowed_claim_level": 3,
            "stage7a_status": "quarantined_from_manuscript_evidence_unless_explicitly_marked_conceptual",
            "evidence_basis": "Quantum_interpretation.txt states no equivalence, no ontology, no direct computational evidence.",
            "paper_use": "Recommend exclude from main Physica D evidence paper; possible short discussion/future-work sentence only if clearly non-evidentiary.",
        },
    ]

    rows.extend(base_objects)

    # Add discovered scalars as internal registry rows, but keep them candidates.
    for i, r in enumerate(scalar_rows):
        key = str(r.get("scalar_key", ""))
        value = safe_float(r.get("value"))
        if value is None:
            continue
        if not key_is_relevant_scalar(key):
            continue
        level, desc = infer_claim_level(key, str(r.get("source_path", "")))
        if level >= 7:
            level = 6
        rows.append({
            "object_id": f"discovered_scalar_{i:05d}",
            "object_label": key,
            "value": value,
            "statistic": r.get("statistic", ""),
            "source_path": r.get("source_path", ""),
            "source_role": r.get("source_role", ""),
            "internal_type": "discovered_stage_scalar_or_summary_statistic",
            "semantic_candidates": "requires manual review; numeric proximity alone is not semantics",
            "allowed_claim_level": level,
            "claim_level_description": desc,
            "stage7a_status": "registry_only_pending_manual_review",
            "paper_use": "Do not use directly unless promoted by manual review and lineage/provenance check.",
        })

    return rows


def build_external_benchmark_permission_table(scalar_rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []

    # Frozen comparator rows against Omega_m.
    omega_m = FROZEN_COMPARATORS["Omega_m_benchmark"]
    for key in [
        "global_mu_conservative_qeg",
        "early_central_separation_sharp_candidate",
        "rejected_global_mu_wrong_source_priority",
        "rejected_early_central_separation_wrong_source_priority",
    ]:
        value = FROZEN_COMPARATORS[key]
        abs_diff = abs(value - omega_m)
        rel_diff = abs_diff / abs(omega_m) if omega_m != 0 else float("nan")
        rejected = key.startswith("rejected")
        rows.append({
            "qeg_quantity": key,
            "qeg_value": value,
            "external_benchmark": "Omega_m",
            "benchmark_value": omega_m,
            "absolute_difference": abs_diff,
            "relative_difference": rel_diff,
            "relative_difference_percent": 100.0 * rel_diff,
            "permission": "REJECTED_DO_NOT_USE" if rejected else "ALLOWED_AS_BENCHMARK_ONLY",
            "forbidden_claim": "derivation_or_fit_to_Omega_m",
            "required_caption": "Numerical proximity only; no physical identification or derivation asserted.",
            "status": "rejected_wrong_source_priority" if rejected else "stage7a_permitted_external_benchmark",
        })

    # General benchmark permission rows.
    for bname, binfo in REFERENCE_BENCHMARKS.items():
        rows.append({
            "qeg_quantity": "GENERAL_QEG_INVARIANT_POOL",
            "qeg_value": "",
            "external_benchmark": bname,
            "benchmark_value": binfo["value"],
            "absolute_difference": "",
            "relative_difference": "",
            "relative_difference_percent": "",
            "permission": "ALLOWED_AS_BENCHMARK_PANEL_ONLY",
            "benchmark_source_note": binfo["source_note"],
            "forbidden_claim": "identification_derivation_or_parameter_fitting",
            "required_caption": "External benchmark panel for semantic calibration; not a target and not a fitted value.",
            "status": binfo["permission"],
        })

    # Candidate scalar proximity audit: this is intentionally marked as low-level bookkeeping.
    # Only include dimensionless-like values to prevent a zoo.
    for i, r in enumerate(scalar_rows):
        value = safe_float(r.get("value"))
        key = str(r.get("scalar_key", ""))
        if value is None:
            continue
        if not (-1.5 <= value <= 1.5):
            continue
        if key.startswith("rejected"):
            continue
        for bname, binfo in REFERENCE_BENCHMARKS.items():
            bval = safe_float(binfo.get("value"))
            if bval is None:
                continue
            abs_diff = abs(value - bval)
            rel_diff = abs_diff / max(abs(bval), 1e-12)
            # Keep compact: only near-ish or named relevant. Still no claims.
            named_relevant = any(tok in key.lower() for tok in ["omega", "mu", "separation", "mass", "ratio", "fraction"])
            if rel_diff <= 0.15 or named_relevant:
                rows.append({
                    "qeg_quantity": key,
                    "qeg_value": value,
                    "external_benchmark": bname,
                    "benchmark_value": bval,
                    "absolute_difference": abs_diff,
                    "relative_difference": rel_diff,
                    "relative_difference_percent": 100.0 * rel_diff,
                    "permission": "NUMERICAL_PROXIMITY_BOOKKEEPING_ONLY",
                    "source_path": r.get("source_path", ""),
                    "source_role": r.get("source_role", ""),
                    "statistic": r.get("statistic", ""),
                    "forbidden_claim": "no_identification_no_derivation_no_cherry_picking",
                    "required_caption": "Candidate row generated by broad scalar scan; requires manual provenance review before manuscript use.",
                    "status": "candidate_unpromoted",
                })

    return rows


def build_entropy_state_space_registry(source_inventory: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    # This table defines state spaces before interpreting entropy.
    rows = [
        {
            "state_space_id": "normalized_rho_s",
            "state_space": "normalized rho(s) over intrinsic coordinate bins",
            "probability_vector": "p_i = max(rho_i,0)/sum max(rho_i,0)",
            "normalization_rule": "nonnegative clipping followed by sum-to-one normalization; sign-sensitive variants must be separate",
            "coarse_graining_rule": "intrinsic s bins inherited from Stage-6 profile; record bin count",
            "evolution_variable": "recursive index n if rho(s,n) exists; otherwise none",
            "interpretation_class": "geometric/modal entropy, not thermodynamic entropy",
            "null_controls_required": "bin-shuffle, low-k matched null, family-conditioned null",
            "physical_entropy_permission": "NO",
            "notes": "Use only as internal distributional complexity unless physically calibrated later.",
        },
        {
            "state_space_id": "normalized_kappa_s",
            "state_space": "normalized |kappa(s)| or signed-kappa split distribution",
            "probability_vector": "p_i = |kappa_i|/sum |kappa_i|, or positive/negative split",
            "normalization_rule": "absolute mass normalization; signed entropy must define two-channel state",
            "coarse_graining_rule": "same s grid as rho where possible",
            "evolution_variable": "recursive index n if kappa(s,n) exists; otherwise none",
            "interpretation_class": "curvature-like geometric entropy",
            "null_controls_required": "sign randomization, coordinate remap, low-k matched null",
            "physical_entropy_permission": "NO",
            "notes": "Do not equate curvature concentration entropy with thermodynamic entropy.",
        },
        {
            "state_space_id": "two_sector_mass_distribution",
            "state_space": "early vs central QEG sector masses",
            "probability_vector": "[M_early, M_central]/(M_early+M_central)",
            "normalization_rule": "sector masses must come from frozen canonical law or repaired lineage profiles",
            "coarse_graining_rule": "two-state partition; sector definitions must be frozen before comparison",
            "evolution_variable": "stage/recursion index if sector masses tracked across n",
            "interpretation_class": "sector-partition entropy / occupancy entropy",
            "null_controls_required": "sector-label swap, random partition, family-conditioned null",
            "physical_entropy_permission": "NO",
            "notes": "Most relevant to Omega-like semantic comparison, but not identification.",
        },
        {
            "state_space_id": "low_k_spectral_coefficients",
            "state_space": "normalized low-k spectral power distribution",
            "probability_vector": "p_k = |a_k|^2 / sum |a_k|^2 for selected basis",
            "normalization_rule": "basis and low-k cutoff must be recorded",
            "coarse_graining_rule": "Fourier/cosine/PCA basis; cutoff K must be explicit",
            "evolution_variable": "recursive index n or perturbation step",
            "interpretation_class": "spectral entropy / information concentration",
            "null_controls_required": "phase randomization, low-k matched null, white-noise null",
            "physical_entropy_permission": "NO",
            "notes": "Useful for time-surrogate evidence only when forward/reverse asymmetry survives nulls.",
        },
        {
            "state_space_id": "transport_transition_matrix",
            "state_space": "row-normalized nonlocal operator or recursion transport matrix",
            "probability_vector": "rows or stationary distribution of transition matrix",
            "normalization_rule": "nonnegative transport weights or signed-channel split",
            "coarse_graining_rule": "operator grid inherited from Stage-6 recursion/operator files",
            "evolution_variable": "operator iteration n",
            "interpretation_class": "transport-theoretic entropy / irreversibility diagnostic",
            "null_controls_required": "transpose operator, symmetrized operator, Toeplitz null, row-shuffled null",
            "physical_entropy_permission": "NO",
            "notes": "Strong candidate for internal arrow-of-time surrogate if forward/reverse gap persists.",
        },
        {
            "state_space_id": "family_conditioned_modal_distributions",
            "state_space": "BARI / NUFIT / VALENCIA modal distributions",
            "probability_vector": "per-family normalized modal or sector masses",
            "normalization_rule": "normalize within family; do not assign family by row index",
            "coarse_graining_rule": "family labels from repaired lineage only",
            "evolution_variable": "family + recursion index if available",
            "interpretation_class": "family-conditioned semantic stability diagnostic",
            "null_controls_required": "family permutation, lineage-preserving bootstrap",
            "physical_entropy_permission": "NO",
            "notes": "Prevents pooled artifact from masquerading as universal semantic object.",
        },
        {
            "state_space_id": "forward_reverse_recursion_state_clouds",
            "state_space": "cloud of states visited by forward and reverse/symmetrized recursion",
            "probability_vector": "histogram or kernel density over reduced state coordinates",
            "normalization_rule": "same bins for forward and reverse clouds",
            "coarse_graining_rule": "PCA/low-dimensional projection must be frozen before entropy comparison",
            "evolution_variable": "recursive index n",
            "interpretation_class": "time-surrogate diagnostic",
            "null_controls_required": "reverse operator, randomized recursion, low-k matched recursion, symmetric recursion",
            "physical_entropy_permission": "NO",
            "notes": "Closest Stage-7A diagnostic to an intrinsic arrow, still not physical time.",
        },
    ]

    # Attach source support counts by keyword matching.
    combined_text_score = Counter()
    for inv in source_inventory:
        role = str(inv.get("source_role", ""))
        combined_text_score[role] += int(inv.get("temporal_keyword_count", 0) or 0) + int(inv.get("information_keyword_count", 0) or 0)

    for row in rows:
        row["source_support_note"] = "Registry definition created by Stage-7A script; source support must be checked in downstream evidence table."
        row["stage7a_requirement"] = "state space must be cited/declared before any entropy-like statement"

    return rows


def build_time_surrogate_evidence_inventory(root: Path, files: List[Path]) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for p in files:
        if p.suffix.lower() not in TEXT_SUFFIXES:
            continue
        text = safe_read_text(p, max_chars=250_000)
        if not text:
            continue

        counts = {
            "forward": keyword_count(text, ["forward"]),
            "reverse": keyword_count(text, ["reverse"]),
            "entropy": keyword_count(text, ["entropy"]),
            "kl_information": keyword_count(text, ["kl", "kullback", "information", "divergence", "contraction"]),
            "attractor_stabilization": keyword_count(text, ["attractor", "stabilization", "stability", "convergence", "basin"]),
            "asymmetry": keyword_count(text, ["asymmetry", "asymmetric", "toeplitz", "non-toeplitz"]),
            "low_k": keyword_count(text, ["low-k", "low_k"]),
            "null_controls": keyword_count(text, ["null", "control", "randomized", "shuffle", "matched"]),
        }
        evidence_score = (
            2 * min(counts["forward"], counts["reverse"])
            + counts["entropy"]
            + counts["kl_information"]
            + counts["attractor_stabilization"]
            + counts["asymmetry"]
            + counts["low_k"]
            + counts["null_controls"]
        )

        if evidence_score <= 0:
            continue

        # Extract a few lines around key terms for human review.
        lines = text.splitlines()
        key_lines = []
        for idx, line in enumerate(lines):
            low = line.lower()
            if any(kw in low for kw in ["forward", "reverse", "entropy", "arrow", "attractor", "asymmetry", "low-k", "null"]):
                snippet = " ".join(lines[max(0, idx - 1): min(len(lines), idx + 2)])
                key_lines.append(snippet[:500])
            if len(key_lines) >= 3:
                break

        rows.append({
            "source_path": safe_rel(p, root),
            "source_role": classify_source(p),
            "evidence_score": evidence_score,
            **counts,
            "time_surrogate_status": "candidate_evidence_requires_null_audit" if evidence_score >= 5 else "weak_textual_signal",
            "interpretation_permission": "internal_time_surrogate_only_not_physical_time",
            "sample_context": " || ".join(key_lines),
        })

    rows.sort(key=lambda r: r.get("evidence_score", 0), reverse=True)
    return rows


def build_forward_reverse_recursion_audit(root: Path, files: List[Path]) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []

    for p in files:
        rel = safe_rel(p, root)
        s = str(p).lower()
        likely = any(tok in s for tok in ["forward", "reverse", "recursion", "recursive", "direction", "arrow"])
        if p.suffix.lower() == ".csv":
            try:
                df = pd.read_csv(p, low_memory=False)
            except Exception:
                continue

            cols = list(df.columns)
            lower_map = {str(c).lower(): c for c in cols}
            forward_cols = [c for c in cols if "forward" in str(c).lower()]
            for fcol in forward_cols:
                f_low = str(fcol).lower()
                candidate_names = [
                    f_low.replace("forward", "reverse"),
                    f_low.replace("fwd", "rev"),
                ]
                rcol = None
                for cand in candidate_names:
                    if cand in lower_map:
                        rcol = lower_map[cand]
                        break
                if rcol is None:
                    continue
                fvals = pd.to_numeric(df[fcol], errors="coerce").dropna()
                rvals = pd.to_numeric(df[rcol], errors="coerce").dropna()
                n = min(len(fvals), len(rvals))
                if n == 0:
                    continue
                f = fvals.iloc[:n].to_numpy(dtype=float)
                r = rvals.iloc[:n].to_numpy(dtype=float)
                rows.append({
                    "source_path": rel,
                    "source_role": classify_source(p),
                    "audit_type": "paired_forward_reverse_columns",
                    "forward_column": fcol,
                    "reverse_column": rcol,
                    "n_pairs": int(n),
                    "forward_mean": float(np.nanmean(f)),
                    "reverse_mean": float(np.nanmean(r)),
                    "mean_gap_forward_minus_reverse": float(np.nanmean(f) - np.nanmean(r)),
                    "abs_mean_gap": abs(float(np.nanmean(f) - np.nanmean(r))),
                    "corr_forward_reverse": pearson_corr(f, r),
                    "directionality_status": "candidate_directional_gap" if abs(float(np.nanmean(f) - np.nanmean(r))) > 1e-9 else "no_mean_gap_detected",
                    "interpretation_permission": "internal_directionality_only_requires_null_controls",
                })

            # If likely recursion file but no pair found, record existence.
            if likely and not any(r.get("source_path") == rel for r in rows):
                rows.append({
                    "source_path": rel,
                    "source_role": classify_source(p),
                    "audit_type": "recursion_file_no_explicit_forward_reverse_column_pair",
                    "directionality_status": "needs_manual_column_mapping",
                    "interpretation_permission": "no_directionality_claim",
                    "columns_sample": ", ".join(map(str, cols[:40])),
                })

        elif p.suffix.lower() in {".txt", ".md", ".json"}:
            if likely:
                text = safe_read_text(p, max_chars=120_000)
                rows.append({
                    "source_path": rel,
                    "source_role": classify_source(p),
                    "audit_type": "text_or_json_evidence_only",
                    "forward_mentions": keyword_count(text, ["forward"]),
                    "reverse_mentions": keyword_count(text, ["reverse"]),
                    "recursion_mentions": keyword_count(text, ["recursion", "recursive"]),
                    "entropy_mentions": keyword_count(text, ["entropy"]),
                    "directionality_status": "textual_candidate_requires_numeric_audit",
                    "interpretation_permission": "no_physical_time_claim",
                })

    if not rows:
        rows.append({
            "source_path": "",
            "source_role": "",
            "audit_type": "no_forward_reverse_sources_found",
            "directionality_status": "no_time_surrogate_claim",
            "interpretation_permission": "none",
        })

    return rows


def build_spacetime_coupling_diagnostics(root: Path, files: List[Path]) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for p in files:
        if p.suffix.lower() not in TEXT_SUFFIXES:
            continue
        text = safe_read_text(p, max_chars=180_000)
        if not text:
            continue

        spatial = keyword_count(text, SPATIAL_KEYWORDS)
        temporal = keyword_count(text, TEMPORAL_KEYWORDS)
        info = keyword_count(text, INFO_KEYWORDS)
        qm = keyword_count(text, QM_INTERPRETATION_KEYWORDS)

        if spatial + temporal + info < 2:
            continue

        coupling_score = min(spatial, temporal) + info
        if spatial > 0 and temporal > 0 and info > 0:
            status = "candidate_space_time_information_coupling"
        elif spatial > 0 and temporal > 0:
            status = "candidate_space_time_coupling_without_information_bridge"
        elif spatial > 0 and info > 0:
            status = "spatial_information_only"
        elif temporal > 0 and info > 0:
            status = "temporal_information_only"
        else:
            status = "single_axis_evidence_only"

        rows.append({
            "source_path": safe_rel(p, root),
            "source_role": classify_source(p),
            "spatial_keyword_count": spatial,
            "temporal_keyword_count": temporal,
            "information_keyword_count": info,
            "qm_interpretation_keyword_count": qm,
            "coupling_score": coupling_score,
            "diagnostic_status": status,
            "permitted_language": "space-time surrogate coupling only; does not assert physical spacetime",
            "manual_review_priority": "high" if coupling_score >= 5 and status.startswith("candidate") else "normal",
        })

    rows.sort(key=lambda r: r.get("coupling_score", 0), reverse=True)
    return rows


def build_claim_status_ladder() -> List[Dict[str, Any]]:
    levels = [
        (0, "raw numerical artifact", "Known rejected or unvalidated numerical output.", "Allowed only as negative control or warning."),
        (1, "stable internal invariant", "Stable under internal reruns or benign transformations.", "May be discussed as internal QEG structure."),
        (2, "lineage-preserved invariant", "Traceable to repaired BARI/NUFIT/VALENCIA lineage or equivalent source chain.", "May be used in methods/results if provenance documented."),
        (3, "family-universal internal invariant", "Survives BARI/NUFIT/VALENCIA separation or equivalent family audit.", "Strong internal result."),
        (4, "operator-supported internal invariant", "Supported by nonlocal/operator/low-rank mechanism evidence.", "Core QEG evidence, still internal."),
        (5, "semantic candidate for external comparison", "Has enough internal status to be compared to external benchmarks.", "Benchmark only; no identification."),
        (6, "mechanism-supported analogy", "Internal mechanism supports analogy to physical/semantic class.", "Allowed as analogy with caveats."),
        (7, "physical identification / derivation", "Claims QEG derives or identifies physical quantity.", "FORBIDDEN IN STAGE-7A."),
    ]
    rows = []
    for level, label, meaning, permission in levels:
        rows.append({
            "claim_level": level,
            "label": label,
            "meaning": meaning,
            "stage7a_permission": permission,
            "required_guardrail": "Explicit caveat required." if level in {5, 6} else ("Forbidden." if level == 7 else "Normal provenance discipline."),
        })
    return rows


def build_claim_guardrails_markdown(root_info: Dict[str, Any]) -> str:
    return f"""# Stage-7A Claim Guardrails

Generated: {now_iso()}

## Root resolution

- supplied_root: `{root_info.get('supplied_root')}`
- effective_project_root: `{root_info.get('effective_project_root')}`
- root_auto_corrected: `{root_info.get('root_auto_corrected')}`
- root_resolution_notes: {root_info.get('root_resolution_notes')}

## Non-negotiable claim boundary

Stage-7A may investigate semantic status, information-flow structure, entropy-like diagnostics, time surrogates, and space-time coupling hypotheses.

Stage-7A must **not** claim:

- QEG derives physical time.
- QEG derives spacetime.
- QEG derives Omega_m.
- QEG derives dark energy.
- QEG derives Einstein gravity.
- QEG proves entropy production.
- QEG proves thermodynamic irreversibility.
- QEG proves quantum gravity.
- Numerical proximity alone establishes physical semantics.

## Required wording for external benchmarks

Use:

> QEG identifies lineage-preserved internal dimensionless comparators that can be externally benchmarked against cosmological quantities. No physical identification or derivation is asserted.

Do not use:

> QEG derives Omega_m.

> QEG fits Omega_m.

> QEG rescales values to Omega_m.

> QEG derives cosmological parameters.

## Entropy language rule

No entropy-like quantity may be interpreted physically unless the following are explicitly defined:

1. state space
2. probability vector
3. normalization rule
4. coarse-graining rule
5. evolution variable
6. null controls
7. whether it is geometric, spectral, transport-theoretic, recursive, ensemble-based, or family-conditioned

Monotonicity alone is insufficient.

## Quantum interpretation note

The quantum-interpretation material is **conceptual / non-evidentiary**. It may guide future tests, but it should not be used as evidence in a Physica D submission unless explicitly marked as conceptual framing or future work.

Recommended manuscript policy:

- Main evidence paper: exclude detailed QM-interpretation claims.
- Possible future-work sentence: admissibility/relational language may be compared later with relational and consistent-histories frameworks.
- No equivalence with any interpretation of quantum mechanics may be claimed.

## Claim ladder

Stage-7A may discuss Levels 1--6.

Stage-7A may not claim Level 7.
"""


def build_ledger_note(summary: Dict[str, Any]) -> str:
    return f"""============================================================
STAGE-7A LEDGER NOTE
Project: Quantum-Emergent Gravity
Generated: {now_iso()}
============================================================

STAGE
-----
Stage-7A:
Semantic Calibration, Entropic Arrow, and Space-Time Coupling
in QEG Operator Geometry

PURPOSE
-------
This script begins the semantic layer of QEG after Stage-6Yn closure.

It does not upgrade QEG results into physical derivations.

It classifies semantic status, audits external benchmark permissions,
defines entropy state spaces, sweeps previous outputs for time-surrogate
evidence, and builds guardrails for manuscript-facing physics language.

ROOT RESOLUTION
---------------
supplied_root:
{summary.get('root_info', {}).get('supplied_root')}

effective_project_root:
{summary.get('root_info', {}).get('effective_project_root')}

root_auto_corrected:
{summary.get('root_info', {}).get('root_auto_corrected')}

root_resolution_notes:
{summary.get('root_info', {}).get('root_resolution_notes')}

SOURCE DISCOVERY
----------------
candidate_sources_found:
{summary.get('n_sources')}

scalar_candidates_found:
{summary.get('n_scalar_candidates')}

time_surrogate_evidence_rows:
{summary.get('n_time_surrogate_rows')}

spacetime_coupling_rows:
{summary.get('n_spacetime_coupling_rows')}

PRELIMINARY STAGE-7A VERDICT
----------------------------
{summary.get('stage7a_verdict')}

INTERPRETATION
--------------
Stage-7A is a semantic-calibration stage.

Accepted:
- internal invariant classification
- external benchmark permission tables
- entropy/state-space registry
- time-surrogate evidence inventory
- space-time surrogate coupling diagnostics
- negative-result preservation

Forbidden:
- physical identification
- Omega_m derivation
- entropy production claims without state space
- quantum-interpretation equivalence claims

NEXT-STAGE POLICY
-----------------
Stage-7B should not be automatic.

It requires at least one of:
1. stable semantic classification of the QEG comparator
2. nontrivial time-surrogate diagnostic surviving null controls
3. convincing space-time surrogate coupling diagnostic
4. disciplined negative result showing no current time surrogate

============================================================
END STAGE-7A LEDGER NOTE
============================================================
"""


def build_recommended_stage7b_handoff(summary: Dict[str, Any]) -> str:
    verdict = summary.get("stage7a_verdict", "UNKNOWN")
    return f"""============================================================
RECOMMENDED STAGE-7B HANDOFF
Project: Quantum-Emergent Gravity
Generated: {now_iso()}
============================================================

UPSTREAM
--------
Stage-7A:
Semantic Calibration, Entropic Arrow, and Space-Time Coupling

Stage-7A preliminary verdict:
{verdict}

STAGE-7B AUTHORIZATION STATUS
-----------------------------
NOT AUTOMATIC.

Stage-7B should be authorized only after manual review of:

1. stage7A_semantic_object_registry.csv
2. stage7A_external_benchmark_permission_table.csv
3. stage7A_entropy_state_space_registry.csv
4. stage7A_time_surrogate_evidence_inventory.csv
5. stage7A_forward_reverse_recursion_audit.csv
6. stage7A_spacetime_coupling_diagnostics.csv

POSSIBLE STAGE-7B TITLES
------------------------
- Mechanism-Side Semantics of QEG Invariants
- Time-Surrogate Robustness and Operator Irreversibility
- Space-Time Coupling Diagnostics in Emergent Operator Geometry
- Semantic Calibration of QEG Cosmology Benchmarks

RECOMMENDED STAGE-7B PRIMARY QUESTION
-------------------------------------
Do the strongest Stage-7A semantic/time-surrogate candidates survive
explicit null controls and family-conditioned perturbation audits?

MANDATORY STAGE-7B RULES
------------------------
- no Omega_m fitting
- no physical-time claim
- no physical-spacetime claim
- no QM interpretation claim
- no entropy claim without state-space declaration
- no synthetic detached recursion
- preserve BARI / NUFIT / VALENCIA lineage

============================================================
END STAGE-7B HANDOFF
============================================================
"""


# ----------------------------------------------------------------------
# OPTIONAL FIGURES
# ----------------------------------------------------------------------

def make_optional_figures(out_dir: Path,
                          source_inventory: List[Dict[str, Any]],
                          time_rows: List[Dict[str, Any]],
                          coupling_rows: List[Dict[str, Any]]) -> List[str]:
    made: List[str] = []
    if not HAVE_MATPLOTLIB:
        return made

    figures_dir = out_dir / "figures"
    ensure_dir(figures_dir)

    try:
        # Figure 1: source role counts.
        counts = Counter(row.get("source_role", "unknown") for row in source_inventory)
        if counts:
            labels, values = zip(*counts.most_common(20))
            plt.figure(figsize=(12, max(5, 0.35 * len(labels))))
            y = np.arange(len(labels))
            plt.barh(y, values)
            plt.yticks(y, labels)
            plt.xlabel("Number of discovered files")
            plt.title("Stage-7A retrospective source inventory by role")
            plt.tight_layout()
            path = figures_dir / "stage7A_source_role_counts.png"
            plt.savefig(path, dpi=160)
            plt.close()
            made.append(str(path))
    except Exception:
        plt.close()

    try:
        # Figure 2: top time-surrogate evidence scores.
        top = sorted(time_rows, key=lambda r: r.get("evidence_score", 0), reverse=True)[:20]
        if top:
            labels = [Path(str(r.get("source_path", ""))).name[:40] for r in top]
            values = [float(r.get("evidence_score", 0) or 0) for r in top]
            plt.figure(figsize=(12, max(5, 0.35 * len(labels))))
            y = np.arange(len(labels))
            plt.barh(y, values)
            plt.yticks(y, labels)
            plt.xlabel("Textual evidence score")
            plt.title("Stage-7A time-surrogate evidence inventory")
            plt.tight_layout()
            path = figures_dir / "stage7A_time_surrogate_evidence_scores.png"
            plt.savefig(path, dpi=160)
            plt.close()
            made.append(str(path))
    except Exception:
        plt.close()

    try:
        # Figure 3: coupling diagnostic scatter.
        xs = [float(r.get("spatial_keyword_count", 0) or 0) for r in coupling_rows]
        ys = [float(r.get("temporal_keyword_count", 0) or 0) for r in coupling_rows]
        sizes = [20 + 5 * float(r.get("information_keyword_count", 0) or 0) for r in coupling_rows]
        if xs and ys:
            plt.figure(figsize=(8, 6))
            plt.scatter(xs, ys, s=sizes, alpha=0.7)
            plt.xlabel("Spatial / geometry keyword count")
            plt.ylabel("Temporal / recursion keyword count")
            plt.title("Stage-7A space-time surrogate coupling screen")
            plt.tight_layout()
            path = figures_dir / "stage7A_spacetime_coupling_screen.png"
            plt.savefig(path, dpi=160)
            plt.close()
            made.append(str(path))
    except Exception:
        plt.close()

    try:
        # Figure 4: claim status ladder.
        ladder = build_claim_status_ladder()
        labels = [f"L{r['claim_level']}: {r['label']}" for r in ladder]
        values = [r["claim_level"] for r in ladder]
        plt.figure(figsize=(12, 6))
        plt.bar(range(len(values)), values)
        plt.xticks(range(len(values)), labels, rotation=45, ha="right")
        plt.ylabel("Claim level")
        plt.title("Stage-7A claim-status ladder")
        plt.tight_layout()
        path = figures_dir / "stage7A_claim_status_ladder.png"
        plt.savefig(path, dpi=160)
        plt.close()
        made.append(str(path))
    except Exception:
        plt.close()

    return made


# ----------------------------------------------------------------------
# SUMMARY VERDICT
# ----------------------------------------------------------------------

def compute_stage7a_verdict(source_inventory: List[Dict[str, Any]],
                            semantic_rows: List[Dict[str, Any]],
                            entropy_rows: List[Dict[str, Any]],
                            time_rows: List[Dict[str, Any]],
                            forward_rows: List[Dict[str, Any]],
                            coupling_rows: List[Dict[str, Any]]) -> str:
    has_sources = len(source_inventory) > 0
    has_entropy_registry = len(entropy_rows) >= 3
    has_semantic = len(semantic_rows) >= 3
    has_time_candidates = any((r.get("time_surrogate_status") == "candidate_evidence_requires_null_audit") for r in time_rows)
    has_forward_pairs = any((r.get("audit_type") == "paired_forward_reverse_columns") for r in forward_rows)
    has_coupling = any(str(r.get("diagnostic_status", "")).startswith("candidate_space_time") for r in coupling_rows)

    if not has_sources:
        return "C_REVIEW_REQUIRED_NO_STAGE6_SOURCES_DISCOVERED"
    if has_semantic and has_entropy_registry and (has_time_candidates or has_forward_pairs or has_coupling):
        return "B_SEMANTIC_REGISTRY_BUILT_TIME_SURROGATE_CANDIDATES_FOUND_REVIEW_REQUIRED"
    if has_semantic and has_entropy_registry:
        return "B_MINUS_SEMANTIC_AND_ENTROPY_GUARDRAILS_BUILT_NO_STRONG_TIME_SURROGATE_YET"
    return "C_REVIEW_REQUIRED_INCOMPLETE_OUTPUTS"


# ----------------------------------------------------------------------
# MAIN
# ----------------------------------------------------------------------

def main() -> None:
    print("=" * 72)
    print("Quantum-Emergent Gravity")
    print("Stage-7A: Semantic Calibration and Intrinsic Time Surrogates")
    print("=" * 72)

    project_root, root_info = resolve_project_root(USER_SUPPLIED_ROOT)
    out_dir = project_root / OUTPUT_RELATIVE
    ensure_dir(out_dir)

    print(f"Supplied/current root : {root_info['supplied_root']}")
    print(f"Effective project root: {root_info['effective_project_root']}")
    print(f"Output directory      : {out_dir}")
    print(f"Root auto-corrected   : {root_info['root_auto_corrected']}")
    print("-" * 72)

    print("Discovering Stage-7A input sources...")
    files = discover_sources(project_root)
    print(f"Discovered {len(files)} candidate source files.")

    print("Building source inventory...")
    source_inventory = build_source_inventory(project_root, files)

    print("Collecting scalar candidates...")
    scalar_rows = collect_relevant_scalars(project_root, files)

    print("Building semantic object registry...")
    semantic_rows = build_semantic_object_registry(scalar_rows)

    print("Building external benchmark permission table...")
    benchmark_rows = build_external_benchmark_permission_table(scalar_rows)

    print("Building entropy state-space registry...")
    entropy_rows = build_entropy_state_space_registry(source_inventory)

    print("Sweeping for time-surrogate evidence...")
    time_rows = build_time_surrogate_evidence_inventory(project_root, files)

    print("Auditing forward/reverse recursion evidence...")
    forward_rows = build_forward_reverse_recursion_audit(project_root, files)

    print("Building space-time surrogate coupling diagnostics...")
    coupling_rows = build_spacetime_coupling_diagnostics(project_root, files)

    print("Building claim ladder and guardrails...")
    ladder_rows = build_claim_status_ladder()

    stage7a_verdict = compute_stage7a_verdict(
        source_inventory=source_inventory,
        semantic_rows=semantic_rows,
        entropy_rows=entropy_rows,
        time_rows=time_rows,
        forward_rows=forward_rows,
        coupling_rows=coupling_rows,
    )

    figure_paths = make_optional_figures(out_dir, source_inventory, time_rows, coupling_rows)

    summary = {
        "project": "Quantum-Emergent Gravity",
        "stage": "Stage-7A",
        "stage_title": STAGE_TITLE,
        "generated_utc": now_iso(),
        "script_file": str(Path(__file__).resolve()) if "__file__" in globals() else "Spyder interactive",
        "root_info": root_info,
        "output_directory": str(out_dir),
        "n_sources": len(files),
        "n_source_inventory_rows": len(source_inventory),
        "n_scalar_candidates": len(scalar_rows),
        "n_semantic_object_rows": len(semantic_rows),
        "n_external_benchmark_permission_rows": len(benchmark_rows),
        "n_entropy_state_space_rows": len(entropy_rows),
        "n_time_surrogate_rows": len(time_rows),
        "n_forward_reverse_rows": len(forward_rows),
        "n_spacetime_coupling_rows": len(coupling_rows),
        "n_claim_ladder_rows": len(ladder_rows),
        "optional_figures_created": figure_paths,
        "stage7a_verdict": stage7a_verdict,
        "frozen_comparators": FROZEN_COMPARATORS,
        "strict_prohibitions": [
            "no Omega_m fitting",
            "no Omega_m rescaling",
            "no cosmological-parameter derivation claim",
            "no entropy interpretation without state-space definition",
            "no synthetic detached recursion",
            "no Stage-6 frozen value overwrite",
            "no reinterpretation of failed local PDE closures as successful",
            "no physical identification in Stage-7A",
        ],
        "qm_interpretation_policy": {
            "status": "conceptual_non_evidentiary",
            "recommended_paper_use": "exclude from main evidence unless marked as conceptual/future work",
            "allowed_use": "bias checkpoint and future-test generator",
            "forbidden_use": "evidence that QEG confirms any quantum interpretation",
        },
    }

    print("Writing mandatory outputs...")

    write_json(out_dir / "stage7A_summary.json", summary)

    write_csv(out_dir / "stage7A_semantic_object_registry.csv", semantic_rows)
    write_csv(out_dir / "stage7A_external_benchmark_permission_table.csv", benchmark_rows)
    write_csv(out_dir / "stage7A_entropy_state_space_registry.csv", entropy_rows)
    write_csv(out_dir / "stage7A_time_surrogate_evidence_inventory.csv", time_rows)
    write_csv(out_dir / "stage7A_forward_reverse_recursion_audit.csv", forward_rows)
    write_csv(out_dir / "stage7A_spacetime_coupling_diagnostics.csv", coupling_rows)
    write_csv(out_dir / "stage7A_claim_status_ladder.csv", ladder_rows)
    write_csv(out_dir / "stage7A_retrospective_source_inventory.csv", source_inventory)

    claim_guardrails = build_claim_guardrails_markdown(root_info)
    (out_dir / "stage7A_claim_guardrails.md").write_text(claim_guardrails, encoding="utf-8")

    ledger_note = build_ledger_note(summary)
    (out_dir / "stage7A_ledger_note.txt").write_text(ledger_note, encoding="utf-8")

    handoff = build_recommended_stage7b_handoff(summary)
    (out_dir / "stage7A_recommended_stage7B_handoff.txt").write_text(handoff, encoding="utf-8")

    # Additional helpful output: scalar pool is not mandatory but useful for manual review.
    write_csv(out_dir / "stage7A_discovered_scalar_pool_REVIEW_ONLY.csv", scalar_rows)

    print("=" * 72)
    print("STAGE-7A SCRIPT COMPLETE")
    print("=" * 72)
    print(f"Verdict: {stage7a_verdict}")
    print(f"Output directory:")
    print(str(out_dir))
    print()
    print("Mandatory outputs written:")
    mandatory = [
        "stage7A_summary.json",
        "stage7A_ledger_note.txt",
        "stage7A_semantic_object_registry.csv",
        "stage7A_external_benchmark_permission_table.csv",
        "stage7A_entropy_state_space_registry.csv",
        "stage7A_time_surrogate_evidence_inventory.csv",
        "stage7A_forward_reverse_recursion_audit.csv",
        "stage7A_spacetime_coupling_diagnostics.csv",
        "stage7A_claim_status_ladder.csv",
        "stage7A_claim_guardrails.md",
        "stage7A_retrospective_source_inventory.csv",
        "stage7A_recommended_stage7B_handoff.txt",
    ]
    for name in mandatory:
        print(f"  - {name}")
    if figure_paths:
        print()
        print("Optional figures:")
        for fp in figure_paths:
            print(f"  - {fp}")
    print("=" * 72)


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print("=" * 72)
        print("STAGE-7A SCRIPT FAILED")
        print("=" * 72)
        print(repr(exc))
        traceback.print_exc()
        print("=" * 72)
        raise
