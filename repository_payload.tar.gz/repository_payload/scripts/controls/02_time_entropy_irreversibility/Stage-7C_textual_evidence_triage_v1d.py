#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Quantum-Emergent Gravity — Stage-7C-v1d
Textual Evidence Triage after Witness-Recognition Repair

Author: Arturo Ortiz-Tapia / QEG pipeline support
Build date: 2026-05-31

Purpose
-------
This is NOT Stage-7D and not a new physics stage.
It is a text-first diagnostic script inside Stage-7C.

Stage-7C-v1c repaired the v1a/v1b implementation failures and reported:
    - loaded files: 48
    - candidate rows: 48155
    - Tier-1/admissible rows: 18522
    - directionality witnesses: 590
    - null witnesses: 15400
    - low-k paired witnesses: 0
    - entropy state-space witnesses: 9508
    - sanity errors: 0
    - final verdict: C_REVIEW_REQUIRED_AFTER_REPAIRED_WITNESS_FILTER

The figures from v1c/v1a are not enough for scientific decision-making.
This script reads the v1c output tables and produces a text-forward review:
    - executive review TXT/MD
    - channel scorecard CSV
    - directionality sign/source/family summaries
    - null survival summaries
    - entropy state-space summaries
    - low-k blocker audit
    - reversibility review
    - top positive/negative directionality rows
    - concrete recommendation for the next repair/adjudication move

Physical guardrails remain unchanged:
    - no physical time derived;
    - no thermodynamic entropy production proven;
    - no spacetime / Friedmann / GR / Omega_m / dark-energy claim;
    - physical semantics bridge material remains tracker-only.
"""

from __future__ import annotations

import argparse
import json
import math
import re
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

PROJECT_NAME = "Quantum-Emergent Gravity"
STAGE = "Stage-7C-v1d"
SCRIPT_NAME = "Stage-7C_textual_evidence_triage_v1d.py"
DEFAULT_V1C_SUBDIR = "metric_stage_7C_outputs/witness_recognition_overexclusion_repair_v1c"
OUT_SUBDIR = "metric_stage_7C_outputs/textual_evidence_triage_v1d"
FAMILY_VALUES = ["BARI", "NUFIT", "VALENCIA"]

FORBIDDEN_CLAIMS = [
    "physical time derived",
    "spacetime derived",
    "thermodynamic arrow proven",
    "entropy production proven",
    "cosmic age derived",
    "Friedmann equations derived",
    "Einstein gravity derived",
    "Omega_m derived",
    "dark energy derived",
    "curvature of the universe derived",
    "quantum gravity proven",
    "quantum-mechanical interpretation confirmed",
]


def now_iso() -> str:
    return datetime.now().replace(microsecond=0).isoformat()


def norm_name(x: Any) -> str:
    s = str(x).strip().lower()
    s = re.sub(r"[^a-z0-9]+", "_", s)
    return re.sub(r"_+", "_", s).strip("_")


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def infer_project_root(explicit_root: Optional[str] = None) -> Path:
    if explicit_root:
        return Path(explicit_root).expanduser().resolve()
    here = Path(__file__).resolve()
    for p in [here.parent, *here.parents]:
        if p.name == "metric_stage_7C_scripts":
            return p.parent.resolve()
    cwd = Path.cwd().resolve()
    for p in [cwd, *cwd.parents]:
        if (p / "metric_stage_7C_scripts").exists() or (p / "metric_stage_7C_outputs").exists():
            return p
    return cwd


def safe_read_csv(path: Path) -> pd.DataFrame:
    if not path.exists():
        return pd.DataFrame()
    try:
        return pd.read_csv(path)
    except Exception:
        try:
            return pd.read_csv(path, engine="python", on_bad_lines="skip")
        except Exception as exc:
            return pd.DataFrame({"__read_error__": [str(exc)], "__path__": [str(path)]})


def safe_read_json(path: Path) -> Dict[str, Any]:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        try:
            return json.loads(path.read_text(encoding="latin-1"))
        except Exception:
            return {}


def write_json(path: Path, obj: Dict[str, Any]) -> None:
    def conv(x: Any) -> Any:
        if isinstance(x, dict):
            return {str(k): conv(v) for k, v in x.items()}
        if isinstance(x, list):
            return [conv(v) for v in x]
        if isinstance(x, tuple):
            return [conv(v) for v in x]
        if isinstance(x, (np.integer,)):
            return int(x)
        if isinstance(x, (np.floating,)):
            f = float(x)
            return None if not math.isfinite(f) else f
        if isinstance(x, float):
            return None if not math.isfinite(x) else x
        if isinstance(x, (np.bool_,)):
            return bool(x)
        try:
            if pd.isna(x):
                return None
        except Exception:
            pass
        return x
    path.write_text(json.dumps(conv(obj), indent=2, ensure_ascii=False), encoding="utf-8")


def find_v1c_dir(root: Path, explicit: Optional[str] = None) -> Path:
    if explicit:
        p = Path(explicit).expanduser().resolve()
        if p.exists():
            return p
    default = root / DEFAULT_V1C_SUBDIR
    if default.exists():
        return default
    candidates = list((root / "metric_stage_7C_outputs").glob("**/stage7C_v1c_summary.json")) if (root / "metric_stage_7C_outputs").exists() else []
    if candidates:
        return max((p.parent for p in candidates), key=lambda p: p.stat().st_mtime)
    return default


def first_existing(*cols: str, df: pd.DataFrame) -> Optional[str]:
    if df.empty:
        return None
    by_norm = {norm_name(c): c for c in df.columns}
    for c in cols:
        nc = norm_name(c)
        if nc in by_norm:
            return by_norm[nc]
    for c in df.columns:
        nc = norm_name(c)
        if any(norm_name(w) in nc for w in cols):
            return c
    return None


def series_num(df: pd.DataFrame, col: Optional[str]) -> pd.Series:
    if df.empty or not col or col not in df.columns:
        return pd.Series(dtype=float)
    return pd.to_numeric(df[col], errors="coerce")


def boolish_series(df: pd.DataFrame, col: Optional[str]) -> pd.Series:
    if df.empty or not col or col not in df.columns:
        return pd.Series(dtype=bool)
    s = df[col]
    if pd.api.types.is_bool_dtype(s):
        return s.fillna(False)
    txt = s.astype(str).str.strip().str.lower()
    return txt.isin(["true", "1", "yes", "y", "pass", "passed", "supported", "valid"])


def qstats(s: pd.Series) -> Dict[str, Any]:
    x = pd.to_numeric(s, errors="coerce").dropna()
    if x.empty:
        return {"n": 0}
    return {
        "n": int(len(x)),
        "mean": float(x.mean()),
        "median": float(x.median()),
        "std": float(x.std(ddof=0)),
        "min": float(x.min()),
        "q05": float(x.quantile(0.05)),
        "q25": float(x.quantile(0.25)),
        "q75": float(x.quantile(0.75)),
        "q95": float(x.quantile(0.95)),
        "max": float(x.max()),
    }


def value_counts_df(df: pd.DataFrame, col: str, name: str, max_rows: int = 100) -> pd.DataFrame:
    if df.empty or col not in df.columns:
        return pd.DataFrame(columns=[col, "count", "fraction"])
    vc = df[col].fillna("MISSING").astype(str).value_counts(dropna=False).head(max_rows)
    out = vc.rename_axis(col).reset_index(name="count")
    out["fraction"] = out["count"] / max(len(df), 1)
    out.insert(0, "table", name)
    return out


def make_group_summary(df: pd.DataFrame, group_cols: List[str], score_col: Optional[str], extra_bool_col: Optional[str] = None) -> pd.DataFrame:
    if df.empty:
        return pd.DataFrame()
    group_cols = [c for c in group_cols if c in df.columns]
    if not group_cols:
        return pd.DataFrame()
    work = df.copy()
    if score_col and score_col in work.columns:
        work[score_col] = pd.to_numeric(work[score_col], errors="coerce")
    rows = []
    for keys, g in work.groupby(group_cols, dropna=False):
        if not isinstance(keys, tuple):
            keys = (keys,)
        row = {c: k for c, k in zip(group_cols, keys)}
        row["row_count"] = int(len(g))
        if score_col and score_col in g.columns:
            x = pd.to_numeric(g[score_col], errors="coerce").dropna()
            row.update({
                f"{score_col}_n": int(len(x)),
                f"{score_col}_mean": float(x.mean()) if len(x) else np.nan,
                f"{score_col}_median": float(x.median()) if len(x) else np.nan,
                f"{score_col}_positive_fraction": float((x > 0).mean()) if len(x) else np.nan,
                f"{score_col}_q25": float(x.quantile(0.25)) if len(x) else np.nan,
                f"{score_col}_q75": float(x.quantile(0.75)) if len(x) else np.nan,
            })
        if extra_bool_col and extra_bool_col in g.columns:
            b = boolish_series(g, extra_bool_col)
            row[f"{extra_bool_col}_fraction"] = float(b.mean()) if len(b) else np.nan
        rows.append(row)
    return pd.DataFrame(rows).sort_values("row_count", ascending=False)


def detect_gap_col(direction: pd.DataFrame) -> Optional[str]:
    for c in ["gap_forward_minus_reverse", "gap_original", "directionality_gap", "gap", "forward_minus_reverse", "delta"]:
        found = first_existing(c, df=direction)
        if found:
            return found
    # last resort: any numeric column containing gap but not reverse-minus if both exist
    for c in direction.columns:
        nc = norm_name(c)
        if "gap" in nc:
            return c
    return None


def load_v1c_outputs(v1c_dir: Path) -> Dict[str, Any]:
    files = {
        "summary": v1c_dir / "stage7C_v1c_summary.json",
        "input_audit": v1c_dir / "stage7C_v1c_input_presence_audit.csv",
        "column_map": v1c_dir / "stage7C_v1c_channel_column_map.csv",
        "sanity": v1c_dir / "stage7C_v1c_sanity_audit.csv",
        "witness": v1c_dir / "stage7C_v1c_witness_class_table.csv",
        "directionality": v1c_dir / "stage7C_v1c_directionality_repaired_table.csv",
        "null": v1c_dir / "stage7C_v1c_null_survival_repaired_table.csv",
        "family": v1c_dir / "stage7C_v1c_family_stability_repaired_table.csv",
        "lowk": v1c_dir / "stage7C_v1c_lowk_reconstruction_audit.csv",
        "entropy": v1c_dir / "stage7C_v1c_entropy_state_space_completion.csv",
        "reversibility": v1c_dir / "stage7C_v1c_reversibility_sandbox_repaired.csv",
        "denominator": v1c_dir / "stage7C_v1c_valid_denominator_audit.csv",
        "layered": v1c_dir / "stage7C_v1c_layered_verdict_table.csv",
    }
    data = {"files": {k: str(v) for k, v in files.items()}}
    data["summary"] = safe_read_json(files["summary"])
    for k, p in files.items():
        if k == "summary":
            continue
        data[k] = safe_read_csv(p)
    return data


def analyze_directionality(direction: pd.DataFrame, outdir: Path) -> Dict[str, Any]:
    res: Dict[str, Any] = {"row_count": int(len(direction))}
    if direction.empty:
        res["verdict"] = "NOT_TESTED_DIRECTIONALITY_TABLE_EMPTY"
        return res
    gap_col = detect_gap_col(direction)
    res["gap_column"] = gap_col or ""
    gap = series_num(direction, gap_col)
    res["gap_stats"] = qstats(gap)
    n = int(gap.notna().sum())
    if n == 0:
        res["verdict"] = "DIRECTIONALITY_PRESENT_BUT_NO_NUMERIC_GAP"
        return res
    pos = float((gap.dropna() > 0).mean())
    neg = float((gap.dropna() < 0).mean())
    zero = float((gap.dropna() == 0).mean())
    res.update({
        "numeric_gap_n": n,
        "positive_fraction_forward_minus_reverse": pos,
        "negative_fraction_forward_minus_reverse": neg,
        "zero_fraction": zero,
    })
    if pos >= 0.70:
        verdict = "FORWARD_SIGN_DIRECTIONALITY_SUPPORTED_REVIEW"
    elif neg >= 0.70:
        verdict = "REVERSE_SIGN_DIRECTIONALITY_SUPPORTED_REVIEW_OR_SIGN_CONVENTION_FLIP"
    elif max(pos, neg) >= 0.55:
        verdict = "WEAK_DIRECTIONALITY_BIAS_REVIEW"
    else:
        verdict = "MIXED_DIRECTIONALITY_NO_DOMINANT_SIGN"
    res["verdict"] = verdict

    # Save quantiles and source/family breakdowns.
    q = pd.DataFrame([res["gap_stats"]])
    q.insert(0, "gap_column", gap_col or "")
    q.to_csv(outdir / "stage7C_v1d_directionality_gap_quantiles.csv", index=False)

    work = direction.copy()
    work["__gap__"] = gap
    group_cols = [c for c in ["source_name", "source_channel", "family", "tier_label", "admissibility_label"] if c in work.columns]
    if "source_name" in group_cols:
        make_group_summary(work, ["source_name"], "__gap__").to_csv(outdir / "stage7C_v1d_directionality_by_source.csv", index=False)
    if "family" in group_cols:
        make_group_summary(work, ["family"], "__gap__").to_csv(outdir / "stage7C_v1d_directionality_by_family.csv", index=False)
    if "source_channel" in group_cols:
        make_group_summary(work, ["source_channel"], "__gap__").to_csv(outdir / "stage7C_v1d_directionality_by_channel.csv", index=False)

    cols_keep = [c for c in ["source_name", "source_channel", "family", "candidate_id", "tier_label", "admissibility_label", gap_col] if c and c in direction.columns]
    if cols_keep:
        tmp = direction.copy()
        tmp["__gap__"] = gap
        tmp.sort_values("__gap__", ascending=False).head(40)[cols_keep + ["__gap__"]].to_csv(outdir / "stage7C_v1d_top_positive_directionality_rows.csv", index=False)
        tmp.sort_values("__gap__", ascending=True).head(40)[cols_keep + ["__gap__"]].to_csv(outdir / "stage7C_v1d_top_negative_directionality_rows.csv", index=False)
    return res


def analyze_null(null: pd.DataFrame, outdir: Path) -> Dict[str, Any]:
    res: Dict[str, Any] = {"row_count": int(len(null))}
    if null.empty:
        res["verdict"] = "NOT_TESTED_NULL_TABLE_EMPTY"
        return res
    score_col = first_existing("null_survival_score", "survival_score", "null_score", "score", df=null)
    res["score_column"] = score_col or ""
    score = series_num(null, score_col)
    res["score_stats"] = qstats(score)
    n = int(score.notna().sum())
    if n == 0:
        res["verdict"] = "NULL_PRESENT_BUT_NO_NUMERIC_SCORE"
        return res
    pass80 = float((score.dropna() >= 0.80).mean())
    pass70 = float((score.dropna() >= 0.70).mean())
    res.update({"numeric_score_n": n, "pass_0_80_fraction": pass80, "pass_0_70_fraction": pass70})
    if pass80 >= 0.70:
        verdict = "NULL_SURVIVAL_STRONG_REVIEW"
    elif pass80 >= 0.40 or pass70 >= 0.60:
        verdict = "NULL_SURVIVAL_PARTIAL_REVIEW"
    else:
        verdict = "NULL_SURVIVAL_WEAK_OR_MIXED"
    res["verdict"] = verdict
    work = null.copy()
    work["__null_score__"] = score
    if "source_name" in work.columns:
        make_group_summary(work, ["source_name"], "__null_score__").to_csv(outdir / "stage7C_v1d_null_by_source.csv", index=False)
    if "family" in work.columns:
        make_group_summary(work, ["family"], "__null_score__").to_csv(outdir / "stage7C_v1d_null_by_family.csv", index=False)
    return res


def analyze_entropy(entropy: pd.DataFrame, outdir: Path) -> Dict[str, Any]:
    res: Dict[str, Any] = {"row_count": int(len(entropy))}
    if entropy.empty:
        res["verdict"] = "NOT_TESTED_ENTROPY_TABLE_EMPTY"
        return res
    valid_col = first_existing("entropy_state_space_valid", "valid_entropy_state_space_witness", "state_space_valid", df=entropy)
    slope_col = first_existing("entropy_like_slope", "entropy_slope", "slope", df=entropy)
    valid = boolish_series(entropy, valid_col) if valid_col else pd.Series(dtype=bool)
    slope = series_num(entropy, slope_col)
    res.update({
        "valid_column": valid_col or "",
        "state_space_valid_fraction": float(valid.mean()) if len(valid) else np.nan,
        "slope_column": slope_col or "",
        "slope_stats": qstats(slope),
    })
    if len(valid) and float(valid.mean()) >= 0.90:
        res["verdict"] = "ENTROPY_STATE_SPACE_COMPLETION_STRONG_INTERNAL_ONLY"
    elif len(valid) and float(valid.mean()) >= 0.50:
        res["verdict"] = "ENTROPY_STATE_SPACE_COMPLETION_PARTIAL_INTERNAL_ONLY"
    else:
        res["verdict"] = "ENTROPY_STATE_SPACE_WEAK_OR_UNDECLARED"
    if "entropy_state_space_status" in entropy.columns:
        value_counts_df(entropy, "entropy_state_space_status", "entropy_status").to_csv(outdir / "stage7C_v1d_entropy_state_space_status_counts.csv", index=False)
    if "source_name" in entropy.columns:
        make_group_summary(entropy.assign(__valid__=valid.values if len(valid) == len(entropy) else np.nan), ["source_name"], slope_col if slope_col else None, "entropy_state_space_valid" if "entropy_state_space_valid" in entropy.columns else None).to_csv(outdir / "stage7C_v1d_entropy_by_source.csv", index=False)
    return res


def analyze_lowk(lowk: pd.DataFrame, outdir: Path) -> Dict[str, Any]:
    res: Dict[str, Any] = {"row_count": int(len(lowk))}
    if lowk.empty:
        res["verdict"] = "NOT_TESTED_LOWK_TABLE_EMPTY"
        res["blocker"] = "No low-k audit rows in v1c outputs."
        return res
    status_col = first_existing("lowk_reverse_evidence_status", "reverse_evidence_status", "status", df=lowk)
    if status_col:
        counts = value_counts_df(lowk, status_col, "lowk_reverse_evidence_status")
        counts.to_csv(outdir / "stage7C_v1d_lowk_status_counts.csv", index=False)
        status_text = " ".join(lowk[status_col].fillna("").astype(str).str.upper().tolist())
    else:
        status_text = ""
    pair_count = int(status_text.count("TESTED_FORWARD_REVERSE_LOWK_PAIR")) if status_col else 0
    # More reliable if both numeric columns exist.
    fwd = first_existing("forward_lowk_retention", "lowk_forward", "forward_lowk", df=lowk)
    rev = first_existing("reverse_lowk_retention", "lowk_reverse", "reverse_lowk", df=lowk)
    if fwd and rev:
        paired = series_num(lowk, fwd).notna() & series_num(lowk, rev).notna()
        pair_count = int(paired.sum())
    res["paired_forward_reverse_count"] = pair_count
    if pair_count == 0:
        res["verdict"] = "LOWK_ARROW_NOT_ADJUDICABLE_REVERSE_MISSING"
        res["blocker"] = "Reverse/backward low-k reconstruction is still missing; do not use low-k as negative evidence."
    else:
        gap_col = first_existing("lowk_gap_forward_minus_reverse", "lowk_gap", df=lowk)
        gap = series_num(lowk, gap_col)
        res["gap_stats"] = qstats(gap)
        res["positive_gap_fraction"] = float((gap.dropna() > 0).mean()) if gap.notna().any() else np.nan
        res["verdict"] = "LOWK_FORWARD_REVERSE_AVAILABLE_REVIEW"
    return res


def analyze_reversibility(rev: pd.DataFrame, outdir: Path) -> Dict[str, Any]:
    res: Dict[str, Any] = {"row_count": int(len(rev))}
    if rev.empty:
        res["verdict"] = "NOT_TESTED_REVERSIBILITY_TABLE_EMPTY"
        return res
    tag_col = first_existing("reversibility_interpretation_tag", "interpretation_tag", "tag", df=rev)
    if tag_col:
        value_counts_df(rev, tag_col, "reversibility_tags").to_csv(outdir / "stage7C_v1d_reversibility_tag_counts.csv", index=False)
        tags = rev[tag_col].fillna("").astype(str).str.upper()
        candidate_frac = float(tags.str.contains("CANDIDATE").mean())
    else:
        candidate_frac = np.nan
    res["candidate_tag_fraction"] = candidate_frac
    if pd.notna(candidate_frac) and candidate_frac > 0.20:
        res["verdict"] = "REVERSIBLE_SECTOR_CANDIDATES_REQUIRE_REVIEW"
    else:
        res["verdict"] = "NO_STRUCTURED_REVERSIBLE_SECTOR_OR_WEAK_CANDIDATES"
    return res


def summarize_column_map(column_map: pd.DataFrame, outdir: Path) -> Dict[str, Any]:
    res = {"row_count": int(len(column_map))}
    if column_map.empty:
        res["verdict"] = "NO_COLUMN_MAP_AVAILABLE"
        return res
    # Save compact source map focusing on nonzero valid rows.
    valid_cols = [c for c in column_map.columns if c.endswith("_valid_rows") or c.endswith("_count_after_repair") or c.endswith("_rows")]
    keep = [c for c in ["source_name", "source_channel", "n_rows", "tier_columns", "forward_col", "reverse_col", "gap_col", "directionality_mapping_method", "null_score_col", "lowk_forward_col", "lowk_reverse_col", "entropy_state_space_col"] if c in column_map.columns]
    keep += [c for c in valid_cols if c not in keep]
    if keep:
        column_map[keep].to_csv(outdir / "stage7C_v1d_compact_column_map.csv", index=False)
    res["sources_with_directionality_rows"] = int((pd.to_numeric(column_map.get("directionality_valid_rows", pd.Series(dtype=float)), errors="coerce").fillna(0) > 0).sum()) if "directionality_valid_rows" in column_map else 0
    res["sources_with_null_rows"] = int((pd.to_numeric(column_map.get("null_valid_rows", pd.Series(dtype=float)), errors="coerce").fillna(0) > 0).sum()) if "null_valid_rows" in column_map else 0
    res["sources_with_entropy_rows"] = int((pd.to_numeric(column_map.get("entropy_valid_rows", pd.Series(dtype=float)), errors="coerce").fillna(0) > 0).sum()) if "entropy_valid_rows" in column_map else 0
    return res


def build_scorecard(analyses: Dict[str, Dict[str, Any]]) -> pd.DataFrame:
    rows = []
    for channel, a in analyses.items():
        if channel in {"summary", "column_map"}:
            continue
        rows.append({
            "channel": channel,
            "row_count": a.get("row_count", np.nan),
            "verdict": a.get("verdict", ""),
            "main_fraction_1": a.get("positive_fraction_forward_minus_reverse", a.get("pass_0_80_fraction", a.get("state_space_valid_fraction", a.get("candidate_tag_fraction", np.nan)))),
            "main_fraction_2": a.get("negative_fraction_forward_minus_reverse", a.get("pass_0_70_fraction", np.nan)),
            "blocker": a.get("blocker", ""),
        })
    return pd.DataFrame(rows)


def classify_next_move(analyses: Dict[str, Dict[str, Any]], summary: Dict[str, Any]) -> Tuple[str, str, List[str]]:
    direction = analyses.get("directionality", {})
    null = analyses.get("null", {})
    lowk = analyses.get("lowk", {})
    entropy = analyses.get("entropy", {})
    sanity_errors = int(summary.get("sanity_error_count", 0) or 0)
    d_n = int(direction.get("numeric_gap_n", direction.get("row_count", 0)) or 0)
    n_n = int(null.get("numeric_score_n", null.get("row_count", 0)) or 0)
    e_frac = entropy.get("state_space_valid_fraction", np.nan)
    lowk_pairs = int(lowk.get("paired_forward_reverse_count", 0) or 0)
    pos = direction.get("positive_fraction_forward_minus_reverse", np.nan)
    neg = direction.get("negative_fraction_forward_minus_reverse", np.nan)
    null80 = null.get("pass_0_80_fraction", np.nan)

    recs: List[str] = []
    if sanity_errors:
        verdict = "E_IMPLEMENTATION_REVIEW_REQUIRED"
        rationale = "v1c reported sanity errors; fix implementation before scientific adjudication."
        recs.append("Do not continue scientific interpretation until sanity errors are resolved.")
        return verdict, rationale, recs

    if d_n > 0 and n_n > 0:
        verdict = "C_REVIEW_REQUIRED_REPAIRED_EVIDENCE_EXISTS"
        rationale = "v1c successfully recovered directionality and null witnesses, but the evidence must be interpreted by sign, source, family, and null survival rather than by figures alone."
        recs.append("Run a focused Stage-7C-v1e sign/source/family adjudicator, not another broad witness-recovery script.")
    else:
        verdict = "E_STILL_NOT_ADJUDICABLE_CHANNELS_MISSING"
        rationale = "Essential repaired evidence channels are still missing."
        recs.append("Reconstruct the missing channel tables before adjudication.")

    if lowk_pairs == 0:
        recs.append("Keep low-k arrow as NOT_TESTED; reconstruct reverse/backward low-k separately if low-k is needed for the final Stage-7C claim.")
    if pd.notna(e_frac) and e_frac >= 0.90:
        recs.append("Preserve entropy state-space completion as a strong internal diagnostic only; do not upgrade to thermodynamic entropy production.")
    if d_n > 0 and pd.notna(pos) and pd.notna(neg):
        if max(pos, neg) < 0.55:
            recs.append("Directionality appears mixed; v1e should split by source file, family, tier label, and candidate class before assigning a sign verdict.")
        elif neg > pos:
            recs.append("Reverse-sign dominance may indicate sign convention mismatch; v1e should explicitly test whether the intended arrow uses reverse-minus-forward.")
        else:
            recs.append("Forward-sign bias exists; v1e should test whether it survives null and family filters.")
    if n_n > 0 and pd.notna(null80):
        if null80 < 0.4:
            recs.append("Null survival is weak/mixed; v1e should report this as a limiter, not hide it behind total row counts.")
        else:
            recs.append("Null survival has enough signal to be crossed with directionality witnesses in v1e.")
    recs.append("Do not create Stage-7D yet. This remains Stage-7C repair/adjudication.")
    return verdict, rationale, recs


def write_executive_review(outdir: Path, root: Path, v1c_dir: Path, summary: Dict[str, Any], analyses: Dict[str, Dict[str, Any]], scorecard: pd.DataFrame, final_v: str, final_r: str, recs: List[str]) -> None:
    lines: List[str] = []
    lines.append("=" * 72)
    lines.append("STAGE-7C-v1d TEXTUAL EVIDENCE TRIAGE")
    lines.append("Project: Quantum-Emergent Gravity")
    lines.append(f"Generated: {now_iso()}")
    lines.append("=" * 72)
    lines.append("")
    lines.append("STATUS")
    lines.append("------")
    lines.append("This is not Stage-7D and not a new physics stage.")
    lines.append("It is a text-first interpretation pass over Stage-7C-v1c outputs.")
    lines.append("")
    lines.append("INPUTS")
    lines.append("------")
    lines.append(f"Project root: {root}")
    lines.append(f"v1c directory: {v1c_dir}")
    lines.append("")
    lines.append("v1c headline, if available:")
    for key in ["loaded_file_count", "candidate_rows", "tier1_or_admissible_rows", "directionality_witnesses", "null_witnesses", "lowk_paired_witnesses", "entropy_state_space_witnesses", "sanity_error_count", "final_stage7C_v1c_verdict", "final_rationale"]:
        if key in summary:
            lines.append(f"  - {key}: {summary.get(key)}")
    lines.append("")
    lines.append("CHANNEL SCORECARD")
    lines.append("-----------------")
    if scorecard.empty:
        lines.append("No scorecard rows generated.")
    else:
        for _, row in scorecard.iterrows():
            lines.append(f"- {row.get('channel')}: rows={row.get('row_count')}, verdict={row.get('verdict')}")
            if isinstance(row.get("blocker"), str) and row.get("blocker"):
                lines.append(f"  blocker: {row.get('blocker')}")
    lines.append("")
    lines.append("DETAILED INTERPRETATION")
    lines.append("-----------------------")
    d = analyses.get("directionality", {})
    lines.append("Directionality:")
    lines.append(f"  rows: {d.get('row_count', 0)}")
    lines.append(f"  verdict: {d.get('verdict', '')}")
    if d.get("numeric_gap_n") is not None:
        lines.append(f"  numeric gap n: {d.get('numeric_gap_n')}")
        lines.append(f"  forward-minus-reverse positive fraction: {d.get('positive_fraction_forward_minus_reverse')}")
        lines.append(f"  forward-minus-reverse negative fraction: {d.get('negative_fraction_forward_minus_reverse')}")
        lines.append(f"  gap stats: {d.get('gap_stats')}")
    lines.append("")
    n = analyses.get("null", {})
    lines.append("Null survival:")
    lines.append(f"  rows: {n.get('row_count', 0)}")
    lines.append(f"  verdict: {n.get('verdict', '')}")
    if n.get("numeric_score_n") is not None:
        lines.append(f"  numeric score n: {n.get('numeric_score_n')}")
        lines.append(f"  pass >= 0.80 fraction: {n.get('pass_0_80_fraction')}")
        lines.append(f"  pass >= 0.70 fraction: {n.get('pass_0_70_fraction')}")
        lines.append(f"  score stats: {n.get('score_stats')}")
    lines.append("")
    l = analyses.get("lowk", {})
    lines.append("Low-k operator arrow:")
    lines.append(f"  rows: {l.get('row_count', 0)}")
    lines.append(f"  paired forward/reverse count: {l.get('paired_forward_reverse_count', 0)}")
    lines.append(f"  verdict: {l.get('verdict', '')}")
    if l.get("blocker"):
        lines.append(f"  blocker: {l.get('blocker')}")
    lines.append("")
    e = analyses.get("entropy", {})
    lines.append("Entropy state-space:")
    lines.append(f"  rows: {e.get('row_count', 0)}")
    lines.append(f"  verdict: {e.get('verdict', '')}")
    lines.append(f"  valid fraction: {e.get('state_space_valid_fraction')}")
    lines.append(f"  slope stats: {e.get('slope_stats')}")
    lines.append("")
    r = analyses.get("reversibility", {})
    lines.append("Reversibility sandbox:")
    lines.append(f"  rows: {r.get('row_count', 0)}")
    lines.append(f"  verdict: {r.get('verdict', '')}")
    lines.append(f"  candidate tag fraction: {r.get('candidate_tag_fraction')}")
    lines.append("")
    lines.append("TEXTUAL TRIAGE VERDICT")
    lines.append("----------------------")
    lines.append(final_v)
    lines.append(final_r)
    lines.append("")
    lines.append("RECOMMENDED NEXT MOVE")
    lines.append("---------------------")
    for rec in recs:
        lines.append(f"- {rec}")
    lines.append("")
    lines.append("GUARDRAILS")
    lines.append("----------")
    lines.append("The following remain forbidden claims in this Stage-7C diagnostic:")
    for c in FORBIDDEN_CLAIMS:
        lines.append(f"- {c}")
    lines.append("")
    text = "\n".join(lines)
    (outdir / "stage7C_v1d_executive_review.txt").write_text(text, encoding="utf-8")
    (outdir / "stage7C_v1d_executive_review.md").write_text(text, encoding="utf-8")


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Stage-7C-v1d textual evidence triage over v1c outputs.")
    parser.add_argument("--root", default=None, help="Project root. Defaults to parent of metric_stage_7C_scripts.")
    parser.add_argument("--v1c-dir", default=None, help="Explicit v1c output directory.")
    args = parser.parse_args(argv)

    root = infer_project_root(args.root)
    v1c_dir = find_v1c_dir(root, args.v1c_dir)
    outdir = ensure_dir(root / OUT_SUBDIR)

    data = load_v1c_outputs(v1c_dir)
    summary = data.get("summary", {}) or {}

    analyses: Dict[str, Dict[str, Any]] = {}
    analyses["directionality"] = analyze_directionality(data.get("directionality", pd.DataFrame()), outdir)
    analyses["null"] = analyze_null(data.get("null", pd.DataFrame()), outdir)
    analyses["lowk"] = analyze_lowk(data.get("lowk", pd.DataFrame()), outdir)
    analyses["entropy"] = analyze_entropy(data.get("entropy", pd.DataFrame()), outdir)
    analyses["reversibility"] = analyze_reversibility(data.get("reversibility", pd.DataFrame()), outdir)
    analyses["column_map"] = summarize_column_map(data.get("column_map", pd.DataFrame()), outdir)

    # Simple table-level counts for sanity and provenance.
    table_counts = []
    for k, v in data.items():
        if isinstance(v, pd.DataFrame):
            table_counts.append({"table": k, "rows": int(len(v)), "columns": int(len(v.columns)), "column_names": ";".join(map(str, v.columns[:50]))})
    pd.DataFrame(table_counts).to_csv(outdir / "stage7C_v1d_loaded_v1c_table_inventory.csv", index=False)

    scorecard = build_scorecard(analyses)
    scorecard.to_csv(outdir / "stage7C_v1d_channel_scorecard.csv", index=False)

    final_v, final_r, recs = classify_next_move(analyses, summary)
    write_executive_review(outdir, root, v1c_dir, summary, analyses, scorecard, final_v, final_r, recs)

    recommendation = "\n".join(["STAGE-7C-v1d NEXT-MOVE RECOMMENDATION", "", final_v, final_r, ""] + [f"- {r}" for r in recs])
    (outdir / "stage7C_v1d_next_move_recommendation.txt").write_text(recommendation, encoding="utf-8")

    out_summary = {
        "project": PROJECT_NAME,
        "stage": STAGE,
        "script": SCRIPT_NAME,
        "generated_at": now_iso(),
        "project_root": str(root),
        "v1c_directory": str(v1c_dir),
        "output_directory": str(outdir),
        "v1c_headline_summary": summary,
        "analyses": analyses,
        "textual_triage_verdict": final_v,
        "textual_triage_rationale": final_r,
        "recommendations": recs,
        "outputs": {
            "executive_review_txt": "stage7C_v1d_executive_review.txt",
            "executive_review_md": "stage7C_v1d_executive_review.md",
            "channel_scorecard": "stage7C_v1d_channel_scorecard.csv",
            "loaded_table_inventory": "stage7C_v1d_loaded_v1c_table_inventory.csv",
            "next_move_recommendation": "stage7C_v1d_next_move_recommendation.txt",
        },
        "forbidden_claims_preserved": FORBIDDEN_CLAIMS,
    }
    write_json(outdir / "stage7C_v1d_summary.json", out_summary)

    print("=" * 60)
    print("Stage-7C-v1d: Textual Evidence Triage")
    print("=" * 60)
    print(f"Project root: {root}")
    print(f"v1c dir     : {v1c_dir}")
    print(f"Output dir  : {outdir}")
    print(f"Directionality rows: {analyses['directionality'].get('row_count')}")
    print(f"Null rows          : {analyses['null'].get('row_count')}")
    print(f"Low-k pairs        : {analyses['lowk'].get('paired_forward_reverse_count', 0)}")
    print(f"Entropy rows       : {analyses['entropy'].get('row_count')}")
    print(f"Triage verdict     : {final_v}")
    print(f"Rationale          : {final_r}")
    print("Primary output     : stage7C_v1d_executive_review.txt")
    print("=" * 60)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
