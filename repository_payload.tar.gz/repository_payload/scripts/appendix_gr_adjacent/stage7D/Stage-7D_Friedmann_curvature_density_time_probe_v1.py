#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Stage-7D Friedmann Curvature/Density Time Probe v1
Project: Quantum-Emergent Gravity (QEG)
Author: generated for Arturo Ortiz-Tapia
Date: 2026-06-01

Purpose
-------
This is a controlled sandbox that deliberately relaxes the previous
"no Friedmann derivation" guardrail for one task only:

    Search the QEG project tree for curvature-like (kappa / curvature / Omega_K)
    and density-like (rho / density / Omega_m-like) evidence, then substitute
    candidate values into Friedmann/Lambda-CDM time integrals to see how close
    they come to the accepted age of the Universe.

Scientific status
-----------------
This script does NOT claim that QEG has derived the Friedmann equation,
physical density, curvature, cosmic time, or Lambda-CDM parameters.
It performs comparison bookkeeping / stress testing:

    QEG internal scalar/operator evidence
        -> formal cosmology substitution scenarios
        -> age-of-Universe agreement/error table

No fitting is performed. External cosmology constants are locked as references,
not optimized. QEG values are substituted as-is, with explicit closure residuals.

Run examples
------------
Spyder:
    %runfile /home/dakini/Downloads/010-Quantum_Emergent_Gravity/metric_stage_7C_scripts/Stage-7D_Friedmann_curvature_density_time_probe_v1.py --wdir

Terminal:
    python3 Stage-7D_Friedmann_curvature_density_time_probe_v1.py
    python3 Stage-7D_Friedmann_curvature_density_time_probe_v1.py /home/dakini/Downloads/010-Quantum_Emergent_Gravity

Primary outputs
---------------
metric_stage_7D_outputs/friedmann_curvature_density_time_probe_v1/
    qeg_file_inventory.csv
    keyword_snippets.csv
    scalar_evidence_candidates.csv
    candidate_summary_by_role.csv
    friedmann_reference.csv
    friedmann_qeg_substitution_results.csv
    pairwise_density_curvature_friedmann_results.csv
    local_time_proxy_results.csv
    stage7D_summary.json
    audit_report.md
    figures/*.png
"""

from __future__ import annotations

import csv
import json
import math
import os
import re
import sys
import traceback
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

# Matplotlib is optional; the script still runs if figure generation fails.
try:
    import matplotlib.pyplot as plt
    HAVE_MPL = True
except Exception:
    HAVE_MPL = False

try:
    from scipy.integrate import quad
    HAVE_SCIPY = True
except Exception:
    HAVE_SCIPY = False

# ============================================================
# Configuration
# ============================================================

DEFAULT_PROJECT_ROOT = Path("/home/dakini/Downloads/010-Quantum_Emergent_Gravity")
STAGE_NAME = "Stage-7D"
RUN_NAME = "friedmann_curvature_density_time_probe_v1"

# External reference constants.
# These are NOT fitted and NOT taken as QEG evidence.
# They are locked comparators so the substitution exercise has a fixed scale.
REFERENCE_COSMOLOGY = {
    "label": "locked_external_reference_planck2018_like_pdg2024_bookkeeping",
    "H0_km_s_Mpc": 67.36,
    "Omega_m": 0.3153,
    "Omega_Lambda": 0.6847,
    "Omega_r": 9.16e-5,
    "Omega_k": 0.0,
    "age_reference_Gyr": 13.797,
    "source_note": (
        "Planck-2018/PDG-2024-like Lambda-CDM bookkeeping values. "
        "Used only as locked external reference constants; no fitting."
    ),
}

# Known QEG anchors discussed in ledgers/chats. The script will also try to
# rediscover these values in files. They are included as manual seed anchors
# because they are central to the question and should appear in the audit even
# if a textual ledger file is absent or named unexpectedly.
QEG_SEED_ANCHORS = [
    {
        "source_file": "manual_prior_ledger_anchor",
        "locator": "global_mu",
        "role": "density_like",
        "name": "global_mu",
        "value": 0.327995,
        "extraction_method": "manual_seed_anchor_expected_in_project_ledgers",
        "status": "comparison_bookkeeping_not_physical_identification",
    },
    {
        "source_file": "manual_prior_ledger_anchor",
        "locator": "early_central_separation",
        "role": "density_like",
        "name": "early_central_separation",
        "value": 0.317696468538139,
        "extraction_method": "manual_seed_anchor_expected_in_project_ledgers",
        "status": "comparison_bookkeeping_not_physical_identification",
    },
    {
        "source_file": "manual_prior_ledger_anchor",
        "locator": "stage6L_mode_width_near_Omega_m_review_only",
        "role": "density_like",
        "name": "stage6L_mode_width_or_width_like",
        "value": 0.2972,
        "extraction_method": "manual_seed_anchor_expected_in_project_ledgers",
        "status": "review_only_width_like_not_matter_density",
    },
]

# Keyword groups. Deliberately broad because the QEG folder contains outputs,
# ledgers, design briefs, and scripts with heterogeneous naming conventions.
ROLE_KEYWORDS = {
    "curvature_like": [
        "kappa", "κ", "curvature", "curved", "omega_k", "omegak", "omega k",
        "Omega_K", "OmegaK", "Omega_K", "okappa", "ricci", "scalar_curvature",
        "kretschmann", "sectional", "gaussian_curvature", "k_value", "curv",
    ],
    "density_like": [
        "rho", "ρ", "density", "omega_m", "omegam", "omega m", "Omega_m",
        "OmegaM", "matter", "modal_rho", "rho_like", "mass_ratio", "mass_fraction",
        "global_mu", "mu_global", "mu", "separation", "early_central", "central_early",
        "baryon", "baryonic", "cold_dark", "dark_matter", "omega_b", "omega_c",
    ],
    "time_like": [
        "time", "temporal", "entropy", "arrow", "irreversibility", "reversibility",
        "clock", "age", "friedmann", "hubble", "scale_factor", "evolution", "dt",
        "proper_time", "tau", "cosmic_time",
    ],
    "operator_like": [
        "operator", "kernel", "nonlocal", "green", "rank", "mode", "modal",
        "transport", "response", "constitutive", "recursive", "recursion",
    ],
}

ALL_KEYWORDS = sorted({kw for kws in ROLE_KEYWORDS.values() for kw in kws}, key=str.lower)
TEXT_EXTS = {".txt", ".md", ".py", ".json", ".csv", ".tsv", ".tex", ".log"}
SCAN_EXTS = TEXT_EXTS | {".pdf"}
MAX_TEXT_FILE_MB = 30
MAX_CSV_ROWS_FOR_FULL_READ = 350_000
MAX_SNIPPETS_PER_FILE = 80
MAX_RESULTS_PER_ROLE = 350
MAX_PAIRWISE_ROWS = 50_000

# ============================================================
# Data structures
# ============================================================

@dataclass
class ScalarCandidate:
    source_file: str
    locator: str
    role: str
    name: str
    value: float
    extraction_method: str
    status: str = "comparison_bookkeeping_not_physical_identification"
    stage_hint: str = ""
    family_hint: str = ""
    confidence: float = 0.0
    context: str = ""

@dataclass
class FriedmannResult:
    scenario: str
    qeg_source: str
    qeg_name: str
    qeg_role: str
    qeg_value_density: Optional[float]
    qeg_value_curvature: Optional[float]
    H0_km_s_Mpc: float
    Omega_r: float
    Omega_m: float
    Omega_Lambda: float
    Omega_k: float
    closure_sum: float
    closure_residual: float
    age_Gyr: Optional[float]
    age_reference_Gyr: float
    abs_error_Gyr: Optional[float]
    rel_error_percent: Optional[float]
    E0_squared: float
    validity_flag: str
    note: str

# ============================================================
# Helpers
# ============================================================

def normalize_name(x: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(x).lower()).strip("_")


def contains_any_keyword(text: str, keywords: Sequence[str]) -> bool:
    low = text.lower()
    return any(str(k).lower() in low for k in keywords)


def infer_role(name: str, context: str = "") -> str:
    blob = f"{name} {context}".lower()
    scores = {}
    for role, kws in ROLE_KEYWORDS.items():
        scores[role] = sum(1 for kw in kws if str(kw).lower() in blob)
    best_role, best_score = max(scores.items(), key=lambda kv: kv[1])
    if best_score <= 0:
        return "unknown"
    # For Friedmann substitution, prefer explicit curvature/density roles.
    if scores.get("curvature_like", 0) > 0 and scores.get("density_like", 0) == 0:
        return "curvature_like"
    if scores.get("density_like", 0) > 0 and scores.get("curvature_like", 0) == 0:
        return "density_like"
    return best_role


def infer_stage(path: Path) -> str:
    text = str(path)
    m = re.search(r"stage[-_ ]?([0-9]+[A-Za-z0-9]*)", text, re.IGNORECASE)
    if m:
        return f"Stage-{m.group(1)}"
    m = re.search(r"metric_stage_([0-9]+[A-Za-z0-9]*)", text, re.IGNORECASE)
    if m:
        return f"Stage-{m.group(1)}"
    return ""


def infer_family(text: str) -> str:
    low = text.lower()
    hits = []
    for fam in ["BARI", "NUFIT", "VALENCIA", "PDG"]:
        if fam.lower() in low:
            hits.append(fam)
    return ";".join(hits)


def score_candidate(c: ScalarCandidate) -> float:
    score = 0.0
    n = f"{c.name} {c.locator} {c.source_file} {c.context}".lower()
    if c.role in {"density_like", "curvature_like"}:
        score += 2.0
    if any(s in n for s in ["global_mu", "early_central", "omega_m", "omega_k", "rho", "kappa", "curvature", "density"]):
        score += 2.0
    if any(s in n for s in ["summary", "ledger", "guardrail", "cosmology", "friedmann", "stage6y", "stage7"]):
        score += 1.0
    if c.extraction_method.startswith("csv") or c.extraction_method.startswith("json"):
        score += 0.7
    if c.extraction_method.startswith("manual_seed"):
        score += 1.2
    v = c.value
    if c.role == "density_like" and 0.0 <= v <= 1.5:
        score += 1.0
    if c.role == "curvature_like" and -1.5 <= v <= 1.5:
        score += 1.0
    if math.isfinite(v):
        score += 0.3
    return score


def safe_float(x: Any) -> Optional[float]:
    try:
        if x is None:
            return None
        if isinstance(x, str):
            xs = x.strip()
            if not xs:
                return None
            xs = xs.replace(",", "")
            # avoid parsing dates as numbers
            if re.fullmatch(r"\d{4}-\d{1,2}-\d{1,2}", xs):
                return None
            x = xs
        v = float(x)
        if not math.isfinite(v):
            return None
        return v
    except Exception:
        return None


def relative_path(path: Path, root: Path) -> str:
    try:
        return str(path.relative_to(root))
    except Exception:
        return str(path)


def read_text_file(path: Path, max_mb: float = MAX_TEXT_FILE_MB) -> Optional[str]:
    try:
        if path.stat().st_size > max_mb * 1024 * 1024:
            return None
        return path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        try:
            return path.read_text(encoding="latin-1", errors="ignore")
        except Exception:
            return None


def try_extract_pdf_text(path: Path, max_pages: int = 12) -> str:
    """Optional low-cost PDF text extraction if PyPDF2 is present."""
    try:
        import PyPDF2  # type: ignore
        texts = []
        with path.open("rb") as f:
            reader = PyPDF2.PdfReader(f)
            for page in reader.pages[:max_pages]:
                try:
                    texts.append(page.extract_text() or "")
                except Exception:
                    continue
        return "\n".join(texts)
    except Exception:
        return ""


def numeric_regex_candidates(text: str) -> Iterable[Tuple[str, float, str]]:
    """Find keyword-adjacent numerical assignments in free text."""
    patterns = [
        r"(?P<name>[A-Za-z_][A-Za-z0-9_\- ]{0,80}?(?:mu|rho|density|kappa|curvature|omega[_ ]?[mkbclambdaΛK]|separation|age|hubble)[A-Za-z0-9_\- ]{0,80})\s*(?:=|:|≈|~|\bis\b)\s*(?P<value>[-+]?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?)",
        r"(?P<name>(?:mu|rho|density|kappa|curvature|Omega[_ ]?[mkbclambdaΛK]|omega[_ ]?[mkbclambdaΛK]|global_mu|early_central_separation)[A-Za-z0-9_\- ]{0,80})\s+(?P<value>[-+]?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?)",
    ]
    for pat in patterns:
        for m in re.finditer(pat, text, flags=re.IGNORECASE):
            name = re.sub(r"\s+", " ", m.group("name")).strip(" -:_")
            value = safe_float(m.group("value"))
            if value is not None:
                context_start = max(0, m.start() - 100)
                context_end = min(len(text), m.end() + 100)
                yield name, value, text[context_start:context_end].replace("\n", " ")


def flatten_json(obj: Any, prefix: str = "") -> Iterable[Tuple[str, Any]]:
    if isinstance(obj, dict):
        for k, v in obj.items():
            key = f"{prefix}.{k}" if prefix else str(k)
            yield from flatten_json(v, key)
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            key = f"{prefix}[{i}]"
            yield from flatten_json(v, key)
    else:
        yield prefix, obj

# ============================================================
# Friedmann calculations
# ============================================================

def H0_to_s_inv(H0_km_s_Mpc: float) -> float:
    km_per_Mpc = 3.0856775814913673e19
    return H0_km_s_Mpc / km_per_Mpc


def seconds_to_Gyr(seconds: float) -> float:
    return seconds / (365.25 * 24 * 3600 * 1.0e9)


def E2_of_a(a: float, Om_r: float, Om_m: float, Om_L: float, Om_k: float) -> float:
    return Om_r / a**4 + Om_m / a**3 + Om_k / a**2 + Om_L


def age_of_universe_Gyr(
    H0_km_s_Mpc: float,
    Omega_r: float,
    Omega_m: float,
    Omega_Lambda: float,
    Omega_k: float,
    a_min: float = 1e-8,
) -> Tuple[Optional[float], str]:
    """Compute t0 = integral_0^1 da/(a H(a)) for fixed components."""
    if H0_km_s_Mpc <= 0:
        return None, "INVALID_H0"
    # present E(1)^2 can be non-unity in no-adjust substitution scenarios;
    # that is allowed but audited via closure residual.
    test_points = np.geomspace(a_min, 1.0, 1200)
    e2 = np.array([E2_of_a(float(a), Omega_r, Omega_m, Omega_Lambda, Omega_k) for a in test_points])
    if np.any(~np.isfinite(e2)) or np.any(e2 <= 0):
        return None, "INVALID_E2_NONPOSITIVE_ON_GRID"
    H0 = H0_to_s_inv(H0_km_s_Mpc)

    def integrand(a: float) -> float:
        e2a = E2_of_a(a, Omega_r, Omega_m, Omega_Lambda, Omega_k)
        if e2a <= 0 or not math.isfinite(e2a):
            return float("nan")
        return 1.0 / (a * math.sqrt(e2a))

    try:
        if HAVE_SCIPY:
            val, err = quad(integrand, a_min, 1.0, epsabs=1e-10, epsrel=1e-8, limit=300)
        else:
            aa = np.geomspace(a_min, 1.0, 5000)
            yy = np.array([integrand(float(a)) for a in aa])
            val = float(np.trapz(yy, aa))
        return seconds_to_Gyr(val / H0), "OK"
    except Exception as exc:
        return None, f"INTEGRATION_FAILED:{exc}"


def make_friedmann_result(
    scenario: str,
    qeg_source: str,
    qeg_name: str,
    qeg_role: str,
    density_value: Optional[float],
    curvature_value: Optional[float],
    Om_m: float,
    Om_k: float,
    Om_L: float,
    Om_r: float,
    note: str,
    H0: Optional[float] = None,
) -> FriedmannResult:
    if H0 is None:
        H0 = REFERENCE_COSMOLOGY["H0_km_s_Mpc"]
    closure_sum = Om_r + Om_m + Om_k + Om_L
    closure_residual = closure_sum - 1.0
    E0_squared = E2_of_a(1.0, Om_r, Om_m, Om_L, Om_k)
    age, flag = age_of_universe_Gyr(H0, Om_r, Om_m, Om_L, Om_k)
    ref_age = REFERENCE_COSMOLOGY["age_reference_Gyr"]
    abs_err = None if age is None else abs(age - ref_age)
    rel_err = None if age is None else 100.0 * abs(age - ref_age) / ref_age
    return FriedmannResult(
        scenario=scenario,
        qeg_source=qeg_source,
        qeg_name=qeg_name,
        qeg_role=qeg_role,
        qeg_value_density=density_value,
        qeg_value_curvature=curvature_value,
        H0_km_s_Mpc=H0,
        Omega_r=Om_r,
        Omega_m=Om_m,
        Omega_Lambda=Om_L,
        Omega_k=Om_k,
        closure_sum=closure_sum,
        closure_residual=closure_residual,
        age_Gyr=age,
        age_reference_Gyr=ref_age,
        abs_error_Gyr=abs_err,
        rel_error_percent=rel_err,
        E0_squared=E0_squared,
        validity_flag=flag,
        note=note,
    )

# ============================================================
# Project scanning
# ============================================================

def build_file_inventory(root: Path) -> pd.DataFrame:
    rows = []
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        try:
            stat = path.stat()
            rel = relative_path(path, root)
            rows.append({
                "relpath": rel,
                "suffix": path.suffix.lower(),
                "size_bytes": stat.st_size,
                "size_mb": stat.st_size / (1024 * 1024),
                "stage_hint": infer_stage(path),
                "family_hint": infer_family(rel),
                "keyword_in_name": contains_any_keyword(rel, ALL_KEYWORDS),
            })
        except Exception:
            continue
    return pd.DataFrame(rows).sort_values(["keyword_in_name", "relpath"], ascending=[False, True])


def extract_text_snippets(root: Path, inventory: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for _, r in inventory.iterrows():
        suffix = str(r["suffix"]).lower()
        if suffix not in SCAN_EXTS:
            continue
        path = root / str(r["relpath"])
        text = ""
        if suffix == ".pdf":
            # Avoid expensive full-PDF extraction. A few first pages are enough
            # for cosmology constants/abstract-like evidence if PyPDF2 exists.
            text = try_extract_pdf_text(path, max_pages=16)
        else:
            text = read_text_file(path) or ""
        if not text:
            continue
        lines = text.splitlines()
        snippet_count = 0
        for i, line in enumerate(lines, start=1):
            if snippet_count >= MAX_SNIPPETS_PER_FILE:
                break
            low = line.lower()
            hit_roles = []
            hit_keywords = []
            for role, kws in ROLE_KEYWORDS.items():
                local_hits = [kw for kw in kws if str(kw).lower() in low]
                if local_hits:
                    hit_roles.append(role)
                    hit_keywords.extend(local_hits[:8])
            if not hit_roles:
                continue
            start = max(1, i - 1)
            end = min(len(lines), i + 1)
            context = " ".join(s.strip() for s in lines[start-1:end])
            rows.append({
                "source_file": str(r["relpath"]),
                "line": i,
                "roles": ";".join(sorted(set(hit_roles))),
                "keywords": ";".join(sorted(set(map(str, hit_keywords)), key=str.lower)),
                "stage_hint": r.get("stage_hint", ""),
                "family_hint": r.get("family_hint", ""),
                "snippet": context[:1500],
            })
            snippet_count += 1
    return pd.DataFrame(rows)


def extract_json_candidates(root: Path, relpath: str) -> List[ScalarCandidate]:
    path = root / relpath
    out: List[ScalarCandidate] = []
    try:
        text = read_text_file(path, max_mb=20)
        if not text:
            return out
        obj = json.loads(text)
        for key, val in flatten_json(obj):
            v = safe_float(val)
            if v is None:
                continue
            role = infer_role(key, relpath)
            if role == "unknown":
                continue
            if not candidate_value_allowed(role, v):
                continue
            c = ScalarCandidate(
                source_file=relpath,
                locator=key,
                role=role,
                name=key.split(".")[-1],
                value=v,
                extraction_method="json_numeric_key_scan",
                stage_hint=infer_stage(path),
                family_hint=infer_family(f"{relpath} {key}"),
                context=key,
            )
            c.confidence = score_candidate(c)
            out.append(c)
    except Exception:
        pass
    return out


def candidate_value_allowed(role: str, v: float) -> bool:
    if not math.isfinite(v):
        return False
    # Keep dimensionless-like values for Friedmann substitution.
    # Raw dimensional constants can still appear in snippets but not as QEG substitutes.
    if role == "density_like":
        return -0.05 <= v <= 2.0
    if role == "curvature_like":
        return -2.0 <= v <= 2.0
    if role == "time_like":
        return 0.0 <= abs(v) <= 1000.0
    if role == "operator_like":
        return -10.0 <= v <= 10.0
    return -2.0 <= v <= 2.0


def extract_text_numeric_candidates(root: Path, relpath: str) -> List[ScalarCandidate]:
    path = root / relpath
    suffix = path.suffix.lower()
    out: List[ScalarCandidate] = []
    if suffix not in TEXT_EXTS:
        return out
    text = read_text_file(path)
    if not text:
        return out
    # Only scan keyword-relevant text to reduce false positives.
    if not contains_any_keyword(text[:500000], ALL_KEYWORDS) and not contains_any_keyword(relpath, ALL_KEYWORDS):
        return out
    for name, value, context in numeric_regex_candidates(text[:2_000_000]):
        role = infer_role(name, context + " " + relpath)
        if role == "unknown":
            continue
        if not candidate_value_allowed(role, value):
            continue
        c = ScalarCandidate(
            source_file=relpath,
            locator=name,
            role=role,
            name=normalize_name(name)[:120],
            value=value,
            extraction_method="text_keyword_adjacent_numeric_scan",
            stage_hint=infer_stage(path),
            family_hint=infer_family(f"{relpath} {context}"),
            context=context[:800],
        )
        c.confidence = score_candidate(c)
        out.append(c)
    return out


def summarize_numeric_column(series: pd.Series) -> Dict[str, float]:
    x = pd.to_numeric(series, errors="coerce").replace([np.inf, -np.inf], np.nan).dropna()
    if len(x) == 0:
        return {}
    return {
        "count": float(len(x)),
        "mean": float(x.mean()),
        "median": float(x.median()),
        "std": float(x.std(ddof=0)) if len(x) > 1 else 0.0,
        "min": float(x.min()),
        "max": float(x.max()),
        "q25": float(x.quantile(0.25)),
        "q75": float(x.quantile(0.75)),
    }


def read_csv_flex(path: Path) -> Optional[pd.DataFrame]:
    try:
        # For very large files, sample rather than exhaust memory. Most QEG scalar
        # evidence appears in summaries/ledgers, not enormous raw arrays.
        nrows = None
        try:
            if path.stat().st_size > 100 * 1024 * 1024:
                nrows = MAX_CSV_ROWS_FOR_FULL_READ
        except Exception:
            pass
        if path.suffix.lower() == ".tsv":
            return pd.read_csv(path, sep="\t", engine="python", nrows=nrows)
        return pd.read_csv(path, engine="python", nrows=nrows)
    except Exception:
        try:
            return pd.read_csv(path, engine="python", sep=None, nrows=MAX_CSV_ROWS_FOR_FULL_READ)
        except Exception:
            return None


def extract_csv_candidates(root: Path, relpath: str) -> Tuple[List[ScalarCandidate], List[Dict[str, Any]]]:
    path = root / relpath
    out: List[ScalarCandidate] = []
    summaries: List[Dict[str, Any]] = []
    df = read_csv_flex(path)
    if df is None or df.empty:
        return out, summaries

    rel_blob = relpath.lower()
    for col in df.columns:
        col_name = str(col)
        role = infer_role(col_name, relpath)
        # If a generic value column lives next to label/name columns, infer role row-wise below.
        is_numeric = pd.api.types.is_numeric_dtype(df[col]) or pd.to_numeric(df[col], errors="coerce").notna().any()
        if not is_numeric:
            continue
        stats = summarize_numeric_column(df[col])
        if stats:
            summaries.append({
                "source_file": relpath,
                "column": col_name,
                "role": role,
                "stage_hint": infer_stage(path),
                "family_hint": infer_family(f"{relpath} {col_name}"),
                **stats,
            })
        if role in {"density_like", "curvature_like"}:
            # Keep summary statistics as scalar candidates.
            for stat_name in ["mean", "median", "min", "max"]:
                v = stats.get(stat_name)
                if v is None or not candidate_value_allowed(role, float(v)):
                    continue
                c = ScalarCandidate(
                    source_file=relpath,
                    locator=f"column:{col_name}:{stat_name}",
                    role=role,
                    name=f"{col_name}_{stat_name}",
                    value=float(v),
                    extraction_method="csv_numeric_column_summary",
                    stage_hint=infer_stage(path),
                    family_hint=infer_family(f"{relpath} {col_name}"),
                    context=f"summary statistic {stat_name} for numeric column {col_name}",
                )
                c.confidence = score_candidate(c)
                out.append(c)
            # If the table is small, preserve actual scalar rows too.
            if len(df) <= 1500:
                vals = pd.to_numeric(df[col], errors="coerce")
                for idx, v in vals.dropna().items():
                    vf = float(v)
                    if not candidate_value_allowed(role, vf):
                        continue
                    # Avoid flooding from long distributions.
                    if len(out) > 5000:
                        break
                    row_context = ""
                    try:
                        row = df.loc[idx]
                        # include string/object columns with useful labels
                        bits = []
                        for cc in df.columns[:18]:
                            if cc == col:
                                continue
                            val = row.get(cc)
                            if isinstance(val, str) and len(val) < 160:
                                if contains_any_keyword(val, ALL_KEYWORDS) or cc.lower() in {"name", "metric", "label", "source", "family", "statistic", "quantity", "parameter"}:
                                    bits.append(f"{cc}={val}")
                        row_context = "; ".join(bits)
                    except Exception:
                        pass
                    c = ScalarCandidate(
                        source_file=relpath,
                        locator=f"row:{idx};column:{col_name}",
                        role=role,
                        name=col_name,
                        value=vf,
                        extraction_method="csv_numeric_keyword_column_row_value",
                        stage_hint=infer_stage(path),
                        family_hint=infer_family(f"{relpath} {row_context}"),
                        context=row_context[:800],
                    )
                    c.confidence = score_candidate(c)
                    out.append(c)

    # Row-wise extraction from generic value columns with label columns.
    possible_value_cols = [c for c in df.columns if normalize_name(c) in {"value", "metric_value", "score", "estimate", "mean", "median", "mu", "parameter_value"}]
    label_cols = [c for c in df.columns if not pd.api.types.is_numeric_dtype(df[c])]
    for vcol in possible_value_cols[:8]:
        vals = pd.to_numeric(df[vcol], errors="coerce")
        for idx, vf in vals.dropna().items():
            try:
                row = df.loc[idx]
            except Exception:
                continue
            label_blob_parts = [relpath, str(vcol)]
            for lc in label_cols[:24]:
                val = row.get(lc)
                if isinstance(val, str):
                    label_blob_parts.append(f"{lc}={val}")
            label_blob = " ".join(label_blob_parts)
            role = infer_role(str(vcol), label_blob)
            if role not in {"density_like", "curvature_like"}:
                continue
            v = float(vf)
            if not candidate_value_allowed(role, v):
                continue
            c = ScalarCandidate(
                source_file=relpath,
                locator=f"row:{idx};value_column:{vcol}",
                role=role,
                name=str(vcol),
                value=v,
                extraction_method="csv_rowwise_label_plus_value_scan",
                stage_hint=infer_stage(path),
                family_hint=infer_family(label_blob),
                context=label_blob[:1000],
            )
            c.confidence = score_candidate(c)
            out.append(c)

    return out, summaries


def collect_scalar_candidates(root: Path, inventory: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    candidates: List[ScalarCandidate] = []
    column_summaries: List[Dict[str, Any]] = []

    # Seed anchors first.
    for row in QEG_SEED_ANCHORS:
        c = ScalarCandidate(**row)
        c.stage_hint = "manual_prior"
        c.family_hint = ""
        c.confidence = score_candidate(c)
        candidates.append(c)

    for _, r in inventory.iterrows():
        rel = str(r["relpath"])
        suffix = str(r["suffix"]).lower()
        path = root / rel
        try:
            if suffix in {".csv", ".tsv"}:
                cs, sums = extract_csv_candidates(root, rel)
                candidates.extend(cs)
                column_summaries.extend(sums)
            elif suffix == ".json":
                candidates.extend(extract_json_candidates(root, rel))
                candidates.extend(extract_text_numeric_candidates(root, rel))
            elif suffix in TEXT_EXTS:
                candidates.extend(extract_text_numeric_candidates(root, rel))
        except KeyboardInterrupt:
            raise
        except Exception as exc:
            column_summaries.append({
                "source_file": rel,
                "column": "__ERROR__",
                "role": "error",
                "error": str(exc),
            })

    # De-duplicate near-identical candidates.
    rows = []
    seen = set()
    for c in candidates:
        c.confidence = score_candidate(c)
        key = (c.source_file, c.locator, c.role, c.name, round(float(c.value), 15))
        if key in seen:
            continue
        seen.add(key)
        rows.append(asdict(c))
    cand_df = pd.DataFrame(rows)
    if not cand_df.empty:
        cand_df = cand_df.sort_values(["confidence", "role", "source_file"], ascending=[False, True, True])
    sum_df = pd.DataFrame(column_summaries)
    return cand_df, sum_df

# ============================================================
# Substitution scenarios
# ============================================================

def select_top_candidates(cand_df: pd.DataFrame, role: str, max_n: int = MAX_RESULTS_PER_ROLE) -> pd.DataFrame:
    if cand_df.empty:
        return cand_df
    d = cand_df[cand_df["role"] == role].copy()
    if d.empty:
        return d
    if role == "density_like":
        d = d[(d["value"] >= 0.0) & (d["value"] <= 1.5)]
    elif role == "curvature_like":
        d = d[(d["value"] >= -1.5) & (d["value"] <= 1.5)]
    d = d.sort_values(["confidence", "source_file", "name"], ascending=[False, True, True])
    # Preserve diversity: avoid thousands of row values from one file/column.
    d["rounded_value"] = d["value"].round(12)
    d = d.drop_duplicates(subset=["source_file", "name", "rounded_value", "role"], keep="first")
    return d.head(max_n).drop(columns=["rounded_value"], errors="ignore")


def run_friedmann_substitutions(cand_df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    ref = REFERENCE_COSMOLOGY
    Omr = float(ref["Omega_r"])
    Omm_ref = float(ref["Omega_m"])
    OmL_ref = float(ref["Omega_Lambda"])
    Omk_ref = float(ref["Omega_k"])
    H0 = float(ref["H0_km_s_Mpc"])

    results: List[FriedmannResult] = []

    # External reference baseline.
    results.append(make_friedmann_result(
        scenario="external_reference_only_no_QEG_substitution",
        qeg_source="external_reference",
        qeg_name="Planck2018_like_reference",
        qeg_role="external_reference",
        density_value=None,
        curvature_value=None,
        Om_m=Omm_ref,
        Om_k=Omk_ref,
        Om_L=OmL_ref,
        Om_r=Omr,
        H0=H0,
        note="Baseline age integral with locked external cosmology only.",
    ))

    density = select_top_candidates(cand_df, "density_like")
    curvature = select_top_candidates(cand_df, "curvature_like")

    for _, row in density.iterrows():
        v = float(row["value"])
        qsrc = str(row["source_file"])
        qname = str(row["name"])
        role = str(row["role"])
        # Scenario 1: substitute QEG as Omega_m, hold all other components fixed.
        results.append(make_friedmann_result(
            scenario="QEG_density_as_Omega_m__H0_OmegaLambda_OmegaK_fixed_no_adjustment",
            qeg_source=qsrc,
            qeg_name=qname,
            qeg_role=role,
            density_value=v,
            curvature_value=None,
            Om_m=v,
            Om_k=Omk_ref,
            Om_L=OmL_ref,
            Om_r=Omr,
            H0=H0,
            note="Only Omega_m replaced by QEG density-like scalar; no closure adjustment.",
        ))
        # Scenario 2: substitute QEG as Omega_m, derive flat closure Omega_Lambda.
        # This is not fitted, but it does adjust one component by closure, so it is separate.
        OmL_closure = 1.0 - Omr - v
        results.append(make_friedmann_result(
            scenario="QEG_density_as_Omega_m__flat_closure_OmegaLambda_derived_not_fitted",
            qeg_source=qsrc,
            qeg_name=qname,
            qeg_role=role,
            density_value=v,
            curvature_value=None,
            Om_m=v,
            Om_k=0.0,
            Om_L=OmL_closure,
            Om_r=Omr,
            H0=H0,
            note="Omega_m replaced by QEG density-like scalar; Omega_Lambda derived only by flat closure, not fitted.",
        ))
        # Scenario 3: substitute QEG as Omega_Lambda for diagnostic contrast.
        results.append(make_friedmann_result(
            scenario="QEG_density_like_as_OmegaLambda__OmegaM_OmegaK_fixed_no_adjustment",
            qeg_source=qsrc,
            qeg_name=qname,
            qeg_role=role,
            density_value=v,
            curvature_value=None,
            Om_m=Omm_ref,
            Om_k=Omk_ref,
            Om_L=v,
            Om_r=Omr,
            H0=H0,
            note="Density-like scalar interpreted as dark-energy-like density only as adversarial contrast.",
        ))

    for _, row in curvature.iterrows():
        v = float(row["value"])
        qsrc = str(row["source_file"])
        qname = str(row["name"])
        role = str(row["role"])
        # Scenario 4: substitute curvature candidate as Omega_k.
        results.append(make_friedmann_result(
            scenario="QEG_curvature_as_Omega_k__H0_OmegaM_OmegaLambda_fixed_no_adjustment",
            qeg_source=qsrc,
            qeg_name=qname,
            qeg_role=role,
            density_value=None,
            curvature_value=v,
            Om_m=Omm_ref,
            Om_k=v,
            Om_L=OmL_ref,
            Om_r=Omr,
            H0=H0,
            note="Curvature-like QEG scalar interpreted as Omega_k; discrete k/a0 not inferred.",
        ))
        # Scenario 5: closure variant with Omega_Lambda derived from QEG Omega_k.
        OmL_closure = 1.0 - Omr - Omm_ref - v
        results.append(make_friedmann_result(
            scenario="QEG_curvature_as_Omega_k__OmegaLambda_closure_derived_not_fitted",
            qeg_source=qsrc,
            qeg_name=qname,
            qeg_role=role,
            density_value=None,
            curvature_value=v,
            Om_m=Omm_ref,
            Om_k=v,
            Om_L=OmL_closure,
            Om_r=Omr,
            H0=H0,
            note="Curvature-like QEG scalar interpreted as Omega_k; Omega_Lambda derived by closure only.",
        ))

    results_df = pd.DataFrame([asdict(x) for x in results])
    if not results_df.empty:
        results_df = results_df.sort_values(["validity_flag", "abs_error_Gyr", "scenario"], na_position="last")

    # Pairwise density-curvature tests, prioritizing same-stage/same-file families.
    pair_results: List[FriedmannResult] = []
    if not density.empty and not curvature.empty:
        d_small = density.head(120).copy()
        k_small = curvature.head(120).copy()
        count = 0
        for _, dr in d_small.iterrows():
            for _, kr in k_small.iterrows():
                if count >= MAX_PAIRWISE_ROWS:
                    break
                dv = float(dr["value"])
                kv = float(kr["value"])
                # Prefer reasonable dimensionless substitutions.
                if not (0 <= dv <= 1.5 and -1.5 <= kv <= 1.5):
                    continue
                same_file = dr["source_file"] == kr["source_file"]
                same_stage = str(dr.get("stage_hint", "")) and dr.get("stage_hint", "") == kr.get("stage_hint", "")
                pair_note = "Density and curvature candidates paired. "
                pair_note += "same_file=" + str(bool(same_file)) + "; same_stage=" + str(bool(same_stage))
                pair_results.append(make_friedmann_result(
                    scenario="QEG_pair_density_as_Omega_m_curvature_as_Omega_k__OmegaLambda_fixed_no_adjustment",
                    qeg_source=f"density:{dr['source_file']} | curvature:{kr['source_file']}",
                    qeg_name=f"density:{dr['name']} | curvature:{kr['name']}",
                    qeg_role="density_like+curvature_like",
                    density_value=dv,
                    curvature_value=kv,
                    Om_m=dv,
                    Om_k=kv,
                    Om_L=OmL_ref,
                    Om_r=Omr,
                    H0=H0,
                    note=pair_note + "; Omega_Lambda fixed.",
                ))
                OmL_closure = 1.0 - Omr - dv - kv
                pair_results.append(make_friedmann_result(
                    scenario="QEG_pair_density_as_Omega_m_curvature_as_Omega_k__OmegaLambda_closure_derived_not_fitted",
                    qeg_source=f"density:{dr['source_file']} | curvature:{kr['source_file']}",
                    qeg_name=f"density:{dr['name']} | curvature:{kr['name']}",
                    qeg_role="density_like+curvature_like",
                    density_value=dv,
                    curvature_value=kv,
                    Om_m=dv,
                    Om_k=kv,
                    Om_L=OmL_closure,
                    Om_r=Omr,
                    H0=H0,
                    note=pair_note + "; Omega_Lambda derived by closure only.",
                ))
                count += 2
    pair_df = pd.DataFrame([asdict(x) for x in pair_results])
    if not pair_df.empty:
        # Boost same-file/same-stage only through sorting note text is not ideal; keep numerical first.
        pair_df = pair_df.sort_values(["validity_flag", "abs_error_Gyr"], na_position="last")

    local_df = run_local_time_proxy(cand_df)
    return results_df, pair_df, local_df


def run_local_time_proxy(cand_df: pd.DataFrame) -> pd.DataFrame:
    """Formal local proper-time proxy: tau/dt = sqrt(1 - compactness).

    This does NOT use dimensional Schwarzschild mass/radius. It only asks:
    if a dimensionless QEG curvature/density scalar were read as a compactness-like
    number chi = 2GM/(c^2 r), what proper-time factor would result?
    """
    if cand_df.empty:
        return pd.DataFrame()
    rows = []
    d = cand_df[cand_df["role"].isin(["density_like", "curvature_like"])].copy()
    d = d[(d["value"] >= 0.0) & (d["value"] < 1.0)]
    d = d.sort_values(["confidence", "source_file"], ascending=[False, True]).head(500)
    for _, r in d.iterrows():
        chi = float(r["value"])
        tau_over_t = math.sqrt(max(0.0, 1.0 - chi))
        rows.append({
            "source_file": r["source_file"],
            "name": r["name"],
            "role": r["role"],
            "qeg_value_as_compactness_proxy": chi,
            "tau_over_coordinate_time_proxy": tau_over_t,
            "time_dilation_fraction_proxy": 1.0 - tau_over_t,
            "confidence": r.get("confidence", 0.0),
            "status": "formal_dimensionless_compactness_proxy_not_physical_schwarzschild_substitution",
        })
    return pd.DataFrame(rows).sort_values(["time_dilation_fraction_proxy", "confidence"], ascending=[False, False]) if rows else pd.DataFrame()

# ============================================================
# Reports and figures
# ============================================================

def write_markdown_report(
    outdir: Path,
    root: Path,
    inventory: pd.DataFrame,
    snippets: pd.DataFrame,
    cand_df: pd.DataFrame,
    colsum_df: pd.DataFrame,
    fried_df: pd.DataFrame,
    pair_df: pd.DataFrame,
    local_df: pd.DataFrame,
) -> None:
    report = []
    report.append(f"# {STAGE_NAME} Friedmann Curvature/Density Time Probe v1")
    report.append("")
    report.append("## Scientific status")
    report.append("")
    report.append("This is a controlled sandbox comparison. It deliberately relaxes the prior no-Friedmann guardrail only to test what happens when QEG curvature-like and density-like quantities are substituted into Friedmann-style age integrals.")
    report.append("")
    report.append("No physical identification is claimed. No cosmological constant is fitted. External constants are locked comparators.")
    report.append("")
    report.append("## Project root")
    report.append("")
    report.append(f"`{root}`")
    report.append("")
    report.append("## External reference constants")
    report.append("")
    for k, v in REFERENCE_COSMOLOGY.items():
        report.append(f"- `{k}`: `{v}`")
    report.append("")
    report.append("## Scan totals")
    report.append("")
    report.append(f"- Files inventoried: {len(inventory)}")
    report.append(f"- Keyword snippets: {len(snippets)}")
    report.append(f"- Scalar candidates: {len(cand_df)}")
    report.append(f"- Numeric column summaries: {len(colsum_df)}")
    report.append(f"- Friedmann single substitutions: {len(fried_df)}")
    report.append(f"- Friedmann density-curvature pair substitutions: {len(pair_df)}")
    report.append(f"- Local proper-time proxy rows: {len(local_df)}")
    report.append("")

    report.append("## Main interpretation rule")
    report.append("")
    report.append("A good age match is not automatically evidence that QEG has derived cosmic time. It is a candidate for further audit only if the source scalar is internally stable, lineage-preserved, non-cherry-picked, and survives null/ablation checks.")
    report.append("")

    if not cand_df.empty:
        report.append("## Top scalar candidates")
        report.append("")
        cols = ["role", "value", "name", "source_file", "confidence", "extraction_method"]
        top = cand_df[cols].head(25).copy()
        report.append(top.to_markdown(index=False))
        report.append("")

    if not fried_df.empty:
        ok = fried_df[fried_df["validity_flag"] == "OK"].copy()
        if not ok.empty:
            report.append("## Top Friedmann single-substitution age matches")
            report.append("")
            cols = [
                "scenario", "qeg_name", "qeg_value_density", "qeg_value_curvature",
                "Omega_m", "Omega_k", "Omega_Lambda", "closure_residual",
                "age_Gyr", "abs_error_Gyr", "rel_error_percent", "qeg_source",
            ]
            report.append(ok.sort_values("abs_error_Gyr")[cols].head(20).to_markdown(index=False))
            report.append("")

    if not pair_df.empty:
        okp = pair_df[pair_df["validity_flag"] == "OK"].copy()
        if not okp.empty:
            report.append("## Top Friedmann density-curvature pair age matches")
            report.append("")
            cols = [
                "scenario", "qeg_value_density", "qeg_value_curvature",
                "Omega_m", "Omega_k", "Omega_Lambda", "closure_residual",
                "age_Gyr", "abs_error_Gyr", "rel_error_percent", "qeg_name",
            ]
            report.append(okp.sort_values("abs_error_Gyr")[cols].head(20).to_markdown(index=False))
            report.append("")

    report.append("## Guardrails retained")
    report.append("")
    report.append("- Do not interpret raw QEG kappa as FLRW discrete `k` unless a scale factor normalization `a0` is supplied.")
    report.append("- Do not interpret QEG rho as physical SI density unless the script finds or is given units/calibration.")
    report.append("- Treat `Omega_m`, `Omega_k`, and `Omega_Lambda` readings as formal substitutions unless independently justified.")
    report.append("- Closure-adjusted scenarios are labeled separately from no-adjustment scenarios.")
    report.append("- Local proper-time proxy rows are dimensionless compactness analogies, not Schwarzschild mass/radius calculations.")
    report.append("")

    (outdir / "audit_report.md").write_text("\n".join(report), encoding="utf-8")


def write_figures(outdir: Path, fried_df: pd.DataFrame, pair_df: pd.DataFrame) -> None:
    if not HAVE_MPL:
        return
    figdir = outdir / "figures"
    figdir.mkdir(parents=True, exist_ok=True)

    try:
        ok = fried_df[fried_df["validity_flag"] == "OK"].copy()
        ok = ok.dropna(subset=["age_Gyr", "abs_error_Gyr"]).sort_values("abs_error_Gyr").head(25)
        if not ok.empty:
            labels = [f"{i+1}. {str(x)[:32]}" for i, x in enumerate(ok["qeg_name"].tolist())]
            plt.figure(figsize=(12, max(5, 0.32 * len(ok))))
            y = np.arange(len(ok))
            plt.barh(y, ok["age_Gyr"].astype(float))
            plt.axvline(float(REFERENCE_COSMOLOGY["age_reference_Gyr"]), linestyle="--")
            plt.yticks(y, labels)
            plt.xlabel("Age from Friedmann integral (Gyr)")
            plt.title("Top QEG single-substitution Friedmann age comparisons")
            plt.gca().invert_yaxis()
            plt.tight_layout()
            plt.savefig(figdir / "age_comparison_top_single_substitutions.png", dpi=180)
            plt.close()
    except Exception:
        traceback.print_exc()

    try:
        ok = fried_df[fried_df["validity_flag"] == "OK"].copy()
        ok = ok.dropna(subset=["age_Gyr", "abs_error_Gyr", "closure_residual"])
        if not ok.empty:
            ok = ok.sort_values("abs_error_Gyr").head(400)
            plt.figure(figsize=(9, 6))
            plt.scatter(ok["closure_residual"].astype(float), ok["abs_error_Gyr"].astype(float), alpha=0.65)
            plt.axhline(0.1, linestyle="--")
            plt.axvline(0.0, linestyle="--")
            plt.xlabel("Closure residual Omega_total - 1")
            plt.ylabel("Absolute age error (Gyr)")
            plt.title("Closure residual vs Friedmann age error")
            plt.tight_layout()
            plt.savefig(figdir / "closure_residual_vs_age_error_single.png", dpi=180)
            plt.close()
    except Exception:
        traceback.print_exc()

    try:
        okp = pair_df[pair_df["validity_flag"] == "OK"].copy() if not pair_df.empty else pd.DataFrame()
        okp = okp.dropna(subset=["qeg_value_density", "qeg_value_curvature", "abs_error_Gyr"])
        if not okp.empty:
            okp = okp.sort_values("abs_error_Gyr").head(1000)
            plt.figure(figsize=(9, 7))
            sc = plt.scatter(
                okp["qeg_value_density"].astype(float),
                okp["qeg_value_curvature"].astype(float),
                c=okp["abs_error_Gyr"].astype(float),
                alpha=0.7,
            )
            plt.colorbar(sc, label="Absolute age error (Gyr)")
            plt.xlabel("QEG density-like value as Omega_m")
            plt.ylabel("QEG curvature-like value as Omega_k")
            plt.title("Pairwise QEG density/curvature Friedmann substitution")
            plt.tight_layout()
            plt.savefig(figdir / "pairwise_density_curvature_age_error.png", dpi=180)
            plt.close()
    except Exception:
        traceback.print_exc()

# ============================================================
# Main
# ============================================================

def main(argv: Optional[Sequence[str]] = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    root = Path(argv[0]).expanduser().resolve() if argv else DEFAULT_PROJECT_ROOT
    if not root.exists():
        print(f"ERROR: project root does not exist: {root}")
        return 2

    outdir = root / "metric_stage_7D_outputs" / RUN_NAME
    outdir.mkdir(parents=True, exist_ok=True)
    (outdir / "figures").mkdir(parents=True, exist_ok=True)

    print("=" * 72)
    print(f"{STAGE_NAME}: Friedmann Curvature/Density Time Probe")
    print("=" * 72)
    print(f"Project root: {root}")
    print(f"Output dir  : {outdir}")
    print(f"SciPy       : {HAVE_SCIPY}")
    print(f"Matplotlib  : {HAVE_MPL}")
    print("Status      : comparison bookkeeping; no physical identification")
    print("-")

    print("[1/7] Building file inventory...")
    inventory = build_file_inventory(root)
    inventory.to_csv(outdir / "qeg_file_inventory.csv", index=False)
    print(f"      files: {len(inventory)}")

    print("[2/7] Extracting keyword snippets...")
    snippets = extract_text_snippets(root, inventory)
    snippets.to_csv(outdir / "keyword_snippets.csv", index=False)
    print(f"      snippets: {len(snippets)}")

    print("[3/7] Extracting scalar candidates from CSV/JSON/text...")
    cand_df, colsum_df = collect_scalar_candidates(root, inventory)
    cand_df.to_csv(outdir / "scalar_evidence_candidates.csv", index=False)
    colsum_df.to_csv(outdir / "numeric_column_summaries.csv", index=False)
    print(f"      scalar candidates: {len(cand_df)}")
    print(f"      numeric summaries : {len(colsum_df)}")

    print("[4/7] Summarizing candidates by role...")
    if not cand_df.empty:
        summary = cand_df.groupby("role").agg(
            count=("value", "count"),
            min_value=("value", "min"),
            median_value=("value", "median"),
            mean_value=("value", "mean"),
            max_value=("value", "max"),
            max_confidence=("confidence", "max"),
        ).reset_index()
    else:
        summary = pd.DataFrame()
    summary.to_csv(outdir / "candidate_summary_by_role.csv", index=False)

    print("[5/7] Running Friedmann substitution scenarios...")
    fried_df, pair_df, local_df = run_friedmann_substitutions(cand_df)
    fried_df.to_csv(outdir / "friedmann_qeg_substitution_results.csv", index=False)
    pair_df.to_csv(outdir / "pairwise_density_curvature_friedmann_results.csv", index=False)
    local_df.to_csv(outdir / "local_time_proxy_results.csv", index=False)

    ref_row = make_friedmann_result(
        scenario="external_reference_only_no_QEG_substitution",
        qeg_source="external_reference",
        qeg_name="Planck2018_like_reference",
        qeg_role="external_reference",
        density_value=None,
        curvature_value=None,
        Om_m=float(REFERENCE_COSMOLOGY["Omega_m"]),
        Om_k=float(REFERENCE_COSMOLOGY["Omega_k"]),
        Om_L=float(REFERENCE_COSMOLOGY["Omega_Lambda"]),
        Om_r=float(REFERENCE_COSMOLOGY["Omega_r"]),
        H0=float(REFERENCE_COSMOLOGY["H0_km_s_Mpc"]),
        note="External reference baseline.",
    )
    pd.DataFrame([asdict(ref_row)]).to_csv(outdir / "friedmann_reference.csv", index=False)

    print("[6/7] Writing figures and audit report...")
    write_figures(outdir, fried_df, pair_df)
    write_markdown_report(outdir, root, inventory, snippets, cand_df, colsum_df, fried_df, pair_df, local_df)

    print("[7/7] Writing JSON summary...")
    def top_rows(df: pd.DataFrame, n: int = 8) -> List[Dict[str, Any]]:
        if df.empty or "abs_error_Gyr" not in df.columns:
            return []
        ok = df[df["validity_flag"] == "OK"].dropna(subset=["abs_error_Gyr"]).sort_values("abs_error_Gyr").head(n)
        return json.loads(ok.to_json(orient="records"))

    summary_json = {
        "stage": STAGE_NAME,
        "run_name": RUN_NAME,
        "project_root": str(root),
        "output_dir": str(outdir),
        "status": "COMPARISON_BOOKKEEPING_NOT_PHYSICAL_IDENTIFICATION",
        "external_reference": REFERENCE_COSMOLOGY,
        "counts": {
            "files_inventoried": int(len(inventory)),
            "keyword_snippets": int(len(snippets)),
            "scalar_candidates": int(len(cand_df)),
            "numeric_column_summaries": int(len(colsum_df)),
            "friedmann_single_substitution_rows": int(len(fried_df)),
            "friedmann_pairwise_rows": int(len(pair_df)),
            "local_time_proxy_rows": int(len(local_df)),
        },
        "top_single_substitution_age_matches": top_rows(fried_df, 10),
        "top_pairwise_age_matches": top_rows(pair_df, 10),
        "guardrail_note": (
            "The no-Friedmann guardrail is relaxed here only as a controlled sandbox. "
            "Do not promote matches unless the source quantities are independently stable, "
            "lineage-preserved, and null-resistant."
        ),
        "main_outputs": [
            "qeg_file_inventory.csv",
            "keyword_snippets.csv",
            "scalar_evidence_candidates.csv",
            "candidate_summary_by_role.csv",
            "friedmann_reference.csv",
            "friedmann_qeg_substitution_results.csv",
            "pairwise_density_curvature_friedmann_results.csv",
            "local_time_proxy_results.csv",
            "audit_report.md",
        ],
    }
    (outdir / "stage7D_summary.json").write_text(json.dumps(summary_json, indent=2), encoding="utf-8")

    print("-")
    print("Primary outputs:")
    for name in summary_json["main_outputs"]:
        print(f"  - {outdir / name}")

    # Console headline results.
    if not fried_df.empty:
        ok = fried_df[fried_df["validity_flag"] == "OK"].dropna(subset=["abs_error_Gyr"]).sort_values("abs_error_Gyr").head(5)
        if not ok.empty:
            print("-")
            print("Top single-substitution age matches:")
            for _, r in ok.iterrows():
                print(
                    f"  age={r['age_Gyr']:.6f} Gyr | err={r['abs_error_Gyr']:.6f} Gyr "
                    f"({r['rel_error_percent']:.3f}%) | scenario={r['scenario']} | "
                    f"value_density={r['qeg_value_density']} value_curvature={r['qeg_value_curvature']} | {r['qeg_name']}"
                )
    if not pair_df.empty:
        okp = pair_df[pair_df["validity_flag"] == "OK"].dropna(subset=["abs_error_Gyr"]).sort_values("abs_error_Gyr").head(5)
        if not okp.empty:
            print("-")
            print("Top pairwise density-curvature age matches:")
            for _, r in okp.iterrows():
                print(
                    f"  age={r['age_Gyr']:.6f} Gyr | err={r['abs_error_Gyr']:.6f} Gyr "
                    f"({r['rel_error_percent']:.3f}%) | Omega_m={r['Omega_m']:.8g} "
                    f"Omega_k={r['Omega_k']:.8g} Omega_L={r['Omega_Lambda']:.8g} | {r['qeg_name'][:110]}"
                )

    print("=" * 72)
    print("DONE")
    print("=" * 72)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
