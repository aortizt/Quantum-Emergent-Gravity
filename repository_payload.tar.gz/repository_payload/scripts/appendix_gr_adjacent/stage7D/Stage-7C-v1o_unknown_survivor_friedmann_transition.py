#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Stage-7C-v1o: Unknown Survivor Provenance + Friedmann Bridge Transition
Project: Quantum-Emergent Gravity
Author: Arturo Ortiz-Tapia / ChatGPT-assisted script generation
Build date: 2026-06-02

Purpose
-------
This is the Option-C repair-and-transition script requested after Stage-7C-v1n.
It is NOT a broad recomputation stage and does NOT rerun old scripts blindly.

It does four tightly scoped jobs:

1. Trace the remaining Stage-7C-v1k UNKNOWN low-k survivor:
   - source file
   - source row
   - vector names
   - candidate IDs
   - possible family hints
   - generating script / output folder hints
   - prior-ledger evidence overlap

2. Decide how the survivor should be treated in manuscript language:
   - promoted only if row-level or source-level provenance is adequate
   - otherwise retained as candidate independent low-k witness / appendix-only

3. Inventory the dormant Stage-7D Friedmann / GR-adjacent branch:
   - do not promote Friedmann age-matching
   - treat as appendix / adversarial benchmark / later v2 branch
   - record criteria for reattempting Friedmann-style calculations after the
     current time-surrogate and operator-geometry evidence is stabilized

4. Write an ASCII transition package for the next stage:
   - closes Stage-7C repair if unknown is resolved or demoted transparently
   - prepares Stage-7D-v2 Friedmann reattempt criteria
   - prepares Stage-7E manuscript / GitHub / Zenodo curation stage

Outputs
-------
All outputs are written to:

  metric_stage_7C_outputs/unknown_survivor_friedmann_transition_v1o/

Main output files:

  stage7C_v1o_summary.json
  stage7C_v1o_ledger_note.txt
  stage7C_v1o_unknown_survivor_trace.csv
  stage7C_v1o_unknown_source_row_dump.json
  stage7C_v1o_survivor_resolution_table.csv
  stage7C_v1o_prior_ledger_overlap.csv
  stage7C_v1o_remaining_loose_ends.csv
  stage7C_v1o_friedmann_branch_inventory.csv
  stage7C_v1o_friedmann_revisit_criteria.csv
  stage7C_v1o_next_stage_task_table.csv
  stage7C_v1o_ascii_transition_package.txt

Scientific guardrails
---------------------
- No PDG/Planck/LambdaCDM/Friedmann/GR/cosmological constants may select,
  orient, fit, score, or upgrade internal witnesses.
- Friedmann calculations remain comparison / appendix / adversarial benchmark
  until QEG supplies an internally generated time/evolution surrogate with
  sufficient family, null, and operator support.
- UNKNOWN family labels are not accepted at face value; they are traced,
  resolved, or transparently demoted.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

try:
    import pandas as pd
except Exception as exc:  # pragma: no cover
    print("ERROR: pandas is required for this script.", file=sys.stderr)
    raise

FAMILY_TERMS = ["BARI", "NUFIT", "VALENCIA", "POOLED"]
ROBUST_NULLS = ["permutation", "circular_shift"]
FORBIDDEN_CLAIMS = [
    "physical time derived",
    "spacetime derived",
    "thermodynamic arrow proven",
    "entropy production proven",
    "cosmic age derived",
    "Friedmann equations derived",
    "Einstein gravity derived",
    "Omega_m derived",
    "dark energy derived",
    "curvature of the universe derived",
    "quantum gravity proven",
    "quantum-mechanical interpretation confirmed",
]


def now_iso() -> str:
    return datetime.now().replace(microsecond=0).isoformat()


def sha16_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8", errors="replace")).hexdigest()[:16]


def sha16_file(path: Path) -> str:
    try:
        h = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b""):
                h.update(chunk)
        return h.hexdigest()[:16]
    except Exception:
        return "UNAVAILABLE"


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def safe_read_csv(path: Optional[Path]) -> pd.DataFrame:
    if path is None:
        return pd.DataFrame()
    try:
        if not path.exists() or path.stat().st_size == 0:
            return pd.DataFrame()
        return pd.read_csv(path)
    except Exception as exc:
        return pd.DataFrame({"__read_error__": [repr(exc)], "__path__": [str(path)]})


def safe_read_json(path: Optional[Path]) -> Any:
    if path is None or not path.exists():
        return None
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            return json.load(f)
    except Exception:
        return None


def safe_write_csv(df: pd.DataFrame, path: Path) -> None:
    df.to_csv(path, index=False)


def safe_str(x: Any) -> str:
    if x is None:
        return ""
    if isinstance(x, float) and pd.isna(x):
        return ""
    return str(x)


def find_project_root(user_root: Optional[str]) -> Path:
    candidates = []
    if user_root:
        candidates.append(Path(user_root).expanduser())
    candidates += [
        Path.cwd(),
        Path("/home/dakini/Downloads/010-Quantum_Emergent_Gravity"),
        Path("/mnt/data"),
    ]
    for c in candidates:
        if c.exists():
            # Prefer a root with the expected project output folders or uploaded artifacts.
            if (c / "metric_stage_7C_outputs").exists() or any(c.glob("stage7C_v1n_*.csv")):
                return c.resolve()
    return candidates[0].resolve()


def candidate_paths(project_root: Path, basename: str) -> List[Path]:
    out: List[Path] = []
    direct = project_root / basename
    if direct.exists():
        out.append(direct)
    try:
        out += list(project_root.rglob(basename))
    except Exception:
        pass
    # include /mnt/data if project root is Dakini and this is run in a sandbox-like environment
    if project_root != Path("/mnt/data") and Path("/mnt/data").exists():
        p = Path("/mnt/data") / basename
        if p.exists():
            out.append(p)
    # de-duplicate preserving order
    seen = set()
    uniq = []
    for p in out:
        key = str(p.resolve()) if p.exists() else str(p)
        if key not in seen:
            seen.add(key)
            uniq.append(p)
    return uniq


def locate_file(project_root: Path, path_or_name: Any) -> Optional[Path]:
    s = safe_str(path_or_name).strip()
    if not s:
        return None
    p = Path(s).expanduser()
    if p.exists():
        return p.resolve()
    # If source is an absolute Dakini path but the local runtime only has uploaded basename.
    for cand in candidate_paths(project_root, p.name):
        if cand.exists():
            return cand.resolve()
    return None


def load_first(project_root: Path, names: Iterable[str], glob_patterns: Iterable[str] = ()) -> Tuple[Optional[Path], pd.DataFrame]:
    for name in names:
        p = locate_file(project_root, name)
        if p is not None:
            return p, safe_read_csv(p)
    for pat in glob_patterns:
        try:
            hits = sorted(project_root.rglob(pat))
        except Exception:
            hits = []
        for h in hits:
            if h.exists():
                return h, safe_read_csv(h)
    return None, pd.DataFrame()


def extract_row_index(*texts: Any) -> Optional[int]:
    for text in texts:
        m = re.search(r"row\s*=\s*(\d+)", safe_str(text))
        if m:
            return int(m.group(1))
    return None


def family_hints_from_text(text: str) -> List[str]:
    upper = text.upper()
    return [f for f in FAMILY_TERMS if f in upper]


def family_columns(df: pd.DataFrame) -> List[str]:
    cols = []
    for c in df.columns:
        low = str(c).lower()
        if any(k in low for k in ["family", "fit", "fit_id", "source_file", "npz", "label", "variant"]):
            cols.append(c)
    return cols


def compact_value(x: Any, max_len: int = 500) -> str:
    s = safe_str(x)
    if len(s) > max_len:
        return s[: max_len - 3] + "..."
    return s


def row_to_flat_dict(df: pd.DataFrame, idx: int) -> Dict[str, Any]:
    if df.empty or idx < 0 or idx >= len(df):
        return {}
    row = df.iloc[idx]
    return {str(k): compact_value(v, 1000) for k, v in row.items()}


def pathlike_values(row_dict: Dict[str, Any]) -> List[str]:
    vals = []
    for k, v in row_dict.items():
        s = safe_str(v)
        if any(tok in s for tok in ["/", ".csv", ".json", ".npz", ".py", "metric_stage_"]):
            # split on common separators to capture embedded paths
            pieces = re.split(r"[;,\s]+", s)
            for piece in pieces:
                if any(tok in piece for tok in ["/", ".csv", ".json", ".npz", ".py", "metric_stage_"]):
                    vals.append(piece.strip().strip('"\''))
    return sorted(set(vals))


def infer_stage_from_path(path: Any) -> str:
    s = safe_str(path)
    m = re.search(r"stage[_-]?(\d+[A-Za-z]*)(?:[_-]|\b)", s, flags=re.IGNORECASE)
    if m:
        return "Stage-" + m.group(1).upper()
    m = re.search(r"metric_stage_(\d+[A-Za-z]*)", s, flags=re.IGNORECASE)
    if m:
        return "Stage-" + m.group(1).upper()
    return "UNKNOWN"


def summarize_prior_overlap(prior_ledger: pd.DataFrame, source_file: str, candidate_id: str, vector_signature: str) -> pd.DataFrame:
    if prior_ledger.empty:
        return pd.DataFrame()
    masks = []
    sf = safe_str(source_file)
    bn = Path(sf).name if sf else ""
    if "source_file" in prior_ledger.columns and sf:
        masks.append(prior_ledger["source_file"].astype(str).eq(sf))
    if "relative_path" in prior_ledger.columns and bn:
        masks.append(prior_ledger["relative_path"].astype(str).str.contains(re.escape(bn), na=False))
    if candidate_id:
        anymask = prior_ledger.astype(str).apply(lambda col: col.str.contains(re.escape(candidate_id), na=False)).any(axis=1)
        masks.append(anymask)
    if vector_signature:
        anymask = prior_ledger.astype(str).apply(lambda col: col.str.contains(re.escape(vector_signature), na=False)).any(axis=1)
        masks.append(anymask)
    if not masks:
        return pd.DataFrame()
    mask = masks[0]
    for m in masks[1:]:
        mask = mask | m
    return prior_ledger.loc[mask].copy()


def build_friedmann_inventory(project_root: Path) -> pd.DataFrame:
    patterns = ["*friedmann*", "*Friedmann*", "*stage7D*", "*Stage-7D*", "*GR*adjacent*", "*proper*time*"]
    rows = []
    seen = set()
    for pat in patterns:
        try:
            hits = list(project_root.rglob(pat))
        except Exception:
            hits = []
        for p in hits:
            if p.is_dir():
                continue
            key = str(p.resolve())
            if key in seen:
                continue
            seen.add(key)
            ext = p.suffix.lower()
            text_preview = ""
            if ext in [".txt", ".md", ".json", ".csv"]:
                try:
                    text_preview = p.read_text(encoding="utf-8", errors="replace")[:1000].replace("\n", " ")
                except Exception:
                    text_preview = ""
            rows.append({
                "path": str(p),
                "relative_path": str(p.relative_to(project_root)) if str(p).startswith(str(project_root)) else str(p),
                "stage_hint": infer_stage_from_path(p),
                "suffix": ext,
                "size_bytes": p.stat().st_size if p.exists() else None,
                "sha16": sha16_file(p),
                "contains_friedmann": "friedmann" in (str(p).lower() + text_preview.lower()),
                "contains_age": "age" in text_preview.lower(),
                "contains_omega": "omega" in text_preview.lower() or "Ω" in text_preview,
                "contains_curvature": "curvature" in text_preview.lower() or "omega_k" in text_preview.lower(),
                "preview": compact_value(text_preview, 300),
            })
    return pd.DataFrame(rows)


def build_revisit_criteria() -> pd.DataFrame:
    rows = [
        {
            "criterion_id": "F1",
            "criterion": "Internal time/evolution surrogate is stable before Friedmann reattempt",
            "required_evidence": "Entropy/operator/forward-reverse channels survive nulls, family audit, and perturbation/ablation tests.",
            "current_status": "PARTIALLY_SUPPORTED_AFTER_STAGE7C_V1M_V1N",
            "paper_role": "gatekeeping criterion",
        },
        {
            "criterion_id": "F2",
            "criterion": "Density-curvature coupling is internally generated",
            "required_evidence": "rho-kappa/kappa-rho operator results are summarized without using cosmological constants as fit targets.",
            "current_status": "SUPPORTED_AS_NONLOCAL_OPERATOR_GEOMETRY; NOT GR_DERIVATION",
            "paper_role": "bridge rationale",
        },
        {
            "criterion_id": "F3",
            "criterion": "Friedmann constants are locked external references only",
            "required_evidence": "No PDG/Planck/LambdaCDM/Friedmann/GR constant selects, orients, fits, scores, or upgrades QEG witnesses.",
            "current_status": "GUARDRAIL_ACTIVE",
            "paper_role": "non-overfitting guardrail",
        },
        {
            "criterion_id": "F4",
            "criterion": "Age matching alone cannot promote a QEG claim",
            "required_evidence": "Age/curvature/density substitutions are classified as comparison bookkeeping or appendix diagnostics.",
            "current_status": "DORMANT_STAGE7D_POLICY_ACTIVE",
            "paper_role": "anti-overclaim guardrail",
        },
        {
            "criterion_id": "F5",
            "criterion": "Stage-7D-v2 may be attempted after UNKNOWN low-k survivor is resolved or demoted",
            "required_evidence": "v1o resolution table shows either adequate provenance or transparent demotion of unresolved survivor.",
            "current_status": "THIS_SCRIPT_TESTS_THE_GATE",
            "paper_role": "next-stage trigger",
        },
    ]
    return pd.DataFrame(rows)


def build_next_stage_task_table() -> pd.DataFrame:
    rows = [
        {
            "next_step": "Stage-7D-v2",
            "title": "Friedmann/GR-adjacent Bridge Reattempt under v1m/v1n/v1o Guardrails",
            "purpose": "Revisit the dormant Friedmann branch only as adversarial comparison/bookkeeping using stronger time-surrogate context.",
            "deliverables": "locked-constant audit; candidate internal variable table; substitution-risk table; no-claim appendix note",
            "start_condition": "UNKNOWN survivor resolved or demoted; v1n evidence hierarchy accepted",
        },
        {
            "next_step": "Stage-7E",
            "title": "Pipeline Compression, Repository Freeze, and Manuscript Asset Curation",
            "purpose": "Deep/wide script-ledger sweep for GitHub README, Zenodo README, and paper outline.",
            "deliverables": "script bundle map; master ledger concordance; minimal frozen reproduction bundle; figure/table short list",
            "start_condition": "Stage-7D-v2 decision recorded as appendix/revisit branch or not-run-yet branch",
        },
        {
            "next_step": "Stage-7E-Part-A",
            "title": "Script and Ledger Audit for GitHub",
            "purpose": "Curate which scripts belong in GitHub and document how to run them.",
            "deliverables": "GitHub README draft; script dependency graph; expected outputs table; environment notes",
            "start_condition": "Stage-7E starts",
        },
        {
            "next_step": "Stage-7E-Part-B",
            "title": "Summary Results and Figures Audit for Zenodo",
            "purpose": "Select core summaries/figures/tables and map each artifact to its generating script.",
            "deliverables": "Zenodo README draft; artifact manifest; figure/table selection; provenance crosswalk",
            "start_condition": "GitHub curation map exists",
        },
        {
            "next_step": "Stage-7F",
            "title": "Paper Architecture and Literature Calibration",
            "purpose": "Turn GitHub/Zenodo READMEs and master ledger into paper outline/introduction/methods/results/discussion.",
            "deliverables": "paper outline; title audit; literature comparison table; claim ladder; abstract posture",
            "start_condition": "Stage-7E curation complete",
        },
    ]
    return pd.DataFrame(rows)


def build_ascii_package(
    summary: Dict[str, Any],
    resolution_df: pd.DataFrame,
    friedmann_inventory: pd.DataFrame,
    next_tasks: pd.DataFrame,
) -> str:
    unresolved_count = int((resolution_df.get("resolution_status", pd.Series(dtype=str)).astype(str).str.contains("UNRESOLVED", na=False)).sum()) if not resolution_df.empty else 0
    promoted_count = int((resolution_df.get("manuscript_status", pd.Series(dtype=str)).astype(str).str.contains("PROMOTABLE", na=False)).sum()) if not resolution_df.empty else 0
    demoted_count = int((resolution_df.get("manuscript_status", pd.Series(dtype=str)).astype(str).str.contains("DEMOTE|APPENDIX|REVIEW_ONLY", na=False)).sum()) if not resolution_df.empty else 0
    friedmann_count = len(friedmann_inventory)

    text = f"""
============================================================
ASCII TRANSITION PACKAGE
Project: Quantum-Emergent Gravity
Stage: Stage-7C-v1o
Working Title: Unknown Survivor Provenance + Friedmann Bridge Transition
Generated: {summary.get('run_timestamp')}
============================================================

PURPOSE
-------
Option C is adopted.

This stage is neither a narrow mini-script nor a full manuscript wrap.
It is the final repair-and-transition checkpoint before:

1) a controlled Friedmann/GR-adjacent reattempt, and
2) a pipeline-wide GitHub / Zenodo / manuscript curation stage.

------------------------------------------------------------
UPSTREAM STATE
------------------------------------------------------------

Stage-7C-v1m produced an A-level internal synthesis:

  A_INTERNAL_SYNTHESIS_SCRIPT_CREATED_EVIDENCE_CHANNELS_AUDITED_AND_RECOMPUTED

Stage-7C-v1n produced a B+ hardening result:

  B_PLUS_MANUSCRIPT_HARDENING_USEFUL_REMAINING_PROVENANCE_OR_INDEPENDENCE_REVIEW

v1n found:

  - robust p<0.05 survivor detail rows: {summary.get('v1n_robust_detail_rows')}
  - distinct low-k independence groups: {summary.get('v1n_independence_groups')}
  - hardened null candidate survivors: {summary.get('v1n_hardened_survivor_groups')}
  - remaining UNKNOWN / unresolved survivor rows before v1o: {summary.get('unknown_rows_loaded')}

------------------------------------------------------------
STAGE-7C-v1o FINDINGS
------------------------------------------------------------

Unknown survivor resolution rows: {len(resolution_df)}
Promotable survivor rows: {promoted_count}
Demoted / appendix / review-only rows: {demoted_count}
Still unresolved rows: {unresolved_count}

Rule:
  UNKNOWN family labels are not accepted at face value.
  Each survivor must be traced to source file, source row, vector names,
  candidate IDs, possible family hints, and generating script/output folder.

Interpretation rule:
  If the Stage-7C-v1k survivor remains without row-level or source-level
  lineage, it is retained only as a candidate independent low-k witness.
  It may support an appendix or future-work note, but not a primary claim.

------------------------------------------------------------
FRIEDMANN / GR-ADJACENT BRANCH
------------------------------------------------------------

Existing Friedmann-related artifacts found: {friedmann_count}

Status:
  dormant background / appendix candidate / adversarial benchmark

Not main pipeline:
  - no physical identification
  - no Friedmann-derived QEG time claim
  - no promotion from age-matching alone

Reattempt allowed only as Stage-7D-v2 if:
  - internal time/evolution surrogate is stable,
  - rho-kappa/density-curvature relation is summarized internally,
  - constants remain locked external references,
  - no external constant selects, fits, scores, or upgrades QEG witnesses.

------------------------------------------------------------
NEXT STAGE PLAN
------------------------------------------------------------

Stage-7D-v2:
  Friedmann/GR-adjacent Bridge Reattempt under v1m/v1n/v1o Guardrails.
  This is optional/adversarial/appendix-facing, not a claim stage.

Stage-7E:
  Pipeline Compression, Repository Freeze, and Manuscript Asset Curation.

Stage-7E Part A:
  Script and ledger audit for GitHub.
  Curate scripts, execution order, expected outputs, and README.

Stage-7E Part B:
  Summary results / figures / tables audit for Zenodo.
  Map every artifact to its generating script and README description.

Stage-7F:
  Paper architecture and literature calibration.
  Use GitHub README, Zenodo README, and master ledger to write the paper.

------------------------------------------------------------
PAPER ARCHITECTURE TO PRESERVE
------------------------------------------------------------

The paper is NOT a 230-script chronology.
It is a compressed mathematical and evidentiary account.

Suggested architecture:

1. Introduction
   - why neutrino-family data were chosen,
   - bottom-up vs top-down emergence programs,
   - prior literature survey / data-driven comparison search,
   - scope and non-claims.

2. From neutrino-family lineage to intrinsic geometry
   - lineage preservation,
   - geometry and metric-like organization,
   - coordinate/repair discipline.

3. Emergent two-sector / bimodal structure
   - two-lobed law,
   - symmetry-breaking-like interpretation,
   - family universality and repair history.

4. Nonlocal rho-kappa / kappa-rho operator geometry
   - density-curvature response,
   - Green-function/nonlocal operator motivation,
   - rejection of simple local PDE closure and tautological rank-1 stories.

5. Recursive stabilization and space-like transport
   - recursion as downstream dynamical probe,
   - sector preservation vs equilibration,
   - low-rank asymmetric transport.

6. Dimensionless cosmological/spacetime bookkeeping
   - Omega_m proximity and variants,
   - curvature/density comparisons,
   - comparison-only status.

7. Time-surrogate evidence
   - entropy as primary surrogate,
   - operator directionality,
   - forward/reverse recursion,
   - low-k spectral witness as corroborating review evidence,
   - partial-reversibility sandbox as diagnostic control.

8. Discussion
   - summary table of physical proximities,
   - semantics of physical objects without overclaiming,
   - what would be needed to elevate QEG toward stronger physical status.

9. Conclusions
   - documented emergence program,
   - conjectural next requirements,
   - GitHub/Zenodo reproducibility pathway.

Appendices:
   A. Mathematical pipeline summary, not full script chronology.
   B. Friedmann/GR-adjacent comparison branch, if retained.
   C. Guardrails and non-claims.

------------------------------------------------------------
FORBIDDEN CLAIMS
------------------------------------------------------------

""".strip()
    for c in FORBIDDEN_CLAIMS:
        text += f"\n- {c}"
    text += "\n\n============================================================\nEND ASCII TRANSITION PACKAGE\n============================================================\n"
    return text


def main() -> None:
    parser = argparse.ArgumentParser(description="Stage-7C-v1o unknown survivor + Friedmann transition script")
    parser.add_argument("--project-root", default=None, help="QEG project root. Defaults to auto-detection.")
    parser.add_argument("--output-dir", default=None, help="Optional explicit output directory.")
    args = parser.parse_args()

    project_root = find_project_root(args.project_root)
    out_dir = Path(args.output_dir).expanduser() if args.output_dir else project_root / "metric_stage_7C_outputs" / "unknown_survivor_friedmann_transition_v1o"
    ensure_dir(out_dir)

    # Load v1n / v1m files, first from project root then from /mnt/data if present.
    prov_path, prov = load_first(project_root, [
        "stage7C_v1n_lowk_survivor_provenance_trace.csv",
    ], ["**/stage7C_v1n_lowk_survivor_provenance_trace.csv"])
    ind_path, independence = load_first(project_root, [
        "stage7C_v1n_independence_audit.csv",
    ], ["**/stage7C_v1n_independence_audit.csv"])
    robust_path, robust = load_first(project_root, [
        "stage7C_v1n_robust_lowk_survivor_detail.csv",
    ], ["**/stage7C_v1n_robust_lowk_survivor_detail.csv"])
    v1m_exports_path, v1m_exports = load_first(project_root, [
        "stage7C_v1m_candidate_vector_exports.csv",
    ], ["**/stage7C_v1m_candidate_vector_exports.csv"])
    v1l_exports_path, v1l_exports = load_first(project_root, [
        "stage7C_v1l_regenerated_primary_vector_exports.csv",
    ], ["**/stage7C_v1l_regenerated_primary_vector_exports.csv"])
    prior_path, prior_ledger = load_first(project_root, [
        "stage7C_v1m_prior_time_surrogate_channel_ledger.csv",
    ], ["**/stage7C_v1m_prior_time_surrogate_channel_ledger.csv"])
    rework_path, rework_plan = load_first(project_root, [
        "stage7C_v1m_source_script_rework_plan.csv",
    ], ["**/stage7C_v1m_source_script_rework_plan.csv", "**/stage7C_v1n_tier1_rework_script_candidates.csv"])

    summary_json_path = locate_file(project_root, "stage7C_v1n_summary.json")
    v1n_summary = safe_read_json(summary_json_path) or {}

    # Identify unresolved/UNKNOWN survivor rows.
    unknown = pd.DataFrame()
    if not prov.empty:
        text_join = prov.astype(str).agg(" | ".join, axis=1)
        resolved_hint = prov.get("resolved_family_hint", pd.Series([""] * len(prov))).astype(str).str.upper()
        family_status = prov.get("family_resolution_status", pd.Series([""] * len(prov))).astype(str)
        provenance_text = prov.get("provenance_conclusion", pd.Series([""] * len(prov))).astype(str)
        mask = (
            resolved_hint.eq("UNKNOWN")
            | family_status.str.contains("UNRESOLVED_NO_ROW_LEVEL|UNRESOLVED", case=False, na=False)
            | provenance_text.str.contains("TRACE_BACK_TO_UPSTREAM_EXPORT_REQUIRED|TRACE_BACK|UNRESOLVED_NO", case=False, na=False)
            | text_join.str.contains("TRACE_BACK_TO_UPSTREAM_EXPORT_REQUIRED", case=False, na=False)
        )
        unknown = prov.loc[mask].copy()

    trace_rows: List[Dict[str, Any]] = []
    resolution_rows: List[Dict[str, Any]] = []
    row_dump: Dict[str, Any] = {}
    prior_overlap_rows: List[pd.DataFrame] = []

    for idx, row in unknown.iterrows():
        cid = safe_str(row.get("candidate_id"))
        source_file_text = safe_str(row.get("source_file"))
        source_file = locate_file(project_root, source_file_text)
        row_idx = extract_row_index(row.get("forward_vector_name"), row.get("reverse_vector_name"), cid)
        vector_signature = safe_str(row.get("vector_pair_signature"))

        source_df = safe_read_csv(source_file) if source_file else pd.DataFrame()
        source_exists = source_file is not None and source_file.exists()
        row_dict = row_to_flat_dict(source_df, row_idx) if row_idx is not None else {}
        row_text = json.dumps(row_dict, ensure_ascii=False, sort_keys=True) if row_dict else ""
        family_hints = family_hints_from_text(row_text + " " + source_file_text)
        fcols = family_columns(source_df) if not source_df.empty and "__read_error__" not in source_df.columns else []

        # Match candidate in v1m/v1l exports for extra context.
        v1m_match = pd.DataFrame()
        if not v1m_exports.empty and "candidate_id" in v1m_exports.columns:
            v1m_match = v1m_exports[v1m_exports["candidate_id"].astype(str).eq(cid)].copy()
        v1l_match = pd.DataFrame()
        if not v1l_exports.empty and "candidate_id" in v1l_exports.columns:
            # v1m imported v1l candidates usually contain v1l candidate ID inside the candidate string.
            needle = re.sub(r"^stage7C_v1m_from_v1l_npz_", "", cid)
            needle = re.sub(r"_ade40bd576d01b32$", "", needle)
            v1l_match = v1l_exports[v1l_exports["candidate_id"].astype(str).str.contains(re.escape(needle[:120]), na=False)].copy()
            if v1l_match.empty and "source_file" in v1l_exports.columns:
                v1l_match = v1l_exports[v1l_exports.astype(str).apply(lambda col: col.str.contains(r"v1k_primary_vector_export_table|forward_vector\[row=2\]", regex=True, na=False)).any(axis=1)].copy()

        overlap = summarize_prior_overlap(prior_ledger, source_file_text, cid, vector_signature)
        if not overlap.empty:
            overlap = overlap.copy()
            overlap.insert(0, "traced_candidate_id", cid)
            prior_overlap_rows.append(overlap.head(250))  # avoid giant output if broad match

        path_values = pathlike_values(row_dict)
        located_path_values = []
        for pv in path_values:
            loc = locate_file(project_root, pv)
            if loc:
                located_path_values.append(str(loc))

        # Look for generating scripts/output folders via source path keywords.
        basename = Path(source_file_text).name if source_file_text else ""
        parent_hint = str(Path(source_file_text).parent.name) if source_file_text else ""
        rework_hits = pd.DataFrame()
        if not rework_plan.empty:
            combined = rework_plan.astype(str).agg(" | ".join, axis=1)
            needles = [basename, parent_hint, "v1k", "primary_vector", "manual_primary_vector_ingest"]
            mask = pd.Series(False, index=rework_plan.index)
            for n in needles:
                if n:
                    mask = mask | combined.str.contains(re.escape(n), case=False, na=False)
            rework_hits = rework_plan.loc[mask].copy()

        if source_exists and family_hints:
            resolution_status = "RESOLVED_SOURCE_ROW_OR_TEXT_CONTAINS_FAMILY_HINTS"
            manuscript_status = "PROMOTABLE_IF_ROW_AND_SCRIPT_CONTEXT_CONFIRMED"
        elif source_exists and fcols:
            resolution_status = "SOURCE_HAS_FAMILY_LIKE_COLUMNS_BUT_ROW_HINT_NOT_DETECTED"
            manuscript_status = "REVIEW_ONLY_UNTIL_ROW_LEVEL_FAMILY_CONFIRMED"
        elif source_exists:
            resolution_status = "SOURCE_FOUND_NO_FAMILY_HINTS_DETECTED"
            manuscript_status = "CANDIDATE_INDEPENDENT_LOWK_WITNESS_DEMOTE_TO_REVIEW_OR_APPENDIX"
        else:
            resolution_status = "UNRESOLVED_SOURCE_FILE_NOT_AVAILABLE_OR_NOT_FOUND"
            manuscript_status = "CANDIDATE_INDEPENDENT_LOWK_WITNESS_REQUIRES_TARGETED_SOURCE_REWORK"

        row_dump[cid] = {
            "source_file_reported": source_file_text,
            "source_file_located": str(source_file) if source_file else None,
            "row_index_interpreted_zero_based": row_idx,
            "source_row_dump": row_dict,
            "pathlike_values_in_source_row": path_values,
            "located_pathlike_values": located_path_values,
            "v1m_export_match_rows": v1m_match.to_dict(orient="records") if not v1m_match.empty else [],
            "v1l_export_match_rows": v1l_match.to_dict(orient="records") if not v1l_match.empty else [],
            "rework_plan_hits_preview": rework_hits.head(25).to_dict(orient="records") if not rework_hits.empty else [],
        }

        trace_rows.append({
            "candidate_id": cid,
            "source_stage": row.get("source_stage"),
            "source_file_reported": source_file_text,
            "source_file_located": str(source_file) if source_file else "",
            "source_file_exists": bool(source_exists),
            "source_file_sha16": sha16_file(source_file) if source_file else "UNAVAILABLE",
            "row_index_interpreted_zero_based": row_idx,
            "source_rows_read": len(source_df) if not source_df.empty and "__read_error__" not in source_df.columns else 0,
            "source_column_count": len(source_df.columns) if not source_df.empty and "__read_error__" not in source_df.columns else 0,
            "source_read_error": source_df["__read_error__"].iloc[0] if "__read_error__" in source_df.columns else "",
            "forward_vector_name": row.get("forward_vector_name"),
            "reverse_vector_name": row.get("reverse_vector_name"),
            "vector_pair_signature": vector_signature,
            "family_hints_from_source_row_or_path": ";".join(family_hints) if family_hints else "UNKNOWN",
            "family_columns_detected_in_source": ";".join(map(str, fcols)) if fcols else "",
            "pathlike_values_count": len(path_values),
            "located_pathlike_values_count": len(located_path_values),
            "prior_ledger_overlap_rows": len(overlap),
            "v1m_export_match_rows": len(v1m_match),
            "v1l_export_match_rows": len(v1l_match),
            "rework_plan_hits": len(rework_hits),
            "resolution_status": resolution_status,
            "manuscript_status": manuscript_status,
        })
        resolution_rows.append({
            "candidate_id": cid,
            "independence_group_id": row.get("independence_group_id"),
            "source_stage": row.get("source_stage"),
            "original_resolved_family_hint": row.get("resolved_family_hint"),
            "v1o_family_hints": ";".join(family_hints) if family_hints else "UNKNOWN",
            "resolution_status": resolution_status,
            "manuscript_status": manuscript_status,
            "recommended_action": (
                "promote only after row/script context is confirmed" if "PROMOTABLE" in manuscript_status else
                "fork a targeted Stage-7C source-specific rework if this witness is needed as primary" if "REQUIRES_TARGETED" in manuscript_status else
                "retain as review/appendix corroboration, not primary evidence"
            ),
            "source_file_reported": source_file_text,
            "source_file_located": str(source_file) if source_file else "",
        })

    trace_df = pd.DataFrame(trace_rows)
    resolution_df = pd.DataFrame(resolution_rows)
    prior_overlap_df = pd.concat(prior_overlap_rows, ignore_index=True) if prior_overlap_rows else pd.DataFrame()

    # Remaining loose ends table.
    loose_rows = []
    if not resolution_df.empty:
        for _, r in resolution_df.iterrows():
            unresolved = "UNRESOLVED" in safe_str(r.get("resolution_status")) or "REQUIRES_TARGETED" in safe_str(r.get("manuscript_status"))
            loose_rows.append({
                "issue": "Stage-7C-v1k UNKNOWN survivor provenance",
                "candidate_id": r.get("candidate_id"),
                "status": "OPEN" if unresolved else "CONTAINED_OR_DEMOTED",
                "risk_if_unresolved": "Cannot use as primary independent low-k witness; keep as candidate/review/appendix evidence.",
                "repair_action": r.get("recommended_action"),
            })
    else:
        loose_rows.append({
            "issue": "Unknown survivor table not found or no unknown rows loaded",
            "candidate_id": "",
            "status": "CHECK_INPUTS",
            "risk_if_unresolved": "Cannot assess final low-k provenance repair.",
            "repair_action": "ensure v1n provenance trace table is available",
        })
    loose_rows += [
        {
            "issue": "Manuscript narrative compression",
            "candidate_id": "",
            "status": "NEXT_STAGE",
            "risk_if_unresolved": "Paper reads like many script reports rather than a compressed emergence program.",
            "repair_action": "Stage-7E GitHub/Zenodo/readme curation before paper writing",
        },
        {
            "issue": "Friedmann branch logic",
            "candidate_id": "Stage-7D",
            "status": "DORMANT_REVISIT_AFTER_V1O",
            "risk_if_unresolved": "Age-matching or Friedmann substitutions may be overread as physical derivation.",
            "repair_action": "Stage-7D-v2 as locked-constant adversarial benchmark only",
        },
    ]
    loose_df = pd.DataFrame(loose_rows)

    friedmann_inventory = build_friedmann_inventory(project_root)
    friedmann_criteria = build_revisit_criteria()
    next_tasks = build_next_stage_task_table()

    summary = {
        "stage": "Stage-7C-v1o",
        "run_label": "unknown_survivor_friedmann_transition_v1o",
        "run_timestamp": now_iso(),
        "project_root": str(project_root),
        "output_dir": str(out_dir),
        "final_decision": "REPAIR_TRANSITION_PACKAGE_CREATED_UNKNOWN_TRACE_AND_FRIEDMANN_GATE_RECORDED",
        "v1n_final_decision": v1n_summary.get("final_decision", "UNKNOWN"),
        "v1n_robust_detail_rows": int(len(robust)) if not robust.empty and "__read_error__" not in robust.columns else 0,
        "v1n_independence_groups": int(len(independence)) if not independence.empty and "__read_error__" not in independence.columns else 0,
        "v1n_hardened_survivor_groups": int(v1n_summary.get("hardened_null_candidates_surviving_p05", 0) or 0),
        "unknown_rows_loaded": int(len(unknown)),
        "unknown_trace_rows": int(len(trace_df)),
        "promotable_after_v1o_rows": int(resolution_df.get("manuscript_status", pd.Series(dtype=str)).astype(str).str.contains("PROMOTABLE", na=False).sum()) if not resolution_df.empty else 0,
        "review_or_appendix_rows": int(resolution_df.get("manuscript_status", pd.Series(dtype=str)).astype(str).str.contains("REVIEW|APPENDIX|DEMOTE", na=False).sum()) if not resolution_df.empty else 0,
        "unresolved_after_v1o_rows": int(resolution_df.get("resolution_status", pd.Series(dtype=str)).astype(str).str.contains("UNRESOLVED", na=False).sum()) if not resolution_df.empty else 0,
        "friedmann_artifacts_found": int(len(friedmann_inventory)),
        "friedmann_policy": "DORMANT_APPENDIX_OR_ADVERSARIAL_BENCHMARK; NO_PROMOTION_FROM_AGE_MATCHING_ALONE",
        "recommended_next_action": "Run Stage-7D-v2 only as locked-constant adversarial comparison if desired; then proceed to Stage-7E repository/Zenodo/manuscript curation.",
        "external_constants_rule": "No PDG/Planck/LambdaCDM/Friedmann/GR/cosmological constants may select, orient, fit, score, or upgrade internal witnesses.",
        "forbidden_claims": FORBIDDEN_CLAIMS,
        "input_files": {
            "v1n_provenance_trace": str(prov_path) if prov_path else None,
            "v1n_independence_audit": str(ind_path) if ind_path else None,
            "v1n_robust_detail": str(robust_path) if robust_path else None,
            "v1m_candidate_exports": str(v1m_exports_path) if v1m_exports_path else None,
            "v1l_candidate_exports": str(v1l_exports_path) if v1l_exports_path else None,
            "prior_channel_ledger": str(prior_path) if prior_path else None,
            "source_rework_plan": str(rework_path) if rework_path else None,
        },
    }

    ascii_package = build_ascii_package(summary, resolution_df, friedmann_inventory, next_tasks)

    # Write outputs.
    safe_write_csv(trace_df, out_dir / "stage7C_v1o_unknown_survivor_trace.csv")
    safe_write_csv(resolution_df, out_dir / "stage7C_v1o_survivor_resolution_table.csv")
    safe_write_csv(prior_overlap_df, out_dir / "stage7C_v1o_prior_ledger_overlap.csv")
    safe_write_csv(loose_df, out_dir / "stage7C_v1o_remaining_loose_ends.csv")
    safe_write_csv(friedmann_inventory, out_dir / "stage7C_v1o_friedmann_branch_inventory.csv")
    safe_write_csv(friedmann_criteria, out_dir / "stage7C_v1o_friedmann_revisit_criteria.csv")
    safe_write_csv(next_tasks, out_dir / "stage7C_v1o_next_stage_task_table.csv")

    with open(out_dir / "stage7C_v1o_unknown_source_row_dump.json", "w", encoding="utf-8") as f:
        json.dump(row_dump, f, indent=2, ensure_ascii=False)
    with open(out_dir / "stage7C_v1o_summary.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)
    with open(out_dir / "stage7C_v1o_ascii_transition_package.txt", "w", encoding="utf-8") as f:
        f.write(ascii_package)

    ledger = f"""
============================================================
ASCII LEDGER NOTE
Project: Quantum-Emergent Gravity
Stage: Stage-7C-v1o
Working Title: Unknown Survivor Provenance + Friedmann Bridge Transition
Run Timestamp: {summary['run_timestamp']}
============================================================

FINAL DECISION
--------------
{summary['final_decision']}

PURPOSE
-------
Implement Option C: trace the remaining UNKNOWN low-k survivor, record whether
it is promotable or must be demoted/reworked, inventory the dormant Friedmann
branch, and prepare the transition package for Stage-7D-v2 / Stage-7E curation.

KEY COUNTS
----------
Unknown survivor rows loaded      : {summary['unknown_rows_loaded']}
Unknown trace rows written        : {summary['unknown_trace_rows']}
Promotable after v1o rows         : {summary['promotable_after_v1o_rows']}
Review/appendix rows              : {summary['review_or_appendix_rows']}
Unresolved after v1o rows         : {summary['unresolved_after_v1o_rows']}
Friedmann artifacts found         : {summary['friedmann_artifacts_found']}

POLICY
------
UNKNOWN family labels are not accepted at face value. If the Stage-7C-v1k
survivor cannot be given adequate row/source/generating-script provenance, it
must remain candidate/review/appendix evidence rather than a primary witness.

FRIEDMANN POLICY
----------------
{summary['friedmann_policy']}

EXTERNAL CONSTANTS RULE
-----------------------
{summary['external_constants_rule']}

OUTPUTS
-------
stage7C_v1o_unknown_survivor_trace.csv
stage7C_v1o_unknown_source_row_dump.json
stage7C_v1o_survivor_resolution_table.csv
stage7C_v1o_prior_ledger_overlap.csv
stage7C_v1o_remaining_loose_ends.csv
stage7C_v1o_friedmann_branch_inventory.csv
stage7C_v1o_friedmann_revisit_criteria.csv
stage7C_v1o_next_stage_task_table.csv
stage7C_v1o_ascii_transition_package.txt
stage7C_v1o_summary.json

============================================================
END LEDGER NOTE
============================================================
""".strip() + "\n"
    with open(out_dir / "stage7C_v1o_ledger_note.txt", "w", encoding="utf-8") as f:
        f.write(ledger)

    print("============================================================")
    print("Stage-7C-v1o complete")
    print("Output dir:", out_dir)
    print("Final decision:", summary["final_decision"])
    print("Unknown rows loaded:", summary["unknown_rows_loaded"])
    print("Unresolved after v1o:", summary["unresolved_after_v1o_rows"])
    print("Friedmann artifacts found:", summary["friedmann_artifacts_found"])
    print("============================================================")


if __name__ == "__main__":
    main()
