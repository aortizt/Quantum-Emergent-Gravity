#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
============================================================
Project: Quantum-Emergent Gravity
Stage  : Stage-7D v2
Script : Stage-7D_v2_friedmann_appendix_polishing.py
Author : Arturo Ortiz-Tapia / QEG pipeline support
Build  : 2026-06-02
============================================================

Working title
-------------
Friedmann / GR-Adjacent Appendix Polishing

Purpose
-------
This is a short appendix-facing audit script. It rereads prior
Friedmann / GR-adjacent outputs, classifies already-generated
candidate rows by physical/admissibility guardrails, and writes clean
appendix-facing tables and text.

It is NOT a new broad scalar search.
It is NOT a Friedmann derivation stage.
It is NOT allowed to promote QEG witnesses from age matching alone.

Core policy
-----------
External cosmological constants are locked references only. They may
be used for comparison after QEG candidates already exist. They may
not select, orient, fit, score-upgrade, or create QEG witnesses.

Output directory
----------------
metric_stage_7D_outputs/friedmann_appendix_polishing_v2/

Expected outputs
----------------
- stage7D_v2_summary.json
- stage7D_v2_ledger_note.txt
- stage7D_v2_appendix_candidate_table.csv
- stage7D_v2_quarantined_candidate_table.csv
- stage7D_v2_promotion_gate_table.csv
- stage7D_v2_forbidden_claims.md
- stage7D_v2_appendix_text_draft.md
- stage7D_v2_ascii_transition_package.txt

Optional/extra outputs
----------------------
- stage7D_v2_age_corridor_table.csv
- stage7D_v2_density_curvature_pair_audit.csv
- stage7D_v2_physical_admissibility_scores.csv
- stage7D_v2_input_file_inventory.csv

Run from Spyder
---------------
%runfile /home/dakini/Downloads/010-Quantum_Emergent_Gravity/metric_stage_7D_scripts/Stage-7D_v2_friedmann_appendix_polishing.py --wdir

Or from terminal
----------------
python3 Stage-7D_v2_friedmann_appendix_polishing.py

============================================================
"""

from __future__ import annotations

import csv
import json
import math
import os
import re
import sys
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd


# ============================================================
# LOCKED EXTERNAL REFERENCES
# ============================================================
# These are comparison references only. They are not used to generate
# or select QEG candidate observables.
LOCKED_REFERENCES = {
    "reference_label": "PDG/Planck-style flat LambdaCDM comparison constants, locked for appendix bookkeeping only",
    "age_universe_gyr": 13.797,
    "h": 0.674,
    "H0_km_s_Mpc": 67.4,
    "Omega_m": 0.315,
    "Omega_Lambda": 0.685,
    "Omega_k": 0.0007,
    "policy": "locked external constants may compare only after internal QEG quantities are frozen",
}

HUBBLE_TIME_GYR_FACTOR = 9.777752  # H0^{-1} = 9.777752 h^{-1} Gyr


# ============================================================
# NAMING / FILE DISCOVERY
# ============================================================
SCRIPT_NAME = "Stage-7D_v2_friedmann_appendix_polishing.py"
OUTPUT_REL = Path("metric_stage_7D_outputs") / "friedmann_appendix_polishing_v2"

INPUT_NAME_PATTERNS = [
    "friedmann",
    "stage7d",
    "stage_7d",
    "age",
    "density",
    "curvature",
    "omega",
    "proper_time",
    "time_proxy",
]

SKIP_DIR_PATTERNS = [
    ".git",
    "__pycache__",
    "friedmann_appendix_polishing_v2",
]

SUPPORTED_INPUT_EXTENSIONS = {".csv", ".json", ".txt", ".md"}


# ============================================================
# SMALL UTILITIES
# ============================================================
def safe_float(x: Any) -> Optional[float]:
    """Return float(x) when possible and finite, otherwise None."""
    if x is None:
        return None
    if isinstance(x, (bool, np.bool_)):
        return 1.0 if bool(x) else 0.0
    try:
        if isinstance(x, str):
            s = x.strip()
            if not s or s.lower() in {"nan", "none", "null", "na", "n/a"}:
                return None
            s = s.replace(",", "")
            # Pull a leading numeric token if the field contains units.
            m = re.search(r"[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?", s)
            if not m:
                return None
            val = float(m.group(0))
        else:
            val = float(x)
        if math.isfinite(val):
            return val
        return None
    except Exception:
        return None


def normalize_key(k: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(k).strip().lower()).strip("_")


def stringify_record(record: Dict[str, Any]) -> str:
    parts = []
    for k, v in record.items():
        if v is None:
            continue
        txt = str(v)
        if txt and txt.lower() != "nan":
            parts.append(f"{k}={txt}")
    return " | ".join(parts)


def compact_text(s: str, limit: int = 240) -> str:
    s = re.sub(r"\s+", " ", str(s)).strip()
    return s[:limit] + ("..." if len(s) > limit else "")


def mkdirp(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def to_jsonable(obj: Any) -> Any:
    if isinstance(obj, Path):
        return str(obj)
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        return float(obj)
    if isinstance(obj, (np.ndarray,)):
        return obj.tolist()
    if isinstance(obj, dict):
        return {str(k): to_jsonable(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [to_jsonable(v) for v in obj]
    return obj


# ============================================================
# PROJECT ROOT DISCOVERY
# ============================================================
def find_project_root(start: Optional[Path] = None) -> Path:
    """Find the QEG project root robustly for Spyder or terminal runs.

    Priority order:
    1) explicit function argument,
    2) first CLI argument if it is an existing directory,
    3) QEG_ROOT environment variable,
    4) current working directory / script directory ancestry,
    5) canonical Dakini path,
    6) script directory fallback.

    Explicit roots are respected directly. This lets the user run:

        python3 Stage-7D_v2_friedmann_appendix_polishing.py /path/to/project

    or set:

        export QEG_ROOT=/path/to/project
    """
    if start is not None:
        return start.resolve()

    if len(sys.argv) > 1:
        possible = Path(sys.argv[1]).expanduser()
        if possible.exists() and possible.is_dir():
            return possible.resolve()

    env_root = os.environ.get("QEG_ROOT", "").strip()
    if env_root:
        possible = Path(env_root).expanduser()
        if possible.exists() and possible.is_dir():
            return possible.resolve()

    candidates: List[Path] = []
    candidates.append(Path.cwd().resolve())
    script_path = Path(__file__).resolve() if "__file__" in globals() else None
    if script_path is not None:
        candidates.append(script_path.parent)

    canonical = Path("/home/dakini/Downloads/010-Quantum_Emergent_Gravity")
    if canonical.exists():
        candidates.insert(0, canonical)

    marker_dirs = [
        "metric_stage_7C_outputs",
        "metric_stage_7D_outputs",
        "metric_stage_6Y_outputs",
        "metric_stage_6P_outputs",
    ]

    for base in candidates:
        cur = base
        for _ in range(10):
            if cur == cur.parent:
                break
            if cur.name == "010-Quantum_Emergent_Gravity":
                return cur
            if any((cur / marker).exists() for marker in marker_dirs):
                return cur
            cur = cur.parent

    # Conservative fallback: if launched from a script file, use the script
    # directory; otherwise use current directory.
    if script_path is not None:
        return script_path.parent
    return Path.cwd().resolve()


# ============================================================
# INPUT INVENTORY
# ============================================================
def should_skip(path: Path) -> bool:
    sp = str(path).lower()
    return any(pat.lower() in sp for pat in SKIP_DIR_PATTERNS)


def file_is_relevant(path: Path) -> bool:
    name = path.name.lower()
    parent = str(path.parent).lower()
    if path.suffix.lower() not in SUPPORTED_INPUT_EXTENSIONS:
        return False
    if should_skip(path):
        return False
    # Prefer Stage-7D / Friedmann / age-related outputs, but include nearby
    # named files if they are already in a Stage-7D output folder.
    haystack = name + " " + parent
    return any(p in haystack for p in INPUT_NAME_PATTERNS)


def discover_input_files(root: Path) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    search_roots = [
        root / "metric_stage_7D_outputs",
        root / "metric_stage_7C_outputs",
        root / "metric_stage_7A_outputs",
        root / "metric_stage_7B_outputs",
    ]
    # Include root-level files only if relevant by name.
    for sr in search_roots:
        if not sr.exists():
            continue
        for p in sr.rglob("*"):
            if p.is_file() and file_is_relevant(p):
                rows.append({
                    "path": str(p),
                    "relative_path": str(p.relative_to(root)) if p.is_relative_to(root) else str(p),
                    "name": p.name,
                    "suffix": p.suffix.lower(),
                    "size_bytes": p.stat().st_size,
                })
    # Also search root for immediate Stage-7D files.
    for p in root.glob("*"):
        if p.is_file() and file_is_relevant(p):
            rows.append({
                "path": str(p),
                "relative_path": str(p.relative_to(root)) if p.is_relative_to(root) else str(p),
                "name": p.name,
                "suffix": p.suffix.lower(),
                "size_bytes": p.stat().st_size,
            })
    if not rows:
        return pd.DataFrame(columns=["path", "relative_path", "name", "suffix", "size_bytes"])
    return pd.DataFrame(rows).drop_duplicates("path").sort_values(["relative_path"]).reset_index(drop=True)


# ============================================================
# JSON FLATTENING / LOADING
# ============================================================
def flatten_json(obj: Any, prefix: str = "") -> List[Dict[str, Any]]:
    """Flatten JSON into one-row or multi-row dictionaries.

    Lists of dictionaries become multiple rows. Nested dictionaries are
    flattened with key prefixes. This is intentionally conservative.
    """
    rows: List[Dict[str, Any]] = []

    if isinstance(obj, list):
        if all(isinstance(x, dict) for x in obj):
            for i, item in enumerate(obj):
                flat = {}
                for subrow in flatten_json(item, prefix=""):
                    flat.update(subrow)
                flat["json_list_index"] = i
                rows.append(flat)
        else:
            rows.append({prefix.rstrip("_") or "value": json.dumps(obj)[:1000]})
        return rows

    if isinstance(obj, dict):
        flat: Dict[str, Any] = {}
        complex_items: Dict[str, Any] = {}
        for k, v in obj.items():
            nk = normalize_key(k)
            key = f"{prefix}{nk}" if prefix else nk
            if isinstance(v, dict):
                for subrow in flatten_json(v, prefix=f"{key}_"):
                    flat.update(subrow)
            elif isinstance(v, list) and all(isinstance(x, dict) for x in v):
                complex_items[key] = v
            else:
                flat[key] = v
        if complex_items:
            # Emit one row for the parent summary and one row per list item.
            if flat:
                rows.append(flat.copy())
            for key, vlist in complex_items.items():
                for i, item in enumerate(vlist):
                    child = flat.copy()
                    child[f"{key}_index"] = i
                    for subrow in flatten_json(item, prefix=f"{key}_"):
                        child.update(subrow)
                    rows.append(child)
        else:
            rows.append(flat)
        return rows

    return [{prefix.rstrip("_") or "value": obj}]


def load_candidate_rows(file_inventory: pd.DataFrame) -> pd.DataFrame:
    """Load relevant candidate-like rows from prior outputs."""
    rows: List[Dict[str, Any]] = []
    for _, frow in file_inventory.iterrows():
        p = Path(str(frow["path"]))
        suffix = p.suffix.lower()
        try:
            if suffix == ".csv":
                df = pd.read_csv(p)
                if df.empty:
                    continue
                # Keep all rows, but cap very large text/object columns later.
                for idx, rec in df.iterrows():
                    d = {normalize_key(k): rec[k] for k in df.columns}
                    d["source_file"] = str(p)
                    d["source_relative_path"] = str(frow.get("relative_path", p.name))
                    d["source_row_index"] = int(idx)
                    d["source_kind"] = "csv"
                    rows.append(d)
            elif suffix == ".json":
                with p.open("r", encoding="utf-8", errors="replace") as fh:
                    obj = json.load(fh)
                jrows = flatten_json(obj)
                for idx, d0 in enumerate(jrows):
                    d = {normalize_key(k): v for k, v in d0.items()}
                    d["source_file"] = str(p)
                    d["source_relative_path"] = str(frow.get("relative_path", p.name))
                    d["source_row_index"] = int(idx)
                    d["source_kind"] = "json"
                    rows.append(d)
            elif suffix in {".txt", ".md"}:
                text = p.read_text(encoding="utf-8", errors="replace")
                # Extract numeric lines as weak evidence rows only when the file
                # appears Friedmann/age-related by name.
                numeric_pairs = re.findall(
                    r"(?P<label>[A-Za-z0-9_\-./: ]{3,80})\s*[=:]\s*(?P<value>[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?)",
                    text,
                )
                if numeric_pairs:
                    for idx, (label, value) in enumerate(numeric_pairs):
                        rows.append({
                            "candidate_label": compact_text(label, 120),
                            "candidate_value": safe_float(value),
                            "source_file": str(p),
                            "source_relative_path": str(frow.get("relative_path", p.name)),
                            "source_row_index": idx,
                            "source_kind": "text_numeric_extract",
                            "text_excerpt": compact_text(text[max(0, text.find(label)-120): text.find(label)+240], 360),
                        })
                else:
                    rows.append({
                        "candidate_label": p.stem,
                        "source_file": str(p),
                        "source_relative_path": str(frow.get("relative_path", p.name)),
                        "source_row_index": 0,
                        "source_kind": "text_file_summary",
                        "text_excerpt": compact_text(text, 500),
                    })
        except Exception as exc:
            rows.append({
                "candidate_label": p.name,
                "source_file": str(p),
                "source_relative_path": str(frow.get("relative_path", p.name)),
                "source_row_index": -1,
                "source_kind": f"load_error:{type(exc).__name__}",
                "load_error": str(exc),
            })

    if not rows:
        return pd.DataFrame()
    return pd.DataFrame(rows)


# ============================================================
# COLUMN DETECTION
# ============================================================
def find_first_column(cols: Sequence[str], patterns: Sequence[str]) -> Optional[str]:
    norm_cols = [normalize_key(c) for c in cols]
    for pat in patterns:
        r = re.compile(pat)
        for c, nc in zip(cols, norm_cols):
            if r.search(nc):
                return c
    return None


def detect_columns(df: pd.DataFrame) -> Dict[str, Optional[str]]:
    cols = list(df.columns)
    return {
        "age_gyr": find_first_column(cols, [r"(^|_)age(_|$).*gyr", r"age.*gyr", r"age_of_universe", r"t0.*gyr"]),
        "age_error_abs": find_first_column(cols, [r"absolute.*age.*error", r"abs.*error", r"age.*absolute", r"error.*gyr"]),
        "age_error_pct": find_first_column(cols, [r"percent.*error", r"pct.*error", r"relative.*error", r"age.*pct"]),
        "omega_m": find_first_column(cols, [r"omega_?m", r"omegam", r"matter.*omega", r"matter.*density"]),
        "omega_lambda": find_first_column(cols, [r"omega_?lambda", r"omega_?l", r"lambda.*omega", r"dark.*energy"]),
        "omega_k": find_first_column(cols, [r"omega_?k", r"curvature.*omega", r"curv.*omega", r"k_value", r"curvature"]),
        "candidate_label": find_first_column(cols, [r"candidate.*label", r"candidate.*name", r"scalar.*name", r"quantity", r"observable", r"label", r"name"]),
        "candidate_value": find_first_column(cols, [r"candidate.*value", r"scalar.*value", r"value", r"anchor", r"invariant"]),
        "rank": find_first_column(cols, [r"rank", r"age.*rank"]),
        "verdict": find_first_column(cols, [r"verdict", r"status", r"decision", r"classification"]),
    }


def get_col_value(row: pd.Series, col: Optional[str]) -> Any:
    if col is None or col not in row.index:
        return None
    val = row[col]
    if isinstance(val, float) and math.isnan(val):
        return None
    return val


# ============================================================
# FRIEDMANN AGE RECOMPUTE FOR EXISTING OMEGA ROWS
# ============================================================
def friedmann_age_gyr(omega_m: float, omega_lambda: float, omega_k: float, h: float = 0.674) -> Optional[float]:
    """Compute a simple LambdaCDM age integral for already-existing rows.

    This is used only when prior outputs already contain Omega-like fields.
    It is not used to create new candidates.
    """
    if any(v is None for v in [omega_m, omega_lambda, omega_k]):
        return None
    if not all(math.isfinite(v) for v in [omega_m, omega_lambda, omega_k, h]):
        return None
    # Reject obviously pathological integrals to avoid misleading rows.
    if omega_m < -5 or omega_lambda < -5 or abs(omega_k) > 10:
        return None
    a = np.linspace(1e-5, 1.0, 20000)
    E2 = omega_m / a**3 + omega_k / a**2 + omega_lambda
    if np.any(E2 <= 0) or np.any(~np.isfinite(E2)):
        return None
    integrand = 1.0 / (a * np.sqrt(E2))
    integral = float(np.trapezoid(integrand, a))
    return HUBBLE_TIME_GYR_FACTOR / h * integral


# ============================================================
# ADMISSIBILITY CLASSIFIER
# ============================================================
INTERNAL_MEANING_TERMS = [
    "qeg",
    "rho",
    "kappa",
    "curv",
    "density",
    "early_central",
    "early",
    "central",
    "bulk",
    "boundary",
    "operator",
    "recursive",
    "transport",
    "entropy",
    "lowk",
    "low_k",
    "stage6",
    "stage_6",
    "stage7",
    "stage_7",
    "bari",
    "nufit",
    "valencia",
]

QUARANTINE_TERMS = [
    "boolean",
    "flag",
    "count",
    "n_file",
    "nfiles",
    "num_files",
    "snippet",
    "keyword",
    "inventory",
    "source_count",
    "rows_scanned",
    "candidate_count",
    "rank_only",
    "manual_anchor",
]

EXTERNAL_SELECTION_TERMS = [
    "pdg",
    "planck",
    "lcdm",
    "lambda_cdm",
    "friedmann_target",
    "age_target",
    "observed_age",
    "external",
    "h0_locked",
]

CLOSURE_TERMS = [
    "closure",
    "inferred_lambda",
    "lambda_closure",
    "omega_lambda_closure",
    "closure_lambda",
    "absorbs_error",
]


@dataclass
class CandidateAssessment:
    source_relative_path: str
    source_row_index: int
    source_kind: str
    candidate_label: str
    candidate_value: Optional[float]
    omega_m: Optional[float]
    omega_lambda: Optional[float]
    omega_k: Optional[float]
    age_gyr: Optional[float]
    age_error_gyr: Optional[float]
    age_error_pct: Optional[float]
    admissibility_score: float
    classification: str
    appendix_status: str
    reason: str
    flags: str
    text_excerpt: str


def assess_candidate(row: pd.Series, colmap: Dict[str, Optional[str]]) -> CandidateAssessment:
    text = stringify_record(row.to_dict()).lower()

    label_val = get_col_value(row, colmap.get("candidate_label"))
    if label_val is None:
        label_val = get_col_value(row, "candidate_label" if "candidate_label" in row.index else None)
    candidate_label = compact_text(label_val if label_val is not None else row.get("source_relative_path", "candidate"), 180)

    candidate_value = safe_float(get_col_value(row, colmap.get("candidate_value")))
    if candidate_value is None and "candidate_value" in row.index:
        candidate_value = safe_float(row.get("candidate_value"))

    omega_m = safe_float(get_col_value(row, colmap.get("omega_m")))
    omega_lambda = safe_float(get_col_value(row, colmap.get("omega_lambda")))
    omega_k = safe_float(get_col_value(row, colmap.get("omega_k")))

    age_gyr = safe_float(get_col_value(row, colmap.get("age_gyr")))
    if age_gyr is None and all(v is not None for v in [omega_m, omega_lambda, omega_k]):
        age_gyr = friedmann_age_gyr(float(omega_m), float(omega_lambda), float(omega_k), LOCKED_REFERENCES["h"])

    age_error_gyr = safe_float(get_col_value(row, colmap.get("age_error_abs")))
    if age_error_gyr is None and age_gyr is not None:
        age_error_gyr = abs(age_gyr - LOCKED_REFERENCES["age_universe_gyr"])

    age_error_pct = safe_float(get_col_value(row, colmap.get("age_error_pct")))
    if age_error_pct is None and age_error_gyr is not None:
        age_error_pct = 100.0 * age_error_gyr / LOCKED_REFERENCES["age_universe_gyr"]

    flags: List[str] = []
    score = 5.0

    # Positive admissibility features.
    if any(term in text for term in INTERNAL_MEANING_TERMS):
        score += 1.5
        flags.append("internal_qeg_semantics_present")
    else:
        score -= 1.0
        flags.append("weak_or_missing_internal_semantics")

    if any(term in text for term in ["bari", "nufit", "valencia", "lineage", "family"]):
        score += 1.0
        flags.append("lineage_or_family_language_present")
    else:
        flags.append("lineage_not_explicit")

    if omega_lambda is not None and omega_lambda >= 0:
        score += 0.7
        flags.append("nonnegative_lambda_like_closure")
    if omega_k is not None and abs(omega_k) <= 0.05:
        score += 0.8
        flags.append("small_curvature_like_value")
    elif omega_k is not None and abs(omega_k) <= 1.0:
        score += 0.2
        flags.append("moderate_curvature_like_value")
    if omega_m is not None and 0 <= omega_m <= 1:
        score += 0.5
        flags.append("matter_like_value_in_unit_interval")

    # Age proximity is deliberately weak evidence.
    if age_error_pct is not None:
        if age_error_pct <= 1.0:
            score += 0.5
            flags.append("age_close_within_1pct_weak_bonus_only")
        elif age_error_pct <= 5.0:
            score += 0.2
            flags.append("age_close_within_5pct_weak_bonus_only")
        else:
            flags.append("age_not_close_or_not_primary")

    # Quarantine / penalty features.
    if omega_lambda is not None and omega_lambda < 0:
        score -= 4.0
        flags.append("negative_lambda_quarantine")
    if omega_k is not None and abs(omega_k) > 1.0:
        score -= 3.0
        flags.append("extreme_curvature_quarantine")
    if any(term in text for term in QUARANTINE_TERMS):
        score -= 2.0
        flags.append("boolean_count_inventory_or_manual_artifact_risk")
    if any(term in text for term in EXTERNAL_SELECTION_TERMS):
        score -= 2.0
        flags.append("external_selection_language_risk")
    if any(term in text for term in CLOSURE_TERMS):
        score -= 1.2
        flags.append("closure_artifact_risk")

    # Values equal to 0/1 can be OK only if not flag/count-like.
    if candidate_value in {0.0, 1.0} and any(term in text for term in ["flag", "boolean", "true", "false", "count"]):
        score -= 2.5
        flags.append("boolean_scalar_not_physical")

    hard_quarantine_flags = {
        "negative_lambda_quarantine",
        "extreme_curvature_quarantine",
        "boolean_scalar_not_physical",
    }
    has_hard_quarantine = bool(hard_quarantine_flags.intersection(flags))

    if has_hard_quarantine:
        classification = "QUARANTINE"
        appendix_status = "NUMERICALLY_OR_FORMALLY_INTERESTING_BUT_NOT_ALLOWED_AS_EMPHASIZED_APPENDIX_EVIDENCE"
    elif score >= 7.0:
        classification = "APPENDIX_ALLOWED"
        appendix_status = "APPENDIX_CANDIDATE_NOT_CLAIM_GRADE"
    elif score >= 5.0:
        classification = "REVIEW_ALLOWED"
        appendix_status = "REVIEW_ONLY_APPENDIX_BACKGROUND"
    else:
        classification = "QUARANTINE"
        appendix_status = "QUARANTINED_OR_LOW_ADMISSIBILITY"

    # Plain-language reason.
    reason_parts = []
    if "internal_qeg_semantics_present" in flags:
        reason_parts.append("contains internal QEG semantic anchors")
    else:
        reason_parts.append("internal QEG meaning is weak or absent")
    if "small_curvature_like_value" in flags:
        reason_parts.append("small curvature-like value is physically admissible as comparison bookkeeping")
    if "negative_lambda_quarantine" in flags:
        reason_parts.append("negative Lambda-like closure is quarantined")
    if "closure_artifact_risk" in flags:
        reason_parts.append("closure-derived structure may absorb the error")
    if "age_close_within_1pct_weak_bonus_only" in flags:
        reason_parts.append("age proximity is noted but not promotional")
    if not reason_parts:
        reason_parts.append("classified by guardrail score")

    return CandidateAssessment(
        source_relative_path=str(row.get("source_relative_path", "")),
        source_row_index=int(row.get("source_row_index", -1)) if safe_float(row.get("source_row_index", None)) is not None else -1,
        source_kind=str(row.get("source_kind", "")),
        candidate_label=candidate_label,
        candidate_value=candidate_value,
        omega_m=omega_m,
        omega_lambda=omega_lambda,
        omega_k=omega_k,
        age_gyr=age_gyr,
        age_error_gyr=age_error_gyr,
        age_error_pct=age_error_pct,
        admissibility_score=round(float(score), 3),
        classification=classification,
        appendix_status=appendix_status,
        reason="; ".join(reason_parts),
        flags=";".join(flags),
        text_excerpt=compact_text(str(row.get("text_excerpt", "")) or stringify_record(row.to_dict()), 500),
    )


# ============================================================
# CANONICAL CORRIDOR ROWS FROM STAGE-7D PACKAGE
# ============================================================
def canonical_corridor_rows() -> pd.DataFrame:
    """Create the fixed Stage-7D corridor rows from the transition package.

    These are not newly searched candidates. They are the preserved appendix
    corridor stated in the Stage-7D transition package.
    """
    rows = [
        {
            "corridor_label": "meaningful_stable_anchor_corridor",
            "omega_m_like_anchor": 0.317696,
            "omega_k_like_anchor": -0.0095,
            "omega_lambda_like_closure": 1.0 - 0.317696 - (-0.0095),
            "corridor_status": "APPENDIX_AUDIT_CANDIDATE_NOT_CLAIM_GRADE",
            "interpretation": "Stable matter-like QEG anchor plus small negative curvature-like correction; Lambda is positive closure; use only as comparison bookkeeping.",
        },
        {
            "corridor_label": "small_curvature_single_substitution_class",
            "omega_m_like_anchor": LOCKED_REFERENCES["Omega_m"],
            "omega_k_like_anchor": -9.22029e-05,
            "omega_lambda_like_closure": LOCKED_REFERENCES["Omega_Lambda"],
            "corridor_status": "CURVATURE_COMPATIBILITY_SIGNAL_APPENDIX_ALLOWED_NOT_AGE_DERIVATION",
            "interpretation": "Near-zero QEG curvature-like scalar does not disrupt locked-reference Friedmann age; not independent age derivation.",
        },
    ]
    df = pd.DataFrame(rows)
    ages = []
    for _, r in df.iterrows():
        age = friedmann_age_gyr(float(r["omega_m_like_anchor"]), float(r["omega_lambda_like_closure"]), float(r["omega_k_like_anchor"]), LOCKED_REFERENCES["h"])
        ages.append(age)
    df["age_gyr_locked_reference_integral"] = ages
    df["age_error_gyr_vs_locked_reference"] = df["age_gyr_locked_reference_integral"].apply(
        lambda x: None if x is None else abs(float(x) - LOCKED_REFERENCES["age_universe_gyr"])
    )
    df["note"] = "Age recompute is locked-reference appendix bookkeeping only; not a QEG age derivation."
    return df


# ============================================================
# PROMOTION GATE TABLE
# ============================================================
def promotion_gate_table() -> pd.DataFrame:
    rows = [
        ("internal_time_or_evolution_surrogate", "QEG produces a time-ordering/evolution parameter internally, not from external chronology or cosmological fitting.", "NOT_SATISFIED_IN_STAGE_7D"),
        ("adversarial_stability", "Survives forward/reverse, shuffled-order nulls, inverse/adjoint tests, family separation, perturbation, and ablation.", "NOT_SATISFIED_IN_STAGE_7D"),
        ("sector_coupling", "Same surrogate couples to early/boundary, central/bulk, rho, kappa, low-k, and recursive transport operators.", "NOT_SATISFIED_IN_STAGE_7D"),
        ("density_curvature_evolution_law", "Internal continuity-like, scale-factor-like, redistribution, expansion, or focusing relation appears.", "NOT_SATISFIED_IN_STAGE_7D"),
        ("no_external_selection", "External constants used only after internal QEG quantities are frozen.", "ENFORCED_AS_GUARDRAIL"),
        ("multi_channel_support", "Same internal surrogate organizes at least three evidence channels.", "NOT_SATISFIED_IN_STAGE_7D"),
        ("structural_friedmann_proximity", "More than age matching: scale-factor, Hubble-like rate, continuity equation, equation-of-state, curvature-density, Raychaudhuri/focusing, or lapse/foliation analogue.", "NOT_SATISFIED_IN_STAGE_7D"),
    ]
    return pd.DataFrame(rows, columns=["promotion_condition", "required_evidence", "stage7D_status"])


# ============================================================
# TEXT OUTPUTS
# ============================================================
def write_forbidden_claims(path: Path) -> None:
    text = """# Stage-7D v2 forbidden claims

The Friedmann / GR-adjacent appendix branch may not use any of the following claims:

- QEG derives the age of the universe.
- QEG derives the Friedmann equations.
- QEG derives cosmic time.
- QEG derives general relativity.
- QEG predicts Omega_m.
- QEG predicts Omega_Lambda or dark energy.
- QEG predicts Omega_k or spatial curvature.
- QEG proves spacetime emergence.
- Age matching alone upgrades a QEG witness.
- External PDG / Planck / LambdaCDM / Friedmann constants select or promote internal QEG observables.

Allowed label:

```text
GR_ADJACENT_APPENDIX_COMPARISON_WITH_PROMOTION_GATE
```

Allowed wording:

```text
The Friedmann branch is a locked-constant GR-adjacent comparison in which frozen QEG density-like and curvature-like invariants are inserted into standard cosmological age relations. It is suggestive comparison bookkeeping only, not a derivation of cosmic time, general relativity, or cosmological parameters.
```
"""
    path.write_text(text, encoding="utf-8")


def write_appendix_text(path: Path) -> None:
    text = """# Appendix draft: Friedmann / GR-adjacent comparison branch

## Status

This appendix records a controlled Friedmann / GR-adjacent comparison branch. The branch is retained because the Friedmann equations are the standard cosmological setting in which density, curvature, expansion, and cosmic time meet in a single formal structure.

QEG has internally generated density-like and curvature-like objects, including rho-like response fields, kappa-like curvature fields, nonlocal kappa -> rho operator structure, early/boundary and central/bulk sectors, two-sector mass partitions, recursive transport, and time/arrow candidates. It is therefore legitimate to ask whether frozen QEG invariants fall into a Friedmann-compatible numerical corridor.

The appendix does not ask whether QEG derives the Friedmann equations.

## Procedure

The comparison is performed only after QEG quantities have already been generated and frozen by the internal pipeline. External cosmological constants are locked references used for comparison only. They are not used to select, orient, fit, score-upgrade, or create internal QEG witnesses.

Candidate rows are classified by physical admissibility rather than by age error alone. The score penalizes negative Lambda-like closure, extreme curvature, Boolean/count-like quantities, missing lineage, external-selection language, and pure closure artifacts. Age proximity is recorded only as weak comparison evidence.

## Meaningful corridor

The meaningful corridor is not the best raw age match. The corridor retained for appendix discussion uses stable internal QEG anchors, especially a matter-like two-sector separation near 0.318 together with a small curvature-like correction and positive Lambda-like closure. This gives an age close to the observed cosmic age under locked external constants.

This is suggestive because the QEG quantities involved already had internal meaning before the Friedmann comparison. It is not a derivation of cosmic time or cosmological parameters.

## Quarantined rows

Rows are quarantined when they require negative Lambda-like closure, extreme curvature, count/Boolean artifacts, theta-coordinate artifacts, external constants for selection, or closure-derived error absorption. Numerically close rows may therefore be rejected when their physical admissibility is poor.

## Promotion gate

The Friedmann appendix may be promoted only if a later QEG stage finds an internally generated time/evolution surrogate that survives adversarial tests and couples coherently to QEG sectors, density-curvature evolution, low-k structure, entropy/operator directionality, and recursive transport. Age matching alone is explicitly non-promotional.

## Recommended main-text wording

A controlled Friedmann comparison is reported in Appendix B. It is treated as a locked-constant GR-adjacent benchmark, not as a derivation of cosmic time.
"""
    path.write_text(text, encoding="utf-8")


def write_ledger_note(path: Path, summary: Dict[str, Any]) -> None:
    text = f"""============================================================
STAGE-7D v2 LEDGER NOTE
Project: Quantum-Emergent Gravity
Script : {SCRIPT_NAME}
Status : COMPLETED
============================================================

VERDICT
-------
{summary['verdict']}

INTERPRETATION
--------------
Stage-7D v2 polishes the Friedmann / GR-adjacent branch as appendix
material only. It does not create a new broad scalar search, does not
promote age matching, and does not change the main Stage-7C evidence
hierarchy.

INPUTS
------
Input files discovered       : {summary['input_files_discovered']}
Candidate-like rows loaded   : {summary['candidate_rows_loaded']}
Assessment rows written      : {summary['assessment_rows']}
Appendix candidate rows      : {summary['appendix_candidate_rows']}
Review-only rows             : {summary['review_allowed_rows']}
Quarantined rows             : {summary['quarantined_rows']}

LOCKED REFERENCE POLICY
-----------------------
External cosmological constants were treated as locked comparison
references only. They were not used to generate or select QEG witnesses.

STAGE-7D DECISION
-----------------
The Friedmann branch remains:

    GR_ADJACENT_APPENDIX_COMPARISON_WITH_PROMOTION_GATE

It is retained because internally generated QEG density-like and
curvature-like quantities fall into suggestive age corridors under
locked Friedmann comparison. It is not claim-grade evidence of cosmic
time, GR, or cosmological parameters.

NEXT ACTION
-----------
Proceed to Stage-7E: Pipeline Compression, Repository Freeze, and
Manuscript Asset Curation.

============================================================
END LEDGER NOTE
============================================================
"""
    path.write_text(text, encoding="utf-8")


def write_ascii_transition_package(path: Path, summary: Dict[str, Any]) -> None:
    text = f"""============================================================
ASCII TRANSITION PACKAGE
Project: Quantum-Emergent Gravity
Stage: Stage-7D v2
Working Title: Friedmann / GR-Adjacent Appendix Polishing
Status: COMPLETED
============================================================

PURPOSE
-------
Stage-7D v2 closed the Friedmann / GR-adjacent appendix branch by
rereading prior Friedmann outputs, applying admissibility guardrails,
writing appendix-facing tables, and freezing claim language.

CORE DECISION
-------------
Stage-7D is NOT a main-pipeline derivation stage.
It is:

    FRIEDMANN_GR_ADJACENT_APPENDIX_POLISHING_AND_PROMOTION_GATE

It may support appendix text and comparison bookkeeping.
It may not claim derivation of Friedmann equations, cosmic time, GR,
Omega_m, Omega_Lambda, or Omega_k.

SCRIPT OUTPUTS
--------------
Output folder:

    {summary['output_dir']}

Required outputs were written:

    stage7D_v2_summary.json
    stage7D_v2_ledger_note.txt
    stage7D_v2_appendix_candidate_table.csv
    stage7D_v2_quarantined_candidate_table.csv
    stage7D_v2_promotion_gate_table.csv
    stage7D_v2_forbidden_claims.md
    stage7D_v2_appendix_text_draft.md
    stage7D_v2_ascii_transition_package.txt

Optional outputs were also written:

    stage7D_v2_age_corridor_table.csv
    stage7D_v2_density_curvature_pair_audit.csv
    stage7D_v2_physical_admissibility_scores.csv
    stage7D_v2_input_file_inventory.csv

VERDICT
-------
{summary['verdict']}

RESULT SUMMARY
--------------
Input files discovered       : {summary['input_files_discovered']}
Candidate-like rows loaded   : {summary['candidate_rows_loaded']}
Appendix candidate rows      : {summary['appendix_candidate_rows']}
Review-only rows             : {summary['review_allowed_rows']}
Quarantined rows             : {summary['quarantined_rows']}

CLAIM STATUS
------------
Allowed:

    GR-adjacent appendix comparison
    locked-constant benchmark
    physically suggestive corridor
    promotion gate

Forbidden:

    QEG derives cosmic time
    QEG derives Friedmann equations
    QEG derives GR
    QEG predicts Omega_m/Omega_Lambda/Omega_k
    age matching alone is promotional

NEXT STAGE
----------
Proceed to Stage-7E:

    Pipeline Compression, Repository Freeze, and Manuscript Asset Curation

============================================================
END STAGE-7D v2 ASCII TRANSITION PACKAGE
============================================================
"""
    path.write_text(text, encoding="utf-8")


# ============================================================
# MAIN
# ============================================================
def main() -> None:
    root = find_project_root()
    outdir = root / OUTPUT_REL
    mkdirp(outdir)

    print("=" * 60)
    print("Stage-7D v2: Friedmann Appendix Polishing")
    print("=" * 60)
    print(f"Project root: {root}")
    print(f"Output dir  : {outdir}")

    inventory = discover_input_files(root)
    inventory_path = outdir / "stage7D_v2_input_file_inventory.csv"
    inventory.to_csv(inventory_path, index=False)
    print(f"Input files discovered: {len(inventory)}")

    candidates_df = load_candidate_rows(inventory)
    print(f"Candidate-like rows loaded: {len(candidates_df)}")

    assessment_rows: List[CandidateAssessment] = []
    if not candidates_df.empty:
        colmap = detect_columns(candidates_df)
        for _, row in candidates_df.iterrows():
            assessment_rows.append(assess_candidate(row, colmap))
    assessment_df = pd.DataFrame([asdict(x) for x in assessment_rows])

    # Always write stable corridor rows from the Stage-7D package.
    corridor_df = canonical_corridor_rows()

    if assessment_df.empty:
        # Create a minimal review row so output tables remain usable.
        assessment_df = pd.DataFrame([
            asdict(CandidateAssessment(
                source_relative_path="NO_PRIOR_STAGE7D_OUTPUTS_FOUND",
                source_row_index=-1,
                source_kind="synthetic_status_row",
                candidate_label="No previous Friedmann tables discovered; only canonical Stage-7D corridor rows written.",
                candidate_value=None,
                omega_m=None,
                omega_lambda=None,
                omega_k=None,
                age_gyr=None,
                age_error_gyr=None,
                age_error_pct=None,
                admissibility_score=0.0,
                classification="REVIEW_ALLOWED",
                appendix_status="NO_PRIOR_TABLES_FOUND_CANONICAL_CORRIDOR_ONLY",
                reason="No previous Stage-7D output tables found in project tree; script still writes guardrails and corridor table.",
                flags="no_prior_outputs_found",
                text_excerpt="",
            ))
        ])

    # Sort rows: admissible first, then by score descending, then age error.
    sort_cols = ["admissibility_score"]
    assessment_df = assessment_df.sort_values(sort_cols, ascending=False, kind="stable").reset_index(drop=True)

    appendix_df = assessment_df[assessment_df["classification"].isin(["APPENDIX_ALLOWED"])].copy()
    review_df = assessment_df[assessment_df["classification"].isin(["REVIEW_ALLOWED"])].copy()
    quarantine_df = assessment_df[assessment_df["classification"].isin(["QUARANTINE"])].copy()

    # If no appendix rows are found from prior outputs, keep the canonical
    # corridor as the appendix-facing material and leave loaded rows as review/quarantine.
    appendix_out = appendix_df.copy()
    if appendix_out.empty:
        appendix_out = pd.DataFrame([
            {
                "source_relative_path": "Stage-7D_ASCII_transition_package",
                "source_row_index": 0,
                "source_kind": "canonical_corridor_from_transition_package",
                "candidate_label": r["corridor_label"],
                "candidate_value": r["omega_m_like_anchor"],
                "omega_m": r["omega_m_like_anchor"],
                "omega_lambda": r["omega_lambda_like_closure"],
                "omega_k": r["omega_k_like_anchor"],
                "age_gyr": r["age_gyr_locked_reference_integral"],
                "age_error_gyr": r["age_error_gyr_vs_locked_reference"],
                "age_error_pct": None if pd.isna(r["age_error_gyr_vs_locked_reference"]) else 100.0 * float(r["age_error_gyr_vs_locked_reference"]) / LOCKED_REFERENCES["age_universe_gyr"],
                "admissibility_score": 7.0,
                "classification": "APPENDIX_ALLOWED",
                "appendix_status": r["corridor_status"],
                "reason": r["interpretation"],
                "flags": "canonical_stage7d_corridor;not_claim_grade;locked_reference_only",
                "text_excerpt": r["note"],
            }
            for _, r in corridor_df.iterrows()
        ])

    # Pair audit: rows with at least two Omega-like fields or rho/kappa semantics.
    pair_mask = assessment_df["flags"].str.contains("small_curvature|matter_like|internal_qeg", case=False, na=False)
    pair_audit_df = assessment_df[pair_mask].copy()

    # Write all tables.
    assessment_df.to_csv(outdir / "stage7D_v2_physical_admissibility_scores.csv", index=False)
    appendix_out.to_csv(outdir / "stage7D_v2_appendix_candidate_table.csv", index=False)
    quarantine_df.to_csv(outdir / "stage7D_v2_quarantined_candidate_table.csv", index=False)
    promotion_gate_table().to_csv(outdir / "stage7D_v2_promotion_gate_table.csv", index=False)
    corridor_df.to_csv(outdir / "stage7D_v2_age_corridor_table.csv", index=False)
    pair_audit_df.to_csv(outdir / "stage7D_v2_density_curvature_pair_audit.csv", index=False)

    # Text outputs.
    write_forbidden_claims(outdir / "stage7D_v2_forbidden_claims.md")
    write_appendix_text(outdir / "stage7D_v2_appendix_text_draft.md")

    verdict = "B_APPENDIX_READY_GR_ADJACENT_COMPARISON_POLISHED_WITH_GUARDRAILS"
    summary = {
        "project": "Quantum-Emergent Gravity",
        "stage": "Stage-7D v2",
        "script": SCRIPT_NAME,
        "verdict": verdict,
        "project_root": str(root),
        "output_dir": str(outdir),
        "locked_references": LOCKED_REFERENCES,
        "input_files_discovered": int(len(inventory)),
        "candidate_rows_loaded": int(len(candidates_df)),
        "assessment_rows": int(len(assessment_df)),
        "appendix_candidate_rows": int(len(appendix_out)),
        "review_allowed_rows": int(len(review_df)),
        "quarantined_rows": int(len(quarantine_df)),
        "policy": {
            "no_new_broad_scalar_search": True,
            "no_promotion_from_age_matching_alone": True,
            "external_constants_locked_reference_only": True,
            "main_stage7c_hierarchy_unchanged": True,
            "appendix_only": True,
        },
        "recommended_next_action": "Proceed to Stage-7E: Pipeline Compression, Repository Freeze, and Manuscript Asset Curation.",
    }

    with (outdir / "stage7D_v2_summary.json").open("w", encoding="utf-8") as fh:
        json.dump(to_jsonable(summary), fh, indent=2, sort_keys=True)

    write_ledger_note(outdir / "stage7D_v2_ledger_note.txt", summary)
    write_ascii_transition_package(outdir / "stage7D_v2_ascii_transition_package.txt", summary)

    print("Verdict:", verdict)
    print(f"Assessment rows      : {len(assessment_df)}")
    print(f"Appendix rows        : {len(appendix_out)}")
    print(f"Review-only rows     : {len(review_df)}")
    print(f"Quarantined rows     : {len(quarantine_df)}")
    print("Primary outputs:")
    for name in [
        "stage7D_v2_summary.json",
        "stage7D_v2_ledger_note.txt",
        "stage7D_v2_appendix_candidate_table.csv",
        "stage7D_v2_quarantined_candidate_table.csv",
        "stage7D_v2_promotion_gate_table.csv",
        "stage7D_v2_forbidden_claims.md",
        "stage7D_v2_appendix_text_draft.md",
        "stage7D_v2_ascii_transition_package.txt",
    ]:
        print("  -", outdir / name)
    print("=" * 60)


if __name__ == "__main__":
    main()
