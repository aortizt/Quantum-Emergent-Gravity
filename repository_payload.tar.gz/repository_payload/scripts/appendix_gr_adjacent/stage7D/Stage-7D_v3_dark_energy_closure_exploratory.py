#!/usr/bin/env python3
"""
Stage-7D v3: Dark-Energy / Lambda Closure Exploratory Audit
Project: Quantum-Emergent Gravity
Author: Arturo Ortiz-Tapia + ChatGPT assistant
Build date: 2026-06-02

Purpose
-------
Appendix-only exploratory script that asks whether the already-frozen
Stage-7D v2 Friedmann / GR-adjacent outputs contain Lambda-like or
dark-energy-like proportion signals.

This script DOES NOT claim that QEG derives dark energy, Omega_Lambda,
LambdaCDM, cosmic acceleration, GR, or cosmic time. It only audits whether
existing Stage-7D v2 outputs contain comparison-bookkeeping proximity to
locked PDG/Planck-style references.

Core rule
---------
Omega_Lambda-like quantities are treated as either:
    (a) locked external references, or
    (b) closure quantities induced by already-frozen QEG matter-like and
        curvature-like anchors.
They are not treated as independently discovered physical constants.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd

SCRIPT_NAME = "Stage-7D_v3_dark_energy_closure_exploratory.py"
STAGE = "Stage-7D v3"
VERDICT = "B_EXPLORATORY_LAMBDA_CLOSURE_PROXIMITY_PRESENT_APPENDIX_ONLY"

DEFAULT_LOCKED_REFERENCES = {
    "Omega_m": 0.315,
    "Omega_Lambda": 0.685,
    "Omega_k": 0.0007,
    "H0_km_s_Mpc": 67.4,
    "h": 0.674,
    "age_universe_gyr": 13.797,
    "reference_label": "PDG/Planck-style flat LambdaCDM comparison constants, locked for appendix bookkeeping only",
    "policy": "Locked external constants may compare only after internal QEG quantities are frozen",
}

FORBIDDEN_CLAIMS = [
    "QEG derives dark energy.",
    "QEG derives Omega_Lambda.",
    "QEG predicts the cosmological constant.",
    "QEG derives cosmic acceleration.",
    "QEG derives LambdaCDM.",
    "QEG derives the Friedmann equations.",
    "QEG derives the age of the universe.",
    "QEG derives general relativity.",
    "A Lambda-like closure quantity is an independent QEG discovery of dark energy.",
    "External PDG / Planck / LambdaCDM constants select or promote QEG observables.",
]

ALLOWED_WORDING = (
    "This Stage-7D v3 audit records whether frozen QEG matter-like and "
    "curvature-like anchors imply a Lambda-like closure proportion near the "
    "locked external Omega_Lambda reference. The result is comparison "
    "bookkeeping only. It is not a derivation of dark energy, cosmic "
    "acceleration, LambdaCDM, GR, or cosmic time."
)


def find_project_root(start: Optional[str]) -> Path:
    """Find a plausible QEG project root, or use the supplied path."""
    if start:
        p = Path(start).expanduser().resolve()
        return p
    cwd = Path.cwd().resolve()
    for candidate in [cwd] + list(cwd.parents):
        if (candidate / "metric_stage_7D_outputs").exists() or "Quantum_Emergent_Gravity" in candidate.name:
            return candidate
    return cwd


def find_v2_dir(project_root: Path, supplied: Optional[str]) -> Path:
    """Locate the Stage-7D v2 output directory."""
    if supplied:
        return Path(supplied).expanduser().resolve()
    candidates = [
        project_root / "metric_stage_7D_outputs" / "friedmann_appendix_polishing_v2",
        project_root / "friedmann_appendix_polishing_v2",
        Path.cwd().resolve(),
        Path("/mnt/data"),
    ]
    for c in candidates:
        if (c / "stage7D_v2_summary.json").exists() or (c / "stage7D_v2_age_corridor_table.csv").exists():
            return c
    return candidates[0]


def safe_float(x) -> float:
    try:
        if x is None:
            return math.nan
        v = float(x)
        if math.isfinite(v):
            return v
        return math.nan
    except Exception:
        return math.nan


def pct_diff(value: float, ref: float) -> float:
    if not math.isfinite(value) or not math.isfinite(ref) or ref == 0:
        return math.nan
    return abs(value - ref) / abs(ref) * 100.0


def read_locked_references(v2_dir: Path) -> Dict[str, float]:
    refs = dict(DEFAULT_LOCKED_REFERENCES)
    summary_path = v2_dir / "stage7D_v2_summary.json"
    if summary_path.exists():
        try:
            with open(summary_path, "r", encoding="utf-8") as f:
                summary = json.load(f)
            locked = summary.get("locked_references", {})
            for k, v in locked.items():
                refs[k] = v
        except Exception as exc:
            print(f"WARNING: could not read {summary_path}: {exc}")
    return refs


def classify_lambda_row(row: pd.Series, refs: Dict[str, float]) -> str:
    lam = safe_float(row.get("omega_lambda_like_closure", row.get("omega_lambda", math.nan)))
    om = safe_float(row.get("omega_m_like_anchor", row.get("omega_m", math.nan)))
    ok = safe_float(row.get("omega_k_like_anchor", row.get("omega_k", math.nan)))
    lam_ref = safe_float(refs.get("Omega_Lambda", 0.685))
    lam_pct = pct_diff(lam, lam_ref)
    if not math.isfinite(lam):
        return "NO_LAMBDA_VALUE"
    if lam < 0:
        return "NEGATIVE_LAMBDA_CLOSURE_QUARANTINE"
    if lam > 1.25:
        return "EXTREME_LAMBDA_CLOSURE_REVIEW"
    if math.isfinite(lam_pct) and lam_pct <= 1.0:
        return "LAMBDA_CLOSURE_WITHIN_1PCT_REFERENCE_APPENDIX_ONLY"
    if math.isfinite(lam_pct) and lam_pct <= 5.0:
        return "LAMBDA_CLOSURE_WITHIN_5PCT_REFERENCE_APPENDIX_ONLY"
    if math.isfinite(lam_pct) and lam_pct <= 10.0:
        return "LAMBDA_CLOSURE_WITHIN_10PCT_REFERENCE_REVIEW"
    return "LAMBDA_CLOSURE_NOT_CLOSE_TO_REFERENCE"


def build_corridor_lambda_table(v2_dir: Path, refs: Dict[str, float]) -> pd.DataFrame:
    path = v2_dir / "stage7D_v2_age_corridor_table.csv"
    if not path.exists():
        return pd.DataFrame()
    df = pd.read_csv(path)
    lam_ref = safe_float(refs.get("Omega_Lambda", 0.685))
    om_ref = safe_float(refs.get("Omega_m", 0.315))
    ok_ref = safe_float(refs.get("Omega_k", 0.0007))
    ratio_ref = lam_ref / om_ref if om_ref else math.nan
    fraction_ref = lam_ref / (lam_ref + om_ref) if (lam_ref + om_ref) else math.nan

    rows = []
    for _, r in df.iterrows():
        om = safe_float(r.get("omega_m_like_anchor", math.nan))
        ok = safe_float(r.get("omega_k_like_anchor", math.nan))
        lam = safe_float(r.get("omega_lambda_like_closure", math.nan))
        age = safe_float(r.get("age_gyr_locked_reference_integral", math.nan))
        age_err = safe_float(r.get("age_error_gyr_vs_locked_reference", math.nan))
        dark_to_matter = lam / om if math.isfinite(lam) and math.isfinite(om) and om != 0 else math.nan
        dark_fraction_m_plus_lam = lam / (lam + om) if math.isfinite(lam) and math.isfinite(om) and (lam + om) != 0 else math.nan
        closure_sum = om + ok + lam if all(math.isfinite(x) for x in [om, ok, lam]) else math.nan
        rows.append({
            "corridor_label": r.get("corridor_label", ""),
            "omega_m_like_anchor": om,
            "omega_k_like_anchor": ok,
            "omega_lambda_like_closure": lam,
            "locked_omega_lambda_reference": lam_ref,
            "lambda_abs_difference": abs(lam - lam_ref) if math.isfinite(lam) else math.nan,
            "lambda_pct_difference": pct_diff(lam, lam_ref),
            "dark_to_matter_ratio": dark_to_matter,
            "locked_dark_to_matter_ratio": ratio_ref,
            "dark_to_matter_ratio_pct_difference": pct_diff(dark_to_matter, ratio_ref),
            "dark_fraction_among_matter_plus_lambda": dark_fraction_m_plus_lam,
            "locked_dark_fraction_among_matter_plus_lambda": fraction_ref,
            "dark_fraction_pct_difference": pct_diff(dark_fraction_m_plus_lam, fraction_ref),
            "closure_sum_omega_m_plus_lambda_plus_k": closure_sum,
            "closure_sum_difference_from_one": abs(closure_sum - 1.0) if math.isfinite(closure_sum) else math.nan,
            "age_gyr_locked_reference_integral": age,
            "age_error_gyr_vs_locked_reference": age_err,
            "dark_energy_status": classify_lambda_row(pd.Series({
                "omega_lambda_like_closure": lam,
                "omega_m_like_anchor": om,
                "omega_k_like_anchor": ok,
            }), refs),
            "interpretation": r.get("interpretation", ""),
            "note": "Closure audit only: Lambda-like value is induced by frozen matter/curvature anchors, not independently derived.",
        })
    return pd.DataFrame(rows)


def update_top(df_existing: pd.DataFrame, df_new: pd.DataFrame, sort_cols: List[str], ascending: List[bool], n: int) -> pd.DataFrame:
    parts = []
    if df_existing is not None and not df_existing.empty:
        parts.append(df_existing)
    if df_new is not None and not df_new.empty:
        parts.append(df_new)
    if not parts:
        return pd.DataFrame()
    out = pd.concat(parts, ignore_index=True)
    return out.sort_values(sort_cols, ascending=ascending).head(n).reset_index(drop=True)


def audit_pairwise_lambda_candidates(v2_dir: Path, refs: Dict[str, float], output_dir: Path, chunksize: int = 50000) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Chunk-audit large pairwise table for Lambda-like proximity."""
    path = v2_dir / "stage7D_v2_density_curvature_pair_audit.csv"
    if not path.exists():
        return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

    lam_ref = safe_float(refs.get("Omega_Lambda", 0.685))
    age_ref = safe_float(refs.get("age_universe_gyr", 13.797))
    threshold_rows = []
    totals = {
        "rows_seen": 0,
        "numeric_lambda_rows": 0,
        "lambda_nonnegative_rows": 0,
        "lambda_between_0_and_1_rows": 0,
        "review_allowed_rows": 0,
        "quarantine_rows": 0,
    }
    lambda_thresholds = [0.1, 0.5, 1.0, 5.0, 10.0]
    age_thresholds = [0.1, 0.5, 1.0, 5.0, 10.0]
    counts = {(lt, at): 0 for lt in lambda_thresholds for at in age_thresholds}
    counts_lambda_only = {lt: 0 for lt in lambda_thresholds}
    counts_review_lambda_only = {lt: 0 for lt in lambda_thresholds}
    counts_review_lambda_and_age = {(lt, at): 0 for lt in lambda_thresholds for at in age_thresholds}

    top_lambda = pd.DataFrame()
    top_composite = pd.DataFrame()
    top_review = pd.DataFrame()

    for chunk in pd.read_csv(path, chunksize=chunksize, low_memory=False):
        totals["rows_seen"] += len(chunk)
        if "omega_lambda" not in chunk.columns:
            continue
        chunk = chunk.copy()
        for col in ["omega_lambda", "omega_m", "omega_k", "age_gyr", "age_error_pct", "admissibility_score"]:
            if col in chunk.columns:
                chunk[col] = pd.to_numeric(chunk[col], errors="coerce")
        chunk = chunk[chunk["omega_lambda"].notna()].copy()
        if chunk.empty:
            continue
        totals["numeric_lambda_rows"] += len(chunk)
        totals["lambda_nonnegative_rows"] += int((chunk["omega_lambda"] >= 0).sum())
        totals["lambda_between_0_and_1_rows"] += int(((chunk["omega_lambda"] >= 0) & (chunk["omega_lambda"] <= 1)).sum())
        if "classification" in chunk.columns:
            totals["review_allowed_rows"] += int((chunk["classification"] == "REVIEW_ALLOWED").sum())
            totals["quarantine_rows"] += int((chunk["classification"] == "QUARANTINE").sum())
        chunk["lambda_abs_difference"] = (chunk["omega_lambda"] - lam_ref).abs()
        chunk["lambda_pct_difference"] = chunk["lambda_abs_difference"] / abs(lam_ref) * 100.0
        if "age_error_pct" not in chunk.columns or chunk["age_error_pct"].isna().all():
            if "age_gyr" in chunk.columns:
                chunk["age_error_pct"] = (chunk["age_gyr"] - age_ref).abs() / abs(age_ref) * 100.0
            else:
                chunk["age_error_pct"] = np.nan
        # Conservative composite: high admissibility, low Lambda deviation, low age error.
        adm = chunk.get("admissibility_score", pd.Series(np.zeros(len(chunk)), index=chunk.index)).fillna(0)
        agep = chunk.get("age_error_pct", pd.Series(np.zeros(len(chunk)), index=chunk.index)).fillna(999)
        chunk["lambda_exploratory_score"] = adm - 0.12 * chunk["lambda_pct_difference"].fillna(999) - 0.03 * agep
        chunk["lambda_closure_status"] = np.select(
            [
                chunk["omega_lambda"] < 0,
                chunk["lambda_pct_difference"] <= 1.0,
                chunk["lambda_pct_difference"] <= 5.0,
                chunk["lambda_pct_difference"] <= 10.0,
            ],
            [
                "NEGATIVE_LAMBDA_QUARANTINE",
                "LAMBDA_WITHIN_1PCT_REFERENCE_APPENDIX_ONLY",
                "LAMBDA_WITHIN_5PCT_REFERENCE_APPENDIX_ONLY",
                "LAMBDA_WITHIN_10PCT_REFERENCE_REVIEW",
            ],
            default="LAMBDA_NOT_CLOSE_OR_REVIEW",
        )

        for lt in lambda_thresholds:
            lmask = chunk["lambda_pct_difference"] <= lt
            counts_lambda_only[lt] += int(lmask.sum())
            if "classification" in chunk.columns:
                rmask = chunk["classification"] == "REVIEW_ALLOWED"
                counts_review_lambda_only[lt] += int((lmask & rmask).sum())
            for at in age_thresholds:
                amask = chunk["age_error_pct"] <= at
                counts[(lt, at)] += int((lmask & amask).sum())
                if "classification" in chunk.columns:
                    counts_review_lambda_and_age[(lt, at)] += int((lmask & amask & (chunk["classification"] == "REVIEW_ALLOWED")).sum())

        keep_cols = [c for c in [
            "source_relative_path", "source_row_index", "source_kind", "candidate_label", "candidate_value",
            "omega_m", "omega_lambda", "omega_k", "age_gyr", "age_error_gyr", "age_error_pct",
            "admissibility_score", "classification", "appendix_status", "reason", "flags", "text_excerpt",
            "lambda_abs_difference", "lambda_pct_difference", "lambda_exploratory_score", "lambda_closure_status",
        ] if c in chunk.columns]
        slim = chunk[keep_cols].copy()
        top_lambda = update_top(top_lambda, slim, ["lambda_abs_difference", "age_error_pct"], [True, True], 250)
        top_composite = update_top(top_composite, slim, ["lambda_exploratory_score", "lambda_abs_difference"], [False, True], 250)
        if "classification" in slim.columns:
            review = slim[slim["classification"] == "REVIEW_ALLOWED"]
            top_review = update_top(top_review, review, ["lambda_abs_difference", "age_error_pct"], [True, True], 250)

    threshold_records = []
    for lt in lambda_thresholds:
        threshold_records.append({
            "lambda_pct_threshold": lt,
            "age_pct_threshold": math.nan,
            "matching_rows": counts_lambda_only[lt],
            "review_allowed_matching_rows": counts_review_lambda_only[lt],
            "criterion": f"Omega_Lambda within {lt}% of locked reference",
        })
    for lt in lambda_thresholds:
        for at in age_thresholds:
            threshold_records.append({
                "lambda_pct_threshold": lt,
                "age_pct_threshold": at,
                "matching_rows": counts[(lt, at)],
                "review_allowed_matching_rows": counts_review_lambda_and_age[(lt, at)],
                "criterion": f"Omega_Lambda within {lt}% and age within {at}% of locked references",
            })
    threshold_df = pd.DataFrame(threshold_records)
    totals_df = pd.DataFrame([totals])
    # Persist candidate extracts now to avoid holding too much in memory later.
    top_lambda.to_csv(output_dir / "stage7D_v3_pairwise_lambda_nearest_rows.csv", index=False)
    top_composite.to_csv(output_dir / "stage7D_v3_pairwise_lambda_composite_ranked_rows.csv", index=False)
    top_review.to_csv(output_dir / "stage7D_v3_pairwise_lambda_review_allowed_nearest_rows.csv", index=False)
    return threshold_df, totals_df, top_review


def write_text(path: Path, content: str) -> None:
    path.write_text(content, encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description="Stage-7D v3 Lambda/dark-energy closure exploratory audit")
    parser.add_argument("project_root", nargs="?", default=None, help="QEG project root. If omitted, inferred from cwd.")
    parser.add_argument("--v2-dir", default=None, help="Stage-7D v2 output directory. Optional.")
    parser.add_argument("--output-dir", default=None, help="Output directory. Optional.")
    parser.add_argument("--chunksize", type=int, default=50000, help="Chunk size for large CSV audit.")
    args = parser.parse_args()

    project_root = find_project_root(args.project_root)
    v2_dir = find_v2_dir(project_root, args.v2_dir)
    if args.output_dir:
        output_dir = Path(args.output_dir).expanduser().resolve()
    else:
        output_dir = project_root / "metric_stage_7D_outputs" / "dark_energy_lambda_closure_exploratory_v3"
    output_dir.mkdir(parents=True, exist_ok=True)

    refs = read_locked_references(v2_dir)
    lam_ref = safe_float(refs.get("Omega_Lambda", 0.685))
    om_ref = safe_float(refs.get("Omega_m", 0.315))
    ok_ref = safe_float(refs.get("Omega_k", 0.0007))
    age_ref = safe_float(refs.get("age_universe_gyr", 13.797))

    corridor_df = build_corridor_lambda_table(v2_dir, refs)
    if not corridor_df.empty:
        corridor_df.to_csv(output_dir / "stage7D_v3_dark_energy_closure_corridor_table.csv", index=False)
    else:
        pd.DataFrame().to_csv(output_dir / "stage7D_v3_dark_energy_closure_corridor_table.csv", index=False)

    threshold_df, totals_df, top_review = audit_pairwise_lambda_candidates(v2_dir, refs, output_dir, chunksize=args.chunksize)
    threshold_df.to_csv(output_dir / "stage7D_v3_lambda_threshold_counts.csv", index=False)
    totals_df.to_csv(output_dir / "stage7D_v3_lambda_pairwise_audit_totals.csv", index=False)

    # Main corridor interpretation.
    stable_row = None
    if not corridor_df.empty:
        matches = corridor_df[corridor_df["corridor_label"].astype(str).str.contains("meaningful_stable_anchor", case=False, na=False)]
        if not matches.empty:
            stable_row = matches.iloc[0].to_dict()
        else:
            stable_row = corridor_df.iloc[0].to_dict()

    # Compact summary values.
    summary = {
        "project": "Quantum-Emergent Gravity",
        "stage": STAGE,
        "script": SCRIPT_NAME,
        "verdict": VERDICT,
        "project_root": str(project_root),
        "input_v2_dir": str(v2_dir),
        "output_dir": str(output_dir),
        "locked_references": refs,
        "policy": {
            "appendix_only": True,
            "dark_energy_claim_forbidden": True,
            "omega_lambda_derivation_claim_forbidden": True,
            "lambda_closure_is_not_independent_discovery": True,
            "external_constants_locked_reference_only": True,
            "no_promotion_from_lambda_or_age_proximity_alone": True,
        },
        "corridor_rows_written": int(len(corridor_df)),
        "pairwise_lambda_rows_seen": int(totals_df.get("numeric_lambda_rows", pd.Series([0])).iloc[0]) if not totals_df.empty else 0,
        "pairwise_review_allowed_rows_seen": int(totals_df.get("review_allowed_rows", pd.Series([0])).iloc[0]) if not totals_df.empty else 0,
        "stable_anchor_lambda_closure": stable_row,
        "recommended_next_action": "Keep as Stage-7D appendix sub-branch or cite during Stage-7E manuscript curation; do not promote to a physical dark-energy claim.",
    }
    with open(output_dir / "stage7D_v3_dark_energy_lambda_summary.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, sort_keys=True)

    # Ledger note.
    if stable_row:
        stable_lam = stable_row.get("omega_lambda_like_closure", math.nan)
        stable_lam_pct = stable_row.get("lambda_pct_difference", math.nan)
        stable_ratio = stable_row.get("dark_to_matter_ratio", math.nan)
        stable_ratio_pct = stable_row.get("dark_to_matter_ratio_pct_difference", math.nan)
        stable_age = stable_row.get("age_gyr_locked_reference_integral", math.nan)
    else:
        stable_lam = stable_lam_pct = stable_ratio = stable_ratio_pct = stable_age = math.nan

    ledger = f"""============================================================
STAGE-7D v3 LEDGER NOTE
Project: Quantum-Emergent Gravity
Script : {SCRIPT_NAME}
Status : COMPLETED
============================================================

VERDICT
-------
{VERDICT}

PURPOSE
-------
Stage-7D v3 audits the dark-energy / Lambda side of the already completed
Stage-7D v2 Friedmann appendix branch.

It asks whether frozen QEG matter-like and curvature-like anchors imply a
Lambda-like closure proportion near the locked external Omega_Lambda
reference.

LOCKED REFERENCES
-----------------
Omega_m      : {om_ref}
Omega_Lambda : {lam_ref}
Omega_k      : {ok_ref}
Age reference: {age_ref} Gyr

MAIN OBSERVATION
----------------
For the stable anchor corridor, the Lambda-like closure is:

    Omega_Lambda_like ≈ {stable_lam}

Relative to the locked reference Omega_Lambda = {lam_ref}, this differs by:

    {stable_lam_pct}%

The corresponding dark-to-matter ratio is:

    Omega_Lambda_like / Omega_m_like ≈ {stable_ratio}

with relative difference from the locked ratio:

    {stable_ratio_pct}%

The locked-reference Friedmann age for the same corridor is:

    {stable_age} Gyr

INTERPRETATION
--------------
This is an exploratory Lambda-closure proximity signal. It is not an
independent QEG derivation of dark energy. The Lambda-like quantity arises
as a closure quantity once a matter-like QEG anchor and curvature-like QEG
anchor are inserted into the normalized Friedmann/LambdaCDM bookkeeping
frame.

CLAIM STATUS
------------
Allowed:
    LAMBDA_CLOSURE_PROXIMITY_APPENDIX_ONLY
    DARK_ENERGY_RATIO_BOOKKEEPING_ONLY
    LOCKED_REFERENCE_COMPARISON

Forbidden:
    QEG derives dark energy
    QEG predicts Omega_Lambda
    QEG derives cosmic acceleration
    QEG derives LambdaCDM

NEXT ACTION
-----------
Carry this as a Stage-7D appendix sub-branch or mention in Stage-7E
manuscript curation. Do not promote it unless a later QEG stage produces
an internally generated acceleration/equation-of-state/time-surrogate
mechanism.

============================================================
END LEDGER NOTE
============================================================
"""
    write_text(output_dir / "stage7D_v3_dark_energy_lambda_ledger_note.txt", ledger)

    forbidden = "# Stage-7D v3 forbidden dark-energy claims\n\n" + "\n".join(f"- {c}" for c in FORBIDDEN_CLAIMS) + f"\n\nAllowed wording:\n\n```text\n{ALLOWED_WORDING}\n```\n"
    write_text(output_dir / "stage7D_v3_dark_energy_forbidden_claims.md", forbidden)

    appendix_note = f"""# Appendix note: Lambda / dark-energy closure audit

## Status

This note records a Stage-7D appendix-only audit of Lambda-like or dark-energy-like proportions in the completed Friedmann / GR-adjacent branch.

The audit is motivated by the fact that the Friedmann/LambdaCDM bookkeeping frame contains not only matter-like density and curvature-like terms, but also a Lambda/dark-energy sector associated with late-time cosmic acceleration.

## Result

Using the stable QEG matter-like anchor and small curvature-like correction already retained in Stage-7D v2, the normalized closure quantity is:

```text
Omega_Lambda_like = 1 - Omega_m_like - Omega_k_like ≈ {stable_lam}
```

The locked external reference used by Stage-7D v2 is:

```text
Omega_Lambda_reference = {lam_ref}
```

The absolute percentage difference is approximately:

```text
{stable_lam_pct}%
```

The dark-to-matter ratio is also close:

```text
QEG closure ratio      Omega_Lambda_like / Omega_m_like ≈ {stable_ratio}
Locked reference ratio Omega_Lambda / Omega_m           ≈ {lam_ref / om_ref if om_ref else math.nan}
```

## Interpretation

This is suggestive enough to preserve as appendix bookkeeping, because the matter-like anchor was already part of the main QEG invariant story before the Friedmann comparison.

However, the Lambda-like value is not an independent derivation of dark energy. It is a closure quantity induced by inserting frozen QEG anchors into a standard normalized cosmological budget.

## Promotion gate

A future promotion would require an internally generated QEG mechanism for acceleration, equation-of-state-like behavior, scale-factor-like evolution, or a robust time/evolution surrogate. Without that, this remains:

```text
LAMBDA_CLOSURE_PROXIMITY_APPENDIX_ONLY
```
"""
    write_text(output_dir / "stage7D_v3_dark_energy_appendix_note.md", appendix_note)

    ascii_package = f"""============================================================
ASCII TRANSITION PACKAGE
Project: Quantum-Emergent Gravity
Stage: Stage-7D v3
Working Title: Lambda / Dark-Energy Closure Exploratory Audit
Status: COMPLETED
============================================================

PURPOSE
-------
Audit whether the Stage-7D v2 Friedmann appendix branch already contains
a meaningful dark-energy / Omega_Lambda-like proportion when the frozen
QEG matter-like and curvature-like anchors are placed into a normalized
Friedmann/LambdaCDM bookkeeping frame.

CORE DECISION
-------------
Stage-7D v3 is NOT a dark-energy derivation stage.
It is:

    LAMBDA_CLOSURE_PROXIMITY_APPENDIX_ONLY

RESULT
------
Stable anchor closure:

    Omega_Lambda_like ≈ {stable_lam}

Locked reference:

    Omega_Lambda ≈ {lam_ref}

Difference:

    {stable_lam_pct}%

Dark-to-matter ratio:

    Omega_Lambda_like / Omega_m_like ≈ {stable_ratio}

CLAIM STATUS
------------
Allowed:
    locked-reference Lambda comparison
    closure-induced dark-energy proportion bookkeeping
    appendix-only proximity signal

Forbidden:
    QEG derives dark energy
    QEG predicts Omega_Lambda
    QEG derives cosmic acceleration
    QEG derives LambdaCDM

OUTPUTS
-------
    stage7D_v3_dark_energy_lambda_summary.json
    stage7D_v3_dark_energy_closure_corridor_table.csv
    stage7D_v3_lambda_threshold_counts.csv
    stage7D_v3_lambda_pairwise_audit_totals.csv
    stage7D_v3_pairwise_lambda_nearest_rows.csv
    stage7D_v3_pairwise_lambda_composite_ranked_rows.csv
    stage7D_v3_pairwise_lambda_review_allowed_nearest_rows.csv
    stage7D_v3_dark_energy_lambda_ledger_note.txt
    stage7D_v3_dark_energy_forbidden_claims.md
    stage7D_v3_dark_energy_appendix_note.md
    stage7D_v3_ascii_transition_package.txt

NEXT STAGE
----------
This branch can be cited in Stage-7E manuscript curation, but it should
not alter the main Stage-7C hierarchy or promote Friedmann/GR claims.

============================================================
END STAGE-7D v3 ASCII TRANSITION PACKAGE
============================================================
"""
    write_text(output_dir / "stage7D_v3_ascii_transition_package.txt", ascii_package)

    print("=" * 60)
    print("Stage-7D v3: Dark-Energy / Lambda Closure Exploratory Audit")
    print("=" * 60)
    print(f"Project root: {project_root}")
    print(f"Input v2 dir: {v2_dir}")
    print(f"Output dir  : {output_dir}")
    print(f"Verdict     : {VERDICT}")
    if stable_row:
        print(f"Stable Omega_Lambda_like: {stable_lam}")
        print(f"Lambda pct difference   : {stable_lam_pct}")
        print(f"Dark/matter ratio       : {stable_ratio}")
    print("Done.")


if __name__ == "__main__":
    main()
