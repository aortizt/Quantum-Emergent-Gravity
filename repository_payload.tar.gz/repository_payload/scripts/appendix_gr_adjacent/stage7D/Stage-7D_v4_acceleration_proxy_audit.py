#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Stage-7D v4: Acceleration Proxy Audit
Project: Quantum-Emergent Gravity
Author: Arturo Ortiz-Tapia / QEG assistant workflow
Stage: 7D appendix sub-branch
Purpose:
    Test whether the Stage-7D v3 Lambda-like closure corridor implies an
    acceleration-like sign and strength under locked LambdaCDM/Friedmann
    bookkeeping.

Status:
    APPENDIX ONLY.
    This script does NOT derive cosmic acceleration, dark energy, LambdaCDM,
    Friedmann equations, GR, or cosmic time.

Core proxy:
    q0_like = 0.5 * Omega_m_like - Omega_Lambda_like

For pressureless matter plus Lambda, ignoring radiation, the deceleration
parameter is negative when the Lambda term dominates:

    q0 < 0  => acceleration-like bookkeeping sign

Curvature is retained in closure bookkeeping but does not enter this simple
late-time acceleration equation directly.

Expected use:
    %runfile /home/dakini/Downloads/010-Quantum_Emergent_Gravity/metric_stage_7D_scripts/Stage-7D_v4_acceleration_proxy_audit.py --wdir

or:
    python3 Stage-7D_v4_acceleration_proxy_audit.py /home/dakini/Downloads/010-Quantum_Emergent_Gravity
"""

from __future__ import annotations

import json
import math
import sys
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd


STAGE = "Stage-7D v4"
SCRIPT = "Stage-7D_v4_acceleration_proxy_audit.py"

LOCKED_REFERENCES = {
    "Omega_m": 0.315,
    "Omega_Lambda": 0.685,
    "Omega_k": 0.0007,
    "age_universe_gyr": 13.797,
    "H0_km_s_Mpc": 67.4,
    "h": 0.674,
    "policy": "locked external constants may compare only after internal QEG quantities are frozen",
    "reference_label": "PDG/Planck-style LambdaCDM comparison constants, locked for appendix bookkeeping only",
}

POLICY = {
    "appendix_only": True,
    "acceleration_claim_forbidden": True,
    "external_constants_locked_reference_only": True,
    "q0_proxy_is_not_independent_derivation": True,
    "no_promotion_from_acceleration_lambda_or_age_proximity_alone": True,
    "friedmann_derivation_claim_forbidden": True,
}


def infer_project_root(argv: List[str]) -> Path:
    """Infer QEG project root from command-line argument, cwd, or known Dakini path."""
    if len(argv) >= 2:
        return Path(argv[1]).expanduser().resolve()

    cwd = Path.cwd().resolve()
    if (cwd / "metric_stage_7D_outputs").exists():
        return cwd

    known = Path("/home/dakini/Downloads/010-Quantum_Emergent_Gravity")
    if known.exists():
        return known.resolve()

    return cwd


def safe_float(x, default=np.nan) -> float:
    try:
        if x is None:
            return default
        return float(x)
    except Exception:
        return default


def q0_proxy(omega_m: float, omega_lambda: float) -> float:
    """Late-time matter+Lambda deceleration proxy q0 = 1/2 Omega_m - Omega_Lambda."""
    return 0.5 * omega_m - omega_lambda


def transition_redshift_proxy(omega_m: float, omega_lambda: float) -> float:
    """
    Approximate acceleration-transition redshift for matter+Lambda:
        q(z)=0 => (1/2) Omega_m (1+z)^3 = Omega_Lambda
        z_acc = (2 Omega_Lambda / Omega_m)^(1/3) - 1
    This is bookkeeping only and ignores radiation.
    """
    if not np.isfinite(omega_m) or not np.isfinite(omega_lambda):
        return np.nan
    if omega_m <= 0 or omega_lambda <= 0:
        return np.nan
    return (2.0 * omega_lambda / omega_m) ** (1.0 / 3.0) - 1.0


def pct_diff(value: float, ref: float) -> float:
    if not np.isfinite(value) or not np.isfinite(ref) or ref == 0:
        return np.nan
    return abs(value - ref) / abs(ref) * 100.0


def signed_ratio(value: float, ref: float) -> float:
    if not np.isfinite(value) or not np.isfinite(ref) or ref == 0:
        return np.nan
    return value / ref


def find_first_existing(paths: Iterable[Path]) -> Optional[Path]:
    for p in paths:
        if p.exists():
            return p
    return None


def load_json(path: Path) -> Dict:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def write_json(path: Path, obj: Dict) -> None:
    with path.open("w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, sort_keys=True)


def normalize_name(s: str) -> str:
    return str(s).lower().replace(" ", "_").replace("-", "_")


def choose_column(df: pd.DataFrame, candidates: List[str]) -> Optional[str]:
    """Choose a likely column by exact normalized name or substring matching."""
    if df.empty:
        return None

    norm_to_orig = {normalize_name(c): c for c in df.columns}

    for cand in candidates:
        nc = normalize_name(cand)
        if nc in norm_to_orig:
            return norm_to_orig[nc]

    for cand in candidates:
        nc = normalize_name(cand)
        for ncol, orig in norm_to_orig.items():
            if nc in ncol:
                return orig

    return None


def add_acceleration_columns(
    df: pd.DataFrame,
    omega_m_col: str,
    omega_lambda_col: str,
    label_col: Optional[str] = None,
) -> pd.DataFrame:
    """Return copy of dataframe with q0 and transition-redshift proxy columns."""
    out = df.copy()

    ref_q0 = q0_proxy(LOCKED_REFERENCES["Omega_m"], LOCKED_REFERENCES["Omega_Lambda"])
    ref_z = transition_redshift_proxy(LOCKED_REFERENCES["Omega_m"], LOCKED_REFERENCES["Omega_Lambda"])

    out["q0_like_proxy"] = 0.5 * pd.to_numeric(out[omega_m_col], errors="coerce") - pd.to_numeric(
        out[omega_lambda_col], errors="coerce"
    )
    out["q0_locked_reference"] = ref_q0
    out["q0_abs_difference"] = (out["q0_like_proxy"] - ref_q0).abs()
    out["q0_pct_difference"] = out["q0_abs_difference"] / abs(ref_q0) * 100.0
    out["acceleration_like_sign"] = out["q0_like_proxy"] < 0
    out["deceleration_like_sign"] = out["q0_like_proxy"] > 0
    out["q0_signed_strength_ratio_vs_locked"] = out["q0_like_proxy"] / ref_q0

    omega_m = pd.to_numeric(out[omega_m_col], errors="coerce")
    omega_lambda = pd.to_numeric(out[omega_lambda_col], errors="coerce")
    with np.errstate(divide="ignore", invalid="ignore"):
        out["z_acc_like_proxy"] = np.power(2.0 * omega_lambda / omega_m, 1.0 / 3.0) - 1.0

    out["z_acc_locked_reference"] = ref_z
    out["z_acc_abs_difference"] = (out["z_acc_like_proxy"] - ref_z).abs()
    out["z_acc_pct_difference"] = out["z_acc_abs_difference"] / abs(ref_z) * 100.0

    if label_col and label_col in out.columns:
        out["source_label_for_acceleration_audit"] = out[label_col].astype(str)

    out["acceleration_proxy_status"] = np.where(
        out["acceleration_like_sign"],
        "NEGATIVE_Q0_ACCELERATION_LIKE_BOOKKEEPING_ONLY",
        "NON_NEGATIVE_Q0_REVIEW_OR_REJECT",
    )

    return out


def build_stable_anchor_from_v3_summary(v3_summary: Dict) -> Dict:
    stable = dict(v3_summary.get("stable_anchor_lambda_closure", {}))

    omega_m = safe_float(stable.get("omega_m_like_anchor", np.nan))
    omega_k = safe_float(stable.get("omega_k_like_anchor", np.nan))
    omega_lambda = safe_float(stable.get("omega_lambda_like_closure", np.nan))

    if not np.isfinite(omega_lambda) and np.isfinite(omega_m) and np.isfinite(omega_k):
        omega_lambda = 1.0 - omega_m - omega_k

    q_like = q0_proxy(omega_m, omega_lambda)
    q_ref = q0_proxy(LOCKED_REFERENCES["Omega_m"], LOCKED_REFERENCES["Omega_Lambda"])

    z_like = transition_redshift_proxy(omega_m, omega_lambda)
    z_ref = transition_redshift_proxy(LOCKED_REFERENCES["Omega_m"], LOCKED_REFERENCES["Omega_Lambda"])

    result = {
        "corridor_label": stable.get("corridor_label", "meaningful_stable_anchor_corridor"),
        "omega_m_like_anchor": omega_m,
        "omega_k_like_anchor": omega_k,
        "omega_lambda_like_closure": omega_lambda,
        "closure_sum_omega_m_plus_lambda_plus_k": omega_m + omega_lambda + omega_k,
        "closure_sum_difference_from_one": (omega_m + omega_lambda + omega_k) - 1.0,
        "q0_like_proxy": q_like,
        "q0_locked_reference": q_ref,
        "q0_abs_difference": abs(q_like - q_ref),
        "q0_pct_difference": pct_diff(q_like, q_ref),
        "q0_signed_strength_ratio_vs_locked": signed_ratio(q_like, q_ref),
        "acceleration_like_sign": bool(q_like < 0),
        "z_acc_like_proxy": z_like,
        "z_acc_locked_reference": z_ref,
        "z_acc_abs_difference": abs(z_like - z_ref) if np.isfinite(z_like) and np.isfinite(z_ref) else np.nan,
        "z_acc_pct_difference": pct_diff(z_like, z_ref),
        "age_gyr_locked_reference_integral": stable.get("age_gyr_locked_reference_integral", np.nan),
        "age_error_gyr_vs_locked_reference": stable.get("age_error_gyr_vs_locked_reference", np.nan),
        "interpretation": (
            "Stable matter-like QEG anchor plus curvature-like correction implies negative q0-like "
            "acceleration sign in late-time LambdaCDM bookkeeping. This is a proxy audit only, "
            "not a derivation of cosmic acceleration."
        ),
        "acceleration_proxy_status": (
            "NEGATIVE_Q0_ACCELERATION_LIKE_WITHIN_2PCT_REFERENCE_APPENDIX_ONLY"
            if (q_like < 0 and pct_diff(q_like, q_ref) <= 2.0)
            else "ACCELERATION_PROXY_REVIEW_ONLY"
        ),
    }

    return result


def try_pairwise_acceleration_audits(v3_dir: Path, out_dir: Path) -> Dict:
    """
    Try to compute acceleration proxies for pairwise Lambda tables if column
    names are discoverable. This is intentionally conservative.
    """
    outputs = {}
    candidate_files = [
        v3_dir / "stage7D_v3_pairwise_lambda_composite_ranked_rows.csv",
        v3_dir / "stage7D_v3_pairwise_lambda_review_allowed_nearest_rows.csv",
        v3_dir / "stage7D_v3_pairwise_lambda_nearest_rows.csv",
        v3_dir / "stage7D_v3_dark_energy_closure_corridor_table.csv",
    ]

    for csv_path in candidate_files:
        if not csv_path.exists():
            continue

        try:
            df = pd.read_csv(csv_path)
        except Exception as exc:
            outputs[csv_path.name] = {"loaded": False, "error": repr(exc)}
            continue

        omega_m_col = choose_column(
            df,
            [
                "omega_m_like_anchor",
                "Omega_m_like",
                "omega_m_like",
                "omega_m",
                "matter_like",
                "matter_anchor",
                "omega_m_candidate",
            ],
        )
        omega_lambda_col = choose_column(
            df,
            [
                "omega_lambda_like_closure",
                "Omega_Lambda_like",
                "omega_lambda_like",
                "omega_lambda",
                "lambda_like",
                "lambda_closure",
                "omega_lambda_candidate",
            ],
        )
        label_col = choose_column(df, ["corridor_label", "source_label", "label", "candidate_label", "row_label"])

        item = {
            "loaded": True,
            "rows": int(len(df)),
            "omega_m_col": omega_m_col,
            "omega_lambda_col": omega_lambda_col,
            "label_col": label_col,
            "audited": False,
        }

        if omega_m_col and omega_lambda_col and len(df) > 0:
            audited = add_acceleration_columns(df, omega_m_col, omega_lambda_col, label_col=label_col)
            sort_cols = [c for c in ["acceleration_like_sign", "q0_pct_difference", "z_acc_pct_difference"] if c in audited.columns]
            if sort_cols:
                audited = audited.sort_values(
                    by=["acceleration_like_sign", "q0_pct_difference", "z_acc_pct_difference"],
                    ascending=[False, True, True],
                    kind="mergesort",
                )

            out_name = csv_path.stem.replace("stage7D_v3_", "stage7D_v4_acceleration_audited_") + ".csv"
            out_path = out_dir / out_name
            audited.to_csv(out_path, index=False)

            item.update(
                {
                    "audited": True,
                    "output_file": str(out_path),
                    "acceleration_like_rows": int(audited["acceleration_like_sign"].sum()),
                    "within_2pct_q0_rows": int((audited["q0_pct_difference"] <= 2.0).sum()),
                    "within_5pct_q0_rows": int((audited["q0_pct_difference"] <= 5.0).sum()),
                    "best_q0_pct_difference": safe_float(audited["q0_pct_difference"].min()),
                }
            )

        outputs[csv_path.name] = item

    return outputs


def make_ledger_note(summary: Dict) -> str:
    stable = summary["stable_anchor_acceleration_proxy"]
    return f"""============================================================
STAGE-7D v4 LEDGER NOTE
Project: Quantum-Emergent Gravity
Script : {SCRIPT}
Status : COMPLETED
============================================================

VERDICT
-------
{summary["verdict"]}

PURPOSE
-------
Stage-7D v4 audits whether the Stage-7D v3 Lambda-like closure corridor
also implies the acceleration-like sign expected in late-time LambdaCDM
bookkeeping.

This is an appendix-only proxy audit.

CORE PROXY
----------
q0_like = 0.5 * Omega_m_like - Omega_Lambda_like

For the stable anchor corridor:

    Omega_m_like      = {stable["omega_m_like_anchor"]}
    Omega_k_like      = {stable["omega_k_like_anchor"]}
    Omega_Lambda_like = {stable["omega_lambda_like_closure"]}

Therefore:

    q0_like           = {stable["q0_like_proxy"]}
    q0_locked_ref     = {stable["q0_locked_reference"]}
    q0_pct_difference = {stable["q0_pct_difference"]}%

The sign is negative:

    q0_like < 0

so the corridor is acceleration-like in the bookkeeping sense.

ACCELERATION TRANSITION PROXY
-----------------------------
Approximate matter+Lambda transition redshift:

    z_acc_like       = {stable["z_acc_like_proxy"]}
    z_acc_locked_ref = {stable["z_acc_locked_reference"]}
    z_acc_pct_diff   = {stable["z_acc_pct_difference"]}%

INTERPRETATION
--------------
This strengthens Stage-7D as an appendix branch because the same frozen
QEG anchors that produced a Lambda-like closure also produce the expected
negative acceleration-like sign.

However, this does NOT derive cosmic acceleration. It is a LambdaCDM-style
proxy computed after QEG anchors were frozen.

CLAIM STATUS
------------
Allowed:
    ACCELERATION_PROXY_APPENDIX_ONLY
    NEGATIVE_Q0_BOOKKEEPING_SIGNAL
    LOCKED_REFERENCE_COMPARISON

Forbidden:
    QEG derives cosmic acceleration
    QEG predicts the deceleration parameter
    QEG derives LambdaCDM
    QEG derives dark energy
    QEG derives Friedmann equations or GR

NEXT ACTION
-----------
Carry this with Stage-7D v2/v3 during Stage-7E manuscript curation.
Do not promote unless a later QEG stage produces an internally generated
time/evolution/acceleration/equation-of-state mechanism.

============================================================
END LEDGER NOTE
============================================================
"""


def make_appendix_note(summary: Dict) -> str:
    stable = summary["stable_anchor_acceleration_proxy"]
    return f"""# Appendix note: acceleration-sign proxy audit

## Status

This note records a Stage-7D appendix-only audit of whether the Lambda-like
closure corridor also implies an acceleration-like sign in a late-time
matter + Lambda bookkeeping frame.

The audit uses the proxy:

```text
q0_like = 0.5 * Omega_m_like - Omega_Lambda_like
```

This is not a derivation of cosmic acceleration. It is a locked-reference
comparison proxy.

## Result

For the stable QEG corridor:

```text
Omega_m_like      ≈ {stable["omega_m_like_anchor"]}
Omega_k_like      ≈ {stable["omega_k_like_anchor"]}
Omega_Lambda_like ≈ {stable["omega_lambda_like_closure"]}
```

the acceleration proxy is:

```text
q0_like ≈ {stable["q0_like_proxy"]}
```

The locked reference proxy is:

```text
q0_reference ≈ {stable["q0_locked_reference"]}
```

The percentage difference is approximately:

```text
{stable["q0_pct_difference"]}%
```

Because `q0_like < 0`, the corridor has the expected acceleration-like sign.

## Transition proxy

The approximate matter+Lambda acceleration-transition redshift is:

```text
z_acc_like ≈ {stable["z_acc_like_proxy"]}
```

compared with the locked reference:

```text
z_acc_reference ≈ {stable["z_acc_locked_reference"]}
```

The difference is approximately:

```text
{stable["z_acc_pct_difference"]}%
```

## Interpretation

This strengthens the Stage-7D appendix branch because the same frozen
matter-like and curvature-like QEG anchors that imply a Lambda-like closure
also imply the expected negative acceleration-like sign.

However, this remains comparison bookkeeping only. A physical acceleration
claim would require an internally generated QEG mechanism for acceleration,
equation-of-state-like behavior, scale-factor-like evolution, or a robust
time/evolution surrogate.

Allowed label:

```text
ACCELERATION_PROXY_APPENDIX_ONLY
```
"""


def make_forbidden_claims() -> str:
    return """# Stage-7D v4 forbidden acceleration claims

- QEG derives cosmic acceleration.
- QEG predicts the deceleration parameter.
- QEG derives the acceleration history of the Universe.
- QEG derives the acceleration-transition redshift.
- QEG derives LambdaCDM.
- QEG derives dark energy.
- QEG derives Omega_Lambda.
- QEG derives the Friedmann equations.
- QEG derives the age of the universe.
- QEG derives general relativity.
- A negative q0-like proxy is an independent QEG discovery of cosmic acceleration.
- External PDG / Planck / LambdaCDM constants select or promote QEG observables.

Allowed wording:

```text
This Stage-7D v4 audit records whether frozen QEG matter-like and
Lambda-like closure anchors imply the expected negative q0-like sign in
a late-time LambdaCDM bookkeeping proxy. The result is appendix comparison
bookkeeping only. It is not a derivation of cosmic acceleration, dark
energy, LambdaCDM, GR, Friedmann equations, or cosmic time.
```
"""


def make_ascii_transition(summary: Dict) -> str:
    stable = summary["stable_anchor_acceleration_proxy"]
    return f"""============================================================
ASCII TRANSITION PACKAGE
Project: Quantum-Emergent Gravity
Stage: Stage-7D v4
Working Title: Acceleration Proxy Audit
Status: COMPLETED
============================================================

PURPOSE
-------
Audit whether the Stage-7D v3 Lambda-like closure corridor also implies
the expected acceleration-like sign in a late-time matter + Lambda
bookkeeping proxy.

CORE DECISION
-------------
Stage-7D v4 is NOT a cosmic-acceleration derivation stage.
It is:

    ACCELERATION_PROXY_APPENDIX_ONLY

RESULT
------
Stable anchor acceleration proxy:

    q0_like = 0.5 * Omega_m_like - Omega_Lambda_like
            ≈ {stable["q0_like_proxy"]}

Locked reference proxy:

    q0_reference ≈ {stable["q0_locked_reference"]}

Difference:

    {stable["q0_pct_difference"]}%

Sign:

    q0_like < 0

Interpretation:

    acceleration-like sign present in locked-reference bookkeeping.

TRANSITION REDSHIFT PROXY
-------------------------
Approximate z_acc_like:

    {stable["z_acc_like_proxy"]}

Locked z_acc_reference:

    {stable["z_acc_locked_reference"]}

Difference:

    {stable["z_acc_pct_difference"]}%

CLAIM STATUS
------------
Allowed:
    locked-reference q0-like comparison
    acceleration-sign bookkeeping
    appendix-only proximity signal

Forbidden:
    QEG derives cosmic acceleration
    QEG predicts q0
    QEG derives LambdaCDM
    QEG derives dark energy
    QEG derives Friedmann equations or GR

OUTPUTS
-------
    stage7D_v4_acceleration_proxy_summary.json
    stage7D_v4_acceleration_proxy_corridor_table.csv
    stage7D_v4_acceleration_proxy_ledger_note.txt
    stage7D_v4_acceleration_proxy_appendix_note.md
    stage7D_v4_acceleration_proxy_forbidden_claims.md
    stage7D_v4_ascii_transition_package.txt

NEXT STAGE
----------
Carry Stage-7D v2/v3/v4 as a guarded appendix bundle during Stage-7E
manuscript curation. Do not promote to a physical acceleration claim unless
a later QEG stage produces an internally generated time/evolution or
equation-of-state mechanism.

============================================================
END STAGE-7D v4 ASCII TRANSITION PACKAGE
============================================================
"""


def main(argv: List[str]) -> int:
    project_root = infer_project_root(argv)

    v3_dir = project_root / "metric_stage_7D_outputs" / "dark_energy_lambda_closure_exploratory_v3"
    out_dir = project_root / "metric_stage_7D_outputs" / "acceleration_proxy_audit_v4"
    out_dir.mkdir(parents=True, exist_ok=True)

    v3_summary_path = v3_dir / "stage7D_v3_dark_energy_lambda_summary.json"
    if not v3_summary_path.exists():
        raise FileNotFoundError(
            f"Cannot find Stage-7D v3 summary at {v3_summary_path}. "
            "Run Stage-7D_v3_dark_energy_closure_exploratory.py first."
        )

    v3_summary = load_json(v3_summary_path)
    stable_anchor = build_stable_anchor_from_v3_summary(v3_summary)

    corridor_df = pd.DataFrame([stable_anchor])
    corridor_df.to_csv(out_dir / "stage7D_v4_acceleration_proxy_corridor_table.csv", index=False)

    pairwise_audit = try_pairwise_acceleration_audits(v3_dir, out_dir)

    q_ok = bool(stable_anchor["acceleration_like_sign"])
    q_close = safe_float(stable_anchor["q0_pct_difference"], default=999.0) <= 2.0
    z_close = safe_float(stable_anchor["z_acc_pct_difference"], default=999.0) <= 2.0

    if q_ok and q_close and z_close:
        verdict = "B_ACCELERATION_PROXY_NEGATIVE_SIGN_AND_REFERENCE_PROXIMITY_APPENDIX_ONLY"
    elif q_ok:
        verdict = "C_ACCELERATION_PROXY_NEGATIVE_SIGN_PRESENT_BUT_REVIEW_REQUIRED"
    else:
        verdict = "C_ACCELERATION_PROXY_NOT_SUPPORTED_OR_REVIEW_REQUIRED"

    summary = {
        "project": "Quantum-Emergent Gravity",
        "stage": STAGE,
        "script": SCRIPT,
        "project_root": str(project_root),
        "input_v3_dir": str(v3_dir),
        "output_dir": str(out_dir),
        "locked_references": LOCKED_REFERENCES,
        "policy": POLICY,
        "stable_anchor_acceleration_proxy": stable_anchor,
        "pairwise_acceleration_audit": pairwise_audit,
        "verdict": verdict,
        "recommended_next_action": (
            "Carry as Stage-7D appendix sub-branch during Stage-7E manuscript curation; "
            "do not promote to a physical cosmic-acceleration claim without an internally "
            "generated QEG acceleration/equation-of-state/time-surrogate mechanism."
        ),
    }

    write_json(out_dir / "stage7D_v4_acceleration_proxy_summary.json", summary)

    (out_dir / "stage7D_v4_acceleration_proxy_ledger_note.txt").write_text(
        make_ledger_note(summary), encoding="utf-8"
    )
    (out_dir / "stage7D_v4_acceleration_proxy_appendix_note.md").write_text(
        make_appendix_note(summary), encoding="utf-8"
    )
    (out_dir / "stage7D_v4_acceleration_proxy_forbidden_claims.md").write_text(
        make_forbidden_claims(), encoding="utf-8"
    )
    (out_dir / "stage7D_v4_ascii_transition_package.txt").write_text(
        make_ascii_transition(summary), encoding="utf-8"
    )

    print("=" * 72)
    print(f"{STAGE}: Acceleration Proxy Audit")
    print("=" * 72)
    print(f"Project root : {project_root}")
    print(f"Input v3 dir : {v3_dir}")
    print(f"Output dir   : {out_dir}")
    print(f"Verdict      : {verdict}")
    print()
    print("Stable anchor:")
    print(f"  Omega_m_like      = {stable_anchor['omega_m_like_anchor']}")
    print(f"  Omega_k_like      = {stable_anchor['omega_k_like_anchor']}")
    print(f"  Omega_Lambda_like = {stable_anchor['omega_lambda_like_closure']}")
    print(f"  q0_like           = {stable_anchor['q0_like_proxy']}")
    print(f"  q0_reference      = {stable_anchor['q0_locked_reference']}")
    print(f"  q0 pct diff       = {stable_anchor['q0_pct_difference']:.6f}%")
    print(f"  z_acc_like        = {stable_anchor['z_acc_like_proxy']}")
    print(f"  z_acc_reference   = {stable_anchor['z_acc_locked_reference']}")
    print(f"  z_acc pct diff    = {stable_anchor['z_acc_pct_difference']:.6f}%")
    print()
    print("Wrote:")
    for name in [
        "stage7D_v4_acceleration_proxy_summary.json",
        "stage7D_v4_acceleration_proxy_corridor_table.csv",
        "stage7D_v4_acceleration_proxy_ledger_note.txt",
        "stage7D_v4_acceleration_proxy_appendix_note.md",
        "stage7D_v4_acceleration_proxy_forbidden_claims.md",
        "stage7D_v4_ascii_transition_package.txt",
    ]:
        print(f"  - {name}")
    print("=" * 72)

    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
