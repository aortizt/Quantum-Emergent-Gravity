#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Stage-6D-branch1 refined boundary v3

Purpose
-------
Third-round refinement of the Stage-6D branch1 admissibility-boundary analysis.
This revision does not try to force a universal pooled boundary. Instead it:

1) keeps the family classification from v2,
2) improves the boundary-bearing reconstruction using adaptive angular pooling,
3) replaces raw slice crossing by a monotone radial profile fit,
4) records threshold-band diagnostics (not only exact 0.5 crossings), and
5) writes outputs compatible with the branch1 v2 filenames while adding richer
   diagnostics to the JSON/TXT outputs.

Main methodological change
--------------------------
For each angular slice we estimate a smoothed failure probability as a function
of radius, then project it to a monotone profile using an isotonic-style
cumulative-max operation. The boundary estimate is extracted as the first radius
where the profile reaches the chosen threshold. When the exact 0.5 crossing is
not well supported, the script also reports whether the slice enters a looser
transition band [0.4, 0.6]. This helps distinguish truly boundary-poor data
from an extraction artifact caused by sparse support.

Outputs
-------
The script overwrites the standard branch1 outputs:
  - stage6D_branch1_joint_density_refined.csv
  - stage6D_branch1_boundary_estimate.csv
  - stage6D_branch1_family_boundary.csv
  - stage6D_branch1_boundary_diagnostics.json
  - stage6D_branch1_interpretive_notes.txt
"""

from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

SCRIPT_TAG = "Stage-6D-branch1 refined boundary v3"
THRESHOLD = 0.5
LOOSE_BAND = (0.4, 0.6)
DEFAULT_THETA_SAMPLES = 120
DEFAULT_RADIAL_SAMPLES = 160
DEFAULT_THETA_BW = 0.22
MIN_EFFECTIVE_SUPPORT = 4.0


# -----------------------------------------------------------------------------
# Utilities
# -----------------------------------------------------------------------------
def log(msg: str) -> None:
    print(f"[{SCRIPT_TAG}] {msg}")


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def nanfloat(x: float) -> Optional[float]:
    if x is None:
        return None
    if isinstance(x, (float, np.floating)) and (np.isnan(x) or np.isinf(x)):
        return None
    return float(x)


def rms_ignore_nan(a: np.ndarray, b: np.ndarray) -> float:
    mask = np.isfinite(a) & np.isfinite(b)
    if not np.any(mask):
        return float("nan")
    return float(np.sqrt(np.mean((a[mask] - b[mask]) ** 2)))


def circular_distance(theta: np.ndarray, theta0: float) -> np.ndarray:
    d = np.abs(theta - theta0)
    return np.minimum(d, 2.0 * np.pi - d)


def gaussian_kernel(x: np.ndarray, bandwidth: float) -> np.ndarray:
    bandwidth = max(float(bandwidth), 1e-12)
    z = x / bandwidth
    return np.exp(-0.5 * z * z)


def weighted_mean(values: np.ndarray, weights: np.ndarray) -> float:
    denom = np.sum(weights)
    if denom <= 0.0:
        return float("nan")
    return float(np.sum(weights * values) / denom)


def weighted_var(values: np.ndarray, weights: np.ndarray) -> float:
    mean = weighted_mean(values, weights)
    denom = np.sum(weights)
    if denom <= 0.0 or not np.isfinite(mean):
        return float("nan")
    return float(np.sum(weights * (values - mean) ** 2) / denom)


def find_first_existing(root: Path, candidates: List[Path]) -> Optional[Path]:
    for p in candidates:
        full = p if p.is_absolute() else root / p
        if full.exists():
            return full
    return None


def choose_column(df: pd.DataFrame, candidates: List[str], required: bool = True) -> Optional[str]:
    cols_lower = {c.lower(): c for c in df.columns}
    for cand in candidates:
        if cand in df.columns:
            return cand
        if cand.lower() in cols_lower:
            return cols_lower[cand.lower()]
    if required:
        raise KeyError(f"None of the candidate columns found: {candidates}")
    return None


def to_binary_failure(series: pd.Series) -> pd.Series:
    if pd.api.types.is_bool_dtype(series):
        return series.astype(int)
    if pd.api.types.is_numeric_dtype(series):
        return (series.astype(float) > 0).astype(int)
    lowered = series.astype(str).str.strip().str.lower()
    true_set = {"1", "true", "yes", "y", "inadmissible", "fail", "failure"}
    return lowered.isin(true_set).astype(int)


def family_regime(n_failures: int, n_successes: int) -> str:
    if n_failures > 0 and n_successes > 0:
        return "mixed"
    if n_failures == 0 and n_successes > 0:
        return "always_admissible_sampled_support"
    if n_successes == 0 and n_failures > 0:
        return "always_inadmissible_sampled_support"
    return "empty"


# -----------------------------------------------------------------------------
# Project-root and file discovery
# -----------------------------------------------------------------------------
def infer_project_root() -> Path:
    cwd = Path.cwd().resolve()
    for candidate in [cwd] + list(cwd.parents):
        if (candidate / "metric_stage_6D_outputs").exists() or (candidate / "metric_stage_6D_branch1_outputs").exists():
            return candidate
    return cwd


def resolve_inputs(project_root: Path) -> Dict[str, Optional[Path]]:
    return {
        "geometry": find_first_existing(project_root, [
            Path("metric_stage_6D_outputs/stage6D_inadmissibility_geometry_table_v2.csv"),
            Path("metric_stage_6D_branch1_inputs/stage6D_inadmissibility_geometry_table_v2.csv"),
        ]),
        "boundary_estimate_v2": find_first_existing(project_root, [
            Path("metric_stage_6D_outputs/stage6D_boundary_estimate_v2.csv"),
        ]),
        "family_boundary_estimate_v2": find_first_existing(project_root, [
            Path("metric_stage_6D_outputs/stage6D_family_boundary_estimate_v2.csv"),
        ]),
        "joint_density_v2": find_first_existing(project_root, [
            Path("metric_stage_6D_outputs/stage6D_joint_density_v2.csv"),
        ]),
        "radius_profile_v2": find_first_existing(project_root, [
            Path("metric_stage_6D_outputs/stage6D_radius_profile_v2.csv"),
        ]),
        "angle_profile_v2": find_first_existing(project_root, [
            Path("metric_stage_6D_outputs/stage6D_angle_profile_v2.csv"),
        ]),
        "summary_v2": find_first_existing(project_root, [
            Path("metric_stage_6D_outputs/stage6D_symmetry_breaking_summary_v2.json"),
        ]),
        "notes_v2": find_first_existing(project_root, [
            Path("metric_stage_6D_outputs/stage6D_interpretive_notes_v2.txt"),
        ]),
    }


# -----------------------------------------------------------------------------
# Data preparation
# -----------------------------------------------------------------------------
def load_geometry_table(path: Path) -> Tuple[pd.DataFrame, Dict[str, str]]:
    df = pd.read_csv(path)

    radius_col = choose_column(df, [
        "radius_value", "radius", "r", "preferred_radius", "intrinsic_radius"
    ])
    theta_col = choose_column(df, [
        "angle_value_after_unfolding", "angle_value", "theta", "preferred_directional_coordinate"
    ])
    family_col = choose_column(df, [
        "family", "metric_family", "metric_name", "fit_name"
    ])

    failure_col = None
    failure_candidates = [
        "inadmissible", "is_inadmissible", "failure", "failed", "inadmissibility_flag", "status"
    ]
    for cand in failure_candidates:
        if cand in df.columns or cand.lower() in {c.lower() for c in df.columns}:
            failure_col = choose_column(df, [cand], required=False)
            break
    if failure_col is None and "status" in df.columns:
        failure_col = "status"
    if failure_col is None:
        raise KeyError("Could not infer failure/inadmissibility column.")

    out = df.copy()
    out[radius_col] = pd.to_numeric(out[radius_col], errors="coerce")
    out[theta_col] = pd.to_numeric(out[theta_col], errors="coerce")
    out = out.dropna(subset=[radius_col, theta_col, family_col]).copy()

    theta_vals = out[theta_col].to_numpy(dtype=float)
    theta_vals = np.mod(theta_vals, 2.0 * np.pi)
    out[theta_col] = theta_vals

    if failure_col == "status" and not pd.api.types.is_numeric_dtype(out[failure_col]):
        lowered = out[failure_col].astype(str).str.lower()
        out["_failure_binary"] = lowered.str.contains("inadmiss|fail").astype(int)
        failure_binary = "_failure_binary"
    else:
        out["_failure_binary"] = to_binary_failure(out[failure_col])
        failure_binary = "_failure_binary"

    out = out.sort_values([family_col, theta_col, radius_col]).reset_index(drop=True)

    colmap = {
        "radius_col": radius_col,
        "theta_col": theta_col,
        "failure_col": failure_col,
        "family_col": family_col,
        "failure_binary_col": failure_binary,
    }
    return out, colmap


# -----------------------------------------------------------------------------
# Boundary estimation core
# -----------------------------------------------------------------------------
def estimate_probability_surface(
    df: pd.DataFrame,
    radius_col: str,
    theta_col: str,
    failure_col: str,
    theta_grid: np.ndarray,
    radius_grid: np.ndarray,
    theta_bandwidth: float,
    radius_bandwidth: float,
) -> Tuple[np.ndarray, np.ndarray]:
    radii = df[radius_col].to_numpy(dtype=float)
    thetas = df[theta_col].to_numpy(dtype=float)
    failures = df[failure_col].to_numpy(dtype=float)

    n_t = len(theta_grid)
    n_r = len(radius_grid)
    p = np.full((n_t, n_r), np.nan)
    eff = np.zeros((n_t, n_r), dtype=float)

    theta_w_full = np.empty((n_t, len(df)), dtype=float)
    for i, t0 in enumerate(theta_grid):
        theta_w_full[i, :] = gaussian_kernel(circular_distance(thetas, t0), theta_bandwidth)

    for j, r0 in enumerate(radius_grid):
        radius_w = gaussian_kernel(radii - r0, radius_bandwidth)
        w = theta_w_full * radius_w[None, :]
        denom = np.sum(w, axis=1)
        numer = np.sum(w * failures[None, :], axis=1)
        good = denom > 0.0
        p[good, j] = numer[good] / denom[good]
        eff[good, j] = denom[good] / max(float(np.max(radius_w)), 1e-12)
    return p, eff


def monotone_profile(prob: np.ndarray) -> np.ndarray:
    # Conservative monotone radialization assuming failure tendency should not
    # decrease once one moves into the inadmissible side.
    out = np.array(prob, copy=True)
    if np.all(~np.isfinite(out)):
        return out
    running = -np.inf
    for i in range(len(out)):
        if np.isfinite(out[i]):
            running = max(running, out[i])
            out[i] = running
    return np.clip(out, 0.0, 1.0)


def extract_crossing(
    radius_grid: np.ndarray,
    prob_profile: np.ndarray,
    eff_profile: np.ndarray,
    threshold: float = THRESHOLD,
    loose_band: Tuple[float, float] = LOOSE_BAND,
    min_support: float = MIN_EFFECTIVE_SUPPORT,
) -> Dict[str, object]:
    p = monotone_profile(prob_profile)
    eff = np.asarray(eff_profile, dtype=float)

    finite = np.isfinite(p)
    if not np.any(finite):
        return {
            "r_c": np.nan,
            "crossing_status": "no_profile",
            "usable_crossing": False,
            "low_support": True,
            "p_min": np.nan,
            "p_max": np.nan,
            "band_entry_radius": np.nan,
        }

    pmin = float(np.nanmin(p))
    pmax = float(np.nanmax(p))

    idx_ge = np.where(finite & (p >= threshold))[0]
    if len(idx_ge) == 0:
        band_idx = np.where(finite & (p >= loose_band[0]) & (p <= loose_band[1]))[0]
        band_entry = float(radius_grid[band_idx[0]]) if len(band_idx) else np.nan
        return {
            "r_c": np.nan,
            "crossing_status": "always_below_threshold",
            "usable_crossing": False,
            "low_support": False,
            "p_min": pmin,
            "p_max": pmax,
            "band_entry_radius": band_entry,
        }

    first = int(idx_ge[0])
    if first == 0:
        r_c = float(radius_grid[0])
    else:
        r1, r2 = float(radius_grid[first - 1]), float(radius_grid[first])
        p1, p2 = float(p[first - 1]), float(p[first])
        if np.isfinite(p1) and np.isfinite(p2) and abs(p2 - p1) > 1e-12:
            alpha = (threshold - p1) / (p2 - p1)
            alpha = min(max(alpha, 0.0), 1.0)
            r_c = r1 + alpha * (r2 - r1)
        else:
            r_c = r2

    local_support = float(eff[first]) if first < len(eff) and np.isfinite(eff[first]) else 0.0
    low_support = local_support < min_support
    status = "crossing_low_support" if low_support else "crossing_ok"

    band_idx = np.where(finite & (p >= loose_band[0]) & (p <= loose_band[1]))[0]
    band_entry = float(radius_grid[band_idx[0]]) if len(band_idx) else np.nan

    return {
        "r_c": r_c,
        "crossing_status": status,
        "usable_crossing": not low_support,
        "low_support": low_support,
        "p_min": pmin,
        "p_max": pmax,
        "band_entry_radius": band_entry,
    }


def reconstruct_boundary(
    df: pd.DataFrame,
    radius_col: str,
    theta_col: str,
    failure_col: str,
    family_name: str,
    theta_samples: int = DEFAULT_THETA_SAMPLES,
    radial_samples: int = DEFAULT_RADIAL_SAMPLES,
    theta_bandwidth: float = DEFAULT_THETA_BW,
    radius_bandwidth: Optional[float] = None,
    threshold: float = THRESHOLD,
    loose_band: Tuple[float, float] = LOOSE_BAND,
) -> Tuple[pd.DataFrame, pd.DataFrame, Dict[str, object]]:
    radii = df[radius_col].to_numpy(dtype=float)
    failures = df[failure_col].to_numpy(dtype=int)

    rmin = float(np.nanmin(radii))
    rmax = float(np.nanmax(radii))
    theta_grid = np.linspace(0.0, 2.0 * np.pi, theta_samples, endpoint=False)
    radius_grid = np.linspace(rmin, rmax, radial_samples)

    if radius_bandwidth is None:
        span = max(rmax - rmin, 1e-9)
        radius_bandwidth = max(0.075 * span, 1e-6)

    p, eff = estimate_probability_surface(
        df=df,
        radius_col=radius_col,
        theta_col=theta_col,
        failure_col=failure_col,
        theta_grid=theta_grid,
        radius_grid=radius_grid,
        theta_bandwidth=theta_bandwidth,
        radius_bandwidth=radius_bandwidth,
    )

    regime = family_regime(int(np.sum(failures)), int(len(failures) - np.sum(failures)))

    boundary_rows = []
    for i, theta0 in enumerate(theta_grid):
        prof = p[i, :]
        ef = eff[i, :]
        crossing = extract_crossing(radius_grid, prof, ef, threshold, loose_band)
        boundary_rows.append({
            "family": family_name,
            "theta": float(theta0),
            "r_c": nanfloat(crossing["r_c"]),
            "band_entry_radius": nanfloat(crossing["band_entry_radius"]),
            "crossing_status": crossing["crossing_status"],
            "usable_crossing": bool(crossing["usable_crossing"]),
            "low_support": bool(crossing["low_support"]),
            "p_min": nanfloat(crossing["p_min"]),
            "p_max": nanfloat(crossing["p_max"]),
            "stable_theta": bool(np.isfinite(crossing["p_min"]) and np.isfinite(crossing["p_max"])),
        })

    joint_rows = []
    for i, theta0 in enumerate(theta_grid):
        for j, r0 in enumerate(radius_grid):
            joint_rows.append({
                "family": family_name,
                "theta": float(theta0),
                "radius": float(r0),
                "p_failure": nanfloat(p[i, j]),
                "effective_support": nanfloat(eff[i, j]),
            })

    boundary_df = pd.DataFrame(boundary_rows)
    joint_df = pd.DataFrame(joint_rows)

    status_counts = boundary_df["crossing_status"].value_counts(dropna=False).to_dict()
    stable_theta_samples = int(boundary_df["stable_theta"].sum())
    usable_crossing_theta_samples = int(boundary_df["usable_crossing"].sum())
    rc_vals = boundary_df["r_c"].to_numpy(dtype=float)

    summary = {
        "family": family_name,
        "status": "ok",
        "theta_samples": int(theta_samples),
        "radial_samples": int(radial_samples),
        "theta_bandwidth": float(theta_bandwidth),
        "radius_bandwidth": float(radius_bandwidth),
        "threshold": float(threshold),
        "loose_band": [float(loose_band[0]), float(loose_band[1])],
        "radius_min": float(rmin),
        "radius_max": float(rmax),
        "n_rows": int(len(df)),
        "n_failures": int(np.sum(failures)),
        "n_successes": int(len(failures) - np.sum(failures)),
        "family_regime": regime,
        "stable_theta_samples": stable_theta_samples,
        "usable_crossing_theta_samples": usable_crossing_theta_samples,
        "low_support_theta_samples": int(boundary_df["low_support"].sum()),
        "always_below_threshold_theta_samples": int(status_counts.get("always_below_threshold", 0)),
        "always_above_threshold_theta_samples": int(status_counts.get("always_above_threshold", 0)),
        "p_min_over_theta": nanfloat(np.nanmin(boundary_df["p_min"].to_numpy(dtype=float))),
        "p_max_over_theta": nanfloat(np.nanmax(boundary_df["p_max"].to_numpy(dtype=float))),
        "mean_r_c": nanfloat(np.nanmean(rc_vals)),
        "std_r_c": nanfloat(np.nanstd(rc_vals)),
        "crossing_status_counts": {str(k): int(v) for k, v in status_counts.items()},
    }
    return joint_df, boundary_df, summary


# -----------------------------------------------------------------------------
# Stability and comparison diagnostics
# -----------------------------------------------------------------------------
def run_stability_suite(
    df: pd.DataFrame,
    radius_col: str,
    theta_col: str,
    failure_col: str,
    family_name: str,
    base_theta_bw: float,
    base_radius_bw: float,
    default_boundary: pd.DataFrame,
) -> Dict[str, object]:
    theta_samples_grid = [72, 96, 120, 144]
    theta_bw_factors = [0.8, 1.0, 1.25]
    radius_bw_factors = [0.8, 1.0, 1.25]

    default_rc = default_boundary["r_c"].to_numpy(dtype=float)
    default_theta = default_boundary["theta"].to_numpy(dtype=float)

    variants = []
    rms_values = []

    for ts in theta_samples_grid:
        for tbf in theta_bw_factors:
            for rbf in radius_bw_factors:
                _, bdf, summary = reconstruct_boundary(
                    df=df,
                    radius_col=radius_col,
                    theta_col=theta_col,
                    failure_col=failure_col,
                    family_name=family_name,
                    theta_samples=ts,
                    radial_samples=DEFAULT_RADIAL_SAMPLES,
                    theta_bandwidth=base_theta_bw * tbf,
                    radius_bandwidth=base_radius_bw * rbf,
                )
                rc = np.interp(default_theta, bdf["theta"].to_numpy(dtype=float), bdf["r_c"].to_numpy(dtype=float), period=2.0 * np.pi)
                rms = rms_ignore_nan(default_rc, rc)
                rms_values.append(rms)
                variants.append({
                    "theta_samples": int(ts),
                    "theta_bw_factor": float(tbf),
                    "radius_bw_factor": float(rbf),
                    "rms_vs_default": nanfloat(rms),
                    "stable_theta_samples": int(summary["stable_theta_samples"]),
                    "usable_crossing_theta_samples": int(summary["usable_crossing_theta_samples"]),
                    "mean_band_entry_radius": nanfloat(np.nanmean(bdf["band_entry_radius"].to_numpy(dtype=float))),
                })

    return {
        "variants": variants,
        "rms_vs_default_mean": nanfloat(np.nanmean(np.asarray(rms_values, dtype=float))),
        "rms_vs_default_max": nanfloat(np.nanmax(np.asarray(rms_values, dtype=float))),
    }


def parse_v2_boundary(path: Optional[Path]) -> Optional[pd.DataFrame]:
    if path is None or not path.exists():
        return None
    old = pd.read_csv(path)
    theta_col = choose_column(old, ["theta_mid", "theta", "theta_bin_mid", "theta_center"], required=False)
    r_col = choose_column(old, ["estimated_r_critical", "r_c", "boundary_radius", "radius"], required=False)
    if theta_col is None or r_col is None:
        return None
    out = pd.DataFrame({
        "theta": pd.to_numeric(old[theta_col], errors="coerce"),
        "r_c_old": pd.to_numeric(old[r_col], errors="coerce"),
    }).dropna()
    if out.empty:
        return None
    out["theta"] = np.mod(out["theta"].to_numpy(dtype=float), 2.0 * np.pi)
    out = out.sort_values("theta").reset_index(drop=True)
    return out


def compare_to_v2(new_boundary: pd.DataFrame, old_v2: Optional[pd.DataFrame]) -> Dict[str, object]:
    if old_v2 is None or old_v2.empty:
        return {"available": False}
    theta_old = old_v2["theta"].to_numpy(dtype=float)
    r_old = old_v2["r_c_old"].to_numpy(dtype=float)
    theta_new = new_boundary["theta"].to_numpy(dtype=float)
    r_new = new_boundary["r_c"].to_numpy(dtype=float)
    interp_new = np.interp(theta_old, theta_new, r_new, period=2.0 * np.pi)
    interp_band = np.interp(theta_old, theta_new, new_boundary["band_entry_radius"].to_numpy(dtype=float), period=2.0 * np.pi)
    return {
        "available": True,
        "n_old_points": int(len(old_v2)),
        "rms_difference": nanfloat(rms_ignore_nan(interp_new, r_old)),
        "rms_difference_band_entry": nanfloat(rms_ignore_nan(interp_band, r_old)),
    }


# -----------------------------------------------------------------------------
# Notes writer
# -----------------------------------------------------------------------------
def build_notes(diag: Dict[str, object]) -> str:
    lines: List[str] = []
    lines.append(SCRIPT_TAG)
    lines.append("")
    lines.append("Summary")
    lines.append("-------")
    lines.append(
        "This third-round revision preserves the family classification from v2, "
        "but replaces raw slice crossing by a monotone radial profile extraction "
        "and also records entry into a looser transition band [0.4, 0.6]."
    )
    lines.append("")

    lines.append("Key classification")
    lines.append("------------------")
    lines.append(f"- Boundary-bearing families: {diag['boundary_families']}")
    lines.append(f"- Non-boundary families on sampled support: {diag['non_boundary_families']}")
    lines.append("")

    all_sum = diag["all_pool_summary"]
    lines.append("All-family pooled reconstruction")
    lines.append("--------------------------------")
    lines.append(f"- Stable theta samples: {all_sum['stable_theta_samples']}")
    lines.append(f"- Usable 0.5-crossing theta samples: {all_sum['usable_crossing_theta_samples']}")
    lines.append(f"- Mean boundary radius: {all_sum['mean_r_c']}")
    lines.append(f"- Boundary radius standard deviation: {all_sum['std_r_c']}")
    lines.append("")

    res_sum = diag["restricted_pool_summary"]
    lines.append("Restricted pooled reconstruction (boundary-bearing families only)")
    lines.append("-----------------------------------------------------------------")
    lines.append(f"- Stable theta samples: {res_sum['stable_theta_samples']}")
    lines.append(f"- Usable 0.5-crossing theta samples: {res_sum['usable_crossing_theta_samples']}")
    lines.append(f"- Mean boundary radius: {res_sum['mean_r_c']}")
    lines.append(f"- Boundary radius standard deviation: {res_sum['std_r_c']}")
    lines.append(f"- Mean RMS variation: {diag['restricted_pool_stability']['rms_vs_default_mean']}")
    lines.append(f"- Max RMS variation: {diag['restricted_pool_stability']['rms_vs_default_max']}")
    lines.append("")

    lines.append("Interpretation")
    lines.append("--------------")
    lines.append(
        "The universal pooled boundary remains absent because the indiscriminate "
        "pool never reaches the 0.5 failure threshold. This is now diagnosed as a "
        "structural consequence of mixing boundary-bearing and always-admissible families, "
        "not as a computational failure."
    )
    lines.append(
        "The restricted pooled branch remains the only defensible candidate for "
        "downstream law fitting. However, if the exact 0.5 crossing count remains small, "
        "then Stage-6E should treat the boundary as sparse-support and may benefit from "
        "using band-entry diagnostics alongside exact crossing radii."
    )
    lines.append("")

    lines.append("Family diagnostics")
    lines.append("------------------")
    for fam, fs in diag["family_stability"].items():
        d = fs["default"]
        lines.append(
            f"- {fam}: regime={d['family_regime']}, stable_theta_samples={d['stable_theta_samples']}, "
            f"usable_crossing_theta_samples={d['usable_crossing_theta_samples']}, "
            f"mean_stability_rms={fs['rms_vs_default_mean']}"
        )
    lines.append("")

    lines.append("Comparison with Stage-6D v2")
    lines.append("---------------------------")
    lines.append("Restricted pooled:")
    lines.append(json.dumps(diag["comparison_with_v2_restricted_pool"], indent=2))
    lines.append("")
    lines.append("Family-by-family:")
    lines.append(json.dumps(diag["comparison_with_v2_family"], indent=2))
    lines.append("")

    lines.append("Downstream comment")
    lines.append("------------------")
    lines.append(
        "This branch still does not fit a parametric law. It now offers three distinct "
        "objects for Stage-6E judgement: exact 0.5 crossings, transition-band entry radii, "
        "and the classification of which metric families genuinely carry a boundary at all."
    )
    return "\n".join(lines) + "\n"


# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------
def main() -> None:
    project_root = infer_project_root()
    log(f"Project root: {project_root}")
    inputs = resolve_inputs(project_root)
    outdir = project_root / "metric_stage_6D_branch1_outputs"
    ensure_dir(outdir)

    geom_path = inputs["geometry"]
    if geom_path is None:
        raise FileNotFoundError("Could not locate stage6D_inadmissibility_geometry_table_v2.csv")

    log("Loading row-level geometry table...")
    df, colmap = load_geometry_table(geom_path)
    radius_col = colmap["radius_col"]
    theta_col = colmap["theta_col"]
    failure_binary_col = colmap["failure_binary_col"]
    family_col = colmap["family_col"]

    log(f"Rows available after cleaning: {len(df)}")
    log(f"Radius column: {radius_col}")
    log(f"Theta column: {theta_col}")
    log(f"Failure source: {colmap['failure_col']}")
    log(f"Family column: {family_col}")

    fam_counts = df[family_col].value_counts().sort_index().to_dict()
    families = list(sorted(df[family_col].astype(str).unique()))

    family_results = {}
    family_joint = []
    family_boundary = []

    log("Reconstructing family-specific boundaries...")
    for fam in families:
        dff = df[df[family_col].astype(str) == fam].copy()
        joint_df, boundary_df, summary = reconstruct_boundary(
            df=dff,
            radius_col=radius_col,
            theta_col=theta_col,
            failure_col=failure_binary_col,
            family_name=fam,
        )
        base_radius_bw = summary["radius_bandwidth"]
        stability = run_stability_suite(
            df=dff,
            radius_col=radius_col,
            theta_col=theta_col,
            failure_col=failure_binary_col,
            family_name=fam,
            base_theta_bw=summary["theta_bandwidth"],
            base_radius_bw=base_radius_bw,
            default_boundary=boundary_df,
        )
        family_results[fam] = {"default": summary, **stability}
        family_joint.append(joint_df)
        family_boundary.append(boundary_df)

    boundary_families = [
        fam for fam in families if family_results[fam]["default"]["family_regime"] == "mixed"
    ]
    non_boundary_families = [fam for fam in families if fam not in boundary_families]

    log("Reconstructing all-family pooled boundary...")
    all_joint_df, all_boundary_df, all_summary = reconstruct_boundary(
        df=df,
        radius_col=radius_col,
        theta_col=theta_col,
        failure_col=failure_binary_col,
        family_name="ALL",
    )
    all_stability = run_stability_suite(
        df=df,
        radius_col=radius_col,
        theta_col=theta_col,
        failure_col=failure_binary_col,
        family_name="ALL",
        base_theta_bw=all_summary["theta_bandwidth"],
        base_radius_bw=all_summary["radius_bandwidth"],
        default_boundary=all_boundary_df,
    )

    restricted_df = df[df[family_col].astype(str).isin(boundary_families)].copy()
    log("Reconstructing restricted pooled boundary from boundary-bearing families...")
    res_joint_df, res_boundary_df, res_summary = reconstruct_boundary(
        df=restricted_df,
        radius_col=radius_col,
        theta_col=theta_col,
        failure_col=failure_binary_col,
        family_name="BOUNDARY_ONLY",
    )
    res_stability = run_stability_suite(
        df=restricted_df,
        radius_col=radius_col,
        theta_col=theta_col,
        failure_col=failure_binary_col,
        family_name="BOUNDARY_ONLY",
        base_theta_bw=res_summary["theta_bandwidth"],
        base_radius_bw=res_summary["radius_bandwidth"],
        default_boundary=res_boundary_df,
    )

    old_v2 = parse_v2_boundary(inputs["boundary_estimate_v2"])
    comp_all = compare_to_v2(all_boundary_df, old_v2)
    comp_res = compare_to_v2(res_boundary_df, old_v2)
    comp_family = {fam: compare_to_v2(
        next(b for b in family_boundary if not b.empty and str(b.iloc[0]["family"]) == fam),
        old_v2
    ) for fam in families}

    diag = {
        "script_tag": SCRIPT_TAG,
        "project_root": str(project_root),
        "cwd": str(Path.cwd().resolve()),
        "input_files": {k: (str(v) if v is not None else None) for k, v in inputs.items()},
        "column_map": {
            "radius_col": radius_col,
            "theta_col": theta_col,
            "failure_col": colmap["failure_col"],
            "family_col": family_col,
        },
        "family_counts": {str(k): int(v) for k, v in fam_counts.items()},
        "boundary_families": boundary_families,
        "non_boundary_families": non_boundary_families,
        "all_pool_stability": {"default": all_summary, **all_stability},
        "restricted_pool_stability": {"default": res_summary, **res_stability},
        "family_stability": family_results,
        "all_pool_summary": {
            "stable_theta_samples": int(all_summary["stable_theta_samples"]),
            "usable_crossing_theta_samples": int(all_summary["usable_crossing_theta_samples"]),
            "mean_r_c": all_summary["mean_r_c"],
            "std_r_c": all_summary["std_r_c"],
            "crossing_status_counts": all_summary["crossing_status_counts"],
            "family_regime": all_summary["family_regime"],
        },
        "restricted_pool_summary": {
            "stable_theta_samples": int(res_summary["stable_theta_samples"]),
            "usable_crossing_theta_samples": int(res_summary["usable_crossing_theta_samples"]),
            "mean_r_c": res_summary["mean_r_c"],
            "std_r_c": res_summary["std_r_c"],
            "crossing_status_counts": res_summary["crossing_status_counts"],
            "family_regime": res_summary["family_regime"],
        },
        "comparison_with_v2_all_pool": comp_all,
        "comparison_with_v2_restricted_pool": comp_res,
        "comparison_with_v2_family": comp_family,
    }

    notes = build_notes(diag)

    # Write outputs
    log("Writing outputs...")
    joint_out = pd.concat([all_joint_df, res_joint_df] + family_joint, ignore_index=True)
    boundary_out = pd.concat([all_boundary_df, res_boundary_df], ignore_index=True)
    family_boundary_out = pd.concat(family_boundary, ignore_index=True)

    joint_path = outdir / "stage6D_branch1_joint_density_refined.csv"
    boundary_path = outdir / "stage6D_branch1_boundary_estimate.csv"
    family_boundary_path = outdir / "stage6D_branch1_family_boundary.csv"
    diag_path = outdir / "stage6D_branch1_boundary_diagnostics.json"
    notes_path = outdir / "stage6D_branch1_interpretive_notes.txt"

    joint_out.to_csv(joint_path, index=False)
    boundary_out.to_csv(boundary_path, index=False)
    family_boundary_out.to_csv(family_boundary_path, index=False)
    with open(diag_path, "w", encoding="utf-8") as f:
        json.dump(diag, f, indent=2)
    with open(notes_path, "w", encoding="utf-8") as f:
        f.write(notes)

    log("Done.")
    log("Wrote:")
    log(f"  CSV : {joint_path}")
    log(f"  CSV : {boundary_path}")
    log(f"  CSV : {family_boundary_path}")
    log(f"  JSON: {diag_path}")
    log(f"  TXT : {notes_path}")


if __name__ == "__main__":
    main()
