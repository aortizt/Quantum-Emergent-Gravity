# -*- coding: utf-8 -*-
"""
Stage-6D v2
Quantum-Emergent Gravity
Author: Arturo Ortiz-Tapia
April 4th, 2026
Purpose
-------
Reconstruct the geometric admissibility structure of the radial_zscore
transformation in intrinsic coordinate space (r, theta), using row-level
metric definitions from Stage-6B plus intrinsic coordinates from Stage-5D.

This script is intentionally designed to resolve the limitation observed in
Stage-6D v1c:

    Stage-6C v2 does not preserve row keys needed to rejoin to Stage-5D.

Therefore, Stage-6D v2 reconstructs the radial_zscore admissibility geometry
directly from:
    - Stage-6B candidate metric evaluations (row-level)
    - Stage-5D preferred intrinsic coordinates
    - explicit radial_zscore domain logic by metric family

Outputs
-------
1) stage6D_inadmissibility_geometry_table_v2.csv
2) stage6D_radius_profile_v2.csv
3) stage6D_angle_profile_v2.csv
4) stage6D_joint_density_v2.csv
5) stage6D_boundary_estimate_v2.csv
6) stage6D_family_boundary_estimate_v2.csv
7) stage6D_family_geometry_summary_v2.csv
8) stage6D_symmetry_breaking_summary_v2.json
9) stage6D_interpretive_notes_v2.txt

Design notes
------------
- No silent drops.
- All joins are audited and logged.
- Fixed reproducible binning.
- Raw counts and probabilities both stored.
- Script does NOT claim curvature; it measures whether a curved boundary is
  empirically supported.
"""

from __future__ import annotations

import json
import math
import os
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd


# ============================================================
# CONFIGURATION
# ============================================================

PROJECT_ROOT = Path("/home/dakini/Downloads/010-Quantum_Emergent_Gravity")

STAGE5D_FILE = PROJECT_ROOT / "metric_stage_5D_outputs" / "stage5D_formalized_preferred_intrinsic_coordinate_v1b.csv"
STAGE6B_FILE = PROJECT_ROOT / "metric_stage_6B_outputs" / "stage6B_metric_evaluation_table_v1.csv"

OUTPUT_DIR = PROJECT_ROOT / "metric_stage_6D_outputs"

RADIUS_BINS = 20
ANGLE_BINS = 20

TARGET_TRANSFORMATION = "radial_zscore"

# Families explicitly expected from prior stages.
EXPECTED_FAMILIES = {
    "euclidean",
    "radial_weighted",
    "hybrid",
    "log_radial",
}

# FITs explicitly expected from prior stages.
EXPECTED_FITS = {
    "BARI",
    "NUFIT",
    "VALENCIA",
}


# ============================================================
# HELPER FUNCTIONS
# ============================================================

def _print(msg: str) -> None:
    print(msg, flush=True)


def require_file(path: Path, label: str) -> None:
    if not path.exists():
        raise FileNotFoundError(f"Required {label} not found: {path}")


def ensure_output_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def find_first_existing_column(df: pd.DataFrame, candidates: List[str], required: bool = True) -> Optional[str]:
    for col in candidates:
        if col in df.columns:
            return col
    if required:
        raise KeyError(f"None of the candidate columns were found: {candidates}")
    return None


def normalize_family_name(x: object) -> str:
    s = str(x).strip().lower()
    if s in {"log_radial", "log-radial", "log radial"}:
        return "log_radial"
    if s in {"radial_weighted", "radial-weighted", "radial weighted"}:
        return "radial_weighted"
    if s in {"hybrid"}:
        return "hybrid"
    if s in {"euclidean"}:
        return "euclidean"
    return s


def normalize_fit_name(x: object) -> str:
    return str(x).strip().upper()


def zscore_series(values: pd.Series) -> pd.Series:
    values = pd.to_numeric(values, errors="coerce")
    mu = values.mean()
    sigma = values.std(ddof=0)
    if pd.isna(mu) or pd.isna(sigma):
        return pd.Series(np.nan, index=values.index)
    if sigma == 0:
        return pd.Series(0.0, index=values.index)
    return (values - mu) / sigma


def infer_stage6b_schema(df: pd.DataFrame) -> Dict[str, Optional[str]]:
    """
    Infer the minimal schema needed from Stage-6B.

    Current Stage-6B is candidate-metric-level, not point-level:
    it has FIT + family/metric_name + alpha + beta, but no metric_id.
    """
    schema = {
        "fit": find_first_existing_column(df, ["FIT", "fit", "fit_name"]),
        "metric_id": find_first_existing_column(df, ["metric_id", "metric_id_int"], required=False),
        "family": find_first_existing_column(df, ["metric_family", "family", "metric_name"]),
        "alpha": find_first_existing_column(df, ["alpha"]),
        "beta": find_first_existing_column(df, ["beta"]),
    }
    return schema


def infer_stage5d_schema(df: pd.DataFrame) -> Dict[str, str]:
    schema = {
        "fit": find_first_existing_column(df, ["fit_name", "FIT", "fit"]),
        "metric_id": find_first_existing_column(df, ["metric_id", "metric_id_int"]),
        "radius": find_first_existing_column(df, ["radius_value"]),
        "angle": find_first_existing_column(df, ["angle_value_after_unfolding", "angle_value"]),
        "preferred_coordinate": find_first_existing_column(
            df,
            ["preferred_directional_coordinate"],
            required=False
        ),
        "pc1": find_first_existing_column(df, ["pc1_value"], required=False),
        "pc2": find_first_existing_column(df, ["pc2_value"], required=False),
    }
    return schema


def build_join_key(df: pd.DataFrame, fit_col: str, metric_id_col: str, prefix: str = "") -> pd.DataFrame:
    out = df.copy()
    out[f"{prefix}FIT_norm"] = out[fit_col].map(normalize_fit_name)
    out[f"{prefix}metric_id_norm"] = pd.to_numeric(out[metric_id_col], errors="coerce").astype("Int64")
    return out


def family_radial_transform(
    family: str,
    radius_raw: float,
    radius_z: float,
    alpha: float,
    beta: float
) -> Tuple[str, bool, str, float]:
    """
    Reconstruct the radial_zscore family-specific transformed radial quantity.

    Returns
    -------
    transformed_name : str
        Human-readable label for transformed radial formula.
    admissible : bool
        Whether the transformed quantity is valid in domain.
    reason : str
        "admissible" or explicit inadmissibility reason.
    transformed_value : float
        The transformed scalar if valid; NaN otherwise.

    Notes
    -----
    The goal here is not to recreate every downstream Stage-6C score.
    The goal is to reconstruct the domain logic underlying radial_zscore
    admissibility geometry.

    Chosen formulas are deliberately minimal and domain-explicit:
    - euclidean       : r_z
    - radial_weighted : alpha * r_z
    - hybrid          : sqrt(alpha * r_z + beta)
    - log_radial      : log(alpha * r_z + beta)

    With the default Stage-6 family grid, the sign/domain violations should
    reproduce the kind of family-level split observed in Stage-6D v1c.

    IMPORTANT:
    This script treats admissibility geometry as the preimage of the domain
    conditions for these family-specific transformed radial charts.
    """
    family = normalize_family_name(family)

    if pd.isna(radius_z) or pd.isna(alpha) or pd.isna(beta):
        return ("undefined", False, "missing_numeric_inputs", np.nan)

    if family == "euclidean":
        return ("r_z", True, "admissible", float(radius_z))

    if family == "radial_weighted":
        return ("alpha_times_r_z", True, "admissible", float(alpha * radius_z))

    arg = alpha * radius_z + beta

    if family == "hybrid":
        if arg < 0:
            return ("sqrt(alpha*r_z + beta)", False, "sqrt_negative_argument", np.nan)
        return ("sqrt(alpha*r_z + beta)", True, "admissible", float(math.sqrt(arg)))

    if family == "log_radial":
        if arg <= 0:
            return ("log(alpha*r_z + beta)", False, "log_nonpositive_radius", np.nan)
        return ("log(alpha*r_z + beta)", True, "admissible", float(math.log(arg)))

    return ("unsupported_family", False, "unsupported_family", np.nan)


def make_fixed_bin_edges(values: pd.Series, n_bins: int) -> np.ndarray:
    vals = pd.to_numeric(values, errors="coerce").dropna().to_numpy()
    if vals.size == 0:
        raise ValueError("Cannot build bin edges from empty series.")
    vmin = float(np.min(vals))
    vmax = float(np.max(vals))
    if vmin == vmax:
        eps = 1e-9 if vmin == 0 else abs(vmin) * 1e-9
        return np.linspace(vmin - eps, vmax + eps, n_bins + 1)
    return np.linspace(vmin, vmax, n_bins + 1)


def cut_with_index(values: pd.Series, edges: np.ndarray, include_lowest: bool = True) -> pd.Categorical:
    return pd.cut(values, bins=edges, include_lowest=include_lowest, duplicates="drop")


def summarize_1d_profile(
    df: pd.DataFrame,
    bin_col: str,
    value_col: str = "inadmissible"
) -> pd.DataFrame:
    grouped = (
        df.groupby(bin_col, dropna=False, observed=False)
        .agg(
            count_total=(value_col, "size"),
            count_failure=(value_col, "sum")
        )
        .reset_index()
    )
    grouped["probability_failure"] = grouped["count_failure"] / grouped["count_total"]
    return grouped


def summarize_2d_profile(
    df: pd.DataFrame,
    r_bin_col: str,
    theta_bin_col: str,
    value_col: str = "inadmissible"
) -> pd.DataFrame:
    grouped = (
        df.groupby([r_bin_col, theta_bin_col], dropna=False)
        .agg(
            count_total=(value_col, "size"),
            count_failure=(value_col, "sum")
        )
        .reset_index()
    )
    grouped["probability_failure"] = grouped["count_failure"] / grouped["count_total"]
    return grouped


def interval_midpoint(interval_obj) -> float:
    if pd.isna(interval_obj):
        return np.nan
    return float((interval_obj.left + interval_obj.right) / 2.0)


def estimate_boundary_from_joint_density(
    joint_df: pd.DataFrame,
    theta_bin_col: str,
    r_bin_col: str,
    prob_col: str = "probability_failure",
) -> pd.DataFrame:
    """
    For each theta bin, estimate r_critical as the radius-bin midpoint whose
    failure probability is closest to 0.5.

    This is not a claim of smooth curvature; it is an empirical transition
    estimate.
    """
    rows = []
    for theta_bin, sub in joint_df.groupby(theta_bin_col, dropna=False):
        sub = sub.copy()
        sub["r_mid"] = sub[r_bin_col].map(interval_midpoint)
        sub["theta_mid"] = sub[theta_bin_col].map(interval_midpoint)
        sub = sub.dropna(subset=["r_mid", "theta_mid", prob_col])

        if sub.empty:
            rows.append({
                "theta_bin": theta_bin,
                "theta_mid": np.nan,
                "estimated_r_critical": np.nan,
                "boundary_support_count": 0,
                "mean_probability_on_selected_bin": np.nan,
            })
            continue

        sub["distance_to_half"] = (sub[prob_col] - 0.5).abs()
        best = sub.sort_values(["distance_to_half", "count_total"], ascending=[True, False]).iloc[0]

        rows.append({
            "theta_bin": theta_bin,
            "theta_mid": float(best["theta_mid"]),
            "estimated_r_critical": float(best["r_mid"]),
            "boundary_support_count": int(best["count_total"]),
            "mean_probability_on_selected_bin": float(best[prob_col]),
        })

    out = pd.DataFrame(rows)
    return out.sort_values("theta_mid", kind="stable").reset_index(drop=True)


def classify_geometry_shape(
    boundary_df: pd.DataFrame,
    radius_profile_df: pd.DataFrame,
    angle_profile_df: pd.DataFrame
) -> Dict[str, object]:
    """
    Coarse classification only. This avoids overclaiming.

    Heuristics:
    - If boundary estimate varies very little across theta: radial-threshold-like
    - If angle profile dominates and boundary estimate unavailable: angular-sector-like
    - If boundary varies materially across theta: curved-boundary-like
    """
    out = {
        "geometry_classification": "undetermined",
        "notes": [],
    }

    b = boundary_df.dropna(subset=["theta_mid", "estimated_r_critical"]).copy()
    if len(b) >= 4:
        r_std = float(b["estimated_r_critical"].std(ddof=0))
        r_mean_abs = float(np.maximum(np.abs(b["estimated_r_critical"]).mean(), 1e-12))
        rel_std = r_std / r_mean_abs

        out["boundary_relative_std"] = rel_std

        if rel_std < 0.05:
            out["geometry_classification"] = "radial_threshold_like"
            out["notes"].append("Estimated critical radius is nearly constant across theta bins.")
        else:
            out["geometry_classification"] = "curved_boundary_like"
            out["notes"].append("Estimated critical radius varies materially across theta bins.")
        return out

    angle_nontrivial = False
    if not angle_profile_df.empty:
        probs = angle_profile_df["probability_failure"].dropna().to_numpy()
        if probs.size >= 4 and (float(np.max(probs)) - float(np.min(probs))) > 0.25:
            angle_nontrivial = True

    if angle_nontrivial:
        out["geometry_classification"] = "angular_sector_like"
        out["notes"].append("Failure probability varies materially across angle bins.")
    else:
        out["geometry_classification"] = "no_clear_structure"
        out["notes"].append("Insufficient evidence for radial, angular, or curved boundary from current binning.")

    return out


def dataframe_to_interval_strings(df: pd.DataFrame, interval_cols: List[str]) -> pd.DataFrame:
    out = df.copy()
    for col in interval_cols:
        if col in out.columns:
            out[col] = out[col].astype(str)
    return out


# ============================================================
# MAIN
# ============================================================

def main() -> None:
    _print("[Stage-6D v2 PRECHECK] Creating output directory...")
    ensure_output_dir(OUTPUT_DIR)

    _print("[Stage-6D v2 PRECHECK] Checking required files...")
    require_file(STAGE5D_FILE, "Stage-5D coordinate file")
    require_file(STAGE6B_FILE, "Stage-6B metric-evaluation table")

    _print("[Stage-6D v2 PRECHECK] Loading Stage-5D and Stage-6B tables...")
    stage5d = pd.read_csv(STAGE5D_FILE)
    stage6b = pd.read_csv(STAGE6B_FILE)

    _print("[Stage-6D v2 PRECHECK] Stage-5D columns:")
    _print(str(stage5d.columns.tolist()))

    _print("[Stage-6D v2 PRECHECK] Stage-6B columns:")
    _print(str(stage6b.columns.tolist()))

    schema5d = infer_stage5d_schema(stage5d)
    schema6b = infer_stage6b_schema(stage6b)

    _print("[Stage-6D v2 PRECHECK] Normalizing schemas and keys...")

    # Stage-5D is point-level and does have metric_id
    stage5d = build_join_key(stage5d, schema5d["fit"], schema5d["metric_id"], prefix="s5d_")

    # Stage-6B is candidate-metric-level and may NOT have metric_id
    stage6b = stage6b.copy()
    stage6b["s6b_FIT_norm"] = stage6b[schema6b["fit"]].map(normalize_fit_name)

    stage5d["radius_value"] = pd.to_numeric(stage5d[schema5d["radius"]], errors="coerce")
    stage5d["angle_value_after_unfolding"] = pd.to_numeric(stage5d[schema5d["angle"]], errors="coerce")

    stage6b["family_norm"] = stage6b[schema6b["family"]].map(normalize_family_name)
    stage6b["FIT_norm"] = stage6b["s6b_FIT_norm"]

    stage5d["FIT_norm"] = stage5d["s5d_FIT_norm"]
    stage5d["metric_id_norm"] = stage5d["s5d_metric_id_norm"]

    # Restrict to expected family universe if present; otherwise keep all and report.
    found_families = set(stage6b["family_norm"].dropna().unique().tolist())
    found_fits = set(stage6b["FIT_norm"].dropna().unique().tolist())

    _print(f"[Stage-6D v2 PRECHECK] Families found in Stage-6B: {sorted(found_families)}")
    _print(f"[Stage-6D v2 PRECHECK] FITs found in Stage-6B: {sorted(found_fits)}")

    _print("[Stage-6D v2] Expanding Stage-6B metric definitions across Stage-5D coordinates within each FIT...")

    s5d_join = stage5d[[
        "FIT_norm",
        "metric_id_norm",
        "radius_value",
        "angle_value_after_unfolding"
    ]].drop_duplicates()

    geometry = stage6b.merge(
        s5d_join,
        how="inner",
        on="FIT_norm",
        indicator=True
    )

    join_counts = geometry["_merge"].value_counts(dropna=False).to_dict()
    unmatched_count = int((geometry["_merge"] != "both").sum())

    _print(f"[Stage-6D v2] Expansion counts: {join_counts}")
    _print(f"[Stage-6D v2] Unmatched Stage-6B rows after FIT-level expansion: {unmatched_count}")

    if unmatched_count > 0:
        _print("[Stage-6D v2 WARNING] Some Stage-6B rows could not be expanded against Stage-5D coordinates.")

    # Family / FIT housekeeping
    geometry["family"] = geometry["family_norm"]
    geometry["FIT"] = geometry["FIT_norm"]
    geometry["metric_id"] = geometry["metric_id_norm"]

    geometry["alpha"] = pd.to_numeric(geometry[schema6b["alpha"]], errors="coerce")
    geometry["beta"] = pd.to_numeric(geometry[schema6b["beta"]], errors="coerce")

    # Build per-(FIT,family) radial z-score
    _print("[Stage-6D v2] Computing radial_zscore within each (FIT, family) block...")
    geometry["radius_zscore"] = (
        geometry.groupby(["FIT", "family", "alpha", "beta"], group_keys=False)["radius_value"]
        .apply(zscore_series)
    )

    _print("[Stage-6D v2] Reconstructing family-specific radial_zscore admissibility...")
    transformed_names = []
    admissible_flags = []
    failure_reasons = []
    transformed_values = []

    for _, row in geometry.iterrows():
        t_name, admissible, reason, t_value = family_radial_transform(
            family=row["family"],
            radius_raw=row["radius_value"],
            radius_z=row["radius_zscore"],
            alpha=row["alpha"],
            beta=row["beta"]
        )
        transformed_names.append(t_name)
        admissible_flags.append(bool(admissible))
        failure_reasons.append(reason)
        transformed_values.append(t_value)

    geometry["transformation_type"] = TARGET_TRANSFORMATION
    geometry["transformed_radial_formula"] = transformed_names
    geometry["admissible"] = admissible_flags
    geometry["inadmissible"] = ~geometry["admissible"]
    geometry["failure_reason"] = failure_reasons
    geometry["transformed_radial_value"] = transformed_values

    # Bring forward a soft stability field if available.
    invariance_col = find_first_existing_column(
        geometry,
        ["overall_invariance_score", "aggregate_score", "score"],
        required=False
    )
    if invariance_col is not None:
        geometry["invariance_score"] = pd.to_numeric(geometry[invariance_col], errors="coerce")
    else:
        geometry["invariance_score"] = np.nan

    _print("[Stage-6D v2] Building geometry-ready subset (matched rows only)...")
    geom_ready = geometry.loc[
        geometry["_merge"] == "both",
        [
            "FIT",
            "metric_id",
            "family",
            "alpha",
            "beta",
            "radius_value",
            "angle_value_after_unfolding",
            "radius_zscore",
            "transformation_type",
            "transformed_radial_formula",
            "transformed_radial_value",
            "admissible",
            "inadmissible",
            "failure_reason",
            "invariance_score",
        ]
    ].copy()

    total_geom_rows = len(geom_ready)
    total_failures = int(geom_ready["inadmissible"].sum())
    total_admissible = int(geom_ready["admissible"].sum())

    _print(f"[Stage-6D v2] Geometry-ready rows: {total_geom_rows}")
    _print(f"[Stage-6D v2] Admissible rows   : {total_admissible}")
    _print(f"[Stage-6D v2] Inadmissible rows : {total_failures}")

    if geom_ready.empty:
        raise RuntimeError("No geometry-ready rows survived the Stage-6B ↔ Stage-5D join.")

    # Fixed reproducible binning over geometry-ready rows.
    _print("[Stage-6D v2] Computing fixed radius and angle bins...")
    r_edges = make_fixed_bin_edges(geom_ready["radius_value"], RADIUS_BINS)
    theta_edges = make_fixed_bin_edges(geom_ready["angle_value_after_unfolding"], ANGLE_BINS)

    geom_ready["radius_bin"] = cut_with_index(geom_ready["radius_value"], r_edges)
    geom_ready["angle_bin"] = cut_with_index(geom_ready["angle_value_after_unfolding"], theta_edges)

    # 1D profiles
    _print("[Stage-6D v2] Building radius and angle failure profiles...")
    radius_profile = summarize_1d_profile(geom_ready, "radius_bin")
    radius_profile["radius_mid"] = radius_profile["radius_bin"].map(interval_midpoint)

    angle_profile = summarize_1d_profile(geom_ready, "angle_bin")
    angle_profile["angle_mid"] = angle_profile["angle_bin"].map(interval_midpoint)

    # 2D joint profile
    _print("[Stage-6D v2] Building joint (r, theta) density...")
    joint_density = summarize_2d_profile(geom_ready, "radius_bin", "angle_bin")
    joint_density["radius_mid"] = joint_density["radius_bin"].map(interval_midpoint)
    joint_density["angle_mid"] = joint_density["angle_bin"].map(interval_midpoint)

    # Boundary estimate: all families together
    _print("[Stage-6D v2] Estimating empirical boundary...")
    boundary_estimate = estimate_boundary_from_joint_density(
        joint_density,
        theta_bin_col="angle_bin",
        r_bin_col="radius_bin",
        prob_col="probability_failure",
    )

    # Family-specific joint densities and boundary estimates
    _print("[Stage-6D v2] Building family-specific geometry summaries...")
    family_summary_rows = []
    family_boundary_frames = []

    for fam in sorted(geom_ready["family"].dropna().unique().tolist()):
        sub = geom_ready.loc[geom_ready["family"] == fam].copy()
        if sub.empty:
            continue

        fam_joint = summarize_2d_profile(sub, "radius_bin", "angle_bin")
        fam_boundary = estimate_boundary_from_joint_density(
            fam_joint,
            theta_bin_col="angle_bin",
            r_bin_col="radius_bin",
            prob_col="probability_failure",
        )
        fam_boundary["family"] = fam
        family_boundary_frames.append(fam_boundary)

        family_summary_rows.append({
            "family": fam,
            "count_total": int(len(sub)),
            "count_admissible": int(sub["admissible"].sum()),
            "count_inadmissible": int(sub["inadmissible"].sum()),
            "failure_rate": float(sub["inadmissible"].mean()),
            "distinct_failure_reasons": "|".join(sorted(sub.loc[sub["inadmissible"], "failure_reason"].dropna().unique().tolist())),
            "mean_radius_failure": float(sub.loc[sub["inadmissible"], "radius_value"].mean()) if sub["inadmissible"].any() else np.nan,
            "mean_radius_admissible": float(sub.loc[sub["admissible"], "radius_value"].mean()) if sub["admissible"].any() else np.nan,
            "mean_invariance_score_admissible": float(sub.loc[sub["admissible"], "invariance_score"].mean()) if sub["admissible"].any() else np.nan,
        })

    family_geometry_summary = pd.DataFrame(family_summary_rows)
    family_boundary_estimate = (
        pd.concat(family_boundary_frames, ignore_index=True)
        if family_boundary_frames else
        pd.DataFrame(columns=["family", "theta_bin", "theta_mid", "estimated_r_critical", "boundary_support_count", "mean_probability_on_selected_bin"])
    )

    # Global geometry classification
    geometry_class = classify_geometry_shape(
        boundary_df=boundary_estimate,
        radius_profile_df=radius_profile,
        angle_profile_df=angle_profile
    )

    # JSON summary
    summary = {
        "stage": "Stage-6D v2",
        "analysis_scope": "Geometric admissibility reconstruction for radial_zscore in intrinsic coordinate space",
        "inputs": {
            "stage5d_file": str(STAGE5D_FILE),
            "stage6b_file": str(STAGE6B_FILE),
        },
        "join_audit": {
            "stage6b_total_rows": int(len(stage6b)),
            "stage5d_total_rows": int(len(stage5d)),
            "join_counts": {str(k): int(v) for k, v in join_counts.items()},
            "unmatched_rows": int(unmatched_count),
            "matched_rows_used_for_geometry": int(total_geom_rows),
        },
        "counts": {
            "geometry_ready_total_rows": int(total_geom_rows),
            "admissible_rows": int(total_admissible),
            "inadmissible_rows": int(total_failures),
        },
        "families_observed": sorted(geom_ready["family"].dropna().unique().tolist()),
        "fits_observed": sorted(geom_ready["FIT"].dropna().unique().tolist()),
        "failure_reasons": (
            geom_ready.loc[geom_ready["inadmissible"], "failure_reason"]
            .value_counts(dropna=False)
            .to_dict()
        ),
        "binning": {
            "radius_bins": int(RADIUS_BINS),
            "angle_bins": int(ANGLE_BINS),
            "radius_min": float(np.nanmin(geom_ready["radius_value"].to_numpy())),
            "radius_max": float(np.nanmax(geom_ready["radius_value"].to_numpy())),
            "angle_min": float(np.nanmin(geom_ready["angle_value_after_unfolding"].to_numpy())),
            "angle_max": float(np.nanmax(geom_ready["angle_value_after_unfolding"].to_numpy())),
        },
        "geometry_classification": geometry_class,
    }

    # Interpretive notes
    notes_lines = []
    notes_lines.append("============================================================")
    notes_lines.append("Stage-6D v2 Interpretive Notes")
    notes_lines.append("============================================================")
    notes_lines.append("")
    notes_lines.append("Purpose:")
    notes_lines.append("  Reconstruct the radial_zscore admissibility geometry directly")
    notes_lines.append("  in intrinsic coordinate space (radius, angle).")
    notes_lines.append("")
    notes_lines.append("Methodological correction relative to Stage-6D v1c:")
    notes_lines.append("  Stage-6C v2 did not preserve row keys needed for coordinate")
    notes_lines.append("  rejoin. Therefore this v2 stage reconstructs geometry from")
    notes_lines.append("  Stage-6B row-level metric definitions plus Stage-5D intrinsic")
    notes_lines.append("  coordinates, using explicit family-wise radial_zscore domain logic.")
    notes_lines.append("")
    notes_lines.append("Join audit:")
    notes_lines.append(f"  Stage-6B total rows              : {len(stage6b)}")
    notes_lines.append(f"  Stage-5D total rows              : {len(stage5d)}")
    notes_lines.append(f"  Matched geometry-ready rows      : {total_geom_rows}")
    notes_lines.append(f"  Unmatched rows                   : {unmatched_count}")
    notes_lines.append("")
    notes_lines.append("Global admissibility counts:")
    notes_lines.append(f"  admissible rows                  : {total_admissible}")
    notes_lines.append(f"  inadmissible rows                : {total_failures}")
    notes_lines.append("")
    notes_lines.append("Family summary:")
    if family_geometry_summary.empty:
        notes_lines.append("  No family-level geometry summary available.")
    else:
        for _, row in family_geometry_summary.iterrows():
            notes_lines.append(
                f"  {row['family']}: total={int(row['count_total'])}, "
                f"admissible={int(row['count_admissible'])}, "
                f"inadmissible={int(row['count_inadmissible'])}, "
                f"failure_rate={row['failure_rate']:.6f}, "
                f"reasons={row['distinct_failure_reasons']}"
            )
    notes_lines.append("")
    notes_lines.append("Empirical geometry classification:")
    notes_lines.append(f"  classification                  : {geometry_class['geometry_classification']}")
    for msg in geometry_class.get("notes", []):
        notes_lines.append(f"  note                            : {msg}")
    if "boundary_relative_std" in geometry_class:
        notes_lines.append(f"  boundary_relative_std           : {geometry_class['boundary_relative_std']:.6f}")
    notes_lines.append("")
    notes_lines.append("Interpretive caution:")
    notes_lines.append("  This script estimates an empirical admissibility boundary from")
    notes_lines.append("  the preimage of family-specific radial_zscore domain conditions.")
    notes_lines.append("  It does not by itself prove physical curvature. A 'curved'")
    notes_lines.append("  interpretation is justified only if the estimated critical radius")
    notes_lines.append("  varies materially with angle and this variation is stable under")
    notes_lines.append("  reasonable bin refinements.")
    notes_lines.append("")
    notes_lines.append("Physical reading:")
    notes_lines.append("  If the boundary is nearly constant in radius, the result is best")
    notes_lines.append("  interpreted as a radial threshold.")
    notes_lines.append("  If failure localizes in angular windows, the result is better read")
    notes_lines.append("  as sector exclusion or directional degeneracy.")
    notes_lines.append("  If the critical radius depends nontrivially on angle, then the")
    notes_lines.append("  admissibility frontier behaves like a curved intrinsic locus.")
    notes_lines.append("")
    notes_lines.append("Next step:")
    notes_lines.append("  Stage-6E should only formalize a geometric law after inspecting:")
    notes_lines.append("    (1) boundary_estimate_v2.csv")
    notes_lines.append("    (2) family_boundary_estimate_v2.csv")
    notes_lines.append("    (3) joint_density_v2.csv")
    notes_lines.append("")
    notes_lines.append("============================================================")

    # Save outputs
    _print("[Stage-6D v2] Writing outputs...")

    geometry_out = dataframe_to_interval_strings(geom_ready, ["radius_bin", "angle_bin"])
    radius_profile_out = dataframe_to_interval_strings(radius_profile, ["radius_bin"])
    angle_profile_out = dataframe_to_interval_strings(angle_profile, ["angle_bin"])
    joint_density_out = dataframe_to_interval_strings(joint_density, ["radius_bin", "angle_bin"])
    boundary_estimate_out = dataframe_to_interval_strings(boundary_estimate, ["theta_bin"])
    family_boundary_estimate_out = dataframe_to_interval_strings(family_boundary_estimate, ["theta_bin"])

    p1 = OUTPUT_DIR / "stage6D_inadmissibility_geometry_table_v2.csv"
    p2 = OUTPUT_DIR / "stage6D_radius_profile_v2.csv"
    p3 = OUTPUT_DIR / "stage6D_angle_profile_v2.csv"
    p4 = OUTPUT_DIR / "stage6D_joint_density_v2.csv"
    p5 = OUTPUT_DIR / "stage6D_boundary_estimate_v2.csv"
    p6 = OUTPUT_DIR / "stage6D_family_boundary_estimate_v2.csv"
    p7 = OUTPUT_DIR / "stage6D_family_geometry_summary_v2.csv"
    p8 = OUTPUT_DIR / "stage6D_symmetry_breaking_summary_v2.json"
    p9 = OUTPUT_DIR / "stage6D_interpretive_notes_v2.txt"

    geometry_out.to_csv(p1, index=False)
    radius_profile_out.to_csv(p2, index=False)
    angle_profile_out.to_csv(p3, index=False)
    joint_density_out.to_csv(p4, index=False)
    boundary_estimate_out.to_csv(p5, index=False)
    family_boundary_estimate_out.to_csv(p6, index=False)
    family_geometry_summary.to_csv(p7, index=False)

    with open(p8, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)

    with open(p9, "w", encoding="utf-8") as f:
        f.write("\n".join(notes_lines))

    _print("[Stage-6D v2] Done.")
    _print(f"[Stage-6D v2] Wrote: {p1}")
    _print(f"[Stage-6D v2] Wrote: {p2}")
    _print(f"[Stage-6D v2] Wrote: {p3}")
    _print(f"[Stage-6D v2] Wrote: {p4}")
    _print(f"[Stage-6D v2] Wrote: {p5}")
    _print(f"[Stage-6D v2] Wrote: {p6}")
    _print(f"[Stage-6D v2] Wrote: {p7}")
    _print(f"[Stage-6D v2] Wrote: {p8}")
    _print(f"[Stage-6D v2] Wrote: {p9}")


if __name__ == "__main__":
    main()
