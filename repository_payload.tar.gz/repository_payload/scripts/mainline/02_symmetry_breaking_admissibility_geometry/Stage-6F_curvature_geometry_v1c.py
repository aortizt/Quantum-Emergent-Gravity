#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Author: Arturo Ortiz-Tapia
Date: 2026-04-12, 20:46 hrs
Stage-6F: curvature / anisotropy analysis for restricted boundary law
Project: Quantum-Emergent Gravity
Upstream: Stage-6E v2b (branch1 restricted fit)

Spyder-ready script.

Purpose
-------
Interpret the fitted boundary law r_c(theta) as a polar boundary curve on its
restricted support, compute stable local geometric quantities, compare them to
refined transition density, and write Stage-6F outputs.

Outputs
-------
metric_stage_6F_outputs/
    stage6F_curvature_profile.csv
    stage6F_anisotropy_summary.json
    stage6F_geometry_notes.txt

Important scope note
--------------------
This script does NOT impose periodic closure and does NOT extrapolate outside
observed angular support. All derivatives are computed only on the restricted
support of the fitted boundary curve.
"""

from __future__ import annotations

import json
import math
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd


# -----------------------------------------------------------------------------
# Configuration
# -----------------------------------------------------------------------------

PROJECT_ROOT = Path("/home/dakini/Downloads/010-Quantum_Emergent_Gravity")

INPUT_BOUNDARY_CURVE = PROJECT_ROOT / "metric_stage_6E_v2_outputs" / "stage6E_boundary_curve_v2.csv"
INPUT_MODEL_COMPARISON = PROJECT_ROOT / "metric_stage_6E_v2_outputs" / "stage6E_model_comparison_v2.csv"
INPUT_RESIDUAL_TABLE = PROJECT_ROOT / "metric_stage_6E_v2_outputs" / "stage6E_residual_table_v2.csv"
INPUT_JOINT_DENSITY = PROJECT_ROOT / "metric_stage_6D_branch1_outputs" / "stage6D_branch1_joint_density_refined.csv"

OUTPUT_DIR = PROJECT_ROOT / "metric_stage_6F_outputs"
OUTPUT_CURVATURE_PROFILE = OUTPUT_DIR / "stage6F_curvature_profile.csv"
OUTPUT_ANISOTROPY_SUMMARY = OUTPUT_DIR / "stage6F_anisotropy_summary.json"
OUTPUT_GEOMETRY_NOTES = OUTPUT_DIR / "stage6F_geometry_notes.txt"

LOCAL_POLY_WINDOW = 7        # odd integer >= 5 recommended
HIGH_CURVATURE_QUANTILE = 0.80
VERY_HIGH_CURVATURE_QUANTILE = 0.90
HIGH_DENSITY_QUANTILE = 0.80
ROUND_DIGITS = 8


# -----------------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------------


def _print(msg: str) -> None:
    print(msg, flush=True)


@dataclass
class ColumnMatch:
    theta: str
    radius: str


@dataclass
class DensityColumnMatch:
    theta: str
    weight: str
    radius: Optional[str]
    support: Optional[str] = None


PREFERRED_THETA_NAMES = [
    "theta",
    "theta_center",
    "theta_mid",
    "theta_bin_center",
    "theta_value",
    "angle",
    "angle_center",
    "preferred_directional_coordinate",
]

PREFERRED_RADIUS_NAMES = [
    "r_fit",
    "r_boundary",
    "r_hat",
    "r_model",
    "radius_fit",
    "radius_boundary",
    "radius_value",
    "r",
    "radius",
]

PREFERRED_WEIGHT_NAMES = [
    "joint_density",
    "density",
    "count",
    "counts",
    "mass",
    "weight",
    "probability",
    "pdf",
    "hist_density",
    "p_failure",
    "failure_probability",
    "prob_failure",
]

PREFERRED_SUPPORT_NAMES = [
    "effective_support",
    "support",
    "n_support",
    "sample_support",
    "count_support",
]


def find_first_existing(paths: Sequence[Path]) -> Path:
    for p in paths:
        if p.exists():
            return p
    raise FileNotFoundError("None of the expected paths exists:\n  - " + "\n  - ".join(str(p) for p in paths))



def normalize_numeric_series(s: pd.Series) -> pd.Series:
    return pd.to_numeric(s, errors="coerce")



def pick_column(df: pd.DataFrame, preferred: Sequence[str], role: str) -> str:
    lower_map = {c.lower(): c for c in df.columns}
    for name in preferred:
        if name.lower() in lower_map:
            return lower_map[name.lower()]

    numeric_cols = []
    for c in df.columns:
        numeric = pd.to_numeric(df[c], errors="coerce")
        if numeric.notna().sum() >= max(5, int(0.5 * len(df))):
            numeric_cols.append(c)

    if len(numeric_cols) == 1:
        return numeric_cols[0]

    raise KeyError(
        f"Could not identify '{role}' column. Available columns: {list(df.columns)}"
    )



def infer_boundary_columns(df: pd.DataFrame) -> ColumnMatch:
    theta_col = pick_column(df, PREFERRED_THETA_NAMES, role="theta")

    radius_candidates = [c for c in df.columns if c != theta_col]
    radius_col = None
    lower_map = {c.lower(): c for c in radius_candidates}
    for name in PREFERRED_RADIUS_NAMES:
        if name.lower() in lower_map:
            radius_col = lower_map[name.lower()]
            break

    if radius_col is None:
        numeric_candidates = []
        for c in radius_candidates:
            numeric = pd.to_numeric(df[c], errors="coerce")
            if numeric.notna().sum() >= max(5, int(0.5 * len(df))):
                numeric_candidates.append(c)
        if len(numeric_candidates) == 1:
            radius_col = numeric_candidates[0]

    if radius_col is None:
        raise KeyError(
            "Could not identify radius column in boundary curve table. "
            f"Available columns: {list(df.columns)}"
        )

    return ColumnMatch(theta=theta_col, radius=radius_col)



def infer_density_columns(df: pd.DataFrame) -> DensityColumnMatch:
    theta_col = pick_column(df, PREFERRED_THETA_NAMES, role="theta")

    weight_col = None
    lower_map = {c.lower(): c for c in df.columns if c != theta_col}
    for name in PREFERRED_WEIGHT_NAMES:
        if name.lower() in lower_map:
            weight_col = lower_map[name.lower()]
            break

    if weight_col is None:
        numeric_candidates = []
        for c in df.columns:
            if c == theta_col:
                continue
            numeric = pd.to_numeric(df[c], errors="coerce")
            if numeric.notna().sum() >= max(5, int(0.5 * len(df))):
                numeric_candidates.append(c)

        radius_name_set = {x.lower() for x in PREFERRED_RADIUS_NAMES}
        support_name_set = {x.lower() for x in PREFERRED_SUPPORT_NAMES}
        preferred_non_radius = [
            c for c in numeric_candidates
            if c.lower() not in radius_name_set and c.lower() not in support_name_set
        ]
        if len(preferred_non_radius) == 1:
            weight_col = preferred_non_radius[0]
        elif len(numeric_candidates) == 1:
            weight_col = numeric_candidates[0]

    if weight_col is None:
        raise KeyError(
            "Could not identify density/weight column in joint density table. "
            f"Available columns: {list(df.columns)}"
        )

    radius_col = None
    for name in PREFERRED_RADIUS_NAMES:
        if name.lower() in lower_map and lower_map[name.lower()] != weight_col:
            radius_col = lower_map[name.lower()]
            break

    support_col = None
    for name in PREFERRED_SUPPORT_NAMES:
        if name.lower() in lower_map and lower_map[name.lower()] not in {weight_col, radius_col}:
            support_col = lower_map[name.lower()]
            break

    return DensityColumnMatch(theta=theta_col, weight=weight_col, radius=radius_col, support=support_col)



def sort_and_clean_boundary(df: pd.DataFrame, cols: ColumnMatch) -> pd.DataFrame:
    out = pd.DataFrame({
        "theta": normalize_numeric_series(df[cols.theta]),
        "r": normalize_numeric_series(df[cols.radius]),
    })
    out = out.dropna().copy()
    out = out[np.isfinite(out["theta"]) & np.isfinite(out["r"])].copy()
    out = out.sort_values("theta").drop_duplicates(subset=["theta"], keep="first").reset_index(drop=True)
    if len(out) < 5:
        raise ValueError("Boundary curve table has fewer than 5 valid theta/r samples after cleaning.")
    if (out["r"] <= 0).any():
        raise ValueError("Boundary curve contains non-positive radius values; Stage-6F expects positive radii.")
    return out



def clean_density(df: pd.DataFrame, cols: DensityColumnMatch) -> pd.DataFrame:
    data = {
        "theta": normalize_numeric_series(df[cols.theta]),
        "weight": normalize_numeric_series(df[cols.weight]),
    }
    if cols.radius is not None:
        data["radius"] = normalize_numeric_series(df[cols.radius])
    if cols.support is not None:
        data["support"] = normalize_numeric_series(df[cols.support])

    out = pd.DataFrame(data).dropna(subset=["theta", "weight"]).copy()
    out = out[np.isfinite(out["theta"]) & np.isfinite(out["weight"])].copy()
    if "radius" in out.columns:
        out = out[np.isfinite(out["radius"])].copy()
    if "support" in out.columns:
        out.loc[~np.isfinite(out["support"]), "support"] = np.nan
        out["support"] = out["support"].fillna(1.0)
        out.loc[out["support"] <= 0, "support"] = 1.0
        out["effective_weight"] = out["weight"] * out["support"]
    else:
        out["effective_weight"] = out["weight"]
    return out.reset_index(drop=True)



def local_poly_derivatives(x: np.ndarray, y: np.ndarray, window: int = 7) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Local quadratic least-squares differentiation on nonuniform x.
    Returns smoothed y, y', y''.
    Uses only restricted-support neighborhoods; no periodic wrap-around.
    """
    n = len(x)
    if n < 5:
        raise ValueError("Need at least 5 points for local polynomial derivatives.")

    w = max(5, int(window))
    if w % 2 == 0:
        w += 1
    w = min(w, n if n % 2 == 1 else n - 1)
    if w < 5:
        w = 5
    half = w // 2

    y_smooth = np.full(n, np.nan, dtype=float)
    y1 = np.full(n, np.nan, dtype=float)
    y2 = np.full(n, np.nan, dtype=float)

    for i in range(n):
        left = max(0, i - half)
        right = min(n, i + half + 1)

        if right - left < w:
            if left == 0:
                right = min(n, w)
            elif right == n:
                left = max(0, n - w)

        xs = x[left:right]
        ys = y[left:right]
        x0 = x[i]
        dx = xs - x0

        # Quadratic fit: a0 + a1 dx + a2 dx^2
        A = np.column_stack([np.ones_like(dx), dx, dx**2])
        coeffs, *_ = np.linalg.lstsq(A, ys, rcond=None)
        a0, a1, a2 = coeffs
        y_smooth[i] = a0
        y1[i] = a1
        y2[i] = 2.0 * a2

    return y_smooth, y1, y2



def finite_diff_derivatives(x: np.ndarray, y: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    y1 = np.gradient(y, x, edge_order=2)
    y2 = np.gradient(y1, x, edge_order=2)
    return y1, y2



def polar_curvature_signed(r: np.ndarray, dr: np.ndarray, d2r: np.ndarray) -> np.ndarray:
    numerator = r**2 + 2.0 * dr**2 - r * d2r
    denominator = np.power(r**2 + dr**2, 1.5)
    with np.errstate(divide="ignore", invalid="ignore"):
        kappa = numerator / denominator
    return kappa



def contiguous_true_segments(theta: np.ndarray, mask: np.ndarray) -> List[Tuple[int, int]]:
    segments: List[Tuple[int, int]] = []
    start = None
    for i, flag in enumerate(mask):
        if flag and start is None:
            start = i
        elif not flag and start is not None:
            segments.append((start, i - 1))
            start = None
    if start is not None:
        segments.append((start, len(mask) - 1))
    return segments



def safe_corr(a: np.ndarray, b: np.ndarray) -> Optional[float]:
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    mask = np.isfinite(a) & np.isfinite(b)
    if mask.sum() < 3:
        return None
    aa = a[mask]
    bb = b[mask]
    if np.std(aa) == 0 or np.std(bb) == 0:
        return None
    return float(np.corrcoef(aa, bb)[0, 1])



def rankdata_average_ties(values: np.ndarray) -> np.ndarray:
    values = np.asarray(values, dtype=float)
    order = np.argsort(values, kind="mergesort")
    ranks = np.empty(len(values), dtype=float)
    i = 0
    while i < len(values):
        j = i + 1
        while j < len(values) and values[order[j]] == values[order[i]]:
            j += 1
        avg_rank = 0.5 * (i + j - 1) + 1.0
        ranks[order[i:j]] = avg_rank
        i = j
    return ranks



def spearman_corr(a: np.ndarray, b: np.ndarray) -> Optional[float]:
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    mask = np.isfinite(a) & np.isfinite(b)
    if mask.sum() < 3:
        return None
    ar = rankdata_average_ties(a[mask])
    br = rankdata_average_ties(b[mask])
    return safe_corr(ar, br)



def interpolate_density_to_boundary(theta_boundary: np.ndarray, density_by_theta: pd.DataFrame) -> np.ndarray:
    src = density_by_theta.sort_values("theta")
    x = src["theta"].to_numpy(dtype=float)
    y = src["angular_density_norm"].to_numpy(dtype=float)
    if len(x) == 1:
        return np.full_like(theta_boundary, y[0], dtype=float)
    return np.interp(theta_boundary, x, y, left=y[0], right=y[-1])



def summarize_model_table(df: pd.DataFrame) -> Dict[str, object]:
    out: Dict[str, object] = {}
    if df is None or df.empty:
        return out

    low = {c.lower(): c for c in df.columns}
    model_col = None
    for candidate in ["model_name", "model", "fit_name", "law_name"]:
        if candidate in low:
            model_col = low[candidate]
            break
    if model_col is not None:
        out["models_seen"] = sorted(df[model_col].dropna().astype(str).unique().tolist())

    best_row = None
    for metric_name in ["weighted_rms", "wrms", "rmse", "aic"]:
        if metric_name in low:
            col = low[metric_name]
            temp = df.copy()
            temp[col] = pd.to_numeric(temp[col], errors="coerce")
            temp = temp.dropna(subset=[col])
            if not temp.empty:
                best_row = temp.sort_values(col, ascending=True).iloc[0]
                out["best_selection_metric"] = metric_name
                break

    if best_row is not None:
        out["best_model_row"] = {k: _jsonable(best_row[k]) for k in df.columns}
    return out



def _jsonable(x):
    if pd.isna(x):
        return None
    if isinstance(x, (np.floating, float)):
        return float(x)
    if isinstance(x, (np.integer, int)):
        return int(x)
    return str(x)



def format_interval(theta_min: float, theta_max: float) -> Dict[str, float]:
    return {
        "theta_min": round(float(theta_min), ROUND_DIGITS),
        "theta_max": round(float(theta_max), ROUND_DIGITS),
        "theta_width": round(float(theta_max - theta_min), ROUND_DIGITS),
    }


# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------


def main() -> None:
    _print("[Stage-6F PRECHECK] Creating output directory...")
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    _print("[Stage-6F PRECHECK] Checking required files...")
    required = [
        INPUT_BOUNDARY_CURVE,
        INPUT_MODEL_COMPARISON,
        INPUT_RESIDUAL_TABLE,
        INPUT_JOINT_DENSITY,
    ]
    missing = [str(p) for p in required if not p.exists()]
    if missing:
        raise FileNotFoundError("Missing required file(s):\n  - " + "\n  - ".join(missing))

    _print("[Stage-6F PRECHECK] Loading Stage-6E / Stage-6D tables...")
    df_boundary_raw = pd.read_csv(INPUT_BOUNDARY_CURVE)
    df_models = pd.read_csv(INPUT_MODEL_COMPARISON)
    df_residual = pd.read_csv(INPUT_RESIDUAL_TABLE)
    df_density_raw = pd.read_csv(INPUT_JOINT_DENSITY)

    _print("[Stage-6F PRECHECK] Boundary columns found:")
    _print(str(list(df_boundary_raw.columns)))
    _print("[Stage-6F PRECHECK] Joint density columns found:")
    _print(str(list(df_density_raw.columns)))

    boundary_cols = infer_boundary_columns(df_boundary_raw)
    density_cols = infer_density_columns(df_density_raw)

    df_boundary = sort_and_clean_boundary(df_boundary_raw, boundary_cols)
    df_density = clean_density(df_density_raw, density_cols)

    _print("[Stage-6F] Computing stable local derivatives...")
    theta = df_boundary["theta"].to_numpy(dtype=float)
    r_raw = df_boundary["r"].to_numpy(dtype=float)

    r_smooth, dr_local, d2r_local = local_poly_derivatives(theta, r_raw, window=LOCAL_POLY_WINDOW)
    dr_fd, d2r_fd = finite_diff_derivatives(theta, r_raw)

    kappa_signed_local = polar_curvature_signed(r_smooth, dr_local, d2r_local)
    kappa_abs_local = np.abs(kappa_signed_local)
    kappa_signed_fd = polar_curvature_signed(r_raw, dr_fd, d2r_fd)
    kappa_abs_fd = np.abs(kappa_signed_fd)

    metric_g_thetatheta = r_smooth**2 + dr_local**2
    ds_dtheta = np.sqrt(metric_g_thetatheta)
    arc_length = np.zeros_like(theta)
    arc_length[1:] = np.cumsum(0.5 * (ds_dtheta[1:] + ds_dtheta[:-1]) * np.diff(theta))

    curvature_disagreement = np.abs(kappa_abs_local - kappa_abs_fd)
    curvature_relative_disagreement = curvature_disagreement / np.maximum(kappa_abs_local, 1e-12)

    _print("[Stage-6F] Aggregating refined transition density onto angular support...")
    if density_cols.support is not None:
        _print(f"[Stage-6F] Using effective angular weight = {density_cols.weight} * {density_cols.support}.")
    else:
        _print(f"[Stage-6F] Using angular weight column: {density_cols.weight}.")
    density_by_theta = (
        df_density.groupby("theta", as_index=False)["effective_weight"]
        .sum()
        .rename(columns={"effective_weight": "angular_density"})
        .sort_values("theta")
        .reset_index(drop=True)
    )

    total_density = float(density_by_theta["angular_density"].sum())
    if total_density > 0:
        density_by_theta["angular_density_norm"] = density_by_theta["angular_density"] / total_density
    else:
        density_by_theta["angular_density_norm"] = 0.0

    angular_density_on_boundary = interpolate_density_to_boundary(theta, density_by_theta)

    _print("[Stage-6F] Detecting anisotropic high-curvature sectors...")
    k80 = float(np.quantile(kappa_abs_local, HIGH_CURVATURE_QUANTILE))
    k90 = float(np.quantile(kappa_abs_local, VERY_HIGH_CURVATURE_QUANTILE))
    d80 = float(np.quantile(angular_density_on_boundary, HIGH_DENSITY_QUANTILE))

    high_curv_mask = kappa_abs_local >= k80
    very_high_curv_mask = kappa_abs_local >= k90
    high_density_mask = angular_density_on_boundary >= d80
    overlap_mask = high_curv_mask & high_density_mask

    high_segments = contiguous_true_segments(theta, high_curv_mask)
    very_high_segments = contiguous_true_segments(theta, very_high_curv_mask)
    overlap_segments = contiguous_true_segments(theta, overlap_mask)

    segment_summaries = []
    for start, end in high_segments:
        segment_summaries.append({
            **format_interval(theta[start], theta[end]),
            "n_points": int(end - start + 1),
            "max_abs_curvature": round(float(np.max(kappa_abs_local[start:end+1])), ROUND_DIGITS),
            "mean_abs_curvature": round(float(np.mean(kappa_abs_local[start:end+1])), ROUND_DIGITS),
            "mean_angular_density": round(float(np.mean(angular_density_on_boundary[start:end+1])), ROUND_DIGITS),
            "mean_metric_g_thetatheta": round(float(np.mean(metric_g_thetatheta[start:end+1])), ROUND_DIGITS),
        })

    overlap_segment_summaries = []
    for start, end in overlap_segments:
        overlap_segment_summaries.append({
            **format_interval(theta[start], theta[end]),
            "n_points": int(end - start + 1),
            "max_abs_curvature": round(float(np.max(kappa_abs_local[start:end+1])), ROUND_DIGITS),
            "mean_angular_density": round(float(np.mean(angular_density_on_boundary[start:end+1])), ROUND_DIGITS),
        })

    i_peak_curv = int(np.argmax(kappa_abs_local))
    i_peak_density = int(np.argmax(angular_density_on_boundary))
    i_peak_metric = int(np.argmax(metric_g_thetatheta))

    pearson_kappa_density = safe_corr(kappa_abs_local, angular_density_on_boundary)
    spearman_kappa_density = spearman_corr(kappa_abs_local, angular_density_on_boundary)
    pearson_metric_density = safe_corr(metric_g_thetatheta, angular_density_on_boundary)
    spearman_metric_density = spearman_corr(metric_g_thetatheta, angular_density_on_boundary)
    pearson_dr_density = safe_corr(np.abs(dr_local), angular_density_on_boundary)

    support_theta_min = float(theta.min())
    support_theta_max = float(theta.max())
    support_theta_width = float(support_theta_max - support_theta_min)

    stability = {
        "mean_abs_disagreement_local_vs_finite_diff": round(float(np.mean(curvature_disagreement)), ROUND_DIGITS),
        "median_abs_disagreement_local_vs_finite_diff": round(float(np.median(curvature_disagreement)), ROUND_DIGITS),
        "mean_relative_disagreement_local_vs_finite_diff": round(float(np.mean(curvature_relative_disagreement)), ROUND_DIGITS),
        "median_relative_disagreement_local_vs_finite_diff": round(float(np.median(curvature_relative_disagreement)), ROUND_DIGITS),
        "local_poly_window": int(LOCAL_POLY_WINDOW),
    }

    _print("[Stage-6F] Writing curvature profile CSV...")
    out_profile = pd.DataFrame({
        "theta": theta,
        "r_observed": r_raw,
        "r_local_poly_smooth": r_smooth,
        "dr_dtheta_local_poly": dr_local,
        "d2r_dtheta2_local_poly": d2r_local,
        "dr_dtheta_finite_diff": dr_fd,
        "d2r_dtheta2_finite_diff": d2r_fd,
        "kappa_signed_local_poly": kappa_signed_local,
        "kappa_abs_local_poly": kappa_abs_local,
        "kappa_signed_finite_diff": kappa_signed_fd,
        "kappa_abs_finite_diff": kappa_abs_fd,
        "kappa_abs_disagreement": curvature_disagreement,
        "metric_g_thetatheta_boundary": metric_g_thetatheta,
        "ds_dtheta": ds_dtheta,
        "arc_length_from_support_start": arc_length,
        "angular_density_interp": angular_density_on_boundary,
        "high_curvature_q80_flag": high_curv_mask.astype(int),
        "very_high_curvature_q90_flag": very_high_curv_mask.astype(int),
        "high_density_q80_flag": high_density_mask.astype(int),
        "curvature_density_overlap_flag": overlap_mask.astype(int),
    })
    out_profile.to_csv(OUTPUT_CURVATURE_PROFILE, index=False)

    _print("[Stage-6F] Writing anisotropy summary JSON...")
    summary = {
        "stage": "Stage-6F",
        "upstream_scope": "Stage-6E v2b BRANCH1 restricted fit",
        "scope_note": "Restricted-support boundary law only; no periodic closure; no extrapolation beyond support.",
        "input_files": {
            "boundary_curve": str(INPUT_BOUNDARY_CURVE),
            "model_comparison": str(INPUT_MODEL_COMPARISON),
            "residual_table": str(INPUT_RESIDUAL_TABLE),
            "joint_density_refined": str(INPUT_JOINT_DENSITY),
        },
        "detected_columns": {
            "boundary_curve": {"theta": boundary_cols.theta, "radius": boundary_cols.radius},
            "joint_density_refined": {
                "theta": density_cols.theta,
                "weight": density_cols.weight,
                "radius": density_cols.radius,
                "support": density_cols.support,
            },
        },
        "support": {
            "theta_min": round(support_theta_min, ROUND_DIGITS),
            "theta_max": round(support_theta_max, ROUND_DIGITS),
            "theta_width": round(support_theta_width, ROUND_DIGITS),
            "n_boundary_samples": int(len(theta)),
            "n_density_rows": int(len(df_density)),
            "n_density_theta_bins": int(len(density_by_theta)),
        },
        "best_fit_context": summarize_model_table(df_models),
        "residual_table_rows": int(len(df_residual)),
        "curvature_statistics": {
            "min_abs_curvature": round(float(np.min(kappa_abs_local)), ROUND_DIGITS),
            "median_abs_curvature": round(float(np.median(kappa_abs_local)), ROUND_DIGITS),
            "mean_abs_curvature": round(float(np.mean(kappa_abs_local)), ROUND_DIGITS),
            "max_abs_curvature": round(float(np.max(kappa_abs_local)), ROUND_DIGITS),
            "q80_abs_curvature": round(k80, ROUND_DIGITS),
            "q90_abs_curvature": round(k90, ROUND_DIGITS),
            "peak_curvature_theta": round(float(theta[i_peak_curv]), ROUND_DIGITS),
            "peak_curvature_value": round(float(kappa_abs_local[i_peak_curv]), ROUND_DIGITS),
        },
        "boundary_metric_statistics": {
            "g_thetatheta_min": round(float(np.min(metric_g_thetatheta)), ROUND_DIGITS),
            "g_thetatheta_median": round(float(np.median(metric_g_thetatheta)), ROUND_DIGITS),
            "g_thetatheta_mean": round(float(np.mean(metric_g_thetatheta)), ROUND_DIGITS),
            "g_thetatheta_max": round(float(np.max(metric_g_thetatheta)), ROUND_DIGITS),
            "peak_metric_theta": round(float(theta[i_peak_metric]), ROUND_DIGITS),
            "peak_metric_value": round(float(metric_g_thetatheta[i_peak_metric]), ROUND_DIGITS),
            "restricted_support_arc_length": round(float(arc_length[-1]), ROUND_DIGITS),
        },
        "density_statistics": {
            "q80_density": round(d80, ROUND_DIGITS),
            "peak_density_theta": round(float(theta[i_peak_density]), ROUND_DIGITS),
            "peak_density_value": round(float(angular_density_on_boundary[i_peak_density]), ROUND_DIGITS),
        },
        "curvature_density_association": {
            "pearson_abs_curvature_vs_density": None if pearson_kappa_density is None else round(pearson_kappa_density, ROUND_DIGITS),
            "spearman_abs_curvature_vs_density": None if spearman_kappa_density is None else round(spearman_kappa_density, ROUND_DIGITS),
            "pearson_metric_vs_density": None if pearson_metric_density is None else round(pearson_metric_density, ROUND_DIGITS),
            "spearman_metric_vs_density": None if spearman_metric_density is None else round(spearman_metric_density, ROUND_DIGITS),
            "pearson_abs_dr_vs_density": None if pearson_dr_density is None else round(pearson_dr_density, ROUND_DIGITS),
        },
        "anisotropy_detection": {
            "n_high_curvature_sectors_q80": int(len(high_segments)),
            "n_very_high_curvature_sectors_q90": int(len(very_high_segments)),
            "n_overlap_sectors_curvature_density": int(len(overlap_segments)),
            "high_curvature_sectors": segment_summaries,
            "overlap_sectors_curvature_density": overlap_segment_summaries,
        },
        "stability": stability,
        "interpretive_flags": {
            "nonuniform_curvature_detected": bool(np.max(kappa_abs_local) > np.median(kappa_abs_local) * 1.25),
            "anisotropy_beyond_radial_symmetry": bool(len(high_segments) >= 1 and np.max(kappa_abs_local) > np.min(kappa_abs_local) * 1.5),
            "curvature_density_overlap_detected": bool(len(overlap_segments) >= 1),
        },
    }
    with open(OUTPUT_ANISOTROPY_SUMMARY, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)

    _print("[Stage-6F] Writing geometry notes TXT...")
    notes = []
    notes.append("STAGE-6F GEOMETRY NOTES")
    notes.append("Project: Quantum-Emergent Gravity")
    notes.append("Upstream: Stage-6E v2b (branch1 restricted fit)")
    notes.append("")
    notes.append("1) What is being computed")
    notes.append("-------------------------")
    notes.append(
        "The fitted boundary law r_c(theta), restricted to the supported angular sector, "
        "is interpreted as a polar curve x(theta)=r(theta)cos(theta), y(theta)=r(theta)sin(theta)."
    )
    notes.append(
        "The script computes dr/dtheta and d^2r/dtheta^2 using a local quadratic estimator "
        "on the observed support only, with a finite-difference cross-check for stability."
    )
    notes.append("")
    notes.append("2) Curvature proxy")
    notes.append("------------------")
    notes.append(
        "For a polar curve r(theta), the signed curvature used here is"
    )
    notes.append(
        "    kappa(theta) = [r^2 + 2(dr/dtheta)^2 - r(d^2r/dtheta^2)] / [r^2 + (dr/dtheta)^2]^(3/2)."
    )
    notes.append(
        "Its magnitude |kappa| measures local bending of the admissibility boundary. "
        "Because Stage-6F is restricted to the observed angular support, this is a sector-local geometric quantity, not a global closed-curve invariant."
    )
    notes.append("")
    notes.append("3) Metric-like quantity on the boundary")
    notes.append("--------------------------------------")
    notes.append(
        "The ambient polar plane carries ds^2 = dr^2 + r^2 dtheta^2. Restricting to the boundary r=r(theta) induces"
    )
    notes.append(
        "    ds_boundary^2 = [(dr/dtheta)^2 + r(theta)^2] dtheta^2."
    )
    notes.append(
        "Hence g_thetatheta_boundary = r^2 + (dr/dtheta)^2 is the natural 1D metric-like coefficient along the supported boundary arc."
    )
    notes.append(
        "This is metric-like in the pipeline sense: it quantifies local stretching of arc length with respect to theta."
    )
    notes.append("")
    notes.append("4) Controlled conceptual link to GR-style language")
    notes.append("-----------------------------------------------")
    notes.append(
        "The present object is not a spacetime metric, and kappa(theta) is not a spacetime Ricci or scalar curvature. "
        "A safe analogy is this: Stage-6F extracts an extrinsic-boundary geometry of the admissible sector inside an effective 2D polar manifold."
    )
    notes.append(
        "Regions where |kappa| concentrates behave like anisotropic geometric stress sectors of the emergent boundary: they signal where the admissibility frontier bends sharply, deviating most strongly from radial symmetry."
    )
    notes.append(
        "Thus, within the pipeline, curvature concentration can be read as a boundary-level geometric diagnostic that may later feed a deeper effective-geometry interpretation, but it should not yet be identified with GR curvature tensors."
    )
    notes.append("")
    notes.append("5) Density comparison")
    notes.append("---------------------")
    notes.append(
        "The refined Stage-6D joint density is aggregated over radius into an angular density profile and interpolated onto the Stage-6F boundary support."
    )
    notes.append(
        "This allows comparison between (i) where the boundary bends most sharply and (ii) where the transition mass is most concentrated."
    )
    notes.append(
        "Any overlap between high-curvature sectors and high-density sectors is evidence that the admissibility transition is not only anisotropic, but geometrically organized."
    )
    notes.append("")
    notes.append("6) Interpretation guardrail")
    notes.append("---------------------------")
    notes.append(
        "No periodic closure is imposed, and no extension beyond the supported theta-sector is used. "
        "Therefore all conclusions are local-to-sector statements for the restricted branch1 law only."
    )
    notes.append("")
    notes.append("7) Quick numerical summary")
    notes.append("--------------------------")
    notes.append(f"Supported theta interval: [{support_theta_min:.8f}, {support_theta_max:.8f}]")
    notes.append(f"Boundary samples: {len(theta)}")
    notes.append(f"Peak |kappa| at theta = {theta[i_peak_curv]:.8f}, value = {kappa_abs_local[i_peak_curv]:.8f}")
    notes.append(f"Peak angular density at theta = {theta[i_peak_density]:.8f}, value = {angular_density_on_boundary[i_peak_density]:.8f}")
    notes.append(f"High-curvature sectors (q80): {len(high_segments)}")
    notes.append(f"Overlap sectors (high curvature & high density): {len(overlap_segments)}")
    notes.append(
        "Pearson(abs curvature, density) = "
        + ("NA" if pearson_kappa_density is None else f"{pearson_kappa_density:.8f}")
    )
    notes.append(
        "Spearman(abs curvature, density) = "
        + ("NA" if spearman_kappa_density is None else f"{spearman_kappa_density:.8f}")
    )

    with open(OUTPUT_GEOMETRY_NOTES, "w", encoding="utf-8") as f:
        f.write("\n".join(notes) + "\n")

    _print("[Stage-6F] Done.")
    _print("[Stage-6F] Wrote:")
    _print(f"  CSV : {OUTPUT_CURVATURE_PROFILE}")
    _print(f"  JSON: {OUTPUT_ANISOTROPY_SUMMARY}")
    _print(f"  TXT : {OUTPUT_GEOMETRY_NOTES}")


if __name__ == "__main__":
    main()
