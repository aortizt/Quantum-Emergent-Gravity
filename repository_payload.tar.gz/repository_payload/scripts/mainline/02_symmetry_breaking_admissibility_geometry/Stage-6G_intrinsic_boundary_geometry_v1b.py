
# -*- coding: utf-8 -*-
"""
============================================================
Stage-6G: Intrinsic Boundary Geometry
Project: Quantum-Emergent Gravity
Upstream: Stage-6F curvature geometry / Stage-6E boundary law
Authoring mode: Spyder-ready standalone script
Version: v1b
============================================================

PATCH NOTE (v1b)
----------------
This revision broadens the Stage-6F column alias map so it correctly
resolves the actual Stage-6F output schema reported by the user, including:

Kairos    - kappa_abs_local_poly
    - kappa_signed_local_poly
    - angular_density_interp
    - metric_g_thetatheta_boundary
    - r_observed / r_local_poly_smooth
    - dr_dtheta_local_poly
    - d2r_dtheta2_local_poly
    - arc_length_from_support_start

It also prefers the local-polynomial curvature channel when available,
while still supporting fallback variants.
"""

from __future__ import annotations

import json
import math
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import pandas as pd


SCRIPT_VERSION = "Stage-6G_intrinsic_boundary_geometry_v1b.py"

INPUT_CURVATURE_FILENAME = "stage6F_curvature_profile.csv"
INPUT_ANISOTROPY_FILENAME = "stage6F_anisotropy_summary.json"
INPUT_NOTES_FILENAME = "stage6F_geometry_notes.txt"
OPTIONAL_STAGE6E_BOUNDARY_FILENAME = "stage6E_boundary_curve_v2.csv"

OUTPUT_DIRNAME = "metric_stage_6G_outputs"
OUTPUT_PROFILE_FILENAME = "stage6G_intrinsic_profile.csv"
OUTPUT_SUMMARY_FILENAME = "stage6G_intrinsic_summary.json"
OUTPUT_NOTES_FILENAME = "stage6G_geometry_notes.txt"

N_SECTORS = 12
HIGH_Q_CURVATURE = 0.80
HIGH_Q_DENSITY = 0.80

THRESH_JACCARD = 0.50
THRESH_RANK_CORR = 0.50
THRESH_ALIGNMENT_IMPROVEMENT = 0.02
THRESH_ANISOTROPY_CV = 0.10

EPS = 1e-12


@dataclass
class LocatedInputs:
    project_root: Path
    curvature_csv: Path
    anisotropy_json: Optional[Path]
    notes_txt: Optional[Path]
    stage6e_boundary_csv: Optional[Path]


def log(msg: str) -> None:
    print(msg, flush=True)


def discover_project_root(start: Optional[Path] = None) -> Path:
    if start is None:
        start = Path.cwd().resolve()

    candidates = [start] + list(start.parents)
    markers = {
        "010-Quantum_Emergent_Gravity",
        "metric_stage_6F_outputs",
        "metric_stage_6E_outputs",
        "metric_stage_6D_outputs",
        "metric_stage_6C_outputs",
    }

    for path in candidates:
        if path.name == "010-Quantum_Emergent_Gravity":
            return path
        try:
            child_names = {p.name for p in path.iterdir()}
        except Exception:
            child_names = set()
        if "010-Quantum_Emergent_Gravity" in child_names:
            return path / "010-Quantum_Emergent_Gravity"
        if markers.intersection(child_names):
            return path

    raise FileNotFoundError(
        "Could not discover the project root. "
        "Please run this script from inside the project tree."
    )


def find_first_file(root: Path, filename: str) -> Optional[Path]:
    matches = list(root.rglob(filename))
    if not matches:
        return None
    matches.sort(key=lambda p: (len(p.parts), -p.stat().st_mtime))
    return matches[0]


def locate_inputs(project_root: Path) -> LocatedInputs:
    curvature_csv = find_first_file(project_root, INPUT_CURVATURE_FILENAME)
    anisotropy_json = find_first_file(project_root, INPUT_ANISOTROPY_FILENAME)
    notes_txt = find_first_file(project_root, INPUT_NOTES_FILENAME)
    stage6e_boundary_csv = find_first_file(project_root, OPTIONAL_STAGE6E_BOUNDARY_FILENAME)

    if curvature_csv is None:
        raise FileNotFoundError(f"Required file not found: {INPUT_CURVATURE_FILENAME}")

    return LocatedInputs(
        project_root=project_root,
        curvature_csv=curvature_csv,
        anisotropy_json=anisotropy_json,
        notes_txt=notes_txt,
        stage6e_boundary_csv=stage6e_boundary_csv,
    )


def normalize_name(name: str) -> str:
    name = name.strip().lower()
    name = re.sub(r"[^a-z0-9]+", "_", name)
    name = re.sub(r"_+", "_", name).strip("_")
    return name


def build_normalized_lookup(columns: List[str]) -> Dict[str, str]:
    return {normalize_name(c): c for c in columns}


def resolve_column(columns: List[str], aliases: List[str]) -> Optional[str]:
    lookup = build_normalized_lookup(columns)
    for alias in aliases:
        if alias in lookup:
            return lookup[alias]
    return None


def require_column(columns: List[str], aliases: List[str], label: str) -> str:
    col = resolve_column(columns, aliases)
    if col is None:
        raise KeyError(
            f"Could not resolve required column for '{label}'. "
            f"Available columns: {columns}"
        )
    return col


def finite_difference(y: np.ndarray, x: np.ndarray) -> np.ndarray:
    return np.gradient(y, x)


def safe_corr(a: np.ndarray, b: np.ndarray) -> Optional[float]:
    mask = np.isfinite(a) & np.isfinite(b)
    if mask.sum() < 3:
        return None
    a2 = a[mask]
    b2 = b[mask]
    if np.std(a2) < EPS or np.std(b2) < EPS:
        return None
    return float(np.corrcoef(a2, b2)[0, 1])


def safe_rank_corr(a: np.ndarray, b: np.ndarray) -> Optional[float]:
    mask = np.isfinite(a) & np.isfinite(b)
    if mask.sum() < 3:
        return None
    s1 = pd.Series(a[mask]).rank(method="average")
    s2 = pd.Series(b[mask]).rank(method="average")
    if s1.std() < EPS or s2.std() < EPS:
        return None
    return float(s1.corr(s2))


def coefficient_of_variation(x: np.ndarray) -> Optional[float]:
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    if x.size == 0:
        return None
    mean = float(np.mean(x))
    std = float(np.std(x))
    if abs(mean) < EPS:
        return None
    return float(std / abs(mean))


def jaccard_similarity(a: set, b: set) -> Optional[float]:
    union = a.union(b)
    if not union:
        return None
    return len(a.intersection(b)) / len(union)


def circular_bin_edges(theta_min: float, theta_max: float, n_bins: int) -> np.ndarray:
    return np.linspace(theta_min, theta_max, n_bins + 1)


def bin_means(coord: np.ndarray, values: np.ndarray, edges: np.ndarray) -> np.ndarray:
    out = np.full(len(edges) - 1, np.nan, dtype=float)
    inds = np.digitize(coord, edges) - 1
    inds = np.clip(inds, 0, len(edges) - 2)
    for k in range(len(out)):
        mask = (inds == k) & np.isfinite(values) & np.isfinite(coord)
        if mask.any():
            out[k] = float(np.mean(values[mask]))
    return out


def bin_integral_weights(coord: np.ndarray, weights: np.ndarray, edges: np.ndarray) -> np.ndarray:
    out = np.zeros(len(edges) - 1, dtype=float)
    inds = np.digitize(coord, edges) - 1
    inds = np.clip(inds, 0, len(edges) - 2)
    for k in range(len(out)):
        mask = (inds == k) & np.isfinite(weights) & np.isfinite(coord)
        if mask.any():
            out[k] = float(np.sum(weights[mask]))
    total = out.sum()
    if total > EPS:
        out /= total
    return out


def weighted_overlap_mass(a: np.ndarray, b: np.ndarray) -> Optional[float]:
    mask = np.isfinite(a) & np.isfinite(b)
    if mask.sum() == 0:
        return None
    a2 = a[mask].astype(float)
    b2 = b[mask].astype(float)
    sa = a2.sum()
    sb = b2.sum()
    if sa <= EPS or sb <= EPS:
        return None
    a2 /= sa
    b2 /= sb
    return float(np.minimum(a2, b2).sum())


def to_builtin(obj):
    if isinstance(obj, dict):
        return {str(k): to_builtin(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [to_builtin(v) for v in obj]
    if isinstance(obj, tuple):
        return [to_builtin(v) for v in obj]
    if isinstance(obj, np.ndarray):
        return [to_builtin(v) for v in obj.tolist()]
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        value = float(obj)
        if math.isnan(value) or math.isinf(value):
            return None
        return value
    return obj


def load_curvature_profile(path: Path) -> pd.DataFrame:
    log(f"[Stage-6G PRECHECK] Loading Stage-6F profile: {path}")
    raw = pd.read_csv(path)
    original_cols = list(raw.columns)

    log("[Stage-6G PRECHECK] Stage-6F columns:")
    log(str(original_cols))

    theta_col = require_column(
        original_cols,
        aliases=["theta", "angle", "theta_value", "theta_center", "theta_rad"],
        label="theta"
    )

    # Prefer local polynomial channels when available.
    kappa_abs_col = require_column(
        original_cols,
        aliases=[
            "kappa_abs_local_poly",
            "kappa_abs_finite_diff",
            "kappa_abs",
            "abs_kappa",
            "curvature_abs",
            "kappa_abs_value"
        ],
        label="abs_kappa"
    )

    kappa_signed_col = resolve_column(
        original_cols,
        aliases=[
            "kappa_signed_local_poly",
            "kappa_signed_finite_diff",
            "kappa_signed",
            "kappa",
            "curvature",
            "curvature_signed"
        ]
    )

    density_col = resolve_column(
        original_cols,
        aliases=[
            "angular_density_interp",
            "density",
            "transition_density",
            "angular_density",
            "sector_density",
            "support_density",
            "mass_density"
        ]
    )

    g_theta_theta_col = resolve_column(
        original_cols,
        aliases=[
            "metric_g_thetatheta_boundary",
            "g_thetatheta",
            "g_theta_theta",
            "metric_theta_theta",
            "boundary_metric_like"
        ]
    )

    ds_dtheta_col = resolve_column(
        original_cols,
        aliases=[
            "ds_dtheta",
            "arc_length_density",
            "arc_speed",
            "intrinsic_speed"
        ]
    )

    s_from_start_col = resolve_column(
        original_cols,
        aliases=[
            "arc_length_from_support_start",
            "arc_length",
            "s",
            "intrinsic_arc_length"
        ]
    )

    r_col = resolve_column(
        original_cols,
        aliases=[
            "r_local_poly_smooth",
            "r_observed",
            "r",
            "radius",
            "r_theta",
            "boundary_radius",
            "r_c",
            "rc"
        ]
    )

    dr_col = resolve_column(
        original_cols,
        aliases=[
            "dr_dtheta_local_poly",
            "dr_dtheta_finite_diff",
            "dr_dtheta",
            "dr_d_theta",
            "radius_derivative",
            "dr",
            "r_prime"
        ]
    )

    d2r_col = resolve_column(
        original_cols,
        aliases=[
            "d2r_dtheta2_local_poly",
            "d2r_dtheta2_finite_diff",
            "d2r_dtheta2",
            "d2r_d_theta2",
            "radius_second_derivative",
            "d2r",
            "r_double_prime"
        ]
    )

    out = pd.DataFrame()
    out["theta"] = pd.to_numeric(raw[theta_col], errors="coerce")
    out["abs_kappa"] = pd.to_numeric(raw[kappa_abs_col], errors="coerce")
    out["kappa"] = (
        pd.to_numeric(raw[kappa_signed_col], errors="coerce")
        if kappa_signed_col is not None
        else np.nan
    )
    out["density"] = (
        pd.to_numeric(raw[density_col], errors="coerce")
        if density_col is not None
        else np.nan
    )
    out["g_thetatheta"] = (
        pd.to_numeric(raw[g_theta_theta_col], errors="coerce")
        if g_theta_theta_col is not None
        else np.nan
    )
    out["ds_dtheta"] = (
        pd.to_numeric(raw[ds_dtheta_col], errors="coerce")
        if ds_dtheta_col is not None
        else np.nan
    )
    out["s_from_start"] = (
        pd.to_numeric(raw[s_from_start_col], errors="coerce")
        if s_from_start_col is not None
        else np.nan
    )
    out["r"] = (
        pd.to_numeric(raw[r_col], errors="coerce")
        if r_col is not None
        else np.nan
    )
    out["dr_dtheta"] = (
        pd.to_numeric(raw[dr_col], errors="coerce")
        if dr_col is not None
        else np.nan
    )
    out["d2r_dtheta2"] = (
        pd.to_numeric(raw[d2r_col], errors="coerce")
        if d2r_col is not None
        else np.nan
    )

    out = out.sort_values("theta").reset_index(drop=True)
    return out


def enrich_missing_geometry(df: pd.DataFrame) -> pd.DataFrame:
    theta = df["theta"].to_numpy(dtype=float)

    if df["dr_dtheta"].isna().all() and (not df["r"].isna().all()):
        r = df["r"].to_numpy(dtype=float)
        df["dr_dtheta"] = finite_difference(r, theta)

    if df["d2r_dtheta2"].isna().all() and (not df["dr_dtheta"].isna().all()):
        dr = df["dr_dtheta"].to_numpy(dtype=float)
        df["d2r_dtheta2"] = finite_difference(dr, theta)

    if df["g_thetatheta"].isna().all():
        if not df["ds_dtheta"].isna().all():
            dsd = df["ds_dtheta"].to_numpy(dtype=float)
            df["g_thetatheta"] = dsd ** 2
        elif (not df["r"].isna().all()) and (not df["dr_dtheta"].isna().all()):
            r = df["r"].to_numpy(dtype=float)
            dr = df["dr_dtheta"].to_numpy(dtype=float)
            df["g_thetatheta"] = r ** 2 + dr ** 2

    if df["kappa"].isna().all() and not df["abs_kappa"].isna().all():
        # Signed curvature unavailable: retain absolute curvature as proxy.
        df["kappa"] = df["abs_kappa"]

    return df


def validate_geometry(df: pd.DataFrame) -> None:
    if df["theta"].isna().any():
        raise ValueError("Theta column contains NaN values after coercion.")
    if not np.all(np.diff(df["theta"].to_numpy(dtype=float)) >= 0):
        raise ValueError("Theta is not monotone after sorting.")
    if df["abs_kappa"].isna().all():
        raise ValueError("Absolute curvature column is entirely missing.")
    if df["g_thetatheta"].isna().all():
        raise ValueError(
            "Could not determine g_thetatheta. "
            "Expected metric_g_thetatheta_boundary, ds_dtheta, or r/dr_dtheta."
        )


def build_intrinsic_profile(df: pd.DataFrame) -> pd.DataFrame:
    theta = df["theta"].to_numpy(dtype=float)
    kappa = df["kappa"].to_numpy(dtype=float)
    abs_kappa = df["abs_kappa"].to_numpy(dtype=float)
    density = df["density"].to_numpy(dtype=float)
    gtt = df["g_thetatheta"].to_numpy(dtype=float)
    r = df["r"].to_numpy(dtype=float)
    dr = df["dr_dtheta"].to_numpy(dtype=float)
    d2r = df["d2r_dtheta2"].to_numpy(dtype=float)

    if not df["s_from_start"].isna().all():
        s = df["s_from_start"].to_numpy(dtype=float)
        s = s - s[0]
        s_total = float(s[-1]) if len(s) else 0.0
        ds_dtheta = (
            df["ds_dtheta"].to_numpy(dtype=float)
            if not df["ds_dtheta"].isna().all()
            else np.sqrt(np.maximum(gtt, 0.0))
        )
        dtheta = np.gradient(theta)
    else:
        ds_dtheta = (
            df["ds_dtheta"].to_numpy(dtype=float)
            if not df["ds_dtheta"].isna().all()
            else np.sqrt(np.maximum(gtt, 0.0))
        )
        dtheta = np.gradient(theta)
        ds = ds_dtheta * dtheta
        s = np.cumsum(ds)
        s = s - s[0]
        s_total = float(s[-1]) if len(s) else 0.0

    s_normalized = s / s_total if s_total > EPS else np.zeros_like(s)

    intrinsic = pd.DataFrame({
        "theta": theta,
        "s": s,
        "s_normalized": s_normalized,
        "dtheta": dtheta,
        "ds_dtheta": ds_dtheta,
        "kappa": kappa,
        "abs_kappa": abs_kappa,
        "kappa_sq": abs_kappa ** 2,
        "density": density,
        "g_thetatheta": gtt,
        "r": r,
        "dr_dtheta": dr,
        "d2r_dtheta2": d2r,
    })
    return intrinsic


def sector_analysis_theta_s(intrinsic: pd.DataFrame) -> Dict[str, object]:
    theta = intrinsic["theta"].to_numpy(dtype=float)
    s = intrinsic["s_normalized"].to_numpy(dtype=float)
    abs_kappa = intrinsic["abs_kappa"].to_numpy(dtype=float)
    density = intrinsic["density"].to_numpy(dtype=float)
    ds = np.gradient(intrinsic["s"].to_numpy(dtype=float))

    theta_edges = circular_bin_edges(theta.min(), theta.max(), N_SECTORS)
    s_edges = np.linspace(0.0, 1.0, N_SECTORS + 1)

    theta_curv = bin_means(theta, abs_kappa, theta_edges)
    s_curv = bin_means(s, abs_kappa, s_edges)
    theta_dens = bin_means(theta, density, theta_edges)
    s_dens = bin_means(s, density, s_edges)

    theta_curv_mass = bin_integral_weights(theta, np.where(np.isfinite(abs_kappa), abs_kappa * np.abs(ds), np.nan), theta_edges)
    s_curv_mass = bin_integral_weights(s, np.where(np.isfinite(abs_kappa), abs_kappa * np.abs(ds), np.nan), s_edges)
    theta_dens_mass = bin_integral_weights(theta, np.where(np.isfinite(density), density * np.abs(ds), np.nan), theta_edges)
    s_dens_mass = bin_integral_weights(s, np.where(np.isfinite(density), density * np.abs(ds), np.nan), s_edges)

    def top_sector_set(values: np.ndarray, q: float) -> set:
        mask = np.isfinite(values)
        if mask.sum() == 0:
            return set()
        thr = np.nanquantile(values[mask], q)
        return set(np.where((values >= thr) & np.isfinite(values))[0].tolist())

    theta_top_curv = top_sector_set(theta_curv, HIGH_Q_CURVATURE)
    s_top_curv = top_sector_set(s_curv, HIGH_Q_CURVATURE)
    theta_top_dens = top_sector_set(theta_dens, HIGH_Q_DENSITY)
    s_top_dens = top_sector_set(s_dens, HIGH_Q_DENSITY)

    return {
        "theta_edges": theta_edges.tolist(),
        "s_edges": s_edges.tolist(),
        "theta_sector_abs_kappa_mean": theta_curv.tolist(),
        "s_sector_abs_kappa_mean": s_curv.tolist(),
        "theta_sector_density_mean": theta_dens.tolist(),
        "s_sector_density_mean": s_dens.tolist(),
        "theta_sector_abs_kappa_mass": theta_curv_mass.tolist(),
        "s_sector_abs_kappa_mass": s_curv_mass.tolist(),
        "theta_sector_density_mass": theta_dens_mass.tolist(),
        "s_sector_density_mass": s_dens_mass.tolist(),
        "theta_top_curvature_sectors": sorted(theta_top_curv),
        "s_top_curvature_sectors": sorted(s_top_curv),
        "theta_top_density_sectors": sorted(theta_top_dens),
        "s_top_density_sectors": sorted(s_top_dens),
    }


def compute_decisive_metrics(intrinsic: pd.DataFrame, sector_info: Dict[str, object]) -> Dict[str, object]:
    abs_kappa = intrinsic["abs_kappa"].to_numpy(dtype=float)
    density = intrinsic["density"].to_numpy(dtype=float)
    kappa_sq = intrinsic["kappa_sq"].to_numpy(dtype=float)

    theta_curv = np.array(sector_info["theta_sector_abs_kappa_mean"], dtype=float)
    s_curv = np.array(sector_info["s_sector_abs_kappa_mean"], dtype=float)
    theta_dens = np.array(sector_info["theta_sector_density_mean"], dtype=float)
    s_dens = np.array(sector_info["s_sector_density_mean"], dtype=float)

    theta_curv_mass = np.array(sector_info["theta_sector_abs_kappa_mass"], dtype=float)
    s_curv_mass = np.array(sector_info["s_sector_abs_kappa_mass"], dtype=float)
    theta_dens_mass = np.array(sector_info["theta_sector_density_mass"], dtype=float)
    s_dens_mass = np.array(sector_info["s_sector_density_mass"], dtype=float)

    theta_top_curv = set(sector_info["theta_top_curvature_sectors"])
    s_top_curv = set(sector_info["s_top_curvature_sectors"])
    theta_top_dens = set(sector_info["theta_top_density_sectors"])
    s_top_dens = set(sector_info["s_top_density_sectors"])

    point_corr_abs = safe_corr(abs_kappa, density)
    point_corr_sq = safe_corr(kappa_sq, density)
    point_rank_abs = safe_rank_corr(abs_kappa, density)
    point_rank_sq = safe_rank_corr(kappa_sq, density)

    sector_corr_theta = safe_corr(theta_curv, theta_dens)
    sector_corr_s = safe_corr(s_curv, s_dens)
    sector_rank_theta = safe_rank_corr(theta_curv, theta_dens)
    sector_rank_s = safe_rank_corr(s_curv, s_dens)

    overlap_mass_theta = weighted_overlap_mass(theta_curv_mass, theta_dens_mass)
    overlap_mass_s = weighted_overlap_mass(s_curv_mass, s_dens_mass)

    curvature_jaccard = jaccard_similarity(theta_top_curv, s_top_curv)
    density_jaccard = jaccard_similarity(theta_top_dens, s_top_dens)

    curvature_rank_persistence = safe_rank_corr(theta_curv, s_curv)
    density_rank_persistence = safe_rank_corr(theta_dens, s_dens)

    curvature_transport_overlap = weighted_overlap_mass(theta_curv_mass, s_curv_mass)
    density_transport_overlap = weighted_overlap_mass(theta_dens_mass, s_dens_mass)

    peak_theta_curv = int(np.nanargmax(theta_curv)) if np.isfinite(theta_curv).any() else None
    peak_s_curv = int(np.nanargmax(s_curv)) if np.isfinite(s_curv).any() else None
    peak_theta_dens = int(np.nanargmax(theta_dens)) if np.isfinite(theta_dens).any() else None
    peak_s_dens = int(np.nanargmax(s_dens)) if np.isfinite(s_dens).any() else None

    anisotropy_cv_theta = coefficient_of_variation(theta_curv)
    anisotropy_cv_s = coefficient_of_variation(s_curv)

    invariance_flags = {
        "peak_curvature_sector_preserved": (peak_theta_curv == peak_s_curv) if (peak_theta_curv is not None and peak_s_curv is not None) else None,
        "high_curvature_support_preserved": (curvature_jaccard is not None and curvature_jaccard >= THRESH_JACCARD),
        "density_support_preserved": (density_jaccard is not None and density_jaccard >= THRESH_JACCARD),
        "curvature_sector_order_preserved": (curvature_rank_persistence is not None and curvature_rank_persistence >= THRESH_RANK_CORR),
        "density_sector_order_preserved": (density_rank_persistence is not None and density_rank_persistence >= THRESH_RANK_CORR),
        "anisotropy_above_null_after_reparam": (anisotropy_cv_s is not None and anisotropy_cv_s >= THRESH_ANISOTROPY_CV),
        "curvature_density_alignment_improves_in_s": (
            sector_corr_theta is not None and sector_corr_s is not None and
            (sector_corr_s - sector_corr_theta) >= THRESH_ALIGNMENT_IMPROVEMENT
        ),
        "curvature_density_overlap_improves_in_s": (
            overlap_mass_theta is not None and overlap_mass_s is not None and
            (overlap_mass_s - overlap_mass_theta) >= THRESH_ALIGNMENT_IMPROVEMENT
        ),
    }

    sector_persistence_scores = {
        "curvature_sector_jaccard": curvature_jaccard,
        "density_sector_jaccard": density_jaccard,
        "curvature_sector_rank_correlation": curvature_rank_persistence,
        "density_sector_rank_correlation": density_rank_persistence,
        "curvature_transport_overlap": curvature_transport_overlap,
        "density_transport_overlap": density_transport_overlap,
        "peak_theta_curvature_sector": peak_theta_curv,
        "peak_s_curvature_sector": peak_s_curv,
        "peak_theta_density_sector": peak_theta_dens,
        "peak_s_density_sector": peak_s_dens,
        "anisotropy_cv_theta": anisotropy_cv_theta,
        "anisotropy_cv_s": anisotropy_cv_s,
    }

    curvature_alignment_metrics = {
        "point_corr_abs_kappa_vs_density": point_corr_abs,
        "point_corr_kappa_sq_vs_density": point_corr_sq,
        "point_rank_corr_abs_kappa_vs_density": point_rank_abs,
        "point_rank_corr_kappa_sq_vs_density": point_rank_sq,
        "sector_corr_theta_abs_kappa_vs_density": sector_corr_theta,
        "sector_corr_s_abs_kappa_vs_density": sector_corr_s,
        "sector_rank_corr_theta_abs_kappa_vs_density": sector_rank_theta,
        "sector_rank_corr_s_abs_kappa_vs_density": sector_rank_s,
        "sector_overlap_mass_theta": overlap_mass_theta,
        "sector_overlap_mass_s": overlap_mass_s,
        "sector_alignment_gain_corr": None if (sector_corr_theta is None or sector_corr_s is None) else float(sector_corr_s - sector_corr_theta),
        "sector_alignment_gain_overlap": None if (overlap_mass_theta is None or overlap_mass_s is None) else float(overlap_mass_s - overlap_mass_theta),
    }

    true_flags = [v for v in invariance_flags.values() if isinstance(v, bool)]
    n_true = sum(true_flags)
    n_bool = len(true_flags)

    if n_bool == 0:
        verdict = "insufficient_evidence"
    elif n_true >= max(5, math.ceil(0.70 * n_bool)):
        verdict = "intrinsic_structure_supported"
    elif n_true >= max(3, math.ceil(0.40 * n_bool)):
        verdict = "mixed_evidence_partial_invariance"
    else:
        verdict = "structure_likely_coordinate_sensitive"

    return {
        "invariance_flags": invariance_flags,
        "sector_persistence_scores": sector_persistence_scores,
        "curvature_alignment_metrics": curvature_alignment_metrics,
        "stage6G_verdict": verdict,
    }


def maybe_load_json(path: Optional[Path]) -> Optional[dict]:
    if path is None or (not path.exists()):
        return None
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def summarize_intrinsic_profile(intrinsic: pd.DataFrame) -> Dict[str, object]:
    s = intrinsic["s"].to_numpy(dtype=float)
    abs_kappa = intrinsic["abs_kappa"].to_numpy(dtype=float)
    density = intrinsic["density"].to_numpy(dtype=float)
    ds_dtheta = intrinsic["ds_dtheta"].to_numpy(dtype=float)

    return {
        "n_points": int(len(intrinsic)),
        "s_total": float(s[-1]) if len(s) else None,
        "theta_min": float(intrinsic["theta"].min()),
        "theta_max": float(intrinsic["theta"].max()),
        "abs_kappa_mean": float(np.nanmean(abs_kappa)) if np.isfinite(abs_kappa).any() else None,
        "abs_kappa_max": float(np.nanmax(abs_kappa)) if np.isfinite(abs_kappa).any() else None,
        "density_mean": float(np.nanmean(density)) if np.isfinite(density).any() else None,
        "density_max": float(np.nanmax(density)) if np.isfinite(density).any() else None,
        "ds_dtheta_min": float(np.nanmin(ds_dtheta)) if np.isfinite(ds_dtheta).any() else None,
        "ds_dtheta_max": float(np.nanmax(ds_dtheta)) if np.isfinite(ds_dtheta).any() else None,
        "metric_flattening_note": "In theta-coordinates the boundary metric-like coefficient is g_thetatheta; in s-coordinates the line element is flattened by construction."
    }


def build_notes(summary: Dict[str, object]) -> str:
    verdict = summary["decisive_metrics"]["stage6G_verdict"]
    flags = summary["decisive_metrics"]["invariance_flags"]
    sector_scores = summary["decisive_metrics"]["sector_persistence_scores"]
    align = summary["decisive_metrics"]["curvature_alignment_metrics"]

    lines = []
    lines.append("============================================================")
    lines.append("STAGE-6G GEOMETRY NOTES")
    lines.append("Project: Quantum-Emergent Gravity")
    lines.append("============================================================")
    lines.append("")
    lines.append("DECISIVE VERDICT")
    lines.append("----------------")
    lines.append(str(verdict))
    lines.append("")
    lines.append("INVARIANCE FLAGS")
    lines.append("----------------")
    for k, v in flags.items():
        lines.append(f"{k}: {v}")
    lines.append("")
    lines.append("SECTOR PERSISTENCE SCORES")
    lines.append("-------------------------")
    for k, v in sector_scores.items():
        lines.append(f"{k}: {v}")
    lines.append("")
    lines.append("CURVATURE ALIGNMENT METRICS")
    lines.append("---------------------------")
    for k, v in align.items():
        lines.append(f"{k}: {v}")
    lines.append("")
    lines.append("INTERPRETATION")
    lines.append("--------------")
    lines.append(
        "This stage evaluates whether Stage-6F boundary anisotropy persists after "
        "intrinsic arc-length reparametrization. It remains a boundary-geometry test, "
        "not a GR identification."
    )
    lines.append("")
    lines.append("============================================================")
    return "\n".join(lines)


def main() -> None:
    log("[Stage-6G PRECHECK] Discovering project root...")
    project_root = discover_project_root()

    log("[Stage-6G PRECHECK] Locating required files...")
    located = locate_inputs(project_root)

    out_dir = project_root / OUTPUT_DIRNAME
    out_dir.mkdir(parents=True, exist_ok=True)

    log("[Stage-6G PRECHECK] Loading and standardizing Stage-6F profile...")
    df = load_curvature_profile(located.curvature_csv)
    df = enrich_missing_geometry(df)
    validate_geometry(df)

    log("[Stage-6G] Building intrinsic profile...")
    intrinsic = build_intrinsic_profile(df)

    log("[Stage-6G] Running sector persistence analysis...")
    sector_info = sector_analysis_theta_s(intrinsic)

    log("[Stage-6G] Computing decisive metrics...")
    decisive = compute_decisive_metrics(intrinsic, sector_info)

    summary = {
        "script_version": SCRIPT_VERSION,
        "input_files": {
            "stage6F_curvature_profile_csv": str(located.curvature_csv),
            "stage6F_anisotropy_summary_json": str(located.anisotropy_json) if located.anisotropy_json else None,
            "stage6F_geometry_notes_txt": str(located.notes_txt) if located.notes_txt else None,
            "stage6E_boundary_curve_csv_optional": str(located.stage6e_boundary_csv) if located.stage6e_boundary_csv else None,
        },
        "configuration": {
            "n_sectors": N_SECTORS,
            "high_q_curvature": HIGH_Q_CURVATURE,
            "high_q_density": HIGH_Q_DENSITY,
            "threshold_jaccard": THRESH_JACCARD,
            "threshold_rank_corr": THRESH_RANK_CORR,
            "threshold_alignment_improvement": THRESH_ALIGNMENT_IMPROVEMENT,
            "threshold_anisotropy_cv": THRESH_ANISOTROPY_CV,
        },
        "intrinsic_profile_summary": summarize_intrinsic_profile(intrinsic),
        "sector_analysis": sector_info,
        "decisive_metrics": decisive,
        "upstream_stage6F_anisotropy_summary": maybe_load_json(located.anisotropy_json),
    }

    notes_text = build_notes(summary)

    profile_path = out_dir / OUTPUT_PROFILE_FILENAME
    summary_path = out_dir / OUTPUT_SUMMARY_FILENAME
    notes_path = out_dir / OUTPUT_NOTES_FILENAME

    log("[Stage-6G] Writing CSV...")
    intrinsic.to_csv(profile_path, index=False)

    log("[Stage-6G] Writing JSON...")
    with summary_path.open("w", encoding="utf-8") as f:
        json.dump(to_builtin(summary), f, indent=2, ensure_ascii=False)

    log("[Stage-6G] Writing notes...")
    with notes_path.open("w", encoding="utf-8") as f:
        f.write(notes_text)

    log("[Stage-6G] Done.")
    log("[Stage-6G] Wrote:")
    log(f"  CSV : {profile_path}")
    log(f"  JSON: {summary_path}")
    log(f"  TXT : {notes_path}")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        log(f"[Stage-6G ERROR] {type(exc).__name__}: {exc}")
        raise
