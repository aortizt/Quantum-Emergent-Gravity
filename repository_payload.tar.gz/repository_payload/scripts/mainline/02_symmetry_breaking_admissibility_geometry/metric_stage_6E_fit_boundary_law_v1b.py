#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Stage-6E v1b
Quantum-Emergent Gravity

Fit a continuous law r_c(theta) to the empirical admissibility boundary
estimated in Stage-6D, with small-sample safeguards and more honest
stability diagnostics.

Key methodological revisions relative to v1/v1a:
    1) Small-sample model gating:
       - disallow over-parameterized models when boundary support is sparse
       - require a minimum rows-per-parameter ratio
    2) Better-conditioned Fourier fitting:
       - rescale theta onto a centered domain
       - prefer lower-order harmonics when conditioning is poor
       - record condition numbers explicitly
    3) Bootstrap revised:
       - evaluate bootstrap models on the ORIGINAL theta grid
       - report coefficient instability and predictive RMSE
       - avoid the artificial near-zero resubstitution effect
    4) Jitter revised:
       - perturb original theta bins and evaluate predictive degradation
    5) Family-conditioned handling revised:
       - only report family-specific laws when family profiles are genuinely distinct
       - flag collapsed/identical family profiles rather than overstating separation

Outputs:
    1) stage6E_boundary_function_fit_v1b.csv
    2) stage6E_boundary_function_parameters_v1b.json
    3) stage6E_family_boundary_function_v1b.csv
    4) stage6E_interpretive_notes_v1b.txt
"""

from __future__ import annotations

import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd


# ============================================================
# USER PATHS / PROJECT CONVENTIONS
# ============================================================
PROJECT_ROOT = Path("/home/dakini/Downloads/010-Quantum_Emergent_Gravity")
INPUT_DIR = PROJECT_ROOT / "metric_stage_6D_outputs"
OUTPUT_DIR = PROJECT_ROOT / "metric_stage_6E_outputs"

BOUNDARY_FILE = INPUT_DIR / "stage6D_boundary_estimate_v2.csv"
FAMILY_BOUNDARY_FILE = INPUT_DIR / "stage6D_family_boundary_estimate_v2.csv"
SUMMARY_FILE = INPUT_DIR / "stage6D_symmetry_breaking_summary_v2.json"


# ============================================================
# HELPERS
# ============================================================
def _print(msg: str) -> None:
    print(msg, flush=True)


def circular_wrap(theta: np.ndarray) -> np.ndarray:
    return np.mod(theta, 2.0 * np.pi)


def safe_float(x) -> float:
    try:
        return float(x)
    except Exception:
        return float("nan")


# ============================================================
# COLUMN DETECTION
# ============================================================
THETA_CANDIDATES = [
    "theta", "theta_center", "theta_mid", "theta_bin_center", "theta_bin",
    "angle", "angle_center", "angle_mid", "angular_coordinate",
]
RADIUS_CANDIDATES = [
    "r_c", "rc", "critical_radius", "boundary_radius", "radius",
    "r_boundary", "r_estimate", "r_cutoff", "r", "radial_coordinate",
    "estimated_r_critical",
]
COUNT_CANDIDATES = [
    "count", "n", "bin_count", "support_count", "sample_count",
    "occupancy", "point_count", "boundary_support_count",
]
FAMILY_CANDIDATES = [
    "family", "metric_family", "metric_name", "family_name",
]


def detect_column(df: pd.DataFrame, candidates: Sequence[str], required: bool = True) -> Optional[str]:
    lookup = {c.lower(): c for c in df.columns}
    for name in candidates:
        if name.lower() in lookup:
            return lookup[name.lower()]
    if required:
        raise KeyError(
            f"Could not find any of the expected columns {list(candidates)} in columns {list(df.columns)}"
        )
    return None


def coerce_theta_to_radians(theta: pd.Series) -> Tuple[pd.Series, str]:
    s = pd.to_numeric(theta, errors="coerce")
    finite = s[np.isfinite(s)]
    if finite.empty:
        return s, "unknown"

    max_abs = float(np.nanmax(np.abs(finite.to_numpy())))
    if max_abs > (2.0 * np.pi + 0.5):
        return np.deg2rad(s), "degrees_to_radians"
    return s, "radians"


# ============================================================
# MODEL SPECIFICATIONS
# ============================================================
@dataclass
class FitResult:
    model_name: str
    model_group: str
    n_params: int
    parameters: Dict[str, object]
    rmse: float
    mae: float
    r2: float
    max_abs_residual: float
    residual_sign_changes: int
    aic_like: float
    condition_number: float
    bootstrap_predictive_rmse_mean: float
    bootstrap_predictive_rmse_std: float
    bootstrap_parameter_cv_median: float
    jitter_predictive_rmse_mean: float
    jitter_predictive_rmse_std: float
    anisotropy_amplitude: float
    anisotropy_ratio: float
    fitted: np.ndarray
    residuals: np.ndarray
    warnings: List[str]


# ============================================================
# NUMERICAL HELPERS
# ============================================================
def theta_centered(theta: np.ndarray) -> np.ndarray:
    # map theta to [-pi, pi) around the circular mean to improve conditioning
    z = np.exp(1j * theta)
    mean_angle = np.angle(np.mean(z))
    centered = ((theta - mean_angle + np.pi) % (2.0 * np.pi)) - np.pi
    return centered


def design_trig(theta: np.ndarray, harmonics: Sequence[int], include_constant: bool = True) -> Tuple[np.ndarray, List[str]]:
    th = theta_centered(theta)
    cols = []
    labels = []
    if include_constant:
        cols.append(np.ones_like(th))
        labels.append("a0")
    for k in harmonics:
        cols.append(np.cos(k * th))
        labels.append(f"cos_{k}")
        cols.append(np.sin(k * th))
        labels.append(f"sin_{k}")
    X = np.column_stack(cols)
    return X, labels


def fit_linear_model(theta: np.ndarray, r: np.ndarray, harmonics: Sequence[int]) -> Tuple[np.ndarray, Dict[str, float], float]:
    X, labels = design_trig(theta, harmonics=harmonics, include_constant=True)
    cond = float(np.linalg.cond(X))
    beta, *_ = np.linalg.lstsq(X, r, rcond=None)
    fitted = X @ beta
    params = {labels[i]: float(beta[i]) for i in range(len(labels))}
    return fitted, params, cond


def fit_piecewise(theta: np.ndarray, r: np.ndarray, n_sectors: int) -> Tuple[np.ndarray, Dict[str, object], float]:
    edges = np.linspace(0.0, 2.0 * np.pi, n_sectors + 1)
    idx = np.digitize(theta, edges[1:-1], right=False)
    means = np.array([np.nanmean(r[idx == j]) if np.any(idx == j) else np.nan for j in range(n_sectors)])

    if np.any(~np.isfinite(means)):
        global_mean = float(np.nanmean(r))
        for j in range(n_sectors):
            if not np.isfinite(means[j]):
                means[j] = global_mean

    fitted = means[idx]
    params = {
        "n_sectors": int(n_sectors),
        "sector_edges": edges.tolist(),
        "sector_values": means.tolist(),
    }
    # simple conditioning proxy for piecewise: finite / stable if all sectors defined
    cond = 1.0
    return fitted, params, cond


# ============================================================
# DIAGNOSTICS
# ============================================================
def residual_sign_changes(residuals: np.ndarray) -> int:
    s = np.sign(residuals)
    s = s[s != 0]
    if len(s) < 2:
        return 0
    return int(np.sum(s[1:] != s[:-1]))


def compute_metrics(y: np.ndarray, yhat: np.ndarray, n_params: int) -> Dict[str, float]:
    resid = y - yhat
    mse = float(np.mean(resid ** 2))
    rmse = float(np.sqrt(mse))
    mae = float(np.mean(np.abs(resid)))
    sst = float(np.sum((y - np.mean(y)) ** 2))
    sse = float(np.sum(resid ** 2))
    r2 = 1.0 - sse / sst if sst > 0 else float("nan")
    n = len(y)
    aic_like = n * np.log(max(sse / max(n, 1), 1e-15)) + 2 * n_params
    return {
        "rmse": rmse,
        "mae": mae,
        "r2": float(r2),
        "max_abs_residual": float(np.max(np.abs(resid))),
        "residual_sign_changes": residual_sign_changes(resid),
        "aic_like": float(aic_like),
    }


def anisotropy_summary(yhat: np.ndarray) -> Dict[str, float]:
    ymin = float(np.min(yhat))
    ymax = float(np.max(yhat))
    amp = ymax - ymin
    mean_level = float(np.mean(yhat))
    ratio = amp / mean_level if abs(mean_level) > 1e-12 else float("nan")
    return {
        "anisotropy_amplitude": amp,
        "anisotropy_ratio": ratio,
    }


def bootstrap_predictive_metrics(
    theta: np.ndarray,
    r: np.ndarray,
    fit_callable,
    rng: np.random.Generator,
    n_params: int,
    n_boot: int = 400,
) -> Tuple[float, float, float]:
    """
    Revised bootstrap:
    - fit on bootstrap resample
    - evaluate predictions on original theta grid
    - summarize coefficient instability by median coefficient CV
    """
    pred_rmses: List[float] = []
    coeff_matrix: List[np.ndarray] = []
    n = len(theta)

    for _ in range(n_boot):
        idx = rng.integers(0, n, size=n)
        th_b = theta[idx]
        r_b = r[idx]
        try:
            _, params_b, _ = fit_callable(th_b, r_b)
            yhat_orig, _, _ = fit_callable(theta, r_b[np.argsort(th_b)[:0]])  # dummy to keep interface? will be overwritten
        except Exception:
            pass

        # explicit fit on bootstrap sample, predict on original grid
        fitted_boot, params_boot, _ = fit_callable(th_b, r_b)
        # rebuild using parameters by re-calling fit on original theta not possible generically;
        # instead define a closure outside this function that already predicts on arbitrary theta.
        # Here we rely on fit_callable exposing fit/predict semantics via optional attribute.
        if not hasattr(fit_callable, "predict"):
            raise AttributeError("fit_callable must provide a .predict(theta_fit, r_fit, theta_eval) method.")
        yhat_orig = fit_callable.predict(th_b, r_b, theta)
        pred_rmses.append(float(np.sqrt(np.mean((r - yhat_orig) ** 2))))

        coeffs = np.full(n_params, np.nan, dtype=float)
        if isinstance(params_boot, dict):
            # stable ordered extraction where possible
            vals = []
            for key in sorted(params_boot.keys()):
                v = params_boot[key]
                if isinstance(v, (int, float, np.floating)):
                    vals.append(float(v))
            vals = vals[:n_params]
            coeffs[:len(vals)] = vals
        coeff_matrix.append(coeffs)

    coeff_arr = np.array(coeff_matrix, dtype=float)
    with np.errstate(invalid="ignore", divide="ignore"):
        coeff_mean = np.nanmean(np.abs(coeff_arr), axis=0)
        coeff_std = np.nanstd(coeff_arr, axis=0, ddof=1)
        coeff_cv = coeff_std / np.maximum(coeff_mean, 1e-12)
    finite_cv = coeff_cv[np.isfinite(coeff_cv)]
    median_cv = float(np.nanmedian(finite_cv)) if finite_cv.size else float("nan")

    return (
        float(np.mean(pred_rmses)),
        float(np.std(pred_rmses, ddof=1)) if len(pred_rmses) > 1 else 0.0,
        median_cv,
    )


def jitter_predictive_metrics(
    theta: np.ndarray,
    r: np.ndarray,
    fit_callable,
    rng: np.random.Generator,
    n_jitter: int = 400,
    jitter_scale: float = 0.03,
) -> Tuple[float, float]:
    """
    Perturb theta bins, refit, evaluate on original theta grid.
    """
    pred_rmses: List[float] = []
    n = len(theta)

    for _ in range(n_jitter):
        th_j = circular_wrap(theta + rng.normal(0.0, jitter_scale, size=n))
        order = np.argsort(th_j)
        th_j = th_j[order]
        r_j = r[order]
        if not hasattr(fit_callable, "predict"):
            raise AttributeError("fit_callable must provide a .predict(theta_fit, r_fit, theta_eval) method.")
        yhat_orig = fit_callable.predict(th_j, r_j, theta)
        pred_rmses.append(float(np.sqrt(np.mean((r - yhat_orig) ** 2))))
    return (
        float(np.mean(pred_rmses)),
        float(np.std(pred_rmses, ddof=1)) if len(pred_rmses) > 1 else 0.0,
    )


# ============================================================
# FITTER CLASSES
# ============================================================
class TrigFitter:
    def __init__(self, harmonics: Sequence[int]):
        self.harmonics = list(harmonics)

    def __call__(self, theta_fit: np.ndarray, r_fit: np.ndarray):
        return fit_linear_model(theta_fit, r_fit, self.harmonics)

    def predict(self, theta_fit: np.ndarray, r_fit: np.ndarray, theta_eval: np.ndarray) -> np.ndarray:
        X_fit, labels = design_trig(theta_fit, harmonics=self.harmonics, include_constant=True)
        beta, *_ = np.linalg.lstsq(X_fit, r_fit, rcond=None)
        X_eval, _ = design_trig(theta_eval, harmonics=self.harmonics, include_constant=True)
        return X_eval @ beta


class PiecewiseFitter:
    def __init__(self, n_sectors: int):
        self.n_sectors = int(n_sectors)

    def __call__(self, theta_fit: np.ndarray, r_fit: np.ndarray):
        return fit_piecewise(theta_fit, r_fit, self.n_sectors)

    def predict(self, theta_fit: np.ndarray, r_fit: np.ndarray, theta_eval: np.ndarray) -> np.ndarray:
        edges = np.linspace(0.0, 2.0 * np.pi, self.n_sectors + 1)
        idx_fit = np.digitize(theta_fit, edges[1:-1], right=False)
        means = np.array([np.nanmean(r_fit[idx_fit == j]) if np.any(idx_fit == j) else np.nan for j in range(self.n_sectors)])
        global_mean = float(np.nanmean(r_fit))
        for j in range(self.n_sectors):
            if not np.isfinite(means[j]):
                means[j] = global_mean
        idx_eval = np.digitize(theta_eval, edges[1:-1], right=False)
        return means[idx_eval]


# ============================================================
# MODEL GATING / CANDIDATES
# ============================================================
def allowed_candidates(n_rows: int) -> List[Tuple[str, str, object, int]]:
    """
    Small-sample safeguard:
    Require roughly >= 2 rows per parameter for candidate admission.
    This is still permissive, but prevents near-interpolation regimes.
    """
    candidates = [
        ("trig_poly_order1", "trig_polynomial", TrigFitter([1]), 3),
        ("trig_poly_order2", "trig_polynomial", TrigFitter([1, 2]), 5),
        ("fourier_k1", "fourier", TrigFitter([1]), 3),
        ("fourier_k2", "fourier", TrigFitter([1, 2]), 5),
        ("fourier_k3", "fourier", TrigFitter([1, 2, 3]), 7),
        ("piecewise_8", "piecewise", PiecewiseFitter(8), 8),
        ("piecewise_12", "piecewise", PiecewiseFitter(12), 12),
    ]
    out = []
    for model_name, group, fitter, n_params in candidates:
        if n_rows >= max(6, 2 * n_params):
            out.append((model_name, group, fitter, n_params))
    # guarantee at least low-order models remain
    if not out:
        out = [
            ("trig_poly_order1", "trig_polynomial", TrigFitter([1]), 3),
            ("fourier_k1", "fourier", TrigFitter([1]), 3),
        ]
    return out


def build_candidates(theta: np.ndarray, r: np.ndarray, rng: np.random.Generator) -> List[FitResult]:
    results: List[FitResult] = []
    n_rows = len(theta)

    for model_name, group, fitter, n_params in allowed_candidates(n_rows):
        warnings: List[str] = []
        yhat, params, cond = fitter(theta, r)
        metrics = compute_metrics(r, yhat, n_params=n_params)
        anis = anisotropy_summary(yhat)
        boot_mean, boot_std, boot_cv = bootstrap_predictive_metrics(theta, r, fitter, rng=rng, n_params=n_params)
        jit_mean, jit_std = jitter_predictive_metrics(theta, r, fitter, rng=rng)

        if cond > 1e6:
            warnings.append("poor_conditioning")
        if n_rows < 2 * n_params + 2:
            warnings.append("sparse_support_relative_to_parameters")
        if jit_std > max(0.10, 0.50 * jit_mean):
            warnings.append("theta_jitter_instability")

        results.append(
            FitResult(
                model_name=model_name,
                model_group=group,
                n_params=n_params,
                parameters=params,
                rmse=metrics["rmse"],
                mae=metrics["mae"],
                r2=metrics["r2"],
                max_abs_residual=metrics["max_abs_residual"],
                residual_sign_changes=metrics["residual_sign_changes"],
                aic_like=metrics["aic_like"],
                condition_number=cond,
                bootstrap_predictive_rmse_mean=boot_mean,
                bootstrap_predictive_rmse_std=boot_std,
                bootstrap_parameter_cv_median=boot_cv,
                jitter_predictive_rmse_mean=jit_mean,
                jitter_predictive_rmse_std=jit_std,
                anisotropy_amplitude=anis["anisotropy_amplitude"],
                anisotropy_ratio=anis["anisotropy_ratio"],
                fitted=yhat,
                residuals=r - yhat,
                warnings=warnings,
            )
        )

    return results


def choose_best(results: Sequence[FitResult]) -> FitResult:
    """
    Conservative model choice:
      1) predictive RMSE first
      2) penalize poor conditioning / instability
      3) prefer lower complexity when close
      4) prefer smooth periodic over piecewise when near tied
    """
    def penalty(res: FitResult) -> float:
        p = 0.0
        if res.condition_number > 1e6:
            p += 0.15 * max(res.rmse, 1e-12)
        if "theta_jitter_instability" in res.warnings:
            p += 0.10 * max(res.rmse, 1e-12)
        p += 0.02 * res.n_params
        return p

    ordered = sorted(
        results,
        key=lambda r: (
            r.bootstrap_predictive_rmse_mean + penalty(r),
            r.jitter_predictive_rmse_mean,
            r.n_params,
            1 if r.model_group == "piecewise" else 0,
        ),
    )

    best = ordered[0]
    for alt in ordered[1:]:
        score_best = best.bootstrap_predictive_rmse_mean + penalty(best)
        score_alt = alt.bootstrap_predictive_rmse_mean + penalty(alt)
        rel_gap = (score_alt - score_best) / max(score_best, 1e-12)
        if 0 <= rel_gap <= 0.10:
            # near-tie: prefer simpler / better-conditioned / smoother
            if alt.n_params < best.n_params:
                best = alt
            elif alt.condition_number < best.condition_number / 10.0:
                best = alt
            elif best.model_group == "piecewise" and alt.model_group != "piecewise":
                best = alt
    return best


# ============================================================
# DATA PREP
# ============================================================
def prepare_boundary_df(df: pd.DataFrame) -> Tuple[pd.DataFrame, Dict[str, object]]:
    theta_col = detect_column(df, THETA_CANDIDATES, required=True)
    r_col = detect_column(df, RADIUS_CANDIDATES, required=True)
    count_col = detect_column(df, COUNT_CANDIDATES, required=False)

    theta_rad, theta_action = coerce_theta_to_radians(df[theta_col])
    out = pd.DataFrame({
        "theta": circular_wrap(theta_rad.to_numpy(dtype=float)),
        "empirical_r_c": pd.to_numeric(df[r_col], errors="coerce").to_numpy(dtype=float),
    })

    if count_col is not None:
        out["count"] = pd.to_numeric(df[count_col], errors="coerce").to_numpy(dtype=float)
    else:
        out["count"] = np.nan

    out = out.replace([np.inf, -np.inf], np.nan).dropna(subset=["theta", "empirical_r_c"]).copy()

    count_filter_applied = False
    count_threshold = None
    if out["count"].notna().any():
        valid_counts = out.loc[out["count"].notna(), "count"]
        # gentler rule than v1a: do not discard lower-support bins automatically;
        # record threshold instead, but keep the full empirical boundary unless
        # counts are truly degenerate.
        count_threshold = max(1.0, float(np.nanquantile(valid_counts, 0.10)))
        if np.nanmin(valid_counts) <= 0:
            before = len(out)
            out = out[(out["count"].isna()) | (out["count"] > 0)].copy()
            count_filter_applied = len(out) < before

    out = out.sort_values("theta").reset_index(drop=True)

    meta = {
        "theta_source_column": theta_col,
        "radius_source_column": r_col,
        "count_source_column": count_col,
        "theta_unit_action": theta_action,
        "count_filter_applied": count_filter_applied,
        "count_threshold_reference_only": count_threshold,
        "n_rows_after_cleaning": int(len(out)),
    }
    return out, meta


# ============================================================
# FAMILY FITS
# ============================================================
def fit_family_models(df_family: pd.DataFrame, rng: np.random.Generator) -> Tuple[pd.DataFrame, List[Dict[str, object]], Dict[str, object]]:
    family_col = detect_column(df_family, FAMILY_CANDIDATES, required=True)
    theta_col = detect_column(df_family, THETA_CANDIDATES, required=True)
    r_col = detect_column(df_family, RADIUS_CANDIDATES, required=True)

    theta_rad, _ = coerce_theta_to_radians(df_family[theta_col])
    work = pd.DataFrame({
        "family": df_family[family_col].astype(str),
        "theta": circular_wrap(theta_rad.to_numpy(dtype=float)),
        "empirical_r_c": pd.to_numeric(df_family[r_col], errors="coerce").to_numpy(dtype=float),
    }).replace([np.inf, -np.inf], np.nan).dropna()

    outputs = []
    summaries: List[Dict[str, object]] = []

    family_profiles = {}
    for family, g in work.groupby("family"):
        g = g.sort_values("theta").reset_index(drop=True)
        if len(g) < 6:
            continue
        family_profiles[family] = np.round(g["empirical_r_c"].to_numpy(dtype=float), 10)

    distinct_profile_count = len({tuple(v.tolist()) for v in family_profiles.values()}) if family_profiles else 0
    profile_status = "distinct" if distinct_profile_count > 1 else "collapsed_or_identical"

    for family, g in work.groupby("family"):
        g = g.sort_values("theta").reset_index(drop=True)
        if len(g) < 6:
            continue
        results = build_candidates(g["theta"].to_numpy(), g["empirical_r_c"].to_numpy(), rng=rng)
        best = choose_best(results)
        temp = g.copy()
        temp["fitted_r_c"] = best.fitted
        temp["residual"] = best.residuals
        temp["selected_model"] = best.model_name
        temp["family_profile_status"] = profile_status
        outputs.append(temp)
        summaries.append({
            "family": family,
            "selected_model": best.model_name,
            "selected_model_group": best.model_group,
            "rmse": best.rmse,
            "mae": best.mae,
            "r2": best.r2,
            "condition_number": best.condition_number,
            "bootstrap_predictive_rmse_mean": best.bootstrap_predictive_rmse_mean,
            "jitter_predictive_rmse_mean": best.jitter_predictive_rmse_mean,
            "anisotropy_amplitude": best.anisotropy_amplitude,
            "anisotropy_ratio": best.anisotropy_ratio,
            "parameters": best.parameters,
            "warnings": best.warnings,
        })

    family_meta = {
        "family_profile_status": profile_status,
        "distinct_profile_count": distinct_profile_count,
        "families_with_usable_profiles": sorted(list(family_profiles.keys())),
    }

    if outputs:
        return pd.concat(outputs, ignore_index=True), summaries, family_meta
    return pd.DataFrame(columns=["family", "theta", "empirical_r_c", "fitted_r_c", "residual", "selected_model"]), summaries, family_meta


# ============================================================
# NOTES / INTERPRETATION
# ============================================================
def classify_curvature(best: FitResult) -> str:
    ratio = best.anisotropy_ratio
    if not np.isfinite(ratio):
        return "undetermined"
    if ratio < 0.01:
        return "approximately isotropic / nearly flat boundary"
    if ratio < 0.05:
        return "weakly anisotropic boundary"
    if ratio < 0.15:
        return "moderately anisotropic boundary"
    return "strongly anisotropic boundary"


def stability_text(best: FitResult) -> str:
    rel_boot = best.bootstrap_predictive_rmse_std / max(best.bootstrap_predictive_rmse_mean, 1e-12)
    rel_jitter = best.jitter_predictive_rmse_std / max(best.jitter_predictive_rmse_mean, 1e-12)
    worst = max(rel_boot, rel_jitter)
    if worst < 0.05:
        return "high predictive stability under bootstrap / theta jitter perturbations"
    if worst < 0.15:
        return "moderate predictive stability under bootstrap / theta jitter perturbations"
    return "limited predictive stability; fitted law may depend noticeably on binning or sparse support"


def make_notes(
    best: FitResult,
    all_results: Sequence[FitResult],
    meta: Dict[str, object],
    family_summaries: Sequence[Dict[str, object]],
    family_meta: Dict[str, object],
) -> str:
    lines: List[str] = []
    lines.append("STAGE-6E INTERPRETIVE NOTES (v1b)")
    lines.append("=" * 60)
    lines.append("")
    lines.append("1) Data preparation")
    lines.append(f"- Theta source column: {meta['theta_source_column']}")
    lines.append(f"- Radius source column: {meta['radius_source_column']}")
    lines.append(f"- Theta normalization: {meta['theta_unit_action']}")
    lines.append(f"- Rows after cleaning: {meta['n_rows_after_cleaning']}")
    if meta["count_source_column"] is not None:
        lines.append(f"- Count column used: {meta['count_source_column']}")
        lines.append(f"- Count filtering applied: {meta['count_filter_applied']}")
        lines.append(f"- Count threshold reference (not automatic exclusion): {meta['count_threshold_reference_only']}")
    else:
        lines.append("- No count/support column detected.")
    lines.append("")
    lines.append("2) Selected functional law")
    lines.append(f"- Selected model: {best.model_name} [{best.model_group}]")
    lines.append(f"- Parameter count: {best.n_params}")
    lines.append(f"- RMSE: {best.rmse:.6g}")
    lines.append(f"- MAE: {best.mae:.6g}")
    lines.append(f"- R^2: {best.r2:.6g}")
    lines.append(f"- Max |residual|: {best.max_abs_residual:.6g}")
    lines.append(f"- Residual sign changes: {best.residual_sign_changes}")
    lines.append(f"- Design-matrix condition number: {best.condition_number:.6g}")
    if best.warnings:
        lines.append(f"- Fit warnings: {', '.join(best.warnings)}")
    else:
        lines.append("- Fit warnings: none")
    lines.append("")
    lines.append("3) Geometric classification")
    lines.append(f"- Boundary classification: {classify_curvature(best)}")
    lines.append(f"- Anisotropy amplitude max(fitted) - min(fitted): {best.anisotropy_amplitude:.6g}")
    lines.append(f"- Relative anisotropy amplitude / mean radius: {best.anisotropy_ratio:.6g}")
    lines.append("")
    lines.append("4) Revised stability assessment")
    lines.append(
        f"- Bootstrap predictive RMSE mean ± std: {best.bootstrap_predictive_rmse_mean:.6g} ± {best.bootstrap_predictive_rmse_std:.6g}"
    )
    lines.append(f"- Bootstrap median coefficient CV: {best.bootstrap_parameter_cv_median:.6g}")
    lines.append(
        f"- Theta-jitter predictive RMSE mean ± std: {best.jitter_predictive_rmse_mean:.6g} ± {best.jitter_predictive_rmse_std:.6g}"
    )
    lines.append(f"- Interpretation: {stability_text(best)}")
    lines.append("")
    lines.append("5) Physical interpretation")
    lines.append(
        "- The fitted law r_c(theta) acts as an intrinsic admissibility frontier in the Stage-5D/6D intrinsic coordinates."
    )
    lines.append(
        "- Nonconstant angular dependence indicates that admissibility is not purely radial: the allowed region depends on direction in intrinsic coordinate space."
    )
    lines.append(
        "- The revised selection emphasizes predictive stability and numerical conditioning, so the chosen law should be read as a conservative empirical constitutive law rather than a maximal-complexity interpolation."
    )
    lines.append(
        "- This remains proto-metric structure: a directional constraint surface, not yet a full GR metric identification."
    )
    lines.append("")
    lines.append("6) Model comparison snapshot")
    ranking = sorted(all_results, key=lambda x: (x.bootstrap_predictive_rmse_mean, x.n_params))
    for i, res in enumerate(ranking, start=1):
        lines.append(
            f"- {i}. {res.model_name:18s} | pred_boot_RMSE={res.bootstrap_predictive_rmse_mean:.6g} | R^2={res.r2:.6g} | cond={res.condition_number:.3g} | n_params={res.n_params}"
        )
    lines.append("")
    lines.append("7) Family-conditioned remarks")
    lines.append(f"- Family profile status: {family_meta.get('family_profile_status', 'unknown')}")
    if family_meta.get("family_profile_status") == "collapsed_or_identical":
        lines.append("- Family boundary profiles are identical or collapsed at the available resolution, so Stage-6E v1b does not claim meaningful family separation.")
    if family_summaries:
        for item in family_summaries:
            lines.append(
                f"- {item['family']}: {item['selected_model']} | pred_boot_RMSE={item['bootstrap_predictive_rmse_mean']:.6g} | anisotropy_ratio={item['anisotropy_ratio']:.6g}"
            )
    else:
        lines.append("- No usable family-conditioned boundary file was available, or no family had enough valid rows.")
    lines.append("")
    lines.append("8) Conservative conclusion")
    lines.append(
        "- Stage-6E v1b is successful if it preserves the anisotropic boundary signal while suppressing artifacts from sparse support, ill-conditioning, and near-interpolation."
    )
    lines.append(
        "- Any later Stage-6F/6G should treat the fitted law as an empirical boundary law and ask whether a deeper invariant, action-like, or effective-geometry principle reproduces it."
    )
    return "\n".join(lines) + "\n"


# ============================================================
# MAIN
# ============================================================
def main() -> None:
    rng = np.random.default_rng(20260407)

    _print("[Stage-6E v1b PRECHECK] Creating output directory...")
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    _print("[Stage-6E v1b PRECHECK] Checking required files...")
    if not BOUNDARY_FILE.exists():
        raise FileNotFoundError(f"Required input not found: {BOUNDARY_FILE}")

    _print("[Stage-6E v1b PRECHECK] Loading Stage-6D boundary table...")
    df = pd.read_csv(BOUNDARY_FILE)
    boundary_df, meta = prepare_boundary_df(df)
    if len(boundary_df) < 6:
        raise ValueError("Not enough valid boundary rows after cleaning to fit Stage-6E v1b models.")

    theta = boundary_df["theta"].to_numpy(dtype=float)
    r = boundary_df["empirical_r_c"].to_numpy(dtype=float)

    _print("[Stage-6E v1b] Fitting candidate models with small-sample safeguards...")
    results = build_candidates(theta, r, rng=rng)
    best = choose_best(results)

    _print(f"[Stage-6E v1b] Selected best model: {best.model_name}")

    fit_table = boundary_df[["theta", "empirical_r_c"]].copy()
    fit_table["fitted_r_c"] = best.fitted
    fit_table["residual"] = best.residuals
    fit_table["selected_model"] = best.model_name

    params_json: Dict[str, object] = {
        "stage": "6E",
        "version": "v1b",
        "selected_model": {
            "model_type": best.model_group,
            "model_name": best.model_name,
            "n_params": best.n_params,
            "coefficients": best.parameters,
            "fit_error_metrics": {
                "rmse": best.rmse,
                "mae": best.mae,
                "r2": best.r2,
                "max_abs_residual": best.max_abs_residual,
                "residual_sign_changes": best.residual_sign_changes,
                "aic_like": best.aic_like,
            },
            "numerical_diagnostics": {
                "condition_number": best.condition_number,
                "warnings": best.warnings,
            },
            "stability_metrics": {
                "bootstrap_predictive_rmse_mean": best.bootstrap_predictive_rmse_mean,
                "bootstrap_predictive_rmse_std": best.bootstrap_predictive_rmse_std,
                "bootstrap_parameter_cv_median": best.bootstrap_parameter_cv_median,
                "jitter_predictive_rmse_mean": best.jitter_predictive_rmse_mean,
                "jitter_predictive_rmse_std": best.jitter_predictive_rmse_std,
            },
            "anisotropy_metrics": {
                "anisotropy_amplitude": best.anisotropy_amplitude,
                "anisotropy_ratio": best.anisotropy_ratio,
                "classification": classify_curvature(best),
            },
        },
        "data_preparation": meta,
        "model_gating_rule": {
            "minimum_rows_per_parameter_target": 2.0,
            "purpose": "avoid near-interpolation and small-sample overfitting"
        },
        "all_candidate_models": [
            {
                "model_name": res.model_name,
                "model_group": res.model_group,
                "n_params": res.n_params,
                "parameters": res.parameters,
                "rmse": res.rmse,
                "mae": res.mae,
                "r2": res.r2,
                "max_abs_residual": res.max_abs_residual,
                "residual_sign_changes": res.residual_sign_changes,
                "aic_like": res.aic_like,
                "condition_number": res.condition_number,
                "bootstrap_predictive_rmse_mean": res.bootstrap_predictive_rmse_mean,
                "bootstrap_predictive_rmse_std": res.bootstrap_predictive_rmse_std,
                "bootstrap_parameter_cv_median": res.bootstrap_parameter_cv_median,
                "jitter_predictive_rmse_mean": res.jitter_predictive_rmse_mean,
                "jitter_predictive_rmse_std": res.jitter_predictive_rmse_std,
                "anisotropy_amplitude": res.anisotropy_amplitude,
                "anisotropy_ratio": res.anisotropy_ratio,
                "warnings": res.warnings,
            }
            for res in results
        ],
    }

    family_fit_df = pd.DataFrame()
    family_summaries: List[Dict[str, object]] = []
    family_meta: Dict[str, object] = {}
    if FAMILY_BOUNDARY_FILE.exists():
        _print("[Stage-6E v1b] Loading family-conditioned boundary file...")
        try:
            df_family = pd.read_csv(FAMILY_BOUNDARY_FILE)
            family_fit_df, family_summaries, family_meta = fit_family_models(df_family, rng=rng)
            params_json["family_conditioned_models"] = family_summaries
            params_json["family_conditioned_meta"] = family_meta
        except Exception as exc:
            params_json["family_conditioned_models_error"] = str(exc)
            _print(f"[Stage-6E v1b WARNING] Could not fit family-conditioned models: {exc}")

    notes = make_notes(best, results, meta, family_summaries, family_meta)

    _print("[Stage-6E v1b] Writing CSV / JSON / notes...")
    fit_csv = OUTPUT_DIR / "stage6E_boundary_function_fit_v1b.csv"
    json_out = OUTPUT_DIR / "stage6E_boundary_function_parameters_v1b.json"
    family_csv = OUTPUT_DIR / "stage6E_family_boundary_function_v1b.csv"
    notes_txt = OUTPUT_DIR / "stage6E_interpretive_notes_v1b.txt"

    fit_table.to_csv(fit_csv, index=False)
    with open(json_out, "w", encoding="utf-8") as f:
        json.dump(params_json, f, indent=2)
    family_fit_df.to_csv(family_csv, index=False)
    notes_txt.write_text(notes, encoding="utf-8")

    _print("[Stage-6E v1b] Done.")
    _print(f"[Stage-6E v1b] Wrote:\n  CSV : {fit_csv}\n  JSON: {json_out}\n  FAM : {family_csv}\n  TXT : {notes_txt}")


if __name__ == "__main__":
    main()
