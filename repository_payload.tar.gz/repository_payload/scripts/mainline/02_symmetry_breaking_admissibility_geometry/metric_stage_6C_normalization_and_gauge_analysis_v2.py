# -*- coding: utf-8 -*-
"""
metric_stage_6C_normalization_and_gauge_analysis_v2.py

Stage-6C v2 — normalization / gauge / admissibility / common-support analysis

Design goals
------------
1) Keep admissible transformed cases.
2) Mark inadmissible cases explicitly instead of crashing.
3) Compute common-support rankings fairly.
4) Record symmetry-breaking patterns as differences in admissibility coverage.

Upstream files expected
-----------------------
- Stage-6A pairwise CSV
- Stage-6B evaluation table

Outputs
-------
- stage6C_metric_invariance_table_v2.csv
- stage6C_metric_invariance_summary_v2.json
- stage6C_interpretive_notes_v2.txt
"""

from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd


# ============================================================================
# PATHS
# ============================================================================

ROOT = "/home/dakini/Downloads/010-Quantum_Emergent_Gravity"

STAGE6A_CSV = os.path.join(
    ROOT,
    "metric_stage_6A_outputs",
    "stage6A_metric_candidates_pairwise_distances_v1.csv",
)

STAGE6B_CSV = os.path.join(
    ROOT,
    "metric_stage_6B_outputs",
    "stage6B_metric_evaluation_table_v1.csv",
)

OUT_DIR = os.path.join(ROOT, "metric_stage_6C_outputs")
OUT_CSV = os.path.join(OUT_DIR, "stage6C_metric_invariance_table_v2.csv")
OUT_JSON = os.path.join(OUT_DIR, "stage6C_metric_invariance_summary_v2.json")
OUT_TXT = os.path.join(OUT_DIR, "stage6C_interpretive_notes_v2.txt")


# ============================================================================
# CONFIG
# ============================================================================

REQUIRED_STAGE6A_COLUMNS = [
    "FIT",
    "metric_id_i",
    "metric_id_j",
    "metric_name",
    "alpha",
    "beta",
    "distance_squared",
    "dr",
    "dtheta",
    "r_i",
    "r_j",
]

REQUIRED_STAGE6B_COLUMNS = [
    "metric_name",
    "alpha",
    "beta",
    "FIT",
    "distance_vs_abs_dtheta_spearman",
    "distance_vs_abs_dr_spearman",
    "component_balance_score",
    "local_smoothness_score",
    "angular_monotone_bin_fraction",
    "degeneracy_indicator",
]

PRIMARY_FAMILIES = ["hybrid", "radial_weighted"]
SECONDARY_FAMILIES = ["euclidean", "log_radial"]
ALL_FAMILIES = PRIMARY_FAMILIES + SECONDARY_FAMILIES
PRIMARY_FIT = "BARI"

TRANSFORM_SPECS = [
    {"transformation_type": "baseline", "transformation_value": None, "mode": "baseline"},
    {"transformation_type": "radial_scale", "transformation_value": 0.5, "mode": "radial"},
    {"transformation_type": "radial_scale", "transformation_value": 2.0, "mode": "radial"},
    {"transformation_type": "radial_shift", "transformation_value": 0.1, "mode": "radial"},
    {"transformation_type": "radial_shift", "transformation_value": 0.5, "mode": "radial"},
    {"transformation_type": "radial_log", "transformation_value": None, "mode": "radial"},
    {"transformation_type": "radial_zscore", "transformation_value": None, "mode": "radial"},
    {"transformation_type": "theta_scale", "transformation_value": 0.5, "mode": "theta"},
    {"transformation_type": "theta_scale", "transformation_value": 2.0, "mode": "theta"},
    {"transformation_type": "theta_center", "transformation_value": "mean_center", "mode": "theta"},
    {"transformation_type": "theta_wrap_2pi", "transformation_value": "mod_2pi", "mode": "theta"},
]


# ============================================================================
# SMALL UTILITIES
# ============================================================================

def utc_now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)


def check_file(path: str) -> None:
    if not os.path.exists(path):
        raise FileNotFoundError(f"Missing required file:\n  {path}")


def validate_columns(df: pd.DataFrame, required: List[str], label: str) -> None:
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise KeyError(f"{label} missing required columns:\n  - " + "\n  - ".join(missing))


def robust_spearman(x: np.ndarray, y: np.ndarray) -> float:
    if len(x) < 2 or len(y) < 2:
        return np.nan
    xs = pd.Series(x).rank(method="average")
    ys = pd.Series(y).rank(method="average")
    if xs.nunique() < 2 or ys.nunique() < 2:
        return np.nan
    return float(xs.corr(ys, method="pearson"))


def pretty_float(x, ndigits: int = 6):
    if pd.isna(x):
        return None
    return round(float(x), ndigits)


def safe_json_value(x):
    if isinstance(x, (np.integer,)):
        return int(x)
    if isinstance(x, (np.floating,)):
        return None if np.isnan(x) else float(x)
    if pd.isna(x):
        return None
    return x


# ============================================================================
# ACTUAL STAGE-6A METRIC FORMULAS
# ============================================================================

def compute_distance_squared(
    metric_name: str,
    alpha: float,
    beta: float,
    dr: np.ndarray,
    dtheta: np.ndarray,
    r_i: np.ndarray,
    r_j: np.ndarray,
) -> np.ndarray:
    dr2 = np.square(dr)
    dt2 = np.square(dtheta)
    m = str(metric_name).strip().lower()

    if m == "euclidean":
        return alpha * dr2 + beta * dt2

    if m == "log_radial":
        return alpha * np.square(np.log(r_i) - np.log(r_j)) + beta * dt2

    if m == "hybrid":
        return alpha * dr2 + beta * np.sqrt(r_i * r_j) * dt2

    if m == "radial_weighted":
        return alpha * dr2 + beta * np.square((r_i + r_j) / 2.0) * dt2

    raise ValueError(f"Unsupported metric_name: {metric_name}")


def compute_component_proxies(
    metric_name: str,
    alpha: float,
    beta: float,
    dr: np.ndarray,
    dtheta: np.ndarray,
    r_i: np.ndarray,
    r_j: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Return radial_proxy, angular_proxy aligned with the actual Stage-6A family formula.
    """
    dr2 = np.square(dr)
    dt2 = np.square(dtheta)
    m = str(metric_name).strip().lower()

    if m == "euclidean":
        return alpha * dr2, beta * dt2

    if m == "log_radial":
        return alpha * np.square(np.log(r_i) - np.log(r_j)), beta * dt2

    if m == "hybrid":
        return alpha * dr2, beta * np.sqrt(r_i * r_j) * dt2

    if m == "radial_weighted":
        return alpha * dr2, beta * np.square((r_i + r_j) / 2.0) * dt2

    raise ValueError(f"Unsupported metric_name: {metric_name}")


# ============================================================================
# ADMISSIBILITY
# ============================================================================

def check_admissibility(metric_name: str, r_i: np.ndarray, r_j: np.ndarray) -> Tuple[bool, str]:
    m = str(metric_name).strip().lower()

    if m == "hybrid":
        if np.any((r_i * r_j) < 0):
            return False, "sqrt_negative_argument"

    if m == "log_radial":
        if np.any(r_i <= 0) or np.any(r_j <= 0):
            return False, "log_nonpositive_radius"

    return True, ""


# ============================================================================
# TRANSFORMS
# ============================================================================

def apply_radial_transform(
    r_i: np.ndarray,
    r_j: np.ndarray,
    transformation_type: str,
    transformation_value,
) -> Tuple[np.ndarray, np.ndarray]:
    if transformation_type == "baseline":
        return r_i.copy(), r_j.copy()

    if transformation_type == "radial_scale":
        c = float(transformation_value)
        return c * r_i, c * r_j

    if transformation_type == "radial_shift":
        c = float(transformation_value)
        return r_i + c, r_j + c

    if transformation_type == "radial_log":
        return np.log(r_i), np.log(r_j)

    if transformation_type == "radial_zscore":
        pooled = np.concatenate([r_i, r_j])
        mu = float(np.mean(pooled))
        sigma = float(np.std(pooled, ddof=0))
        if sigma == 0.0:
            raise ValueError("radial_zscore_zero_std")
        return (r_i - mu) / sigma, (r_j - mu) / sigma

    raise ValueError(f"Unknown radial transform: {transformation_type}")


def apply_theta_transform(
    dtheta: np.ndarray,
    transformation_type: str,
    transformation_value,
) -> np.ndarray:
    if transformation_type == "baseline":
        return dtheta.copy()

    if transformation_type == "theta_scale":
        c = float(transformation_value)
        return c * dtheta

    if transformation_type == "theta_center":
        # Pairwise dtheta is unaffected by centering of endpoint coordinates.
        return dtheta.copy()

    if transformation_type == "theta_wrap_2pi":
        return np.mod(dtheta, 2.0 * np.pi)

    raise ValueError(f"Unknown theta transform: {transformation_type}")


def transform_group(group: pd.DataFrame, spec: Dict) -> pd.DataFrame:
    g = group.copy()
    ttype = spec["transformation_type"]
    mode = spec["mode"]
    tvalue = spec["transformation_value"]

    if mode == "baseline":
        return g

    if mode == "radial":
        # Guard domain for the transform itself first.
        if ttype == "radial_log":
            if np.any(g["r_i"].to_numpy(dtype=float) <= 0) or np.any(g["r_j"].to_numpy(dtype=float) <= 0):
                raise ValueError("radial_log_transform_nonpositive_radius")

        r_i_new, r_j_new = apply_radial_transform(
            g["r_i"].to_numpy(dtype=float),
            g["r_j"].to_numpy(dtype=float),
            ttype,
            tvalue,
        )
        g["r_i"] = r_i_new
        g["r_j"] = r_j_new
        g["dr"] = g["r_j"].to_numpy(dtype=float) - g["r_i"].to_numpy(dtype=float)
        return g

    if mode == "theta":
        g["dtheta"] = apply_theta_transform(
            g["dtheta"].to_numpy(dtype=float),
            ttype,
            tvalue,
        )
        return g

    raise ValueError(f"Unknown transformation mode: {mode}")


# ============================================================================
# DIAGNOSTICS
# ============================================================================

def suffix_num(s: str) -> int:
    tail = str(s).split("_")[-1]
    return int(tail)


def compute_local_smoothness_score(group: pd.DataFrame, distance_squared: np.ndarray) -> float:
    try:
        idx_i = group["metric_id_i"].astype(str).map(suffix_num).to_numpy(dtype=int)
        idx_j = group["metric_id_j"].astype(str).map(suffix_num).to_numpy(dtype=int)
    except Exception:
        return np.nan

    local_sep = np.abs(idx_j - idx_i).astype(float)
    return robust_spearman(local_sep, distance_squared)


def compute_angular_monotone_bin_fraction(dtheta_abs: np.ndarray, distance_squared: np.ndarray) -> float:
    df = pd.DataFrame({"dtheta_abs": dtheta_abs, "distance_squared": distance_squared})
    grp = (
        df.groupby("dtheta_abs", dropna=False)["distance_squared"]
        .mean()
        .reset_index()
        .sort_values("dtheta_abs")
    )
    means = grp["distance_squared"].to_list()

    valid_pairs = 0
    ok_pairs = 0
    for a, b in zip(means[:-1], means[1:]):
        if pd.isna(a) or pd.isna(b):
            continue
        valid_pairs += 1
        if b >= a:
            ok_pairs += 1

    return np.nan if valid_pairs == 0 else float(ok_pairs / valid_pairs)


def compute_degeneracy_indicator(distance_squared: np.ndarray) -> float:
    n = len(distance_squared)
    if n == 0:
        return np.nan
    unique_count = pd.Series(distance_squared).nunique(dropna=False)
    return float(1.0 - unique_count / n)


def compute_group_diagnostics(group: pd.DataFrame) -> Dict[str, float]:
    metric_name = str(group["metric_name"].iloc[0]).strip().lower()
    alpha = float(group["alpha"].iloc[0])
    beta = float(group["beta"].iloc[0])

    dr = group["dr"].to_numpy(dtype=float)
    dtheta = group["dtheta"].to_numpy(dtype=float)
    r_i = group["r_i"].to_numpy(dtype=float)
    r_j = group["r_j"].to_numpy(dtype=float)

    distance_squared = compute_distance_squared(metric_name, alpha, beta, dr, dtheta, r_i, r_j)
    if np.any(~np.isfinite(distance_squared)):
        raise ValueError("nonfinite_distance_squared")

    radial_proxy, angular_proxy = compute_component_proxies(metric_name, alpha, beta, dr, dtheta, r_i, r_j)

    total_proxy = radial_proxy + angular_proxy
    with np.errstate(divide="ignore", invalid="ignore"):
        angular_share = np.where(total_proxy > 0, angular_proxy / total_proxy, np.nan)
        radial_share = np.where(total_proxy > 0, radial_proxy / total_proxy, np.nan)

    mean_ang_share = float(np.nanmean(angular_share)) if np.any(np.isfinite(angular_share)) else np.nan
    mean_rad_share = float(np.nanmean(radial_share)) if np.any(np.isfinite(radial_share)) else np.nan
    balance_score = (
        float(1.0 - abs(mean_ang_share - mean_rad_share))
        if (not pd.isna(mean_ang_share) and not pd.isna(mean_rad_share))
        else np.nan
    )

    theta_rho = robust_spearman(distance_squared, np.abs(dtheta))
    dr_rho = robust_spearman(distance_squared, np.abs(dr))
    smoothness = compute_local_smoothness_score(group, distance_squared)
    monotonicity = compute_angular_monotone_bin_fraction(np.abs(dtheta), distance_squared)
    degeneracy = compute_degeneracy_indicator(distance_squared)

    return {
        "distance_vs_abs_dtheta_spearman": theta_rho,
        "distance_vs_abs_dr_spearman": dr_rho,
        "component_balance_score": balance_score,
        "local_smoothness_score": smoothness,
        "angular_monotone_bin_fraction": monotonicity,
        "degeneracy_indicator": degeneracy,
    }


def compare_to_baseline(baseline_row: pd.Series, transformed_diag: Dict[str, float]) -> Dict[str, float]:
    metric_names = [
        "distance_vs_abs_dtheta_spearman",
        "distance_vs_abs_dr_spearman",
        "component_balance_score",
        "local_smoothness_score",
        "angular_monotone_bin_fraction",
        "degeneracy_indicator",
    ]

    out = {}
    inv_vals = []

    label_map = {
        "distance_vs_abs_dtheta_spearman": "theta_alignment",
        "distance_vs_abs_dr_spearman": "dr_alignment",
        "component_balance_score": "balance",
        "local_smoothness_score": "smoothness",
        "angular_monotone_bin_fraction": "monotonicity",
        "degeneracy_indicator": "degeneracy",
    }

    for col in metric_names:
        short = label_map[col]
        b = baseline_row[col]
        t = transformed_diag[col]
        delta = np.nan if (pd.isna(b) or pd.isna(t)) else float(t - b)
        inv = np.nan if pd.isna(delta) else float(1.0 / (1.0 + abs(delta)))

        out[f"baseline_{short}"] = b
        out[f"transformed_{short}"] = t
        out[f"delta_{short}"] = delta
        out[f"invariance_{short}"] = inv
        if not pd.isna(inv):
            inv_vals.append(inv)

    out["overall_invariance_score"] = float(np.mean(inv_vals)) if inv_vals else np.nan
    return out


# ============================================================================
# MAIN
# ============================================================================

def main() -> None:
    print("[Stage-6C v2 PRECHECK] Creating output directory...")
    ensure_dir(OUT_DIR)

    print("[Stage-6C v2 PRECHECK] Checking required files...")
    check_file(STAGE6A_CSV)
    check_file(STAGE6B_CSV)

    print("[Stage-6C v2 PRECHECK] Loading Stage-6A / Stage-6B tables...")
    df6a = pd.read_csv(STAGE6A_CSV)
    df6b = pd.read_csv(STAGE6B_CSV)

    validate_columns(df6a, REQUIRED_STAGE6A_COLUMNS, "Stage-6A CSV")
    validate_columns(df6b, REQUIRED_STAGE6B_COLUMNS, "Stage-6B CSV")

    print("[Stage-6C v2 PRECHECK] Filtering requested families...")
    df6a = df6a[df6a["metric_name"].isin(ALL_FAMILIES)].copy()
    df6b = df6b[df6b["metric_name"].isin(ALL_FAMILIES)].copy()

    if df6a.empty:
        raise ValueError("Stage-6A filtered table is empty.")
    if df6b.empty:
        raise ValueError("Stage-6B filtered table is empty.")

    baseline_lookup = df6b.set_index(["metric_name", "alpha", "beta", "FIT"], drop=False)
    group_cols = ["metric_name", "alpha", "beta", "FIT"]

    rows = []

    print("[Stage-6C v2] Running transformations...")
    for key, group in df6a.groupby(group_cols, dropna=False):
        metric_name, alpha, beta, fit = key

        baseline_row = baseline_lookup.loc[(metric_name, alpha, beta, fit)]
        if isinstance(baseline_row, pd.DataFrame):
            if len(baseline_row) != 1:
                raise ValueError(f"Unexpected duplicate baseline rows for key={key}")
            baseline_row = baseline_row.iloc[0]

        for spec in TRANSFORM_SPECS:
            ttype = spec["transformation_type"]
            tvalue = spec["transformation_value"]

            try:
                g2 = transform_group(group, spec)

                admissible, reason = check_admissibility(
                    metric_name,
                    g2["r_i"].to_numpy(dtype=float),
                    g2["r_j"].to_numpy(dtype=float),
                )
                if not admissible:
                    rows.append({
                        "metric_name": metric_name,
                        "alpha": float(alpha),
                        "beta": float(beta),
                        "FIT": str(fit),
                        "transformation_type": ttype,
                        "transformation_value": tvalue,
                        "status": "inadmissible",
                        "inadmissibility_reason": reason,
                        "overall_invariance_score": np.nan,
                    })
                    continue

                transformed_diag = compute_group_diagnostics(g2)
                comp = compare_to_baseline(baseline_row, transformed_diag)

                row = {
                    "metric_name": metric_name,
                    "alpha": float(alpha),
                    "beta": float(beta),
                    "FIT": str(fit),
                    "transformation_type": ttype,
                    "transformation_value": tvalue,
                    "status": "ok",
                    "inadmissibility_reason": "",
                    **comp,
                }
                rows.append(row)

            except Exception as exc:
                rows.append({
                    "metric_name": metric_name,
                    "alpha": float(alpha),
                    "beta": float(beta),
                    "FIT": str(fit),
                    "transformation_type": ttype,
                    "transformation_value": tvalue,
                    "status": "failed",
                    "inadmissibility_reason": str(exc),
                    "overall_invariance_score": np.nan,
                })

    result_df = pd.DataFrame(rows)

    ok_df = result_df[result_df["status"] == "ok"].copy()
    inad_df = result_df[result_df["status"] == "inadmissible"].copy()
    fail_df = result_df[result_df["status"] == "failed"].copy()

    # ------------------------------------------------------------------------
    # Common-support ranking
    # ------------------------------------------------------------------------
    n_families = len(set(ALL_FAMILIES) & set(ok_df["metric_name"].unique()))
    common_support_transforms = []
    family_ranking_common_support = []

    if not ok_df.empty and n_families > 0:
        common_counts = ok_df.groupby("transformation_type")["metric_name"].nunique()
        common_support_transforms = common_counts[common_counts == n_families].index.tolist()

        common_df = ok_df[ok_df["transformation_type"].isin(common_support_transforms)].copy()
        if not common_df.empty:
            fam = (
                common_df.groupby("metric_name")["overall_invariance_score"]
                .agg(["mean", "median", "count"])
                .reset_index()
                .sort_values(["mean", "median"], ascending=False)
            )
            for _, r in fam.iterrows():
                family_ranking_common_support.append({
                    "metric_name": str(r["metric_name"]),
                    "mean_overall_invariance_score": pretty_float(r["mean"]),
                    "median_overall_invariance_score": pretty_float(r["median"]),
                    "n_rows": int(r["count"]),
                })

    # ------------------------------------------------------------------------
    # Admissible-case ranking
    # ------------------------------------------------------------------------
    family_ranking_admissible = []
    if not ok_df.empty:
        fam = (
            ok_df.groupby("metric_name")["overall_invariance_score"]
            .agg(["mean", "median", "count"])
            .reset_index()
            .sort_values(["mean", "median"], ascending=False)
        )
        for _, r in fam.iterrows():
            family_ranking_admissible.append({
                "metric_name": str(r["metric_name"]),
                "mean_overall_invariance_score": pretty_float(r["mean"]),
                "median_overall_invariance_score": pretty_float(r["median"]),
                "n_rows": int(r["count"]),
            })

    # ------------------------------------------------------------------------
    # Coverage / symmetry-breaking
    # ------------------------------------------------------------------------
    admissible_coverage_by_family = []
    for fam_name in ALL_FAMILIES:
        sub = result_df[result_df["metric_name"] == fam_name]
        if sub.empty:
            continue
        admissible_count = int((sub["status"] == "ok").sum())
        inadmissible_count = int((sub["status"] == "inadmissible").sum())
        failed_count = int((sub["status"] == "failed").sum())
        admissible_coverage_by_family.append({
            "metric_name": fam_name,
            "admissible_rows": admissible_count,
            "inadmissible_rows": inadmissible_count,
            "failed_rows": failed_count,
            "total_rows": int(len(sub)),
        })

    symmetry_breaking_pattern = []
    if not result_df.empty:
        pat = (
            result_df[result_df["status"] == "ok"]
            .groupby("transformation_type")["metric_name"]
            .nunique()
            .reset_index(name="n_families_admissible")
            .sort_values(["n_families_admissible", "transformation_type"], ascending=[False, True])
        )
        for _, r in pat.iterrows():
            symmetry_breaking_pattern.append({
                "transformation_type": str(r["transformation_type"]),
                "n_families_admissible": int(r["n_families_admissible"]),
            })

    inadmissibility_reasons = []
    if not inad_df.empty:
        reasons = (
            inad_df.groupby(["metric_name", "transformation_type", "inadmissibility_reason"])
            .size()
            .reset_index(name="count")
            .sort_values("count", ascending=False)
        )
        for _, r in reasons.iterrows():
            inadmissibility_reasons.append({
                "metric_name": str(r["metric_name"]),
                "transformation_type": str(r["transformation_type"]),
                "inadmissibility_reason": str(r["inadmissibility_reason"]),
                "count": int(r["count"]),
            })

    summary = {
        "stage": "Stage-6C",
        "script_name": "metric_stage_6C_normalization_and_gauge_analysis_v2.py",
        "timestamp_utc": utc_now_iso(),
        "families_primary": PRIMARY_FAMILIES,
        "families_secondary": SECONDARY_FAMILIES,
        "primary_fit": PRIMARY_FIT,
        "transformations_tested": TRANSFORM_SPECS,
        "counts": {
            "rows_written": int(len(result_df)),
            "successful_rows": int((result_df["status"] == "ok").sum()),
            "inadmissible_rows": int((result_df["status"] == "inadmissible").sum()),
            "failed_rows": int((result_df["status"] == "failed").sum()),
        },
        "family_ranking_admissible_cases": family_ranking_admissible,
        "common_support_transforms": common_support_transforms,
        "family_ranking_common_support": family_ranking_common_support,
        "admissible_coverage_by_family": admissible_coverage_by_family,
        "symmetry_breaking_pattern": symmetry_breaking_pattern,
        "inadmissibility_reasons": inadmissibility_reasons,
        "notes": {
            "interpretation": (
                "Stage-6C v2 distinguishes admissibility, common-support comparison, "
                "and symmetry-breaking patterns. Inadmissible transformed cases are "
                "recorded rather than silently dropped."
            )
        },
    }

    notes_lines = [
        "STAGE-6C INTERPRETIVE NOTES — v2 ADMISSIBILITY / COMMON-SUPPORT / SYMMETRY-BREAKING",
        f"Generated (UTC): {summary['timestamp_utc']}",
        "",
        "Interpretive stance",
        "------------------",
        "This version treats Stage-6C as both an invariance-analysis step and a",
        "symmetry-breaking probe.",
        "",
        "Counts",
        "------",
        f"Rows written      : {summary['counts']['rows_written']}",
        f"Successful rows   : {summary['counts']['successful_rows']}",
        f"Inadmissible rows : {summary['counts']['inadmissible_rows']}",
        f"Failed rows       : {summary['counts']['failed_rows']}",
        "",
        "Common-support transforms",
        "-------------------------",
    ]
    if common_support_transforms:
        notes_lines.extend([f"- {x}" for x in common_support_transforms])
    else:
        notes_lines.append("- none")
    notes_lines.extend([
        "",
        "Interpretive rule",
        "-----------------",
        "Admissible-case rankings preserve valid information inside each family's domain.",
        "Common-support rankings provide the fairest apples-to-apples comparison.",
        "Differences in admissibility are retained as symmetry-breaking evidence.",
        "",
    ])

    print("[Stage-6C v2] Writing CSV...")
    result_df.to_csv(OUT_CSV, index=False)

    print("[Stage-6C v2] Writing JSON summary...")
    with open(OUT_JSON, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)

    print("[Stage-6C v2] Writing interpretive notes...")
    with open(OUT_TXT, "w", encoding="utf-8") as f:
        f.write("\n".join(notes_lines))

    print("[Stage-6C v2] Done.")
    print("[Stage-6C v2] Wrote:")
    print(f"  CSV : {OUT_CSV}")
    print(f"  JSON: {OUT_JSON}")
    print(f"  TXT : {OUT_TXT}")


if __name__ == "__main__":
    main()