#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
============================================================
Project: Quantum-Emergent Gravity
Stage: 6Q
Script: Stage-6Q_canonical_law_extraction_v1.py
Author: Arturo Ortiz-Tapia / ChatGPT assistant
Build Date: 2026-05-03
============================================================

WORKING TITLE
-------------
Canonical Two-Lobe Law Extraction

WHY THIS STAGE EXISTS
---------------------
Stage-6P v6 accepted the repaired family-aware observable and supported
family-level two-lobe universality. 6Q is therefore not a repair stage and
not a discovery/fitting stage. It is a canonicalization stage.

Frozen upstream conclusion:
    V5_REPAIR_ACCEPTED_FAMILY_TWO_LOBE_UNIVERSALITY_SUPPORTED

Canonical target law:
    rho(s) ~= E(s) + C(s)

where E(s) is the early localized lobe and C(s) is the central/bulk lobe.

STRICT RULES FOR THIS SCRIPT
----------------------------
1) DO NOT re-fit Stage-6P models.
2) DO NOT change the observable definition.
3) DO NOT introduce Green functions.
4) DO NOT introduce PDE closure.
5) DO NOT revisit upstream family-label repair.
6) DO extract normalized canonical parameters and invariants from Stage-6P v6.

EXPECTED INPUT DIRECTORY
------------------------
metric_stage_6P_outputs/two_lobe_universality_test_v6/

Required upstream files, if present:
    stage6P_v6_family_two_lobe_fit_summary.csv
    stage6P_v6_family_lobe_parameters.csv
    stage6P_v6_candidate_vs_canonical_comparison.csv
    stage6P_v6_pairwise_family_parameter_distances.csv
    stage6P_v6_audit_summary.json

OUTPUT DIRECTORY
----------------
metric_stage_6Q_outputs/canonical_law_extraction_v1/

Primary outputs:
    stage6Q_canonical_parameters.csv
    stage6Q_invariant_summary.csv
    stage6Q_dimensionless_ratios.csv
    stage6Q_transformation_tests.csv
    stage6Q_canonical_law_summary.json
    stage6Q_notes.txt

Optional plots, written when enough parameter columns exist:
    stage6Q_canonical_law_overlay.png
    stage6Q_invariant_bands.png
    stage6Q_ratio_distributions.png

Spyder usage:
    Open this file in Spyder and run it.

Terminal usage:
    python3 Stage-6Q_canonical_law_extraction_v1.py

Optional explicit project root:
    python3 Stage-6Q_canonical_law_extraction_v1.py /home/dakini/Downloads/010-Quantum_Emergent_Gravity
============================================================
"""

from __future__ import annotations

import json
import math
import os
import sys
import traceback
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd

try:
    import matplotlib.pyplot as plt
    MATPLOTLIB_AVAILABLE = True
except Exception:
    MATPLOTLIB_AVAILABLE = False


# ------------------------------------------------------------
# Configuration
# ------------------------------------------------------------

STAGE = "6Q"
SCRIPT_NAME = "Stage-6Q_canonical_law_extraction_v1.py"
UPSTREAM_REL = Path("metric_stage_6P_outputs") / "two_lobe_universality_test_v6"
OUTPUT_REL = Path("metric_stage_6Q_outputs") / "canonical_law_extraction_v1"

FAMILIES = ["BARI", "NUFIT", "VALENCIA"]

REQUIRED_FILES = {
    "fit_summary": "stage6P_v6_family_two_lobe_fit_summary.csv",
    "lobe_parameters": "stage6P_v6_family_lobe_parameters.csv",
    "canonical_comparison": "stage6P_v6_candidate_vs_canonical_comparison.csv",
    "pairwise_distances": "stage6P_v6_pairwise_family_parameter_distances.csv",
    "audit_summary": "stage6P_v6_audit_summary.json",
}

# Column aliases are deliberately broad because Stage-6P scripts evolved quickly.
ALIASES = {
    "family": ["family", "stage6P_family", "FIT", "FIT_id", "pdg_family", "source_family"],
    "resolution": ["resolution", "bins", "n_bins", "bin_count", "profile_bins", "stage6P_bins"],
    "mu_early": ["mu_early", "early_mu", "mu_e", "early_center", "center_early", "early_lobe_mu"],
    "sigma_early": ["sigma_early", "early_sigma", "sigma_e", "early_width", "width_early", "early_lobe_sigma"],
    "amp_early": ["amp_early", "amplitude_early", "A_early", "early_amplitude", "A_e", "early_lobe_amplitude"],
    "mass_early": ["mass_early", "early_mass", "early_mass_fraction", "E_mass", "mass_fraction_early"],
    "mu_central": ["mu_central", "central_mu", "mu_c", "central_center", "center_central", "central_lobe_mu"],
    "sigma_central": ["sigma_central", "central_sigma", "sigma_c", "central_width", "width_central", "central_lobe_sigma"],
    "amp_central": ["amp_central", "amplitude_central", "A_central", "central_amplitude", "A_c", "central_lobe_amplitude"],
    "mass_central": ["mass_central", "central_mass", "central_mass_fraction", "C_mass", "mass_fraction_central"],
    "skew_central": ["skew_central", "central_skew", "alpha_central", "central_alpha", "skew"],
    "r2": ["r2", "R2", "R_squared", "fit_r2", "model_r2"],
    "corr": ["corr", "correlation", "fit_corr", "pearson_corr"],
    "rmse": ["rmse", "fit_rmse", "model_rmse"],
}

PARAM_KEYS = [
    "mu_early", "sigma_early", "amp_early", "mass_early",
    "mu_central", "sigma_central", "amp_central", "mass_central", "skew_central",
]

RATIO_KEYS = [
    "early_mass_fraction", "central_mass_fraction", "early_to_central_mass_ratio",
    "mu_ratio_early_over_central", "sigma_ratio_early_over_central",
    "amplitude_ratio_early_over_central", "separation_over_total_width",
]


# ------------------------------------------------------------
# Console and filesystem helpers
# ------------------------------------------------------------

def banner(title: str) -> None:
    print("=" * 72)
    print(title)
    print("=" * 72)


def echo_environment(project_root: Path, input_dir: Path, output_dir: Path) -> None:
    banner("Stage-6Q: Canonical Two-Lobe Law Extraction")
    print(f"[Stage-6Q] Python executable : {sys.executable}")
    print(f"[Stage-6Q] Working directory : {Path.cwd()}")
    print(f"[Stage-6Q] Project root      : {project_root}")
    print(f"[Stage-6Q] Input directory   : {input_dir}")
    print(f"[Stage-6Q] Output directory  : {output_dir}")
    print("[Stage-6Q] Rule              : canonicalize only; no refit; no new kernels; no upstream repair.")
    print("[Stage-6Q] Target law         : rho(s) ~= E(s) + C(s)")
    print("-" * 72)


def find_project_root() -> Path:
    """Find the QEG project root using command-line argument, cwd, or parent search."""
    if len(sys.argv) >= 2:
        candidate = Path(sys.argv[1]).expanduser().resolve()
        if candidate.exists():
            return candidate

    cwd = Path.cwd().resolve()
    markers = ["metric_stage_6P_outputs", "metric_stage_6O_outputs", "metric_stage_6M_outputs"]
    for p in [cwd] + list(cwd.parents):
        if any((p / m).exists() for m in markers):
            return p

    default = Path("/home/dakini/Downloads/010-Quantum_Emergent_Gravity")
    if default.exists():
        return default.resolve()

    return cwd


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def read_csv_if_exists(path: Path) -> Optional[pd.DataFrame]:
    if not path.exists():
        return None
    try:
        return pd.read_csv(path)
    except Exception as exc:
        print(f"[Stage-6Q WARNING] Could not read CSV: {path}\n    {exc}")
        return None


def read_json_if_exists(path: Path) -> Optional[dict]:
    if not path.exists():
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as exc:
        print(f"[Stage-6Q WARNING] Could not read JSON: {path}\n    {exc}")
        return None


def safe_float(x) -> float:
    try:
        if pd.isna(x):
            return np.nan
        return float(x)
    except Exception:
        return np.nan


def find_col(df: pd.DataFrame, semantic_key: str) -> Optional[str]:
    aliases = ALIASES.get(semantic_key, [semantic_key])
    cols = list(df.columns)
    lower_map = {c.lower(): c for c in cols}
    for a in aliases:
        if a in cols:
            return a
        if a.lower() in lower_map:
            return lower_map[a.lower()]
    # Fallback: relaxed substring search.
    tokens = semantic_key.lower().split("_")
    for c in cols:
        cl = c.lower()
        if all(t in cl for t in tokens):
            return c
    return None


def canonicalize_family(value) -> str:
    s = str(value).upper()
    for fam in FAMILIES:
        if fam in s:
            return fam
    return str(value)


def infer_resolution(value, default="unknown") -> str:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return default
    text = str(value)
    # Keep labels such as 48, 361, 48bins, etc.
    return text


# ------------------------------------------------------------
# Core extraction helpers
# ------------------------------------------------------------

def build_parameter_table(lobe_df: pd.DataFrame, fit_df: Optional[pd.DataFrame]) -> pd.DataFrame:
    """Extract canonical parameter columns from Stage-6P lobe parameter table.

    This function does not fit anything. It only standardizes columns already
    produced upstream.
    """
    fam_col = find_col(lobe_df, "family")
    if fam_col is None:
        raise ValueError("Could not find a family column in lobe parameter table.")

    res_col = find_col(lobe_df, "resolution")

    rows = []
    for idx, row in lobe_df.iterrows():
        out = {
            "source_row": int(idx),
            "family": canonicalize_family(row[fam_col]),
            "resolution": infer_resolution(row[res_col]) if res_col else "unknown",
        }
        for key in PARAM_KEYS:
            col = find_col(lobe_df, key)
            out[key] = safe_float(row[col]) if col else np.nan
        # Optional fit quality columns, if they were included in the lobe table.
        for key in ["r2", "corr", "rmse"]:
            col = find_col(lobe_df, key)
            out[key] = safe_float(row[col]) if col else np.nan
        rows.append(out)

    params = pd.DataFrame(rows)

    # If fit quality lives only in the fit summary, merge it conservatively by
    # family/resolution. This remains bookkeeping, not fitting.
    if fit_df is not None and not fit_df.empty:
        f_fam = find_col(fit_df, "family")
        f_res = find_col(fit_df, "resolution")
        if f_fam is not None:
            fit_small = pd.DataFrame()
            fit_small["family"] = fit_df[f_fam].map(canonicalize_family)
            fit_small["resolution"] = fit_df[f_res].map(infer_resolution) if f_res else "unknown"
            for key in ["r2", "corr", "rmse"]:
                col = find_col(fit_df, key)
                if col is not None:
                    fit_small[f"fit_{key}"] = pd.to_numeric(fit_df[col], errors="coerce")
            merge_cols = ["family", "resolution"]
            if "resolution" not in params.columns or params["resolution"].nunique() == 1 and fit_small["resolution"].nunique() > 1:
                merge_cols = ["family"]
            if any(c.startswith("fit_") for c in fit_small.columns):
                params = params.merge(fit_small.drop_duplicates(merge_cols), on=merge_cols, how="left")
                for key in ["r2", "corr", "rmse"]:
                    fk = f"fit_{key}"
                    if fk in params.columns:
                        params[key] = params[key].where(params[key].notna(), params[fk])
                        params = params.drop(columns=[fk])

    # Repair mass fractions from amplitudes and widths when explicit mass columns
    # are absent. This is not a refit; it is analytic bookkeeping from existing
    # upstream lobe parameters.
    missing_mass = params[["mass_early", "mass_central"]].isna().all(axis=None)
    if missing_mass:
        early_proxy = params["amp_early"].abs() * params["sigma_early"].abs()
        central_proxy = params["amp_central"].abs() * params["sigma_central"].abs()
        total_proxy = early_proxy + central_proxy
        params["mass_early"] = np.where(total_proxy > 0, early_proxy / total_proxy, np.nan)
        params["mass_central"] = np.where(total_proxy > 0, central_proxy / total_proxy, np.nan)
        params["mass_source"] = "amplitude_width_proxy"
    else:
        # If masses look like absolute component masses, normalize them.
        total_mass = params["mass_early"].abs() + params["mass_central"].abs()
        looks_fractional = np.nanmax(total_mass.values) <= 1.25 if np.isfinite(total_mass).any() else True
        if looks_fractional:
            params["mass_source"] = "upstream_fraction_or_normalized"
        else:
            params["mass_early"] = np.where(total_mass > 0, params["mass_early"].abs() / total_mass, np.nan)
            params["mass_central"] = np.where(total_mass > 0, params["mass_central"].abs() / total_mass, np.nan)
            params["mass_source"] = "upstream_mass_normalized_by_script"

    return params


def add_dimensionless_ratios(params: pd.DataFrame) -> pd.DataFrame:
    df = params.copy()
    total_mass = df["mass_early"].abs() + df["mass_central"].abs()
    df["early_mass_fraction"] = np.where(total_mass > 0, df["mass_early"].abs() / total_mass, np.nan)
    df["central_mass_fraction"] = np.where(total_mass > 0, df["mass_central"].abs() / total_mass, np.nan)
    df["early_to_central_mass_ratio"] = safe_div(df["early_mass_fraction"], df["central_mass_fraction"])
    df["mu_ratio_early_over_central"] = safe_div(df["mu_early"], df["mu_central"])
    df["sigma_ratio_early_over_central"] = safe_div(df["sigma_early"], df["sigma_central"])
    df["amplitude_ratio_early_over_central"] = safe_div(df["amp_early"], df["amp_central"])
    separation = (df["mu_central"] - df["mu_early"]).abs()
    total_width = df["sigma_early"].abs() + df["sigma_central"].abs()
    df["separation_over_total_width"] = safe_div(separation, total_width)
    return df


def safe_div(a, b):
    a_arr = np.asarray(a, dtype=float)
    b_arr = np.asarray(b, dtype=float)
    return np.where(np.abs(b_arr) > 1e-15, a_arr / b_arr, np.nan)


def summarize_invariants(ratio_df: pd.DataFrame) -> pd.DataFrame:
    records = []
    numeric_cols = [c for c in ratio_df.columns if pd.api.types.is_numeric_dtype(ratio_df[c])]
    exclude = {"source_row"}
    for col in numeric_cols:
        if col in exclude:
            continue
        values = pd.to_numeric(ratio_df[col], errors="coerce").dropna()
        if values.empty:
            continue
        rec = {
            "quantity": col,
            "n": int(values.size),
            "mean": float(values.mean()),
            "std": float(values.std(ddof=1)) if values.size > 1 else 0.0,
            "min": float(values.min()),
            "max": float(values.max()),
            "range": float(values.max() - values.min()),
            "cv_abs": float(abs(values.std(ddof=1) / values.mean())) if values.size > 1 and abs(values.mean()) > 1e-15 else 0.0,
            "invariance_class": classify_invariance(values),
        }
        records.append(rec)

    inv = pd.DataFrame(records).sort_values(["invariance_class", "quantity"]).reset_index(drop=True)
    return inv


def classify_invariance(values: pd.Series) -> str:
    if values.size <= 1:
        return "single_value"
    mean = float(values.mean())
    rng = float(values.max() - values.min())
    std = float(values.std(ddof=1))
    scale = max(abs(mean), 1.0)
    rel_rng = rng / scale
    rel_std = std / scale
    if rel_rng < 1e-6:
        return "hard_invariant"
    if rel_rng < 0.02 or rel_std < 0.01:
        return "strong_invariant"
    if rel_rng < 0.10 or rel_std < 0.05:
        return "soft_invariant"
    if rel_rng < 0.25 or rel_std < 0.125:
        return "family_modulated"
    return "variable_review"


def transformation_tests(ratio_df: pd.DataFrame) -> pd.DataFrame:
    """Perform non-fitting transformation bookkeeping tests.

    These are parameter-level tests, not model refits.
    They ask whether the already extracted law is stable under:
      - amplitude scaling: mass fractions and ratios should be unchanged.
      - resolution change: same family across bin counts should be stable.
      - reflection: early and central centers should not become equivalent
        under s -> 1-s unless the law is symmetric.
    """
    records = []

    # Scaling: by construction, dimensionless ratios should be invariant to
    # amplitude scaling. We quantify spread across rows.
    for key in RATIO_KEYS:
        if key in ratio_df.columns:
            vals = pd.to_numeric(ratio_df[key], errors="coerce").dropna()
            if not vals.empty:
                records.append({
                    "test": "amplitude_scaling_invariance",
                    "quantity": key,
                    "metric": "relative_range",
                    "value": float((vals.max() - vals.min()) / max(abs(vals.mean()), 1.0)),
                    "interpretation": classify_invariance(vals),
                })

    # Resolution stability: compare rows within each family if multiple
    # resolution labels exist.
    if "resolution" in ratio_df.columns:
        for fam, g in ratio_df.groupby("family"):
            if g["resolution"].nunique() < 2:
                continue
            for key in ["mu_early", "mu_central", "early_mass_fraction", "central_mass_fraction", "sigma_ratio_early_over_central"]:
                vals = pd.to_numeric(g[key], errors="coerce").dropna() if key in g.columns else pd.Series(dtype=float)
                if vals.size >= 2:
                    records.append({
                        "test": "resolution_stability",
                        "quantity": f"{fam}:{key}",
                        "metric": "range",
                        "value": float(vals.max() - vals.min()),
                        "interpretation": classify_invariance(vals),
                    })

    # Reflection: not a pass/fail symmetry demand. It reports whether the
    # two-sector law is reflection asymmetric in center location.
    if {"mu_early", "mu_central"}.issubset(ratio_df.columns):
        mu_e = pd.to_numeric(ratio_df["mu_early"], errors="coerce")
        mu_c = pd.to_numeric(ratio_df["mu_central"], errors="coerce")
        reflected_early = 1.0 - mu_e
        reflected_central = 1.0 - mu_c
        asym = (mu_e - reflected_central).abs() + (mu_c - reflected_early).abs()
        vals = asym.dropna()
        if not vals.empty:
            records.append({
                "test": "reflection_asymmetry",
                "quantity": "mu_early_mu_central",
                "metric": "mean_reflection_mismatch",
                "value": float(vals.mean()),
                "interpretation": "asymmetric_two_sector_law" if vals.mean() > 0.05 else "near_reflection_symmetric_review",
            })

    return pd.DataFrame(records)


# ------------------------------------------------------------
# Canonical law reconstruction for plotting and compact summary
# ------------------------------------------------------------

def gaussian(x: np.ndarray, mu: float, sigma: float) -> np.ndarray:
    sigma = max(abs(float(sigma)), 1e-9)
    return np.exp(-0.5 * ((x - float(mu)) / sigma) ** 2)


def canonical_component_curve(x: np.ndarray, mu: float, sigma: float, mass_fraction: float) -> np.ndarray:
    y = gaussian(x, mu, sigma)
    area = np.trapz(y, x)
    if area > 0:
        y = y / area
    return mass_fraction * y


def build_canonical_curve(ratio_df: pd.DataFrame) -> Tuple[pd.DataFrame, Dict[str, float]]:
    """Build a normalized representative E+C curve from mean parameters.

    This is not a refit. It is the compact analytic representation implied by
    Stage-6P parameters after averaging across family/resolution rows.
    """
    means = {}
    for key in ["mu_early", "sigma_early", "early_mass_fraction", "mu_central", "sigma_central", "central_mass_fraction"]:
        if key in ratio_df.columns:
            means[key] = float(pd.to_numeric(ratio_df[key], errors="coerce").dropna().mean())
        else:
            means[key] = np.nan

    x = np.linspace(0.0, 1.0, 1001)
    if any(not np.isfinite(means[k]) for k in ["mu_early", "sigma_early", "mu_central", "sigma_central"]):
        return pd.DataFrame({"s": x}), means

    ef = means.get("early_mass_fraction", np.nan)
    cf = means.get("central_mass_fraction", np.nan)
    if not np.isfinite(ef) or not np.isfinite(cf) or ef + cf <= 0:
        ef, cf = 0.5, 0.5
    else:
        total = ef + cf
        ef, cf = ef / total, cf / total

    E = canonical_component_curve(x, means["mu_early"], means["sigma_early"], ef)
    C = canonical_component_curve(x, means["mu_central"], means["sigma_central"], cf)
    rho = E + C
    area = np.trapz(rho, x)
    if area > 0:
        E, C, rho = E / area, C / area, rho / area

    curve = pd.DataFrame({"s": x, "E_early": E, "C_central": C, "rho_canonical": rho})
    means["canonical_mass_check"] = float(np.trapz(rho, x))
    means["canonical_peak_s"] = float(x[np.nanargmax(rho)])
    return curve, means


def make_plots(output_dir: Path, ratio_df: pd.DataFrame, inv_df: pd.DataFrame, curve_df: pd.DataFrame) -> List[str]:
    written = []
    if not MATPLOTLIB_AVAILABLE:
        return written

    # Plot 1: canonical E + C law.
    if {"s", "E_early", "C_central", "rho_canonical"}.issubset(curve_df.columns):
        plt.figure(figsize=(9, 5))
        plt.plot(curve_df["s"], curve_df["E_early"], label="E(s): early lobe")
        plt.plot(curve_df["s"], curve_df["C_central"], label="C(s): central lobe")
        plt.plot(curve_df["s"], curve_df["rho_canonical"], label="E(s)+C(s)", linewidth=2)
        plt.xlabel("intrinsic coordinate s")
        plt.ylabel("normalized density")
        plt.title("Stage-6Q canonical two-lobe representation")
        plt.legend()
        plt.tight_layout()
        path = output_dir / "stage6Q_canonical_law_overlay.png"
        plt.savefig(path, dpi=160)
        plt.close()
        written.append(str(path))

    # Plot 2: key invariant bands by row.
    key_cols = [c for c in ["mu_early", "mu_central", "early_mass_fraction", "central_mass_fraction"] if c in ratio_df.columns]
    if key_cols:
        plt.figure(figsize=(9, 5))
        xlabels = []
        for i, c in enumerate(key_cols):
            vals = pd.to_numeric(ratio_df[c], errors="coerce").dropna().values
            if vals.size:
                plt.scatter(np.full(vals.shape, i), vals)
                plt.errorbar(i, np.mean(vals), yerr=np.std(vals, ddof=1) if vals.size > 1 else 0.0, fmt="o", capsize=5)
                xlabels.append(c)
        plt.xticks(range(len(key_cols)), xlabels, rotation=25, ha="right")
        plt.ylabel("value")
        plt.title("Stage-6Q invariant bands")
        plt.tight_layout()
        path = output_dir / "stage6Q_invariant_bands.png"
        plt.savefig(path, dpi=160)
        plt.close()
        written.append(str(path))

    # Plot 3: ratio distributions.
    ratio_cols = [c for c in RATIO_KEYS if c in ratio_df.columns]
    ratio_cols = ratio_cols[:6]
    if ratio_cols:
        plt.figure(figsize=(10, 5))
        data = [pd.to_numeric(ratio_df[c], errors="coerce").dropna().values for c in ratio_cols]
        data = [d for d in data if len(d) > 0]
        labels = [c for c in ratio_cols if len(pd.to_numeric(ratio_df[c], errors="coerce").dropna()) > 0]
        if data:
            plt.boxplot(data, labels=labels, vert=True)
            plt.xticks(rotation=25, ha="right")
            plt.ylabel("dimensionless value")
            plt.title("Stage-6Q dimensionless ratio distributions")
            plt.tight_layout()
            path = output_dir / "stage6Q_ratio_distributions.png"
            plt.savefig(path, dpi=160)
            plt.close()
            written.append(str(path))

    return written


# ------------------------------------------------------------
# Notes and summary
# ------------------------------------------------------------

def compact_record(inv_df: pd.DataFrame, quantity: str) -> Optional[dict]:
    if inv_df.empty or "quantity" not in inv_df.columns:
        return None
    sub = inv_df[inv_df["quantity"] == quantity]
    if sub.empty:
        return None
    return sub.iloc[0].to_dict()


def write_notes(
    output_dir: Path,
    input_paths: Dict[str, Path],
    missing: List[str],
    params: Optional[pd.DataFrame],
    inv_df: Optional[pd.DataFrame],
    trans_df: Optional[pd.DataFrame],
    plot_paths: List[str],
    summary: dict,
) -> None:
    path = output_dir / "stage6Q_notes.txt"
    with open(path, "w", encoding="utf-8") as f:
        f.write("============================================================\n")
        f.write("STAGE-6Q NOTES\n")
        f.write("Project: Quantum-Emergent Gravity\n")
        f.write("Script: Stage-6Q_canonical_law_extraction_v1.py\n")
        f.write("============================================================\n\n")
        f.write("Purpose:\n")
        f.write("Canonicalize the Stage-6P v6 universal two-lobe law without re-fitting.\n\n")
        f.write("Frozen rule set:\n")
        f.write("- no model refit\n- no observable revision\n- no new kernels\n- no PDE closure\n- no upstream repair\n\n")
        f.write("Input files checked:\n")
        for key, p in input_paths.items():
            f.write(f"- {key}: {p} [{'FOUND' if p.exists() else 'MISSING'}]\n")
        if missing:
            f.write("\nMissing required files:\n")
            for m in missing:
                f.write(f"- {m}\n")
        f.write("\nGenerated outputs:\n")
        for out in [
            "stage6Q_canonical_parameters.csv",
            "stage6Q_invariant_summary.csv",
            "stage6Q_dimensionless_ratios.csv",
            "stage6Q_transformation_tests.csv",
            "stage6Q_canonical_curve.csv",
            "stage6Q_canonical_law_summary.json",
        ]:
            f.write(f"- {out}\n")
        for p in plot_paths:
            f.write(f"- {Path(p).name}\n")
        f.write("\nVerdict:\n")
        f.write(str(summary.get("stage6Q_verdict", "UNKNOWN")) + "\n")
        f.write("\nInterpretation:\n")
        f.write(str(summary.get("interpretation", "No interpretation available.")) + "\n")
        f.write("\nZenodo note:\n")
        f.write("Track this under dataset group QEG_Stage6_Canonical_Law. Include Stage-6P v6 frozen inputs and Stage-6Q canonical outputs.\n")
        f.write("Do not archive only plots; keep raw CSV/JSON. Compress large JSON if needed.\n")


def build_summary(
    params: pd.DataFrame,
    ratio_df: pd.DataFrame,
    inv_df: pd.DataFrame,
    trans_df: pd.DataFrame,
    canonical_means: dict,
    audit_json: Optional[dict],
    missing: List[str],
) -> dict:
    hard = inv_df[inv_df["invariance_class"].isin(["hard_invariant", "strong_invariant"])] if not inv_df.empty else pd.DataFrame()
    soft = inv_df[inv_df["invariance_class"].isin(["soft_invariant", "family_modulated"])] if not inv_df.empty else pd.DataFrame()

    mu_e_rec = compact_record(inv_df, "mu_early")
    mu_c_rec = compact_record(inv_df, "mu_central")
    em_rec = compact_record(inv_df, "early_mass_fraction")
    cm_rec = compact_record(inv_df, "central_mass_fraction")

    sufficient = params is not None and not params.empty and mu_e_rec is not None and mu_c_rec is not None
    verdict = "CANONICAL_LAW_EXTRACTED" if sufficient else "CANONICAL_EXTRACTION_INCOMPLETE_REVIEW_INPUTS"

    interpretation = (
        "Stage-6Q extracted a compact normalized two-sector representation rho(s) ~= E(s)+C(s) "
        "from frozen Stage-6P v6 parameters. Early-sector quantities should be read as hard/strong "
        "invariants when their range is negligible; central-sector quantities are allowed to behave as soft "
        "family-modulated invariants. This script did not refit models or introduce new physics."
        if sufficient else
        "Stage-6Q could not fully canonicalize because required upstream parameter columns or files were missing. "
        "Review Stage-6P v6 lobe parameter output names/columns."
    )

    return {
        "project": "Quantum-Emergent Gravity",
        "stage": "6Q",
        "script": SCRIPT_NAME,
        "build_date": "2026-05-03",
        "upstream_verdict": "V5_REPAIR_ACCEPTED_FAMILY_TWO_LOBE_UNIVERSALITY_SUPPORTED",
        "stage6Q_verdict": verdict,
        "missing_required_files": missing,
        "n_parameter_rows": int(len(params)) if params is not None else 0,
        "families_detected": sorted(params["family"].dropna().unique().tolist()) if params is not None and "family" in params.columns else [],
        "resolutions_detected": sorted(params["resolution"].dropna().astype(str).unique().tolist()) if params is not None and "resolution" in params.columns else [],
        "canonical_law": {
            "form": "rho(s) ~= E(s) + C(s)",
            "E": "early localized lobe",
            "C": "central/bulk lobe",
            "canonical_mean_parameters": canonical_means,
        },
        "key_invariants": {
            "mu_early": mu_e_rec,
            "mu_central": mu_c_rec,
            "early_mass_fraction": em_rec,
            "central_mass_fraction": cm_rec,
        },
        "hard_or_strong_invariants": hard.to_dict(orient="records") if not hard.empty else [],
        "soft_or_family_modulated_invariants": soft.to_dict(orient="records") if not soft.empty else [],
        "transformation_tests": trans_df.to_dict(orient="records") if trans_df is not None and not trans_df.empty else [],
        "audit_summary_upstream": audit_json if audit_json is not None else {},
        "zenodo_dataset_group": "QEG_Stage6_Canonical_Law",
        "zenodo_directive": {
            "include_frozen_stage6P_v6_inputs": list(REQUIRED_FILES.values()) + ["stage6P_v6_audit_notes.txt", "overlay plots 48 and 361 bins if present"],
            "include_stage6Q_outputs": [
                "stage6Q_canonical_parameters.csv",
                "stage6Q_invariant_summary.csv",
                "stage6Q_dimensionless_ratios.csv",
                "stage6Q_transformation_tests.csv",
                "stage6Q_canonical_law_summary.json",
                "stage6Q_notes.txt",
            ],
            "metadata_notes": [
                "no PDG injection",
                "no artificial family assignment",
                "intrinsic observable only",
                "family-aware validation",
                "canonicalization only; no re-fit",
            ],
        },
        "interpretation": interpretation,
    }


# ------------------------------------------------------------
# Main pipeline
# ------------------------------------------------------------

def main() -> int:
    project_root = find_project_root()
    input_dir = project_root / UPSTREAM_REL
    output_dir = project_root / OUTPUT_REL
    ensure_dir(output_dir)
    echo_environment(project_root, input_dir, output_dir)

    input_paths = {k: input_dir / v for k, v in REQUIRED_FILES.items()}
    missing = [str(p) for p in input_paths.values() if not p.exists()]

    if missing:
        print("[Stage-6Q WARNING] Some required files are missing:")
        for m in missing:
            print(f"    - {m}")
        print("[Stage-6Q] Continuing with available files; output will mark review status if needed.")
        print("-" * 72)

    fit_df = read_csv_if_exists(input_paths["fit_summary"])
    lobe_df = read_csv_if_exists(input_paths["lobe_parameters"])
    comparison_df = read_csv_if_exists(input_paths["canonical_comparison"])
    pairwise_df = read_csv_if_exists(input_paths["pairwise_distances"])
    audit_json = read_json_if_exists(input_paths["audit_summary"])

    if lobe_df is None or lobe_df.empty:
        print("[Stage-6Q ERROR] Lobe parameter table is missing or empty. Cannot extract canonical law.")
        summary = {
            "project": "Quantum-Emergent Gravity",
            "stage": "6Q",
            "script": SCRIPT_NAME,
            "stage6Q_verdict": "CANONICAL_EXTRACTION_FAILED_MISSING_LOBE_PARAMETERS",
            "missing_required_files": missing,
        }
        with open(output_dir / "stage6Q_canonical_law_summary.json", "w", encoding="utf-8") as f:
            json.dump(summary, f, indent=2)
        write_notes(output_dir, input_paths, missing, None, None, None, [], summary)
        return 2

    print(f"[Stage-6Q] Loaded lobe parameter rows : {len(lobe_df)}")
    if fit_df is not None:
        print(f"[Stage-6Q] Loaded fit summary rows     : {len(fit_df)}")
    if comparison_df is not None:
        print(f"[Stage-6Q] Loaded canonical comparison : {len(comparison_df)} rows")
    if pairwise_df is not None:
        print(f"[Stage-6Q] Loaded pairwise distances   : {len(pairwise_df)} rows")
    print("-" * 72)

    try:
        params = build_parameter_table(lobe_df, fit_df)
        ratio_df = add_dimensionless_ratios(params)
        inv_df = summarize_invariants(ratio_df)
        trans_df = transformation_tests(ratio_df)
        curve_df, canonical_means = build_canonical_curve(ratio_df)

        params_path = output_dir / "stage6Q_canonical_parameters.csv"
        ratio_path = output_dir / "stage6Q_dimensionless_ratios.csv"
        inv_path = output_dir / "stage6Q_invariant_summary.csv"
        trans_path = output_dir / "stage6Q_transformation_tests.csv"
        curve_path = output_dir / "stage6Q_canonical_curve.csv"

        params.to_csv(params_path, index=False)
        ratio_df.to_csv(ratio_path, index=False)
        inv_df.to_csv(inv_path, index=False)
        trans_df.to_csv(trans_path, index=False)
        curve_df.to_csv(curve_path, index=False)

        plot_paths = make_plots(output_dir, ratio_df, inv_df, curve_df)
        summary = build_summary(params, ratio_df, inv_df, trans_df, canonical_means, audit_json, missing)

        with open(output_dir / "stage6Q_canonical_law_summary.json", "w", encoding="utf-8") as f:
            json.dump(summary, f, indent=2)

        write_notes(output_dir, input_paths, missing, params, inv_df, trans_df, plot_paths, summary)

        banner("Stage-6Q OUTPUTS WRITTEN")
        for p in [params_path, ratio_path, inv_path, trans_path, curve_path, output_dir / "stage6Q_canonical_law_summary.json", output_dir / "stage6Q_notes.txt"]:
            print(f"[Stage-6Q] {p}")
        for p in plot_paths:
            print(f"[Stage-6Q] {p}")

        print("-" * 72)
        print(f"[Stage-6Q] Verdict: {summary['stage6Q_verdict']}")
        print("[Stage-6Q] Canonical law: rho(s) ~= E(s) + C(s)")
        print("[Stage-6Q] Zenodo group: QEG_Stage6_Canonical_Law")
        print("[Stage-6Q] Done.")
        return 0

    except Exception as exc:
        print("[Stage-6Q ERROR] Unhandled exception during canonical extraction.")
        print(str(exc))
        traceback.print_exc()
        summary = {
            "project": "Quantum-Emergent Gravity",
            "stage": "6Q",
            "script": SCRIPT_NAME,
            "stage6Q_verdict": "CANONICAL_EXTRACTION_FAILED_EXCEPTION",
            "exception": str(exc),
            "traceback": traceback.format_exc(),
            "missing_required_files": missing,
        }
        with open(output_dir / "stage6Q_canonical_law_summary.json", "w", encoding="utf-8") as f:
            json.dump(summary, f, indent=2)
        write_notes(output_dir, input_paths, missing, None, None, None, [], summary)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
