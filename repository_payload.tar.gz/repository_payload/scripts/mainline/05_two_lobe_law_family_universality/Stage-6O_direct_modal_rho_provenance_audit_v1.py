#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
========================================================================
Stage-6O: Direct Modal Rho Provenance Audit
Project: Quantum-Emergent Gravity
Author: Arturo Ortiz-Tapia workflow / ChatGPT assisted
Build Date: 2026-04-30
========================================================================

Purpose
-------
The previous Stage-6O semantic candidate review found non-duplicated
family-aware candidates, but no candidate whose rho_col was semantically
appropriate for the intended Stage-6M/6N modal rho / density / profile
observable.

This script therefore stops trying to select from the already-built candidate
score table and directly audits upstream modal/output files, especially:

    metric_stage_6H_outputs
    metric_stage_6I_outputs
    metric_stage_6J_outputs
    metric_stage_6K_outputs
    metric_stage_6L_outputs
    metric_stage_6M_outputs
    metric_stage_6N_outputs
    metric_stage_6O_outputs

It searches for:

    1) modal rho/density/profile-like columns
    2) coordinate columns such as s, s_normalized, bin, theta
    3) explicit family provenance: BARI / NUFIT / VALENCIA in columns or paths
    4) lineage columns that might permit a safe join, WITHOUT row-index repair

Critical rule
-------------
No family labels are assigned to orphaned downstream rows by row index.
This script only inspects explicit columns, path provenance, and possible
join keys. If modal rho exists without family provenance, it is reported as
ORPHANED_MODAL_RHO, not repaired.

Outputs
-------
metric_stage_6O_outputs/direct_modal_rho_provenance_audit_v1/
    stage6O_direct_modal_rho_file_inventory.csv
    stage6O_direct_modal_rho_column_inventory.csv
    stage6O_direct_modal_rho_candidate_files.csv
    stage6O_direct_modal_rho_join_key_audit.csv
    stage6O_direct_modal_rho_summary.json
    stage6O_direct_modal_rho_notes.txt

Run
---
From Spyder, run this file with --wdir from anywhere inside the project.
The script hard-prioritizes /home/dakini/Downloads/010-Quantum_Emergent_Gravity
and refuses to treat *_scripts folders as the project root.
========================================================================
"""

from __future__ import annotations

import json
import os
import re
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

PROJECT_NAME = "Quantum-Emergent Gravity"
SCRIPT_NAME = "Stage-6O_direct_modal_rho_provenance_audit_v1"
ROOT_MARKERS = [
    "metric_stage_4A_outputs",
    "metric_stage_5A_outputs",
    "metric_stage_6C_outputs",
    "metric_stage_6M_outputs",
    "metric_stage_6O_outputs",
]
HARD_ROOT = Path("/home/dakini/Downloads/010-Quantum_Emergent_Gravity")
FAMILIES = ["BARI", "NUFIT", "VALENCIA"]

PREFERRED_STAGE_DIRS = [
    "metric_stage_6H_outputs",
    "metric_stage_6I_outputs",
    "metric_stage_6J_outputs",
    "metric_stage_6K_outputs",
    "metric_stage_6L_outputs",
    "metric_stage_6M_outputs",
    "metric_stage_6N_outputs",
    "metric_stage_6O_outputs",
]

RHO_TERMS_STRONG = ["rho", "density", "profile", "mass", "u1", "mode", "target", "observed", "fit_y"]
RHO_TERMS_WEAK = ["kappa", "curvature", "response", "amplitude", "signal", "field", "pdf", "hist"]
COORD_TERMS = ["s", "s_normalized", "s_norm", "arc", "theta", "bin", "coordinate", "grid", "index"]
FAMILY_COL_TERMS = ["family", "fit", "fit_id", "npz", "source", "label", "variant", "dataset"]
JOIN_KEY_TERMS = ["id", "row", "record", "source", "fit", "npz", "particle", "metric", "variant", "anchor", "lineage"]
BAD_RHO_TERMS = ["degeneracy", "alignment", "spearman", "distance", "smoothness", "alpha", "beta", "delta", "invariance"]


def echo(msg: str) -> None:
    print(f"[Stage-6O direct-rho-audit] {msg}")


def detect_project_root() -> Path:
    candidates: List[Path] = []
    if HARD_ROOT.exists():
        candidates.append(HARD_ROOT)
    here = Path.cwd().resolve()
    candidates.extend([here] + list(here.parents))
    script_dir = Path(__file__).resolve().parent
    candidates.extend([script_dir] + list(script_dir.parents))

    for cand in candidates:
        if cand.name.endswith("_scripts"):
            continue
        if all((cand / marker).exists() for marker in ["metric_stage_6O_outputs"]):
            marker_count = sum((cand / marker).exists() for marker in ROOT_MARKERS)
            if marker_count >= 2:
                return cand
    # final fallback: hard root if it exists
    if HARD_ROOT.exists():
        return HARD_ROOT
    return here


def safe_read_header(path: Path) -> Tuple[Optional[List[str]], Optional[int], Optional[str]]:
    try:
        df0 = pd.read_csv(path, nrows=0)
        cols = [str(c) for c in df0.columns]
        try:
            # cheap-ish line count, excluding header
            with path.open("rb") as f:
                n = max(0, sum(1 for _ in f) - 1)
        except Exception:
            n = None
        return cols, n, None
    except Exception as exc:
        return None, None, repr(exc)


def contains_family_text(value: object) -> bool:
    s = str(value).upper()
    return any(f in s for f in FAMILIES)


def path_family_hits(path: Path) -> List[str]:
    up = str(path).upper()
    return [f for f in FAMILIES if f in up]


def col_score(col: str, terms: List[str]) -> int:
    low = col.lower()
    score = 0
    for t in terms:
        if t.lower() == low:
            score += 5
        elif t.lower() in low:
            score += 2
    return score


def semantic_rho_score(col: str) -> Tuple[int, str]:
    low = col.lower()
    strong = col_score(col, RHO_TERMS_STRONG)
    weak = col_score(col, RHO_TERMS_WEAK)
    bad = col_score(col, BAD_RHO_TERMS)
    score = strong + weak - bad
    reasons = []
    if strong:
        reasons.append(f"strong_rho_terms={strong}")
    if weak:
        reasons.append(f"weak_field_terms={weak}")
    if bad:
        reasons.append(f"diagnostic_penalty={bad}")
    return score, "; ".join(reasons) if reasons else "no_rho_terms"


def coord_score(col: str) -> Tuple[int, str]:
    score = col_score(col, COORD_TERMS)
    return score, f"coord_terms={score}" if score else "no_coord_terms"


def family_col_score(col: str) -> int:
    return col_score(col, FAMILY_COL_TERMS)


def join_key_score(col: str) -> int:
    return col_score(col, JOIN_KEY_TERMS)


def sample_family_values(path: Path, family_like_cols: List[str], max_rows: int = 2000) -> Dict[str, List[str]]:
    out: Dict[str, List[str]] = {}
    if not family_like_cols:
        return out
    try:
        df = pd.read_csv(path, usecols=family_like_cols, nrows=max_rows)
        for c in family_like_cols:
            vals = []
            ser = df[c].dropna().astype(str)
            for fam in FAMILIES:
                if ser.str.upper().str.contains(fam, regex=False).any():
                    vals.append(fam)
            if vals:
                out[c] = vals
    except Exception:
        pass
    return out


def numeric_preview_stats(path: Path, cols: List[str], max_rows: int = 5000) -> Dict[str, Dict[str, object]]:
    stats: Dict[str, Dict[str, object]] = {}
    if not cols:
        return stats
    try:
        df = pd.read_csv(path, usecols=cols, nrows=max_rows)
        for c in cols:
            x = pd.to_numeric(df[c], errors="coerce").dropna()
            if len(x) == 0:
                stats[c] = {"numeric": False, "n_numeric": 0}
            else:
                stats[c] = {
                    "numeric": True,
                    "n_numeric": int(len(x)),
                    "min": float(x.min()),
                    "max": float(x.max()),
                    "mean": float(x.mean()),
                    "std": float(x.std(ddof=0)),
                    "n_unique_sample": int(x.nunique()),
                }
    except Exception:
        pass
    return stats


def stage_rank_from_path(path: Path) -> int:
    s = str(path)
    # lower is more preferred for direct audit; 6H-L-M-N are highly relevant
    ranks = {
        "metric_stage_6M_outputs": 1,
        "metric_stage_6N_outputs": 2,
        "metric_stage_6L_outputs": 3,
        "metric_stage_6H_outputs": 4,
        "metric_stage_6K_outputs": 5,
        "metric_stage_6J_outputs": 6,
        "metric_stage_6I_outputs": 7,
        "metric_stage_6O_outputs": 8,
        "metric_stage_6D_outputs": 9,
        "metric_stage_6C_outputs": 10,
    }
    for k, v in ranks.items():
        if k in s:
            return v
    return 99


def collect_csvs(project_root: Path) -> List[Path]:
    files: List[Path] = []
    for d in PREFERRED_STAGE_DIRS:
        base = project_root / d
        if base.exists():
            files.extend(sorted(base.rglob("*.csv")))
    # Add key earlier stages that may contain family bridges, but keep them secondary.
    for d in ["metric_stage_6A_outputs", "metric_stage_6B_outputs", "metric_stage_6C_outputs", "metric_stage_6D_outputs", "metric_stage_5A_outputs", "metric_stage_4A_outputs"]:
        base = project_root / d
        if base.exists():
            files.extend(sorted(base.rglob("*.csv")))
    # Deduplicate while preserving order
    seen = set()
    out = []
    for f in files:
        rp = str(f.resolve())
        if rp not in seen:
            seen.add(rp)
            out.append(f)
    return out


def classify_candidate(has_rho: bool, has_coord: bool, has_family: bool, has_join: bool, stage_rank: int) -> str:
    if has_rho and has_coord and has_family:
        return "A_DIRECT_FAMILY_MODAL_RHO_CANDIDATE"
    if has_rho and has_coord and has_join:
        return "B_ORPHANED_MODAL_RHO_WITH_JOIN_KEYS"
    if has_rho and has_coord:
        return "C_ORPHANED_MODAL_RHO_NO_FAMILY"
    if has_family and has_join:
        return "D_FAMILY_BRIDGE_OR_LINEAGE_TABLE"
    if has_rho:
        return "E_RHO_COLUMNS_NO_COORDINATE"
    return "F_NOT_MODAL_RHO_RELEVANT"


def main() -> int:
    print("========================================================================")
    print("Stage-6O: Direct Modal Rho Provenance Audit")
    print("========================================================================")
    echo(f"Python executable: {sys.executable}")
    echo(f"Working directory : {Path.cwd().resolve()}")
    echo("Priority rule: inspect explicit modal rho provenance; no row-index repair.")

    root = detect_project_root()
    echo(f"Project root: {root}")
    outdir = root / "metric_stage_6O_outputs" / "direct_modal_rho_provenance_audit_v1"
    outdir.mkdir(parents=True, exist_ok=True)
    echo(f"Output dir  : {outdir}")

    csvs = collect_csvs(root)
    echo(f"Scanning CSV files: {len(csvs)}")

    file_rows = []
    col_rows = []
    candidate_rows = []
    join_rows = []

    for i, path in enumerate(csvs, start=1):
        if i % 25 == 0:
            echo(f"  scanned {i}/{len(csvs)} files...")
        cols, nrows, err = safe_read_header(path)
        rel = str(path.relative_to(root)) if str(path).startswith(str(root)) else str(path)
        pr = stage_rank_from_path(path)
        phits = path_family_hits(path)
        if cols is None:
            file_rows.append({"file": str(path), "relative_file": rel, "read_error": err, "n_rows": nrows})
            continue

        rho_cols = []
        coord_cols = []
        fam_like_cols = []
        join_cols = []
        for c in cols:
            rs, rr = semantic_rho_score(c)
            cs, cr = coord_score(c)
            fs = family_col_score(c)
            js = join_key_score(c)
            if rs > 0:
                rho_cols.append(c)
            if cs > 0:
                coord_cols.append(c)
            if fs > 0:
                fam_like_cols.append(c)
            if js > 0:
                join_cols.append(c)
            col_rows.append({
                "file": str(path),
                "relative_file": rel,
                "stage_rank": pr,
                "column": c,
                "rho_semantic_score": rs,
                "rho_semantic_reasons": rr,
                "coord_score": cs,
                "family_col_score": fs,
                "join_key_score": js,
            })

        fam_values = sample_family_values(path, fam_like_cols)
        explicit_family_cols = list(fam_values.keys())
        has_family = bool(phits or explicit_family_cols)
        has_rho = bool(rho_cols)
        has_coord = bool(coord_cols)
        has_join = bool(join_cols)
        classification = classify_candidate(has_rho, has_coord, has_family, has_join, pr)

        rho_stats = numeric_preview_stats(path, rho_cols[:8])
        file_rows.append({
            "file": str(path),
            "relative_file": rel,
            "stage_rank": pr,
            "n_rows": nrows,
            "n_cols": len(cols),
            "path_family_hits": ",".join(phits),
            "family_like_cols": ",".join(fam_like_cols),
            "explicit_family_cols": ",".join(explicit_family_cols),
            "family_values_found": json.dumps(fam_values),
            "rho_like_cols": ",".join(rho_cols),
            "coord_like_cols": ",".join(coord_cols),
            "join_like_cols": ",".join(join_cols),
            "classification": classification,
            "read_error": err,
        })

        if classification != "F_NOT_MODAL_RHO_RELEVANT":
            # Score direct modal relevance. Penalize diagnostic-ish rho names.
            best_rho_score = max([semantic_rho_score(c)[0] for c in rho_cols], default=0)
            best_coord_score = max([coord_score(c)[0] for c in coord_cols], default=0)
            direct_bonus = 20 if classification.startswith("A_") else 0
            orphan_bonus = 10 if classification.startswith("B_") else 0
            stage_bonus = max(0, 12 - pr)
            family_bonus = 8 if has_family else 0
            review_score = direct_bonus + orphan_bonus + stage_bonus + family_bonus + best_rho_score + best_coord_score
            candidate_rows.append({
                "review_score": review_score,
                "classification": classification,
                "file": str(path),
                "relative_file": rel,
                "stage_rank": pr,
                "n_rows": nrows,
                "path_family_hits": ",".join(phits),
                "explicit_family_cols": ",".join(explicit_family_cols),
                "rho_like_cols": ",".join(rho_cols),
                "coord_like_cols": ",".join(coord_cols),
                "join_like_cols": ",".join(join_cols),
                "rho_stats_preview": json.dumps(rho_stats),
            })

        if has_join or has_family:
            join_rows.append({
                "file": str(path),
                "relative_file": rel,
                "stage_rank": pr,
                "classification": classification,
                "explicit_family_cols": ",".join(explicit_family_cols),
                "family_values_found": json.dumps(fam_values),
                "join_like_cols": ",".join(join_cols),
                "rho_like_cols": ",".join(rho_cols),
                "coord_like_cols": ",".join(coord_cols),
            })

    file_df = pd.DataFrame(file_rows)
    col_df = pd.DataFrame(col_rows)
    cand_df = pd.DataFrame(candidate_rows)
    join_df = pd.DataFrame(join_rows)
    if not cand_df.empty:
        cand_df = cand_df.sort_values(["classification", "review_score", "stage_rank"], ascending=[True, False, True])
    if not join_df.empty:
        join_df = join_df.sort_values(["stage_rank", "classification"])

    file_csv = outdir / "stage6O_direct_modal_rho_file_inventory.csv"
    col_csv = outdir / "stage6O_direct_modal_rho_column_inventory.csv"
    cand_csv = outdir / "stage6O_direct_modal_rho_candidate_files.csv"
    join_csv = outdir / "stage6O_direct_modal_rho_join_key_audit.csv"
    file_df.to_csv(file_csv, index=False)
    col_df.to_csv(col_csv, index=False)
    cand_df.to_csv(cand_csv, index=False)
    join_df.to_csv(join_csv, index=False)

    counts = cand_df["classification"].value_counts().to_dict() if not cand_df.empty else {}
    direct = cand_df[cand_df["classification"].eq("A_DIRECT_FAMILY_MODAL_RHO_CANDIDATE")] if not cand_df.empty else pd.DataFrame()
    orphan_join = cand_df[cand_df["classification"].eq("B_ORPHANED_MODAL_RHO_WITH_JOIN_KEYS")] if not cand_df.empty else pd.DataFrame()
    orphan = cand_df[cand_df["classification"].eq("C_ORPHANED_MODAL_RHO_NO_FAMILY")] if not cand_df.empty else pd.DataFrame()

    if len(direct) > 0:
        verdict = "DIRECT_FAMILY_MODAL_RHO_CANDIDATE_FOUND"
        explanation = "At least one file contains rho/density/profile-like columns, coordinate columns, and explicit family provenance. Inspect top A candidates for universality rebuild."
    elif len(orphan_join) > 0:
        verdict = "ORPHANED_MODAL_RHO_WITH_JOIN_KEYS_FOUND"
        explanation = "Modal rho-like files exist with possible join keys, but no explicit family labels. Next step is a safe key-based join to an upstream family bridge, not row-index repair."
    elif len(orphan) > 0:
        verdict = "ORPHANED_MODAL_RHO_FOUND_NO_FAMILY_PROVENANCE"
        explanation = "Modal rho-like files exist, but no family provenance or safe join keys were found. Family-aware universality remains blocked."
    else:
        verdict = "NO_MODAL_RHO_FILES_FOUND_IN_DIRECT_AUDIT"
        explanation = "No rho/density/profile-like modal source files were detected in audited CSV outputs. The intended modal object may be JSON-only, image-only, generated in memory, or outside scanned outputs."

    top_candidates = cand_df.head(25).to_dict(orient="records") if not cand_df.empty else []
    summary = {
        "script": SCRIPT_NAME,
        "project_root": str(root),
        "output_dir": str(outdir),
        "n_csv_scanned": len(csvs),
        "candidate_class_counts": counts,
        "consensus_verdict": verdict,
        "consensus_explanation": explanation,
        "outputs": {
            "file_inventory_csv": str(file_csv),
            "column_inventory_csv": str(col_csv),
            "candidate_files_csv": str(cand_csv),
            "join_key_audit_csv": str(join_csv),
        },
        "top_candidates": top_candidates,
    }
    summary_json = outdir / "stage6O_direct_modal_rho_summary.json"
    notes_txt = outdir / "stage6O_direct_modal_rho_notes.txt"
    with summary_json.open("w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, allow_nan=True)

    with notes_txt.open("w", encoding="utf-8") as f:
        f.write("============================================================\n")
        f.write("STAGE-6O DIRECT MODAL RHO PROVENANCE AUDIT NOTES\n")
        f.write(f"Project: {PROJECT_NAME}\n")
        f.write("Stage: 6O-Direct-Modal-Rho-Provenance-Audit\n")
        f.write("============================================================\n\n")
        f.write("CRITICAL RULE\n-------------\n")
        f.write("No family labels are assigned to orphaned downstream rows by row index.\n")
        f.write("This audit inspects explicit family provenance and possible join keys only.\n\n")
        f.write("CONSENSUS VERDICT\n-----------------\n")
        f.write(verdict + "\n\n")
        f.write("EXPLANATION\n-----------\n")
        f.write(explanation + "\n\n")
        f.write("CLASSIFICATION COUNTS\n---------------------\n")
        for k, v in counts.items():
            f.write(f"{k}: {v}\n")
        f.write("\nTOP 25 CANDIDATE FILES\n----------------------\n")
        if cand_df.empty:
            f.write("No candidate files.\n")
        else:
            cols_to_show = [
                "review_score", "classification", "stage_rank", "relative_file",
                "explicit_family_cols", "rho_like_cols", "coord_like_cols", "join_like_cols"
            ]
            f.write(cand_df[cols_to_show].head(25).to_string(index=False))
            f.write("\n")
        f.write("\nNEXT ACTION\n-----------\n")
        if verdict == "DIRECT_FAMILY_MODAL_RHO_CANDIDATE_FOUND":
            f.write("Manually inspect top A candidates, then rebuild family profiles from those explicit family modal-rho files.\n")
        elif verdict == "ORPHANED_MODAL_RHO_WITH_JOIN_KEYS_FOUND":
            f.write("Build a safe key-join script using the reported join keys and Stage-5A/6C family bridge. Do not use row index.\n")
        elif verdict == "ORPHANED_MODAL_RHO_FOUND_NO_FAMILY_PROVENANCE":
            f.write("Return to the script that created the modal rho object and modify it to carry family provenance forward at creation time.\n")
        else:
            f.write("Inspect non-CSV outputs or regenerate Stage-6M/6N modal rho with explicit family provenance.\n")
        f.write("\n============================================================\nEND NOTES\n============================================================\n")

    print("------------------------------------------------------------------------")
    echo("Done.")
    echo(f"File inventory CSV : {file_csv}")
    echo(f"Column inventory CSV: {col_csv}")
    echo(f"Candidates CSV     : {cand_csv}")
    echo(f"Join audit CSV     : {join_csv}")
    echo(f"Summary JSON       : {summary_json}")
    echo(f"Notes TXT          : {notes_txt}")
    echo(f"Consensus          : {verdict}")
    print("========================================================================")
    return 0 if verdict in ["DIRECT_FAMILY_MODAL_RHO_CANDIDATE_FOUND", "ORPHANED_MODAL_RHO_WITH_JOIN_KEYS_FOUND"] else 3


if __name__ == "__main__":
    raise SystemExit(main())
