#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
============================================================
Project: Quantum-Emergent Gravity
Stage  : 6M-targeted-v2c
Title  : Targeted Modal Resolution
Author : Arturo Ortiz-Tapia
Build  : 2026-04-23
============================================================

Purpose
-------
Stage-6M v2b improved the modal baseline by moving from a one-component
anchor to an unconstrained two-component anchor.  However, both learned
Gaussian lobes drifted toward the central region and left the early-s / left
edge spike under-explained.  Derivative and fractional corrections gave only
small gains, so this targeted substage tests modal geometry directly rather
than adding more calculus.

This script runs BOTH targeted upgrades in the same execution:

A) Constrained two-component fit
   - one Gaussian-like component forced into an early-s window
   - one Gaussian-like component forced into the central window

B) Central + edge decomposition
   - one Gaussian-like central component
   - one explicitly left-boundary-loaded template

The goal is to decide whether the remaining rho(s) mismatch is closer to a
true constrained bimodal geometry or to boundary-sector / edge-loaded physics.

Expected upstream inputs
------------------------
Primary:
    metric_stage_6M_outputs/stage6M_modal_profile.csv
    metric_stage_6M_outputs/stage6M_modal_summary.json
    metric_stage_6M_outputs/stage6M_modal_notes.txt

Optional:
    metric_stage_6M_outputs/stage6M_center_width_table.csv
    metric_stage_6M_outputs/stage6M_derivative_terms_optional.csv
    metric_stage_6M_outputs/stage6M_family_universality.csv

Outputs
-------
Written to metric_stage_6M_outputs/:
    stage6M_targeted_v2c_profile.csv
    stage6M_targeted_v2c_model_comparison.csv
    stage6M_targeted_v2c_residual_localization.csv
    stage6M_targeted_v2c_summary.json
    stage6M_targeted_v2c_notes.txt
    stage6M_targeted_v2c_fit_comparison.png
    stage6M_targeted_v2c_residuals.png

Scientific status
-----------------
This is a targeted diagnostic/corrective substage. It does not claim a final
physical law. It asks whether Stage-6M should remain modal with improved
geometry, return to the separable-operator language, or revisit rho/kappa
upstream.
============================================================
"""

from __future__ import annotations

import json
import math
import os
import sys
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

try:
    from scipy.optimize import least_squares
    SCIPY_AVAILABLE = True
except Exception:
    SCIPY_AVAILABLE = False

try:
    import matplotlib.pyplot as plt
    MPL_AVAILABLE = True
except Exception:
    MPL_AVAILABLE = False


# -----------------------------------------------------------------------------
# Console helpers
# -----------------------------------------------------------------------------

def echo(msg: str = "") -> None:
    print(msg, flush=True)


def banner(title: str) -> None:
    echo("=" * 72)
    echo(title)
    echo("=" * 72)


# -----------------------------------------------------------------------------
# Project discovery and I/O
# -----------------------------------------------------------------------------

def discover_project_root() -> Path:
    """Find the QEG project root robustly in Spyder, terminal, or uploaded sandbox."""
    candidates: List[Path] = []

    # 1) Script location and current working directory ancestors.
    try:
        candidates.append(Path(__file__).resolve().parent)
    except Exception:
        pass
    candidates.append(Path.cwd().resolve())

    # 2) Known user project location.
    candidates.append(Path("/home/dakini/Downloads/010-Quantum_Emergent_Gravity"))

    # 3) Sandbox fallback used only for testing this handoff script here.
    candidates.append(Path("/mnt/data"))

    for base in list(candidates):
        for p in [base] + list(base.parents):
            if (p / "metric_stage_6M_outputs").exists():
                return p
            if (p / "stage6M_modal_profile.csv").exists():
                return p

    # If no output folder exists yet, prefer the known project location if its
    # parent is available; otherwise use the current directory.
    known = Path("/home/dakini/Downloads/010-Quantum_Emergent_Gravity")
    if known.parent.exists():
        return known
    return Path.cwd().resolve()


def read_csv_first(paths: List[Path], required: bool = True) -> Optional[pd.DataFrame]:
    for p in paths:
        if p.exists():
            echo(f"[Stage-6M v2c INPUT] Loaded CSV: {p}")
            return pd.read_csv(p)
    if required:
        raise FileNotFoundError("None of the CSV candidates exists:\n" + "\n".join(str(p) for p in paths))
    return None


def read_json_first(paths: List[Path]) -> Dict:
    for p in paths:
        if p.exists():
            echo(f"[Stage-6M v2c INPUT] Loaded JSON: {p}")
            with open(p, "r", encoding="utf-8") as f:
                return json.load(f)
    return {}


def ensure_output_dir(root: Path) -> Path:
    if root.name == "metric_stage_6M_outputs":
        out = root
    else:
        out = root / "metric_stage_6M_outputs"
    out.mkdir(parents=True, exist_ok=True)
    return out


# -----------------------------------------------------------------------------
# Numerical utilities
# -----------------------------------------------------------------------------

def finite_xy(s: np.ndarray, y: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    mask = np.isfinite(s) & np.isfinite(y)
    return s[mask].astype(float), y[mask].astype(float)


def safe_r2(y: np.ndarray, yhat: np.ndarray) -> float:
    ss_res = float(np.sum((y - yhat) ** 2))
    ss_tot = float(np.sum((y - np.mean(y)) ** 2))
    if ss_tot <= 1e-15:
        return float("nan")
    return 1.0 - ss_res / ss_tot


def safe_corr(y: np.ndarray, yhat: np.ndarray) -> float:
    if len(y) < 3 or np.std(y) <= 1e-15 or np.std(yhat) <= 1e-15:
        return float("nan")
    return float(np.corrcoef(y, yhat)[0, 1])


def rmse(y: np.ndarray, yhat: np.ndarray) -> float:
    return float(np.sqrt(np.mean((y - yhat) ** 2)))


def aic_like(y: np.ndarray, yhat: np.ndarray, k: int) -> float:
    n = len(y)
    rss = max(float(np.sum((y - yhat) ** 2)), 1e-300)
    return float(n * math.log(rss / n) + 2 * k)


def gaussian(s: np.ndarray, amp: float, mu: float, sigma: float) -> np.ndarray:
    sigma = max(abs(float(sigma)), 1e-8)
    return amp * np.exp(-0.5 * ((s - mu) / sigma) ** 2)


def normalize_template(t: np.ndarray) -> np.ndarray:
    t = np.asarray(t, dtype=float)
    m = float(np.max(np.abs(t))) if t.size else 0.0
    if m <= 1e-15:
        return t
    return t / m


def linear_fit_templates(y: np.ndarray, templates: List[np.ndarray], include_intercept: bool = True) -> Tuple[np.ndarray, np.ndarray]:
    cols = [np.asarray(t, dtype=float) for t in templates]
    if include_intercept:
        cols.append(np.ones_like(y, dtype=float))
    X = np.vstack(cols).T
    coef, *_ = np.linalg.lstsq(X, y, rcond=None)
    return X @ coef, coef


def edge_template(s: np.ndarray, kind: str, scale: float) -> np.ndarray:
    """Left-boundary-loaded basis templates, normalized to max absolute value 1."""
    scale = max(float(scale), 1e-6)
    ss = np.clip(s - np.min(s), 0, None)
    if kind == "left_exponential":
        raw = np.exp(-ss / scale)
    elif kind == "left_half_gaussian":
        raw = np.exp(-0.5 * (ss / scale) ** 2)
    elif kind == "left_rational":
        raw = 1.0 / (1.0 + (ss / scale) ** 2)
    elif kind == "left_linear_cutoff":
        raw = np.maximum(0.0, 1.0 - ss / scale)
    else:
        raise ValueError(f"Unknown edge template: {kind}")
    return normalize_template(raw)


@dataclass
class FitResult:
    model_name: str
    r2: float
    corr: float
    rmse: float
    aic_like: float
    n_params: int
    prediction_col: str
    residual_col: str
    params: Dict[str, float]
    component_summary: Dict[str, float]
    edge_capture_ratio: float
    edge_rmse: float
    central_rmse: float
    right_rmse: float
    verdict: str


# -----------------------------------------------------------------------------
# Model fits
# -----------------------------------------------------------------------------

def fit_constrained_two_component(s: np.ndarray, y: np.ndarray) -> Tuple[np.ndarray, Dict[str, float], Dict[str, np.ndarray]]:
    """Fit baseline + early-window Gaussian + central-window Gaussian."""
    if not SCIPY_AVAILABLE:
        # Fallback grid search over centers and widths with linear amplitudes.
        best = None
        for mu_e in np.linspace(0.02, 0.22, 21):
            for sig_e in np.linspace(0.015, 0.18, 14):
                te = np.exp(-0.5 * ((s - mu_e) / sig_e) ** 2)
                for mu_c in np.linspace(0.30, 0.62, 33):
                    for sig_c in np.linspace(0.03, 0.22, 12):
                        tc = np.exp(-0.5 * ((s - mu_c) / sig_c) ** 2)
                        pred, coef = linear_fit_templates(y, [te, tc], include_intercept=True)
                        val = rmse(y, pred)
                        if best is None or val < best[0]:
                            best = (val, pred, coef, mu_e, sig_e, mu_c, sig_c, te, tc)
        _, pred, coef, mu_e, sig_e, mu_c, sig_c, te, tc = best
        params = {"amp_early": float(coef[0]), "mu_early": float(mu_e), "sigma_early": float(sig_e),
                  "amp_central": float(coef[1]), "mu_central": float(mu_c), "sigma_central": float(sig_c),
                  "baseline": float(coef[2])}
        return pred, params, {"early_component": coef[0] * te, "central_component": coef[1] * tc}

    y_min, y_max = float(np.min(y)), float(np.max(y))
    amp_scale = max(abs(y_min), abs(y_max), 1e-3)
    idx_left = int(np.argmax(y[s <= np.quantile(s, 0.30)])) if np.any(s <= np.quantile(s, 0.30)) else 0
    s_left = s[s <= np.quantile(s, 0.30)]
    y_left = y[s <= np.quantile(s, 0.30)]
    mu_e0 = float(s_left[int(np.argmax(y_left))]) if len(s_left) else 0.08
    mu_c0 = float(s[int(np.argmax(y))])
    mu_c0 = min(max(mu_c0, 0.30), 0.70)
    p0 = [0.35 * amp_scale, mu_e0, 0.06, 0.80 * amp_scale, mu_c0, 0.08, float(np.percentile(y, 10))]
    lb = [-5 * amp_scale, 0.000, 0.008, -5 * amp_scale, 0.250, 0.012, y_min - 5 * amp_scale]
    ub = [ 5 * amp_scale, 0.250, 0.250,  5 * amp_scale, 0.750, 0.350, y_max + 5 * amp_scale]

    def residual(p: np.ndarray) -> np.ndarray:
        ae, mue, se, ac, muc, sc, b = p
        return b + gaussian(s, ae, mue, se) + gaussian(s, ac, muc, sc) - y

    res = least_squares(residual, p0, bounds=(lb, ub), max_nfev=50000)
    ae, mue, se, ac, muc, sc, b = res.x
    early = gaussian(s, ae, mue, se)
    central = gaussian(s, ac, muc, sc)
    pred = b + early + central
    params = {"amp_early": float(ae), "mu_early": float(mue), "sigma_early": float(se),
              "amp_central": float(ac), "mu_central": float(muc), "sigma_central": float(sc),
              "baseline": float(b), "optimizer_cost": float(res.cost), "optimizer_success": float(res.success)}
    return pred, params, {"early_component": early, "central_component": central}


def fit_central_edge(s: np.ndarray, y: np.ndarray) -> Tuple[np.ndarray, Dict[str, float], Dict[str, np.ndarray]]:
    """Fit central Gaussian plus one left-boundary-loaded template."""
    if not SCIPY_AVAILABLE:
        best = None
        for kind in ["left_exponential", "left_half_gaussian", "left_rational", "left_linear_cutoff"]:
            for scale in np.linspace(0.015, 0.35, 45):
                edge = edge_template(s, kind, scale)
                for mu_c in np.linspace(0.30, 0.70, 45):
                    for sig_c in np.linspace(0.025, 0.28, 25):
                        cent = np.exp(-0.5 * ((s - mu_c) / sig_c) ** 2)
                        pred, coef = linear_fit_templates(y, [edge, cent], include_intercept=True)
                        val = rmse(y, pred)
                        if best is None or val < best[0]:
                            best = (val, pred, coef, kind, scale, mu_c, sig_c, edge, cent)
        _, pred, coef, kind, scale, mu_c, sig_c, edge, cent = best
        params = {"edge_kind_code": kind, "edge_scale": float(scale), "amp_edge": float(coef[0]),
                  "amp_central": float(coef[1]), "mu_central": float(mu_c), "sigma_central": float(sig_c),
                  "baseline": float(coef[2])}
        return pred, params, {"edge_component": coef[0] * edge, "central_component": coef[1] * cent}

    y_min, y_max = float(np.min(y)), float(np.max(y))
    amp_scale = max(abs(y_min), abs(y_max), 1e-3)
    best = None

    # Edge template kind is discrete; optimize continuous parameters for each kind.
    for kind in ["left_exponential", "left_half_gaussian", "left_rational", "left_linear_cutoff"]:
        mu_c0 = float(s[int(np.argmax(y))])
        mu_c0 = min(max(mu_c0, 0.30), 0.70)
        # p = edge_amp, edge_scale, central_amp, central_mu, central_sigma, baseline
        p0 = [0.35 * amp_scale, 0.08, 0.80 * amp_scale, mu_c0, 0.08, float(np.percentile(y, 10))]
        lb = [-5 * amp_scale, 0.006, -5 * amp_scale, 0.250, 0.012, y_min - 5 * amp_scale]
        ub = [ 5 * amp_scale, 0.500,  5 * amp_scale, 0.800, 0.400, y_max + 5 * amp_scale]

        def residual(p: np.ndarray) -> np.ndarray:
            ae, scale, ac, muc, sc, b = p
            edge = edge_template(s, kind, scale)
            return b + ae * edge + gaussian(s, ac, muc, sc) - y

        res = least_squares(residual, p0, bounds=(lb, ub), max_nfev=50000)
        pred = y + residual(res.x)
        score = rmse(y, pred)
        if best is None or score < best[0]:
            best = (score, kind, res, pred)

    _, kind, res, pred = best
    ae, scale, ac, muc, sc, b = res.x
    edge = ae * edge_template(s, kind, scale)
    central = gaussian(s, ac, muc, sc)
    params = {"edge_kind": kind, "amp_edge": float(ae), "edge_scale": float(scale),
              "amp_central": float(ac), "mu_central": float(muc), "sigma_central": float(sc),
              "baseline": float(b), "optimizer_cost": float(res.cost), "optimizer_success": float(res.success)}
    return pred, params, {"edge_component": edge, "central_component": central}


def fit_prior_unconstrained_two_component(s: np.ndarray, y: np.ndarray) -> Tuple[np.ndarray, Dict[str, float], Dict[str, np.ndarray]]:
    """Re-fit an unconstrained two-Gaussian baseline for local side-by-side comparison."""
    if not SCIPY_AVAILABLE:
        # Use uploaded prediction if possible elsewhere; this fallback is intentionally simple.
        pred, coef = linear_fit_templates(y, [np.ones_like(y)], include_intercept=False)
        return pred, {"fallback": 1.0}, {"component1": np.zeros_like(y), "component2": np.zeros_like(y)}
    y_min, y_max = float(np.min(y)), float(np.max(y))
    amp_scale = max(abs(y_min), abs(y_max), 1e-3)
    p0 = [0.5 * amp_scale, 0.42, 0.06, 0.5 * amp_scale, 0.52, 0.06, float(np.percentile(y, 10))]
    lb = [-5 * amp_scale, float(np.min(s)), 0.008, -5 * amp_scale, float(np.min(s)), 0.008, y_min - 5 * amp_scale]
    ub = [ 5 * amp_scale, float(np.max(s)), 0.500,  5 * amp_scale, float(np.max(s)), 0.500, y_max + 5 * amp_scale]
    def residual(p: np.ndarray) -> np.ndarray:
        a1, m1, sg1, a2, m2, sg2, b = p
        return b + gaussian(s, a1, m1, sg1) + gaussian(s, a2, m2, sg2) - y
    res = least_squares(residual, p0, bounds=(lb, ub), max_nfev=50000)
    a1, m1, sg1, a2, m2, sg2, b = res.x
    c1 = gaussian(s, a1, m1, sg1)
    c2 = gaussian(s, a2, m2, sg2)
    params = {"amp1": float(a1), "mu1": float(m1), "sigma1": float(sg1),
              "amp2": float(a2), "mu2": float(m2), "sigma2": float(sg2), "baseline": float(b)}
    return b + c1 + c2, params, {"component1": c1, "component2": c2}


# -----------------------------------------------------------------------------
# Diagnostics
# -----------------------------------------------------------------------------

def window_masks(s: np.ndarray) -> Dict[str, np.ndarray]:
    return {
        "edge": s <= 0.25,
        "central": (s > 0.25) & (s <= 0.75),
        "right": s > 0.75,
    }


def residual_diagnostics(s: np.ndarray, y: np.ndarray, pred: np.ndarray) -> Dict[str, float]:
    masks = window_masks(s)
    res = y - pred
    out: Dict[str, float] = {}
    for name, mask in masks.items():
        if np.any(mask):
            out[f"{name}_rmse"] = rmse(y[mask], pred[mask])
            out[f"{name}_mean_abs_residual"] = float(np.mean(np.abs(res[mask])))
            out[f"{name}_residual_mass_abs"] = float(np.sum(np.abs(res[mask])))
            out[f"{name}_observed_mass_abs"] = float(np.sum(np.abs(y[mask])))
        else:
            out[f"{name}_rmse"] = float("nan")
            out[f"{name}_mean_abs_residual"] = float("nan")
            out[f"{name}_residual_mass_abs"] = float("nan")
            out[f"{name}_observed_mass_abs"] = float("nan")
    # Capture ratio: 1 means edge residual vanished; 0 means no improvement over zero prediction in edge window.
    edge = masks["edge"]
    if np.any(edge):
        denom = float(np.sum((y[edge] - np.mean(y[edge])) ** 2))
        numer = float(np.sum((y[edge] - pred[edge]) ** 2))
        out["edge_capture_ratio"] = float(1.0 - numer / denom) if denom > 1e-15 else float("nan")
    else:
        out["edge_capture_ratio"] = float("nan")
    return out


def make_fit_result(name: str, s: np.ndarray, y: np.ndarray, pred: np.ndarray, params: Dict[str, float], pred_col: str) -> FitResult:
    diag = residual_diagnostics(s, y, pred)
    r2 = safe_r2(y, pred)
    corr = safe_corr(y, pred)
    err = rmse(y, pred)
    k = len(params)
    edge_capture = diag["edge_capture_ratio"]
    if np.isfinite(edge_capture) and edge_capture > 0.50 and r2 > 0.45:
        verdict = "strong_targeted_capture"
    elif np.isfinite(edge_capture) and edge_capture > 0.20 and r2 > 0.40:
        verdict = "partial_targeted_capture"
    elif r2 > 0.40:
        verdict = "global_fit_but_edge_unclear"
    else:
        verdict = "weak_or_structurally_incomplete"
    return FitResult(
        model_name=name,
        r2=float(r2), corr=float(corr), rmse=float(err), aic_like=aic_like(y, pred, k), n_params=k,
        prediction_col=pred_col, residual_col=pred_col.replace("prediction", "residual"),
        params={kk: (float(v) if isinstance(v, (int, float, np.floating)) and np.isfinite(v) else v) for kk, v in params.items()},
        component_summary={},
        edge_capture_ratio=float(edge_capture), edge_rmse=float(diag["edge_rmse"]),
        central_rmse=float(diag["central_rmse"]), right_rmse=float(diag["right_rmse"]),
        verdict=verdict,
    )


def add_result_to_profile(profile: pd.DataFrame, col: str, pred: np.ndarray, comps: Dict[str, np.ndarray]) -> None:
    profile[col] = pred
    profile[col.replace("prediction", "residual")] = profile["rho"].to_numpy(dtype=float) - pred
    for cname, cval in comps.items():
        profile[f"{col.replace('_prediction','')}_{cname}"] = cval


def previous_model_rows(profile: pd.DataFrame, y: np.ndarray) -> List[Dict]:
    rows = []
    for col in ["one_mode_template_prediction", "two_component_prediction", "derivative_corrected_prediction"]:
        if col in profile.columns:
            pred = profile[col].to_numpy(dtype=float)
            diag = residual_diagnostics(profile["s"].to_numpy(dtype=float), y, pred)
            rows.append({
                "model_name": f"prior_{col.replace('_prediction','')}",
                "r2": safe_r2(y, pred),
                "corr": safe_corr(y, pred),
                "rmse": rmse(y, pred),
                "aic_like": np.nan,
                "n_params": np.nan,
                "edge_capture_ratio": diag["edge_capture_ratio"],
                "edge_rmse": diag["edge_rmse"],
                "central_rmse": diag["central_rmse"],
                "right_rmse": diag["right_rmse"],
                "verdict": "prior_reference",
            })
    return rows


# -----------------------------------------------------------------------------
# Main execution
# -----------------------------------------------------------------------------

def main() -> None:
    banner("Stage-6M-targeted-v2c: Targeted Modal Resolution")
    echo(f"[Stage-6M v2c PRECHECK] Python executable: {sys.executable}")
    echo(f"[Stage-6M v2c PRECHECK] scipy available: {SCIPY_AVAILABLE}")
    echo(f"[Stage-6M v2c PRECHECK] matplotlib available: {MPL_AVAILABLE}")

    root = discover_project_root()
    out_dir = ensure_output_dir(root)
    echo(f"[Stage-6M v2c PRECHECK] Project root: {root}")
    echo(f"[Stage-6M v2c PRECHECK] Output dir  : {out_dir}")

    profile_candidates = [
        out_dir / "stage6M_modal_profile.csv",
        root / "stage6M_modal_profile.csv",
        Path("/mnt/data/stage6M_modal_profile.csv"),
    ]
    summary_candidates = [
        out_dir / "stage6M_modal_summary.json",
        root / "stage6M_modal_summary.json",
        Path("/mnt/data/stage6M_modal_summary.json"),
    ]

    profile = read_csv_first(profile_candidates, required=True)
    upstream_summary = read_json_first(summary_candidates)

    required_cols = ["s", "rho"]
    for c in required_cols:
        if c not in profile.columns:
            raise ValueError(f"Required column '{c}' not found in modal profile. Available: {list(profile.columns)}")

    s, rho = finite_xy(profile["s"].to_numpy(dtype=float), profile["rho"].to_numpy(dtype=float))
    # Reindex profile to finite rows only, preserving all other upstream columns.
    finite_mask = np.isfinite(profile["s"].to_numpy(dtype=float)) & np.isfinite(profile["rho"].to_numpy(dtype=float))
    profile = profile.loc[finite_mask].reset_index(drop=True)
    s = profile["s"].to_numpy(dtype=float)
    rho = profile["rho"].to_numpy(dtype=float)

    # Sort by intrinsic coordinate to make windows and derivative interpretations stable.
    order = np.argsort(s)
    profile = profile.iloc[order].reset_index(drop=True)
    s = profile["s"].to_numpy(dtype=float)
    rho = profile["rho"].to_numpy(dtype=float)

    echo(f"[Stage-6M v2c DATA] n = {len(profile)}")
    echo(f"[Stage-6M v2c DATA] s range = [{np.min(s):.6g}, {np.max(s):.6g}]")
    echo(f"[Stage-6M v2c DATA] rho range = [{np.min(rho):.6g}, {np.max(rho):.6g}]")

    # METHOD A: constrained two-component geometry.
    banner("METHOD A: constrained early-s + central two-component fit")
    pred_A, params_A, comps_A = fit_constrained_two_component(s, rho)
    add_result_to_profile(profile, "targeted_constrained_two_component_prediction", pred_A, comps_A)
    result_A = make_fit_result("targeted_constrained_two_component", s, rho, pred_A, params_A,
                               "targeted_constrained_two_component_prediction")
    echo(f"[METHOD A] R2={result_A.r2:.6f}, corr={result_A.corr:.6f}, rmse={result_A.rmse:.6f}, edge_capture={result_A.edge_capture_ratio:.6f}")
    echo(f"[METHOD A] params={params_A}")

    # METHOD B: central + edge/boundary template.
    banner("METHOD B: central Gaussian + explicit left-edge template")
    pred_B, params_B, comps_B = fit_central_edge(s, rho)
    add_result_to_profile(profile, "targeted_central_edge_prediction", pred_B, comps_B)
    result_B = make_fit_result("targeted_central_edge", s, rho, pred_B, params_B,
                               "targeted_central_edge_prediction")
    echo(f"[METHOD B] R2={result_B.r2:.6f}, corr={result_B.corr:.6f}, rmse={result_B.rmse:.6f}, edge_capture={result_B.edge_capture_ratio:.6f}")
    echo(f"[METHOD B] params={params_B}")

    # Local reference: unconstrained two Gaussian, not as target but as sanity check.
    banner("REFERENCE: local unconstrained two-Gaussian refit")
    pred_U, params_U, comps_U = fit_prior_unconstrained_two_component(s, rho)
    add_result_to_profile(profile, "refit_unconstrained_two_gaussian_prediction", pred_U, comps_U)
    result_U = make_fit_result("refit_unconstrained_two_gaussian", s, rho, pred_U, params_U,
                               "refit_unconstrained_two_gaussian_prediction")
    echo(f"[REFERENCE] R2={result_U.r2:.6f}, corr={result_U.corr:.6f}, rmse={result_U.rmse:.6f}, edge_capture={result_U.edge_capture_ratio:.6f}")

    # Comparison table includes prior columns already present in the upstream profile.
    comparison_rows = previous_model_rows(profile, rho)
    comparison_rows.extend([asdict(result_U), asdict(result_A), asdict(result_B)])
    comparison = pd.DataFrame(comparison_rows)

    # Residual localization for targeted models.
    residual_rows = []
    for name, pred in [
        ("refit_unconstrained_two_gaussian", pred_U),
        ("targeted_constrained_two_component", pred_A),
        ("targeted_central_edge", pred_B),
    ]:
        diag = residual_diagnostics(s, rho, pred)
        for window in ["edge", "central", "right"]:
            residual_rows.append({
                "model_name": name,
                "window": window,
                "rmse": diag[f"{window}_rmse"],
                "mean_abs_residual": diag[f"{window}_mean_abs_residual"],
                "residual_mass_abs": diag[f"{window}_residual_mass_abs"],
                "observed_mass_abs": diag[f"{window}_observed_mass_abs"],
            })
    residual_localization = pd.DataFrame(residual_rows)

    # Determine winner with a preference for global score first, then edge capture.
    targeted = comparison[comparison["model_name"].isin(["targeted_constrained_two_component", "targeted_central_edge"])]
    targeted = targeted.copy()
    targeted["decision_score"] = targeted["r2"].astype(float) + 0.20 * targeted["edge_capture_ratio"].astype(float).fillna(0.0)
    best_row = targeted.sort_values(["decision_score", "r2", "edge_capture_ratio"], ascending=False).iloc[0]
    best_model = str(best_row["model_name"])

    prior_two_r2 = np.nan
    if "two_component_prediction" in profile.columns:
        prior_two_r2 = safe_r2(rho, profile["two_component_prediction"].to_numpy(dtype=float))
    gain_over_prior_two = float(best_row["r2"] - prior_two_r2) if np.isfinite(prior_two_r2) else float("nan")

    if best_model == "targeted_central_edge" and best_row["edge_capture_ratio"] > result_A.edge_capture_ratio:
        scientific_verdict = "boundary_loaded_edge_mode_preferred"
    elif best_model == "targeted_constrained_two_component":
        scientific_verdict = "constrained_bimodal_geometry_preferred"
    else:
        scientific_verdict = "targeted_models_partial_or_inconclusive"

    if np.isfinite(gain_over_prior_two) and gain_over_prior_two < 0.02 and float(best_row["edge_capture_ratio"]) < 0.20:
        strategic_next = "weak_gain_recommend_upstream_rho_kappa_or_operator_reentry"
    elif scientific_verdict == "boundary_loaded_edge_mode_preferred":
        strategic_next = "develop_boundary_sector_template_and_compare_to_stage6J_6K_separable_kernel"
    elif scientific_verdict == "constrained_bimodal_geometry_preferred":
        strategic_next = "canonicalize_two_lobe_modal_law_and_test_family_separation"
    else:
        strategic_next = "inspect_residuals_and_family_separated_recovery_before_stage6N"

    summary = {
        "script_version": "Stage-6M_targeted_modal_resolution_v2c.py",
        "project_root": str(root),
        "output_dir": str(out_dir),
        "input_profile_rows": int(len(profile)),
        "scipy_available": SCIPY_AVAILABLE,
        "upstream_script_version": upstream_summary.get("script_version", "unknown"),
        "upstream_baseline_two_component_r2": prior_two_r2,
        "targeted_results": {
            "constrained_two_component": asdict(result_A),
            "central_edge": asdict(result_B),
            "unconstrained_refit": asdict(result_U),
        },
        "best_targeted_model": best_model,
        "gain_over_upstream_two_component_r2": gain_over_prior_two,
        "scientific_verdict": scientific_verdict,
        "strategic_next": strategic_next,
        "negative_branch_status": {
            "higher_derivatives": "provisionally_pruned_as_primary_driver; retain only as optional residual diagnostics",
            "fractional_terms": "provisionally_pruned_as_primary_driver; retain only if future evidence changes",
        },
        "interpretation": {
            "core_question": "Is the left-edge spike a true early-s lobe or a boundary-loaded sector?",
            "decision_rule": "Prefer model with high global R2 and improved edge capture; do not revive derivative/fractional ontology for tiny gains.",
        },
    }

    # Write outputs.
    profile_path = out_dir / "stage6M_targeted_v2c_profile.csv"
    comparison_path = out_dir / "stage6M_targeted_v2c_model_comparison.csv"
    residual_path = out_dir / "stage6M_targeted_v2c_residual_localization.csv"
    summary_path = out_dir / "stage6M_targeted_v2c_summary.json"
    notes_path = out_dir / "stage6M_targeted_v2c_notes.txt"

    profile.to_csv(profile_path, index=False)
    comparison.to_csv(comparison_path, index=False)
    residual_localization.to_csv(residual_path, index=False)
    with open(summary_path, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)

    notes = f"""
============================================================
STAGE-6M TARGETED v2c NOTES
Project: Quantum-Emergent Gravity
Build Date: 2026-04-23
============================================================

PURPOSE
-------
This targeted substage tests whether the remaining Stage-6M mismatch in rho(s)
is better explained by constrained bimodal geometry or by a left-boundary-loaded
edge sector. It runs both tests in one script.

UPSTREAM CARRIED CONCLUSION
---------------------------
Stage-6M v2b improved over the one-component anchor, but both unconstrained
lobes migrated centrally and the left-edge spike remained insufficiently
captured. Derivative and fractional gains were tiny, so those branches remain
optional diagnostics rather than the primary ontology.

METHOD A: CONSTRAINED TWO-COMPONENT FIT
---------------------------------------
Model:
    rho(s) ~ baseline + A_left G(s; mu_left, sigma_left)
                    + A_center G(s; mu_center, sigma_center)

Constraint:
    mu_left   in early-s window [0.000, 0.250]
    mu_center in central window [0.250, 0.750]

Result:
    R2              = {result_A.r2:.6f}
    corr            = {result_A.corr:.6f}
    RMSE            = {result_A.rmse:.6f}
    edge_capture    = {result_A.edge_capture_ratio:.6f}
    verdict         = {result_A.verdict}
    parameters      = {json.dumps(params_A, indent=2)}

METHOD B: CENTRAL + EDGE DECOMPOSITION
--------------------------------------
Model:
    rho(s) ~ baseline + A_edge E_left(s; scale)
                    + A_center G(s; mu_center, sigma_center)

Where E_left is selected among explicit left-boundary-loaded templates:
left_exponential, left_half_gaussian, left_rational, left_linear_cutoff.

Result:
    R2              = {result_B.r2:.6f}
    corr            = {result_B.corr:.6f}
    RMSE            = {result_B.rmse:.6f}
    edge_capture    = {result_B.edge_capture_ratio:.6f}
    verdict         = {result_B.verdict}
    parameters      = {json.dumps(params_B, indent=2)}

REFERENCE UNCONSTRAINED REFIT
-----------------------------
This is not the preferred ontology; it is included only to compare targeted
constraints against an unconstrained two-Gaussian reference.

    R2              = {result_U.r2:.6f}
    corr            = {result_U.corr:.6f}
    RMSE            = {result_U.rmse:.6f}
    edge_capture    = {result_U.edge_capture_ratio:.6f}

DECISION
--------
Best targeted model:
    {best_model}

Scientific verdict:
    {scientific_verdict}

Gain over upstream two-component R2:
    {gain_over_prior_two:.6f}

Strategic next:
    {strategic_next}

INTERPRETIVE NOTE
-----------------
The dominant issue remains modal geometry, not missing derivative order.
If targeted geometry and edge decomposition both fail to improve the left-edge
residual materially, the next decision should be upstream: revisit rho/kappa
normalization, recover family-separated structure, or re-enter the separable
Stage-6J/6K operator language.

============================================================
END STAGE-6M TARGETED v2c NOTES
============================================================
""".strip() + "\n"
    with open(notes_path, "w", encoding="utf-8") as f:
        f.write(notes)

    # Figures.
    if MPL_AVAILABLE:
        fig_path = out_dir / "stage6M_targeted_v2c_fit_comparison.png"
        plt.figure(figsize=(10, 6))
        plt.plot(s, rho, marker="o", linewidth=1.5, label="rho observed")
        if "two_component_prediction" in profile.columns:
            plt.plot(s, profile["two_component_prediction"], linewidth=1.2, label="prior two-component")
        plt.plot(s, pred_A, linewidth=1.6, label="targeted constrained two-component")
        plt.plot(s, pred_B, linewidth=1.6, label="targeted central+edge")
        plt.xlabel("intrinsic coordinate s")
        plt.ylabel("rho")
        plt.title("Stage-6M targeted v2c: fit comparison")
        plt.legend()
        plt.tight_layout()
        plt.savefig(fig_path, dpi=180)
        plt.close()

        res_fig_path = out_dir / "stage6M_targeted_v2c_residuals.png"
        plt.figure(figsize=(10, 6))
        plt.axhline(0, linewidth=1)
        plt.plot(s, rho - pred_A, marker="o", linewidth=1.4, label="residual: constrained two-component")
        plt.plot(s, rho - pred_B, marker="o", linewidth=1.4, label="residual: central+edge")
        plt.axvspan(float(np.min(s)), 0.25, alpha=0.10, label="edge window")
        plt.xlabel("intrinsic coordinate s")
        plt.ylabel("rho - prediction")
        plt.title("Stage-6M targeted v2c: residual localization")
        plt.legend()
        plt.tight_layout()
        plt.savefig(res_fig_path, dpi=180)
        plt.close()
        echo(f"[Stage-6M v2c OUTPUT] Figure: {fig_path}")
        echo(f"[Stage-6M v2c OUTPUT] Figure: {res_fig_path}")

    echo(f"[Stage-6M v2c OUTPUT] Profile   : {profile_path}")
    echo(f"[Stage-6M v2c OUTPUT] Compare   : {comparison_path}")
    echo(f"[Stage-6M v2c OUTPUT] Residuals : {residual_path}")
    echo(f"[Stage-6M v2c OUTPUT] Summary   : {summary_path}")
    echo(f"[Stage-6M v2c OUTPUT] Notes     : {notes_path}")

    banner("Stage-6M-targeted-v2c completed")
    echo(f"Best targeted model : {best_model}")
    echo(f"Scientific verdict  : {scientific_verdict}")
    echo(f"Strategic next      : {strategic_next}")


if __name__ == "__main__":
    main()
