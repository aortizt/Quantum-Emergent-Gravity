# -*- coding: utf-8 -*-
"""
========================================================================
Stage-6N: Canonical Two-Lobe Law / Family Persistence / Coordinate Robustness
========================================================================
Project : Quantum-Emergent Gravity
Author  : Arturo Ortiz-Tapia
Build   : 2026-04-24
Script  : Stage-6N_canonical_two_lobe_law_v1a.py

Purpose
-------
Stage-6M targeted v2c produced the decisive verdict:

    constrained_bimodal_geometry_preferred

The preferred model found one genuine early-s lobe and one genuine central
lobe in rho(s). Stage-6N now asks whether that two-lobe law is intrinsic:

1) Does it persist under family separation, if family labels are available?
2) Does it persist under monotone coordinate changes?
3) Is a simpler canonical parametric law adequate?
4) Which robust dimensionless outputs should be logged against the
   cosmology comparison panel, cautiously and without claims?

This script is intentionally conservative. It does not declare cosmological
identification. It only records numerical proximity of robust modal quantities
to a fixed reference panel.

Expected project root
---------------------
/home/dakini/Downloads/010-Quantum_Emergent_Gravity

Primary upstream inputs
-----------------------
metric_stage_6M_outputs/stage6M_targeted_v2c_profile.csv
metric_stage_6M_outputs/stage6M_targeted_v2c_model_comparison.csv
metric_stage_6M_outputs/stage6M_targeted_v2c_summary.json
metric_stage_6M_outputs/stage6M_targeted_v2c_residual_localization.csv

Outputs
-------
metric_stage_6N_outputs/stage6N_canonical_two_lobe_profile.csv
metric_stage_6N_outputs/stage6N_model_comparison.csv
metric_stage_6N_outputs/stage6N_family_persistence_table.csv
metric_stage_6N_outputs/stage6N_coordinate_robustness_table.csv
metric_stage_6N_outputs/stage6N_canonical_parameter_table.csv
metric_stage_6N_outputs/stage6N_cosmology_panel_comparison.csv
metric_stage_6N_outputs/stage6N_summary.json
metric_stage_6N_outputs/stage6N_notes.txt

Run in Spyder
-------------
%runfile /home/dakini/Downloads/010-Quantum_Emergent_Gravity/metric_stage_6N_scripts/Stage-6N_canonical_two_lobe_law_v1a.py --wdir
"""

from __future__ import annotations

import json
import math
import os
import sys
import glob
from pathlib import Path
from typing import Dict, List, Tuple, Any, Optional

import numpy as np
import pandas as pd

try:
    from scipy.optimize import least_squares
    SCIPY_AVAILABLE = True
except Exception:
    SCIPY_AVAILABLE = False


# ---------------------------------------------------------------------
# Console helpers
# ---------------------------------------------------------------------
def line(ch: str = "=", n: int = 72) -> None:
    print(ch * n)


def echo(msg: str = "") -> None:
    print(msg)


def safe_float(x: Any, default: float = np.nan) -> float:
    try:
        return float(x)
    except Exception:
        return default


# ---------------------------------------------------------------------
# Project discovery
# ---------------------------------------------------------------------
def discover_project_root() -> Path:
    """Find the QEG project root, while remaining portable for testing."""
    candidates = [
        Path.cwd(),
        Path.cwd().parent,
        Path("/home/dakini/Downloads/010-Quantum_Emergent_Gravity"),
        Path("/mnt/data"),
    ]
    for c in candidates:
        if (c / "metric_stage_6M_outputs").exists():
            return c
        if (c / "stage6M_targeted_v2c_profile.csv").exists():
            return c
    return Path.cwd()


PROJECT_ROOT = discover_project_root()
OUT_DIR = PROJECT_ROOT / "metric_stage_6N_outputs"
SCRIPT_DIR = PROJECT_ROOT / "metric_stage_6N_scripts"
OUT_DIR.mkdir(parents=True, exist_ok=True)
try:
    SCRIPT_DIR.mkdir(parents=True, exist_ok=True)
except Exception:
    pass


# ---------------------------------------------------------------------
# Input resolution
# ---------------------------------------------------------------------
def first_existing(paths: List[Path]) -> Optional[Path]:
    for p in paths:
        if p.exists():
            return p
    return None


def resolve_input(name: str) -> Optional[Path]:
    paths = [
        PROJECT_ROOT / "metric_stage_6M_outputs" / name,
        PROJECT_ROOT / name,
        Path("/mnt/data") / name,
    ]
    return first_existing(paths)


PROFILE_PATH = resolve_input("stage6M_targeted_v2c_profile.csv")
MODEL_PATH = resolve_input("stage6M_targeted_v2c_model_comparison.csv")
SUMMARY_PATH = resolve_input("stage6M_targeted_v2c_summary.json")
RESID_PATH = resolve_input("stage6M_targeted_v2c_residual_localization.csv")


# ---------------------------------------------------------------------
# Basic numerical utilities
# ---------------------------------------------------------------------
def gaussian(x: np.ndarray, amp: float, mu: float, sigma: float) -> np.ndarray:
    sigma = max(float(sigma), 1e-8)
    return amp * np.exp(-0.5 * ((x - mu) / sigma) ** 2)


def skewed_gaussian(x: np.ndarray, amp: float, mu: float, sigma: float, skew: float) -> np.ndarray:
    """Mild skew template: Gaussian multiplied by a bounded linear tilt."""
    sigma = max(float(sigma), 1e-8)
    z = (x - mu) / sigma
    tilt = np.maximum(0.05, 1.0 + skew * z)
    return amp * np.exp(-0.5 * z ** 2) * tilt


def left_half_gaussian(x: np.ndarray, amp: float, scale: float) -> np.ndarray:
    scale = max(float(scale), 1e-8)
    return amp * np.exp(-0.5 * (x / scale) ** 2)


def left_exponential(x: np.ndarray, amp: float, scale: float) -> np.ndarray:
    scale = max(float(scale), 1e-8)
    return amp * np.exp(-x / scale)


def left_rational(x: np.ndarray, amp: float, scale: float) -> np.ndarray:
    scale = max(float(scale), 1e-8)
    return amp / (1.0 + (x / scale) ** 2)


def left_linear_cutoff(x: np.ndarray, amp: float, scale: float) -> np.ndarray:
    scale = max(float(scale), 1e-8)
    return amp * np.maximum(0.0, 1.0 - x / scale)


def r2_score(y: np.ndarray, yhat: np.ndarray) -> float:
    y = np.asarray(y, dtype=float)
    yhat = np.asarray(yhat, dtype=float)
    ss_res = float(np.sum((y - yhat) ** 2))
    ss_tot = float(np.sum((y - np.mean(y)) ** 2))
    if ss_tot <= 1e-15:
        return np.nan
    return 1.0 - ss_res / ss_tot


def corr_score(y: np.ndarray, yhat: np.ndarray) -> float:
    y = np.asarray(y, dtype=float)
    yhat = np.asarray(yhat, dtype=float)
    if len(y) < 3 or np.std(y) <= 1e-15 or np.std(yhat) <= 1e-15:
        return np.nan
    return float(np.corrcoef(y, yhat)[0, 1])


def rmse_score(y: np.ndarray, yhat: np.ndarray) -> float:
    return float(np.sqrt(np.mean((np.asarray(y) - np.asarray(yhat)) ** 2)))


def aic_like(y: np.ndarray, yhat: np.ndarray, n_params: int) -> float:
    n = len(y)
    rss = float(np.sum((y - yhat) ** 2))
    rss = max(rss, 1e-300)
    return float(n * np.log(rss / max(n, 1)) + 2 * n_params)


def mass_fraction(x: np.ndarray, y: np.ndarray, mask: np.ndarray) -> float:
    total = float(np.trapezoid(np.maximum(y, 0), x))
    if total <= 1e-15:
        return np.nan
    return float(np.trapezoid(np.maximum(y[mask], 0), x[mask]) / total)


def edge_capture(y: np.ndarray, yhat: np.ndarray, mask: np.ndarray) -> float:
    """One minus edge residual mass divided by observed edge mass."""
    denom = float(np.sum(np.abs(y[mask])))
    if denom <= 1e-15:
        return np.nan
    return 1.0 - float(np.sum(np.abs(y[mask] - yhat[mask]))) / denom


def component_integral(x: np.ndarray, comp: np.ndarray) -> float:
    return float(np.trapezoid(np.maximum(comp, 0.0), x))


def canonical_metrics(x: np.ndarray, y: np.ndarray, yhat: np.ndarray, params: Dict[str, float], n_params: int) -> Dict[str, Any]:
    early_mask = x <= 0.25
    central_mask = (x > 0.25) & (x <= 0.75)
    right_mask = x > 0.75
    return {
        "r2": r2_score(y, yhat),
        "corr": corr_score(y, yhat),
        "rmse": rmse_score(y, yhat),
        "aic_like": aic_like(y, yhat, n_params),
        "edge_capture_ratio": edge_capture(y, yhat, early_mask),
        "edge_rmse": rmse_score(y[early_mask], yhat[early_mask]) if early_mask.sum() else np.nan,
        "central_rmse": rmse_score(y[central_mask], yhat[central_mask]) if central_mask.sum() else np.nan,
        "right_rmse": rmse_score(y[right_mask], yhat[right_mask]) if right_mask.sum() else np.nan,
        "params": params,
    }


# ---------------------------------------------------------------------
# Coordinate maps
# ---------------------------------------------------------------------
def normalize01(v: np.ndarray) -> np.ndarray:
    v = np.asarray(v, dtype=float)
    lo = float(np.min(v))
    hi = float(np.max(v))
    if hi - lo <= 1e-15:
        return np.zeros_like(v)
    return (v - lo) / (hi - lo)


def coordinate_variants(s: np.ndarray, rho: np.ndarray) -> Dict[str, np.ndarray]:
    """Return monotone coordinate charts on [0,1]."""
    s = normalize01(np.asarray(s, dtype=float))
    n = len(s)
    ranks = np.argsort(np.argsort(s)).astype(float)
    rank_u = ranks / max(n - 1, 1)

    eps = 1e-4
    logit = np.log((s + eps) / (1.0 - s + eps))
    logit_u = normalize01(logit)

    # Arc-length coordinate of the observed profile: a monotone remap that
    # weights changes in rho as geometric path length in (s,rho)-space.
    ds = np.diff(s)
    dr = np.diff(np.asarray(rho, dtype=float))
    seg = np.sqrt(ds * ds + dr * dr)
    arc = np.concatenate([[0.0], np.cumsum(seg)])
    arc_u = normalize01(arc)

    # Cumulative mass coordinate: useful as a conservative monotone chart.
    y_pos = np.maximum(rho, 0.0)
    cum = np.concatenate([[0.0], np.cumsum(0.5 * (y_pos[1:] + y_pos[:-1]) * np.maximum(ds, 0))])
    mass_u = normalize01(cum)

    return {
        "original_s": s,
        "rank_uniformized_s": rank_u,
        "logit_stretched_s": logit_u,
        "arc_length_s": arc_u,
        "cumulative_mass_s": mass_u,
    }


# ---------------------------------------------------------------------
# Model fitting functions
# ---------------------------------------------------------------------
def initial_two_lobe_guess(x: np.ndarray, y: np.ndarray) -> np.ndarray:
    early = x <= 0.25
    central = (x > 0.25) & (x <= 0.75)
    baseline = max(float(np.percentile(y, 5)), 0.0)
    if early.any():
        i_e = np.argmax(y[early])
        mu_e = float(x[early][i_e])
        amp_e = max(float(y[early][i_e] - baseline), 1e-5)
    else:
        mu_e, amp_e = 0.05, max(float(np.max(y) - baseline), 1e-5)
    if central.any():
        i_c = np.argmax(y[central])
        mu_c = float(x[central][i_c])
        amp_c = max(float(y[central][i_c] - baseline), 1e-5)
    else:
        mu_c, amp_c = 0.50, max(float(np.max(y) - baseline), 1e-5)
    return np.array([amp_e, mu_e, 0.035, amp_c, mu_c, 0.075, baseline], dtype=float)


def fit_constrained_two_gaussian(x: np.ndarray, y: np.ndarray) -> Dict[str, Any]:
    """Two Gaussian lobes with early and central windows imposed."""
    p0 = initial_two_lobe_guess(x, y)
    y_max = max(float(np.max(y)), 1e-5)
    upper_amp = max(3.0 * y_max, 1e-3)
    lo = np.array([0.0, 0.000, 0.003, 0.0, 0.250, 0.005, 0.0])
    hi = np.array([upper_amp, 0.250, 0.150, upper_amp, 0.750, 0.250, y_max])
    p0 = np.minimum(np.maximum(p0, lo + 1e-8), hi - 1e-8)

    def pred(p: np.ndarray) -> np.ndarray:
        return (p[6]
                + gaussian(x, p[0], p[1], p[2])
                + gaussian(x, p[3], p[4], p[5]))

    if SCIPY_AVAILABLE:
        res = least_squares(lambda p: pred(p) - y, p0, bounds=(lo, hi), max_nfev=40000)
        p = res.x
        success = bool(res.success)
        cost = float(res.cost)
    else:
        # Fallback: use the initialization if scipy is unavailable.
        p = p0
        success = False
        cost = float(np.sum((pred(p) - y) ** 2))

    yhat = pred(p)
    early_comp = gaussian(x, p[0], p[1], p[2])
    central_comp = gaussian(x, p[3], p[4], p[5])
    params = {
        "amp_early": float(p[0]),
        "mu_early": float(p[1]),
        "sigma_early": float(p[2]),
        "amp_central": float(p[3]),
        "mu_central": float(p[4]),
        "sigma_central": float(p[5]),
        "baseline": float(p[6]),
        "optimizer_success": float(success),
        "optimizer_cost": cost,
    }
    out = canonical_metrics(x, y, yhat, params, 7)
    out.update({
        "model_name": "constrained_two_gaussian",
        "prediction": yhat,
        "early_component": early_comp,
        "central_component": central_comp,
        "residual": y - yhat,
    })
    return out


def fit_boundary_edge_plus_gaussian(x: np.ndarray, y: np.ndarray, edge_kind: str) -> Dict[str, Any]:
    """Central Gaussian plus one explicit left-boundary-loaded template."""
    y_max = max(float(np.max(y)), 1e-5)
    baseline0 = max(float(np.percentile(y, 5)), 0.0)
    early = x <= 0.25
    central = (x > 0.25) & (x <= 0.75)
    amp_edge0 = max(float(np.max(y[early]) - baseline0), 1e-5) if early.any() else y_max / 2
    mu0 = float(x[central][np.argmax(y[central])]) if central.any() else 0.5
    amp_c0 = max(float(np.max(y[central]) - baseline0), 1e-5) if central.any() else y_max
    p0 = np.array([amp_edge0, 0.05, amp_c0, mu0, 0.075, baseline0])
    lo = np.array([0.0, 0.003, 0.0, 0.250, 0.005, 0.0])
    hi = np.array([3*y_max, 0.300, 3*y_max, 0.750, 0.250, y_max])
    p0 = np.minimum(np.maximum(p0, lo + 1e-8), hi - 1e-8)

    edge_map = {
        "left_exponential": left_exponential,
        "left_half_gaussian": left_half_gaussian,
        "left_rational": left_rational,
        "left_linear_cutoff": left_linear_cutoff,
    }
    edge_fun = edge_map[edge_kind]

    def pred(p: np.ndarray) -> np.ndarray:
        return p[5] + edge_fun(x, p[0], p[1]) + gaussian(x, p[2], p[3], p[4])

    if SCIPY_AVAILABLE:
        res = least_squares(lambda p: pred(p) - y, p0, bounds=(lo, hi), max_nfev=40000)
        p = res.x
        success = bool(res.success)
        cost = float(res.cost)
    else:
        p = p0
        success = False
        cost = float(np.sum((pred(p) - y) ** 2))

    yhat = pred(p)
    edge_comp = edge_fun(x, p[0], p[1])
    central_comp = gaussian(x, p[2], p[3], p[4])
    params = {
        "edge_kind": edge_kind,
        "amp_edge": float(p[0]),
        "edge_scale": float(p[1]),
        "amp_central": float(p[2]),
        "mu_central": float(p[3]),
        "sigma_central": float(p[4]),
        "baseline": float(p[5]),
        "optimizer_success": float(success),
        "optimizer_cost": cost,
    }
    out = canonical_metrics(x, y, yhat, params, 6)
    out.update({
        "model_name": "central_plus_" + edge_kind,
        "prediction": yhat,
        "early_component": edge_comp,
        "central_component": central_comp,
        "residual": y - yhat,
    })
    return out


def fit_skewed_two_lobe(x: np.ndarray, y: np.ndarray) -> Dict[str, Any]:
    """A simple canonical ansatz: early Gaussian plus skewed central bump."""
    p0_base = initial_two_lobe_guess(x, y)
    p0 = np.array([p0_base[0], p0_base[1], p0_base[2], p0_base[3], p0_base[4], p0_base[5], 0.0, p0_base[6]])
    y_max = max(float(np.max(y)), 1e-5)
    lo = np.array([0.0, 0.000, 0.003, 0.0, 0.250, 0.005, -2.0, 0.0])
    hi = np.array([3*y_max, 0.250, 0.150, 3*y_max, 0.750, 0.250, 2.0, y_max])
    p0 = np.minimum(np.maximum(p0, lo + 1e-8), hi - 1e-8)

    def pred(p: np.ndarray) -> np.ndarray:
        return (p[7]
                + gaussian(x, p[0], p[1], p[2])
                + skewed_gaussian(x, p[3], p[4], p[5], p[6]))

    if SCIPY_AVAILABLE:
        res = least_squares(lambda p: pred(p) - y, p0, bounds=(lo, hi), max_nfev=40000)
        p = res.x
        success = bool(res.success)
        cost = float(res.cost)
    else:
        p = p0
        success = False
        cost = float(np.sum((pred(p) - y) ** 2))

    yhat = pred(p)
    early_comp = gaussian(x, p[0], p[1], p[2])
    central_comp = skewed_gaussian(x, p[3], p[4], p[5], p[6])
    params = {
        "amp_early": float(p[0]), "mu_early": float(p[1]), "sigma_early": float(p[2]),
        "amp_central": float(p[3]), "mu_central": float(p[4]), "sigma_central": float(p[5]),
        "central_skew": float(p[6]), "baseline": float(p[7]),
        "optimizer_success": float(success), "optimizer_cost": cost,
    }
    out = canonical_metrics(x, y, yhat, params, 8)
    out.update({"model_name": "early_gaussian_plus_skewed_central", "prediction": yhat,
                "early_component": early_comp, "central_component": central_comp, "residual": y-yhat})
    return out


def run_canonical_model_suite(x: np.ndarray, y: np.ndarray) -> List[Dict[str, Any]]:
    models = [fit_constrained_two_gaussian(x, y)]
    for kind in ["left_exponential", "left_half_gaussian", "left_rational", "left_linear_cutoff"]:
        models.append(fit_boundary_edge_plus_gaussian(x, y, kind))
    models.append(fit_skewed_two_lobe(x, y))
    models.sort(key=lambda d: (-np.nan_to_num(d["r2"], nan=-999), np.nan_to_num(d["aic_like"], nan=999)))
    return models


# ---------------------------------------------------------------------
# Tables and summaries
# ---------------------------------------------------------------------
def flatten_params(params: Dict[str, Any]) -> Dict[str, Any]:
    out = {}
    for k, v in params.items():
        out[k] = v if isinstance(v, str) else safe_float(v)
    return out


def summarize_model(model: Dict[str, Any], group: str, coordinate_name: str = "original_s") -> Dict[str, Any]:
    row = {
        "group": group,
        "coordinate_name": coordinate_name,
        "model_name": model["model_name"],
        "r2": model["r2"],
        "corr": model["corr"],
        "rmse": model["rmse"],
        "aic_like": model["aic_like"],
        "edge_capture_ratio": model["edge_capture_ratio"],
        "edge_rmse": model["edge_rmse"],
        "central_rmse": model["central_rmse"],
        "right_rmse": model["right_rmse"],
    }
    row.update(flatten_params(model.get("params", {})))
    return row


def parameter_invariants(x: np.ndarray, model: Dict[str, Any], group: str, coordinate_name: str) -> Dict[str, Any]:
    p = model.get("params", {})
    early_comp = np.asarray(model.get("early_component", np.zeros_like(x)))
    central_comp = np.asarray(model.get("central_component", np.zeros_like(x)))
    m_e = component_integral(x, early_comp)
    m_c = component_integral(x, central_comp)
    total = m_e + m_c
    mu_e = safe_float(p.get("mu_early", 0.0 if "edge_kind" in p else np.nan))
    sig_e = safe_float(p.get("sigma_early", p.get("edge_scale", np.nan)))
    mu_c = safe_float(p.get("mu_central", np.nan))
    sig_c = safe_float(p.get("sigma_central", np.nan))
    return {
        "group": group,
        "coordinate_name": coordinate_name,
        "model_name": model["model_name"],
        "early_mass": m_e,
        "central_mass": m_c,
        "early_mass_fraction": m_e / total if total > 1e-15 else np.nan,
        "central_mass_fraction": m_c / total if total > 1e-15 else np.nan,
        "early_to_central_mass_ratio": m_e / m_c if m_c > 1e-15 else np.nan,
        "mu_early_or_edge": mu_e,
        "mu_central": mu_c,
        "center_separation": mu_c - mu_e if np.isfinite(mu_c) and np.isfinite(mu_e) else np.nan,
        "sigma_early_or_edge": sig_e,
        "sigma_central": sig_c,
        "width_ratio_early_to_central": sig_e / sig_c if np.isfinite(sig_e) and np.isfinite(sig_c) and sig_c > 1e-15 else np.nan,
        "r2": model["r2"],
        "edge_capture_ratio": model["edge_capture_ratio"],
    }


def compare_to_cosmology(invariant_rows: List[Dict[str, Any]]) -> pd.DataFrame:
    """Cautious dimensionless comparison panel. No physical claim is made.

    v1a bug fix: the v1 script filtered only for model_name ==
    'constrained_two_gaussian'. In the actual run the best pooled model was
    'early_gaussian_plus_skewed_central', so that filter removed every row and
    pandas crashed while sorting an empty table. This version accepts any fitted
    two-lobe model and returns a well-formed empty table when needed.
    """
    panel = {
        "Omega_b": 0.0493,
        "Omega_c": 0.265,
        "Omega_m": 0.315,
        "Omega_Lambda": 0.685,
        "Omega_b_over_Omega_m": 0.0493 / 0.315,
        "Omega_c_over_Omega_m": 0.265 / 0.315,
        "Omega_m_over_Omega_Lambda": 0.315 / 0.685,
        "sigma8": 0.811,
        "S8": 0.832,
        "h_Planck": 0.674,
        "h_SH0ES_reference": 0.730,
    }
    quantity_names = [
        "early_mass_fraction", "central_mass_fraction",
        "early_to_central_mass_ratio", "center_separation",
        "sigma_early_or_edge", "sigma_central", "width_ratio_early_to_central",
    ]
    columns = [
        "group", "coordinate_name", "model_name", "quantity", "value",
        "reference", "reference_value", "absolute_difference",
        "relative_difference", "interpretation_guardrail",
    ]
    rows = []
    for inv in invariant_rows:
        if inv.get("coordinate_name") != "original_s":
            continue
        model_name = str(inv.get("model_name", ""))
        if model_name in ("", "not_run", "not_run_too_few_rows"):
            continue
        for q in quantity_names:
            val = safe_float(inv.get(q))
            if not np.isfinite(val):
                continue
            for ref_name, ref_val in panel.items():
                rows.append({
                    "group": inv.get("group"),
                    "coordinate_name": inv.get("coordinate_name"),
                    "model_name": inv.get("model_name"),
                    "quantity": q,
                    "value": val,
                    "reference": ref_name,
                    "reference_value": ref_val,
                    "absolute_difference": abs(val - ref_val),
                    "relative_difference": abs(val - ref_val) / abs(ref_val) if abs(ref_val) > 1e-15 else np.nan,
                    "interpretation_guardrail": "exploratory_numeric_proximity_only_no_physical_claim",
                })
    table = pd.DataFrame(rows, columns=columns)
    if table.empty:
        return table
    return table.sort_values(["absolute_difference", "relative_difference"], na_position="last").reset_index(drop=True)
def determine_verdict(best_global: Dict[str, Any], family_rows: pd.DataFrame, coord_rows: pd.DataFrame) -> str:
    r2 = safe_float(best_global.get("r2"))
    edge = safe_float(best_global.get("edge_capture_ratio"))
    robust_coords = 0
    if not coord_rows.empty:
        robust_coords = int(((coord_rows["r2"] >= 0.90) & (coord_rows["edge_capture_ratio"] >= 0.80)).sum())
    family_available = (not family_rows.empty) and (family_rows["group"].nunique() > 1)
    if r2 >= 0.95 and edge >= 0.90 and robust_coords >= 3 and family_available:
        return "A: two_lobe_law_strong_and_family_coordinate_supported"
    if r2 >= 0.95 and edge >= 0.90 and robust_coords >= 3:
        return "B: two_lobe_law_strong_and_coordinate_robust_family_pending"
    if r2 >= 0.90 and edge >= 0.75:
        return "C: two_lobe_law_supported_but_persistence_incomplete"
    return "D: two_lobe_law_not_yet_canonical"


# ---------------------------------------------------------------------
# Main execution
# ---------------------------------------------------------------------
def main() -> None:
    line()
    echo("Stage-6N: Canonical Two-Lobe Law / Family Persistence / Coordinate Robustness")
    line()
    echo(f"[Stage-6N PRECHECK] Python executable: {sys.executable}")
    echo(f"[Stage-6N PRECHECK] scipy available   : {SCIPY_AVAILABLE}")
    echo(f"[Stage-6N PRECHECK] project root      : {PROJECT_ROOT}")
    echo(f"[Stage-6N PRECHECK] output dir        : {OUT_DIR}")
    echo(f"[Stage-6N PRECHECK] profile input     : {PROFILE_PATH}")
    echo(f"[Stage-6N PRECHECK] summary input     : {SUMMARY_PATH}")
    line("-")

    if PROFILE_PATH is None:
        raise FileNotFoundError("Could not find stage6M_targeted_v2c_profile.csv")

    df = pd.read_csv(PROFILE_PATH)
    required = ["s", "rho"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"Input profile missing required columns: {missing}")

    df = df.sort_values("s").reset_index(drop=True)
    s = normalize01(df["s"].to_numpy(dtype=float))
    rho = df["rho"].to_numpy(dtype=float)

    echo(f"[Stage-6N INPUT] rows: {len(df)}")
    echo(f"[Stage-6N INPUT] columns: {list(df.columns)}")
    echo("[Stage-6N CARRIED VERDICT] constrained_bimodal_geometry_preferred")
    line("-")

    # Global canonical model suite.
    echo("[Stage-6N GLOBAL] Fitting canonical two-lobe candidates on pooled profile...")
    global_models = run_canonical_model_suite(s, rho)
    best_global = global_models[0]
    echo(f"[Stage-6N GLOBAL] best model: {best_global['model_name']}")
    echo(f"[Stage-6N GLOBAL] R2={best_global['r2']:.6f}, corr={best_global['corr']:.6f}, "
         f"RMSE={best_global['rmse']:.6f}, edge_capture={best_global['edge_capture_ratio']:.6f}")
    line("-")

    # Coordinate robustness.
    echo("[Stage-6N COORDINATES] Testing monotone coordinate changes...")
    coord_rows = []
    coord_invariants = []
    coord_predictions = {}
    for cname, xvar in coordinate_variants(s, rho).items():
        idx = np.argsort(xvar)
        x_sorted = xvar[idx]
        y_sorted = rho[idx]
        # If duplicated coordinate values occur, add a tiny monotone jitter only for fitting.
        x_sorted = np.asarray(x_sorted, dtype=float)
        if np.any(np.diff(x_sorted) <= 0):
            x_sorted = normalize01(x_sorted + np.linspace(0, 1e-9, len(x_sorted)))
        models = run_canonical_model_suite(x_sorted, y_sorted)
        best = models[0]
        coord_rows.append(summarize_model(best, "pooled", cname))
        coord_invariants.append(parameter_invariants(x_sorted, best, "pooled", cname))
        # store prediction back in original row order where possible
        pred_unsorted = np.empty_like(y_sorted)
        pred_unsorted[idx.argsort()] = best["prediction"]
        coord_predictions[cname + "_best_prediction"] = pred_unsorted
        echo(f"  {cname:22s} best={best['model_name']:38s} R2={best['r2']:.6f} edge={best['edge_capture_ratio']:.6f}")
    coord_table = pd.DataFrame(coord_rows)
    line("-")

    # Family separation. If there is no family column, make a clear pending record.
    family_candidates = ["family", "fit_name", "FIT", "source_family", "dataset", "variant"]
    family_col = next((c for c in family_candidates if c in df.columns), None)
    family_rows = []
    family_invariants = []
    if family_col is None:
        echo("[Stage-6N FAMILY] No family label found in profile. Family separation marked pending.")
        family_rows.append({
            "group": "family_separation_pending_no_family_column",
            "coordinate_name": "original_s",
            "model_name": "not_run",
            "r2": np.nan,
            "corr": np.nan,
            "rmse": np.nan,
            "aic_like": np.nan,
            "edge_capture_ratio": np.nan,
            "note": "No family/fit_name/FIT/source_family/dataset/variant column found in Stage-6M targeted profile.",
        })
    else:
        echo(f"[Stage-6N FAMILY] Using family column: {family_col}")
        for fam, sub in df.groupby(family_col):
            if len(sub) < 12:
                family_rows.append({"group": str(fam), "coordinate_name": "original_s", "model_name": "not_run_too_few_rows", "r2": np.nan,
                                    "corr": np.nan, "rmse": np.nan, "aic_like": np.nan, "edge_capture_ratio": np.nan,
                                    "note": f"Only {len(sub)} rows available; too few for stable constrained fitting."})
                continue
            xf = normalize01(sub["s"].to_numpy(dtype=float))
            yf = sub["rho"].to_numpy(dtype=float)
            models = run_canonical_model_suite(xf, yf)
            best = models[0]
            family_rows.append(summarize_model(best, str(fam), "original_s"))
            family_invariants.append(parameter_invariants(xf, best, str(fam), "original_s"))
            echo(f"  {str(fam):16s} best={best['model_name']:38s} R2={best['r2']:.6f} edge={best['edge_capture_ratio']:.6f}")
    family_table = pd.DataFrame(family_rows)
    line("-")

    # Canonical parameter table for the best pooled original-s model plus coordinate variants.
    invariant_rows = [parameter_invariants(s, best_global, "pooled", "original_s")]
    invariant_rows.extend(coord_invariants)
    invariant_rows.extend(family_invariants)
    invariant_table = pd.DataFrame(invariant_rows)

    # Cosmology panel comparison.
    echo("[Stage-6N COSMOLOGY] Logging cautious dimensionless proximity panel...")
    cosmology_table = compare_to_cosmology(invariant_rows)
    if not cosmology_table.empty:
        top = cosmology_table.head(5)
        for _, row in top.iterrows():
            echo(f"  {row['quantity']}={row['value']:.6g} vs {row['reference']}={row['reference_value']:.6g}; "
                 f"abs diff={row['absolute_difference']:.6g}")
    else:
        echo("  No finite two-lobe invariants available for cosmology panel.")
    line("-")

    # Output full profile with best global components.
    profile_out = df.copy()
    profile_out["stage6N_best_global_prediction"] = best_global["prediction"]
    profile_out["stage6N_best_global_residual"] = best_global["residual"]
    profile_out["stage6N_best_global_early_component"] = best_global["early_component"]
    profile_out["stage6N_best_global_central_component"] = best_global["central_component"]
    for k, v in coord_predictions.items():
        profile_out["stage6N_" + k] = v

    model_rows = [summarize_model(m, "pooled", "original_s") for m in global_models]
    model_table = pd.DataFrame(model_rows)

    # Verdict.
    verdict = determine_verdict(best_global, family_table, coord_table)
    echo(f"[Stage-6N VERDICT] {verdict}")

    # Persist outputs.
    profile_file = OUT_DIR / "stage6N_canonical_two_lobe_profile.csv"
    model_file = OUT_DIR / "stage6N_model_comparison.csv"
    family_file = OUT_DIR / "stage6N_family_persistence_table.csv"
    coord_file = OUT_DIR / "stage6N_coordinate_robustness_table.csv"
    param_file = OUT_DIR / "stage6N_canonical_parameter_table.csv"
    cosmo_file = OUT_DIR / "stage6N_cosmology_panel_comparison.csv"
    summary_file = OUT_DIR / "stage6N_summary.json"
    notes_file = OUT_DIR / "stage6N_notes.txt"

    profile_out.to_csv(profile_file, index=False)
    model_table.to_csv(model_file, index=False)
    family_table.to_csv(family_file, index=False)
    coord_table.to_csv(coord_file, index=False)
    invariant_table.to_csv(param_file, index=False)
    cosmology_table.to_csv(cosmo_file, index=False)

    upstream_summary = {}
    if SUMMARY_PATH is not None and SUMMARY_PATH.exists():
        try:
            upstream_summary = json.loads(SUMMARY_PATH.read_text())
        except Exception:
            upstream_summary = {"warning": "Could not parse upstream summary JSON."}

    summary = {
        "script_version": "Stage-6N_canonical_two_lobe_law_v1a.py",
        "project_root": str(PROJECT_ROOT),
        "output_dir": str(OUT_DIR),
        "scipy_available": SCIPY_AVAILABLE,
        "input_profile": str(PROFILE_PATH),
        "input_rows": int(len(df)),
        "carried_stage6M_verdict": "constrained_bimodal_geometry_preferred",
        "best_global_model": summarize_model(best_global, "pooled", "original_s"),
        "best_global_invariants": parameter_invariants(s, best_global, "pooled", "original_s"),
        "coordinate_tests_run": int(len(coord_table)),
        "family_column": family_col,
        "family_separation_status": "run" if family_col is not None else "pending_no_family_column",
        "stage6N_verdict": verdict,
        "guardrail": "Cosmology panel is exploratory numeric proximity only; no physical identification claimed.",
        "upstream_stage6M_targeted_summary_excerpt": {
            "upstream_script_version": upstream_summary.get("script_version"),
            "upstream_baseline_two_component_r2": upstream_summary.get("upstream_baseline_two_component_r2"),
            "scientific_verdict": upstream_summary.get("scientific_verdict"),
            "strategic_next": upstream_summary.get("strategic_next"),
        },
        "outputs": {
            "profile": str(profile_file),
            "model_comparison": str(model_file),
            "family_persistence": str(family_file),
            "coordinate_robustness": str(coord_file),
            "canonical_parameters": str(param_file),
            "cosmology_panel": str(cosmo_file),
            "notes": str(notes_file),
        },
    }
    summary_file.write_text(json.dumps(summary, indent=2))

    notes = []
    notes.append("=" * 72)
    notes.append("STAGE-6N NOTES")
    notes.append("Project: Quantum-Emergent Gravity")
    notes.append("Build Date: 2026-04-24")
    notes.append("=" * 72)
    notes.append("")
    notes.append("CARRIED RESULT")
    notes.append("--------------")
    notes.append("Stage-6M targeted v2c verdict is recorded exactly as:")
    notes.append("")
    notes.append("    constrained_bimodal_geometry_preferred")
    notes.append("")
    notes.append("Stage-6N tests whether this two-lobe law is canonical rather than merely rescued.")
    notes.append("")
    notes.append("GLOBAL RESULT")
    notes.append("-------------")
    notes.append(f"Best pooled model: {best_global['model_name']}")
    notes.append(f"R2: {best_global['r2']:.6f}")
    notes.append(f"corr: {best_global['corr']:.6f}")
    notes.append(f"RMSE: {best_global['rmse']:.6f}")
    notes.append(f"edge_capture: {best_global['edge_capture_ratio']:.6f}")
    notes.append("")
    notes.append("BEST GLOBAL PARAMETERS")
    notes.append("----------------------")
    for k, v in best_global.get("params", {}).items():
        notes.append(f"{k}: {v}")
    notes.append("")
    notes.append("FAMILY SEPARATION")
    notes.append("-----------------")
    if family_col is None:
        notes.append("Not run: no family label column was present in the Stage-6M targeted profile.")
        notes.append("This is a pending input issue, not a mathematical disconfirmation.")
    else:
        notes.append(f"Run using family column: {family_col}")
    notes.append("")
    notes.append("COORDINATE ROBUSTNESS")
    notes.append("---------------------")
    for _, row in coord_table.iterrows():
        notes.append(f"{row['coordinate_name']}: model={row['model_name']}, R2={row['r2']:.6f}, edge={row['edge_capture_ratio']:.6f}")
    notes.append("")
    notes.append("COSMOLOGY GUARDRAIL")
    notes.append("-------------------")
    notes.append("All cosmology comparisons are exploratory dimensionless bookkeeping only.")
    notes.append("They are not claims of identification with matter, dark matter, dark energy, or Lambda.")
    notes.append("")
    notes.append("VERDICT")
    notes.append("-------")
    notes.append(verdict)
    notes.append("")
    notes.append("NEXT")
    notes.append("----")
    notes.append("If family-separated inputs become available, rerun Stage-6N before interpreting universality.")
    notes.append("If coordinate robustness remains strong, Stage-6O should move toward canonical law compression")
    notes.append("and controlled physical calibration, not unconstrained fitting.")
    notes.append("=" * 72)
    notes_file.write_text("\n".join(notes))

    echo("[Stage-6N OUTPUTS]")
    for p in [profile_file, model_file, family_file, coord_file, param_file, cosmo_file, summary_file, notes_file]:
        echo(f"  {p}")
    line()
    echo("Stage-6N complete.")
    line()


if __name__ == "__main__":
    main()
