#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
========================================================================
Stage-6P v6: Two-Lobe Universality Test on v5 Candidate
Project: Quantum-Emergent Gravity
Author: Arturo Ortiz-Tapia / ChatGPT assistant
Build date: 2026-05-02
========================================================================

Purpose
-------
Stage-6P v5 built the first non-degenerate family-preserving candidate
modal-rho object from explicit family lineage. Stage-6P v6 tests whether
that candidate supports the canonical early+central two-lobe law separately
for BARI, NUFIT, and VALENCIA.

This is an acceptance/rejection test for the v5 repair object.

Rules
-----
- No PDG injection.
- No Green-function machinery.
- No row-index family assignment.
- No smoothing of input profiles.
- No reconstruction of upstream rows.
- Uses only explicit family labels already present in v5 candidate files.
- Fits are diagnostic only: they test whether the v5 candidate has a
  two-lobe modal structure comparable to the frozen pooled Stage-6P reference.

Expected inputs
---------------
Primary v5 candidates:
  metric_stage_6P_outputs/family_preserving_profile_rebuild_v5/
      stage6P_v5_family_preserving_candidate_48bins.csv
      stage6P_v5_family_preserving_candidate_361bins.csv

Frozen canonical references:
  metric_stage_6P_outputs/canonical_modal_rho_selection_v1/
      stage6P_canonical_family_modal_rho_48bins.csv
      stage6P_canonical_family_modal_rho_361bins.csv

Outputs
-------
metric_stage_6P_outputs/two_lobe_universality_test_v6/
  stage6P_v6_family_two_lobe_fit_summary.csv
  stage6P_v6_family_lobe_parameters.csv
  stage6P_v6_candidate_vs_canonical_comparison.csv
  stage6P_v6_pairwise_family_parameter_distances.csv
  stage6P_v6_audit_summary.json
  stage6P_v6_audit_notes.txt
  stage6P_v6_48bins_family_fit_overlay.png
  stage6P_v6_361bins_family_fit_overlay.png

========================================================================
"""

from __future__ import annotations

import json
import math
import os
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd

try:
    import matplotlib.pyplot as plt
except Exception:
    plt = None

try:
    from scipy.optimize import curve_fit
    SCIPY_AVAILABLE = True
except Exception:
    curve_fit = None
    SCIPY_AVAILABLE = False


EXPECTED_FAMILIES = ["BARI", "NUFIT", "VALENCIA"]
EARLY_WINDOW = (0.0, 0.15)
CENTRAL_WINDOW = (0.35, 0.75)
CANONICAL_EARLY_MU = 0.035
CANONICAL_CENTRAL_MU = 0.500

# Acceptance thresholds are intentionally moderate because v5 is a repaired
# candidate object, not the exact original pooled Stage-6M/6N modal object.
MIN_R2_ACCEPT = 0.70
MIN_CORR_ACCEPT = 0.80
MAX_EARLY_MU_RANGE_ACCEPT = 0.08
MAX_CENTRAL_MU_RANGE_ACCEPT = 0.16
MAX_EARLY_MU_CANONICAL_DEVIATION = 0.12
MAX_CENTRAL_MU_CANONICAL_DEVIATION = 0.22
MIN_CANONICAL_ABS_CORR_ACCEPT = 0.70


@dataclass
class FitResult:
    family: str
    resolution: str
    n: int
    model: str
    status: str
    r2: float
    corr: float
    rmse: float
    a0: float
    a_early: float
    mu_early: float
    sigma_early: float
    a_central: float
    mu_central: float
    sigma_central: float
    early_mass_fraction: float
    central_mass_fraction: float
    early_peak_abs: float
    central_peak_abs: float
    edge_capture: float
    canonical_corr: float
    notes: str


def find_project_root(start: Path) -> Path:
    """Find project root by walking upward from current directory."""
    candidates = [start] + list(start.parents)
    for p in candidates:
        if (p / "metric_stage_6P_outputs").exists() or (p / "metric_stage_6O_outputs").exists():
            return p
    # Common absolute fallback used in this project.
    fallback = Path("/home/dakini/Downloads/010-Quantum_Emergent_Gravity")
    if fallback.exists():
        return fallback
    return start


def safe_float(x, default=np.nan) -> float:
    try:
        if x is None:
            return default
        v = float(x)
        if not np.isfinite(v):
            return default
        return v
    except Exception:
        return default


def norm_family_value(v: object) -> Optional[str]:
    s = str(v).strip().upper()
    if "BARI" in s:
        return "BARI"
    if "NUFIT" in s or "NU-FIT" in s or "NU_FIT" in s:
        return "NUFIT"
    if "VALENCIA" in s:
        return "VALENCIA"
    return None


def infer_columns(df: pd.DataFrame) -> Tuple[str, str, str]:
    lower = {c.lower(): c for c in df.columns}

    family_candidates = ["family", "fit_id", "fit", "family_col", "stage6p_family"]
    s_candidates = ["s", "s_norm", "s_normalized", "stage6p_s", "x", "coordinate"]
    y_candidates = ["rho", "rho_like", "y", "value", "profile", "holonomy_dev_mean", "stage6p_y"]

    fam = None
    for c in family_candidates:
        if c in lower:
            fam = lower[c]
            break
    if fam is None:
        for c in df.columns:
            vals = df[c].astype(str).str.upper().head(50).tolist()
            if any(any(f in v for f in EXPECTED_FAMILIES) for v in vals):
                fam = c
                break

    scol = None
    for c in s_candidates:
        if c in lower:
            scol = lower[c]
            break
    if scol is None:
        numeric = [c for c in df.columns if pd.api.types.is_numeric_dtype(df[c])]
        for c in numeric:
            vals = pd.to_numeric(df[c], errors="coerce")
            if vals.notna().sum() > 2 and vals.min() >= -1e-9 and vals.max() <= 1 + 1e-9:
                scol = c
                break
        if scol is None and numeric:
            scol = numeric[0]

    ycol = None
    for c in y_candidates:
        if c in lower and lower[c] != scol:
            ycol = lower[c]
            break
    if ycol is None:
        numeric = [c for c in df.columns if pd.api.types.is_numeric_dtype(df[c]) and c != scol]
        if numeric:
            # Pick numeric column with largest variance.
            variances = []
            for c in numeric:
                vals = pd.to_numeric(df[c], errors="coerce")
                variances.append((float(vals.var(skipna=True) or 0.0), c))
            variances.sort(reverse=True)
            ycol = variances[0][1]

    if fam is None or scol is None or ycol is None:
        raise ValueError(f"Could not infer family/s/y columns. Columns: {list(df.columns)}")
    return fam, scol, ycol


def load_profile(path: Path) -> Tuple[pd.DataFrame, Dict[str, str]]:
    df = pd.read_csv(path)
    fam_col, s_col, y_col = infer_columns(df)
    out = df[[fam_col, s_col, y_col]].copy()
    out.columns = ["family_raw", "s", "rho"]
    out["family"] = out["family_raw"].map(norm_family_value)
    out["s"] = pd.to_numeric(out["s"], errors="coerce")
    out["rho"] = pd.to_numeric(out["rho"], errors="coerce")
    out = out.dropna(subset=["family", "s", "rho"]).copy()
    out = out.sort_values(["family", "s"]).reset_index(drop=True)
    meta = {"family_col": fam_col, "s_col": s_col, "rho_col": y_col}
    return out, meta


def gaussian(x: np.ndarray, a: float, mu: float, sigma: float) -> np.ndarray:
    sigma = max(float(abs(sigma)), 1e-6)
    return a * np.exp(-0.5 * ((x - mu) / sigma) ** 2)


def two_gaussian(x, a0, ae, mue, se, ac, muc, sc):
    return a0 + gaussian(x, ae, mue, se) + gaussian(x, ac, muc, sc)


def fallback_two_lobe_fit(s: np.ndarray, y: np.ndarray) -> Tuple[np.ndarray, np.ndarray, str]:
    """Fallback non-iterative fit using window peaks and linear least squares amplitudes."""
    abs_y = np.abs(y)
    e_mask = (s >= EARLY_WINDOW[0]) & (s <= EARLY_WINDOW[1])
    c_mask = (s >= CENTRAL_WINDOW[0]) & (s <= CENTRAL_WINDOW[1])
    mue = float(s[e_mask][np.argmax(abs_y[e_mask])]) if e_mask.any() else CANONICAL_EARLY_MU
    muc = float(s[c_mask][np.argmax(abs_y[c_mask])]) if c_mask.any() else CANONICAL_CENTRAL_MU
    se = 0.035
    sc = 0.100
    ge = np.exp(-0.5 * ((s - mue) / se) ** 2)
    gc = np.exp(-0.5 * ((s - muc) / sc) ** 2)
    X = np.column_stack([np.ones_like(s), ge, gc])
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    p = np.array([beta[0], beta[1], mue, se, beta[2], muc, sc], dtype=float)
    yhat = two_gaussian(s, *p)
    return p, yhat, "fallback_window_peak_lstsq"


def fit_two_lobe(s: np.ndarray, y: np.ndarray) -> Tuple[np.ndarray, np.ndarray, str]:
    s = np.asarray(s, dtype=float)
    y = np.asarray(y, dtype=float)
    order = np.argsort(s)
    s = s[order]
    y = y[order]

    if len(s) < 7 or np.nanstd(y) <= 1e-12:
        return fallback_two_lobe_fit(s, y)

    abs_y = np.abs(y)
    e_mask = (s >= EARLY_WINDOW[0]) & (s <= EARLY_WINDOW[1])
    c_mask = (s >= CENTRAL_WINDOW[0]) & (s <= CENTRAL_WINDOW[1])
    mue0 = float(s[e_mask][np.argmax(abs_y[e_mask])]) if e_mask.any() else CANONICAL_EARLY_MU
    muc0 = float(s[c_mask][np.argmax(abs_y[c_mask])]) if c_mask.any() else CANONICAL_CENTRAL_MU
    ae0 = float(y[e_mask][np.argmax(abs_y[e_mask])]) if e_mask.any() else float(np.nanmax(y))
    ac0 = float(y[c_mask][np.argmax(abs_y[c_mask])]) if c_mask.any() else float(np.nanmax(y))
    a00 = float(np.nanmedian(y))
    yscale = max(float(np.nanmax(np.abs(y))), 1.0)

    p0 = np.array([a00, ae0, mue0, 0.035, ac0, muc0, 0.10], dtype=float)
    lo = np.array([-5 * yscale, -10 * yscale, EARLY_WINDOW[0], 0.005, -10 * yscale, CENTRAL_WINDOW[0], 0.015])
    hi = np.array([ 5 * yscale,  10 * yscale, EARLY_WINDOW[1], 0.120,  10 * yscale, CENTRAL_WINDOW[1], 0.250])

    if SCIPY_AVAILABLE:
        try:
            popt, _ = curve_fit(
                two_gaussian,
                s,
                y,
                p0=np.clip(p0, lo + 1e-9, hi - 1e-9),
                bounds=(lo, hi),
                maxfev=50000,
            )
            return popt, two_gaussian(s, *popt), "bounded_two_gaussian_curve_fit"
        except Exception:
            pass
    return fallback_two_lobe_fit(s, y)


def metrics(y: np.ndarray, yhat: np.ndarray) -> Tuple[float, float, float]:
    y = np.asarray(y, dtype=float)
    yhat = np.asarray(yhat, dtype=float)
    resid = y - yhat
    rmse = float(np.sqrt(np.nanmean(resid ** 2)))
    ss_res = float(np.nansum(resid ** 2))
    ss_tot = float(np.nansum((y - np.nanmean(y)) ** 2))
    r2 = float(1.0 - ss_res / ss_tot) if ss_tot > 1e-15 else np.nan
    if np.nanstd(y) > 1e-15 and np.nanstd(yhat) > 1e-15:
        corr = float(np.corrcoef(y, yhat)[0, 1])
    else:
        corr = np.nan
    return r2, corr, rmse


def trapezoid_abs(s: np.ndarray, y: np.ndarray) -> float:
    if len(s) <= 1:
        return float(np.nansum(np.abs(y)))
    return float(np.trapezoid(np.abs(y), s))


def window_mass_fraction(s: np.ndarray, y: np.ndarray, window: Tuple[float, float]) -> float:
    total = trapezoid_abs(s, y)
    if total <= 1e-15:
        return np.nan
    mask = (s >= window[0]) & (s <= window[1])
    if not mask.any():
        return 0.0
    return float(trapezoid_abs(s[mask], y[mask]) / total)


def window_peak_abs(s: np.ndarray, y: np.ndarray, window: Tuple[float, float]) -> float:
    mask = (s >= window[0]) & (s <= window[1])
    if not mask.any():
        return np.nan
    return float(np.nanmax(np.abs(y[mask])))


def canonical_corr_for_family(s: np.ndarray, y: np.ndarray, canon_df: Optional[pd.DataFrame], family: str) -> float:
    if canon_df is None or canon_df.empty:
        return np.nan
    c = canon_df[canon_df["family"] == family].sort_values("s")
    if c.empty:
        # The canonical profiles are often duplicated across families. Use pooled mean if needed.
        c = canon_df.groupby("s", as_index=False)["rho"].mean().sort_values("s")
    if len(c) < 2:
        return np.nan
    cy = np.interp(s, c["s"].to_numpy(float), c["rho"].to_numpy(float))
    if np.nanstd(y) <= 1e-15 or np.nanstd(cy) <= 1e-15:
        return np.nan
    return float(np.corrcoef(y, cy)[0, 1])


def classify_family_fit(fr: FitResult) -> str:
    if not np.isfinite(fr.r2) or not np.isfinite(fr.corr):
        return "FIT_FAILED_OR_CONSTANT"
    early_ok = EARLY_WINDOW[0] <= fr.mu_early <= EARLY_WINDOW[1]
    central_ok = CENTRAL_WINDOW[0] <= fr.mu_central <= CENTRAL_WINDOW[1]
    quality_ok = fr.r2 >= MIN_R2_ACCEPT and fr.corr >= MIN_CORR_ACCEPT
    canonical_ok = (
        abs(fr.mu_early - CANONICAL_EARLY_MU) <= MAX_EARLY_MU_CANONICAL_DEVIATION
        and abs(fr.mu_central - CANONICAL_CENTRAL_MU) <= MAX_CENTRAL_MU_CANONICAL_DEVIATION
    )
    lobe_visible = fr.early_peak_abs > 1e-9 and fr.central_peak_abs > 1e-9
    if quality_ok and early_ok and central_ok and canonical_ok and lobe_visible:
        return "TWO_LOBE_ACCEPTABLE"
    if quality_ok and early_ok and central_ok and lobe_visible:
        return "FIT_GOOD_BUT_CANONICAL_CENTER_DRIFT_REVIEW"
    if quality_ok:
        return "FIT_GOOD_BUT_LOBE_LOCATION_REVIEW"
    return "FIT_WEAK_OR_REVIEW_REQUIRED"


def run_resolution(candidate_path: Path, canonical_path: Optional[Path], resolution: str) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, Optional[pd.DataFrame], Dict[str, str]]:
    cand, cand_meta = load_profile(candidate_path)
    canon = None
    if canonical_path and canonical_path.exists():
        try:
            canon, _ = load_profile(canonical_path)
        except Exception:
            canon = None

    fit_rows: List[dict] = []
    param_rows: List[dict] = []
    plot_rows: List[dict] = []

    for fam in EXPECTED_FAMILIES:
        g = cand[cand["family"] == fam].sort_values("s")
        if g.empty:
            fit_rows.append({
                "resolution": resolution,
                "family": fam,
                "status": "MISSING_FAMILY",
                "n": 0,
            })
            continue

        s = g["s"].to_numpy(float)
        y = g["rho"].to_numpy(float)
        popt, yhat, model = fit_two_lobe(s, y)
        r2, corr, rmse = metrics(y, yhat)
        a0, ae, mue, se, ac, muc, sc = [safe_float(v) for v in popt]
        early_mf = window_mass_fraction(s, y, EARLY_WINDOW)
        central_mf = window_mass_fraction(s, y, CENTRAL_WINDOW)
        early_peak = window_peak_abs(s, y, EARLY_WINDOW)
        central_peak = window_peak_abs(s, y, CENTRAL_WINDOW)
        # Edge capture: fraction of early-window absolute mass explained by fit in early window.
        e_mask = (s >= EARLY_WINDOW[0]) & (s <= EARLY_WINDOW[1])
        if e_mask.any():
            den = trapezoid_abs(s[e_mask], y[e_mask])
            num = trapezoid_abs(s[e_mask], yhat[e_mask])
            edge_capture = float(min(num / den, den / num)) if den > 1e-15 and num > 1e-15 else np.nan
        else:
            edge_capture = np.nan
        ccorr = canonical_corr_for_family(s, y, canon, fam)

        fr = FitResult(
            family=fam,
            resolution=resolution,
            n=len(g),
            model=model,
            status="",
            r2=r2,
            corr=corr,
            rmse=rmse,
            a0=a0,
            a_early=ae,
            mu_early=mue,
            sigma_early=se,
            a_central=ac,
            mu_central=muc,
            sigma_central=sc,
            early_mass_fraction=early_mf,
            central_mass_fraction=central_mf,
            early_peak_abs=early_peak,
            central_peak_abs=central_peak,
            edge_capture=edge_capture,
            canonical_corr=ccorr,
            notes="",
        )
        fr.status = classify_family_fit(fr)

        row = fr.__dict__.copy()
        fit_rows.append(row)
        param_rows.append(row)

        for sx, yy, yh in zip(s, y, yhat):
            plot_rows.append({"resolution": resolution, "family": fam, "s": sx, "rho": yy, "rho_fit": yh})

    fit_df = pd.DataFrame(fit_rows)
    param_df = pd.DataFrame(param_rows)
    plot_df = pd.DataFrame(plot_rows)
    return fit_df, param_df, plot_df, canon, cand_meta


def summarize_consensus(fit_df: pd.DataFrame) -> Dict[str, object]:
    valid = fit_df[fit_df.get("n", 0) > 0].copy()
    out: Dict[str, object] = {}
    if valid.empty:
        out["consensus"] = "NO_USABLE_FAMILIES"
        return out

    for col in ["mu_early", "mu_central", "early_mass_fraction", "central_mass_fraction", "r2", "corr", "canonical_corr"]:
        if col in valid:
            vals = pd.to_numeric(valid[col], errors="coerce")
            out[f"{col}_min"] = safe_float(vals.min())
            out[f"{col}_max"] = safe_float(vals.max())
            out[f"{col}_range"] = safe_float(vals.max() - vals.min())
            out[f"{col}_mean"] = safe_float(vals.mean())

    statuses = valid["status"].astype(str).tolist() if "status" in valid else []
    all_acceptable = all(s == "TWO_LOBE_ACCEPTABLE" for s in statuses) and len(valid) == len(EXPECTED_FAMILIES)
    any_weak = any("WEAK" in s or "FAILED" in s or "MISSING" in s for s in statuses)

    mu_e_range = out.get("mu_early_range", np.nan)
    mu_c_range = out.get("mu_central_range", np.nan)
    stable_centers = (
        np.isfinite(mu_e_range) and mu_e_range <= MAX_EARLY_MU_RANGE_ACCEPT
        and np.isfinite(mu_c_range) and mu_c_range <= MAX_CENTRAL_MU_RANGE_ACCEPT
    )
    mean_canon = out.get("canonical_corr_mean", np.nan)
    canon_ok = np.isfinite(mean_canon) and abs(mean_canon) >= MIN_CANONICAL_ABS_CORR_ACCEPT

    if all_acceptable and stable_centers and canon_ok:
        consensus = "V5_REPAIR_ACCEPTED_FAMILY_TWO_LOBE_UNIVERSALITY_SUPPORTED"
    elif not any_weak and stable_centers:
        consensus = "V5_REPAIR_PROMISING_BUT_REVIEW_REQUIRED"
    elif any_weak:
        consensus = "V5_REPAIR_NOT_ACCEPTED_FAMILY_TWO_LOBE_WEAK_OR_INCOMPLETE"
    else:
        consensus = "V5_REPAIR_REVIEW_REQUIRED"
    out["consensus"] = consensus
    out["family_statuses"] = "; ".join([f"{r.family}:{r.status}" for r in valid.itertuples()])
    return out


def pairwise_parameter_distances(param_df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    cols = ["mu_early", "mu_central", "sigma_early", "sigma_central", "early_mass_fraction", "central_mass_fraction", "r2", "corr"]
    for res, g in param_df.groupby("resolution"):
        families = sorted(g["family"].unique())
        for i, f1 in enumerate(families):
            for f2 in families[i+1:]:
                a = g[g["family"] == f1].iloc[0]
                b = g[g["family"] == f2].iloc[0]
                row = {"resolution": res, "family_a": f1, "family_b": f2}
                sq = 0.0
                n = 0
                for c in cols:
                    da = safe_float(a.get(c))
                    db = safe_float(b.get(c))
                    d = abs(da - db) if np.isfinite(da) and np.isfinite(db) else np.nan
                    row[f"abs_delta_{c}"] = d
                    if np.isfinite(d):
                        sq += d * d
                        n += 1
                row["parameter_euclidean_distance"] = float(math.sqrt(sq)) if n else np.nan
                rows.append(row)
    return pd.DataFrame(rows)


def make_plot(plot_df: pd.DataFrame, out_path: Path, title: str) -> None:
    if plt is None or plot_df.empty:
        return
    fig, ax = plt.subplots(figsize=(10, 6))
    for fam in EXPECTED_FAMILIES:
        g = plot_df[plot_df["family"] == fam].sort_values("s")
        if g.empty:
            continue
        ax.plot(g["s"], g["rho"], linewidth=1.3, label=f"{fam} observed")
        ax.plot(g["s"], g["rho_fit"], linestyle="--", linewidth=1.0, label=f"{fam} fit")
    ax.axvspan(EARLY_WINDOW[0], EARLY_WINDOW[1], alpha=0.08)
    ax.axvspan(CENTRAL_WINDOW[0], CENTRAL_WINDOW[1], alpha=0.08)
    ax.set_title(title)
    ax.set_xlabel("s")
    ax.set_ylabel("candidate rho")
    ax.grid(True, alpha=0.25)
    ax.legend(fontsize=8, ncol=2)
    fig.tight_layout()
    fig.savefig(out_path, dpi=180)
    plt.close(fig)


def main() -> int:
    print("========================================================================")
    print("Stage-6P v6: Two-Lobe Universality Test on v5 Candidate")
    print("========================================================================")
    print(f"[Stage-6P v6] Python executable: {sys.executable}")
    cwd = Path.cwd()
    print(f"[Stage-6P v6] Working directory : {cwd}")
    print("[Stage-6P v6] Rule: test v5 candidate only; no PDG/Green functions/row-index family assignment.")

    project_root = find_project_root(cwd)
    out_dir = project_root / "metric_stage_6P_outputs" / "two_lobe_universality_test_v6"
    out_dir.mkdir(parents=True, exist_ok=True)
    print(f"[Stage-6P v6] Project root: {project_root}")
    print(f"[Stage-6P v6] Output dir  : {out_dir}")
    print(f"[Stage-6P v6] scipy available: {SCIPY_AVAILABLE}")

    v5_dir = project_root / "metric_stage_6P_outputs" / "family_preserving_profile_rebuild_v5"
    canon_dir = project_root / "metric_stage_6P_outputs" / "canonical_modal_rho_selection_v1"

    paths = {
        "48": {
            "candidate": v5_dir / "stage6P_v5_family_preserving_candidate_48bins.csv",
            "canonical": canon_dir / "stage6P_canonical_family_modal_rho_48bins.csv",
        },
        "361": {
            "candidate": v5_dir / "stage6P_v5_family_preserving_candidate_361bins.csv",
            "canonical": canon_dir / "stage6P_canonical_family_modal_rho_361bins.csv",
        },
    }

    missing = [str(v["candidate"]) for v in paths.values() if not v["candidate"].exists()]
    if missing:
        print("[Stage-6P v6] ERROR: missing required v5 candidate files:")
        for m in missing:
            print("  -", m)
        return 2

    all_fit = []
    all_params = []
    all_plot = []
    metadata = {}
    per_resolution_consensus = {}

    for res, p in paths.items():
        print(f"[Stage-6P v6] Testing resolution {res}: {p['candidate'].name}")
        fit_df, param_df, plot_df, canon_df, meta = run_resolution(p["candidate"], p["canonical"], res)
        all_fit.append(fit_df)
        all_params.append(param_df)
        all_plot.append(plot_df)
        metadata[res] = meta
        per_resolution_consensus[res] = summarize_consensus(fit_df)
        make_plot(plot_df, out_dir / f"stage6P_v6_{res}bins_family_fit_overlay.png", f"Stage-6P v6 family two-lobe fit ({res} bins)")

    fit_all = pd.concat(all_fit, ignore_index=True) if all_fit else pd.DataFrame()
    params_all = pd.concat(all_params, ignore_index=True) if all_params else pd.DataFrame()
    plot_all = pd.concat(all_plot, ignore_index=True) if all_plot else pd.DataFrame()
    pairwise = pairwise_parameter_distances(params_all) if not params_all.empty else pd.DataFrame()

    # Candidate vs canonical comparison table is a compact subset of family fit metrics.
    comparison_cols = [
        "resolution", "family", "r2", "corr", "canonical_corr", "mu_early", "mu_central",
        "early_mass_fraction", "central_mass_fraction", "status"
    ]
    comparison = fit_all[[c for c in comparison_cols if c in fit_all.columns]].copy()

    fit_csv = out_dir / "stage6P_v6_family_two_lobe_fit_summary.csv"
    params_csv = out_dir / "stage6P_v6_family_lobe_parameters.csv"
    comparison_csv = out_dir / "stage6P_v6_candidate_vs_canonical_comparison.csv"
    pairwise_csv = out_dir / "stage6P_v6_pairwise_family_parameter_distances.csv"
    fit_all.to_csv(fit_csv, index=False)
    params_all.to_csv(params_csv, index=False)
    comparison.to_csv(comparison_csv, index=False)
    pairwise.to_csv(pairwise_csv, index=False)

    # Overall verdict.
    cons = [v.get("consensus", "UNKNOWN") for v in per_resolution_consensus.values()]
    if all(c == "V5_REPAIR_ACCEPTED_FAMILY_TWO_LOBE_UNIVERSALITY_SUPPORTED" for c in cons):
        verdict = "V5_REPAIR_ACCEPTED_FAMILY_TWO_LOBE_UNIVERSALITY_SUPPORTED"
    elif any(c == "V5_REPAIR_ACCEPTED_FAMILY_TWO_LOBE_UNIVERSALITY_SUPPORTED" for c in cons) and not any("NOT_ACCEPTED" in c for c in cons):
        verdict = "V5_REPAIR_PARTIALLY_ACCEPTED_REVIEW_OTHER_RESOLUTION"
    elif any("PROMISING" in c for c in cons):
        verdict = "V5_REPAIR_PROMISING_BUT_REVIEW_REQUIRED"
    elif any("NOT_ACCEPTED" in c for c in cons):
        verdict = "V5_REPAIR_NOT_ACCEPTED_AS_CANONICAL_FAMILY_MODAL_RHO"
    else:
        verdict = "V5_REPAIR_REVIEW_REQUIRED"

    summary = {
        "project": "Quantum-Emergent Gravity",
        "stage": "6P-v6",
        "script": Path(__file__).name,
        "project_root": str(project_root),
        "output_dir": str(out_dir),
        "verdict": verdict,
        "constraints": {
            "pdg_or_new_physical_information_injected": False,
            "green_function_machinery_introduced": False,
            "row_index_family_assignment_performed": False,
            "upstream_reconstruction_performed": False,
            "input_smoothing_performed": False,
            "diagnostic_two_lobe_fit_performed": True,
            "family_labels_required_explicitly_from_v5_candidate": True,
        },
        "input_files": {
            res: {k: str(v) for k, v in p.items()} for res, p in paths.items()
        },
        "inferred_columns": metadata,
        "per_resolution_consensus": per_resolution_consensus,
        "outputs": {
            "fit_summary_csv": str(fit_csv),
            "lobe_parameters_csv": str(params_csv),
            "candidate_vs_canonical_csv": str(comparison_csv),
            "pairwise_family_parameter_distances_csv": str(pairwise_csv),
            "plot_48": str(out_dir / "stage6P_v6_48bins_family_fit_overlay.png"),
            "plot_361": str(out_dir / "stage6P_v6_361bins_family_fit_overlay.png"),
        },
        "recommendation": "If accepted or promising, inspect plots and then freeze v5/v6 as the repaired family-aware modal-rho branch. If not accepted, do not add Green functions yet; return to source observable selection from v5 candidate scores.",
    }

    summary_json = out_dir / "stage6P_v6_audit_summary.json"
    notes_txt = out_dir / "stage6P_v6_audit_notes.txt"
    with open(summary_json, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)

    with open(notes_txt, "w", encoding="utf-8") as f:
        f.write("============================================================\n")
        f.write("STAGE-6P v6 TWO-LOBE UNIVERSALITY TEST ON v5 CANDIDATE\n")
        f.write("============================================================\n\n")
        f.write("RULES\n-----\n")
        f.write("No PDG injection, no Green-function machinery, no row-index family assignment,\n")
        f.write("no upstream reconstruction, and no input smoothing were performed.\n")
        f.write("Diagnostic two-lobe fits were performed only to test the v5 repair object.\n\n")
        f.write("VERDICT\n-------\n")
        f.write(f"{verdict}\n\n")
        f.write("PER-RESOLUTION CONSENSUS\n------------------------\n")
        for res, info in per_resolution_consensus.items():
            f.write(f"{res}: {info.get('consensus')}\n")
            f.write(f"    {info.get('family_statuses', '')}\n")
            f.write(f"    mu_early_range={info.get('mu_early_range')}  mu_central_range={info.get('mu_central_range')}\n")
            f.write(f"    mean_r2={info.get('r2_mean')}  mean_corr={info.get('corr_mean')}  mean_canonical_corr={info.get('canonical_corr_mean')}\n")
        f.write("\nINTERPRETATION\n--------------\n")
        if "ACCEPTED" in verdict and "NOT" not in verdict:
            f.write("The v5 candidate passes the family-separated two-lobe test strongly enough to be treated as a repaired family-aware modal-rho candidate.\n")
        elif "PROMISING" in verdict:
            f.write("The v5 candidate shows family-separated two-lobe structure, but at least one stability or canonical-alignment criterion requires review. Inspect the plots before freezing it.\n")
        elif "NOT_ACCEPTED" in verdict:
            f.write("The v5 candidate does not yet pass as the canonical family-aware modal-rho object. Return to the v5 candidate-score table and test the next non-degenerate source observable.\n")
        else:
            f.write("The v5 candidate requires review; inspect CSVs and plots before deciding.\n")
        f.write("\nGREEN FUNCTIONS / OTHER TOOLS\n-----------------------------\n")
        f.write("Still not introduced in this script. They become appropriate only after the repaired family-aware modal-rho object is accepted or the current repair path is explicitly closed.\n")
        f.write("\nOUTPUTS\n-------\n")
        for _, v in summary["outputs"].items():
            f.write(f"- {v}\n")
        f.write("\n============================================================\n")
        f.write("END STAGE-6P v6 NOTES\n")
        f.write("============================================================\n")

    print("\n[Stage-6P v6] Output files written:")
    for pth in [fit_csv, params_csv, comparison_csv, pairwise_csv, summary_json, notes_txt,
                out_dir / "stage6P_v6_48bins_family_fit_overlay.png",
                out_dir / "stage6P_v6_361bins_family_fit_overlay.png"]:
        print(f"  - {pth}")
    print(f"\n[Stage-6P v6] VERDICT: {verdict}")
    print("========================================================================")
    print("Stage-6P v6 complete")
    print("========================================================================")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
