# -*- coding: utf-8 -*-
"""
Author: Arturo Ortiz-Tapia
04-15-2026 17:33hrs
============================================================
Stage-6H: Intrinsic Distributional Invariants
Project: Quantum-Emergent Gravity
Upstream: Stage-6G intrinsic boundary geometry
Authoring mode: Spyder-ready standalone script
Version: v1b
============================================================

REVISION PURPOSE
----------------
This revision implements the full Stage-6H design brief and ledger supplement:

1) replace sector-label dependence by intrinsic distributional invariants;
2) add robust dispersion metrics (MAD, NMAD, quantile spreads, tail ratios);
3) add shape metrics (skewness, kurtosis, quantile asymmetry, tail heaviness);
4) add symmetric / geometry-aware distribution distances
   (JS, Wasserstein, L1/TV, Hellinger);
5) test peak clustering via run-length encoding on exceedance sets;
6) repeat the analysis under smoothing and coarse-graining to assess stability.

NOTES
-----
* This remains a boundary-geometry diagnostic, not a GR identification.
* Implemented without SciPy so it can run in a minimal Spyder/Pandas/Numpy setup.
"""

from __future__ import annotations

import json
import math
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd


SCRIPT_VERSION = "Stage-6H_intrinsic_distributional_invariants_v1b.py"

INPUT_PROFILE_FILENAME = "stage6G_intrinsic_profile.csv"
INPUT_SUMMARY_FILENAME = "stage6G_intrinsic_summary.json"
INPUT_NOTES_FILENAME = "stage6G_geometry_notes.txt"

OUTPUT_DIRNAME = "metric_stage_6H_outputs"
OUTPUT_PROFILE_FILENAME = "stage6H_distributional_profile.csv"
OUTPUT_SUMMARY_FILENAME = "stage6H_distributional_summary.json"
OUTPUT_NOTES_FILENAME = "stage6H_distributional_notes.txt"

# Core thresholds and resolutions
HIGH_Q = 0.80
VERY_HIGH_Q = 0.90
SMOOTHING_WINDOWS = [1, 5, 11]          # moving-average windows in samples
GAUSSIAN_SIGMAS = [0.0, 2.0, 5.0]       # sample-space sigmas; 0.0 = identity
COARSE_BIN_COUNTS = [24, 48, 96]
SMOOTH_ALIGN_Q = 0.90
EPS = 1e-12


@dataclass
class LocatedInputs:
    project_root: Path
    profile_csv: Path
    summary_json: Optional[Path]
    notes_txt: Optional[Path]


def log(msg: str) -> None:
    print(msg, flush=True)


def discover_project_root(start: Optional[Path] = None) -> Path:
    if start is None:
        start = Path.cwd().resolve()

    candidates = [start] + list(start.parents)
    markers = {
        "010-Quantum_Emergent_Gravity",
        "metric_stage_6G_outputs",
        "metric_stage_6F_outputs",
        "metric_stage_6E_v2_outputs",
    }

    for path in candidates:
        if path.name == "010-Quantum_Emergent_Gravity":
            return path
        try:
            child_names = {p.name for p in path.iterdir()}
        except Exception:
            child_names = set()
        if "010-Quantum_Emergent_Gravity" in child_names:
            return path / "010-Quantum_Emergent_Gravity"
        if markers.intersection(child_names):
            return path

    raise FileNotFoundError(
        "Could not discover the project root. "
        "Please run this script from inside the project tree."
    )


def find_first_file(root: Path, filename: str) -> Optional[Path]:
    matches = list(root.rglob(filename))
    if not matches:
        return None
    matches.sort(key=lambda p: (len(p.parts), -p.stat().st_mtime))
    return matches[0]


def locate_inputs(project_root: Path) -> LocatedInputs:
    profile_csv = find_first_file(project_root, INPUT_PROFILE_FILENAME)
    summary_json = find_first_file(project_root, INPUT_SUMMARY_FILENAME)
    notes_txt = find_first_file(project_root, INPUT_NOTES_FILENAME)

    if profile_csv is None:
        raise FileNotFoundError(
            f"Required file not found: {INPUT_PROFILE_FILENAME}"
        )

    return LocatedInputs(
        project_root=project_root,
        profile_csv=profile_csv,
        summary_json=summary_json,
        notes_txt=notes_txt,
    )


def normalize_name(name: str) -> str:
    name = name.strip().lower()
    name = re.sub(r"[^a-z0-9]+", "_", name)
    name = re.sub(r"_+", "_", name).strip("_")
    return name


def build_normalized_lookup(columns: List[str]) -> Dict[str, str]:
    return {normalize_name(c): c for c in columns}


def resolve_column(columns: List[str], aliases: List[str]) -> Optional[str]:
    lookup = build_normalized_lookup(columns)
    for alias in aliases:
        if alias in lookup:
            return lookup[alias]
    return None


def require_column(columns: List[str], aliases: List[str], label: str) -> str:
    col = resolve_column(columns, aliases)
    if col is None:
        raise KeyError(
            f"Could not resolve required column for '{label}'. "
            f"Available columns: {columns}"
        )
    return col


def maybe_load_json(path: Optional[Path]) -> Optional[dict]:
    if path is None or (not path.exists()):
        return None
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def to_builtin(obj):
    if isinstance(obj, dict):
        return {str(k): to_builtin(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [to_builtin(v) for v in obj]
    if isinstance(obj, tuple):
        return [to_builtin(v) for v in obj]
    if isinstance(obj, np.ndarray):
        return [to_builtin(v) for v in obj.tolist()]
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        value = float(obj)
        if math.isnan(value) or math.isinf(value):
            return None
        return value
    return obj


def safe_normalize_nonnegative(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    x = np.where(np.isfinite(x), x, 0.0)
    x = np.maximum(x, 0.0)
    s = x.sum()
    if s <= EPS:
        return np.zeros_like(x)
    return x / s


def load_profile(path: Path) -> pd.DataFrame:
    log(f"[Stage-6H PRECHECK] Loading Stage-6G profile: {path}")
    raw = pd.read_csv(path)
    cols = list(raw.columns)
    log("[Stage-6H PRECHECK] Stage-6G columns:")
    log(str(cols))

    s_col = require_column(cols, ["s_normalized", "s", "intrinsic_s", "arc_s_normalized"], "s")
    abs_kappa_col = require_column(cols, ["abs_kappa", "kappa_abs", "curvature_abs"], "abs_kappa")
    density_col = require_column(cols, ["density", "angular_density", "mass_density"], "density")

    theta_col = resolve_column(cols, ["theta", "angle"])
    ds_col = resolve_column(cols, ["ds_dtheta", "arc_speed", "arc_length_density"])
    kappa_col = resolve_column(cols, ["kappa", "signed_kappa", "curvature"])
    kappa_sq_col = resolve_column(cols, ["kappa_sq", "abs_kappa_sq"])

    out = pd.DataFrame()
    out["s"] = pd.to_numeric(raw[s_col], errors="coerce")
    out["abs_kappa"] = pd.to_numeric(raw[abs_kappa_col], errors="coerce")
    out["density"] = pd.to_numeric(raw[density_col], errors="coerce")
    out["theta"] = pd.to_numeric(raw[theta_col], errors="coerce") if theta_col else np.nan
    out["ds_dtheta"] = pd.to_numeric(raw[ds_col], errors="coerce") if ds_col else np.nan
    out["kappa"] = pd.to_numeric(raw[kappa_col], errors="coerce") if kappa_col else np.nan
    if kappa_sq_col:
        out["kappa_sq"] = pd.to_numeric(raw[kappa_sq_col], errors="coerce")
    else:
        out["kappa_sq"] = out["abs_kappa"] ** 2

    out = out.sort_values("s").reset_index(drop=True)
    return out


def validate_profile(df: pd.DataFrame) -> None:
    if df["s"].isna().any():
        raise ValueError("Intrinsic coordinate s contains NaN values.")
    if not np.all(np.diff(df["s"].to_numpy(dtype=float)) >= 0):
        raise ValueError("Intrinsic coordinate s is not monotone after sorting.")
    if df["abs_kappa"].isna().all():
        raise ValueError("Absolute curvature is entirely missing.")
    if df["density"].isna().all():
        raise ValueError("Density is entirely missing.")


def prepare_base_arrays(df: pd.DataFrame) -> pd.DataFrame:
    s = df["s"].to_numpy(dtype=float)
    if s.max() > 1.0 + 1e-6 or s.min() < -1e-6:
        s = (s - s.min()) / max(s.max() - s.min(), EPS)

    abs_kappa = np.where(np.isfinite(df["abs_kappa"].to_numpy(dtype=float)), df["abs_kappa"].to_numpy(dtype=float), 0.0)
    density = np.where(np.isfinite(df["density"].to_numpy(dtype=float)), df["density"].to_numpy(dtype=float), 0.0)
    theta = np.where(np.isfinite(df["theta"].to_numpy(dtype=float)), df["theta"].to_numpy(dtype=float), np.nan)
    kappa = np.where(np.isfinite(df["kappa"].to_numpy(dtype=float)), df["kappa"].to_numpy(dtype=float), 0.0)
    kappa_sq = np.where(np.isfinite(df["kappa_sq"].to_numpy(dtype=float)), df["kappa_sq"].to_numpy(dtype=float), abs_kappa ** 2)

    ds = np.gradient(s)
    ds = np.where(np.isfinite(ds), np.abs(ds), 0.0)

    out = pd.DataFrame({
        "s": s,
        "theta": theta,
        "kappa": kappa,
        "abs_kappa": abs_kappa,
        "kappa_sq": kappa_sq,
        "density": density,
        "ds": ds,
    })
    return out


def moving_average(x: np.ndarray, window: int) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    if window <= 1:
        return x.copy()
    if window % 2 == 0:
        window += 1
    kernel = np.ones(window, dtype=float) / float(window)
    pad = window // 2
    padded = np.pad(x, pad_width=pad, mode="reflect")
    return np.convolve(padded, kernel, mode="valid")


def gaussian_smooth(x: np.ndarray, sigma: float) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    if sigma <= 0.0:
        return x.copy()
    radius = max(1, int(math.ceil(4.0 * sigma)))
    grid = np.arange(-radius, radius + 1, dtype=float)
    kernel = np.exp(-0.5 * (grid / sigma) ** 2)
    kernel /= kernel.sum()
    padded = np.pad(x, pad_width=radius, mode="reflect")
    return np.convolve(padded, kernel, mode="valid")


def safe_corr(a: np.ndarray, b: np.ndarray) -> Optional[float]:
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    mask = np.isfinite(a) & np.isfinite(b)
    if mask.sum() < 3:
        return None
    aa = a[mask]
    bb = b[mask]
    if np.std(aa) <= EPS or np.std(bb) <= EPS:
        return None
    return float(np.corrcoef(aa, bb)[0, 1])


def safe_rank_corr(a: np.ndarray, b: np.ndarray) -> Optional[float]:
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    mask = np.isfinite(a) & np.isfinite(b)
    if mask.sum() < 3:
        return None
    sa = pd.Series(a[mask]).rank(method="average")
    sb = pd.Series(b[mask]).rank(method="average")
    if sa.std() <= EPS or sb.std() <= EPS:
        return None
    return float(sa.corr(sb))


def weighted_mean(coord: np.ndarray, weights: np.ndarray) -> Optional[float]:
    w = safe_normalize_nonnegative(weights)
    if w.sum() <= EPS:
        return None
    return float(np.sum(coord * w))


def weighted_variance(coord: np.ndarray, weights: np.ndarray) -> Optional[float]:
    mu = weighted_mean(coord, weights)
    if mu is None:
        return None
    w = safe_normalize_nonnegative(weights)
    return float(np.sum(w * (coord - mu) ** 2))


def weighted_quantile(coord: np.ndarray, weights: np.ndarray, q: float) -> Optional[float]:
    if not (0.0 <= q <= 1.0):
        raise ValueError("q must lie in [0,1]")
    w = safe_normalize_nonnegative(weights)
    if w.sum() <= EPS:
        return None
    order = np.argsort(coord)
    xs = coord[order]
    ws = w[order]
    cdf = np.cumsum(ws)
    idx = int(np.searchsorted(cdf, q, side="left"))
    idx = min(max(idx, 0), len(xs) - 1)
    return float(xs[idx])


def median_abs_deviation(x: np.ndarray) -> Optional[float]:
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    if x.size == 0:
        return None
    med = np.median(x)
    return float(np.median(np.abs(x - med)))


def nmad(x: np.ndarray) -> Optional[float]:
    mad = median_abs_deviation(x)
    if mad is None:
        return None
    return float(1.4826 * mad)


def quantile_value(x: np.ndarray, q: float) -> Optional[float]:
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    if x.size == 0:
        return None
    return float(np.quantile(x, q))


def skewness_moment(x: np.ndarray) -> Optional[float]:
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    if x.size < 3:
        return None
    mu = float(np.mean(x))
    sd = float(np.std(x))
    if sd <= EPS:
        return None
    z = (x - mu) / sd
    return float(np.mean(z ** 3))


def kurtosis_excess(x: np.ndarray) -> Optional[float]:
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    if x.size < 4:
        return None
    mu = float(np.mean(x))
    sd = float(np.std(x))
    if sd <= EPS:
        return None
    z = (x - mu) / sd
    return float(np.mean(z ** 4) - 3.0)


def quantile_asymmetry(x: np.ndarray, q_low: float = 0.10, q_mid: float = 0.50, q_high: float = 0.90) -> Optional[float]:
    ql = quantile_value(x, q_low)
    qm = quantile_value(x, q_mid)
    qh = quantile_value(x, q_high)
    if ql is None or qm is None or qh is None:
        return None
    denom = qh - ql
    if abs(denom) <= EPS:
        return None
    return float((qh + ql - 2.0 * qm) / denom)


def tail_concentration_ratio(x: np.ndarray, q: float = 0.90) -> Optional[float]:
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    if x.size == 0:
        return None
    mean_all = float(np.mean(x))
    if abs(mean_all) <= EPS:
        return None
    thr = float(np.quantile(x, q))
    top = x[x >= thr]
    if top.size == 0:
        return None
    return float(np.mean(top) / mean_all)


def tail_heaviness_indicator(x: np.ndarray) -> Optional[float]:
    q80 = quantile_value(x, 0.80)
    q50 = quantile_value(x, 0.50)
    q20 = quantile_value(x, 0.20)
    if q80 is None or q50 is None or q20 is None:
        return None
    denom = q50 - q20
    if abs(denom) <= EPS:
        return None
    return float((q80 - q50) / denom)


def shannon_entropy(weights: np.ndarray) -> Optional[float]:
    w = safe_normalize_nonnegative(weights)
    w = w[w > 0]
    if w.size == 0:
        return None
    return float(-np.sum(w * np.log(w)))


def concentration_ratio(weights: np.ndarray, top_k: int) -> Optional[float]:
    w = safe_normalize_nonnegative(weights)
    if w.size == 0:
        return None
    if top_k <= 0:
        return 0.0
    return float(np.sort(w)[::-1][:top_k].sum())


def gini_coefficient(weights: np.ndarray) -> Optional[float]:
    w = safe_normalize_nonnegative(weights)
    if w.size == 0 or np.allclose(w, 0.0):
        return None
    x = np.sort(w)
    n = len(x)
    idx = np.arange(1, n + 1)
    return float((2.0 * np.sum(idx * x) / (n * np.sum(x))) - (n + 1) / n)


def overlap_mass(a: np.ndarray, b: np.ndarray) -> Optional[float]:
    a2 = safe_normalize_nonnegative(a)
    b2 = safe_normalize_nonnegative(b)
    if a2.sum() <= EPS or b2.sum() <= EPS:
        return None
    return float(np.minimum(a2, b2).sum())


def total_variation_distance(a: np.ndarray, b: np.ndarray) -> Optional[float]:
    a2 = safe_normalize_nonnegative(a)
    b2 = safe_normalize_nonnegative(b)
    if a2.sum() <= EPS or b2.sum() <= EPS:
        return None
    return float(0.5 * np.sum(np.abs(a2 - b2)))


def wasserstein_1_on_line(coord: np.ndarray, a: np.ndarray, b: np.ndarray) -> Optional[float]:
    a2 = safe_normalize_nonnegative(a)
    b2 = safe_normalize_nonnegative(b)
    if a2.sum() <= EPS or b2.sum() <= EPS:
        return None
    order = np.argsort(coord)
    xs = coord[order]
    da = a2[order]
    db = b2[order]
    cdfa = np.cumsum(da)
    cdfb = np.cumsum(db)
    dx = np.diff(xs)
    if dx.size == 0:
        return 0.0
    return float(np.sum(np.abs(cdfa[:-1] - cdfb[:-1]) * dx))


def jensen_shannon_divergence(a: np.ndarray, b: np.ndarray) -> Optional[float]:
    p = safe_normalize_nonnegative(a)
    q = safe_normalize_nonnegative(b)
    if p.sum() <= EPS or q.sum() <= EPS:
        return None
    m = 0.5 * (p + q)

    def kl(x: np.ndarray, y: np.ndarray) -> float:
        mask = (x > 0) & (y > 0)
        if not mask.any():
            return 0.0
        return float(np.sum(x[mask] * np.log(x[mask] / y[mask])))

    return float(0.5 * kl(p, m) + 0.5 * kl(q, m))


def hellinger_distance(a: np.ndarray, b: np.ndarray) -> Optional[float]:
    p = safe_normalize_nonnegative(a)
    q = safe_normalize_nonnegative(b)
    if p.sum() <= EPS or q.sum() <= EPS:
        return None
    return float(np.sqrt(0.5 * np.sum((np.sqrt(p) - np.sqrt(q)) ** 2)))


def contiguous_intervals(coord: np.ndarray, mask: np.ndarray) -> List[Tuple[float, float, int]]:
    mask = np.asarray(mask, dtype=bool)
    intervals: List[Tuple[float, float, int]] = []
    start = None
    for i, flag in enumerate(mask):
        if flag and start is None:
            start = i
        if (not flag) and (start is not None):
            intervals.append((float(coord[start]), float(coord[i - 1]), int(i - start)))
            start = None
    if start is not None:
        intervals.append((float(coord[start]), float(coord[len(coord) - 1]), int(len(coord) - start)))
    return intervals


def interval_summary(intervals: List[Tuple[float, float, int]]) -> Dict[str, object]:
    if not intervals:
        return {
            "n_intervals": 0,
            "max_width": None,
            "total_width": 0.0,
            "cluster_sizes_points": [],
            "intervals": [],
        }
    widths = [b - a for a, b, _ in intervals]
    return {
        "n_intervals": len(intervals),
        "max_width": float(max(widths)),
        "total_width": float(sum(widths)),
        "cluster_sizes_points": [int(n) for _, _, n in intervals],
        "intervals": [
            {"s_start": float(a), "s_end": float(b), "n_points": int(n), "width": float(b - a)}
            for a, b, n in intervals
        ],
    }


def peak_structure_summary(s: np.ndarray, x: np.ndarray, q: float) -> Dict[str, object]:
    x = np.asarray(x, dtype=float)
    finite = np.isfinite(x)
    if finite.sum() == 0:
        return {
            "threshold_quantile": q,
            "threshold_value": None,
            "n_exceedance_points": 0,
            "fraction_exceedance_points": 0.0,
            "cluster_summary": interval_summary([]),
        }
    thr = float(np.quantile(x[finite], q))
    mask = finite & (x >= thr)
    return {
        "threshold_quantile": q,
        "threshold_value": thr,
        "n_exceedance_points": int(mask.sum()),
        "fraction_exceedance_points": float(mask.mean()),
        "cluster_summary": interval_summary(contiguous_intervals(s, mask)),
    }


def arglocalmax_simple(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    if len(x) < 3:
        return np.array([], dtype=int)
    mids = np.arange(1, len(x) - 1)
    mask = (x[mids] >= x[mids - 1]) & (x[mids] > x[mids + 1])
    return mids[mask]


def peak_alignment_after_smoothing(s: np.ndarray, curv: np.ndarray, dens: np.ndarray, smoothing_desc: str) -> Dict[str, object]:
    curv_peaks = arglocalmax_simple(curv)
    dens_peaks = arglocalmax_simple(dens)

    curv_thr = np.quantile(curv[np.isfinite(curv)], SMOOTH_ALIGN_Q) if np.isfinite(curv).any() else np.nan
    dens_thr = np.quantile(dens[np.isfinite(dens)], SMOOTH_ALIGN_Q) if np.isfinite(dens).any() else np.nan
    curv_sig = [i for i in curv_peaks if curv[i] >= curv_thr]
    dens_sig = [i for i in dens_peaks if dens[i] >= dens_thr]

    matches = []
    if curv_sig and dens_sig:
        for i in curv_sig:
            j = min(dens_sig, key=lambda k: abs(s[k] - s[i]))
            matches.append(abs(float(s[j] - s[i])))

    return {
        "smoothing": smoothing_desc,
        "n_curvature_peaks_significant": int(len(curv_sig)),
        "n_density_peaks_significant": int(len(dens_sig)),
        "mean_nearest_peak_gap_s": None if not matches else float(np.mean(matches)),
        "max_nearest_peak_gap_s": None if not matches else float(np.max(matches)),
    }


def mass_profile_from_values(values: np.ndarray, ds: np.ndarray) -> np.ndarray:
    return safe_normalize_nonnegative(np.maximum(values, 0.0) * np.maximum(ds, 0.0))


def distributional_descriptors(values: np.ndarray, masses: np.ndarray, s: np.ndarray) -> Dict[str, object]:
    q10 = quantile_value(values, 0.10)
    q20 = quantile_value(values, 0.20)
    q50 = quantile_value(values, 0.50)
    q80 = quantile_value(values, 0.80)
    q90 = quantile_value(values, 0.90)

    return {
        "median": quantile_value(values, 0.50),
        "mad": median_abs_deviation(values),
        "nmad": nmad(values),
        "quantile_spread_q90_q10": None if (q90 is None or q10 is None) else float(q90 - q10),
        "quantile_spread_q80_q20": None if (q80 is None or q20 is None) else float(q80 - q20),
        "tail_concentration_ratio_top10": tail_concentration_ratio(values, 0.90),
        "tail_concentration_ratio_top20": tail_concentration_ratio(values, 0.80),
        "skewness": skewness_moment(values),
        "kurtosis_excess": kurtosis_excess(values),
        "quantile_asymmetry_q10_q50_q90": quantile_asymmetry(values, 0.10, 0.50, 0.90),
        "tail_heaviness_indicator": tail_heaviness_indicator(values),
        "entropy_mass": shannon_entropy(masses),
        "gini_mass": gini_coefficient(masses),
        "barycenter_s": weighted_mean(s, masses),
        "variance_s": weighted_variance(s, masses),
        "mass_q10_s": weighted_quantile(s, masses, 0.10),
        "mass_q50_s": weighted_quantile(s, masses, 0.50),
        "mass_q90_s": weighted_quantile(s, masses, 0.90),
        "top1_mass": concentration_ratio(masses, 1),
        "top3_mass": concentration_ratio(masses, 3),
        "top5_mass": concentration_ratio(masses, 5),
    }


def coarse_grain(s: np.ndarray, curv_mass: np.ndarray, dens_mass: np.ndarray, curv_values: np.ndarray, dens_values: np.ndarray, n_bins: int) -> Dict[str, object]:
    edges = np.linspace(0.0, 1.0, n_bins + 1)
    idx = np.digitize(s, edges) - 1
    idx = np.clip(idx, 0, n_bins - 1)

    s_bin = np.zeros(n_bins, dtype=float)
    curv_m = np.zeros(n_bins, dtype=float)
    dens_m = np.zeros(n_bins, dtype=float)
    curv_mean = np.full(n_bins, np.nan, dtype=float)
    dens_mean = np.full(n_bins, np.nan, dtype=float)

    for k in range(n_bins):
        mask = idx == k
        if not mask.any():
            s_bin[k] = 0.5 * (edges[k] + edges[k + 1])
            continue
        s_bin[k] = float(np.mean(s[mask]))
        curv_m[k] = float(np.sum(curv_mass[mask]))
        dens_m[k] = float(np.sum(dens_mass[mask]))
        curv_mean[k] = float(np.mean(curv_values[mask]))
        dens_mean[k] = float(np.mean(dens_values[mask]))

    return {
        "n_bins": int(n_bins),
        "overlap_mass": overlap_mass(curv_m, dens_m),
        "js_divergence": jensen_shannon_divergence(curv_m, dens_m),
        "wasserstein_1_distance": wasserstein_1_on_line(s_bin, curv_m, dens_m),
        "total_variation_distance": total_variation_distance(curv_m, dens_m),
        "hellinger_distance": hellinger_distance(curv_m, dens_m),
        "value_corr": safe_corr(curv_mean, dens_mean),
        "value_rank_corr": safe_rank_corr(curv_mean, dens_mean),
    }


def build_distributional_profile(base: pd.DataFrame) -> pd.DataFrame:
    s = base["s"].to_numpy(dtype=float)
    abs_kappa = base["abs_kappa"].to_numpy(dtype=float)
    density = base["density"].to_numpy(dtype=float)
    ds = base["ds"].to_numpy(dtype=float)

    curv_mass = mass_profile_from_values(abs_kappa, ds)
    dens_mass = mass_profile_from_values(density, ds)
    curv_cdf = np.cumsum(curv_mass)
    dens_cdf = np.cumsum(dens_mass)

    pointwise_overlap = np.minimum(curv_mass, dens_mass)
    pointwise_signed_mismatch = curv_mass - dens_mass
    pointwise_abs_mismatch = np.abs(pointwise_signed_mismatch)

    curv_thr = np.quantile(abs_kappa[np.isfinite(abs_kappa)], HIGH_Q) if np.isfinite(abs_kappa).any() else np.nan
    dens_thr = np.quantile(density[np.isfinite(density)], HIGH_Q) if np.isfinite(density).any() else np.nan
    curv_very_thr = np.quantile(abs_kappa[np.isfinite(abs_kappa)], VERY_HIGH_Q) if np.isfinite(abs_kappa).any() else np.nan
    dens_very_thr = np.quantile(density[np.isfinite(density)], VERY_HIGH_Q) if np.isfinite(density).any() else np.nan

    profile = pd.DataFrame({
        "s": s,
        "theta": base["theta"].to_numpy(dtype=float),
        "kappa": base["kappa"].to_numpy(dtype=float),
        "abs_kappa": abs_kappa,
        "kappa_sq": base["kappa_sq"].to_numpy(dtype=float),
        "density": density,
        "ds": ds,
        "curvature_mass": curv_mass,
        "density_mass": dens_mass,
        "curvature_cdf": curv_cdf,
        "density_cdf": dens_cdf,
        "pointwise_overlap_mass": pointwise_overlap,
        "pointwise_signed_mass_mismatch": pointwise_signed_mismatch,
        "pointwise_abs_mass_mismatch": pointwise_abs_mismatch,
        "high_curvature_support_q80": abs_kappa >= curv_thr,
        "high_density_support_q80": density >= dens_thr,
        "very_high_curvature_support_q90": abs_kappa >= curv_very_thr,
        "very_high_density_support_q90": density >= dens_very_thr,
    })
    return profile


def build_summary(profile: pd.DataFrame, upstream_summary: Optional[dict]) -> Dict[str, object]:
    s = profile["s"].to_numpy(dtype=float)
    abs_kappa = profile["abs_kappa"].to_numpy(dtype=float)
    density = profile["density"].to_numpy(dtype=float)
    ds = profile["ds"].to_numpy(dtype=float)
    curv_mass = profile["curvature_mass"].to_numpy(dtype=float)
    dens_mass = profile["density_mass"].to_numpy(dtype=float)

    curvature_dispersion = distributional_descriptors(abs_kappa, curv_mass, s)
    density_dispersion = distributional_descriptors(density, dens_mass, s)

    distribution_distances = {
        "js_divergence": jensen_shannon_divergence(curv_mass, dens_mass),
        "wasserstein_1_distance": wasserstein_1_on_line(s, curv_mass, dens_mass),
        "total_variation_distance": total_variation_distance(curv_mass, dens_mass),
        "hellinger_distance": hellinger_distance(curv_mass, dens_mass),
        "point_corr_abs_kappa_vs_density": safe_corr(abs_kappa, density),
        "point_rank_corr_abs_kappa_vs_density": safe_rank_corr(abs_kappa, density),
    }

    curv_peak_q80 = peak_structure_summary(s, abs_kappa, HIGH_Q)
    dens_peak_q80 = peak_structure_summary(s, density, HIGH_Q)
    curv_peak_q90 = peak_structure_summary(s, abs_kappa, VERY_HIGH_Q)
    dens_peak_q90 = peak_structure_summary(s, density, VERY_HIGH_Q)

    support_curv = profile["high_curvature_support_q80"].to_numpy(dtype=bool)
    support_dens = profile["high_density_support_q80"].to_numpy(dtype=bool)
    support_joint = support_curv & support_dens

    peak_structure = {
        "curvature_q80": curv_peak_q80,
        "density_q80": dens_peak_q80,
        "curvature_q90": curv_peak_q90,
        "density_q90": dens_peak_q90,
        "joint_high_support_q80": interval_summary(contiguous_intervals(s, support_joint)),
    }

    multiscale_smoothing = []
    for window in SMOOTHING_WINDOWS:
        curv_sm = moving_average(abs_kappa, window)
        dens_sm = moving_average(density, window)
        curv_m = mass_profile_from_values(curv_sm, ds)
        dens_m = mass_profile_from_values(dens_sm, ds)
        multiscale_smoothing.append({
            "method": "moving_average",
            "parameter": int(window),
            "overlap_mass": overlap_mass(curv_m, dens_m),
            "js_divergence": jensen_shannon_divergence(curv_m, dens_m),
            "wasserstein_1_distance": wasserstein_1_on_line(s, curv_m, dens_m),
            "total_variation_distance": total_variation_distance(curv_m, dens_m),
            "hellinger_distance": hellinger_distance(curv_m, dens_m),
            "value_corr": safe_corr(curv_sm, dens_sm),
            "value_rank_corr": safe_rank_corr(curv_sm, dens_sm),
            "peak_alignment": peak_alignment_after_smoothing(s, curv_sm, dens_sm, f"moving_average:{window}"),
            "curvature_cluster_q90": peak_structure_summary(s, curv_sm, VERY_HIGH_Q)["cluster_summary"],
            "density_cluster_q90": peak_structure_summary(s, dens_sm, VERY_HIGH_Q)["cluster_summary"],
        })

    for sigma in GAUSSIAN_SIGMAS:
        curv_sm = gaussian_smooth(abs_kappa, sigma)
        dens_sm = gaussian_smooth(density, sigma)
        curv_m = mass_profile_from_values(curv_sm, ds)
        dens_m = mass_profile_from_values(dens_sm, ds)
        multiscale_smoothing.append({
            "method": "gaussian",
            "parameter": float(sigma),
            "overlap_mass": overlap_mass(curv_m, dens_m),
            "js_divergence": jensen_shannon_divergence(curv_m, dens_m),
            "wasserstein_1_distance": wasserstein_1_on_line(s, curv_m, dens_m),
            "total_variation_distance": total_variation_distance(curv_m, dens_m),
            "hellinger_distance": hellinger_distance(curv_m, dens_m),
            "value_corr": safe_corr(curv_sm, dens_sm),
            "value_rank_corr": safe_rank_corr(curv_sm, dens_sm),
            "peak_alignment": peak_alignment_after_smoothing(s, curv_sm, dens_sm, f"gaussian:{sigma}"),
            "curvature_cluster_q90": peak_structure_summary(s, curv_sm, VERY_HIGH_Q)["cluster_summary"],
            "density_cluster_q90": peak_structure_summary(s, dens_sm, VERY_HIGH_Q)["cluster_summary"],
        })

    coarse_graining = [
        coarse_grain(s, curv_mass, dens_mass, abs_kappa, density, n_bins)
        for n_bins in COARSE_BIN_COUNTS
    ]

    def stable_range(records: Sequence[Dict[str, object]], key: str) -> Optional[float]:
        vals = [r.get(key) for r in records if r.get(key) is not None]
        if not vals:
            return None
        return float(max(vals) - min(vals))

    overlap_range = stable_range(multiscale_smoothing, "overlap_mass")
    js_range = stable_range(multiscale_smoothing, "js_divergence")
    w1_range = stable_range(multiscale_smoothing, "wasserstein_1_distance")
    corr_range = stable_range(multiscale_smoothing, "value_corr")

    coarse_overlap_range = stable_range(coarse_graining, "overlap_mass")
    coarse_js_range = stable_range(coarse_graining, "js_divergence")
    coarse_w1_range = stable_range(coarse_graining, "wasserstein_1_distance")

    stability_flags = {
        "smoothing_overlap_stable": (overlap_range is not None and overlap_range <= 0.15),
        "smoothing_js_stable": (js_range is not None and js_range <= 0.08),
        "smoothing_w1_stable": (w1_range is not None and w1_range <= 0.08),
        "smoothing_corr_stable": (corr_range is not None and corr_range <= 0.25),
        "coarse_overlap_stable": (coarse_overlap_range is not None and coarse_overlap_range <= 0.15),
        "coarse_js_stable": (coarse_js_range is not None and coarse_js_range <= 0.08),
        "coarse_w1_stable": (coarse_w1_range is not None and coarse_w1_range <= 0.10),
        "distribution_level_relation_detectable": (
            distribution_distances["js_divergence"] is not None and
            distribution_distances["wasserstein_1_distance"] is not None and
            distribution_distances["total_variation_distance"] is not None and
            distribution_distances["js_divergence"] <= 0.30 and
            distribution_distances["wasserstein_1_distance"] <= 0.30 and
            distribution_distances["total_variation_distance"] <= 0.70
        ),
        "curvature_q90_clustered": (curv_peak_q90["cluster_summary"]["n_intervals"] is not None and curv_peak_q90["cluster_summary"]["n_intervals"] <= 6),
        "joint_high_support_nontrivial": peak_structure["joint_high_support_q80"]["total_width"] >= 0.05,
    }

    true_flags = [v for v in stability_flags.values() if isinstance(v, bool)]
    n_true = sum(true_flags)
    n_flags = len(true_flags)

    if n_flags == 0:
        verdict = "insufficient_evidence"
    elif n_true >= max(6, math.ceil(0.70 * n_flags)):
        verdict = "intrinsic_distributional_structure_supported"
    elif n_true >= max(4, math.ceil(0.45 * n_flags)):
        verdict = "mixed_but_usable_distributional_signal"
    else:
        verdict = "distributional_structure_weak_or_coordinate_induced"

    interpretation_goal = (
        "A" if verdict in {"intrinsic_distributional_structure_supported", "mixed_but_usable_distributional_signal"}
        else "B"
    )

    return {
        "script_version": SCRIPT_VERSION,
        "configuration": {
            "high_q": HIGH_Q,
            "very_high_q": VERY_HIGH_Q,
            "smoothing_windows": list(SMOOTHING_WINDOWS),
            "gaussian_sigmas": list(GAUSSIAN_SIGMAS),
            "coarse_bin_counts": list(COARSE_BIN_COUNTS),
            "smooth_alignment_quantile": SMOOTH_ALIGN_Q,
        },
        "dispersion_metrics": {
            "curvature": curvature_dispersion,
            "density": density_dispersion,
        },
        "shape_metrics": {
            "curvature": {
                "skewness": curvature_dispersion["skewness"],
                "kurtosis_excess": curvature_dispersion["kurtosis_excess"],
                "quantile_asymmetry_q10_q50_q90": curvature_dispersion["quantile_asymmetry_q10_q50_q90"],
                "tail_heaviness_indicator": curvature_dispersion["tail_heaviness_indicator"],
            },
            "density": {
                "skewness": density_dispersion["skewness"],
                "kurtosis_excess": density_dispersion["kurtosis_excess"],
                "quantile_asymmetry_q10_q50_q90": density_dispersion["quantile_asymmetry_q10_q50_q90"],
                "tail_heaviness_indicator": density_dispersion["tail_heaviness_indicator"],
            },
        },
        "distribution_distances": distribution_distances,
        "peak_structure": peak_structure,
        "multiscale_analysis": {
            "smoothing": multiscale_smoothing,
            "coarse_graining": coarse_graining,
            "stability_ranges": {
                "smoothing_overlap_range": overlap_range,
                "smoothing_js_range": js_range,
                "smoothing_w1_range": w1_range,
                "smoothing_corr_range": corr_range,
                "coarse_overlap_range": coarse_overlap_range,
                "coarse_js_range": coarse_js_range,
                "coarse_w1_range": coarse_w1_range,
            },
        },
        "invariance_like_flags": stability_flags,
        "stage6H_verdict": verdict,
        "interpretation_goal_result": {
            "selected_case": interpretation_goal,
            "meaning": (
                "geometry is intrinsically structured but sector labels were too fragile"
                if interpretation_goal == "A"
                else "geometry is weak and mostly coordinate-induced at the tested distributional level"
            ),
        },
        "upstream_stage6G_summary": upstream_summary,
    }


def build_notes(summary: Dict[str, object]) -> str:
    verdict = summary["stage6H_verdict"]
    dist = summary["distribution_distances"]
    flags = summary["invariance_like_flags"]
    stability = summary["multiscale_analysis"]["stability_ranges"]

    lines = []
    lines.append("============================================================")
    lines.append("STAGE-6H DISTRIBUTIONAL NOTES")
    lines.append("Project: Quantum-Emergent Gravity")
    lines.append("============================================================")
    lines.append("")
    lines.append("DECISIVE VERDICT")
    lines.append("----------------")
    lines.append(str(verdict))
    lines.append("")
    lines.append("DISTRIBUTION DISTANCES")
    lines.append("----------------------")
    for k, v in dist.items():
        lines.append(f"{k}: {v}")
    lines.append("")
    lines.append("STABILITY RANGES")
    lines.append("----------------")
    for k, v in stability.items():
        lines.append(f"{k}: {v}")
    lines.append("")
    lines.append("FLAGS")
    lines.append("-----")
    for k, v in flags.items():
        lines.append(f"{k}: {v}")
    lines.append("")
    lines.append("INTERPRETATION")
    lines.append("--------------")
    lines.append(
        "Stage-6H replaces sector identity by continuous distributional geometry on the intrinsic coordinate s. "
        "It tests robust dispersion, shape, distributional distances, clustering of high-curvature regions, and "
        "their stability under smoothing and coarse-graining."
    )
    lines.append("")
    lines.append("============================================================")
    return "\n".join(lines)


def main() -> None:
    log("[Stage-6H PRECHECK] Discovering project root...")
    project_root = discover_project_root()

    log("[Stage-6H PRECHECK] Locating Stage-6G inputs...")
    located = locate_inputs(project_root)

    out_dir = project_root / OUTPUT_DIRNAME
    out_dir.mkdir(parents=True, exist_ok=True)

    log("[Stage-6H PRECHECK] Loading Stage-6G intrinsic profile...")
    df = load_profile(located.profile_csv)
    validate_profile(df)
    base = prepare_base_arrays(df)

    log("[Stage-6H] Building Stage-6H distributional profile...")
    profile = build_distributional_profile(base)

    log("[Stage-6H] Computing Stage-6H summary...")
    upstream_summary = maybe_load_json(located.summary_json)
    summary = build_summary(profile, upstream_summary)

    log("[Stage-6H] Writing outputs...")
    profile_path = out_dir / OUTPUT_PROFILE_FILENAME
    summary_path = out_dir / OUTPUT_SUMMARY_FILENAME
    notes_path = out_dir / OUTPUT_NOTES_FILENAME

    profile.to_csv(profile_path, index=False)
    with summary_path.open("w", encoding="utf-8") as f:
        json.dump(to_builtin(summary), f, indent=2, ensure_ascii=False)
    with notes_path.open("w", encoding="utf-8") as f:
        f.write(build_notes(summary))

    log("[Stage-6H] Done.")
    log(f"[Stage-6H] Wrote CSV : {profile_path}")
    log(f"[Stage-6H] Wrote JSON: {summary_path}")
    log(f"[Stage-6H] Wrote TXT : {notes_path}")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        log(f"[Stage-6H ERROR] {type(exc).__name__}: {exc}")
        raise
