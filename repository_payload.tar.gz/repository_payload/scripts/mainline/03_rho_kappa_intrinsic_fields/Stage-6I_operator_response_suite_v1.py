
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Stage-6I_operator_response_suite_v1.py

Project: Quantum-Emergent Gravity
Stage: 6I
Upstream: Stage-6H distributional invariants

Purpose
-------
Construct and compare multiple intrinsic operator-level relations between
curvature and density fields on the intrinsic coordinate s:

    kappa(s) <-> rho(s)

This script is designed to be Spyder-friendly and robust to modest schema
variation, while remaining self-contained under the contract-level Stage-6I
handoff.

Outputs
-------
metric_stage_6I_outputs/
    stage6I_operator_profile.csv
    stage6I_operator_summary.json
    stage6I_operator_notes.txt

Authoring note
--------------
This implementation follows the contract-level handoff and the observed
Stage-6H schema in which the profile file contains, at minimum, s, abs_kappa,
and density. If signed curvature `kappa` is present, it is preserved as an
auxiliary field, but Stage-6I uses abs_kappa as the primary curvature field.
"""

from __future__ import annotations

import json
import math
import sys
import traceback
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Any

import numpy as np
import pandas as pd
from scipy import interpolate, signal, stats
from scipy.ndimage import gaussian_filter1d
from scipy.spatial.distance import jensenshannon
from sklearn.linear_model import Ridge


# ---------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------

SCRIPT_VERSION = "Stage-6I_operator_response_suite_v1.py"

INPUT_CANDIDATES = [
    Path("metric_stage_6H_outputs/stage6H_distributional_profile.csv"),
    Path("stage6H_distributional_profile.csv"),
]

OPTIONAL_SUMMARY_CANDIDATES = [
    Path("metric_stage_6H_outputs/stage6H_distributional_summary.json"),
    Path("stage6H_distributional_summary.json"),
]

OPTIONAL_NOTES_CANDIDATES = [
    Path("metric_stage_6H_outputs/stage6H_distributional_notes.txt"),
    Path("stage6H_distributional_notes.txt"),
]

OUTPUT_DIR_NAME = "metric_stage_6I_outputs"

SMOOTHING_VARIANTS = [
    {"kind": "raw", "param": 0},
    {"kind": "moving_average", "param": 5},
    {"kind": "moving_average", "param": 11},
    {"kind": "gaussian", "param": 2.0},
    {"kind": "gaussian", "param": 5.0},
]

COARSE_BIN_COUNTS = [24, 48, 96]

MAX_ABS_LAG = 0.25      # in normalized s-units
N_LAG_STEPS = 161
KERNEL_BANDWIDTHS = [0.01, 0.02, 0.04, 0.06, 0.08, 0.12, 0.16]
RIDGE_ALPHAS = [1e-6, 1e-4, 1e-2, 1e-1, 1.0, 10.0]

STABILITY_THRESHOLDS = {
    "cross_corr_optimal_lag_range": 0.08,
    "cross_corr_max_corr_range": 0.20,
    "lagged_align_shift_range": 0.08,
    "lagged_align_gain_range": 0.10,
    "ridge_r2_range": 0.20,
    "kernel_l2_range": 0.12,
    "spectral_overlap_range": 0.20,
}

EPS = 1e-12


# ---------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------

@dataclass
class VariantData:
    variant_name: str
    family: str                 # smoothing or coarse
    s: np.ndarray
    kappa: np.ndarray
    rho: np.ndarray
    meta: Dict[str, Any]


# ---------------------------------------------------------------------
# Utility functions
# ---------------------------------------------------------------------

def log(msg: str) -> None:
    print(msg)
    sys.stdout.flush()


def safe_float(x: Any) -> float:
    if x is None:
        return float("nan")
    try:
        return float(x)
    except Exception:
        return float("nan")


def json_ready(obj: Any) -> Any:
    if isinstance(obj, dict):
        return {str(k): json_ready(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [json_ready(v) for v in obj]
    if isinstance(obj, tuple):
        return [json_ready(v) for v in obj]
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, (np.floating,)):
        x = float(obj)
        return None if (math.isnan(x) or math.isinf(x)) else x
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    if isinstance(obj, Path):
        return str(obj)
    return obj


def first_existing(paths: List[Path], root: Path) -> Optional[Path]:
    for candidate in paths:
        p = root / candidate
        if p.exists():
            return p
    return None


def discover_project_root() -> Path:
    """
    Conservative root discovery:
    1) current working directory
    2) script directory
    3) parents of each, up to 4 levels
    """
    candidates = []
    cwd = Path.cwd().resolve()
    candidates.append(cwd)
    try:
        script_dir = Path(__file__).resolve().parent
        candidates.append(script_dir)
    except NameError:
        pass

    expanded = []
    for c in candidates:
        expanded.append(c)
        expanded.extend(list(c.parents[:4]))

    seen = set()
    for root in expanded:
        if root in seen:
            continue
        seen.add(root)
        if first_existing(INPUT_CANDIDATES, root) is not None:
            return root

    # Fallback: current directory
    return cwd


def choose_s_column(df: pd.DataFrame) -> str:
    if "s_normalized" in df.columns:
        return "s_normalized"
    if "s" in df.columns:
        return "s"
    raise ValueError("Input file must contain `s` or `s_normalized`.")


def ensure_numeric_series(x: pd.Series, name: str) -> np.ndarray:
    arr = pd.to_numeric(x, errors="coerce").to_numpy(dtype=float)
    if np.all(np.isnan(arr)):
        raise ValueError(f"Column `{name}` is NaN-only after numeric coercion.")
    return arr


def normalize_01(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    xmin = np.nanmin(x)
    xmax = np.nanmax(x)
    span = xmax - xmin
    if span <= EPS:
        return np.zeros_like(x)
    return (x - xmin) / span


def monotone_sort(s: np.ndarray, *arrays: np.ndarray) -> Tuple[np.ndarray, ...]:
    order = np.argsort(s)
    out = [s[order]]
    for arr in arrays:
        out.append(arr[order])
    return tuple(out)


def remove_invalid_rows(s: np.ndarray, kappa: np.ndarray, rho: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    mask = np.isfinite(s) & np.isfinite(kappa) & np.isfinite(rho)
    s2, k2, r2 = s[mask], kappa[mask], rho[mask]
    if len(s2) < 8:
        raise ValueError("Too few valid rows after removing non-finite values.")
    return s2, k2, r2


def enforce_nonnegative(x: np.ndarray) -> np.ndarray:
    y = np.asarray(x, dtype=float).copy()
    y[~np.isfinite(y)] = 0.0
    y[y < 0] = 0.0
    return y


def moving_average_reflect(x: np.ndarray, window: int) -> np.ndarray:
    if window <= 1:
        return x.copy()
    kernel = np.ones(window, dtype=float) / float(window)
    pad = window // 2
    xp = np.pad(x, pad_width=pad, mode="reflect")
    yp = np.convolve(xp, kernel, mode="same")
    return yp[pad:pad + len(x)]


def smooth_signal(x: np.ndarray, kind: str, param: float) -> np.ndarray:
    if kind == "raw":
        return x.copy()
    if kind == "moving_average":
        return moving_average_reflect(x, int(round(param)))
    if kind == "gaussian":
        if float(param) <= 0:
            return x.copy()
        return gaussian_filter1d(x, sigma=float(param), mode="reflect")
    raise ValueError(f"Unknown smoothing kind: {kind}")


def coarse_grain(s: np.ndarray, x: np.ndarray, y: np.ndarray, n_bins: int) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    edges = np.linspace(float(s.min()), float(s.max()), int(n_bins) + 1)
    centers = 0.5 * (edges[:-1] + edges[1:])
    idx = np.digitize(s, edges) - 1
    idx = np.clip(idx, 0, n_bins - 1)

    xc = np.full(n_bins, np.nan, dtype=float)
    yc = np.full(n_bins, np.nan, dtype=float)

    for b in range(n_bins):
        m = idx == b
        if np.any(m):
            xc[b] = np.nanmean(x[m])
            yc[b] = np.nanmean(y[m])

    # fill gaps by interpolation if any empty bins arise
    good = np.isfinite(xc) & np.isfinite(yc)
    if np.sum(good) < 4:
        raise ValueError(f"Too few populated bins in coarse graining with {n_bins} bins.")

    xc = np.interp(centers, centers[good], xc[good])
    yc = np.interp(centers, centers[good], yc[good])

    return centers, xc, yc


def derivative_nonuniform(s: np.ndarray, x: np.ndarray, order: int = 1) -> np.ndarray:
    if order == 1:
        return np.gradient(x, s, edge_order=2)
    if order == 2:
        first = np.gradient(x, s, edge_order=2)
        return np.gradient(first, s, edge_order=2)
    raise ValueError("Only first and second derivatives are supported.")


def safe_corr(x: np.ndarray, y: np.ndarray) -> float:
    if len(x) != len(y) or len(x) < 3:
        return float("nan")
    sx = np.std(x)
    sy = np.std(y)
    if sx <= EPS or sy <= EPS:
        return float("nan")
    return float(np.corrcoef(x, y)[0, 1])


def normalize_mass(s: np.ndarray, x: np.ndarray) -> np.ndarray:
    z = enforce_nonnegative(x)
    total = np.trapezoid(z, s)
    if total <= EPS:
        return np.full_like(z, 1.0 / len(z))
    return z / total


def l2_error(s: np.ndarray, x: np.ndarray, y: np.ndarray) -> float:
    return float(np.sqrt(np.trapezoid((x - y) ** 2, s) / max(float(s.max() - s.min()), EPS)))


def w1_distance_1d(s: np.ndarray, p: np.ndarray, q: np.ndarray) -> float:
    p = normalize_mass(s, p)
    q = normalize_mass(s, q)
    cdf_p = np.cumsum(p)
    cdf_q = np.cumsum(q)
    cdf_p = cdf_p / max(cdf_p[-1], EPS)
    cdf_q = cdf_q / max(cdf_q[-1], EPS)
    ds_mean = float(np.mean(np.diff(s))) if len(s) > 1 else 1.0
    return float(np.sum(np.abs(cdf_p - cdf_q)) * ds_mean)


def js_distance_1d(s: np.ndarray, p: np.ndarray, q: np.ndarray) -> float:
    pp = normalize_mass(s, p) + EPS
    qq = normalize_mass(s, q) + EPS
    pp = pp / pp.sum()
    qq = qq / qq.sum()
    return float(jensenshannon(pp, qq, base=2.0))


def shift_signal_interp(s: np.ndarray, y: np.ndarray, delta: float) -> np.ndarray:
    f = interpolate.interp1d(
        s,
        y,
        kind="linear",
        bounds_error=False,
        fill_value=np.nan,
        assume_sorted=True,
    )
    ys = f(s + delta)
    if np.any(np.isnan(ys)):
        valid = np.isfinite(ys)
        if np.sum(valid) >= 2:
            ys = np.interp(s, s[valid], ys[valid])
        else:
            ys = np.nan_to_num(ys, nan=float(np.nanmean(y)))
    return ys


# ---------------------------------------------------------------------
# Core analyses
# ---------------------------------------------------------------------

def cross_correlation_with_lag(s: np.ndarray, source: np.ndarray, target: np.ndarray) -> Dict[str, float]:
    lags = np.linspace(-MAX_ABS_LAG, MAX_ABS_LAG, N_LAG_STEPS)
    corrs = []
    for lag in lags:
        target_shifted = shift_signal_interp(s, target, lag)
        corrs.append(safe_corr(source, target_shifted))
    corrs = np.array(corrs, dtype=float)

    if np.all(~np.isfinite(corrs)):
        return {
            "max_corr": float("nan"),
            "optimal_lag": float("nan"),
            "symmetry_indicator": float("nan"),
            "zero_lag_corr": float("nan"),
        }

    i_best = int(np.nanargmax(np.abs(corrs)))
    zero_idx = int(np.argmin(np.abs(lags)))
    symmetry_indicator = np.nanmean(np.abs(corrs - corrs[::-1]))

    return {
        "max_corr": safe_float(corrs[i_best]),
        "optimal_lag": safe_float(lags[i_best]),
        "symmetry_indicator": safe_float(symmetry_indicator),
        "zero_lag_corr": safe_float(corrs[zero_idx]),
    }


def make_kernel_from_distance_matrix(dist: np.ndarray, family: str, bandwidth: float) -> np.ndarray:
    u = dist / max(float(bandwidth), EPS)
    if family == "gaussian":
        K = np.exp(-0.5 * u ** 2)
    elif family == "exponential":
        K = np.exp(-np.abs(u))
    elif family == "compact_support":
        K = np.maximum(1.0 - np.abs(u), 0.0)
    else:
        raise ValueError(f"Unknown kernel family: {family}")

    row_sums = K.sum(axis=1, keepdims=True)
    row_sums[row_sums <= EPS] = 1.0
    return K / row_sums


def kernel_fit(s: np.ndarray, source: np.ndarray, target: np.ndarray) -> Dict[str, Any]:
    dist = np.abs(s[:, None] - s[None, :])
    best = None

    for family in ("gaussian", "exponential", "compact_support"):
        for bw in KERNEL_BANDWIDTHS:
            K = make_kernel_from_distance_matrix(dist, family=family, bandwidth=bw)
            conv = K @ source

            X = np.column_stack([np.ones(len(conv)), conv])
            beta, *_ = np.linalg.lstsq(X, target, rcond=None)
            pred = X @ beta

            record = {
                "kernel_family": family,
                "bandwidth": float(bw),
                "intercept": safe_float(beta[0]),
                "scale": safe_float(beta[1]),
                "l2_error": l2_error(s, pred, target),
                "wasserstein_1_distance": w1_distance_1d(s, pred, target),
                "js_distance": js_distance_1d(s, pred, target),
                "corr_pred_target": safe_float(safe_corr(pred, target)),
            }

            score = (
                2.0 * record["l2_error"]
                + 1.0 * record["wasserstein_1_distance"]
                + 1.0 * record["js_distance"]
                - 0.5 * abs(record["corr_pred_target"])
            )

            if (best is None) or (score < best["score"]):
                best = dict(record)
                best["score"] = float(score)

    assert best is not None
    return best


def spectral_comparison(s: np.ndarray, source: np.ndarray, target: np.ndarray) -> Dict[str, float]:
    # FFT assumes near-uniform spacing; Stage-6H contract recommends aligned sampling,
    # and the observed file is effectively uniform in s.
    ds = float(np.mean(np.diff(s))) if len(s) > 1 else 1.0

    x = source - np.mean(source)
    y = target - np.mean(target)

    X = np.fft.rfft(x)
    Y = np.fft.rfft(y)
    freqs = np.fft.rfftfreq(len(s), d=ds)

    Px = np.abs(X) ** 2
    Py = np.abs(Y) ** 2

    if len(freqs) <= 1:
        return {
            "dominant_mode_source": float("nan"),
            "dominant_mode_target": float("nan"),
            "spectral_overlap": float("nan"),
            "phase_shift_dominant": float("nan"),
        }

    # Ignore zero frequency for dominant mode
    idx = slice(1, None)
    ixs = int(np.argmax(Px[idx])) + 1
    iyt = int(np.argmax(Py[idx])) + 1

    num = float(np.sum(Px[idx] * Py[idx]))
    den = float(np.sqrt(np.sum(Px[idx] ** 2) * np.sum(Py[idx] ** 2)))
    spectral_overlap = num / den if den > EPS else float("nan")

    cross = X * np.conjugate(Y)
    phase_shift = float(np.angle(cross[ixs])) if ixs < len(cross) else float("nan")

    return {
        "dominant_mode_source": safe_float(freqs[ixs]),
        "dominant_mode_target": safe_float(freqs[iyt]),
        "spectral_overlap": safe_float(spectral_overlap),
        "phase_shift_dominant": safe_float(phase_shift),
    }


def lagged_distributional_alignment(s: np.ndarray, source: np.ndarray, target: np.ndarray) -> Dict[str, float]:
    lags = np.linspace(-MAX_ABS_LAG, MAX_ABS_LAG, N_LAG_STEPS)
    js_vals = []
    w1_vals = []

    source_mass = normalize_mass(s, source)
    base_js = js_distance_1d(s, source_mass, target)
    base_w1 = w1_distance_1d(s, source_mass, target)

    for lag in lags:
        shifted = shift_signal_interp(s, target, lag)
        js_vals.append(js_distance_1d(s, source_mass, shifted))
        w1_vals.append(w1_distance_1d(s, source_mass, shifted))

    js_vals = np.array(js_vals, dtype=float)
    w1_vals = np.array(w1_vals, dtype=float)

    i_js = int(np.nanargmin(js_vals))
    i_w1 = int(np.nanargmin(w1_vals))

    return {
        "optimal_shift_js": safe_float(lags[i_js]),
        "best_js_distance": safe_float(js_vals[i_js]),
        "js_improvement_gain": safe_float(base_js - js_vals[i_js]),
        "optimal_shift_w1": safe_float(lags[i_w1]),
        "best_w1_distance": safe_float(w1_vals[i_w1]),
        "w1_improvement_gain": safe_float(base_w1 - w1_vals[i_w1]),
    }


def ridge_differential_regression(s: np.ndarray, source: np.ndarray, target: np.ndarray) -> Dict[str, float]:
    d1 = derivative_nonuniform(s, source, order=1)
    d2 = derivative_nonuniform(s, source, order=2)

    X = np.column_stack([source, d1, d2])

    # standardize predictors for ridge stability
    mu = np.mean(X, axis=0)
    sd = np.std(X, axis=0)
    sd[sd <= EPS] = 1.0
    Xs = (X - mu) / sd

    best = None
    for alpha in RIDGE_ALPHAS:
        model = Ridge(alpha=float(alpha), fit_intercept=True)
        model.fit(Xs, target)
        pred = model.predict(Xs)

        ss_res = float(np.sum((target - pred) ** 2))
        ss_tot = float(np.sum((target - np.mean(target)) ** 2))
        r2 = 1.0 - ss_res / max(ss_tot, EPS)

        record = {
            "ridge_alpha": float(alpha),
            "intercept": safe_float(model.intercept_),
            "coef_source": safe_float(model.coef_[0]),
            "coef_source_d1": safe_float(model.coef_[1]),
            "coef_source_d2": safe_float(model.coef_[2]),
            "r2": safe_float(r2),
            "l2_error": l2_error(s, pred, target),
            "corr_pred_target": safe_float(safe_corr(pred, target)),
        }

        score = -record["r2"] + 0.5 * record["l2_error"] - 0.25 * abs(record["corr_pred_target"])
        if (best is None) or (score < best["score"]):
            best = dict(record)
            best["score"] = float(score)

    assert best is not None
    return best


def analyze_direction(variant: VariantData, source_name: str, source: np.ndarray, target_name: str, target: np.ndarray) -> Dict[str, Any]:
    s = variant.s

    cross = cross_correlation_with_lag(s, source, target)
    kernel = kernel_fit(s, source, target)
    spectral = spectral_comparison(s, source, target)
    lagged = lagged_distributional_alignment(s, source, target)
    ridge = ridge_differential_regression(s, source, target)

    record = {
        "variant_name": variant.variant_name,
        "variant_family": variant.family,
        "direction": f"{source_name}_to_{target_name}",
        "n_points": int(len(s)),
        "s_min": safe_float(np.min(s)),
        "s_max": safe_float(np.max(s)),
        "source_mean": safe_float(np.mean(source)),
        "target_mean": safe_float(np.mean(target)),
    }
    record.update({f"cross_{k}": v for k, v in cross.items()})
    record.update({f"kernel_{k}": v for k, v in kernel.items()})
    record.update({f"spectral_{k}": v for k, v in spectral.items()})
    record.update({f"lagged_{k}": v for k, v in lagged.items()})
    record.update({f"ridge_{k}": v for k, v in ridge.items()})
    return record


# ---------------------------------------------------------------------
# Pipeline construction
# ---------------------------------------------------------------------

def build_variants(s: np.ndarray, kappa: np.ndarray, rho: np.ndarray) -> List[VariantData]:
    variants: List[VariantData] = []

    for spec in SMOOTHING_VARIANTS:
        kind = spec["kind"]
        param = spec["param"]
        ks = smooth_signal(kappa, kind, param)
        rs = smooth_signal(rho, kind, param)
        name = f"{kind}:{param}"
        variants.append(
            VariantData(
                variant_name=name,
                family="smoothing",
                s=s.copy(),
                kappa=ks,
                rho=rs,
                meta={"kind": kind, "param": param},
            )
        )

    for bins in COARSE_BIN_COUNTS:
        sc, kc, rc = coarse_grain(s, kappa, rho, int(bins))
        name = f"coarse:{bins}"
        variants.append(
            VariantData(
                variant_name=name,
                family="coarse",
                s=sc,
                kappa=kc,
                rho=rc,
                meta={"n_bins": int(bins)},
            )
        )

    return variants


def stability_summary(profile_df: pd.DataFrame) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    if profile_df.empty:
        return out

    # Compute range over variants, per direction, for key metrics.
    metric_map = {
        "cross_corr_optimal_lag_range": "cross_optimal_lag",
        "cross_corr_max_corr_range": "cross_max_corr",
        "lagged_align_shift_range": "lagged_optimal_shift_w1",
        "lagged_align_gain_range": "lagged_w1_improvement_gain",
        "ridge_r2_range": "ridge_r2",
        "kernel_l2_range": "kernel_l2_error",
        "spectral_overlap_range": "spectral_spectral_overlap",
    }

    per_direction = {}
    for direction, g in profile_df.groupby("direction"):
        info = {}
        for label, col in metric_map.items():
            vals = pd.to_numeric(g[col], errors="coerce").to_numpy(dtype=float)
            vals = vals[np.isfinite(vals)]
            if len(vals) == 0:
                rng = float("nan")
                stable = False
            else:
                rng = float(np.max(vals) - np.min(vals))
                stable = bool(rng <= STABILITY_THRESHOLDS[label])
            info[label] = rng
            info[label.replace("_range", "_stable")] = stable
        per_direction[direction] = info

    out["per_direction"] = per_direction
    return out


def choose_best_evidence(profile_df: pd.DataFrame) -> Dict[str, Any]:
    """
    Build a practical, transparent ranking of evidence by method/direction.
    """
    out: Dict[str, Any] = {}

    best_cross = []
    for direction, g in profile_df.groupby("direction"):
        gg = g.copy()
        gg["score"] = gg["cross_max_corr"].abs() - 0.5 * gg["cross_symmetry_indicator"].fillna(0.0)
        idx = gg["score"].astype(float).idxmax()
        best_cross.append(gg.loc[idx].to_dict())
    out["best_cross_correlation"] = best_cross

    best_kernel = []
    for direction, g in profile_df.groupby("direction"):
        idx = g["kernel_l2_error"].astype(float).idxmin()
        best_kernel.append(g.loc[idx].to_dict())
    out["best_kernel_fit"] = best_kernel

    best_lagged = []
    for direction, g in profile_df.groupby("direction"):
        gg = g.copy()
        gg["score"] = gg["lagged_w1_improvement_gain"].fillna(0.0) + gg["lagged_js_improvement_gain"].fillna(0.0)
        idx = gg["score"].astype(float).idxmax()
        best_lagged.append(gg.loc[idx].to_dict())
    out["best_lagged_alignment"] = best_lagged

    best_ridge = []
    for direction, g in profile_df.groupby("direction"):
        idx = g["ridge_r2"].astype(float).idxmax()
        best_ridge.append(g.loc[idx].to_dict())
    out["best_ridge_regression"] = best_ridge

    best_spectral = []
    for direction, g in profile_df.groupby("direction"):
        idx = g["spectral_spectral_overlap"].astype(float).idxmax()
        best_spectral.append(g.loc[idx].to_dict())
    out["best_spectral"] = best_spectral

    return out


def infer_stage_success(profile_df: pd.DataFrame, stability: Dict[str, Any]) -> Dict[str, Any]:
    """
    Transparent inference aligned with Stage-6I contract:
      (A) intrinsic operator relation exists
      (B) relation is weak / indirect / nonlocal
      (C) no meaningful operator structure
    """
    verdict = "C"
    reasons: List[str] = []

    # Aggregate across both directions.
    max_abs_corr = float(np.nanmax(np.abs(pd.to_numeric(profile_df["cross_max_corr"], errors="coerce"))))
    max_ridge_r2 = float(np.nanmax(pd.to_numeric(profile_df["ridge_r2"], errors="coerce")))
    max_spectral_overlap = float(np.nanmax(pd.to_numeric(profile_df["spectral_spectral_overlap"], errors="coerce")))
    max_lag_gain = float(np.nanmax(pd.to_numeric(profile_df["lagged_w1_improvement_gain"], errors="coerce")))

    # Stability count
    stable_count = 0
    total_checks = 0
    for _, info in stability.get("per_direction", {}).items():
        for k, v in info.items():
            if k.endswith("_stable"):
                total_checks += 1
                stable_count += int(bool(v))
    stability_fraction = (stable_count / total_checks) if total_checks > 0 else 0.0

    if (
        (max_abs_corr >= 0.60 and max_ridge_r2 >= 0.50)
        or (max_abs_corr >= 0.55 and max_spectral_overlap >= 0.75 and stability_fraction >= 0.55)
    ):
        verdict = "A"
        reasons.append("Strong operator-level evidence: at least one combination of correlation/regression/spectral diagnostics is sizable and reasonably stable.")
    elif (
        (max_abs_corr >= 0.30)
        or (max_ridge_r2 >= 0.20)
        or (max_lag_gain >= 0.01)
        or (max_spectral_overlap >= 0.50)
    ):
        verdict = "B"
        reasons.append("Partial but nontrivial evidence detected: relations appear weak, indirect, shifted, or nonlocal rather than strongly local.")
    else:
        verdict = "C"
        reasons.append("No method reached even a modest and stable operator-level signal.")

    return {
        "interpretation_target": {
            "A": "intrinsic operator relation exists",
            "B": "relation is weak / indirect / nonlocal",
            "C": "no meaningful operator structure",
        },
        "verdict": verdict,
        "stable_checks_fraction": stability_fraction,
        "aggregate_metrics": {
            "max_abs_cross_corr": max_abs_corr,
            "max_ridge_r2": max_ridge_r2,
            "max_spectral_overlap": max_spectral_overlap,
            "max_lagged_w1_gain": max_lag_gain,
        },
        "reasons": reasons,
        "successful_under_contract": bool(verdict in ("A", "B")),
    }


def build_notes_text(summary: Dict[str, Any]) -> str:
    verdict = summary["stage6I_verdict"]["verdict"]
    reasons = summary["stage6I_verdict"]["reasons"]
    agg = summary["stage6I_verdict"]["aggregate_metrics"]

    lines = []
    lines.append("============================================================")
    lines.append("STAGE-6I OPERATOR NOTES")
    lines.append("Project: Quantum-Emergent Gravity")
    lines.append("============================================================")
    lines.append("")
    lines.append("DECISIVE VERDICT")
    lines.append("----------------")
    lines.append(f"{verdict}")
    lines.append("")
    lines.append("AGGREGATE SIGNALS")
    lines.append("-----------------")
    lines.append(f"max_abs_cross_corr: {agg['max_abs_cross_corr']}")
    lines.append(f"max_ridge_r2: {agg['max_ridge_r2']}")
    lines.append(f"max_spectral_overlap: {agg['max_spectral_overlap']}")
    lines.append(f"max_lagged_w1_gain: {agg['max_lagged_w1_gain']}")
    lines.append("")
    lines.append("INTERPRETATION")
    lines.append("--------------")
    for r in reasons:
        lines.append(f"- {r}")
    lines.append("")
    lines.append("METHOD SUMMARY")
    lines.append("--------------")
    lines.append("Stage-6I compares curvature and density as intrinsic fields on s via:")
    lines.append("1) lagged cross-correlation,")
    lines.append("2) kernel-response fitting,")
    lines.append("3) spectral overlap and phase comparisons,")
    lines.append("4) lagged distributional alignment, and")
    lines.append("5) regularized differential regression.")
    lines.append("")
    lines.append("These diagnostics are repeated under smoothing and coarse-graining")
    lines.append("to test parameter stability rather than relying on a single raw-scale fit.")
    lines.append("")
    return "\n".join(lines)


# ---------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------

def main() -> int:
    try:
        log("[Stage-6I PRECHECK] Discovering project root...")
        root = discover_project_root()
        log(f"[Stage-6I PRECHECK] Project root: {root}")

        input_csv = first_existing(INPUT_CANDIDATES, root)
        if input_csv is None:
            raise FileNotFoundError(
                "Could not locate stage6H_distributional_profile.csv in expected locations."
            )

        optional_summary = first_existing(OPTIONAL_SUMMARY_CANDIDATES, root)
        optional_notes = first_existing(OPTIONAL_NOTES_CANDIDATES, root)

        output_dir = root / OUTPUT_DIR_NAME
        output_dir.mkdir(parents=True, exist_ok=True)

        log("[Stage-6I PRECHECK] Loading Stage-6H profile...")
        df = pd.read_csv(input_csv)
        log(f"[Stage-6I PRECHECK] Input rows, cols: {df.shape}")
        log(f"[Stage-6I PRECHECK] Columns: {list(df.columns)}")

        s_col = choose_s_column(df)
        required_cols = [s_col, "abs_kappa", "density"]
        for col in required_cols:
            if col not in df.columns:
                raise ValueError(f"Missing required column `{col}` in input profile.")

        s = ensure_numeric_series(df[s_col], s_col)
        kappa = ensure_numeric_series(df["abs_kappa"], "abs_kappa")
        rho = ensure_numeric_series(df["density"], "density")

        s, kappa, rho = remove_invalid_rows(s, kappa, rho)
        s, kappa, rho = monotone_sort(s, kappa, rho)

        # normalize s if needed
        if s_col != "s_normalized":
            s = normalize_01(s)

        # final sanity
        if np.any(np.diff(s) < -EPS):
            raise ValueError("Intrinsic coordinate is not monotone after sorting.")
        if np.nanmin(kappa) < -EPS:
            log("[Stage-6I PRECHECK] Warning: abs_kappa has negative entries after coercion; clipping to 0.")
            kappa = enforce_nonnegative(kappa)
        if np.nanmin(rho) < -EPS:
            log("[Stage-6I PRECHECK] Warning: density has negative entries after coercion; clipping to 0.")
            rho = enforce_nonnegative(rho)

        log("[Stage-6I ANALYSIS] Building smoothing and coarse-grained variants...")
        variants = build_variants(s, kappa, rho)
        log(f"[Stage-6I ANALYSIS] Total variants: {len(variants)}")

        log("[Stage-6I ANALYSIS] Running operator diagnostics in both directions...")
        records: List[Dict[str, Any]] = []
        for variant in variants:
            records.append(analyze_direction(variant, "kappa", variant.kappa, "rho", variant.rho))
            records.append(analyze_direction(variant, "rho", variant.rho, "kappa", variant.kappa))

        profile_df = pd.DataFrame(records)
        profile_path = output_dir / "stage6I_operator_profile.csv"
        profile_df.to_csv(profile_path, index=False)

        log("[Stage-6I ANALYSIS] Computing stability summary and overall verdict...")
        stability = stability_summary(profile_df)
        best_evidence = choose_best_evidence(profile_df)
        verdict = infer_stage_success(profile_df, stability)

        summary = {
            "script_version": SCRIPT_VERSION,
            "input_profile": str(input_csv),
            "optional_summary_used": str(optional_summary) if optional_summary else None,
            "optional_notes_used": str(optional_notes) if optional_notes else None,
            "configuration": {
                "smoothing_variants": SMOOTHING_VARIANTS,
                "coarse_bin_counts": COARSE_BIN_COUNTS,
                "max_abs_lag": MAX_ABS_LAG,
                "n_lag_steps": N_LAG_STEPS,
                "kernel_bandwidths": KERNEL_BANDWIDTHS,
                "ridge_alphas": RIDGE_ALPHAS,
                "stability_thresholds": STABILITY_THRESHOLDS,
            },
            "input_contract_observed": {
                "rows": int(len(s)),
                "s_column_used": s_col,
                "s_is_normalized_output": True,
                "required_columns_present": all(c in df.columns for c in required_cols),
                "optional_columns_present": [c for c in ["kappa", "ds_dtheta"] if c in df.columns],
            },
            "best_evidence": best_evidence,
            "stability": stability,
            "stage6I_verdict": verdict,
        }

        summary_path = output_dir / "stage6I_operator_summary.json"
        with open(summary_path, "w", encoding="utf-8") as f:
            json.dump(json_ready(summary), f, indent=2)

        notes_text = build_notes_text(summary)
        notes_path = output_dir / "stage6I_operator_notes.txt"
        with open(notes_path, "w", encoding="utf-8") as f:
            f.write(notes_text)

        log("[Stage-6I DONE] Outputs written:")
        log(f"  - {profile_path}")
        log(f"  - {summary_path}")
        log(f"  - {notes_path}")
        return 0

    except Exception as exc:
        log("[Stage-6I ERROR] Execution failed.")
        log(f"[Stage-6I ERROR] {exc}")
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
