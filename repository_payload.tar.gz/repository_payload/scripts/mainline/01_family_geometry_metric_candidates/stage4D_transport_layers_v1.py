#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Feb 12 21:03:50 2026

@author: Arturo Ortiz-Tapia
Stage-4D (Option A): OT + Procrustes + Obstruction layers
Reads Stage-4C canonical microfeatures CSV and populates:
  - ot_cost_mean
  - procrustes_resid
  - obstruction_score

Designed to reuse existing Stage-3A NPZ assets (no Stage-3A regen).
Robust NPZ discovery + key introspection.

Run (from anywhere):
  python stage4D_transport_layers_v1.py --repo_root "/home/dakini/Downloads/010-Quantum_Emergent_Gravity"

Outputs:
  - Updated CSV (copy) with filled columns
  - Diagnostics JSON (per row) for auditing
  - Evidence ledger append (if evidence module present); otherwise prints block
"""

from __future__ import annotations

import argparse
import datetime as _dt
import glob
import hashlib
import json
import os
import sys
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

# Optional SciPy; we fall back to a greedy matcher if SciPy isn't available.
try:
    from scipy.optimize import linear_sum_assignment
except Exception:
    linear_sum_assignment = None


# -------------------------
# Helpers: hashing, IO, logs
# -------------------------

def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)


def now_iso() -> str:
    return _dt.datetime.now().isoformat(timespec="seconds")


def eprint(*args) -> None:
    print(*args, file=sys.stderr)


def stable_float(x) -> Optional[float]:
    try:
        if x is None:
            return None
        if isinstance(x, float) and (np.isnan(x) or np.isinf(x)):
            return None
        y = float(x)
        if np.isnan(y) or np.isinf(y):
            return None
        return y
    except Exception:
        return None


# -------------------------
# NPZ choice ranking
# -------------------------

def rank_npz(p: str) -> tuple:
    """
    Lower tuple = higher priority.
    Prefer metric_stage_3A_outputs, prefer stage3A__eigshells, then zscore variants.
    """
    pl = p.lower()
    return (
        0 if "metric_stage_3a_outputs" in pl else 1,
        0 if "stage3a__eigshells" in pl else 1,
        0 if "__zscore__signed" in pl else 1,
        0 if "__zscore__abs" in pl else 1,
        0 if "__zscore__drop" in pl else 1,
        len(p),
    )


# -------------------------
# NPZ extraction heuristics
# -------------------------

@dataclass
class ShellData:
    shells: List[np.ndarray]          # list of (n_i, 2) arrays
    source_npz: str
    used_keys: List[str]
    notes: List[str]


def _as_2d_points(arr: np.ndarray) -> Optional[np.ndarray]:
    """
    Convert arr into (n,2) point cloud if possible.
    Accepts:
      - complex vector -> (Re, Im)
      - real (n,2)
      - real (n,) -> (x, 0)
      - real (2,n) -> transpose to (n,2)
    """
    if arr is None:
        return None
    a = np.array(arr)

    if a.size == 0:
        return None

    # Complex -> 2D
    if np.iscomplexobj(a):
        a = a.ravel()
        pts = np.column_stack([a.real, a.imag]).astype(float)
        return pts

    # If it's 1D -> embed as (x,0)
    if a.ndim == 1:
        x = a.astype(float).ravel()
        return np.column_stack([x, np.zeros_like(x)])

    # If (n,2)
    if a.ndim == 2 and a.shape[1] == 2:
        return a.astype(float)

    # If (2,n)
    if a.ndim == 2 and a.shape[0] == 2 and a.shape[1] != 2:
        return a.T.astype(float)

    return None


def extract_shells_from_npz(npz_path: str) -> Optional[ShellData]:
    """
    Heuristics:
      1) Object array/list of shells (dtype=object), 1D -> list of shells
      2) 3D array (K, n, 2) etc -> axis0 as shells
      3) 2D array (K, n) etc -> axis0 as shells
      4) Otherwise: multiple candidate arrays treated as shells (sorted by key)
    """
    used_keys: List[str] = []
    notes: List[str] = []

    try:
        with np.load(npz_path, allow_pickle=True) as z:
            keys = sorted(list(z.keys()))
            if not keys:
                return None

            preferred = [
                "eigshells", "eig_shells", "shells",
                "evals_shells", "eigvals_shells", "lambda_shells",
                "eigen_shells", "spectral_shells",
                "eigvals", "evals", "eigs", "lambda",
            ]

            def get_key(k):
                return z[k]

            # 1) object-array shells
            for k in preferred + keys:
                if k in z:
                    a = get_key(k)
                    if isinstance(a, np.ndarray) and a.dtype == object and a.ndim == 1:
                        shells: List[np.ndarray] = []
                        ok = True
                        for item in a.tolist():
                            pts = _as_2d_points(np.array(item))
                            if pts is None or pts.shape[0] < 3:
                                ok = False
                                break
                            shells.append(pts)
                        if ok and len(shells) >= 2:
                            used_keys.append(k)
                            notes.append(f"Used object-shell list from key '{k}'.")
                            return ShellData(shells=shells, source_npz=npz_path, used_keys=used_keys, notes=notes)

            # 2) 3D arrays -> shells along axis0
            for k in preferred + keys:
                if k in z:
                    a = get_key(k)
                    if isinstance(a, np.ndarray) and a.ndim == 3:
                        shells: List[np.ndarray] = []
                        for i in range(a.shape[0]):
                            pts = _as_2d_points(a[i])
                            if pts is None or pts.shape[0] < 3:
                                continue
                            shells.append(pts)
                        if len(shells) >= 2:
                            used_keys.append(k)
                            notes.append(f"Used 3D array shells from key '{k}' with K={a.shape[0]}.")
                            return ShellData(shells=shells, source_npz=npz_path, used_keys=used_keys, notes=notes)

            # 3) 2D arrays -> shells along axis0 if K>=2
            for k in preferred + keys:
                if k in z:
                    a = get_key(k)
                    if isinstance(a, np.ndarray) and a.ndim == 2 and a.shape[0] >= 2 and a.shape[1] >= 3:
                        shells: List[np.ndarray] = []
                        for i in range(a.shape[0]):
                            pts = _as_2d_points(a[i])
                            if pts is None or pts.shape[0] < 3:
                                continue
                            shells.append(pts)
                        if len(shells) >= 2:
                            used_keys.append(k)
                            notes.append(f"Used 2D array as shells from key '{k}' with K={a.shape[0]}.")
                            return ShellData(shells=shells, source_npz=npz_path, used_keys=used_keys, notes=notes)

            # 4) Otherwise: collect candidate arrays as shells
            candidates: List[Tuple[str, np.ndarray]] = []
            for k in keys:
                a = get_key(k)
                if not isinstance(a, np.ndarray):
                    continue
                pts = _as_2d_points(a)
                if pts is not None and pts.shape[0] >= 3:
                    candidates.append((k, pts))

            if len(candidates) >= 2:
                candidates.sort(key=lambda kv: kv[0])
                used_keys.extend([k for k, _ in candidates])
                notes.append("Used multiple 2D candidates as shells (sorted by key).")
                shells = [pts for _, pts in candidates]
                return ShellData(shells=shells, source_npz=npz_path, used_keys=used_keys, notes=notes)

            return None

    except Exception as ex:
        eprint(f"[extract_shells_from_npz] Failed on {npz_path}: {ex}")
        return None


# -------------------------
# Geometry: OT + Procrustes
# -------------------------

def _downsample_to_equal(a: np.ndarray, b: np.ndarray, seed: int = 0) -> Tuple[np.ndarray, np.ndarray]:
    rng = np.random.default_rng(seed)
    n = min(a.shape[0], b.shape[0])
    if a.shape[0] > n:
        idx = rng.choice(a.shape[0], size=n, replace=False)
        a = a[idx]
    if b.shape[0] > n:
        idx = rng.choice(b.shape[0], size=n, replace=False)
        b = b[idx]
    return a, b


def ot_assignment_cost(a: np.ndarray, b: np.ndarray) -> float:
    a2, b2 = _downsample_to_equal(a, b, seed=0)
    if a2.shape[0] < 3:
        return np.nan

    diff = a2[:, None, :] - b2[None, :, :]
    D = np.sqrt(np.sum(diff * diff, axis=2))

    if linear_sum_assignment is None:
        # Greedy fallback (deterministic)
        n = D.shape[0]
        used = set()
        total = 0.0
        for i in range(n):
            best_j = None
            best = np.inf
            for jj in range(n):
                if jj in used:
                    continue
                if D[i, jj] < best:
                    best = D[i, jj]
                    best_j = jj
            used.add(int(best_j))
            total += float(best)
        return total / n

    row_ind, col_ind = linear_sum_assignment(D)
    return float(D[row_ind, col_ind].mean())


def procrustes_residual(a: np.ndarray, b: np.ndarray) -> float:
    a2, b2 = _downsample_to_equal(a, b, seed=0)
    if a2.shape[0] < 3:
        return np.nan

    a0 = a2 - a2.mean(axis=0, keepdims=True)
    b0 = b2 - b2.mean(axis=0, keepdims=True)

    na = np.linalg.norm(a0)
    nb = np.linalg.norm(b0)
    if na == 0 or nb == 0:
        return np.nan
    a0 /= na
    b0 /= nb

    M = b0.T @ a0
    U, _, Vt = np.linalg.svd(M)
    R = U @ Vt
    b_aligned = b0 @ R

    err = a0 - b_aligned
    return float(np.sqrt((err * err).sum(axis=1)).mean())


# -------------------------
# Repo discovery + main
# -------------------------

def find_repo_root(user_repo_root: Optional[str]) -> str:
    if user_repo_root and os.path.isdir(user_repo_root):
        return os.path.abspath(user_repo_root)

    here = os.path.abspath(os.path.dirname(__file__))
    cur = here
    for _ in range(6):
        if os.path.isdir(os.path.join(cur, "__qeg_evidence__")):
            return cur
        nxt = os.path.dirname(cur)
        if nxt == cur:
            break
        cur = nxt

    raise FileNotFoundError("Could not determine repo_root. Pass --repo_root explicitly.")


def find_stage4c_canonical_csv(repo_root: str, explicit_path: Optional[str]) -> str:
    if explicit_path and os.path.isfile(explicit_path):
        return os.path.abspath(explicit_path)

    patt = os.path.join(repo_root, "**", "stage4C_microfeatures_canonical_v1.csv")
    hits = glob.glob(patt, recursive=True)
    if not hits:
        raise FileNotFoundError(f"Could not find canonical CSV via pattern: {patt}")

    hits.sort(key=lambda p: (("metric_stage_4C_outputs" not in p), len(p)))
    return os.path.abspath(hits[0])


def discover_npz_for_row(repo_root: str, fit_id: str, metric_id: str) -> List[str]:
    """
    Broad brute-force NPZ discovery across the repo (Option-A safe).
    Finds all .npz under repo_root and filters those whose path contains BOTH
    fit_id and metric_id (case-insensitive substring match).
    """
    all_npz = glob.glob(os.path.join(repo_root, "**", "*.npz"), recursive=True)

    f = str(fit_id).lower()
    m = str(metric_id).lower()

    hits = []
    for p in all_npz:
        full = p.lower()
        if (f in full) and (m in full):
            hits.append(p)

    return sorted(list(set(hits)))


def choose_output_dir(repo_root: str) -> str:
    d4 = os.path.join(repo_root, "metric_stage_4D_outputs")
    if os.path.isdir(d4):
        return d4
    d4c = os.path.join(repo_root, "metric_stage_4C_outputs")
    if os.path.isdir(d4c):
        return d4c
    return repo_root


def compute_obstruction(df: pd.DataFrame) -> pd.Series:
    cols = ["holonomy_dev_mean", "ot_cost_mean", "procrustes_resid"]
    z = {}
    for c in cols:
        x = pd.to_numeric(df[c], errors="coerce")
        mu = x.mean(skipna=True)
        sig = x.std(skipna=True, ddof=0)
        if sig == 0 or np.isnan(sig):
            z[c] = pd.Series(np.nan, index=df.index)
        else:
            z[c] = (x - mu) / sig
    return z["holonomy_dev_mean"] + z["ot_cost_mean"] + z["procrustes_resid"]


def maybe_append_evidence(repo_root: str, payload: Dict) -> bool:
    """
    If __qeg_evidence__/evidence.py exists and has append_entry, use it.
    Otherwise return False and the caller will print a manual block.
    """
    ev_dir = os.path.join(repo_root, "__qeg_evidence__")
    ev_py = os.path.join(ev_dir, "evidence.py")
    if not os.path.isfile(ev_py):
        return False

    try:
        sys.path.insert(0, ev_dir)
        import evidence  # type: ignore

        if hasattr(evidence, "append_entry"):
            evidence.append_entry(**payload)  # type: ignore
            return True
        return False
    except Exception as ex:
        eprint(f"[evidence] Could not append via evidence.py: {ex}")
        return False


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo_root", default=None, help="Repo root path.")
    ap.add_argument("--canonical_csv", default=None, help="Explicit path to stage4C_microfeatures_canonical_v1.csv")
    ap.add_argument("--write_csv_name", default="stage4C_microfeatures_canonical_v1_plus_transport_v1.csv")
    ap.add_argument("--diagnostics_subdir", default="stage4D_transport_diagnostics_v1")
    ap.add_argument("--dry_run", action="store_true", help="Compute but do not write outputs.")
    args = ap.parse_args()

    repo_root = find_repo_root(args.repo_root)
    canonical_csv = find_stage4c_canonical_csv(repo_root, args.canonical_csv)

    total_npz = len(glob.glob(os.path.join(repo_root, "**", "*.npz"), recursive=True))
    print(f"[npz_index] total_npz_found={total_npz}")

    out_dir = choose_output_dir(repo_root)
    diag_dir = os.path.join(out_dir, args.diagnostics_subdir)
    ensure_dir(diag_dir)

    df = pd.read_csv(canonical_csv)

    required = {"FIT_id", "metric_id", "holonomy_dev_mean", "ot_cost_mean", "procrustes_resid", "obstruction_score"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Canonical CSV missing required columns: {sorted(list(missing))}")

    row_diags = []
    for idx, row in df.iterrows():
        fit_id = str(row["FIT_id"])
        metric_id = str(row["metric_id"])

        npz_hits = discover_npz_for_row(repo_root, fit_id, metric_id)

        # --- strict pairing guard (exact FIT + metric token match) ---
        token_metric = f"__{metric_id}__".lower()
        token_fit = f"__{fit_id}__".lower()
        npz_hits = [p for p in npz_hits if (token_metric in p.lower()) and (token_fit in p.lower())]

        # --- deterministic ranking (Stage-3A preferred) ---
        npz_hits = sorted(npz_hits, key=rank_npz)

        diag = {
            "row_index": int(idx),
            "FIT_id": fit_id,
            "metric_id": metric_id,
            "npz_hits": npz_hits,
            "chosen_npz": None,
            "used_keys": [],
            "notes": [],
            "ot_pair_costs": [],
            "procrustes_shell_resids": [],
            "ot_cost_mean": None,
            "procrustes_resid": None,
        }

        if not npz_hits:
            diag["notes"].append("No NPZ found for this row after strict token filter; leaving OT/Procrustes as NaN.")
            row_diags.append(diag)
            continue

        # choose the first extractable NPZ (deterministic after sorting)
        shell_data = None
        for p in npz_hits:
            sd = extract_shells_from_npz(p)
            if sd is not None and len(sd.shells) >= 2:
                shell_data = sd
                break

        if shell_data is None:
            diag["notes"].append("NPZs found but none yielded >=2 valid shells; leaving NaN.")
            row_diags.append(diag)
            continue

        diag["chosen_npz"] = shell_data.source_npz
        diag["used_keys"] = shell_data.used_keys
        diag["notes"].extend(shell_data.notes)

        shells = shell_data.shells

        # OT: consecutive shells
        ot_costs = []
        for k in range(len(shells) - 1):
            c = ot_assignment_cost(shells[k], shells[k + 1])
            if not np.isnan(c):
                ot_costs.append(float(c))
        diag["ot_pair_costs"] = ot_costs
        ot_mean = float(np.mean(ot_costs)) if ot_costs else np.nan

        # Procrustes: align each shell to shell0
        pres = []
        ref = shells[0]
        for k in range(len(shells)):
            r = procrustes_residual(ref, shells[k])
            if not np.isnan(r):
                pres.append(float(r))
        diag["procrustes_shell_resids"] = pres
        pro_mean = float(np.mean(pres)) if pres else np.nan

        diag["ot_cost_mean"] = stable_float(ot_mean)
        diag["procrustes_resid"] = stable_float(pro_mean)

        df.at[idx, "ot_cost_mean"] = ot_mean
        df.at[idx, "procrustes_resid"] = pro_mean

        row_diags.append(diag)

    # obstruction score (z-summed)
    df["obstruction_score"] = compute_obstruction(df)

    if args.dry_run:
        print("[dry_run] Completed computations; no files written.")
        print(df[["FIT_id", "metric_id", "ot_cost_mean", "procrustes_resid", "obstruction_score"]])
        return 0

    # Write outputs
    out_csv = os.path.join(os.path.dirname(canonical_csv), args.write_csv_name)
    df.to_csv(out_csv, index=False)

    diag_path = os.path.join(diag_dir, f"stage4D_transport_diagnostics_{now_iso().replace(':','-')}.json")
    with open(diag_path, "w", encoding="utf-8") as f:
        json.dump({"generated_at": now_iso(), "canonical_csv": canonical_csv, "rows": row_diags}, f, indent=2)

    # Hashes for evidence
    payload = {
        "stage": "Stage-4D",
        "script_name": os.path.relpath(__file__, repo_root),
        "script_version": "v1",
        "inputs": {
            "canonical_csv": canonical_csv,
            "canonical_csv_sha256": sha256_file(canonical_csv),
        },
        "outputs_written": {
            "out_csv": out_csv,
            "out_csv_sha256": sha256_file(out_csv),
            "diagnostics_json": diag_path,
            "diagnostics_json_sha256": sha256_file(diag_path),
        },
        "row_counts": {
            "rows_total": int(df.shape[0]),
            "ot_filled": int(pd.to_numeric(df["ot_cost_mean"], errors="coerce").notna().sum()),
            "procrustes_filled": int(pd.to_numeric(df["procrustes_resid"], errors="coerce").notna().sum()),
            "obstruction_filled": int(pd.to_numeric(df["obstruction_score"], errors="coerce").notna().sum()),
        },
        "notes": [
            "Option A: comm_norm path; no R_k transport matrices.",
            "OT cost computed via assignment (Hungarian) on consecutive shells.",
            "Procrustes residual computed by orthogonal alignment to shell0.",
            "Obstruction score = z(holonomy_dev_mean)+z(ot_cost_mean)+z(procrustes_resid) within canonical table.",
            "NPZ pairing patched: strict __FIT__/__metric__ token filter + deterministic NPZ ranking.",
        ],
        "timestamp": now_iso(),
    }

    appended = maybe_append_evidence(repo_root, payload)
    if appended:
        print("[evidence] Appended entry via __qeg_evidence__/evidence.py")
    else:
        print("\nMANUAL_EVIDENCE_LEDGER_BLOCK (paste into __qeg_evidence__/EVIDENCE_LEDGER.md):")
        print("----")
        print(f"- timestamp: {payload['timestamp']}")
        print(f"  stage: {payload['stage']}")
        print(f"  script: {payload['script_name']} ({payload['script_version']})")
        print(f"  inputs: {os.path.relpath(canonical_csv, repo_root)} sha256={payload['inputs']['canonical_csv_sha256']}")
        print(f"  outputs: {os.path.relpath(out_csv, repo_root)} sha256={payload['outputs_written']['out_csv_sha256']}")
        print(f"           {os.path.relpath(diag_path, repo_root)} sha256={payload['outputs_written']['diagnostics_json_sha256']}")
        print(f"  row_counts: {payload['row_counts']}")
        print("  notes:")
        for n in payload["notes"]:
            print(f"    - {n}")
        print("----\n")

    print(f"[done] Wrote: {out_csv}")
    print(f"[done] Wrote: {diag_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
