#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
metric_stage_6B_evaluate_candidate_metrics_from_stage6A_v1.py

Stage-6B diagnostic evaluation of candidate metrics produced by Stage-6A.

Purpose
-------
Evaluate the behavior of Stage-6A candidate metric families across FITs and
parameter settings, with explicit emphasis on compatibility with the angular
intrinsic structure established in Stage-5.

This script is DIAGNOSTIC. It does not claim a final metric selection, assign
physical meaning, or compare to cosmological constants.

Inputs (authoritative upstream Stage-6A outputs)
------------------------------------------------
- stage6A_metric_candidates_pairwise_distances_v1.csv
- stage6A_metric_candidates_summary_v1.json
- stage6A_provenance_v1.json

Outputs
-------
- stage6B_metric_evaluation_table_v1.csv
- stage6B_metric_evaluation_summary_v1.json
- stage6B_interpretive_notes_v1.txt

Core diagnostics
----------------
1) Cross-FIT consistency
2) Parameter stability
3) Angular compatibility
4) Component balance / dominance
5) Within-FIT smoothness along metric_id
6) Degeneracy / collapse
7) Angular monotonicity consistency (added explicitly)
8) Family-level heuristic ranking (diagnostic only)

Implementation note
-------------------
This script begins with an explicit archive/schema PRECHECK block. That is now
considered part of the normal reproducibility pipeline after the Stage-6A schema
mismatch incident.
"""

from __future__ import annotations

import json
import math
import os
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd


# =============================================================================
# USER-ADJUSTABLE PATHS
# =============================================================================

PROJECT_ROOT = Path("/home/dakini/Downloads/010-Quantum_Emergent_Gravity")
INPUT_DIR = PROJECT_ROOT / "metric_stage_6A_outputs"
OUTPUT_DIR = PROJECT_ROOT / "metric_stage_6B_outputs"

PAIRWISE_CSV = INPUT_DIR / "stage6A_metric_candidates_pairwise_distances_v1.csv"
SUMMARY_JSON = INPUT_DIR / "stage6A_metric_candidates_summary_v1.json"
PROVENANCE_JSON = INPUT_DIR / "stage6A_provenance_v1.json"

OUTPUT_CSV = OUTPUT_DIR / "stage6B_metric_evaluation_table_v1.csv"
OUTPUT_JSON = OUTPUT_DIR / "stage6B_metric_evaluation_summary_v1.json"
OUTPUT_TXT = OUTPUT_DIR / "stage6B_interpretive_notes_v1.txt"


# =============================================================================
# CONSTANTS / REQUIRED SCHEMA
# =============================================================================

REQUIRED_COLUMNS = [
    "FIT",
    "metric_id_i",
    "metric_id_j",
    "metric_name",
    "alpha",
    "beta",
    "distance_squared",
    "dr",
    "dtheta",
    "r_i",
    "r_j",
]

EXPECTED_FITS = ["NUFIT", "VALENCIA", "BARI"]

EPS = 1e-12
DEGENERACY_ROUND_DECIMALS = 10
SMOOTHNESS_NEAR_FRACTION = 0.20
MONO_BIN_COUNT = 10


# =============================================================================
# SMALL UTILITIES
# =============================================================================


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


class Stage6BPrecheckError(RuntimeError):
    """Raised when required files or schema are missing."""


@dataclass
class DegeneracyDiagnostics:
    exact_duplicate_fraction: float
    near_duplicate_fraction_12dp: float
    rounded_unique_fraction_10dp: float
    zero_distance_fraction: float
    degeneracy_indicator: float


@dataclass
class AngularMonotonicityDiagnostics:
    monotone_bin_fraction: float
    monotone_violation_count: int
    binned_means: List[float]
    binned_abs_dtheta_means: List[float]


@dataclass
class GroupDiagnostics:
    metric_name: str
    alpha: float
    beta: float
    FIT: str
    n_pairs: int
    mean_distance_squared: float
    std_distance_squared: float
    median_distance_squared: float
    min_distance_squared: float
    max_distance_squared: float
    mean_abs_dtheta: float
    mean_abs_dr: float
    distance_vs_abs_dtheta_spearman: float
    distance_vs_abs_dr_spearman: float
    angular_component_share_mean: float
    radial_component_share_mean: float
    component_balance_score: float
    dominance_label: str
    local_smoothness_score: float
    angular_monotone_bin_fraction: float
    angular_monotone_violation_count: int
    degeneracy_indicator: float
    exact_duplicate_fraction: float
    near_duplicate_fraction_12dp: float
    rounded_unique_fraction_10dp: float
    zero_distance_fraction: float
    parameter_stability_indicator: float
    cross_fit_consistency_indicator: float
    family_heuristic_score: float
    heuristic_rank_within_fit: Optional[float] = None


# =============================================================================
# PRECHECK BLOCK
# =============================================================================


def precheck_files_exist() -> None:
    missing = [str(p) for p in [PAIRWISE_CSV, SUMMARY_JSON, PROVENANCE_JSON] if not p.exists()]
    if missing:
        msg = (
            "[Stage-6B PRECHECK] Missing required input file(s):\n"
            + "\n".join(f"  - {m}" for m in missing)
        )
        raise Stage6BPrecheckError(msg)


def load_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as fh:
        return json.load(fh)


def precheck_pairwise_schema(df: pd.DataFrame) -> None:
    missing_cols = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing_cols:
        detected = list(df.columns)
        msg = (
            "[Stage-6B PRECHECK] Pairwise CSV is missing required columns.\n"
            f"Missing: {missing_cols}\n"
            f"Detected columns: {detected}"
        )
        raise Stage6BPrecheckError(msg)


def run_precheck() -> Tuple[pd.DataFrame, Any, Any, Dict[str, Any]]:
    print("[Stage-6B PRECHECK] Checking required files...")
    precheck_files_exist()

    print("[Stage-6B PRECHECK] Loading Stage-6A inputs...")
    df = pd.read_csv(PAIRWISE_CSV)
    summary_data = load_json(SUMMARY_JSON)
    provenance_data = load_json(PROVENANCE_JSON)

    print("[Stage-6B PRECHECK] Validating pairwise schema...")
    precheck_pairwise_schema(df)

    # Numeric coercion for safety.
    for col in ["alpha", "beta", "distance_squared", "dr", "dtheta", "r_i", "r_j"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    if df[REQUIRED_COLUMNS].isnull().any().any():
        bad_counts = df[REQUIRED_COLUMNS].isnull().sum()
        bad_counts = {k: int(v) for k, v in bad_counts.items() if int(v) > 0}
        raise Stage6BPrecheckError(
            "[Stage-6B PRECHECK] Required columns contain null/NaN values after numeric coercion.\n"
            f"Affected columns: {bad_counts}"
        )

    precheck_report = {
        "timestamp_utc": utc_now_iso(),
        "input_files": {
            "pairwise_csv": str(PAIRWISE_CSV),
            "summary_json": str(SUMMARY_JSON),
            "provenance_json": str(PROVENANCE_JSON),
        },
        "required_columns": REQUIRED_COLUMNS,
        "detected_columns": list(df.columns),
        "row_count": int(len(df)),
        "fit_values_detected": sorted(df["FIT"].astype(str).unique().tolist()),
        "metric_values_detected": sorted(df["metric_name"].astype(str).unique().tolist()),
    }

    print("[Stage-6B PRECHECK] OK")
    print(f"[Stage-6B PRECHECK] Rows: {len(df)}")
    print(f"[Stage-6B PRECHECK] FITs: {precheck_report['fit_values_detected']}")
    print(f"[Stage-6B PRECHECK] Metric families: {precheck_report['metric_values_detected']}")

    return df, summary_data, provenance_data, precheck_report


# =============================================================================
# STATISTICS HELPERS
# =============================================================================


def safe_float(x: Any, default: float = float("nan")) -> float:
    try:
        return float(x)
    except Exception:
        return default



def safe_spearman(x: Iterable[float], y: Iterable[float]) -> float:
    xs = pd.Series(list(x), dtype="float64")
    ys = pd.Series(list(y), dtype="float64")
    if len(xs) < 2:
        return float("nan")
    if xs.nunique(dropna=True) < 2 or ys.nunique(dropna=True) < 2:
        return float("nan")
    return safe_float(xs.corr(ys, method="spearman"))



def normalize_01(series: pd.Series) -> pd.Series:
    s = pd.Series(series, dtype="float64")
    finite = s[np.isfinite(s)]
    if finite.empty:
        return pd.Series(np.nan, index=s.index, dtype="float64")
    lo = finite.min()
    hi = finite.max()
    if abs(hi - lo) < EPS:
        return pd.Series(0.5, index=s.index, dtype="float64")
    return (s - lo) / (hi - lo)



def pair_index_gap(df: pd.DataFrame) -> pd.Series:
    # metric_id values can be numeric or string-like. Try numeric first.
    mi = pd.to_numeric(df["metric_id_i"], errors="coerce")
    mj = pd.to_numeric(df["metric_id_j"], errors="coerce")
    if mi.notna().all() and mj.notna().all():
        return (mi - mj).abs()

    # Fallback: rank unique IDs lexicographically, then compute positional gap.
    values = pd.Index(sorted(set(df["metric_id_i"].astype(str)).union(set(df["metric_id_j"].astype(str)))))
    lookup = {v: i for i, v in enumerate(values)}
    mi_rank = df["metric_id_i"].astype(str).map(lookup)
    mj_rank = df["metric_id_j"].astype(str).map(lookup)
    return (mi_rank - mj_rank).abs().astype(float)



def compute_component_shares(group: pd.DataFrame) -> Tuple[pd.Series, pd.Series]:
    abs_dr = group["dr"].abs().astype(float)
    abs_dtheta = group["dtheta"].abs().astype(float)

    # Proxy contributions. We do not reconstruct the exact Stage-6A formula here;
    # instead we form a diagnostic balance measure from the observed pairwise
    # radial/angular separations. This is intentionally interpretive, not a claim
    # of exact decomposition of distance_squared.
    radial_proxy = abs_dr
    angular_proxy = abs_dtheta
    denom = radial_proxy + angular_proxy + EPS
    radial_share = radial_proxy / denom
    angular_share = angular_proxy / denom
    return angular_share, radial_share



def classify_dominance(angular_share_mean: float, radial_share_mean: float) -> str:
    if not np.isfinite(angular_share_mean) or not np.isfinite(radial_share_mean):
        return "undetermined"
    if angular_share_mean >= 0.65:
        return "angular_dominated"
    if radial_share_mean >= 0.65:
        return "radial_dominated"
    return "reasonably_balanced"



def compute_local_smoothness_score(group: pd.DataFrame) -> float:
    gaps = pair_index_gap(group)
    dist = group["distance_squared"].astype(float)
    if len(group) < 3 or gaps.nunique(dropna=True) < 2 or dist.nunique(dropna=True) < 2:
        return float("nan")

    # Smoothness idea: near pairs should tend to have smaller distances.
    # Using negative correlation of distance with closeness, equivalently positive
    # correlation of distance with gap.
    return safe_spearman(gaps, dist)



def compute_angular_monotonicity(group: pd.DataFrame) -> AngularMonotonicityDiagnostics:
    abs_dtheta = group["dtheta"].abs().astype(float)
    dist = group["distance_squared"].astype(float)

    valid = np.isfinite(abs_dtheta) & np.isfinite(dist)
    abs_dtheta = abs_dtheta[valid]
    dist = dist[valid]

    if len(abs_dtheta) < max(10, MONO_BIN_COUNT):
        return AngularMonotonicityDiagnostics(
            monotone_bin_fraction=float("nan"),
            monotone_violation_count=0,
            binned_means=[],
            binned_abs_dtheta_means=[],
        )

    work = pd.DataFrame({"abs_dtheta": abs_dtheta, "dist": dist}).sort_values("abs_dtheta")
    # Equal-count bins via qcut; duplicates="drop" guards repeated values.
    try:
        bins = pd.qcut(work["abs_dtheta"], q=min(MONO_BIN_COUNT, len(work)), duplicates="drop")
    except ValueError:
        return AngularMonotonicityDiagnostics(
            monotone_bin_fraction=float("nan"),
            monotone_violation_count=0,
            binned_means=[],
            binned_abs_dtheta_means=[],
        )

    binned = work.groupby(bins, observed=False).agg(
        mean_abs_dtheta=("abs_dtheta", "mean"),
        mean_dist=("dist", "mean"),
    )

    means = binned["mean_dist"].tolist()
    theta_means = binned["mean_abs_dtheta"].tolist()
    if len(means) < 2:
        return AngularMonotonicityDiagnostics(
            monotone_bin_fraction=float("nan"),
            monotone_violation_count=0,
            binned_means=means,
            binned_abs_dtheta_means=theta_means,
        )

    monotone_steps = 0
    violations = 0
    for a, b in zip(means[:-1], means[1:]):
        if b + EPS >= a:
            monotone_steps += 1
        else:
            violations += 1

    frac = monotone_steps / max(len(means) - 1, 1)
    return AngularMonotonicityDiagnostics(
        monotone_bin_fraction=float(frac),
        monotone_violation_count=int(violations),
        binned_means=[safe_float(v) for v in means],
        binned_abs_dtheta_means=[safe_float(v) for v in theta_means],
    )



def compute_degeneracy(group: pd.DataFrame) -> DegeneracyDiagnostics:
    dist = group["distance_squared"].astype(float)
    n = len(dist)
    if n == 0:
        return DegeneracyDiagnostics(np.nan, np.nan, np.nan, np.nan, np.nan)

    exact_duplicate_fraction = 1.0 - (dist.nunique(dropna=True) / n)
    rounded_12 = dist.round(12)
    near_duplicate_fraction_12dp = 1.0 - (rounded_12.nunique(dropna=True) / n)
    rounded_10 = dist.round(DEGENERACY_ROUND_DECIMALS)
    rounded_unique_fraction_10dp = rounded_10.nunique(dropna=True) / n
    zero_distance_fraction = float((dist.abs() <= EPS).mean())

    # Heuristic composite: larger means more degeneracy/collapse.
    degeneracy_indicator = float(
        0.40 * exact_duplicate_fraction
        + 0.30 * near_duplicate_fraction_12dp
        + 0.20 * (1.0 - rounded_unique_fraction_10dp)
        + 0.10 * zero_distance_fraction
    )

    return DegeneracyDiagnostics(
        exact_duplicate_fraction=float(exact_duplicate_fraction),
        near_duplicate_fraction_12dp=float(near_duplicate_fraction_12dp),
        rounded_unique_fraction_10dp=float(rounded_unique_fraction_10dp),
        zero_distance_fraction=float(zero_distance_fraction),
        degeneracy_indicator=float(degeneracy_indicator),
    )


# =============================================================================
# GROUP-LEVEL EVALUATION
# =============================================================================


def evaluate_group(metric_name: str, alpha: float, beta: float, fit_name: str, group: pd.DataFrame) -> Dict[str, Any]:
    dist = group["distance_squared"].astype(float)
    abs_dtheta = group["dtheta"].abs().astype(float)
    abs_dr = group["dr"].abs().astype(float)

    angular_share, radial_share = compute_component_shares(group)
    angular_share_mean = safe_float(angular_share.mean())
    radial_share_mean = safe_float(radial_share.mean())
    component_balance_score = float(1.0 - abs(angular_share_mean - radial_share_mean))
    dominance_label = classify_dominance(angular_share_mean, radial_share_mean)

    smoothness_score = compute_local_smoothness_score(group)
    angular_mon = compute_angular_monotonicity(group)
    degeneracy = compute_degeneracy(group)

    row = {
        "metric_name": str(metric_name),
        "alpha": safe_float(alpha),
        "beta": safe_float(beta),
        "FIT": str(fit_name),
        "n_pairs": int(len(group)),
        "mean_distance_squared": safe_float(dist.mean()),
        "std_distance_squared": safe_float(dist.std(ddof=1)),
        "median_distance_squared": safe_float(dist.median()),
        "min_distance_squared": safe_float(dist.min()),
        "max_distance_squared": safe_float(dist.max()),
        "mean_abs_dtheta": safe_float(abs_dtheta.mean()),
        "mean_abs_dr": safe_float(abs_dr.mean()),
        "distance_vs_abs_dtheta_spearman": safe_float(safe_spearman(abs_dtheta, dist)),
        "distance_vs_abs_dr_spearman": safe_float(safe_spearman(abs_dr, dist)),
        "angular_component_share_mean": angular_share_mean,
        "radial_component_share_mean": radial_share_mean,
        "component_balance_score": component_balance_score,
        "dominance_label": dominance_label,
        "local_smoothness_score": safe_float(smoothness_score),
        "angular_monotone_bin_fraction": safe_float(angular_mon.monotone_bin_fraction),
        "angular_monotone_violation_count": int(angular_mon.monotone_violation_count),
        "degeneracy_indicator": safe_float(degeneracy.degeneracy_indicator),
        "exact_duplicate_fraction": safe_float(degeneracy.exact_duplicate_fraction),
        "near_duplicate_fraction_12dp": safe_float(degeneracy.near_duplicate_fraction_12dp),
        "rounded_unique_fraction_10dp": safe_float(degeneracy.rounded_unique_fraction_10dp),
        "zero_distance_fraction": safe_float(degeneracy.zero_distance_fraction),
        # Filled later after cross-group aggregation.
        "parameter_stability_indicator": float("nan"),
        "cross_fit_consistency_indicator": float("nan"),
        "family_heuristic_score": float("nan"),
        "heuristic_rank_within_fit": float("nan"),
        # Detailed internals retained for JSON only if needed.
        "_angular_monotonicity_binned_means": angular_mon.binned_means,
        "_angular_monotonicity_binned_abs_dtheta_means": angular_mon.binned_abs_dtheta_means,
    }
    return row



def evaluate_all_groups(df: pd.DataFrame) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    grouped = df.groupby(["metric_name", "alpha", "beta", "FIT"], dropna=False, sort=True)
    for (metric_name, alpha, beta, fit_name), group in grouped:
        rows.append(evaluate_group(metric_name, alpha, beta, fit_name, group.copy()))

    out = pd.DataFrame(rows)
    return out


# =============================================================================
# AGGREGATED INDICATORS
# =============================================================================


def add_parameter_stability_indicator(eval_df: pd.DataFrame) -> pd.DataFrame:
    eval_df = eval_df.copy()

    # Metric family stability across alpha/beta settings within each FIT.
    # Lower variance of load-bearing diagnostics -> higher stability.
    diag_cols = [
        "distance_vs_abs_dtheta_spearman",
        "distance_vs_abs_dr_spearman",
        "component_balance_score",
        "local_smoothness_score",
        "angular_monotone_bin_fraction",
        "degeneracy_indicator",
    ]

    stability_lookup: Dict[Tuple[str, str], float] = {}
    for (metric_name, fit_name), sub in eval_df.groupby(["metric_name", "FIT"], dropna=False):
        variances = []
        for col in diag_cols:
            vals = pd.to_numeric(sub[col], errors="coerce").dropna()
            if len(vals) >= 2:
                variances.append(float(vals.var(ddof=0)))
        if not variances:
            stability = float("nan")
        else:
            # Convert instability -> stability in (0, 1] roughly.
            mean_var = float(np.mean(variances))
            stability = 1.0 / (1.0 + mean_var)
        stability_lookup[(str(metric_name), str(fit_name))] = stability

    eval_df["parameter_stability_indicator"] = eval_df.apply(
        lambda r: stability_lookup.get((str(r["metric_name"]), str(r["FIT"])), float("nan")),
        axis=1,
    )
    return eval_df



def add_cross_fit_consistency_indicator(eval_df: pd.DataFrame) -> pd.DataFrame:
    eval_df = eval_df.copy()

    diag_cols = [
        "distance_vs_abs_dtheta_spearman",
        "distance_vs_abs_dr_spearman",
        "component_balance_score",
        "local_smoothness_score",
        "angular_monotone_bin_fraction",
        "degeneracy_indicator",
    ]

    lookup: Dict[Tuple[str, float, float], float] = {}
    for (metric_name, alpha, beta), sub in eval_df.groupby(["metric_name", "alpha", "beta"], dropna=False):
        dispersion_terms = []
        for col in diag_cols:
            vals = pd.to_numeric(sub[col], errors="coerce").dropna()
            if len(vals) >= 2:
                dispersion_terms.append(float(vals.var(ddof=0)))
        if not dispersion_terms:
            consistency = float("nan")
        else:
            mean_disp = float(np.mean(dispersion_terms))
            consistency = 1.0 / (1.0 + mean_disp)
        lookup[(str(metric_name), safe_float(alpha), safe_float(beta))] = consistency

    eval_df["cross_fit_consistency_indicator"] = eval_df.apply(
        lambda r: lookup.get(
            (str(r["metric_name"]), safe_float(r["alpha"]), safe_float(r["beta"])),
            float("nan"),
        ),
        axis=1,
    )
    return eval_df



def add_family_heuristic_score(eval_df: pd.DataFrame) -> pd.DataFrame:
    eval_df = eval_df.copy()

    # Positive contributors.
    theta_corr_norm = normalize_01(eval_df["distance_vs_abs_dtheta_spearman"])
    stability_norm = normalize_01(eval_df["parameter_stability_indicator"])
    consistency_norm = normalize_01(eval_df["cross_fit_consistency_indicator"])
    smoothness_norm = normalize_01(eval_df["local_smoothness_score"])
    monotone_norm = normalize_01(eval_df["angular_monotone_bin_fraction"])
    balance_norm = normalize_01(eval_df["component_balance_score"])

    # Penalties.
    dr_corr_norm = normalize_01(eval_df["distance_vs_abs_dr_spearman"])
    degeneracy_norm = normalize_01(eval_df["degeneracy_indicator"])

    # Diagnostic-only composite score.
    score = (
        0.28 * theta_corr_norm.fillna(0.5)
        + 0.18 * stability_norm.fillna(0.5)
        + 0.16 * consistency_norm.fillna(0.5)
        + 0.12 * monotone_norm.fillna(0.5)
        + 0.10 * smoothness_norm.fillna(0.5)
        + 0.08 * balance_norm.fillna(0.5)
        - 0.05 * dr_corr_norm.fillna(0.5)
        - 0.13 * degeneracy_norm.fillna(0.5)
    )

    eval_df["family_heuristic_score"] = score.astype(float)

    # Rank within each FIT for convenience.
    eval_df["heuristic_rank_within_fit"] = (
        eval_df.groupby("FIT")["family_heuristic_score"]
        .rank(method="dense", ascending=False)
        .astype(float)
    )

    return eval_df


# =============================================================================
# SUMMARY BUILDERS
# =============================================================================


def dataframe_to_json_records(df: pd.DataFrame) -> List[Dict[str, Any]]:
    records = []
    for row in df.to_dict(orient="records"):
        clean = {}
        for k, v in row.items():
            if isinstance(v, (np.floating, np.integer)):
                if pd.isna(v):
                    clean[k] = None
                else:
                    clean[k] = float(v) if isinstance(v, np.floating) else int(v)
            elif pd.isna(v) if not isinstance(v, (list, dict, str, bool, type(None))) else False:
                clean[k] = None
            else:
                clean[k] = v
        records.append(clean)
    return records



def build_family_notes(eval_df: pd.DataFrame) -> Dict[str, Any]:
    notes: Dict[str, Any] = {}
    for metric_name, sub in eval_df.groupby("metric_name", dropna=False):
        metric_name = str(metric_name)
        notes[metric_name] = {
            "row_count": int(len(sub)),
            "mean_theta_alignment": safe_float(sub["distance_vs_abs_dtheta_spearman"].mean()),
            "mean_dr_alignment": safe_float(sub["distance_vs_abs_dr_spearman"].mean()),
            "mean_parameter_stability": safe_float(sub["parameter_stability_indicator"].mean()),
            "mean_cross_fit_consistency": safe_float(sub["cross_fit_consistency_indicator"].mean()),
            "mean_balance_score": safe_float(sub["component_balance_score"].mean()),
            "mean_degeneracy": safe_float(sub["degeneracy_indicator"].mean()),
            "mean_heuristic_score": safe_float(sub["family_heuristic_score"].mean()),
            "dominance_labels": sorted(sub["dominance_label"].dropna().astype(str).unique().tolist()),
        }
    return notes



def pick_promising_and_flagged(eval_df: pd.DataFrame) -> Dict[str, Any]:
    work = eval_df.copy()

    # Promising: high heuristic score + positive theta alignment + tolerable degeneracy.
    promising = work[
        (work["family_heuristic_score"] >= work["family_heuristic_score"].quantile(0.75))
        & (work["distance_vs_abs_dtheta_spearman"] > 0)
        & (work["degeneracy_indicator"] <= work["degeneracy_indicator"].quantile(0.75))
    ].sort_values(["family_heuristic_score", "metric_name", "FIT"], ascending=[False, True, True])

    # Flagged: weak theta alignment or high degeneracy or strong radial dominance.
    flagged = work[
        (work["distance_vs_abs_dtheta_spearman"] <= 0)
        | (work["degeneracy_indicator"] >= work["degeneracy_indicator"].quantile(0.75))
        | (work["dominance_label"] == "radial_dominated")
    ].sort_values(["degeneracy_indicator", "metric_name", "FIT"], ascending=[False, True, True])

    cols = [
        "metric_name",
        "alpha",
        "beta",
        "FIT",
        "family_heuristic_score",
        "distance_vs_abs_dtheta_spearman",
        "distance_vs_abs_dr_spearman",
        "dominance_label",
        "parameter_stability_indicator",
        "cross_fit_consistency_indicator",
        "degeneracy_indicator",
    ]

    return {
        "provisionally_promising": dataframe_to_json_records(promising[cols].head(12)),
        "flagged_for_caution": dataframe_to_json_records(flagged[cols].head(12)),
    }



def build_cross_fit_notes(eval_df: pd.DataFrame) -> Dict[str, Any]:
    notes: Dict[str, Any] = {}
    grouped = eval_df.groupby(["metric_name", "alpha", "beta"], dropna=False)
    for (metric_name, alpha, beta), sub in grouped:
        notes[f"{metric_name}__alpha={alpha}__beta={beta}"] = {
            "FITS_present": sorted(sub["FIT"].astype(str).unique().tolist()),
            "theta_alignment_by_fit": {
                str(r["FIT"]): safe_float(r["distance_vs_abs_dtheta_spearman"])
                for _, r in sub.iterrows()
            },
            "dr_alignment_by_fit": {
                str(r["FIT"]): safe_float(r["distance_vs_abs_dr_spearman"])
                for _, r in sub.iterrows()
            },
            "dominance_by_fit": {
                str(r["FIT"]): str(r["dominance_label"]) for _, r in sub.iterrows()
            },
            "cross_fit_consistency_indicator": safe_float(sub["cross_fit_consistency_indicator"].iloc[0]),
        }
    return notes



def build_summary_json(
    eval_df: pd.DataFrame,
    precheck_report: Dict[str, Any],
    stage6a_summary: Any,
    stage6a_provenance: Any,
) -> Dict[str, Any]:
    family_notes = build_family_notes(eval_df)
    status_notes = pick_promising_and_flagged(eval_df)
    cross_fit_notes = build_cross_fit_notes(eval_df)

    warnings = [
        "Stage-6B is diagnostic only; no final metric selection is claimed here.",
        "Large distance values are not interpreted as superior geometry.",
        "Component balance uses diagnostic radial/angular proxies from |dr| and |dtheta|, not a claim of exact Stage-6A metric decomposition.",
        "Any family-level ranking is a heuristic for triage, not a theorem or physical conclusion.",
    ]

    return {
        "script_name": "metric_stage_6B_evaluate_candidate_metrics_from_stage6A_v1.py",
        "stage": "Stage-6B",
        "timestamp_utc": utc_now_iso(),
        "purpose": "Diagnostic evaluation of Stage-6A candidate metrics against angular structure, stability, smoothness, and degeneracy criteria.",
        "precheck_report": precheck_report,
        "upstream_references": {
            "stage6A_summary_json_path": str(SUMMARY_JSON),
            "stage6A_provenance_json_path": str(PROVENANCE_JSON),
        },
        "evaluation_protocol": {
            "cross_fit_consistency": "Compare diagnostic behavior across FITs for each metric/parameter setting.",
            "parameter_stability": "Assess how metric behavior varies across alpha/beta within a family.",
            "angular_compatibility": "Favorable candidates should show positive distance-vs-|dtheta| alignment.",
            "component_balance": "Diagnose angular-dominated, radial-dominated, or balanced behavior using |dr| and |dtheta| proxies.",
            "within_fit_smoothness": "Near metric_id pairs should tend to receive smaller distances than distant pairs.",
            "degeneracy_check": "Track duplicate/near-duplicate distances and zero-distance collapse.",
            "angular_monotonicity": "Binned mean distances should generally increase with mean |dtheta|.",
            "family_heuristic_score": "Composite triage score for provisional ranking only.",
        },
        "aggregate_family_summaries": family_notes,
        "cross_fit_comparison_notes": cross_fit_notes,
        "warnings_and_caveats": warnings,
        "candidates_not_eliminated_but_flagged": status_notes["flagged_for_caution"],
        "candidates_provisionally_promising": status_notes["provisionally_promising"],
        "evaluation_table_records": dataframe_to_json_records(eval_df),
        "embedded_upstream_stage6A_summary": stage6a_summary,
        "embedded_upstream_stage6A_provenance": stage6a_provenance,
    }


# =============================================================================
# INTERPRETIVE NOTES (TXT)
# =============================================================================


def build_interpretive_notes(eval_df: pd.DataFrame) -> str:
    lines: List[str] = []
    lines.append("STAGE-6B INTERPRETIVE NOTES — CANDIDATE METRIC EVALUATION")
    lines.append(f"Generated (UTC): {utc_now_iso()}")
    lines.append("")
    lines.append("Interpretive stance")
    lines.append("------------------")
    lines.append("This output is diagnostic, not a final metric declaration. The main question")
    lines.append("is whether candidate metrics behave coherently with the angular intrinsic")
    lines.append("structure established in Stage-5.")
    lines.append("")

    # Top provisional candidates.
    ranked = eval_df.sort_values("family_heuristic_score", ascending=False)
    lines.append("Provisional top rows by heuristic score")
    lines.append("-------------------------------------")
    for _, r in ranked.head(10).iterrows():
        lines.append(
            f"- {r['metric_name']} | alpha={r['alpha']} | beta={r['beta']} | FIT={r['FIT']} | "
            f"score={r['family_heuristic_score']:.6f} | theta_rho={r['distance_vs_abs_dtheta_spearman']:.6f} | "
            f"dr_rho={r['distance_vs_abs_dr_spearman']:.6f} | dominance={r['dominance_label']} | "
            f"stability={r['parameter_stability_indicator']:.6f} | degeneracy={r['degeneracy_indicator']:.6f}"
        )
    lines.append("")

    lines.append("Family-level summary")
    lines.append("--------------------")
    for metric_name, sub in eval_df.groupby("metric_name", dropna=False):
        lines.append(
            f"- {metric_name}: mean theta-alignment={sub['distance_vs_abs_dtheta_spearman'].mean():.6f}, "
            f"mean dr-alignment={sub['distance_vs_abs_dr_spearman'].mean():.6f}, "
            f"mean stability={sub['parameter_stability_indicator'].mean():.6f}, "
            f"mean cross-fit consistency={sub['cross_fit_consistency_indicator'].mean():.6f}, "
            f"mean balance={sub['component_balance_score'].mean():.6f}, "
            f"mean degeneracy={sub['degeneracy_indicator'].mean():.6f}, "
            f"mean score={sub['family_heuristic_score'].mean():.6f}."
        )
    lines.append("")

    lines.append("Cautions")
    lines.append("--------")
    lines.append("1) A large numerical distance scale is not interpreted as superiority.")
    lines.append("2) A smooth metric is not automatically a more physical metric.")
    lines.append("3) Radial dominance may indicate erasure of the angular structure discovered earlier.")
    lines.append("4) Provisional rankings should be treated as triage for Stage-6C, not as final truth.")
    lines.append("")

    lines.append("Recommended next transition")
    lines.append("---------------------------")
    lines.append("Use the most stable and angular-compatible rows/families as Stage-6C inputs for")
    lines.append("normalization, invariance, and coordinate-gauge analysis.")
    lines.append("")

    return "\n".join(lines) + "\n"


# =============================================================================
# MAIN
# =============================================================================


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    df, stage6a_summary, stage6a_provenance, precheck_report = run_precheck()

    print("[Stage-6B] Evaluating groups...")
    eval_df = evaluate_all_groups(df)

    print("[Stage-6B] Computing aggregate indicators...")
    eval_df = add_parameter_stability_indicator(eval_df)
    eval_df = add_cross_fit_consistency_indicator(eval_df)
    eval_df = add_family_heuristic_score(eval_df)

    # Reorder columns for CSV cleanliness.
    public_cols = [
        "metric_name",
        "alpha",
        "beta",
        "FIT",
        "n_pairs",
        "mean_distance_squared",
        "std_distance_squared",
        "median_distance_squared",
        "min_distance_squared",
        "max_distance_squared",
        "mean_abs_dtheta",
        "mean_abs_dr",
        "distance_vs_abs_dtheta_spearman",
        "distance_vs_abs_dr_spearman",
        "angular_component_share_mean",
        "radial_component_share_mean",
        "component_balance_score",
        "dominance_label",
        "local_smoothness_score",
        "angular_monotone_bin_fraction",
        "angular_monotone_violation_count",
        "degeneracy_indicator",
        "exact_duplicate_fraction",
        "near_duplicate_fraction_12dp",
        "rounded_unique_fraction_10dp",
        "zero_distance_fraction",
        "parameter_stability_indicator",
        "cross_fit_consistency_indicator",
        "family_heuristic_score",
        "heuristic_rank_within_fit",
    ]
    csv_df = eval_df[public_cols].copy().sort_values(
        ["FIT", "heuristic_rank_within_fit", "metric_name", "alpha", "beta"],
        ascending=[True, True, True, True, True],
    )

    print("[Stage-6B] Writing CSV...")
    csv_df.to_csv(OUTPUT_CSV, index=False)

    print("[Stage-6B] Building JSON summary...")
    summary_json = build_summary_json(
        eval_df=eval_df,
        precheck_report=precheck_report,
        stage6a_summary=stage6a_summary,
        stage6a_provenance=stage6a_provenance,
    )
    with OUTPUT_JSON.open("w", encoding="utf-8") as fh:
        json.dump(summary_json, fh, indent=2, ensure_ascii=False)

    print("[Stage-6B] Writing interpretive notes...")
    with OUTPUT_TXT.open("w", encoding="utf-8") as fh:
        fh.write(build_interpretive_notes(eval_df))

    print("[Stage-6B] Wrote:")
    print(f"  CSV : {OUTPUT_CSV}")
    print(f"  JSON: {OUTPUT_JSON}")
    print(f"  TXT : {OUTPUT_TXT}")

    # Console summary.
    print("[Stage-6B] Top provisional rows by heuristic score:")
    top = csv_df.sort_values("family_heuristic_score", ascending=False).head(10)
    for _, r in top.iterrows():
        print(
            "  - "
            f"{r['metric_name']} | alpha={r['alpha']} | beta={r['beta']} | FIT={r['FIT']} | "
            f"score={r['family_heuristic_score']:.6f} | "
            f"theta_rho={r['distance_vs_abs_dtheta_spearman']:.6f} | "
            f"dr_rho={r['distance_vs_abs_dr_spearman']:.6f} | "
            f"dominance={r['dominance_label']} | "
            f"degeneracy={r['degeneracy_indicator']:.6f}"
        )


if __name__ == "__main__":
    main()

