#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Provenance note
# This major Stage-5D formalization script is downstream of:
#   - stage5B_metric_candidate_from_global_PC1_v1.{csv,json}
#   - stage5C_intrinsic_coordinate_from_PC1_PC2_v1.{csv,json}
#   - stage5C_intrinsic_coordinate_from_PC1_PC2_v3.{csv,json}
#   - stage5C_intrinsic_coordinate_from_PC1_PC2_v4.{csv,json}
#
# Decision basis:
#   - Stage-5B established a rank~2 global enriched geometry with
#     stable-but-nonmonotone PC1 and directional PC2.
#   - Stage-5C established that linear and radial constructions are
#     insufficient, while angular constructions recover the directional
#     intrinsic structure.
#   - Stage-5C v4 resolved the remaining BARI symmetry using targeted
#     integer-lift unfolding.
#
# Therefore this script does not compare candidates again; it freezes
# the selected Stage-5 directional intrinsic coordinate and records the
# radial-vs-directional decomposition as settled Stage-5 output.

from __future__ import annotations

import json
import math
import os
import re
import sys
from collections import defaultdict
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

try:
    import pandas as pd
except Exception as exc:  # pragma: no cover
    raise RuntimeError("This script requires pandas.") from exc


SCRIPT_VERSION = "formalize_preferred_intrinsic_coordinate_v1b"
STAGE = "5D"
EXPECTED_CANDIDATE = "option4_angle_bari_targeted_hybrid"
EXPECTED_FITS = ["BARI", "NUFIT", "VALENCIA"]

DEFAULT_PROJECT_ROOT = Path(
    "/home/dakini/Downloads/010-Quantum_Emergent_Gravity"
)
DEFAULT_STAGE5C_JSON = DEFAULT_PROJECT_ROOT / "metric_stage_5C_outputs" / "stage5C_intrinsic_coordinate_from_PC1_PC2_v4.json"
DEFAULT_STAGE5C_CSV = DEFAULT_PROJECT_ROOT / "metric_stage_5C_outputs" / "stage5C_intrinsic_coordinate_from_PC1_PC2_v4.csv"
DEFAULT_STAGE5B_JSON = DEFAULT_PROJECT_ROOT / "metric_stage_5B_outputs" / "stage5B_metric_candidate_from_global_PC1_v1.json"
DEFAULT_STAGE5B_CSV = DEFAULT_PROJECT_ROOT / "metric_stage_5B_outputs" / "stage5B_metric_candidate_from_global_PC1_v1.csv"
DEFAULT_OUTPUT_DIR = DEFAULT_PROJECT_ROOT / "metric_stage_5D_outputs"

ROUND_TIES_DECIMALS = 12


# -----------------------------------------------------------------------------
# Generic helpers
# -----------------------------------------------------------------------------
def utc_now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def load_json(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def try_load_csv(path: Path) -> Optional[pd.DataFrame]:
    if not path.exists():
        return None
    try:
        return pd.read_csv(path)
    except Exception:
        return None


def norm_key(text: Any) -> str:
    if text is None:
        return ""
    text = str(text)
    text = text.replace("-", "_")
    text = re.sub(r"[^a-zA-Z0-9_]+", "_", text)
    text = re.sub(r"_+", "_", text)
    return text.strip("_").lower()


def safe_float(x: Any) -> Optional[float]:
    if x is None:
        return None
    if isinstance(x, bool):
        return float(x)
    if isinstance(x, (int, float)):
        if isinstance(x, float) and (math.isnan(x) or math.isinf(x)):
            return None
        return float(x)
    if isinstance(x, str):
        s = x.strip()
        if not s:
            return None
        try:
            val = float(s)
            if math.isnan(val) or math.isinf(val):
                return None
            return val
        except Exception:
            return None
    return None


def safe_int(x: Any) -> Optional[int]:
    if x is None:
        return None
    if isinstance(x, bool):
        return int(x)
    if isinstance(x, int):
        return x
    if isinstance(x, float):
        if math.isnan(x) or math.isinf(x):
            return None
        if abs(x - round(x)) < 1e-9:
            return int(round(x))
        return None
    s = str(x).strip()
    if re.fullmatch(r"[-+]?\d+", s):
        try:
            return int(s)
        except Exception:
            return None
    m = re.search(r"(\d+)", s)
    if m:
        try:
            return int(m.group(1))
        except Exception:
            return None
    return None


def stringify_compact(x: Any) -> str:
    if x is None:
        return ""
    if isinstance(x, str):
        return x
    try:
        return json.dumps(x, ensure_ascii=False, sort_keys=True)
    except Exception:
        return str(x)


def make_json_safe(obj: Any) -> Any:
    if isinstance(obj, dict):
        return {str(k): make_json_safe(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [make_json_safe(v) for v in obj]
    if isinstance(obj, tuple):
        return [make_json_safe(v) for v in obj]
    if isinstance(obj, Path):
        return str(obj)
    if isinstance(obj, pd.DataFrame):
        return make_json_safe(obj.to_dict(orient="records"))
    if isinstance(obj, pd.Series):
        return make_json_safe(obj.to_dict())
    if hasattr(obj, "item"):
        try:
            return make_json_safe(obj.item())
        except Exception:
            pass
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            return None
        return obj
    return obj


def flatten_numeric_sequence(x: Any) -> Optional[List[float]]:
    if x is None:
        return None
    if isinstance(x, (list, tuple)):
        out = []
        for v in x:
            fv = safe_float(v)
            if fv is None:
                return None
            out.append(fv)
        return out
    return None


def find_first_key_value(obj: Any, candidate_keys: Sequence[str]) -> Any:
    wanted = {norm_key(k) for k in candidate_keys}

    def _walk(x: Any) -> Any:
        if isinstance(x, dict):
            for k, v in x.items():
                if norm_key(k) in wanted:
                    return v
            for v in x.values():
                got = _walk(v)
                if got is not None:
                    return got
        elif isinstance(x, list):
            for v in x:
                got = _walk(v)
                if got is not None:
                    return got
        return None

    return _walk(obj)


def find_all_dicts_with_key(obj: Any, candidate_keys: Sequence[str]) -> List[Dict[str, Any]]:
    wanted = {norm_key(k) for k in candidate_keys}
    out: List[Dict[str, Any]] = []

    def _walk(x: Any) -> None:
        if isinstance(x, dict):
            if any(norm_key(k) in wanted for k in x.keys()):
                out.append(x)
            for v in x.values():
                _walk(v)
        elif isinstance(x, list):
            for v in x:
                _walk(v)

    _walk(obj)
    return out


def maybe_get(d: Dict[str, Any], keys: Sequence[str], default: Any = None) -> Any:
    nd = {norm_key(k): v for k, v in d.items()}
    for key in keys:
        nk = norm_key(key)
        if nk in nd:
            return nd[nk]
    return default


def discover_project_root(cli_root: Optional[Path] = None) -> Path:
    if cli_root is not None:
        return cli_root
    env_root = os.environ.get("QEG_PROJECT_ROOT")
    if env_root:
        return Path(env_root)
    if DEFAULT_PROJECT_ROOT.exists():
        return DEFAULT_PROJECT_ROOT
    return Path.cwd().resolve().parent if Path.cwd().name == "metric_stage_5D_outputs" else Path.cwd().resolve()


# -----------------------------------------------------------------------------
# Search / extraction helpers for Stage-5C JSON
# -----------------------------------------------------------------------------
def extract_recommended_candidate(stage5c: Dict[str, Any]) -> Optional[str]:
    candidates = [
        "final_recommended_candidate_name",
        "recommended_candidate_name",
        "preferred_directional_coordinate_name",
        "best_candidate_name",
        "selected_candidate_name",
        "winner",
        "recommended_candidate",
        "final_candidate",
    ]
    value = find_first_key_value(stage5c, candidates)
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, dict):
        for k in ["name", "candidate_name"]:
            v = maybe_get(value, [k])
            if isinstance(v, str):
                return v.strip()
    return None


def extract_aggregate_snapshot(stage5c: Dict[str, Any]) -> Any:
    return find_first_key_value(
        stage5c,
        [
            "aggregate_comparison_snapshot",
            "aggregate_comparison",
            "comparison_snapshot",
            "scoreboard",
            "comparison_scoreboard",
            "aggregate_snapshot",
        ],
    )


def normalize_fit_name(name: Any) -> Optional[str]:
    if name is None:
        return None
    s = str(name).strip().upper()
    if s in EXPECTED_FITS:
        return s
    aliases = {
        "NU FIT": "NUFIT",
        "VALENCIA": "VALENCIA",
        "BARI": "BARI",
        "NUFIT": "NUFIT",
    }
    return aliases.get(s, s if s in EXPECTED_FITS else None)


def find_fit_blocks(stage5c: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    fit_blocks: Dict[str, Dict[str, Any]] = {}

    def _register(name: str, block: Dict[str, Any]) -> None:
        fn = normalize_fit_name(name)
        if fn is None:
            return
        if fn not in fit_blocks:
            fit_blocks[fn] = block
        else:
            merged = deepcopy(fit_blocks[fn])
            merged.update({k: v for k, v in block.items() if k not in merged or merged[k] in (None, "", [], {})})
            fit_blocks[fn] = merged

    # 1) direct top-level or nested dict keyed by fit name
    def _walk(x: Any) -> None:
        if isinstance(x, dict):
            for k, v in x.items():
                fn = normalize_fit_name(k)
                if fn is not None and isinstance(v, dict):
                    _register(fn, v)
                if isinstance(v, dict):
                    fit_name = maybe_get(v, ["fit_name", "fit", "name"])
                    fn2 = normalize_fit_name(fit_name)
                    if fn2 is not None:
                        _register(fn2, v)
                _walk(v)
        elif isinstance(x, list):
            for v in x:
                _walk(v)

    _walk(stage5c)
    return fit_blocks


def choose_seq(block: Dict[str, Any], keys: Sequence[str]) -> Optional[List[float]]:
    for key in keys:
        value = maybe_get(block, [key])
        seq = flatten_numeric_sequence(value)
        if seq is not None:
            return seq
    # recursive fallback
    value = find_first_key_value(block, keys)
    seq = flatten_numeric_sequence(value)
    return seq


def choose_scalar(block: Dict[str, Any], keys: Sequence[str]) -> Any:
    value = maybe_get(block, keys)
    if value is not None:
        return value
    return find_first_key_value(block, keys)


def compute_spearman_from_pairs(metric_ids: Sequence[int], values: Sequence[float]) -> Optional[float]:
    if len(metric_ids) != len(values) or len(metric_ids) < 2:
        return None

    def average_ranks(items: Sequence[float]) -> List[float]:
        indexed = sorted(enumerate(items), key=lambda t: t[1])
        ranks = [0.0] * len(items)
        i = 0
        while i < len(indexed):
            j = i
            while j + 1 < len(indexed) and indexed[j + 1][1] == indexed[i][1]:
                j += 1
            avg_rank = 0.5 * (i + j) + 1.0
            for k in range(i, j + 1):
                ranks[indexed[k][0]] = avg_rank
            i = j + 1
        return ranks

    xr = average_ranks([float(x) for x in metric_ids])
    yr = average_ranks([float(y) for y in values])
    xbar = sum(xr) / len(xr)
    ybar = sum(yr) / len(yr)
    num = sum((a - xbar) * (b - ybar) for a, b in zip(xr, yr))
    denx = math.sqrt(sum((a - xbar) ** 2 for a in xr))
    deny = math.sqrt(sum((b - ybar) ** 2 for b in yr))
    if denx == 0 or deny == 0:
        return None
    return num / (denx * deny)


def monotonicity_flags(values: Sequence[float], tol: float = 1e-12) -> Tuple[bool, bool]:
    if len(values) < 2:
        return (False, False)
    diffs = [values[i + 1] - values[i] for i in range(len(values) - 1)]
    nondec = all(d >= -tol for d in diffs)
    noninc = all(d <= tol for d in diffs)
    strict_up = nondec and any(d > tol for d in diffs)
    strict_dn = noninc and any(d < -tol for d in diffs)
    return strict_up, strict_dn


def tie_count(values: Sequence[float], decimals: int = ROUND_TIES_DECIMALS) -> int:
    rounded = [round(v, decimals) for v in values]
    return len(rounded) - len(set(rounded))


def dynamic_range(values: Sequence[float]) -> Optional[float]:
    if not values:
        return None
    return max(values) - min(values)


def endpoint_separation(values: Sequence[float]) -> Optional[float]:
    if len(values) < 2:
        return None
    return values[-1] - values[0]


def extract_metric_ids(block: Dict[str, Any], seq_len_hint: Optional[int] = None) -> Optional[List[Any]]:
    direct = choose_seq(block, ["metric_ids", "metric_id_sequence", "ordered_metric_ids"])
    if direct is not None:
        return direct

    raw = choose_scalar(block, ["metric_id_ordering", "metric_ordering", "metric_id_order"])
    if isinstance(raw, list):
        return raw

    rows = maybe_get(block, ["rows", "records", "table"])
    if isinstance(rows, list) and rows and isinstance(rows[0], dict):
        ids = []
        for row in rows:
            ids.append(maybe_get(row, ["metric_id", "metric", "metric_name", "metric_label"]))
        if any(v is not None for v in ids):
            return ids

    if seq_len_hint:
        return list(range(1, seq_len_hint + 1))
    return None


def metric_id_to_int(metric_id: Any) -> Optional[int]:
    return safe_int(metric_id)


def pick_directional_sequence(block: Dict[str, Any]) -> Optional[List[float]]:
    priority = [
        "preferred_directional_coordinate_values",
        "directional_coordinate_values",
        "final_directional_sequence",
        "selected_directional_sequence",
        "preferred_sequence",
        "unfolded_directional_coordinate_values",
        "angle_value_after_unfolding",
        "angles_after_unfolding",
        "lifted_angle_values",
        "final_unwrapped_angles",
        "values",
    ]
    seq = choose_seq(block, priority)
    if seq is not None:
        return seq

    rows = maybe_get(block, ["rows", "records", "table"])
    if isinstance(rows, list) and rows and isinstance(rows[0], dict):
        vals = []
        for row in rows:
            v = maybe_get(
                row,
                [
                    "preferred_directional_coordinate",
                    "directional_coordinate",
                    "angle_value_after_unfolding",
                    "angle_after_unfolding",
                    "lifted_angle",
                    "preferred_value",
                ],
            )
            fv = safe_float(v)
            if fv is None:
                return None
            vals.append(fv)
        return vals if vals else None

    return None


def pick_radial_sequence(block: Dict[str, Any]) -> Optional[List[float]]:
    priority = [
        "radial_coordinate_values",
        "pc1_values",
        "pc1_value",
        "radius_values",
        "radius_value",
        "radial_values",
    ]
    seq = choose_seq(block, priority)
    if seq is not None:
        return seq

    rows = maybe_get(block, ["rows", "records", "table"])
    if isinstance(rows, list) and rows and isinstance(rows[0], dict):
        vals = []
        for row in rows:
            v = maybe_get(row, ["pc1_value", "radial_coordinate", "radius_value", "radial_value"])
            fv = safe_float(v)
            if fv is None:
                return None
            vals.append(fv)
        return vals if vals else None
    return None


def extract_rowwise_optional(block: Dict[str, Any], keys: Sequence[str], n: int) -> List[Any]:
    seq = choose_seq(block, keys)
    if seq is not None and len(seq) == n:
        return seq
    rows = maybe_get(block, ["rows", "records", "table"])
    if isinstance(rows, list) and len(rows) == n and all(isinstance(r, dict) for r in rows):
        out = []
        for row in rows:
            out.append(maybe_get(row, keys))
        return out
    return [None] * n



def extract_fit_summary_from_block(fit_name: str, block: Dict[str, Any]) -> Dict[str, Any]:
    def _get_dict_local(x: Any, keys: Sequence[str]) -> Optional[Dict[str, Any]]:
        if not isinstance(x, dict):
            return None
        value = maybe_get(x, keys)
        if isinstance(value, dict):
            return value
        value = find_first_key_value(x, keys)
        if isinstance(value, dict):
            return value
        return None

    # Prefer the already-selected Stage-5C summary block whenever available.
    preferred_summary = _get_dict_local(
        block,
        [
            "selected_bari_summary",
            "preferred_directional_summary",
            "final_directional_summary",
            "selected_summary",
            "preferred_summary",
        ],
    )

    # BARI-specific selected method block can carry the authoritative lift metadata.
    selected_method_name = choose_scalar(
        block,
        [
            "selected_bari_method",
            "selected_unfolding_method",
            "selected_method",
            "bari_selected_unfolding_method",
        ],
    )
    selected_method_block: Optional[Dict[str, Any]] = None
    targeted_methods = _get_dict_local(block, ["bari_targeted_methods"])
    if isinstance(targeted_methods, dict) and isinstance(selected_method_name, str):
        for k, v in targeted_methods.items():
            if norm_key(k) == norm_key(selected_method_name) and isinstance(v, dict):
                selected_method_block = v
                break

    summary_source = preferred_summary or selected_method_block or block

    directional = pick_directional_sequence(summary_source)
    if directional is None and selected_method_block is not None:
        directional = pick_directional_sequence(selected_method_block)
    if directional is None:
        directional = pick_directional_sequence(block)
    if directional is None:
        raise ValueError(f"Could not extract preferred directional coordinate sequence for FIT={fit_name}.")

    metric_ids_raw = extract_metric_ids(summary_source, seq_len_hint=len(directional))
    if metric_ids_raw is None and selected_method_block is not None:
        metric_ids_raw = extract_metric_ids(selected_method_block, seq_len_hint=len(directional))
    if metric_ids_raw is None:
        metric_ids_raw = extract_metric_ids(block, seq_len_hint=len(directional))
    if metric_ids_raw is None:
        raise ValueError(f"Could not extract metric_id ordering for FIT={fit_name}.")

    metric_ids = list(metric_ids_raw)
    if len(metric_ids) != len(directional):
        raise ValueError(
            f"Length mismatch for FIT={fit_name}: metric_ids={len(metric_ids)} vs directional={len(directional)}."
        )

    metric_ids_int = [metric_id_to_int(x) for x in metric_ids]

    radial = pick_radial_sequence(block)
    if radial is not None and len(radial) != len(directional):
        radial = None

    # Stage-5C v4 stores radius_raw directly at fit level.
    radius_raw = choose_seq(block, ["radius_raw"])
    if radial is None and radius_raw is not None and len(radius_raw) == len(directional):
        radial = radius_raw

    theta_raw = choose_seq(block, ["theta_raw"])
    angle_before = theta_raw[:] if theta_raw is not None and len(theta_raw) == len(directional) else [None] * len(directional)
    angle_after = directional[:]

    pc1_vals = extract_rowwise_optional(block, ["pc1_value", "pc1_values"], len(directional))
    pc2_vals = extract_rowwise_optional(block, ["pc2_value", "pc2_values"], len(directional))
    radius_vals = extract_rowwise_optional(block, ["radius_value", "radius_values", "radius_raw"], len(directional))

    if radial is None:
        # prefer explicit radius values, then pc1
        cand = [safe_float(v) for v in radius_vals]
        if any(v is not None for v in cand):
            radial = cand
        else:
            radial = [safe_float(v) for v in pc1_vals]
        if all(v is None for v in radial):
            radial = [None] * len(directional)

    # Pull fit-level quality statistics from the authoritative selected summary first,
    # not from an earlier exploratory baseline nested elsewhere in the block.
    monotone_inc = choose_scalar(summary_source, ["fit_monotone_increasing", "monotone_increasing", "is_monotone_increasing"])
    monotone_dec = choose_scalar(summary_source, ["fit_monotone_decreasing", "monotone_decreasing", "is_monotone_decreasing"])
    rho = choose_scalar(summary_source, ["fit_spearman_rho_vs_metric_id", "spearman_rho_vs_metric_id", "spearman_rho", "rho"])
    endpoint = choose_scalar(summary_source, ["fit_endpoint_separation_last_minus_first", "endpoint_separation_last_minus_first", "endpoint_separation", "last_minus_first"])
    ties = choose_scalar(summary_source, ["fit_ties_count_after_round12", "ties_count_after_round12", "ties_count"])
    dyn = choose_scalar(summary_source, ["fit_dynamic_range", "dynamic_range"])

    rho_f = safe_float(rho)
    if rho_f is None and all(v is not None for v in metric_ids_int):
        rho_f = compute_spearman_from_pairs(metric_ids_int, directional)

    endpoint_f = safe_float(endpoint)
    if endpoint_f is None:
        endpoint_f = endpoint_separation(directional)

    dyn_f = safe_float(dyn)
    if dyn_f is None:
        dyn_f = dynamic_range(directional)

    ties_i = safe_int(ties)
    if ties_i is None:
        ties_i = tie_count(directional)

    inc_flag = monotone_inc if isinstance(monotone_inc, bool) else None
    dec_flag = monotone_dec if isinstance(monotone_dec, bool) else None
    if inc_flag is None or dec_flag is None:
        inc_calc, dec_calc = monotonicity_flags(directional)
        inc_flag = inc_calc if inc_flag is None else inc_flag
        dec_flag = dec_calc if dec_flag is None else dec_flag

    directional_method_used = choose_scalar(
        block,
        [
            "directional_method_used",
            "method_used",
            "selected_unfolding_method",
            "selected_method",
            "construction_method",
            "selected_bari_method",
        ],
    )
    anchor_strategy = choose_scalar(
        block,
        [
            "directional_anchor_strategy",
            "anchor_strategy",
            "angular_anchor_strategy",
            "canonical_anchor_strategy",
        ],
    )
    unfolding_strategy = choose_scalar(
        block,
        [
            "directional_unfolding_strategy",
            "unfolding_strategy",
            "selected_unfolding_strategy",
            "bari_selected_unfolding_method",
            "selected_bari_method",
        ],
    )

    lift_vector = None
    if selected_method_block is not None:
        lift_vector = choose_scalar(selected_method_block, ["integer_lift_vector", "chosen_lift_vector", "lift_vector", "bari_lift_vector"])
    if lift_vector is None:
        lift_vector = choose_scalar(block, ["integer_lift_vector", "chosen_lift_vector", "lift_vector", "bari_lift_vector"])

    orbit_diag = _get_dict_local(block, ["selected_bari_orbit_plateau_diagnostics", "orbit_plateau_diagnostics"])
    orbit_plateau_pattern_class = None
    if isinstance(orbit_diag, dict):
        orbit_plateau_pattern_class = choose_scalar(
            orbit_diag,
            ["quotient_orbit_interpretation", "orbit_plateau_pattern_class", "plateau_pattern_class", "orbit_pattern_class"],
        )
    if orbit_plateau_pattern_class is None:
        orbit_plateau_pattern_class = choose_scalar(
            block,
            ["orbit_plateau_pattern_class", "plateau_pattern_class", "orbit_pattern_class"],
        )

    if fit_name == "BARI" and not unfolding_strategy:
        unfolding_strategy = "exhaustive_integer_lift_from_metric003"
    if fit_name in ("NUFIT", "VALENCIA") and (not unfolding_strategy or str(unfolding_strategy) == "not_applicable_non_BARI"):
        unfolding_strategy = "canonical_angle_resolved"
    if fit_name in ("NUFIT", "VALENCIA") and not anchor_strategy:
        anchor_strategy = "canonical_global_angular_anchoring"
    if fit_name == "BARI" and not anchor_strategy:
        anchor_strategy = "fit_endpoint_metric003_anchor"

    if fit_name in ("NUFIT", "VALENCIA") and (not directional_method_used or str(directional_method_used) == "not_applicable_non_BARI"):
        directional_method_used = "canonical_angle_resolved"
    elif not directional_method_used:
        if fit_name == "BARI":
            directional_method_used = "fit_aware_integer_lift_unfolded"
        else:
            directional_method_used = "canonical_angle_resolved"

    summary = {
        "fit_name": fit_name,
        "metric_ids": metric_ids,
        "metric_ids_int": metric_ids_int,
        "preferred_directional_coordinate_values": directional,
        "radial_coordinate_values": radial,
        "fit_monotone_increasing": bool(inc_flag),
        "fit_monotone_decreasing": bool(dec_flag),
        "fit_spearman_rho_vs_metric_id": rho_f,
        "fit_abs_spearman_rho_vs_metric_id": abs(rho_f) if rho_f is not None else None,
        "fit_endpoint_separation_last_minus_first": endpoint_f,
        "fit_dynamic_range": dyn_f,
        "fit_ties_count_after_round12": ties_i,
        "directional_method_used": directional_method_used,
        "directional_anchor_strategy": anchor_strategy,
        "directional_unfolding_strategy": unfolding_strategy,
        "bari_lift_vector": lift_vector,
        "orbit_plateau_pattern_class": orbit_plateau_pattern_class,
        "pc1_values": pc1_vals,
        "pc2_values": pc2_vals,
        "radius_values": radius_vals if any(v is not None for v in radius_vals) else (radius_raw if radius_raw is not None else [None] * len(directional)),
        "angle_value_before_unfolding": angle_before,
        "angle_value_after_unfolding": angle_after,
        "source_block": block,
    }
    return summary


# -----------------------------------------------------------------------------
# CSV / JSON assembly
# -----------------------------------------------------------------------------
def build_rows(fit_summaries: Dict[str, Dict[str, Any]]) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for fit_name in EXPECTED_FITS:
        s = fit_summaries[fit_name]
        for idx, metric_id in enumerate(s["metric_ids"]):
            row = {
                "fit_name": fit_name,
                "metric_id": metric_id,
                "metric_id_int": s["metric_ids_int"][idx],
                "preferred_directional_coordinate": s["preferred_directional_coordinate_values"][idx],
                "preferred_directional_coordinate_kind": "angular_intrinsic_coordinate",
                "preferred_directional_coordinate_units": "radians_unwrapped",
                "directional_method_used": s["directional_method_used"],
                "radial_coordinate": s["radial_coordinate_values"][idx] if idx < len(s["radial_coordinate_values"]) else None,
                "radial_coordinate_kind": "radial_deviation_scalar",
                "radial_coordinate_units": "stage5_pc_units",
                "monotone_reference_order_index": idx,
                "fit_monotone_increasing": s["fit_monotone_increasing"],
                "fit_monotone_decreasing": s["fit_monotone_decreasing"],
                "fit_spearman_rho_vs_metric_id": s["fit_spearman_rho_vs_metric_id"],
                "fit_abs_spearman_rho_vs_metric_id": s["fit_abs_spearman_rho_vs_metric_id"],
                "fit_endpoint_separation_last_minus_first": s["fit_endpoint_separation_last_minus_first"],
                "fit_dynamic_range": s["fit_dynamic_range"],
                "fit_ties_count_after_round12": s["fit_ties_count_after_round12"],
                "stage5c_parent_candidate_name": EXPECTED_CANDIDATE,
                "stage5d_status": "formalized_preferred_coordinate",
                "directional_anchor_strategy": s["directional_anchor_strategy"],
                "directional_unfolding_strategy": s["directional_unfolding_strategy"],
                "bari_lift_vector": stringify_compact(s["bari_lift_vector"]),
                "orbit_plateau_pattern_class": s["orbit_plateau_pattern_class"],
                "pc1_value": s["pc1_values"][idx] if idx < len(s["pc1_values"]) else None,
                "pc2_value": s["pc2_values"][idx] if idx < len(s["pc2_values"]) else None,
                "radius_value": s["radius_values"][idx] if idx < len(s["radius_values"]) else None,
                "angle_value_before_unfolding": s["angle_value_before_unfolding"][idx] if idx < len(s["angle_value_before_unfolding"]) else None,
                "angle_value_after_unfolding": s["angle_value_after_unfolding"][idx] if idx < len(s["angle_value_after_unfolding"]) else None,
            }
            rows.append(row)
    return rows


def build_fit_formalization(fit_summaries: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    for fit_name in EXPECTED_FITS:
        s = fit_summaries[fit_name]
        fit_class = (
            "fit_aware_integer_lift_unfolded"
            if fit_name == "BARI"
            else "canonical_angle_resolved"
        )
        block = {
            "fit_class": fit_class,
            "metric_id_ordering": s["metric_ids"],
            "metric_id_int_ordering": s["metric_ids_int"],
            "final_directional_sequence": s["preferred_directional_coordinate_values"],
            "monotone_increasing": s["fit_monotone_increasing"],
            "monotone_decreasing": s["fit_monotone_decreasing"],
            "spearman_rho_vs_metric_id": s["fit_spearman_rho_vs_metric_id"],
            "endpoint_separation_last_minus_first": s["fit_endpoint_separation_last_minus_first"],
            "dynamic_range": s["fit_dynamic_range"],
            "ties_count_after_round12": s["fit_ties_count_after_round12"],
            "directional_method_used": s["directional_method_used"],
            "directional_anchor_strategy": s["directional_anchor_strategy"],
            "directional_unfolding_strategy": s["directional_unfolding_strategy"],
            "pc1_values": s["pc1_values"],
            "pc2_values": s["pc2_values"],
            "radius_values": s["radius_values"],
            "angle_value_before_unfolding": s["angle_value_before_unfolding"],
            "angle_value_after_unfolding": s["angle_value_after_unfolding"],
            "orbit_plateau_pattern_class": s["orbit_plateau_pattern_class"],
        }
        if fit_name == "BARI":
            block.update(
                {
                    "selected_unfolding_strategy": s["directional_unfolding_strategy"] or "exhaustive_integer_lift_from_metric003",
                    "chosen_lift_vector": s["bari_lift_vector"],
                    "lifted_angle_values": s["angle_value_after_unfolding"],
                    "note": "BARI required stronger quotient-resolution via FIT-aware integer-lift angular unfolding.",
                }
            )
        else:
            block.update(
                {
                    "canonical_angular_construction": True,
                    "note": f"{fit_name} resolved by canonical angular anchoring.",
                }
            )
        out[fit_name] = block
    return out


def write_summary_txt(path: Path, fit_summaries: Dict[str, Dict[str, Any]]) -> None:
    lines = []
    lines.append("Stage-5D formalization summary")
    lines.append("=" * 79)
    lines.append(f"created_utc: {utc_now_iso()}")
    lines.append(f"stage: {STAGE}")
    lines.append(f"script_version: {SCRIPT_VERSION}")
    lines.append("")
    lines.append("Imported Stage-5C preferred candidate:")
    lines.append(f"  {EXPECTED_CANDIDATE}")
    lines.append("")
    lines.append("Stage-5 decomposition:")
    lines.append("  radial      -> PC1 / radius-like scalar")
    lines.append("  directional -> angular intrinsic coordinate with FIT-aware unfolding")
    lines.append("")
    lines.append("Fit summaries:")
    for fit_name in EXPECTED_FITS:
        s = fit_summaries[fit_name]
        lines.append(
            f"  - {fit_name}: monotone_inc={s['fit_monotone_increasing']}, "
            f"rho={s['fit_spearman_rho_vs_metric_id']}, method={s['directional_method_used']}"
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------
def parse_cli(argv: Sequence[str]) -> Dict[str, Optional[Path]]:
    args = list(argv[1:])
    out: Dict[str, Optional[Path]] = {
        "project_root": None,
        "stage5c_json": None,
        "stage5c_csv": None,
        "stage5b_json": None,
        "stage5b_csv": None,
        "output_dir": None,
    }
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--project-root" and i + 1 < len(args):
            out["project_root"] = Path(args[i + 1])
            i += 2
        elif a == "--stage5c-json" and i + 1 < len(args):
            out["stage5c_json"] = Path(args[i + 1])
            i += 2
        elif a == "--stage5c-csv" and i + 1 < len(args):
            out["stage5c_csv"] = Path(args[i + 1])
            i += 2
        elif a == "--stage5b-json" and i + 1 < len(args):
            out["stage5b_json"] = Path(args[i + 1])
            i += 2
        elif a == "--stage5b-csv" and i + 1 < len(args):
            out["stage5b_csv"] = Path(args[i + 1])
            i += 2
        elif a == "--output-dir" and i + 1 < len(args):
            out["output_dir"] = Path(args[i + 1])
            i += 2
        else:
            raise SystemExit(f"Unknown or incomplete argument: {a}")
    return out


def main(argv: Sequence[str]) -> int:
    cli = parse_cli(argv)
    project_root = discover_project_root(cli_root=cli["project_root"])

    stage5c_json = cli["stage5c_json"] or (project_root / "metric_stage_5C_outputs" / "stage5C_intrinsic_coordinate_from_PC1_PC2_v4.json")
    stage5c_csv = cli["stage5c_csv"] or (project_root / "metric_stage_5C_outputs" / "stage5C_intrinsic_coordinate_from_PC1_PC2_v4.csv")
    stage5b_json = cli["stage5b_json"] or (project_root / "metric_stage_5B_outputs" / "stage5B_metric_candidate_from_global_PC1_v1.json")
    stage5b_csv = cli["stage5b_csv"] or (project_root / "metric_stage_5B_outputs" / "stage5B_metric_candidate_from_global_PC1_v1.csv")
    output_dir = cli["output_dir"] or (project_root / "metric_stage_5D_outputs")

    ensure_dir(output_dir)

    if not stage5c_json.exists():
        raise FileNotFoundError(f"Required Stage-5C JSON not found: {stage5c_json}")

    stage5c = load_json(stage5c_json)
    stage5c_csv_df = try_load_csv(stage5c_csv)
    stage5b_json_data = load_json(stage5b_json) if stage5b_json.exists() else None
    stage5b_csv_df = try_load_csv(stage5b_csv)

    imported_candidate = extract_recommended_candidate(stage5c)
    if imported_candidate != EXPECTED_CANDIDATE:
        raise RuntimeError(
            "Stage-5C v4 recommended candidate mismatch. "
            f"Expected '{EXPECTED_CANDIDATE}' but extracted '{imported_candidate}'."
        )

    fit_blocks = find_fit_blocks(stage5c)
    missing_fits = [f for f in EXPECTED_FITS if f not in fit_blocks]
    if missing_fits:
        raise RuntimeError(f"Missing FIT blocks in Stage-5C v4 JSON: {missing_fits}")

    fit_summaries: Dict[str, Dict[str, Any]] = {}
    for fit_name in EXPECTED_FITS:
        fit_summaries[fit_name] = extract_fit_summary_from_block(fit_name, fit_blocks[fit_name])

    rows = build_rows(fit_summaries)
    df = pd.DataFrame(rows)

    csv_path = output_dir / "stage5D_formalized_preferred_intrinsic_coordinate_v1b.csv"
    json_path = output_dir / "stage5D_formalized_preferred_intrinsic_coordinate_v1b.json"
    txt_path = output_dir / "stage5D_formalized_preferred_intrinsic_coordinate_v1b_summary.txt"

    df.to_csv(csv_path, index=False)

    fit_level_formalization = build_fit_formalization(fit_summaries)

    json_payload = {
        "created_utc": utc_now_iso(),
        "stage": STAGE,
        "script_version": SCRIPT_VERSION,
        "inputs": {
            "project_root": project_root,
            "stage5c_json": stage5c_json,
            "stage5c_csv": stage5c_csv if stage5c_csv.exists() else None,
            "stage5b_json": stage5b_json if stage5b_json.exists() else None,
            "stage5b_csv": stage5b_csv if stage5b_csv.exists() else None,
        },
        "stage5c_decision_imported": {
            "expected_recommended_candidate_name": EXPECTED_CANDIDATE,
            "imported_recommended_candidate_name": imported_candidate,
            "aggregate_comparison_snapshot": extract_aggregate_snapshot(stage5c),
        },
        "formal_stage5_coordinate_decision": {
            "status": "settled_for_stage5",
            "preferred_directional_coordinate_name": EXPECTED_CANDIDATE,
            "preferred_directional_coordinate_kind": "angular_intrinsic_coordinate",
            "radial_component_name": "pc1_radius_like_scalar",
            "radial_component_kind": "radial_deviation_scalar",
            "interpretation": [
                "Stage-5 geometry admits a radial-vs-directional decomposition.",
                "The radial component is structurally stable but not intrinsically orderable by metric_id.",
                "The directional component is angular rather than linear.",
                "BARI requires FIT-aware integer-lift angular unfolding.",
                "NUFIT and VALENCIA are resolved by canonical angular anchoring.",
            ],
        },
        "radial_directional_decomposition": {
            "radial_component": {
                "name": "pc1_radius_like_scalar",
                "kind": "radial_deviation_scalar",
                "units": "stage5_pc_units",
                "interpretation": "PC1 / radius-like deviation scalar",
            },
            "directional_component": {
                "name": EXPECTED_CANDIDATE,
                "kind": "angular_intrinsic_coordinate",
                "units": "radians_unwrapped",
                "interpretation": "angular intrinsic coordinate with FIT-aware unfolding",
            },
        },
        "fit_level_formalization": fit_level_formalization,
        "tabular_output_schema": {
            "row_definition": "one row per (FIT, metric_id) pair",
            "required_csv_columns": list(df.columns),
        },
        "outputs": {
            "csv": csv_path,
            "json": json_path,
            "summary_txt": txt_path,
            "row_count": int(len(df)),
            "fit_names": EXPECTED_FITS,
        },
        "provenance_snapshots": {
            "stage5c_raw_excerpt_keys": sorted(list(stage5c.keys())),
            "stage5b_json_present": bool(stage5b_json_data is not None),
            "stage5b_csv_present": bool(stage5b_csv_df is not None),
            "stage5c_csv_present": bool(stage5c_csv_df is not None),
        },
    }

    with json_path.open("w", encoding="utf-8") as f:
        json.dump(make_json_safe(json_payload), f, indent=2, ensure_ascii=False)

    write_summary_txt(txt_path, fit_summaries)

    print("[Stage-5D formalization v1b] Wrote:")
    print(f"  CSV : {csv_path}")
    print(f"  JSON: {json_path}")
    print(f"  TXT : {txt_path}")
    print()
    print("[Stage-5D formalization v1b] Imported Stage-5C preferred candidate:")
    print(f"  {EXPECTED_CANDIDATE}")
    print()
    print("[Stage-5D formalization v1b] Fit summaries:")
    for fit_name in EXPECTED_FITS:
        s = fit_summaries[fit_name]
        print(
            f"  - {fit_name}: monotone_inc={s['fit_monotone_increasing']}, "
            f"rho={s['fit_spearman_rho_vs_metric_id']}, method={s['directional_method_used']}"
        )
    print()
    print("[Stage-5D formalization v1b] Stage-5 decomposition:")
    print("  radial     -> PC1 / radius-like scalar")
    print("  directional -> angular intrinsic coordinate with FIT-aware unfolding")

    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
