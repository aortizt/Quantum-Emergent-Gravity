import sys
import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

repo_root = "/home/dakini/Downloads/010-Quantum_Emergent_Gravity"
csv_path = os.path.join(
    repo_root,
    "metric_stage_5B_outputs",
    "stage5B_pca_dimension_test_vNEXT.csv"
)

# ---------------------------------------------------------------------
# Provenance / decision note
# ---------------------------------------------------------------------
# This auxiliary Spyder script is used to inspect the global (PC1, PC2)
# geometry of the enriched Stage-5B feature space after the earlier
# auxiliary script:
#
#   Spyder_Console_Computes_global_PC2_03_14_2026.py
#
# established that:
#   - global EVR ~ [0.5639, 0.3859, 0.0502, ~0, ~0, 0]
#   - PC2 is structured, not noise
#   - PC2 loads mainly on:
#       transport_z            +0.289406
#       comm_mean_w_z          +0.522915
#       comm_var_w_z           +0.023271
#       comm_band_dispersion_z -0.429432
#       comm_band_contrast_z   -0.429432
#       shape_z                -0.522915
#
# Purpose of THIS script:
#   - visualize whether PC2 behaves as FIT-contrast / family deformation
#     rather than a second intrinsic metric coordinate;
#   - support the Stage-5B decision:
#         promote global PC1 as metric candidate,
#         retain PC2 as diagnostics-only.
# ---------------------------------------------------------------------

df = pd.read_csv(csv_path)

features = [
    "transport_z",
    "comm_mean_w_z",
    "comm_var_w_z",
    "comm_band_dispersion_z",
    "comm_band_contrast_z",
    "shape_z",
]

X = df[features].values.astype(float)
X_centered = X - X.mean(axis=0)

cov = np.cov(X_centered, rowvar=False)
eigvals, eigvecs = np.linalg.eigh(cov)

# Sort descending
idx = np.argsort(eigvals)[::-1]
eigvals = eigvals[idx]
eigvecs = eigvecs[:, idx]

# Scores in global PCA coordinates
scores = X_centered @ eigvecs
df["global_PC1"] = scores[:, 0]
df["global_PC2"] = scores[:, 1]
df["global_PC3"] = scores[:, 2]

# EVR
total = eigvals[eigvals > 0].sum()
evr = eigvals / eigvals.sum() if eigvals.sum() != 0 else np.zeros_like(eigvals)

print("\nGlobal eigenvalues:")
print(eigvals)

print("\nGlobal EVR:")
print(evr)

print("\nGlobal PC1 eigenvector:")
for f, v in zip(features, eigvecs[:, 0]):
    print(f"{f:25s} {v:+.6f}")

print("\nGlobal PC2 eigenvector:")
for f, v in zip(features, eigvecs[:, 1]):
    print(f"{f:25s} {v:+.6f}")

# ---------------------------------------------------------------------
# FIT centroids in global PC plane
# ---------------------------------------------------------------------
print("\nFIT centroids in (global_PC1, global_PC2):")
centroids = (
    df.groupby("FIT_id")[["global_PC1", "global_PC2"]]
      .mean()
      .reset_index()
)

for _, row in centroids.iterrows():
    print(
        f"{row['FIT_id']:10s}  "
        f"PC1={row['global_PC1']:+.6f}  "
        f"PC2={row['global_PC2']:+.6f}"
    )

# ---------------------------------------------------------------------
# Per-FIT principal direction inside the global PC1-PC2 plane
# ---------------------------------------------------------------------
print("\nPer-FIT dominant direction inside global (PC1, PC2) plane:")
for fit_id, g in df.groupby("FIT_id"):
    Y = g[["global_PC1", "global_PC2"]].values
    Yc = Y - Y.mean(axis=0)
    cov2 = np.cov(Yc, rowvar=False)
    vals2, vecs2 = np.linalg.eigh(cov2)
    j = np.argsort(vals2)[::-1]
    vals2 = vals2[j]
    vecs2 = vecs2[:, j]

    direction = vecs2[:, 0]
    angle_deg = np.degrees(np.arctan2(direction[1], direction[0]))

    print(
        f"{fit_id:10s}  "
        f"lambda1={vals2[0]:.6f}  lambda2={vals2[1]:.6f}  "
        f"dir=({direction[0]:+.6f}, {direction[1]:+.6f})  "
        f"angle_deg={angle_deg:+.2f}"
    )

# ---------------------------------------------------------------------
# Plot
# ---------------------------------------------------------------------
fig, ax = plt.subplots(figsize=(9, 7))

fit_order = sorted(df["FIT_id"].unique())
markers = {
    "BARI": "o",
    "NUFIT": "s",
    "VALENCIA": "^",
}

for fit_id in fit_order:
    g = df[df["FIT_id"] == fit_id]
    ax.scatter(
        g["global_PC1"],
        g["global_PC2"],
        s=90,
        marker=markers.get(fit_id, "o"),
        label=fit_id,
        alpha=0.85
    )

    for _, row in g.iterrows():
        ax.text(
            row["global_PC1"] + 0.01,
            row["global_PC2"] + 0.01,
            str(row["metric_id"]),
            fontsize=8
        )

# plot centroids
for _, row in centroids.iterrows():
    ax.scatter(
        row["global_PC1"],
        row["global_PC2"],
        s=180,
        marker="x",
        linewidths=2.0
    )
    ax.text(
        row["global_PC1"] + 0.02,
        row["global_PC2"] + 0.02,
        f"{row['FIT_id']}_centroid",
        fontsize=9
    )

ax.axhline(0.0, linewidth=1.0)
ax.axvline(0.0, linewidth=1.0)
ax.set_xlabel("global_PC1")
ax.set_ylabel("global_PC2")
ax.set_title("Stage-5B enriched geometry in global (PC1, PC2) plane")
ax.legend()
ax.grid(True, alpha=0.25)
plt.tight_layout()
plt.show()
