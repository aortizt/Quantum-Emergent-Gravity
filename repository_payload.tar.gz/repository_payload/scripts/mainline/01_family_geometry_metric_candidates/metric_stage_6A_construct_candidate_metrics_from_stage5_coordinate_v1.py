# =============================================================================
# metric_stage_6A_construct_candidate_metrics_from_stage5_coordinate_v1.py
# =============================================================================
# Stage-6A: Construct candidate metrics over (r, θ)
#
# Provenance:
#   Upstream (frozen):
#     - /home/dakini/Downloads/010-Quantum_Emergent_Gravity/
#       metric_stage_5D_outputs/
#       stage5D_formalized_preferred_intrinsic_coordinate_v1b.csv
#     - /home/dakini/Downloads/010-Quantum_Emergent_Gravity/
#       metric_stage_5D_outputs/
#       stage5D_formalized_preferred_intrinsic_coordinate_v1b.json
#
#   Script location (recommended):
#     - /home/dakini/Downloads/010-Quantum_Emergent_Gravity/
#       metric_stage_6A_scripts/
#       metric_stage_6A_construct_candidate_metrics_from_stage5_coordinate_v1.py
#
#   Downstream outputs:
#     - /home/dakini/Downloads/010-Quantum_Emergent_Gravity/
#       metric_stage_6A_outputs/
#       stage6A_metric_candidates_pairwise_distances_v1.csv
#     - /home/dakini/Downloads/010-Quantum_Emergent_Gravity/
#       metric_stage_6A_outputs/
#       stage6A_metric_candidates_summary_v1.json
#     - /home/dakini/Downloads/010-Quantum_Emergent_Gravity/
#       metric_stage_6A_outputs/
#       stage6A_provenance_v1.json
#
# Design:
#   - Build multiple candidate metrics
#   - Evaluate pairwise distances within each FIT
#   - NO ranking collapse yet
#   - NO physics interpretation yet
#
# Notes:
#   - Stage-5 coordinate is treated as frozen input
#   - Angular coordinate is consumed from preferred_directional_coordinate
#   - Radial coordinate is consumed from radial_coordinate
#   - Angular coordinate is assumed already unwrapped
#   - Radial coordinate is sanitized to be strictly positive if needed
#
# =============================================================================

import os
import sys
import glob
import json
import hashlib
import datetime
import numpy as np
import pandas as pd

# =============================================================================
# PATH RESOLUTION (Spyder-friendly, script-aware)
# =============================================================================

BASE_DIR = "/home/dakini/Downloads/010-Quantum_Emergent_Gravity"

SCRIPT_DIR = os.path.join(BASE_DIR, "metric_stage_6A_scripts")
INPUT_DIR = os.path.join(BASE_DIR, "metric_stage_5D_outputs")
OUTPUT_DIR = os.path.join(BASE_DIR, "metric_stage_6A_outputs")

os.makedirs(OUTPUT_DIR, exist_ok=True)

try:
    SCRIPT_PATH = os.path.abspath(__file__)
except NameError:
    SCRIPT_PATH = os.path.abspath(sys.argv[0])

csv_files = glob.glob(
    os.path.join(INPUT_DIR, "stage5D_formalized_preferred_intrinsic_coordinate_v1b.csv")
)
json_files = glob.glob(
    os.path.join(INPUT_DIR, "stage5D_formalized_preferred_intrinsic_coordinate_v1b.json")
)

assert len(csv_files) == 1, "CSV input not found or ambiguous"
assert len(json_files) == 1, "JSON input not found or ambiguous"

CSV_PATH = csv_files[0]
JSON_PATH = json_files[0]

# =============================================================================
# LOAD DATA
# =============================================================================

df = pd.read_csv(CSV_PATH)

print("[Stage-6A] Detected columns:")
print(df.columns.tolist())

# =============================================================================
# COLUMN NORMALIZATION (Stage-5D v1b schema)
# =============================================================================

required_stage5d_cols = [
    "fit_name",
    "metric_id",
    "preferred_directional_coordinate",
    "radial_coordinate",
]

for col in required_stage5d_cols:
    assert col in df.columns, f"Missing required Stage-5D column: {col}"

df = df.rename(columns={
    "fit_name": "FIT",
    "metric_id": "metric_id",
    "preferred_directional_coordinate": "theta",
    "radial_coordinate": "r",
})

print("[Stage-6A] Canonical column mapping:")
print({
    "FIT": "fit_name",
    "metric_id": "metric_id",
    "theta": "preferred_directional_coordinate",
    "r": "radial_coordinate",
})

# =============================================================================
# OPTIONAL SCHEMA CHECKS
# =============================================================================

if "preferred_directional_coordinate_units" in df.columns:
    units = sorted(df["preferred_directional_coordinate_units"].dropna().unique().tolist())
    print("[Stage-6A] Directional units:", units)

if "preferred_directional_coordinate_kind" in df.columns:
    kinds = sorted(df["preferred_directional_coordinate_kind"].dropna().unique().tolist())
    print("[Stage-6A] Directional kind:", kinds)

if "radial_coordinate_units" in df.columns:
    radial_units = sorted(df["radial_coordinate_units"].dropna().unique().tolist())
    print("[Stage-6A] Radial units:", radial_units)

if "radial_coordinate_kind" in df.columns:
    radial_kinds = sorted(df["radial_coordinate_kind"].dropna().unique().tolist())
    print("[Stage-6A] Radial kind:", radial_kinds)

# =============================================================================
# TYPE ENFORCEMENT
# =============================================================================

df["r"] = pd.to_numeric(df["r"], errors="raise")
df["theta"] = pd.to_numeric(df["theta"], errors="raise")

# =============================================================================
# SANITIZE RADIAL COMPONENT
# =============================================================================

EPS = 1e-8
radial_shift_applied = False
radial_shift_amount = 0.0

if (df["r"] <= 0).any():
    r_min = df["r"].min()
    radial_shift_amount = float(-r_min + EPS)
    df["r"] = df["r"] - r_min + EPS
    radial_shift_applied = True

# =============================================================================
# PARAMETER GRID
# =============================================================================

alpha_values = [0.5, 1.0, 2.0]
beta_values = [0.5, 1.0, 2.0]

# =============================================================================
# METRIC DEFINITIONS
# =============================================================================

def metric_euclidean(dr, dtheta, r1, r2, alpha, beta):
    return alpha * (dr ** 2) + beta * (dtheta ** 2)

def metric_radial_weighted(dr, dtheta, r1, r2, alpha, beta):
    r_bar = 0.5 * (r1 + r2)
    return alpha * (dr ** 2) + beta * (r_bar ** 2) * (dtheta ** 2)

def metric_log_radial(dr, dtheta, r1, r2, alpha, beta):
    log_r1 = np.log(r1)
    log_r2 = np.log(r2)
    dlogr = log_r2 - log_r1
    return alpha * (dlogr ** 2) + beta * (dtheta ** 2)

def metric_hybrid(dr, dtheta, r1, r2, alpha, beta):
    f = (r1 * r2) ** 0.5
    return alpha * (dr ** 2) + beta * f * (dtheta ** 2)

metric_registry = {
    "euclidean": metric_euclidean,
    "radial_weighted": metric_radial_weighted,
    "log_radial": metric_log_radial,
    "hybrid": metric_hybrid,
}

# =============================================================================
# PAIRWISE DISTANCE COMPUTATION
# =============================================================================

records = []

for fit_name, df_fit in df.groupby("FIT"):
    df_fit = df_fit.sort_values("metric_id").reset_index(drop=True)

    for i in range(len(df_fit)):
        for j in range(i + 1, len(df_fit)):
            row_i = df_fit.iloc[i]
            row_j = df_fit.iloc[j]

            dr = row_j["r"] - row_i["r"]
            dtheta = row_j["theta"] - row_i["theta"]

            for metric_name, metric_func in metric_registry.items():
                for alpha in alpha_values:
                    for beta in beta_values:
                        d2 = metric_func(
                            dr=dr,
                            dtheta=dtheta,
                            r1=row_i["r"],
                            r2=row_j["r"],
                            alpha=alpha,
                            beta=beta,
                        )

                        records.append({
                            "FIT": fit_name,
                            "metric_id_i": row_i["metric_id"],
                            "metric_id_j": row_j["metric_id"],
                            "metric_name": metric_name,
                            "alpha": alpha,
                            "beta": beta,
                            "distance_squared": float(d2),
                            "dr": float(dr),
                            "dtheta": float(dtheta),
                            "r_i": float(row_i["r"]),
                            "r_j": float(row_j["r"]),
                        })

pairwise_df = pd.DataFrame(records)

# =============================================================================
# DIAGNOSTICS (LIGHT — Stage-6A only)
# =============================================================================

summary = {}

for metric_name in metric_registry.keys():
    df_m = pairwise_df[pairwise_df["metric_name"] == metric_name]

    summary[metric_name] = {
        "mean_distance_squared": float(df_m["distance_squared"].mean()),
        "std_distance_squared": float(df_m["distance_squared"].std()),
        "min_distance_squared": float(df_m["distance_squared"].min()),
        "max_distance_squared": float(df_m["distance_squared"].max()),
        "count": int(len(df_m)),
    }

summary["_meta"] = {
    "stage": "6A",
    "description": "Initial candidate metric construction over frozen Stage-5 (r, theta) coordinate",
    "alpha_values": alpha_values,
    "beta_values": beta_values,
    "metric_names": list(metric_registry.keys()),
    "radial_shift_applied": radial_shift_applied,
    "radial_shift_amount": radial_shift_amount,
    "input_schema": {
        "fit_column": "fit_name",
        "metric_id_column": "metric_id",
        "theta_column": "preferred_directional_coordinate",
        "r_column": "radial_coordinate",
    },
}

# =============================================================================
# OUTPUT
# =============================================================================

csv_out = os.path.join(
    OUTPUT_DIR,
    "stage6A_metric_candidates_pairwise_distances_v1.csv"
)
json_out = os.path.join(
    OUTPUT_DIR,
    "stage6A_metric_candidates_summary_v1.json"
)

pairwise_df.to_csv(csv_out, index=False)

with open(json_out, "w") as f:
    json.dump(summary, f, indent=2)

# =============================================================================
# PROVENANCE HASHES (FULL TRACEABILITY)
# =============================================================================

def sha256_of_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        h.update(f.read())
    return h.hexdigest()

SCRIPT_SHA256 = sha256_of_file(SCRIPT_PATH)
INPUT_CSV_SHA256 = sha256_of_file(CSV_PATH)
INPUT_JSON_SHA256 = sha256_of_file(JSON_PATH)

provenance = {
    "timestamp_utc": datetime.datetime.utcnow().isoformat(),
    "script_path": SCRIPT_PATH,
    "script_sha256": SCRIPT_SHA256,
    "python_executable": sys.executable,
    "base_dir": BASE_DIR,
    "script_dir_expected": SCRIPT_DIR,
    "input_dir": INPUT_DIR,
    "output_dir": OUTPUT_DIR,
    "input_csv_path": CSV_PATH,
    "input_csv_sha256": INPUT_CSV_SHA256,
    "input_json_path": JSON_PATH,
    "input_json_sha256": INPUT_JSON_SHA256,
    "output_csv_path": csv_out,
    "output_json_path": json_out,
}

prov_path = os.path.join(OUTPUT_DIR, "stage6A_provenance_v1.json")

with open(prov_path, "w") as f:
    json.dump(provenance, f, indent=2)

# =============================================================================
# CONSOLE REPORT
# =============================================================================

print("[Stage-6A] Outputs written:")
print("  CSV :", csv_out)
print("  JSON:", json_out)
print("  PROV:", prov_path)
print("  SCRIPT PATH:", SCRIPT_PATH)
print("  SCRIPT SHA256:", SCRIPT_SHA256)
