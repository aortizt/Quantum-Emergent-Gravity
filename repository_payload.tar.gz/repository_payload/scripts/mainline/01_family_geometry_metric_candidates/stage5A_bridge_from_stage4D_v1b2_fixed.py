#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Feb 14 23:00:25 2026

@author: Arturo Ortiz-Tapia
Stage-5A (Option A): Bridge table from Stage-4D transport scalars + Stage-4B comm_norm summary (v1b2).

Inputs:
  - stage4C_microfeatures_canonical_v1_plus_transport_v1.csv  (15 rows; FIT_id x metric_003..007)
  - stage4B_commonly_v*.csv (Option-A comm_norm summary; discovered)

Outputs:
  - stage5A_bridge_from_4D_v1b.csv (15 rows; join+driver columns)
  - stage5A_bridge_diagnostics_v1b.json

No renames. No Stage-3A regeneration. Option-A consistent.
"""

from __future__ import annotations

import argparse
import glob
import hashlib
import json
import os
import sys
import datetime as _dt
from typing import Dict, Optional, List

import pandas as pd
import numpy as np


def now_iso() -> str:
    return _dt.datetime.now().isoformat(timespec="seconds")


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def find_repo_root(user_repo_root: Optional[str]) -> str:
    if user_repo_root and os.path.isdir(user_repo_root):
        return os.path.abspath(user_repo_root)
    here = os.path.abspath(os.path.dirname(__file__))
    cur = here
    for _ in range(6):
        if os.path.isdir(os.path.join(cur, "__qeg_evidence__")):
            return cur
        nxt = os.path.dirname(cur)
        if nxt == cur:
            break
        cur = nxt
    raise FileNotFoundError("Could not determine repo_root. Pass --repo_root explicitly.")


def ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)


def find_stage4d_enriched_csv(repo_root: str, explicit: Optional[str]) -> str:
    if explicit and os.path.isfile(explicit):
        return os.path.abspath(explicit)

    patt = os.path.join(repo_root, "**", "stage4C_microfeatures_canonical_v1_plus_transport_v1.csv")
    hits = glob.glob(patt, recursive=True)
    if not hits:
        raise FileNotFoundError(f"Could not find Stage-4D enriched CSV via pattern: {patt}")
    hits.sort(key=lambda p: (("metric_stage_4C_outputs" not in p), len(p)))
    return os.path.abspath(hits[0])


def find_stage4b_comm_norm_csv(repo_root: str, explicit: Optional[str]) -> str:
    if explicit and os.path.isfile(explicit):
        return os.path.abspath(explicit)

    # Preferred candidates (Option-A “commonly”)
    preferred_names = [
        "stage4B_alpha_commonly_v2.csv",
        "stage4B_commonly_v1.csv",
        "stage4B_alpha_commonly.csv",
    ]

    for name in preferred_names:
        patt = os.path.join(repo_root, "**", name)
        hits = glob.glob(patt, recursive=True)
        if hits:
            hits.sort(key=len)
            return os.path.abspath(hits[0])

    # Fallback: anything with 'commonly' in name
    patt = os.path.join(repo_root, "**", "*commonly*.csv")
    hits = glob.glob(patt, recursive=True)
    if not hits:
        raise FileNotFoundError("Could not find any Stage-4B commonly/comm_norm CSV.")
    hits.sort(key=len)
    return os.path.abspath(hits[0])


def choose_output_dir(repo_root: str) -> str:
    d5a = os.path.join(repo_root, "metric_stage_5A_outputs")
    if os.path.isdir(d5a):
        return d5a
    # ok to create a new stage folder; not a rename
    try:
        ensure_dir(d5a)
        return d5a
    except Exception:
        # fallback to stage4C outputs
        d4c = os.path.join(repo_root, "metric_stage_4C_outputs")
        ensure_dir(d4c)
        return d4c


def add_driver_columns(df: pd.DataFrame, topk_per_fit: int = 1, global_quantile: float = 0.80) -> pd.DataFrame:
    out = df.copy()

    obs = pd.to_numeric(out["obstruction_score"], errors="coerce")
    out["obstruction_quantile_global"] = obs.rank(pct=True)

    # rank within each FIT: 1 = highest
    out["obstruction_rank_within_fit"] = (
        out.groupby("FIT_id")["obstruction_score"]
           .rank(ascending=False, method="min")
    )

    out["is_obstruction_topk_fit"] = out["obstruction_rank_within_fit"] <= float(topk_per_fit)

    thr = obs.quantile(global_quantile)
    out["obstruction_hi_global_threshold"] = float(thr) if not np.isnan(thr) else np.nan
    out["is_obstruction_hi_global"] = obs >= thr if not np.isnan(thr) else False

    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo_root", default=None)
    ap.add_argument("--stage4d_csv", default=None, help="Explicit path to stage4C_microfeatures_canonical_v1_plus_transport_v1.csv")
    ap.add_argument("--stage4b_csv", default=None, help="Explicit path to stage4B commonly/comm_norm CSV")
    ap.add_argument("--topk_per_fit", type=int, default=1)
    ap.add_argument("--global_quantile", type=float, default=0.80)
    ap.add_argument("--write_csv_name", default="stage5A_bridge_from_4D_v1b.csv")
    ap.add_argument("--diag_json_name", default="stage5A_bridge_diagnostics_v1b.json")
    args = ap.parse_args()

    repo_root = find_repo_root(args.repo_root)
    in_4d = find_stage4d_enriched_csv(repo_root, args.stage4d_csv)
    in_4b = find_stage4b_comm_norm_csv(repo_root, args.stage4b_csv)

    df4d = pd.read_csv(in_4d)
    df4b = pd.read_csv(in_4b)

    # --- Backward compatibility: Stage-4B commonly schema (v1b2) ---
    if "FIT_id" not in df4b.columns:
        if "FIT" in df4b.columns:
            # Stage-4D FIT_id is plain FIT (BARI/NUFIT/VALENCIA), so match that.
            df4b["FIT_id"] = df4b["FIT"].astype(str)
        else:
            raise ValueError("Stage-4B table missing FIT_id and cannot infer it (need FIT).")

    if "metric_id" not in df4b.columns and "npz_file" in df4b.columns:
        import re
        def _extract_metric_id(p):
            m = re.search(r"__metric_(\d{3})__", str(p))
            return f"metric_{m.group(1)}" if m else None
        df4b["metric_id"] = df4b["npz_file"].map(_extract_metric_id)

    # Hard fail if we still couldn't normalize keys
    if "FIT_id" not in df4b.columns:
        raise ValueError("Stage-4B table missing FIT_id and cannot infer it (need FIT).")
    if "metric_id" not in df4b.columns or df4b["metric_id"].isna().any():
        bad = df4b[df4b.get("metric_id").isna()][["npz_file"]].head(10) if "npz_file" in df4b.columns else None
        raise ValueError(f"Stage-4B table missing metric_id and cannot infer it from npz_file. Examples:\n{bad}")
    # --- End compatibility block ---


    # Require join keys
    for key in ["FIT_id", "metric_id"]:
        if key not in df4d.columns:
            raise ValueError(f"Stage-4D table missing key column: {key}")
        if key not in df4b.columns:
            raise ValueError(f"Stage-4B table missing key column: {key}")

    # Reduce Stage-4B deterministically across bands:
    # Prefer widest band (band_width), tie-break by comm_band_mean.
    if {"band_width", "comm_band_mean"}.issubset(df4b.columns):
        df4b_dedup = (
            df4b.sort_values(
                ["FIT_id", "metric_id", "band_width", "comm_band_mean"],
                ascending=[True, True, False, False],
            )
            .drop_duplicates(subset=["FIT_id", "metric_id"], keep="first")
            .copy()
        )
    else:
        # Fallback: first row per key
        df4b_dedup = df4b.drop_duplicates(subset=["FIT_id", "metric_id"]).copy()


    # Join
    merged = df4d.merge(df4b_dedup, on=["FIT_id", "metric_id"], how="left", suffixes=("", "__stage4B"))

    # Driver columns
    merged = add_driver_columns(merged, topk_per_fit=args.topk_per_fit, global_quantile=args.global_quantile)

    # Outputs
    out_dir = choose_output_dir(repo_root)
    out_csv = os.path.join(out_dir, args.write_csv_name)
    out_json = os.path.join(out_dir, args.diag_json_name)

    merged.to_csv(out_csv, index=False)

    diag = {
        "timestamp": now_iso(),
        "script": os.path.relpath(__file__, repo_root),
        "inputs": {
            "stage4d_csv": in_4d,
            "stage4d_sha256": sha256_file(in_4d),
            "stage4b_csv": in_4b,
            "stage4b_sha256": sha256_file(in_4b),
        },
        "outputs": {
            "out_csv": out_csv,
            "out_csv_sha256": sha256_file(out_csv),
        },
        "row_counts": {
            "stage4d_rows": int(df4d.shape[0]),
            "stage4b_rows": int(df4b.shape[0]),
            "stage4b_rows_dedup": int(df4b_dedup.shape[0]),
            "merged_rows": int(merged.shape[0]),
            "merged_with_stage4b_match": int(merged["comm_band_mean"].notna().sum()) if "comm_band_mean" in merged.columns else 0,
        },
        "driver_policy": {
            "topk_per_fit": int(args.topk_per_fit),
            "global_quantile": float(args.global_quantile),
        },
        "notes": [
            "Stage-5A bridge joins Stage-4D enriched microfeatures/transport scalars with Stage-4B comm_norm summary.",
            "Driver columns computed from obstruction_score (rank within FIT, global quantile threshold flags).",
            "v1b2: Stage-4B reduced deterministically (max band_width, tie-break by comm_band_mean); FIT_id inferred as FIT to match Stage-4D; discovery prefers stage4B_alpha_commonly_v2.csv.",
            "Option A consistent; no Stage-3A regeneration.",
            "Metrics expected: metric_003..metric_007 across FITs (15 rows).",
        ],
    }

    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(diag, f, indent=2)

    # Manual ledger block (until evidence.py signature patched)
    print("\nMANUAL_EVIDENCE_LEDGER_BLOCK (paste into __qeg_evidence__/EVIDENCE_LEDGER.md):")
    print("----")
    print(f"- timestamp: {diag['timestamp']}")
    print(f"  stage: Stage-5A")
    print(f"  script: {diag['script']} (v1b2)")
    print(f"  inputs: {os.path.relpath(in_4d, repo_root)} sha256={diag['inputs']['stage4d_sha256']}")
    print(f"          {os.path.relpath(in_4b, repo_root)} sha256={diag['inputs']['stage4b_sha256']}")
    print(f"  outputs: {os.path.relpath(out_csv, repo_root)} sha256={diag['outputs']['out_csv_sha256']}")
    print(f"           {os.path.relpath(out_json, repo_root)}")
    print(f"  row_counts: {diag['row_counts']}")
    print("  notes:")
    for n in diag["notes"]:
        print(f"    - {n}")
    print("----\n")

    print(f"[done] Wrote: {out_csv}")
    print(f"[done] Wrote: {out_json}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
