#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jan 16 16:46:11 2026

Stage-4A: Formal Shell-Band Extraction
Consumes Stage-3A eigshell NPZ outputs and produces
dm32-robust shell bands per FIT.

Author: Arturo Ortiz-Tapia
"""

import os
import json
import glob
import numpy as np
import pandas as pd

# =========================
# CONFIGURATION
# =========================

ROOT = os.path.abspath(os.path.dirname(__file__))

INDIR = os.path.join(ROOT, "metric_stage_3A_outputs")
OUTDIR = os.path.join(ROOT, "metric_stage_4A_outputs")

FITS = ["BARI", "NUFIT", "VALENCIA"]
DM32_MODES = ["signed", "abs", "drop"]

METRIC_NAME = "metric_003"
ZSCORE_MODE = "zscore"

# Thresholds
TAU = 0.5          # activation threshold (robust z-score)
PERSIST_MIN = 2/3  # dm32 persistence threshold
DELTA = 1          # shell adjacency tolerance

# Preferred shell metric order
METRIC_KEYS = ["medianW", "meanW", "maxW"]

os.makedirs(OUTDIR, exist_ok=True)

# =========================
# HELPERS
# =========================

def robust_zscore(x):
    med = np.median(x)
    iqr = np.subtract(*np.percentile(x, [75, 25]))
    if iqr == 0:
        return np.zeros_like(x)
    return (x - med) / iqr


def extract_metric(npz):
    if "comm_norm" not in npz:
        raise KeyError("Expected 'comm_norm' in Stage-3A NPZ")
    W = npz["comm_norm"]
    if W.ndim != 1:
        raise ValueError("comm_norm must be a 1D per-shell array")
    return W



def connected_components(indices, delta=1):
    if len(indices) == 0:
        return []

    indices = sorted(indices)
    bands = []
    start = indices[0]
    prev = indices[0]

    for s in indices[1:]:
        if s - prev <= delta:
            prev = s
        else:
            bands.append((start, prev))
            start = s
            prev = s

    bands.append((start, prev))
    return bands


# =========================
# MAIN
# =========================

all_band_rows = []

for FIT in FITS:
    print(f"\n=== Stage-4A | FIT={FIT} ===")

    shell_metrics = {}
    n_shells = None

    # --- load dm32 data
    for dm32 in DM32_MODES:
        pattern = (
            f"stage3A__eigshells__{METRIC_NAME}__"
            f"{FIT}__{ZSCORE_MODE}__{dm32}.npz"
        )
        path = os.path.join(INDIR, pattern)

        if not os.path.exists(path):
            raise FileNotFoundError(path)

        data = np.load(path, allow_pickle=True)
        W = extract_metric(data)


        if n_shells is None:
            n_shells = len(W)
        else:
            assert len(W) == n_shells, "Shell count mismatch"

        shell_metrics[dm32] = robust_zscore(W)

    # --- persistence per shell
    shells = np.arange(1, n_shells + 1)
    persistence = np.zeros(n_shells)

    for i in range(n_shells):
        active = sum(
            shell_metrics[dm32][i] >= TAU for dm32 in DM32_MODES
        )
        persistence[i] = active / len(DM32_MODES)

    persistent_shells = shells[persistence >= PERSIST_MIN]

    # --- build bands
    bands = connected_components(persistent_shells, delta=DELTA)

    # --- compute band strengths
    band_records = []

    for (s0, s1) in bands:
        idx = np.arange(s0 - 1, s1)
        median_over_dm32 = np.median(
            np.vstack([shell_metrics[d][idx] for d in DM32_MODES]),
            axis=0
        )
        strength = float(np.sum(median_over_dm32))

        band_records.append({
            "band_start": int(s0),
            "band_end": int(s1),
            "width": int(s1 - s0 + 1),
            "strength": strength
        })

        all_band_rows.append({
            "FIT": FIT,
            "band_start": s0,
            "band_end": s1,
            "width": s1 - s0 + 1,
            "strength": strength
        })

    # --- save per-FIT JSON
    out_json = {
        "FIT": FIT,
        "n_shells": n_shells,
        "tau": TAU,
        "persistence_threshold": PERSIST_MIN,
        "bands": band_records
    }

    outpath = os.path.join(OUTDIR, f"stage4A_shellbands_{FIT}.json")
    with open(outpath, "w") as f:
        json.dump(out_json, f, indent=2)

    print(f"Saved {outpath}")

# --- global CSV summary
df = pd.DataFrame(all_band_rows)
csv_path = os.path.join(OUTDIR, "stage4A_shellbands_summary.csv")
df.to_csv(csv_path, index=False)

print(f"\nSaved {csv_path}")
print("\nStage-4A complete.")
