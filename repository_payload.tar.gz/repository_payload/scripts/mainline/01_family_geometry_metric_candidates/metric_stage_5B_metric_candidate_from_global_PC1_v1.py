#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Mar 14 21:45:12 2026

@author: Arturo Ortiz-Tapia
"""


# Provenance note
# This major Stage-5B metric-candidate script is downstream of:
#   - stage5B_pca_dimension_test_vNEXT.{csv,json}
#   - Spyder_Console_Computes_global_PC2_03_14_2026.py
#   - Spyder_Console_plot_global_PC1_PC2_03_14_2026.py
#
# Decision basis:
#   - enriched Stage-5B space is globally rank~2 but per-FIT rank~1;
#   - global PC1 is interpreted as the preferred intrinsic scalar direction;
#   - global PC2 is retained as diagnostics-only (family deformation / FIT contrast).
#
# Therefore this script promotes global PC1, not PC2, into the first
# Stage-5B metric candidate.

import os
import json
import hashlib
from datetime import datetime, timezone

import numpy as np
import pandas as pd


def sha256_of_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def signed_evr(eigvals_desc):
    total = np.sum(eigvals_desc)
    if np.isclose(total, 0.0):
        return np.zeros_like(eigvals_desc)
    return eigvals_desc / total


def normalize_within_fit(series):
    smin = series.min()
    smax = series.max()
    if np.isclose(smax - smin, 0.0):
        return pd.Series(np.zeros(len(series)), index=series.index)
    return (series - smin) / (smax - smin)


def monotonicity_summary(df, raw_col, norm_col):
    out = {}
    for fit_id, g in df.groupby("FIT_id", sort=True):
        g2 = g.sort_values("metric_id").reset_index(drop=True)

        raw_vals = g2[raw_col].tolist()
        norm_vals = g2[norm_col].tolist()

        raw_diffs = np.diff(raw_vals).tolist()
        norm_diffs = np.diff(norm_vals).tolist()

        raw_monotone_inc = bool(np.all(np.diff(raw_vals) >= -1e-12))
        raw_monotone_dec = bool(np.all(np.diff(raw_vals) <=  1e-12))
        norm_monotone_inc = bool(np.all(np.diff(norm_vals) >= -1e-12))
        norm_monotone_dec = bool(np.all(np.diff(norm_vals) <=  1e-12))

        out[fit_id] = {
            "metric_id_order": g2["metric_id"].tolist(),
            "global_PC1_metric_candidate_raw": raw_vals,
            "global_PC1_metric_candidate_norm01_withinFIT": norm_vals,
            "raw_adjacent_differences": raw_diffs,
            "norm_adjacent_differences": norm_diffs,
            "raw_monotone_increasing": raw_monotone_inc,
            "raw_monotone_decreasing": raw_monotone_dec,
            "norm_monotone_increasing": norm_monotone_inc,
            "norm_monotone_decreasing": norm_monotone_dec,
        }
    return out


def leave_one_feature_out_stability(df, features, pc1_ref, score_ref):
    """
    Recompute PC1 leaving one feature out each time.
    Compare:
      1) cosine alignment with reference PC1 restricted to retained features
      2) correlation of candidate scores with reference scores
    """
    results = []

    X_full = df[features].values.astype(float)
    X_full_centered = X_full - X_full.mean(axis=0)

    for drop_feature in features:
        kept = [f for f in features if f != drop_feature]

        X = df[kept].values.astype(float)
        Xc = X - X.mean(axis=0)

        cov = np.cov(Xc, rowvar=False)
        eigvals, eigvecs = np.linalg.eigh(cov)
        idx = np.argsort(eigvals)[::-1]
        eigvals = eigvals[idx]
        eigvecs = eigvecs[:, idx]

        pc1 = eigvecs[:, 0]

        # reference restricted to retained features
        ref_mask = [features.index(f) for f in kept]
        ref_restricted = pc1_ref[ref_mask]

        # normalize both
        ref_norm = np.linalg.norm(ref_restricted)
        pc1_norm = np.linalg.norm(pc1)

        if np.isclose(ref_norm, 0.0) or np.isclose(pc1_norm, 0.0):
            cosine_abs = np.nan
        else:
            cosine = float(np.dot(ref_restricted / ref_norm, pc1 / pc1_norm))
            cosine_abs = abs(cosine)

        score = Xc @ pc1

        # sign-align to maximize correlation
        corr_plus = np.corrcoef(score_ref, score)[0, 1]
        corr_minus = np.corrcoef(score_ref, -score)[0, 1]

        if np.isnan(corr_plus) and np.isnan(corr_minus):
            best_corr = np.nan
            sign_used = 1.0
        elif np.nan_to_num(corr_plus, nan=-np.inf) >= np.nan_to_num(corr_minus, nan=-np.inf):
            best_corr = float(corr_plus)
            sign_used = 1.0
        else:
            best_corr = float(corr_minus)
            sign_used = -1.0

        pc1_aligned = pc1 * sign_used

        results.append({
            "dropped_feature": drop_feature,
            "retained_features": kept,
            "pc1_abs_cosine_alignment_to_reference_restricted": cosine_abs,
            "score_correlation_to_reference": best_corr,
            "pc1_loadings_retained_order": {
                f: float(v) for f, v in zip(kept, pc1_aligned)
            },
            "eigenvalues_desc_retained": [float(v) for v in eigvals.tolist()],
        })

    return results


def main():
    repo_root = "/home/dakini/Downloads/010-Quantum_Emergent_Gravity"
    out_dir = os.path.join(repo_root, "metric_stage_5B_outputs")

    in_csv = os.path.join(out_dir, "stage5B_pca_dimension_test_vNEXT.csv")
    in_json = os.path.join(out_dir, "stage5B_pca_dimension_test_vNEXT.json")

    out_csv = os.path.join(out_dir, "stage5B_metric_candidate_from_global_PC1_v1.csv")
    out_json = os.path.join(out_dir, "stage5B_metric_candidate_from_global_PC1_v1.json")

    if not os.path.exists(in_csv):
        raise FileNotFoundError(f"Missing input CSV: {in_csv}")
    if not os.path.exists(in_json):
        raise FileNotFoundError(f"Missing input JSON: {in_json}")

    df = pd.read_csv(in_csv)

    features = [
        "transport_z",
        "comm_mean_w_z",
        "comm_var_w_z",
        "comm_band_dispersion_z",
        "comm_band_contrast_z",
        "shape_z",
    ]

    missing = [c for c in features if c not in df.columns]
    if missing:
        raise ValueError(f"Missing expected feature columns: {missing}")

    # ------------------------------------------------------------
    # Global PCA from enriched features
    # ------------------------------------------------------------
    X = df[features].values.astype(float)
    X_centered = X - X.mean(axis=0)

    cov = np.cov(X_centered, rowvar=False)
    eigvals, eigvecs = np.linalg.eigh(cov)

    idx = np.argsort(eigvals)[::-1]
    eigvals = eigvals[idx]
    eigvecs = eigvecs[:, idx]

    pc1 = eigvecs[:, 0]
    pc2 = eigvecs[:, 1]

    # Sign convention:
    # orient PC1 so that transport_z loading is positive if possible.
    if pc1[features.index("transport_z")] < 0:
        pc1 = -pc1

    # orient PC2 so that comm_mean_w_z loading is positive if possible.
    if pc2[features.index("comm_mean_w_z")] < 0:
        pc2 = -pc2

    # Recompute scores with sign-adjusted basis vectors
    score_pc1 = X_centered @ pc1
    score_pc2 = X_centered @ pc2

    df["global_PC1_metric_candidate_raw"] = score_pc1
    df["global_PC2_diagnostic_raw"] = score_pc2

    df["global_PC1_metric_candidate_norm01_withinFIT"] = (
        df.groupby("FIT_id", group_keys=False)["global_PC1_metric_candidate_raw"]
          .apply(normalize_within_fit)
    )

    # also keep z-scored within FIT for comparability
    def z_within_fit(s):
        mu = s.mean()
        sd = s.std(ddof=0)
        if np.isclose(sd, 0.0):
            return pd.Series(np.zeros(len(s)), index=s.index)
        return (s - mu) / sd

    df["global_PC1_metric_candidate_z_withinFIT"] = (
        df.groupby("FIT_id", group_keys=False)["global_PC1_metric_candidate_raw"]
          .apply(z_within_fit)
    )

    # rank order within FIT
    df["global_PC1_metric_rank_withinFIT_ascending"] = (
        df.groupby("FIT_id")["global_PC1_metric_candidate_raw"]
          .rank(method="dense", ascending=True)
          .astype(int)
    )

    df["global_PC1_metric_rank_withinFIT_descending"] = (
        df.groupby("FIT_id")["global_PC1_metric_candidate_raw"]
          .rank(method="dense", ascending=False)
          .astype(int)
    )

    # ------------------------------------------------------------
    # Diagnostics
    # ------------------------------------------------------------
    evr = signed_evr(eigvals)

    monotone = monotonicity_summary(
        df=df,
        raw_col="global_PC1_metric_candidate_raw",
        norm_col="global_PC1_metric_candidate_norm01_withinFIT",
    )

    loo = leave_one_feature_out_stability(
        df=df,
        features=features,
        pc1_ref=pc1,
        score_ref=score_pc1,
    )

    fit_centroids = (
        df.groupby("FIT_id")[["global_PC1_metric_candidate_raw", "global_PC2_diagnostic_raw"]]
          .mean()
          .reset_index()
    )

    # ------------------------------------------------------------
    # Write CSV
    # ------------------------------------------------------------
    preferred_cols = [
        "FIT_id",
        "metric_id",
        "preprocess",
        "dm32",
        "transport_z",
        "comm_mean_w_z",
        "comm_var_w_z",
        "comm_band_dispersion_z",
        "comm_band_contrast_z",
        "shape_z",
        "global_PC1_metric_candidate_raw",
        "global_PC1_metric_candidate_norm01_withinFIT",
        "global_PC1_metric_candidate_z_withinFIT",
        "global_PC1_metric_rank_withinFIT_ascending",
        "global_PC1_metric_rank_withinFIT_descending",
        "global_PC2_diagnostic_raw",
    ]

    remaining_cols = [c for c in df.columns if c not in preferred_cols]
    df_out = df[preferred_cols + remaining_cols].copy()
    df_out.to_csv(out_csv, index=False)

    # ------------------------------------------------------------
    # Write JSON
    # ------------------------------------------------------------
    payload = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "stage": "5B",
        "script_version": "metric_candidate_from_global_PC1_v1",
        "inputs": {
            "repo_root": repo_root,
            "stage5b_vnext_csv": in_csv,
            "stage5b_vnext_json": in_json,
            "stage5b_vnext_csv_sha256": sha256_of_file(in_csv),
            "stage5b_vnext_json_sha256": sha256_of_file(in_json),
        },
        "decision_basis": {
            "global_rank_interpretation": "approximately_2D",
            "per_fit_rank_interpretation": "approximately_1D_each",
            "pc1_role": "metric_candidate",
            "pc2_role": "diagnostics_only_family_deformation",
        },
        "features_used_global_pca": features,
        "global_pca": {
            "cov_eigenvalues_desc": [float(v) for v in eigvals.tolist()],
            "explained_variance_ratio_desc_signed": [float(v) for v in evr.tolist()],
            "pc1_loadings_feature_order": {
                f: float(v) for f, v in zip(features, pc1)
            },
            "pc2_loadings_feature_order": {
                f: float(v) for f, v in zip(features, pc2)
            },
        },
        "fit_centroids_in_metric_diagnostic_plane": fit_centroids.to_dict(orient="records"),
        "monotonicity_by_fit_metric_id_order": monotone,
        "leave_one_feature_out_stability": loo,
        "outputs": {
            "csv": out_csv,
            "json": out_json,
        },
    }

    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)

    # ------------------------------------------------------------
    # Console summary
    # ------------------------------------------------------------
    print("[Stage-5B metric-candidate v1] Wrote:")
    print(f"  CSV : {out_csv}")
    print(f"  JSON: {out_json}")
    print("[Stage-5B metric-candidate v1] Features used:", features)
    print("[Stage-5B metric-candidate v1] Global eigenvalues (desc):", eigvals.tolist())
    print("[Stage-5B metric-candidate v1] Global EVR (desc, signed):", evr.tolist())
    print("[Stage-5B metric-candidate v1] PC1 loadings:")
    for f, v in zip(features, pc1):
        print(f"   - {f}: {v:+.6f}")
    print("[Stage-5B metric-candidate v1] PC2 loadings (diagnostic only):")
    for f, v in zip(features, pc2):
        print(f"   - {f}: {v:+.6f}")

    print("[Stage-5B metric-candidate v1] Monotonicity by FIT:")
    for fit_id, info in monotone.items():
        print(
            f"   - {fit_id}: "
            f"raw_inc={info['raw_monotone_increasing']}, "
            f"raw_dec={info['raw_monotone_decreasing']}, "
            f"norm_inc={info['norm_monotone_increasing']}, "
            f"norm_dec={info['norm_monotone_decreasing']}"
        )


if __name__ == "__main__":
    main()