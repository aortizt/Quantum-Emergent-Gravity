#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Feb  5 18:13:33 2026

@author: Arturo Ortiz-Tapia
Stage-4B beta (Option A) — holonomy deviation scalar from Stage-3A comm_norm (MINIMAL)

Purpose
-------
Populate holonomy_dev_mean for metrics 003–007 WITHOUT holdevshell_from_R sidecars.
We treat comm_norm as the shellwise deviation signal already stored in Stage-3A NPZ outputs.

Definition (standing decision Option A)
--------------------------------------
holonomy_dev_mean := mean(comm_norm)

Inputs (auto-discovered under project root)
-------------------------------------------
- <ROOT>/metric_stage_3A_outputs/**/*.npz  (base NPZs; NOT the holdevshell_from_R sidecars)

Requires in each NPZ:
- key: "comm_norm"

Outputs (DO NOT rename directories)
-----------------------------------
- <ROOT>/metric_stage_4B_outputs_beta/
    stage4B_beta_holonly.json
    stage4B_beta_holonly.csv

Evidence ledger (append-only)
-----------------------------
- <ROOT>/__qeg_evidence__/EVIDENCE_LEDGER.md

Notes
-----
- Spyder-friendly: NO CLI args. Press Run.
- NO pipeline refactor.
- We intentionally ignore R / holdevshell_from_R sidecars.
"""

from __future__ import annotations

import os, sys, json, glob, re, datetime as _dt
from typing import Dict, Any, List, Tuple, Optional
import numpy as np


# -----------------------------
# Configuration (minimal)
# -----------------------------
FITS = ("NUFIT", "BARI", "VALENCIA")
METRICS = (3, 4, 5, 6, 7)

ROOT_CANDIDATES = [
    os.getcwd(),
    "/home/dakini/Downloads/010-Quantum_Emergent_Gravity",
]

STAGE3A_DIRNAME = "metric_stage_3A_outputs"
OUTDIR_BETA_DIRNAME = "metric_stage_4B_outputs_beta"

OUT_JSON_NAME = "stage4B_beta_holonly.json"
OUT_CSV_NAME  = "stage4B_beta_holonly.csv"

# Match filenames like:
# stage3A__eigshells__metric_004__NUFIT__zscore__pos.npz
# stage3A__eigshells__metric_003__BARI__zscore__neg.npz
RX_BASE = re.compile(
    r"stage3A__eigshells__metric_(?P<metric>\d{3})__(?P<fit>[A-Z]+)__zscore__(?P<dm32>[a-zA-Z0-9_]+)\.npz$"
)

# Exclude any sidecars explicitly:
EXCLUDE_SUBSTRINGS = ("holdevshell_from_R",)


def ts() -> str:
    return _dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def find_project_root() -> Optional[str]:
    for root in ROOT_CANDIDATES:
        if not os.path.isdir(root):
            continue
        if os.path.isdir(os.path.join(root, STAGE3A_DIRNAME)):
            return root
    return None


def metric_id(n: int) -> str:
    return f"metric_{n:03d}"


def safe_nanmean(x: np.ndarray) -> float:
    x = np.asarray(x, dtype=float).ravel()
    if x.size == 0:
        return float("nan")
    if np.isnan(x).any():
        return float(np.nanmean(x))
    return float(np.mean(x))


def safe_stats(x: np.ndarray) -> Dict[str, float]:
    x = np.asarray(x, dtype=float).ravel()
    if x.size == 0:
        return dict(mean=float("nan"), median=float("nan"), p90=float("nan"), n=0.0)
    if np.isnan(x).any():
        x2 = x[~np.isnan(x)]
    else:
        x2 = x
    if x2.size == 0:
        return dict(mean=float("nan"), median=float("nan"), p90=float("nan"), n=0.0)
    return dict(
        mean=float(np.mean(x2)),
        median=float(np.median(x2)),
        p90=float(np.quantile(x2, 0.90)),
        n=float(x2.size),
    )


def discover_base_npzs(stage3a_dir: str) -> List[str]:
    pat = os.path.join(stage3a_dir, "**", "*.npz")
    hits = sorted(glob.glob(pat, recursive=True))
    # filter out sidecars / excluded
    out = []
    for fp in hits:
        bn = os.path.basename(fp)
        if any(s in bn for s in EXCLUDE_SUBSTRINGS):
            continue
        out.append(fp)
    return out


def load_comm_norm(fp: str) -> np.ndarray:
    z = np.load(fp, allow_pickle=True)
    try:
        if "comm_norm" not in z.files:
            raise KeyError("comm_norm missing")
        return np.asarray(z["comm_norm"], dtype=float).ravel()
    finally:
        try:
            z.close()
        except Exception:
            pass


def try_append_ledger(root: str, out_json: str, out_csv: str, notes: List[str]) -> None:
    """
    Minimal: try to append to __qeg_evidence__/EVIDENCE_LEDGER.md.
    If ledger infra missing, do NOT fail Stage-4B outputs.
    """
    try:
        from __qeg_evidence__.evidence import append_entry  # preferred
    except Exception:
        # fallback: attempt local evidence.py in ROOT
        try:
            if root not in sys.path:
                sys.path.insert(0, root)
            from evidence import append_entry  # type: ignore
        except Exception:
            print("[WARN] Evidence ledger append skipped (append_entry not importable).")
            return

    append_entry(
        root=os.path.abspath(root),
        script_name="stage4B_beta_holonly_from_commnorm_v1.py",
        script_version="v1",
        assumptions_validated=[
            "Standing decision Option A: use comm_norm as shellwise deviation signal",
            "Stage-3A NPZs provide comm_norm without persisting R (no holdevshell_from_R needed)",
            "holonomy_dev_mean reducer = mean(comm_norm)",
        ],
        assumptions_invalidated=[
            "Stage-4B beta requires holdevshell_from_R sidecars (deprecated)",
        ],
        outputs_written=[out_json, out_csv],
        watch_items=[
            "Option B trigger only if Stage-6+ needs transport-resolved curvature (R_k-level); then patch Stage-3A to persist R and rerun.",
        ],
        notes=notes,
    )


def main() -> int:
    print("=" * 78)
    print("Stage-4B beta (Option A) — holonomy_dev_mean from comm_norm (v1)")
    print("Timestamp :", ts())
    print("Python    :", sys.version.split()[0])
    print("Executable:", sys.executable)
    print("CWD       :", os.getcwd())
    print("=" * 78)

    root = find_project_root()
    if root is None:
        print("[FAIL] Could not identify project root. Edit ROOT_CANDIDATES.")
        return 2
    print("[OK] Project root:", root)

    stage3a_dir = os.path.join(root, STAGE3A_DIRNAME)
    if not os.path.isdir(stage3a_dir):
        print("[FAIL] Missing Stage-3A outputs dir:", stage3a_dir)
        return 2

    base_npzs = discover_base_npzs(stage3a_dir)
    if not base_npzs:
        print("[FAIL] Found 0 base NPZs under:", stage3a_dir)
        return 2
    print(f"[OK] Found {len(base_npzs)} base NPZ(s) (excluding sidecars).")

    # Collect candidates by (metric, fit)
    # For each (metric, fit), we may have multiple dm32 variants; we average per-file means.
    bucket: Dict[Tuple[int, str], List[Dict[str, Any]]] = {}

    ignored = 0
    used = 0
    for fp in base_npzs:
        bn = os.path.basename(fp)
        m = RX_BASE.search(bn)
        if not m:
            ignored += 1
            continue

        metric_n = int(m.group("metric"))
        fit = m.group("fit")
        dm32 = m.group("dm32")

        if metric_n not in METRICS:
            continue
        if fit not in FITS:
            continue

        # Must have comm_norm
        try:
            cn = load_comm_norm(fp)
        except Exception:
            continue

        st = safe_stats(cn)
        bucket.setdefault((metric_n, fit), []).append({
            "metric_n": metric_n,
            "fit": fit,
            "dm32": dm32,
            "comm_norm_mean": float(st["mean"]),
            "comm_norm_median": float(st["median"]),
            "comm_norm_p90": float(st["p90"]),
            "comm_norm_n": int(st["n"]),
            "source_npz": fp,
            "mtime": os.path.getmtime(fp),
        })
        used += 1

    print(f"[OK] Parsed comm_norm from {used} NPZ(s). Ignored filename-mismatched: {ignored}")

    # Reduce to holonomy_dev_mean per (metric, fit)
    rows: List[Dict[str, Any]] = []
    missing_pairs: List[str] = []
    for metric_n in METRICS:
        for fit in FITS:
            key = (metric_n, fit)
            items = bucket.get(key, [])
            if not items:
                missing_pairs.append(f"{metric_id(metric_n)} / {fit}")
                continue

            # reducer: mean over shells, then mean over dm32 variants (simple average)
            vals = np.array([it["comm_norm_mean"] for it in items], dtype=float)
            hol_mu = safe_nanmean(vals)

            dm32s = sorted({it["dm32"] for it in items})
            # choose newest source for traceability
            newest = max(items, key=lambda it: float(it["mtime"]))

            rows.append({
                "FIT_id": fit,
                "metric_id": metric_id(metric_n),
                "holonomy_dev_mean": float(hol_mu),
                "reducer": "mean(comm_norm) then mean_over_dm32_variants",
                "dm32_variants": dm32s,
                "n_variants": int(len(items)),
                "source_stage3a_npz_newest": newest["source_npz"],
            })

    if missing_pairs:
        print("[WARN] Missing comm_norm base NPZs for some metric/FIT pairs:")
        for s in missing_pairs:
            print("       -", s)

    outdir = os.path.join(root, OUTDIR_BETA_DIRNAME)
    os.makedirs(outdir, exist_ok=True)
    out_json = os.path.join(outdir, OUT_JSON_NAME)
    out_csv  = os.path.join(outdir, OUT_CSV_NAME)

    # Write JSON (robust schema: rows list + lookup table)
    lookup: Dict[str, Dict[str, float]] = {}
    for r in rows:
        lookup.setdefault(r["FIT_id"], {})[r["metric_id"]] = float(r["holonomy_dev_mean"])

    payload = {
        "stage": "4B",
        "label": "beta",
        "kind": "holonomy_dev_mean_from_comm_norm",
        "timestamp": ts(),
        "python": sys.version.split()[0],
        "executable": sys.executable,
        "root": root,
        "stage3a_dir": stage3a_dir,
        "metrics": [metric_id(m) for m in METRICS],
        "fits": list(FITS),
        "reducer": "holonomy_dev_mean := mean(comm_norm) (per file), then mean over dm32 variants",
        "rows": rows,
        "holonomy_dev_mean_table": lookup,
        "deprecated_inputs": ["holdevshell_from_R sidecars"],
    }
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)

    # Write CSV
    # Keep it simple and Stage-4C merge-friendly.
    header = ["FIT_id", "metric_id", "holonomy_dev_mean", "n_variants", "dm32_variants", "source_stage3a_npz_newest", "reducer"]
    lines = [",".join(header)]
    for r in sorted(rows, key=lambda x: (x["FIT_id"], x["metric_id"])):
        dm32_join = "|".join(r.get("dm32_variants", []))
        # careful with commas in path: wrap in quotes
        lines.append(",".join([
            r["FIT_id"],
            r["metric_id"],
            f"{float(r['holonomy_dev_mean']):.12g}",
            str(int(r.get("n_variants", 0))),
            f"\"{dm32_join}\"",
            f"\"{r.get('source_stage3a_npz_newest','')}\"",
            f"\"{r.get('reducer','')}\"",
        ]))
    with open(out_csv, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")

    print("[OK] Wrote:", out_json)
    print("[OK] Wrote:", out_csv)
    print(f"[OK] Rows written: {len(rows)} (expected up to {len(METRICS)*len(FITS)} if complete)")

    # Evidence ledger append (non-fatal if missing)
    notes = [
        f"Excluded sidecars containing: {EXCLUDE_SUBSTRINGS}",
        f"Parsed base NPZs: {used}; wrote beta rows: {len(rows)}",
        f"Missing pairs count: {len(missing_pairs)}",
    ]
    try_append_ledger(root=root, out_json=out_json, out_csv=out_csv, notes=notes)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
