#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Feb  5 18:27:51 2026

Stage-4C REAL Option-A rebuild → canonical CSV (v5)

Author: Arturo Ortiz-Tapia
Date: 2026-02-05

Why v5 exists (IMPORTANT / Standing Decision)
--------------------------------------------
Stage-4B beta used to be produced from Stage-3A *sidecar NPZ* files:
    .../stage3A__eigshells__metric_003__{FIT}__zscore__{dm32}__holdevshell_from_R.npz
and Stage-4C v4 inferred metric_id by parsing metric_### from the *sidecar_npz* path.

That path is now deprecated under Option A because Stage-3A base NPZ outputs
do NOT persist transport matrices R, so holdevshell_from_R sidecars are not
generally constructible (and were blocking Stage-3A → Stage-4B beta).

Option A (comm_norm path)
-------------------------
We treat comm_norm as the shellwise deviation signal already stored in Stage-3A base NPZs,
and Stage-4B beta now writes rows that include explicit keys:
    FIT_id, metric_id, holonomy_dev_mean
so Stage-4C should NOT rely on parsing sidecar_npz for metric_id.

Summary: v5 adds an Option-A-aware beta parser that uses explicit metric_id
from Stage-4B beta JSON, while keeping backward-compat support for legacy sidecar schemas.

Sidecars vs metric_id (brief)
-----------------------------
- "Sidecar NPZ" = auxiliary .npz artifact derived from other outputs (here: requires R which is absent).
- "metric_id"   = canonical identifier (e.g., metric_004) that should be carried explicitly in JSON rows.

No pipeline refactor. No directory renames. Minimal stability patch + documentation.

"""

import os, re, json, glob, argparse
import numpy as np
import pandas as pd
from pathlib import Path


OUTNAME = "stage4C_microfeatures_canonical_v1.csv"
PAT_STAGE4C = ["**/stage4C_tables.json"]

METRIC_PAT = re.compile(r"__metric_(\d{3})__", re.IGNORECASE)


def _first_existing_glob(patterns, root):
    for pat in patterns:
        hits = glob.glob(os.path.join(root, pat), recursive=True)
        if hits:
            return sorted(hits)[0]
    return None


def _load_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _is_num(x):
    try:
        return x is not None and np.isfinite(float(x))
    except Exception:
        return False


def _to_float(x):
    try:
        return float(x)
    except Exception:
        return float("nan")


def _metric_id_from_path(p):
    if not p:
        return None
    m = METRIC_PAT.search(str(p))
    if not m:
        return None
    return f"metric_{m.group(1)}"


def _band_asymmetry_from_endpoints(band):
    """
    band is [lo, hi]. With only endpoints, the natural center is (lo+hi)/2,
    so asymmetry is 0. Kept for future richer schemas.
    """
    if not isinstance(band, (list, tuple)) or len(band) != 2:
        return float("nan")
    lo, hi = band[0], band[1]
    if not (_is_num(lo) and _is_num(hi)) or float(hi) <= float(lo):
        return float("nan")
    return 0.0


def _read_alpha_rows(alpha_json_path):
    js = _load_json(alpha_json_path)
    rows = js.get("rows", [])
    out = []

    for r in rows:
        if not isinstance(r, dict):
            continue
        fit = r.get("FIT", None)
        dm32 = r.get("dm32", None)
        npz = r.get("npz_file", None)

        metric_id = _metric_id_from_path(npz)
        if fit is None or metric_id is None:
            continue

        out.append({
            "FIT_id": str(fit),
            "metric_id": metric_id,
            "dm32": str(dm32) if dm32 is not None else None,
            "band_center_mean": _to_float(r.get("comm_band_mean", np.nan)),
            "band_width_mean": _to_float(r.get("band_width", np.nan)),
            "band_asymmetry": _band_asymmetry_from_endpoints(r.get("band", None)),
        })

    return pd.DataFrame(out)


def _read_beta_rows_v5(beta_json_path):
    """
    v5 beta parser:

    Option A schema (preferred):
      - beta["kind"] == "holonomy_dev_mean_from_comm_norm"
      - rows contain explicit FIT_id, metric_id, holonomy_dev_mean

    Legacy schema (backward compat):
      - rows contain FIT, dm32, sidecar_npz, hol_band_mean
      - metric_id inferred by parsing sidecar_npz path
    """
    js = _load_json(beta_json_path)
    rows = js.get("rows", [])
    out = []

    # --- Option A schema ---
    if isinstance(js, dict) and js.get("kind") == "holonomy_dev_mean_from_comm_norm":
        for r in rows:
            if not isinstance(r, dict):
                continue
            fit_id = r.get("FIT_id", None)
            metric_id = r.get("metric_id", None)
            hol_mu = r.get("holonomy_dev_mean", None)
            if fit_id is None or metric_id is None:
                continue
            out.append({
                "FIT_id": str(fit_id),
                "metric_id": str(metric_id),
                "dm32": None,  # Option A beta already reduced over dm32 variants
                "holonomy_dev_mean": _to_float(hol_mu),
            })
        return pd.DataFrame(out)

    # --- Legacy schema fallback (v4 behavior) ---
    for r in rows:
        if not isinstance(r, dict):
            continue
        fit = r.get("FIT", None)
        dm32 = r.get("dm32", None)
        sidecar = r.get("sidecar_npz", None)

        metric_id = _metric_id_from_path(sidecar)
        if fit is None or metric_id is None:
            continue

        out.append({
            "FIT_id": str(fit),
            "metric_id": metric_id,
            "dm32": str(dm32) if dm32 is not None else None,
            # In legacy beta, hol_band_mean is the holonomy-derived scalar (band mean)
            "holonomy_dev_mean": _to_float(r.get("hol_band_mean", np.nan)),
        })

    return pd.DataFrame(out)


def _append_ledger(ROOT: Path, outpath: str):
    """
    Append an evidence ledger entry. Must be non-fatal if evidence infra missing.
    """
    try:
        from __qeg_evidence__.evidence import append_entry
    except ModuleNotFoundError:
        # fallback: allow root-level evidence.py if present
        import sys
        if str(ROOT) not in sys.path:
            sys.path.insert(0, str(ROOT))
        try:
            from evidence import append_entry  # type: ignore
        except Exception:
            print("[WARN] Evidence ledger append skipped (append_entry not importable).")
            return

    append_entry(
        root=ROOT,
        script_name="Stage-4C_REAL_Option-A_v5.py",
        script_version="v5",
        assumptions_validated=[
            "Option A active: Stage-4B beta provides explicit FIT_id + metric_id + holonomy_dev_mean (comm_norm reducer).",
            "Stage-4C v5 does NOT rely on sidecar_npz parsing for metric_id under Option A.",
        ],
        assumptions_invalidated=[
            "Stage-4C must infer metric_id from beta sidecar_npz (deprecated legacy assumption).",
        ],
        outputs_written=[str(outpath)],
        watch_items=[
            "Option B trigger only if Stage-6+ needs transport-resolved curvature (R_k-level); then persist R in Stage-3A and rerun derivations.",
        ],
        notes=[
            "v5 adds Option-A-aware beta parser keyed by beta['kind'] == 'holonomy_dev_mean_from_comm_norm'.",
        ],
    )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=os.getcwd(), help="Project root (default: CWD).")
    ap.add_argument("--stage4c-tables", default=None,
                    help="Optional explicit path to stage4C_tables.json (otherwise auto-glob under root).")
    ap.add_argument("--alpha-json", default=None,
                    help="Override alpha_json path (e.g. metric_stage_4B_outputs_alpha/stage4B_alpha_commonly_v2.json).")
    ap.add_argument("--beta-json", default=None,
                    help="Override beta_json path (e.g. metric_stage_4B_outputs_beta/stage4B_beta_holonly.json).")
    args = ap.parse_args()

    ROOT = Path(args.root).resolve()

    print("=== Stage-4C REAL Option-A rebuild → canonical CSV (v5) ===")
    print(f"ROOT: {ROOT}")

    # Locate stage4C_tables.json (used to infer output directory, and as default alpha/beta pointers)
    if args.stage4c_tables:
        stage4c_path = Path(args.stage4c_tables).resolve()
        if not stage4c_path.exists():
            raise FileNotFoundError(f"--stage4c-tables not found: {stage4c_path}")
    else:
        found = _first_existing_glob(PAT_STAGE4C, str(ROOT))
        if not found:
            raise FileNotFoundError("Could not find stage4C_tables.json under ROOT (use --stage4c-tables).")
        stage4c_path = Path(found).resolve()

    stage4c = _load_json(str(stage4c_path))

    # Defaults from locator file
    alpha_path = stage4c.get("alpha_json", None)
    beta_path  = stage4c.get("beta_json", None)

    # Overrides (preferred for reproducible backfill runs)
    if args.alpha_json:
        alpha_path = str((ROOT / args.alpha_json).resolve()) if not os.path.isabs(args.alpha_json) else str(Path(args.alpha_json).resolve())
    if args.beta_json:
        beta_path = str((ROOT / args.beta_json).resolve()) if not os.path.isabs(args.beta_json) else str(Path(args.beta_json).resolve())

    if not alpha_path or not os.path.exists(alpha_path):
        raise FileNotFoundError(f"alpha_json missing or not found: {alpha_path}")
    if not beta_path or not os.path.exists(beta_path):
        raise FileNotFoundError(f"beta_json missing or not found: {beta_path}")

    print(f"Stage-4C locator: {stage4c_path}")
    print(f"alpha_json: {alpha_path}")
    print(f"beta_json : {beta_path}")

    df_a = _read_alpha_rows(alpha_path)
    df_b = _read_beta_rows_v5(beta_path)

    if len(df_a) == 0:
        raise RuntimeError("Parsed alpha rows but got 0 records (could not infer metric_id from npz_file?).")
    if len(df_b) == 0:
        raise RuntimeError("Parsed beta rows but got 0 records (beta schema not recognized / empty rows).")

    # Aggregate across dm32 modes: mean over abs/drop/signed (or whatever exists)
    agg_a = (df_a
             .groupby(["FIT_id", "metric_id"], as_index=False)
             .agg({
                 "band_center_mean": "mean",
                 "band_width_mean": "mean",
                 "band_asymmetry": "mean",
             }))

    agg_b = (df_b
             .groupby(["FIT_id", "metric_id"], as_index=False)
             .agg({
                 "holonomy_dev_mean": "mean",
             }))

    # Merge alpha+beta onto canonical table
    df = agg_a.merge(agg_b, on=["FIT_id", "metric_id"], how="outer")

    # Add remaining canonical columns (placeholders for later joins)
    df["ot_cost_mean"] = np.nan
    df["procrustes_resid"] = np.nan
    df["obstruction_score"] = np.nan

    # Final column order
    df = df[[
        "FIT_id", "metric_id",
        "band_center_mean", "band_width_mean", "band_asymmetry", "holonomy_dev_mean",
        "ot_cost_mean", "procrustes_resid", "obstruction_score"
    ]].sort_values(["FIT_id", "metric_id"]).reset_index(drop=True)

    outdir = stage4c_path.parent
    outpath = outdir / OUTNAME
    df.to_csv(str(outpath), index=False)

    print(f"Wrote: {outpath}")
    print(f"Rows: {len(df)}")
    print("Non-null counts:", df.notna().sum().to_dict())

    # Evidence ledger append (non-fatal)
    _append_ledger(ROOT=ROOT, outpath=str(outpath))


if __name__ == "__main__":
    main()
