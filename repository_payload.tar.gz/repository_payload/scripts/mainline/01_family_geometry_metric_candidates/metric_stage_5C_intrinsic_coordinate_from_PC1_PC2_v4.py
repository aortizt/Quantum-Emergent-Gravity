# -*- coding: utf-8 -*-
"""
metric_stage_5C_intrinsic_coordinate_from_PC1_PC2_v4.py

Spyder-runnable script

Stage-5C v4 goal:
    Focus only on the remaining BARI symmetry problem identified after v3.
    The canonical angular coordinate already succeeded for NUFIT and VALENCIA,
    so this script does not re-open the full Stage-5C comparison. Instead, it:

      1) reconstructs the Stage-5C angular coordinates from Stage-5B (PC1,PC2),
      2) keeps the v3 canonical angle as the baseline directional coordinate,
      3) runs BARI-only targeted angular-unfolding strategies,
      4) builds a hybrid preferred coordinate:
            canonical for non-BARI FITs,
            targeted BARI unfolding for BARI,
      5) compares baseline canonical vs BARI-targeted hybrid.

Interpretive intent:
    - test whether the remaining BARI failure is a residual quotient / endpoint
      identification issue rather than evidence against the angular picture;
    - if the targeted BARI unfolding becomes monotone without damaging the other
      FITs, Stage-5C can move from:
          "preferred directional intrinsic coordinate (provisional)"
      toward:
          "preferred Stage-5C directional intrinsic coordinate"
      with explicit note that the BARI branch required endpoint unfolding.
"""

from __future__ import annotations

import hashlib
import itertools
import json
from pathlib import Path

import numpy as np
import pandas as pd


# ---------------------------------------------------------------------
# User-facing configuration
# ---------------------------------------------------------------------

REPO_ROOT = Path("/home/dakini/Downloads/010-Quantum_Emergent_Gravity")
STAGE5B_DIR = REPO_ROOT / "metric_stage_5B_outputs"
STAGE5C_DIR = REPO_ROOT / "metric_stage_5C_outputs"

INPUT_CSV = STAGE5B_DIR / "stage5B_metric_candidate_from_global_PC1_v1.csv"
INPUT_JSON = STAGE5B_DIR / "stage5B_metric_candidate_from_global_PC1_v1.json"

OUTPUT_CSV = STAGE5C_DIR / "stage5C_intrinsic_coordinate_from_PC1_PC2_v4.csv"
OUTPUT_JSON = STAGE5C_DIR / "stage5C_intrinsic_coordinate_from_PC1_PC2_v4.json"

SCRIPT_VERSION = "intrinsic_coordinate_from_PC1_PC2_v4"


# ---------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------

def sha256_of_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def load_json(path: Path) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def make_json_safe(obj):
    if isinstance(obj, dict):
        return {str(k): make_json_safe(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [make_json_safe(v) for v in obj]
    if isinstance(obj, np.ndarray):
        return [make_json_safe(v) for v in obj.tolist()]
    if isinstance(obj, (np.floating,)):
        return float(obj)
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    if isinstance(obj, pd.Timestamp):
        return obj.isoformat()
    if isinstance(obj, Path):
        return str(obj)
    if pd.isna(obj) and not isinstance(obj, str):
        return None
    return obj


def dump_json_safe(payload, path: Path) -> None:
    safe_payload = make_json_safe(payload)
    tmp_path = path.with_suffix(path.suffix + ".tmp")
    with open(tmp_path, "w", encoding="utf-8") as f:
        json.dump(safe_payload, f, indent=2, allow_nan=False)
    tmp_path.replace(path)


def principal_angle(angle):
    return float(np.arctan2(np.sin(angle), np.cos(angle)))


def circular_mean(theta):
    theta = np.asarray(theta, dtype=float)
    return float(np.arctan2(np.mean(np.sin(theta)), np.mean(np.cos(theta))))


def minmax01(values):
    vals = np.asarray(values, dtype=float)
    vmin = np.min(vals)
    vmax = np.max(vals)
    if abs(vmax - vmin) < 1e-15:
        return np.zeros_like(vals)
    return (vals - vmin) / (vmax - vmin)


def zscore(values):
    vals = np.asarray(values, dtype=float)
    mu = np.mean(vals)
    sd = np.std(vals, ddof=0)
    if sd < 1e-15:
        return np.zeros_like(vals)
    return (vals - mu) / sd


def rank_average_ties(values):
    return pd.Series(values).rank(method="average").to_numpy()


def try_parse_metric_order(metric_ids):
    parsed = []
    ok = True
    for x in metric_ids:
        sx = str(x)
        tail = sx.split("_")[-1]
        try:
            parsed.append(int(tail))
        except Exception:
            ok = False
            break
    if ok:
        return np.array(parsed, dtype=int)
    return np.array([str(x) for x in metric_ids], dtype=object)


def build_order_index(metric_ids):
    parsed = try_parse_metric_order(metric_ids)
    return pd.Series(parsed).rank(method="dense").to_numpy()


def spearman_rho(x, y):
    xr = rank_average_ties(x)
    yr = rank_average_ties(y)
    xs = xr - xr.mean()
    ys = yr - yr.mean()
    denom = np.sqrt(np.sum(xs**2) * np.sum(ys**2))
    if denom < 1e-15:
        return 0.0
    return float(np.sum(xs * ys) / denom)


def is_monotone_increasing(values, tol=1e-12) -> bool:
    vals = np.asarray(values, dtype=float)
    return bool(np.all(np.diff(vals) >= -tol))


def is_monotone_decreasing(values, tol=1e-12) -> bool:
    vals = np.asarray(values, dtype=float)
    return bool(np.all(np.diff(vals) <= tol))


def summarize_candidate_for_fit(values, metric_ids):
    metric_order = try_parse_metric_order(metric_ids)
    vals = np.asarray(values, dtype=float)
    diffs = np.diff(vals)
    rho = spearman_rho(vals, metric_order)
    unique_vals = np.unique(np.round(vals, 12))
    return {
        "metric_id_order": [str(x) for x in metric_ids],
        "values": [float(x) for x in vals],
        "adjacent_differences": [float(x) for x in diffs],
        "monotone_increasing": bool(is_monotone_increasing(vals)),
        "monotone_decreasing": bool(is_monotone_decreasing(vals)),
        "spearman_rho_vs_metric_id": float(rho),
        "abs_spearman_rho_vs_metric_id": float(abs(rho)),
        "endpoint_separation_last_minus_first": float(vals[-1] - vals[0]),
        "dynamic_range": float(np.max(vals) - np.min(vals)),
        "ties_count_after_round12": int(len(vals) - len(unique_vals)),
    }


def aggregate_candidate_summary(per_fit_summaries):
    fit_names = sorted(per_fit_summaries.keys())
    out = {
        "fit_names": fit_names,
        "monotone_any_direction_count": 0,
        "monotone_increasing_count": 0,
        "monotone_decreasing_count": 0,
        "mean_abs_spearman_rho": 0.0,
        "mean_signed_spearman_rho": 0.0,
        "mean_dynamic_range": 0.0,
        "mean_abs_endpoint_separation": 0.0,
        "total_ties_count_after_round12": 0,
    }
    for fit in fit_names:
        s = per_fit_summaries[fit]
        if s["monotone_increasing"] or s["monotone_decreasing"]:
            out["monotone_any_direction_count"] += 1
        if s["monotone_increasing"]:
            out["monotone_increasing_count"] += 1
        if s["monotone_decreasing"]:
            out["monotone_decreasing_count"] += 1
        out["mean_abs_spearman_rho"] += s["abs_spearman_rho_vs_metric_id"]
        out["mean_signed_spearman_rho"] += s["spearman_rho_vs_metric_id"]
        out["mean_dynamic_range"] += s["dynamic_range"]
        out["mean_abs_endpoint_separation"] += abs(s["endpoint_separation_last_minus_first"])
        out["total_ties_count_after_round12"] += s["ties_count_after_round12"]
    n = max(len(fit_names), 1)
    for key in [
        "mean_abs_spearman_rho",
        "mean_signed_spearman_rho",
        "mean_dynamic_range",
        "mean_abs_endpoint_separation",
    ]:
        out[key] = float(out[key] / n)
    return out


def score_aggregate_summary(agg):
    return (
        1000.0 * agg["monotone_any_direction_count"]
        + 100.0 * agg["mean_abs_spearman_rho"]
        + 1.0 * agg["mean_abs_endpoint_separation"]
        + 0.1 * agg["mean_dynamic_range"]
        - 0.5 * agg["total_ties_count_after_round12"]
    )


def detect_orbit_plateau_pattern(values, atol=1e-9):
    vals = np.asarray(values, dtype=float)
    n = len(vals)
    out = {
        "length": int(n),
        "rounded_unique_count": int(len(np.unique(np.round(vals, 12)))),
        "endpoint_pair_close": False,
        "middle_plateau_close": False,
        "first_last_abs_diff": None,
        "middle_span": None,
        "pattern_2plus3_detected": False,
        "quotient_orbit_interpretation": "not_tested",
    }
    if n < 5:
        out["quotient_orbit_interpretation"] = "insufficient_length"
        return out
    first_last_abs_diff = float(abs(vals[0] - vals[-1]))
    middle = vals[1:-1]
    middle_span = float(np.max(middle) - np.min(middle)) if len(middle) else None
    endpoint_pair_close = first_last_abs_diff <= atol
    middle_plateau_close = (middle_span is not None and middle_span <= atol)
    out.update({
        "endpoint_pair_close": bool(endpoint_pair_close),
        "middle_plateau_close": bool(middle_plateau_close),
        "first_last_abs_diff": first_last_abs_diff,
        "middle_span": middle_span,
        "pattern_2plus3_detected": bool(endpoint_pair_close and middle_plateau_close),
    })
    if endpoint_pair_close and middle_plateau_close:
        out["quotient_orbit_interpretation"] = "strong_2_endpoint_plus_middle_plateau_pattern"
    elif endpoint_pair_close or middle_plateau_close:
        out["quotient_orbit_interpretation"] = "partial_symmetry_pattern"
    else:
        out["quotient_orbit_interpretation"] = "no_strong_2plus3_pattern"
    return out


def centered_theta(pc1, pc2):
    pts = np.column_stack([pc1, pc2]).astype(float)
    center = pts.mean(axis=0)
    theta = np.arctan2(pts[:, 1] - center[1], pts[:, 0] - center[0])
    radius = np.sqrt(np.sum((pts - center) ** 2, axis=1))
    return center, theta, radius


def unwrap_with_anchor(theta, anchor_angle):
    shifted = np.array([principal_angle(t - anchor_angle) for t in theta], dtype=float)
    return np.unwrap(shifted)


def choose_best_sign(values, metric_ids):
    order = build_order_index(metric_ids)
    vals = np.asarray(values, dtype=float)
    trials = []
    for sign in (+1.0, -1.0):
        v = sign * vals
        s = summarize_candidate_for_fit(v, metric_ids)
        trials.append({"sign": float(sign), "summary": s, "values": [float(x) for x in v]})
    trials = sorted(
        trials,
        key=lambda d: (
            1 if d["summary"]["monotone_increasing"] else 0,
            d["summary"]["abs_spearman_rho_vs_metric_id"],
            abs(d["summary"]["endpoint_separation_last_minus_first"]),
        ),
        reverse=True,
    )
    best = trials[0]
    return float(best["sign"]), np.asarray(best["values"], dtype=float), trials


def bari_targeted_methods(theta, metric_ids, global_anchor):
    """
    Build BARI-only candidate unfoldings.

    Method family rationale:
      - baseline_global_anchor:
            the v3 canonical construction.
      - anchor_metric003:
            treat the first metric in order as the phase origin; for the BARI
            pattern this often converts [a,-b,-b,-b,a] into [0,pi,pi,pi,2pi].
      - anchor_metric007:
            symmetric endpoint anchor for completeness.
      - exhaustive_integer_lift_from_metric003:
            start from metric_003 anchor and allow integer 2π lifts per point,
            preserving local principal-angle representatives but explicitly
            searching for the best monotone unfolding.
    """
    theta = np.asarray(theta, dtype=float)
    methods = {}

    # Baseline canonical/global-anchor method.
    base_global = unwrap_with_anchor(theta, global_anchor)
    sign, vals, sign_trials = choose_best_sign(base_global, metric_ids)
    methods["baseline_global_anchor"] = {
        "anchor_angle": float(global_anchor),
        "sequence_before_sign_choice": [float(x) for x in base_global],
        "chosen_sign": float(sign),
        "sign_trials": sign_trials,
        "summary": summarize_candidate_for_fit(vals, metric_ids),
        "integer_lift_vector": [0, 0, 0, 0, 0],
        "method_note": "v3 canonical baseline",
    }

    # Anchor at metric_003.
    base_m003 = unwrap_with_anchor(theta, theta[0])
    sign, vals, sign_trials = choose_best_sign(base_m003, metric_ids)
    methods["anchor_metric003"] = {
        "anchor_angle": float(theta[0]),
        "sequence_before_sign_choice": [float(x) for x in base_m003],
        "chosen_sign": float(sign),
        "sign_trials": sign_trials,
        "summary": summarize_candidate_for_fit(vals, metric_ids),
        "integer_lift_vector": [0, 0, 0, 0, 0],
        "method_note": "endpoint-as-origin targeted unfolding",
    }

    # Anchor at metric_007.
    base_m007 = unwrap_with_anchor(theta, theta[-1])
    sign, vals, sign_trials = choose_best_sign(base_m007, metric_ids)
    methods["anchor_metric007"] = {
        "anchor_angle": float(theta[-1]),
        "sequence_before_sign_choice": [float(x) for x in base_m007],
        "chosen_sign": float(sign),
        "sign_trials": sign_trials,
        "summary": summarize_candidate_for_fit(vals, metric_ids),
        "integer_lift_vector": [0, 0, 0, 0, 0],
        "method_note": "other-endpoint-as-origin targeted unfolding",
    }

    # Exhaustive integer-lift search based on metric_003 anchor.
    base_principal = np.array([principal_angle(t - theta[0]) for t in theta], dtype=float)
    best_record = None
    lift_trials = []
    # Keep first point fixed at zero-lift; allow the others a modest range.
    for ks in itertools.product(range(0, 4), repeat=len(theta) - 1):
        kvec = np.array((0,) + ks, dtype=int)
        seq = base_principal + 2.0 * np.pi * kvec
        # We allow sign orientation after the lift, because sign choice is part
        # of the Stage-5C directional comparison convention.
        sign, vals, sign_trials = choose_best_sign(seq, metric_ids)
        summary = summarize_candidate_for_fit(vals, metric_ids)
        monotone_bonus = 1000 if (summary["monotone_increasing"] or summary["monotone_decreasing"]) else 0
        score = (
            monotone_bonus
            + 100.0 * summary["abs_spearman_rho_vs_metric_id"]
            + abs(summary["endpoint_separation_last_minus_first"])
            + 0.1 * summary["dynamic_range"]
            - 0.5 * summary["ties_count_after_round12"]
            - 0.05 * float(np.sum(np.abs(kvec)))
        )
        rec = {
            "integer_lift_vector": [int(x) for x in kvec],
            "sequence_before_sign_choice": [float(x) for x in seq],
            "chosen_sign": float(sign),
            "sign_trials": sign_trials,
            "summary": summary,
            "internal_selection_score": float(score),
        }
        lift_trials.append(rec)
        if (best_record is None) or (score > best_record["internal_selection_score"]):
            best_record = rec

    lift_trials = sorted(lift_trials, key=lambda d: d["internal_selection_score"], reverse=True)
    methods["exhaustive_integer_lift_from_metric003"] = {
        "anchor_angle": float(theta[0]),
        "base_principal_sequence": [float(x) for x in base_principal],
        "best_trial": best_record,
        "top_trials": lift_trials[:10],
        "summary": best_record["summary"],
        "chosen_sign": best_record["chosen_sign"],
        "integer_lift_vector": best_record["integer_lift_vector"],
        "method_note": "explicit BARI-only search over 2π endpoint / plateau lifts",
    }

    return methods


# ---------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------

def main():
    ensure_dir(STAGE5C_DIR)
    if not INPUT_CSV.exists():
        raise FileNotFoundError(f"Missing input CSV: {INPUT_CSV}")
    if not INPUT_JSON.exists():
        raise FileNotFoundError(f"Missing input JSON: {INPUT_JSON}")

    df = pd.read_csv(INPUT_CSV)
    meta = load_json(INPUT_JSON)

    required_cols = [
        "FIT_id",
        "metric_id",
        "global_PC1_metric_candidate_raw",
        "global_PC2_diagnostic_raw",
    ]
    missing = [c for c in required_cols if c not in df.columns]
    if missing:
        raise KeyError(f"Missing required columns: {missing}")

    work = df.copy()
    work["PC1"] = work["global_PC1_metric_candidate_raw"].astype(float)
    work["PC2"] = work["global_PC2_diagnostic_raw"].astype(float)
    work["_metric_order_key"] = try_parse_metric_order(work["metric_id"].tolist())

    out_cols = [
        "stage5C_v4_angle_canonical_baseline_raw",
        "stage5C_v4_angle_canonical_baseline_norm01_withinFIT",
        "stage5C_v4_angle_canonical_baseline_z_withinFIT",
        "stage5C_v4_angle_canonical_baseline_rank_withinFIT",
        "stage5C_v4_angle_bari_targeted_raw",
        "stage5C_v4_angle_bari_targeted_norm01_withinFIT",
        "stage5C_v4_angle_bari_targeted_z_withinFIT",
        "stage5C_v4_angle_bari_targeted_rank_withinFIT",
    ]
    for c in out_cols:
        work[c] = np.nan

    global_center = np.array([work["PC1"].mean(), work["PC2"].mean()], dtype=float)
    global_theta = np.arctan2(work["PC2"].to_numpy() - global_center[1], work["PC1"].to_numpy() - global_center[0])
    global_anchor = circular_mean(global_theta)

    fit_names = sorted(work["FIT_id"].astype(str).unique().tolist())
    per_fit_baseline = {}
    per_fit_targeted = {}
    fit_details = {}

    for fit in fit_names:
        sub = work.loc[work["FIT_id"].astype(str) == fit].copy()
        sub = sub.sort_values(by="_metric_order_key").reset_index()
        metric_ids = sub["metric_id"].tolist()
        pc1 = sub["PC1"].to_numpy(dtype=float)
        pc2 = sub["PC2"].to_numpy(dtype=float)
        center, theta, radius = centered_theta(pc1, pc2)

        baseline_raw = unwrap_with_anchor(theta, global_anchor)
        sign_base, baseline_vals, baseline_sign_trials = choose_best_sign(baseline_raw, metric_ids)
        baseline_summary = summarize_candidate_for_fit(baseline_vals, metric_ids)
        per_fit_baseline[fit] = baseline_summary

        if fit == "BARI":
            bari_methods = bari_targeted_methods(theta, metric_ids, global_anchor)
            bari_scoreboard = []
            for name, rec in bari_methods.items():
                summary = rec["summary"]
                score = (
                    1000.0 * (1 if (summary["monotone_increasing"] or summary["monotone_decreasing"]) else 0)
                    + 100.0 * summary["abs_spearman_rho_vs_metric_id"]
                    + abs(summary["endpoint_separation_last_minus_first"])
                    + 0.1 * summary["dynamic_range"]
                    - 0.5 * summary["ties_count_after_round12"]
                )
                bari_scoreboard.append({
                    "method_name": name,
                    "selection_score": float(score),
                    **summary,
                })
            bari_scoreboard = sorted(bari_scoreboard, key=lambda d: d["selection_score"], reverse=True)
            best_method_name = bari_scoreboard[0]["method_name"]

            if best_method_name == "exhaustive_integer_lift_from_metric003":
                best_method = bari_methods[best_method_name]
                targeted_vals = np.asarray(best_method["best_trial"]["sign_trials"][0]["values"], dtype=float)
                # Use the exact chosen sign and best-trial sequence.
                targeted_vals = np.asarray(best_method["best_trial"]["sequence_before_sign_choice"], dtype=float) * float(best_method["best_trial"]["chosen_sign"])
                targeted_summary = summarize_candidate_for_fit(targeted_vals, metric_ids)
            else:
                best_method = bari_methods[best_method_name]
                targeted_vals = np.asarray(best_method["sequence_before_sign_choice"], dtype=float) * float(best_method["chosen_sign"])
                targeted_summary = summarize_candidate_for_fit(targeted_vals, metric_ids)

            fit_details[fit] = {
                "fit_center_PC1_PC2": [float(center[0]), float(center[1])],
                "theta_raw": [float(x) for x in theta],
                "radius_raw": [float(x) for x in radius],
                "baseline_global_anchor": {
                    "anchor_angle": float(global_anchor),
                    "sequence_before_sign_choice": [float(x) for x in baseline_raw],
                    "chosen_sign": float(sign_base),
                    "sign_trials": baseline_sign_trials,
                    "summary": baseline_summary,
                    "orbit_plateau_diagnostics": detect_orbit_plateau_pattern(baseline_vals),
                },
                "bari_targeted_methods": bari_methods,
                "bari_targeted_scoreboard": bari_scoreboard,
                "selected_bari_method": best_method_name,
                "selected_bari_summary": targeted_summary,
                "selected_bari_orbit_plateau_diagnostics": detect_orbit_plateau_pattern(targeted_vals),
            }
        else:
            targeted_vals = baseline_vals.copy()
            targeted_summary = baseline_summary
            fit_details[fit] = {
                "fit_center_PC1_PC2": [float(center[0]), float(center[1])],
                "theta_raw": [float(x) for x in theta],
                "radius_raw": [float(x) for x in radius],
                "baseline_global_anchor": {
                    "anchor_angle": float(global_anchor),
                    "sequence_before_sign_choice": [float(x) for x in baseline_raw],
                    "chosen_sign": float(sign_base),
                    "sign_trials": baseline_sign_trials,
                    "summary": baseline_summary,
                    "orbit_plateau_diagnostics": detect_orbit_plateau_pattern(baseline_vals),
                },
                "bari_targeted_methods": None,
                "bari_targeted_scoreboard": None,
                "selected_bari_method": "not_applicable_non_BARI",
                "selected_bari_summary": targeted_summary,
                "selected_bari_orbit_plateau_diagnostics": detect_orbit_plateau_pattern(targeted_vals),
            }

        per_fit_targeted[fit] = targeted_summary

        work.loc[sub["index"], "stage5C_v4_angle_canonical_baseline_raw"] = baseline_vals
        work.loc[sub["index"], "stage5C_v4_angle_canonical_baseline_norm01_withinFIT"] = minmax01(baseline_vals)
        work.loc[sub["index"], "stage5C_v4_angle_canonical_baseline_z_withinFIT"] = zscore(baseline_vals)
        work.loc[sub["index"], "stage5C_v4_angle_canonical_baseline_rank_withinFIT"] = rank_average_ties(baseline_vals)

        work.loc[sub["index"], "stage5C_v4_angle_bari_targeted_raw"] = targeted_vals
        work.loc[sub["index"], "stage5C_v4_angle_bari_targeted_norm01_withinFIT"] = minmax01(targeted_vals)
        work.loc[sub["index"], "stage5C_v4_angle_bari_targeted_z_withinFIT"] = zscore(targeted_vals)
        work.loc[sub["index"], "stage5C_v4_angle_bari_targeted_rank_withinFIT"] = rank_average_ties(targeted_vals)

    aggregate = {
        "option3_angle_canonical_baseline": aggregate_candidate_summary(per_fit_baseline),
        "option4_angle_bari_targeted_hybrid": aggregate_candidate_summary(per_fit_targeted),
    }

    scoreboard = []
    for name, agg in aggregate.items():
        scoreboard.append({
            "candidate_name": name,
            "selection_score": float(score_aggregate_summary(agg)),
            **agg,
        })
    scoreboard = sorted(scoreboard, key=lambda d: d["selection_score"], reverse=True)
    recommended = scoreboard[0]["candidate_name"]

    orbit_summary = {
        "option3_angle_canonical_baseline": {},
        "option4_angle_bari_targeted_hybrid": {},
    }
    for fit in fit_names:
        orbit_summary["option3_angle_canonical_baseline"][fit] = fit_details[fit]["baseline_global_anchor"]["orbit_plateau_diagnostics"]
        orbit_summary["option4_angle_bari_targeted_hybrid"][fit] = fit_details[fit]["selected_bari_orbit_plateau_diagnostics"]

    work = work.sort_values(by=["FIT_id", "_metric_order_key"]).reset_index(drop=True)
    work = work.drop(columns=["_metric_order_key"])
    work.to_csv(OUTPUT_CSV, index=False)

    payload = {
        "created_utc": pd.Timestamp.utcnow().isoformat(),
        "stage": "5C",
        "script_version": SCRIPT_VERSION,
        "inputs": {
            "repo_root": str(REPO_ROOT),
            "stage5b_metric_candidate_csv": str(INPUT_CSV),
            "stage5b_metric_candidate_json": str(INPUT_JSON),
            "stage5b_metric_candidate_csv_sha256": sha256_of_file(INPUT_CSV),
            "stage5b_metric_candidate_json_sha256": sha256_of_file(INPUT_JSON),
        },
        "decision_basis_entering_stage5C_v4": {
            "stage5c_v3_recommendation": "option3_angle_canonical",
            "stage5c_v3_limitation": "BARI remained non-monotone under canonical angle despite NUFIT and VALENCIA success",
            "stage5c_v4_goal": "test whether BARI can be unfolded by targeted endpoint / integer-lift angular symmetry breaking",
        },
        "global_reference_from_stage5B": {
            "pc1_loadings_feature_order": meta.get("global_pca", {}).get("pc1_loadings_feature_order", {}),
            "pc2_loadings_feature_order": meta.get("global_pca", {}).get("pc2_loadings_feature_order", {}),
            "explained_variance_ratio_desc_signed": meta.get("global_pca", {}).get("explained_variance_ratio_desc_signed", []),
        },
        "global_stage5c_v4_anchor": {
            "global_center_PC1_PC2": [float(global_center[0]), float(global_center[1])],
            "global_anchor_angle_radians": float(global_anchor),
            "anchor_definition": "circular_mean_of_all_centered_stage5B_points_in_PC1_PC2_plane",
        },
        "fit_level_details": fit_details,
        "aggregate_comparison": aggregate,
        "orbit_plateau_summary": orbit_summary,
        "recommendation": {
            "recommended_candidate_name": recommended,
            "scoreboard_descending": scoreboard,
            "interpretive_note": "v4 compares only the v3 canonical baseline against a BARI-targeted hybrid directional coordinate.",
        },
        "outputs": {
            "csv": str(OUTPUT_CSV),
            "json": str(OUTPUT_JSON),
        },
    }
    dump_json_safe(payload, OUTPUT_JSON)

    print("[Stage-5C intrinsic-coordinate v4] Wrote:")
    print(f"  CSV : {OUTPUT_CSV}")
    print(f"  JSON: {OUTPUT_JSON}")
    print("[Stage-5C intrinsic-coordinate v4] Comparison scoreboard (best first):")
    for item in scoreboard:
        print(
            "  - {name}: score={score:.6f}, monotone_any_dir={mcount}, mean_abs_rho={rho:.6f}, ties={ties}".format(
                name=item["candidate_name"],
                score=item["selection_score"],
                mcount=item["monotone_any_direction_count"],
                rho=item["mean_abs_spearman_rho"],
                ties=item["total_ties_count_after_round12"],
            )
        )
    print("[Stage-5C intrinsic-coordinate v4] BARI targeted unfolding scoreboard:")
    bari_board = fit_details["BARI"]["bari_targeted_scoreboard"]
    for item in bari_board:
        print(
            "  - {name}: score={score:.6f}, mono_inc={inc}, mono_dec={dec}, rho={rho:.6f}, end_sep={endsep:.6f}, ties={ties}".format(
                name=item["method_name"],
                score=item["selection_score"],
                inc=item["monotone_increasing"],
                dec=item["monotone_decreasing"],
                rho=item["spearman_rho_vs_metric_id"],
                endsep=item["endpoint_separation_last_minus_first"],
                ties=item["ties_count_after_round12"],
            )
        )
    print(f"[Stage-5C intrinsic-coordinate v4] Selected BARI method: {fit_details['BARI']['selected_bari_method']}")
    print(f"[Stage-5C intrinsic-coordinate v4] Recommended candidate: {recommended}")


if __name__ == "__main__":
    main()
