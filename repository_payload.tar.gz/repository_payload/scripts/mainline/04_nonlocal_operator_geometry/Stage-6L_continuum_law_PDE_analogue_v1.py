#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
============================================================
Quantum-Emergent Gravity
Stage-6L: Continuum Law / PDE Analogue

Author: Arturo Ortiz-Tapia
Build Date: 2026-04-21

Summary:
Stage-6J found strong nonlocal coupling from kappa to rho.
Stage-6K reduced that coupling to a dominant low-rank mode.
Stage-6L tests whether this compact response can be expressed as
an interpretable continuum constitutive equation, Green-function
law, or PDE analogue.

This script emphasizes:
- transparent definitions
- explanatory comments
- reproducibility
- interpretable outputs
- cautious physical comparisons

Notes for Stage-6L
------------------
1) This script is designed for Spyder / plain Python execution.
2) It uses robust file discovery so it can be launched from different
   working directories.
3) Stage-6L really needs the Stage-6J kernel and preferably the Stage-6H
   profile in order to recover the dominant mode shapes u1(s), v1(s), and
   the underlying kappa(s), rho(s) fields on a common intrinsic grid.
4) When a required upstream file is missing, the script fails clearly and
   explains what is missing rather than silently improvising.

Conceptual target
-----------------
We are testing whether the practical rank-1 law

    rho(s) ≈ sigma1 * u1(s) * <v1, kappa>

admits one or more continuum interpretations such as:

    rho - L^2 rho'' = b kappa                     (screened response)
    rho'' + a rho' + c rho = d kappa             (general linear ODE)
    -(p rho')' + q rho = d kappa                 (Sturm-Liouville-like)

and whether a Green-kernel surrogate derived from those candidates is at
least qualitatively consistent with the empirical Stage-6J kernel.
============================================================
"""

from __future__ import annotations

import json
import math
import os
import sys
import glob
import traceback
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

try:
    from scipy.optimize import curve_fit
    SCIPY_AVAILABLE = True
except Exception:
    curve_fit = None
    SCIPY_AVAILABLE = False


# -----------------------------------------------------------------------------
# Console helpers
# -----------------------------------------------------------------------------

def echo(msg: str) -> None:
    """Console echo in the established stage style."""
    print(msg, flush=True)


def stage_echo(msg: str) -> None:
    echo(f"[Stage-6L] {msg}")


def precheck_echo(msg: str) -> None:
    echo(f"[Stage-6L PRECHECK] {msg}")


def warn_echo(msg: str) -> None:
    echo(f"[Stage-6L WARNING] {msg}")


# -----------------------------------------------------------------------------
# Small numerical helpers
# -----------------------------------------------------------------------------

def nan_to_none(x):
    if isinstance(x, float) and not np.isfinite(x):
        return None
    return x


def safe_corr(x: np.ndarray, y: np.ndarray) -> float:
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    if x.size != y.size or x.size == 0:
        return np.nan
    if np.std(x) == 0 or np.std(y) == 0:
        return np.nan
    return float(np.corrcoef(x, y)[0, 1])


def safe_r2(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    ss_res = float(np.sum((y_true - y_pred) ** 2))
    ss_tot = float(np.sum((y_true - np.mean(y_true)) ** 2))
    if ss_tot == 0.0:
        return np.nan
    return 1.0 - ss_res / ss_tot


def safe_rmse(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    return float(np.sqrt(np.mean((y_true - y_pred) ** 2)))


def cosine_similarity(x: np.ndarray, y: np.ndarray) -> float:
    x = np.asarray(x, dtype=float).ravel()
    y = np.asarray(y, dtype=float).ravel()
    nx = np.linalg.norm(x)
    ny = np.linalg.norm(y)
    if nx == 0 or ny == 0:
        return np.nan
    return float(np.dot(x, y) / (nx * ny))


def normalize_vector(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=float).ravel()
    nrm = np.linalg.norm(x)
    if nrm == 0:
        return x.copy()
    return x / nrm


def orient_mode(mode: np.ndarray, prefer_negative_center: bool = False) -> np.ndarray:
    """
    Singular vectors are sign-indeterminate. We orient them with a stable rule:
    - otherwise make the largest absolute entry positive,
    - optionally prefer a negative center (useful for the Stage-6K target bump,
      whose mean and the earlier interpretation suggested a negative central well).
    """
    mode = np.asarray(mode, dtype=float).copy()
    if mode.size == 0:
        return mode
    center = mode[mode.size // 2]
    if prefer_negative_center and center > 0:
        return -mode
    idx = int(np.argmax(np.abs(mode)))
    if mode[idx] < 0:
        return -mode
    return mode


def second_derivative(y: np.ndarray, s: np.ndarray) -> np.ndarray:
    return np.gradient(np.gradient(y, s), s)


def first_derivative(y: np.ndarray, s: np.ndarray) -> np.ndarray:
    return np.gradient(y, s)


def effective_bandwidth_from_kernel(K: np.ndarray, threshold_fraction: float = 0.05) -> float:
    """
    Crude effective bandwidth from row-wise support width around the largest mass.
    The result is normalized by source grid length.
    """
    Kabs = np.abs(np.asarray(K, dtype=float))
    n_t, n_s = Kabs.shape
    if n_t == 0 or n_s == 0:
        return np.nan
    widths = []
    for i in range(n_t):
        row = Kabs[i]
        maxv = float(np.max(row))
        if maxv <= 0:
            continue
        mask = row >= threshold_fraction * maxv
        if not np.any(mask):
            continue
        idx = np.flatnonzero(mask)
        widths.append((idx[-1] - idx[0] + 1) / max(n_s, 1))
    if not widths:
        return np.nan
    return float(np.mean(widths))


def transport_skew_from_kernel(K: np.ndarray) -> float:
    """Average target-source displacement weighted by |K|, normalized by grid size."""
    Kabs = np.abs(np.asarray(K, dtype=float))
    n_t, n_s = Kabs.shape
    if n_t == 0 or n_s == 0:
        return np.nan
    ii, jj = np.meshgrid(np.arange(n_t), np.arange(n_s), indexing='ij')
    weights = Kabs
    denom = float(np.sum(weights))
    if denom == 0.0:
        return np.nan
    skew = float(np.sum(weights * (ii - jj))) / denom
    return skew / max(n_t, n_s)


# -----------------------------------------------------------------------------
# Data classes
# -----------------------------------------------------------------------------

@dataclass
class LocatedFiles:
    project_root: Path
    output_dir: Path
    stage6k_summary_json: Path
    stage6k_notes_txt: Path
    stage6k_profile_csv: Path
    stage6k_singular_values_csv: Path
    stage6k_rank_reconstruction_csv: Path
    stage6j_kernel_csv: Optional[Path]
    stage6h_profile_csv: Optional[Path]


@dataclass
class ModeFitResult:
    side: str
    family: str
    score_r2: float
    rmse: float
    corr: float
    parameters: Dict[str, float]


@dataclass
class OperatorFitRow:
    family: str
    variant: str
    r2: float
    corr: float
    rmse: float
    parameters: Dict[str, float]
    plausibility_comment: str


# -----------------------------------------------------------------------------
# Discovery / loading
# -----------------------------------------------------------------------------

def candidate_roots_from_environment() -> List[Path]:
    roots: List[Path] = []

    # Current interpreter, current working directory, and script location are the
    # most relevant locations for Spyder / local Python usage.
    roots.extend([
        Path.cwd(),
        Path(sys.executable).resolve().parent,
        Path(__file__).resolve().parent,
    ])

    # Common user-specific project location used in earlier stages.
    roots.append(Path('/home/dakini/Downloads/010-Quantum_Emergent_Gravity'))

    # Walk a couple of parents upward from the working directory.
    cwd = Path.cwd().resolve()
    roots.extend(cwd.parents)

    # Deduplicate while preserving order.
    out: List[Path] = []
    seen = set()
    for root in roots:
        try:
            rr = root.resolve()
        except Exception:
            rr = root
        if rr not in seen:
            seen.add(rr)
            out.append(rr)
    return out


def find_first_existing(paths: Iterable[Path]) -> Optional[Path]:
    for p in paths:
        if p and p.exists():
            return p
    return None


def glob_first(patterns: Sequence[str], base_dirs: Sequence[Path]) -> Optional[Path]:
    for base in base_dirs:
        for pattern in patterns:
            matches = sorted(base.glob(pattern))
            if matches:
                return matches[0]
    return None


def discover_project_root() -> Path:
    """Locate the QEG project root by checking for known stage output folders."""
    precheck_echo('Discovering project root...')
    roots = candidate_roots_from_environment()

    known_markers = [
        'metric_stage_6K_outputs',
        'metric_stage_6J_outputs',
        'metric_stage_6H_outputs',
    ]

    for root in roots:
        if all((root / marker).exists() for marker in ['metric_stage_6K_outputs']):
            precheck_echo(f'Project root discovered: {root}')
            return root

    # Broader recursive search from a few candidate roots.
    for base in roots[:5]:
        for match in base.glob('**/metric_stage_6K_outputs'):
            project_root = match.parent
            if project_root.exists():
                precheck_echo(f'Project root discovered by recursive search: {project_root}')
                return project_root

    raise FileNotFoundError(
        'Could not locate the Quantum-Emergent Gravity project root. '
        'Expected a directory containing metric_stage_6K_outputs.'
    )


def locate_stage6l_files() -> LocatedFiles:
    project_root = discover_project_root()
    stage6k_dir = project_root / 'metric_stage_6K_outputs'
    stage6j_dir = project_root / 'metric_stage_6J_outputs'
    stage6h_dir = project_root / 'metric_stage_6H_outputs'
    output_dir = project_root / 'metric_stage_6L_outputs'

    summary_json = stage6k_dir / 'stage6K_canonical_operator_summary.json'
    notes_txt = stage6k_dir / 'stage6K_canonical_operator_notes.txt'
    profile_csv = stage6k_dir / 'stage6K_canonical_operator_profile.csv'
    singular_csv = stage6k_dir / 'stage6K_singular_values.csv'
    rank_csv = stage6k_dir / 'stage6K_rank_reconstruction_table.csv'

    required = [summary_json, notes_txt, profile_csv, singular_csv, rank_csv]
    missing = [str(p) for p in required if not p.exists()]
    if missing:
        raise FileNotFoundError(
            'Missing required Stage-6K inputs:\n' + '\n'.join(missing)
        )

    kernel_csv = stage6j_dir / 'stage6J_kernel_matrix_best.csv'
    if not kernel_csv.exists():
        # Fall back to any matching file under the project root.
        kernel_csv = find_first_existing([
            project_root / 'stage6J_kernel_matrix_best.csv',
            *project_root.glob('**/stage6J_kernel_matrix_best.csv'),
        ])

    stage6h_csv = stage6h_dir / 'stage6H_distributional_profile.csv'
    if not stage6h_csv.exists():
        stage6h_csv = find_first_existing([
            project_root / 'stage6H_distributional_profile.csv',
            *project_root.glob('**/stage6H_distributional_profile.csv'),
        ])

    return LocatedFiles(
        project_root=project_root,
        output_dir=output_dir,
        stage6k_summary_json=summary_json,
        stage6k_notes_txt=notes_txt,
        stage6k_profile_csv=profile_csv,
        stage6k_singular_values_csv=singular_csv,
        stage6k_rank_reconstruction_csv=rank_csv,
        stage6j_kernel_csv=kernel_csv,
        stage6h_profile_csv=stage6h_csv,
    )


def read_json(path: Path) -> dict:
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)


# -----------------------------------------------------------------------------
# Kernel loading
# -----------------------------------------------------------------------------

def kernel_from_long_table(df: pd.DataFrame) -> Optional[np.ndarray]:
    possible_source_cols = ['source_index', 'source_idx', 'j', 'col', 'column_index']
    possible_target_cols = ['target_index', 'target_idx', 'i', 'row', 'row_index']
    possible_value_cols = ['kernel_weight', 'weight', 'value', 'kernel', 'g', 'entry']

    source_col = next((c for c in possible_source_cols if c in df.columns), None)
    target_col = next((c for c in possible_target_cols if c in df.columns), None)
    value_col = next((c for c in possible_value_cols if c in df.columns), None)

    if source_col and target_col and value_col:
        dfx = df[[target_col, source_col, value_col]].copy()
        dfx[target_col] = dfx[target_col].astype(int)
        dfx[source_col] = dfx[source_col].astype(int)
        dfx = dfx.sort_values([target_col, source_col])
        n_t = int(dfx[target_col].max()) + 1
        n_s = int(dfx[source_col].max()) + 1
        K = np.full((n_t, n_s), np.nan, dtype=float)
        for _, row in dfx.iterrows():
            K[int(row[target_col]), int(row[source_col])] = float(row[value_col])
        if np.isnan(K).any():
            return None
        return K
    return None


def kernel_from_wide_table(df: pd.DataFrame) -> Optional[np.ndarray]:
    # Try purely numeric content after dropping obvious index-like columns.
    work = df.copy()
    drop_candidates = ['Unnamed: 0', 'index', 'target_index', 'row_index']
    for col in drop_candidates:
        if col in work.columns:
            work = work.drop(columns=[col])
    numeric = work.select_dtypes(include=[np.number])
    if numeric.shape[0] >= 2 and numeric.shape[1] >= 2:
        return numeric.to_numpy(dtype=float)
    return None


def load_kernel_matrix(path: Path) -> np.ndarray:
    precheck_echo(f'Loading Stage-6J kernel matrix: {path}')
    df = pd.read_csv(path)
    K = kernel_from_long_table(df)
    if K is None:
        K = kernel_from_wide_table(df)
    if K is None:
        raise ValueError(
            'Could not reconstruct kernel matrix from Stage-6J CSV. '
            'Expected either long-table columns such as source_index / target_index / kernel_weight '
            'or a rectangular numeric matrix.'
        )
    return np.asarray(K, dtype=float)


# -----------------------------------------------------------------------------
# Stage-6H profile loading
# -----------------------------------------------------------------------------

def pick_first_present(columns: Sequence[str], candidates: Sequence[str]) -> Optional[str]:
    for c in candidates:
        if c in columns:
            return c
    return None


def coarsen_series(x: np.ndarray, n_bins: int) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    if n_bins >= x.size:
        return x.copy()
    edges = np.linspace(0, x.size, n_bins + 1).astype(int)
    out = []
    for a, b in zip(edges[:-1], edges[1:]):
        segment = x[a:b]
        if segment.size == 0:
            continue
        out.append(float(np.mean(segment)))
    return np.asarray(out, dtype=float)


def infer_coarse_target_length(summary: dict, kernel_shape: Tuple[int, int]) -> int:
    try:
        n_points = summary['upstream_stage6j_context']['best_free_kernel_profile_row']['n_points']
        if np.isfinite(n_points):
            return int(round(float(n_points)))
    except Exception:
        pass
    return int(kernel_shape[0])


def load_stage6h_profile(path: Path, target_length: int) -> Tuple[np.ndarray, np.ndarray, np.ndarray, pd.DataFrame, Dict[str, str]]:
    """
    Returns s, kappa, rho, raw_df, selected_columns.

    The Stage-6H contract from the earlier handoff preferred columns like:
    - s or s_normalized
    - abs_kappa or kappa
    - density

    Because versions can differ, we use robust column heuristics.
    """
    precheck_echo(f'Loading Stage-6H profile: {path}')
    df = pd.read_csv(path)
    cols = list(df.columns)

    s_col = pick_first_present(cols, [
        's_normalized', 's', 'intrinsic_coordinate', 'preferred_directional_coordinate',
        'arc_fraction', 'grid_s', 'x'
    ])
    kappa_col = pick_first_present(cols, [
        'abs_kappa', 'kappa_abs', 'kappa', 'curvature', 'abs_curvature'
    ])
    rho_col = pick_first_present(cols, [
        'density', 'rho', 'density_mass', 'probability_density', 'mass_density'
    ])

    if s_col is None:
        # If no intrinsic coordinate column exists, use row index normalized to [0,1].
        warn_echo('No explicit intrinsic coordinate column found in Stage-6H profile; using normalized row index.')
        s = np.linspace(0.0, 1.0, len(df))
    else:
        s = np.asarray(df[s_col], dtype=float)

    if kappa_col is None or rho_col is None:
        raise ValueError(
            'Stage-6H profile does not contain recoverable kappa/density columns. '
            f'Columns seen: {cols}'
        )

    kappa = np.asarray(df[kappa_col], dtype=float)
    rho = np.asarray(df[rho_col], dtype=float)

    # Sort by intrinsic coordinate if needed.
    order = np.argsort(s)
    s = s[order]
    kappa = kappa[order]
    rho = rho[order]
    df = df.iloc[order].reset_index(drop=True)

    # Coarsen to match kernel size if Stage-6H is finer than the Stage-6J best variant.
    if len(s) != target_length:
        precheck_echo(f'Coarsening Stage-6H profile from {len(s)} to target length {target_length}.')
        s = coarsen_series(s, target_length)
        kappa = coarsen_series(kappa, target_length)
        rho = coarsen_series(rho, target_length)

    # Re-normalize s to [0,1] to make extracted lengths dimensionless and comparable.
    s_min = float(np.min(s))
    s_max = float(np.max(s))
    if s_max > s_min:
        s = (s - s_min) / (s_max - s_min)
    else:
        s = np.linspace(0.0, 1.0, len(s))

    selected = {'s_col': s_col or '__row_index__', 'kappa_col': kappa_col, 'rho_col': rho_col}
    return s, kappa, rho, df, selected


# -----------------------------------------------------------------------------
# Mode fitting families
# -----------------------------------------------------------------------------

def family_gaussian(s, A, mu, sig, C):
    sig = max(abs(sig), 1e-8)
    return C + A * np.exp(-0.5 * ((s - mu) / sig) ** 2)


def family_exponential_centered(s, A, mu, ell, C):
    ell = max(abs(ell), 1e-8)
    return C + A * np.exp(-np.abs(s - mu) / ell)


def family_screened_exp_left(s, A, ell, C):
    ell = max(abs(ell), 1e-8)
    return C + A * np.exp(-s / ell)


def family_screened_exp_right(s, A, ell, C):
    ell = max(abs(ell), 1e-8)
    return C + A * np.exp(-(1.0 - s) / ell)


def family_cosine(s, A, k, phi, C):
    return C + A * np.cos(2.0 * np.pi * k * s + phi)


def family_poly2(s, a0, a1, a2):
    return a0 + a1 * s + a2 * s ** 2


def family_bessel_like(s, A, omega, C):
    # A smooth surrogate rather than a strict Bessel function, so that the fit
    # remains robust even when scipy.special is unavailable.
    return C + A * np.sinc(omega * (s - 0.5) / np.pi)


def family_boundary_layer_left(s, A, ell, B, C):
    ell = max(abs(ell), 1e-8)
    return C + A * np.exp(-s / ell) + B * s


def family_boundary_layer_right(s, A, ell, B, C):
    ell = max(abs(ell), 1e-8)
    return C + A * np.exp(-(1.0 - s) / ell) + B * (1.0 - s)


def fit_curve_family(
    s: np.ndarray,
    y: np.ndarray,
    family_name: str,
    func,
    p0: Sequence[float],
    bounds: Tuple[Sequence[float], Sequence[float]],
    side: str,
) -> Optional[ModeFitResult]:
    s = np.asarray(s, dtype=float)
    y = np.asarray(y, dtype=float)

    try:
        if SCIPY_AVAILABLE:
            popt, _ = curve_fit(func, s, y, p0=p0, bounds=bounds, maxfev=50000)
            yhat = func(s, *popt)
            params = {f'p{i+1}': float(v) for i, v in enumerate(popt)}
        else:
            # Fall back only for polynomial; otherwise skip family.
            if family_name == 'low_polynomial':
                coeffs = np.polyfit(s, y, 2)
                yhat = np.polyval(coeffs, s)
                params = {'a2': float(coeffs[0]), 'a1': float(coeffs[1]), 'a0': float(coeffs[2])}
            else:
                return None

        return ModeFitResult(
            side=side,
            family=family_name,
            score_r2=safe_r2(y, yhat),
            rmse=safe_rmse(y, yhat),
            corr=safe_corr(y, yhat),
            parameters=params,
        )
    except Exception:
        return None


def fit_mode_families(s: np.ndarray, y: np.ndarray, side: str) -> List[ModeFitResult]:
    s = np.asarray(s, dtype=float)
    y = np.asarray(y, dtype=float)
    amp = float(np.max(y) - np.min(y))
    y_mean = float(np.mean(y))
    peak_loc = float(s[int(np.argmax(np.abs(y - y_mean)))])
    results: List[ModeFitResult] = []

    families = [
        ('gaussian', family_gaussian,
         [amp if amp != 0 else 1.0, peak_loc, 0.15, y_mean],
         ([-10 * max(abs(amp), 1e-6), 0.0, 1e-4, -10 * max(abs(y_mean) + abs(amp), 1e-6)],
          [10 * max(abs(amp), 1e-6), 1.0, 2.0, 10 * max(abs(y_mean) + abs(amp), 1e-6)])),

        ('exponential', family_exponential_centered,
         [amp if amp != 0 else 1.0, peak_loc, 0.2, y_mean],
         ([-10 * max(abs(amp), 1e-6), 0.0, 1e-4, -10 * max(abs(y_mean) + abs(amp), 1e-6)],
          [10 * max(abs(amp), 1e-6), 1.0, 3.0, 10 * max(abs(y_mean) + abs(amp), 1e-6)])),

        ('screened_exponential_left', family_screened_exp_left,
         [amp if amp != 0 else 1.0, 0.2, y_mean],
         ([-10 * max(abs(amp), 1e-6), 1e-4, -10 * max(abs(y_mean) + abs(amp), 1e-6)],
          [10 * max(abs(amp), 1e-6), 3.0, 10 * max(abs(y_mean) + abs(amp), 1e-6)])),

        ('screened_exponential_right', family_screened_exp_right,
         [amp if amp != 0 else 1.0, 0.2, y_mean],
         ([-10 * max(abs(amp), 1e-6), 1e-4, -10 * max(abs(y_mean) + abs(amp), 1e-6)],
          [10 * max(abs(amp), 1e-6), 3.0, 10 * max(abs(y_mean) + abs(amp), 1e-6)])),

        ('cosine', family_cosine,
         [amp if amp != 0 else 1.0, 1.0, 0.0, y_mean],
         ([-10 * max(abs(amp), 1e-6), 0.0, -4 * np.pi, -10 * max(abs(y_mean) + abs(amp), 1e-6)],
          [10 * max(abs(amp), 1e-6), 4.0, 4 * np.pi, 10 * max(abs(y_mean) + abs(amp), 1e-6)])),

        ('low_polynomial', family_poly2,
         [y_mean, 0.0, 0.0],
         ([-10 * max(abs(y_mean) + abs(amp), 1e-6)] * 3,
          [10 * max(abs(y_mean) + abs(amp), 1e-6)] * 3)),

        ('bessel_like', family_bessel_like,
         [amp if amp != 0 else 1.0, 3.0, y_mean],
         ([-10 * max(abs(amp), 1e-6), 0.1, -10 * max(abs(y_mean) + abs(amp), 1e-6)],
          [10 * max(abs(amp), 1e-6), 20.0, 10 * max(abs(y_mean) + abs(amp), 1e-6)])),

        ('boundary_layer_left', family_boundary_layer_left,
         [amp if amp != 0 else 1.0, 0.15, 0.0, y_mean],
         ([-10 * max(abs(amp), 1e-6), 1e-4, -10 * max(abs(amp), 1e-6), -10 * max(abs(y_mean) + abs(amp), 1e-6)],
          [10 * max(abs(amp), 1e-6), 3.0, 10 * max(abs(amp), 1e-6), 10 * max(abs(y_mean) + abs(amp), 1e-6)])),

        ('boundary_layer_right', family_boundary_layer_right,
         [amp if amp != 0 else 1.0, 0.15, 0.0, y_mean],
         ([-10 * max(abs(amp), 1e-6), 1e-4, -10 * max(abs(amp), 1e-6), -10 * max(abs(y_mean) + abs(amp), 1e-6)],
          [10 * max(abs(amp), 1e-6), 3.0, 10 * max(abs(amp), 1e-6), 10 * max(abs(y_mean) + abs(amp), 1e-6)])),
    ]

    for family_name, func, p0, bounds in families:
        res = fit_curve_family(s, y, family_name, func, p0, bounds, side)
        if res is not None:
            results.append(res)

    results.sort(key=lambda r: (-np.nan_to_num(r.score_r2, nan=-np.inf), np.nan_to_num(r.rmse, nan=np.inf)))
    return results


# -----------------------------------------------------------------------------
# Differential operator fits
# -----------------------------------------------------------------------------

def fit_screened_response(s: np.ndarray, kappa: np.ndarray, rho: np.ndarray) -> OperatorFitRow:
    """
    Fit: rho - L^2 rho'' = b kappa.

    For each candidate L we solve the linear least-squares problem for b.
    This is intentionally separated into a one-parameter nonlinear search and a
    linear solve because it is transparent and numerically stable.
    """
    rho2 = second_derivative(rho, s)
    best = None
    for L in np.linspace(0.0, 1.5, 301):
        lhs = rho - (L ** 2) * rho2
        denom = float(np.dot(kappa, kappa))
        b = 0.0 if denom == 0.0 else float(np.dot(kappa, lhs) / denom)
        lhs_hat = b * kappa
        rmse = safe_rmse(lhs, lhs_hat)
        row = OperatorFitRow(
            family='screened_response',
            variant='rho - L^2 rho" = b kappa',
            r2=safe_r2(lhs, lhs_hat),
            corr=safe_corr(lhs, lhs_hat),
            rmse=rmse,
            parameters={'L': L, 'b': b},
            plausibility_comment='Helmholtz/screened-Poisson-like closure on intrinsic coordinate.'
        )
        if best is None or row.rmse < best.rmse:
            best = row
    assert best is not None
    return best


def fit_general_linear_ode(s: np.ndarray, kappa: np.ndarray, rho: np.ndarray) -> OperatorFitRow:
    """Fit rho'' + a rho' + c rho = d kappa via linear least squares."""
    rho1 = first_derivative(rho, s)
    rho2 = second_derivative(rho, s)
    X = np.column_stack([rho1, rho, kappa])
    y = -rho2
    coef, *_ = np.linalg.lstsq(X, y, rcond=None)
    a, c, minus_d = coef
    d = -float(minus_d)
    lhs = rho2 + a * rho1 + c * rho
    rhs = d * kappa
    return OperatorFitRow(
        family='general_linear_ode',
        variant='rho" + a rho\' + c rho = d kappa',
        r2=safe_r2(lhs, rhs),
        corr=safe_corr(lhs, rhs),
        rmse=safe_rmse(lhs, rhs),
        parameters={'a': float(a), 'c': float(c), 'd': d},
        plausibility_comment='More flexible linear differential closure; may absorb drift and restoring terms.'
    )


def fit_sturm_liouville_like(s: np.ndarray, kappa: np.ndarray, rho: np.ndarray) -> OperatorFitRow:
    """
    Approximate -(p rho')' + q rho = d kappa with p(s)=p0+p1*s, q constant.

    This is a modest, interpretable surrogate rather than a fully general function-space fit.
    It keeps the model identifiable for small grid sizes.
    """
    rho1 = first_derivative(rho, s)
    rho2 = second_derivative(rho, s)
    # -(p rho')' = -(p rho'' + p' rho'). With p(s)=p0+p1*s, p'=p1.
    A = np.column_stack([
        -rho2,            # coefficient p0
        -(s * rho2 + rho1),  # coefficient p1
        rho,              # coefficient q0
        -kappa            # coefficient -d
    ])
    y = np.zeros_like(rho)
    coef, *_ = np.linalg.lstsq(A, y, rcond=None)
    p0, p1, q0, minus_d = coef
    d = -float(minus_d)
    lhs = -(p0 * rho2 + p1 * (s * rho2 + rho1)) + q0 * rho
    rhs = d * kappa
    return OperatorFitRow(
        family='sturm_liouville_like',
        variant='-(p rho\')\' + q rho = d kappa with p(s)=p0+p1 s',
        r2=safe_r2(lhs, rhs),
        corr=safe_corr(lhs, rhs),
        rmse=safe_rmse(lhs, rhs),
        parameters={'p0': float(p0), 'p1': float(p1), 'q0': float(q0), 'd': d},
        plausibility_comment='Weak Sturm-Liouville surrogate with low-complexity coefficient field.'
    )


# -----------------------------------------------------------------------------
# Green-kernel surrogates and weak-form tests
# -----------------------------------------------------------------------------

def pairwise_distance_grid(s_t: np.ndarray, s_s: np.ndarray) -> np.ndarray:
    st = np.asarray(s_t, dtype=float)[:, None]
    ss = np.asarray(s_s, dtype=float)[None, :]
    return np.abs(st - ss)


def green_kernel_screened(s_t: np.ndarray, s_s: np.ndarray, L: float) -> np.ndarray:
    d = pairwise_distance_grid(s_t, s_s)
    L = max(abs(float(L)), 1e-8)
    return np.exp(-d / L)


def green_kernel_gaussian(s_t: np.ndarray, s_s: np.ndarray, ell: float) -> np.ndarray:
    d = pairwise_distance_grid(s_t, s_s)
    ell = max(abs(float(ell)), 1e-8)
    return np.exp(-0.5 * (d / ell) ** 2)


def green_kernel_boundary_left(s_t: np.ndarray, s_s: np.ndarray, ell: float) -> np.ndarray:
    st = np.asarray(s_t, dtype=float)[:, None]
    ss = np.asarray(s_s, dtype=float)[None, :]
    ell = max(abs(float(ell)), 1e-8)
    return np.exp(-st / ell) * np.exp(-ss / ell)


def fit_kernel_amplitude(empirical_K: np.ndarray, template_K: np.ndarray) -> Tuple[float, np.ndarray]:
    num = float(np.sum(empirical_K * template_K))
    den = float(np.sum(template_K * template_K))
    amp = 0.0 if den == 0.0 else num / den
    return amp, amp * template_K


def compare_green_families(
    s_t: np.ndarray,
    s_s: np.ndarray,
    empirical_K: np.ndarray,
    screened_L: float,
) -> List[OperatorFitRow]:
    candidates = []

    families = [
        ('green_screened', lambda: green_kernel_screened(s_t, s_s, screened_L),
         'Kernel implied by screened response length L.'),
        ('green_gaussian', lambda: green_kernel_gaussian(s_t, s_s, max(screened_L, 0.05)),
         'Smooth finite-range surrogate to test whether the empirical kernel is merely local smoothing.'),
        ('green_boundary_left', lambda: green_kernel_boundary_left(s_t, s_s, max(screened_L, 0.05)),
         'Boundary-forced separable response concentrated near one edge.'),
    ]

    for fam, builder, comment in families:
        K0 = builder()
        amp, Khat = fit_kernel_amplitude(empirical_K, K0)
        candidates.append(OperatorFitRow(
            family=fam,
            variant='kernel-vs-green',
            r2=safe_r2(empirical_K.ravel(), Khat.ravel()),
            corr=safe_corr(empirical_K.ravel(), Khat.ravel()),
            rmse=safe_rmse(empirical_K.ravel(), Khat.ravel()),
            parameters={
                'amplitude': amp,
                'effective_bandwidth': effective_bandwidth_from_kernel(Khat),
                'transport_skew': transport_skew_from_kernel(Khat),
            },
            plausibility_comment=comment,
        ))

    candidates.sort(key=lambda r: (-np.nan_to_num(r.r2, nan=-np.inf), np.nan_to_num(r.rmse, nan=np.inf)))
    return candidates


def weak_form_energy_scan(s: np.ndarray, kappa: np.ndarray, rho: np.ndarray) -> Dict[str, float]:
    """
    Weak-form / energy consistency test for

        E[rho] = ∫ (rho^2 + alpha |rho'|^2 - beta rho kappa) ds

    Euler-Lagrange gives a screened-like law. We therefore scan alpha and fit beta
    by least squares to assess consistency.
    """
    rho2 = second_derivative(rho, s)
    best = None
    for alpha in np.linspace(0.0, 1.5, 301):
        lhs = rho - alpha * rho2
        denom = float(np.dot(kappa, kappa))
        beta = 0.0 if denom == 0.0 else float(np.dot(kappa, lhs) / denom)
        rhs = beta * kappa
        rmse = safe_rmse(lhs, rhs)
        row = {
            'alpha': float(alpha),
            'beta': float(beta),
            'r2': safe_r2(lhs, rhs),
            'corr': safe_corr(lhs, rhs),
            'rmse': rmse,
            'euler_lagrange_comment': 'Best alpha/beta under weak-form screened-response consistency.'
        }
        if best is None or row['rmse'] < best['rmse']:
            best = row
    assert best is not None
    return best


# -----------------------------------------------------------------------------
# Scale extraction and cosmology track
# -----------------------------------------------------------------------------

def mode_width_from_half_max(s: np.ndarray, y: np.ndarray) -> float:
    y = np.asarray(y, dtype=float)
    s = np.asarray(s, dtype=float)
    ya = np.abs(y - np.mean(y))
    ymax = float(np.max(ya))
    if ymax <= 0:
        return np.nan
    mask = ya >= 0.5 * ymax
    idx = np.flatnonzero(mask)
    if idx.size == 0:
        return np.nan
    return float(s[idx[-1]] - s[idx[0]])


def oscillation_wavelength_from_zero_crossings(s: np.ndarray, y: np.ndarray) -> float:
    y0 = np.asarray(y, dtype=float) - np.mean(y)
    signs = np.sign(y0)
    zero_crossings = np.flatnonzero(signs[:-1] * signs[1:] < 0)
    if zero_crossings.size < 2:
        return np.nan
    s_cross = s[zero_crossings]
    mean_half_period = float(np.mean(np.diff(s_cross)))
    return 2.0 * mean_half_period


def extract_scale_table(
    s: np.ndarray,
    u1: np.ndarray,
    v1: np.ndarray,
    sigma1: float,
    best_screened: OperatorFitRow,
    best_energy: Dict[str, float],
) -> pd.DataFrame:
    rows = [
        {'scale_name': 'response_length_L', 'value': best_screened.parameters.get('L', np.nan),
         'interpretation': 'Best screened-response length on normalized intrinsic coordinate.'},
        {'scale_name': 'energy_alpha', 'value': best_energy.get('alpha', np.nan),
         'interpretation': 'Weak-form gradient penalty coefficient on normalized intrinsic coordinate.'},
        {'scale_name': 'mode_width_u1', 'value': mode_width_from_half_max(s, u1),
         'interpretation': 'Half-maximum width of dominant target mode.'},
        {'scale_name': 'mode_width_v1', 'value': mode_width_from_half_max(s, v1),
         'interpretation': 'Half-maximum width of dominant source mode.'},
        {'scale_name': 'oscillation_wavelength_v1', 'value': oscillation_wavelength_from_zero_crossings(s, v1),
         'interpretation': 'Approximate wavelength inferred from zero crossings of dominant source mode.'},
        {'scale_name': 'sigma1', 'value': sigma1,
         'interpretation': 'Leading singular value of the empirical kernel.'},
        {'scale_name': 'u1_l2_norm', 'value': float(np.linalg.norm(u1)),
         'interpretation': 'Diagnostic normalization check.'},
        {'scale_name': 'v1_l2_norm', 'value': float(np.linalg.norm(v1)),
         'interpretation': 'Diagnostic normalization check.'},
    ]
    return pd.DataFrame(rows)


def exploratory_cosmology_rows(scale_df: pd.DataFrame) -> pd.DataFrame:
    """
    Exploratory only. We do not assert identifications.

    The handoff asked for cautious tracking of dimensionless/scaled quantities that might
    resemble broad physical ratios. To keep this honest, we compare only normalized,
    dimensionless values from Stage-6L against a *small* reference set of widely cited
    cosmological fractions / parameters.
    """
    value_map = dict(zip(scale_df['scale_name'], scale_df['value']))
    stage_values = {
        'response_length_L': float(value_map.get('response_length_L', np.nan)),
        'mode_width_u1': float(value_map.get('mode_width_u1', np.nan)),
        'mode_width_v1': float(value_map.get('mode_width_v1', np.nan)),
    }

    # Reference values aligned with PDG 2024 booklet conventions for flat LCDM/Planck-era summaries.
    refs = {
        'Omega_b': 0.0493,
        'Omega_c': 0.2650,
        'Omega_m': 0.3150,
        'Omega_Lambda': 0.6850,
        'h': 0.6740,
    }

    rows = []
    for stage_name, stage_val in stage_values.items():
        if not np.isfinite(stage_val):
            continue
        for ref_name, ref_val in refs.items():
            rel_gap = abs(stage_val - ref_val)
            rows.append({
                'stage_quantity': stage_name,
                'stage_value': float(stage_val),
                'reference_quantity': ref_name,
                'reference_value': float(ref_val),
                'absolute_gap': float(rel_gap),
                'note': 'Exploratory dimensionless comparison only; no identification claim.'
            })
    out = pd.DataFrame(rows)
    if not out.empty:
        out = out.sort_values(['stage_quantity', 'absolute_gap']).reset_index(drop=True)
    return out


# -----------------------------------------------------------------------------
# Plotting
# -----------------------------------------------------------------------------

def save_mode_fit_plot(path: Path, s: np.ndarray, u1: np.ndarray, v1: np.ndarray,
                       best_u: ModeFitResult, best_v: ModeFitResult) -> None:
    plt.figure(figsize=(10, 6))
    plt.plot(s, u1, label='u1 empirical')
    plt.plot(s, v1, label='v1 empirical')

    # Reconstruct plotted best fits only for the displayed family names.
    fam_map = {
        'gaussian': family_gaussian,
        'exponential': family_exponential_centered,
        'screened_exponential_left': family_screened_exp_left,
        'screened_exponential_right': family_screened_exp_right,
        'cosine': family_cosine,
        'low_polynomial': family_poly2,
        'bessel_like': family_bessel_like,
        'boundary_layer_left': family_boundary_layer_left,
        'boundary_layer_right': family_boundary_layer_right,
    }

    def eval_fit(best: ModeFitResult) -> Optional[np.ndarray]:
        func = fam_map.get(best.family)
        if func is None:
            return None
        params = list(best.parameters.values())
        return func(s, *params)

    uhat = eval_fit(best_u)
    vhat = eval_fit(best_v)
    if uhat is not None:
        plt.plot(s, uhat, '--', label=f'u1 best fit: {best_u.family}')
    if vhat is not None:
        plt.plot(s, vhat, '--', label=f'v1 best fit: {best_v.family}')

    plt.xlabel('normalized intrinsic coordinate s')
    plt.ylabel('mode amplitude')
    plt.title('Stage-6L dominant-mode continuum fits')
    plt.legend()
    plt.tight_layout()
    plt.savefig(path, dpi=180)
    plt.close()


def save_pde_fit_plot(path: Path, s: np.ndarray, kappa: np.ndarray, rho: np.ndarray,
                      best_screened: OperatorFitRow, best_general: OperatorFitRow,
                      best_sturm: OperatorFitRow) -> None:
    rho1 = first_derivative(rho, s)
    rho2 = second_derivative(rho, s)

    L = best_screened.parameters['L']
    b = best_screened.parameters['b']
    screen_lhs = rho - (L ** 2) * rho2
    screen_rhs = b * kappa

    a = best_general.parameters['a']
    c = best_general.parameters['c']
    d = best_general.parameters['d']
    general_lhs = rho2 + a * rho1 + c * rho
    general_rhs = d * kappa

    p0 = best_sturm.parameters['p0']
    p1 = best_sturm.parameters['p1']
    q0 = best_sturm.parameters['q0']
    d2 = best_sturm.parameters['d']
    sturm_lhs = -(p0 * rho2 + p1 * (s * rho2 + rho1)) + q0 * rho
    sturm_rhs = d2 * kappa

    plt.figure(figsize=(10, 6))
    plt.plot(s, screen_lhs, label='screened lhs')
    plt.plot(s, screen_rhs, '--', label='screened rhs')
    plt.plot(s, general_lhs, label='general ODE lhs', alpha=0.7)
    plt.plot(s, general_rhs, '--', label='general ODE rhs', alpha=0.7)
    plt.plot(s, sturm_lhs, label='Sturm-Liouville lhs', alpha=0.7)
    plt.plot(s, sturm_rhs, '--', label='Sturm-Liouville rhs', alpha=0.7)
    plt.xlabel('normalized intrinsic coordinate s')
    plt.ylabel('operator response')
    plt.title('Stage-6L PDE analogue comparison')
    plt.legend(fontsize=8)
    plt.tight_layout()
    plt.savefig(path, dpi=180)
    plt.close()


def save_kernel_vs_green_plot(path: Path, empirical_K: np.ndarray, green_K: np.ndarray) -> None:
    fig = plt.figure(figsize=(10, 4))
    ax1 = fig.add_subplot(1, 2, 1)
    im1 = ax1.imshow(empirical_K, aspect='auto')
    ax1.set_title('Empirical Stage-6J kernel')
    plt.colorbar(im1, ax=ax1, fraction=0.046, pad=0.04)

    ax2 = fig.add_subplot(1, 2, 2)
    im2 = ax2.imshow(green_K, aspect='auto')
    ax2.set_title('Best Green surrogate')
    plt.colorbar(im2, ax=ax2, fraction=0.046, pad=0.04)

    plt.tight_layout()
    plt.savefig(path, dpi=180)
    plt.close(fig)


# -----------------------------------------------------------------------------
# Notes / summary writers
# -----------------------------------------------------------------------------

def write_notes(
    path: Path,
    summary: dict,
    best_u: ModeFitResult,
    best_v: ModeFitResult,
    operator_rows: List[OperatorFitRow],
    green_rows: List[OperatorFitRow],
    best_energy: Dict[str, float],
    selected_columns: Dict[str, str],
    scale_df: pd.DataFrame,
    cosmology_df: pd.DataFrame,
) -> None:
    best_operator = operator_rows[0]
    best_green = green_rows[0] if green_rows else None

    lines = []
    lines.append('============================================================')
    lines.append('STAGE-6L CONTINUUM NOTES')
    lines.append('Project: Quantum-Emergent Gravity')
    lines.append('============================================================')
    lines.append('')
    lines.append('UPSTREAM CONTEXT')
    lines.append('----------------')
    lines.append('Stage-6K reported a practically rank-1 operator with overwhelming first-mode dominance.')
    lines.append(f"Stage-6K energy rank-1: {summary.get('svd_summary', {}).get('energy_rank1', np.nan):.12g}")
    lines.append(f"Stage-6K singular gap s1/s2: {summary.get('svd_summary', {}).get('singular_value_gap_1_over_2', np.nan):.12g}")
    lines.append('')
    lines.append('RECOVERED FIELD COLUMNS')
    lines.append('-----------------------')
    for k, v in selected_columns.items():
        lines.append(f'{k}: {v}')
    lines.append('')
    lines.append('DOMINANT MODE FITS')
    lines.append('------------------')
    lines.append(f'u1 best family: {best_u.family} | R^2={best_u.score_r2:.6f} | corr={best_u.corr:.6f} | rmse={best_u.rmse:.6f}')
    lines.append(f'u1 parameters: {json.dumps({k: nan_to_none(v) for k, v in best_u.parameters.items()})}')
    lines.append(f'v1 best family: {best_v.family} | R^2={best_v.score_r2:.6f} | corr={best_v.corr:.6f} | rmse={best_v.rmse:.6f}')
    lines.append(f'v1 parameters: {json.dumps({k: nan_to_none(v) for k, v in best_v.parameters.items()})}')
    lines.append('')
    lines.append('DIFFERENTIAL OPERATOR TESTS')
    lines.append('---------------------------')
    for row in operator_rows:
        lines.append(f'{row.family}: R^2={row.r2:.6f} | corr={row.corr:.6f} | rmse={row.rmse:.6f} | params={json.dumps({k: nan_to_none(v) for k, v in row.parameters.items()})}')
    lines.append('')
    lines.append('GREEN-FUNCTION CONSISTENCY')
    lines.append('--------------------------')
    if best_green is not None:
        lines.append(f'Best Green surrogate: {best_green.family} | R^2={best_green.r2:.6f} | corr={best_green.corr:.6f} | rmse={best_green.rmse:.6f}')
        lines.append(f'Green parameters: {json.dumps({k: nan_to_none(v) for k, v in best_green.parameters.items()})}')
    else:
        lines.append('No Green surrogate comparison performed.')
    lines.append('')
    lines.append('WEAK-FORM / ENERGY TEST')
    lines.append('-----------------------')
    lines.append(f"best alpha={best_energy.get('alpha', np.nan):.6f} | beta={best_energy.get('beta', np.nan):.6f} | R^2={best_energy.get('r2', np.nan):.6f} | corr={best_energy.get('corr', np.nan):.6f} | rmse={best_energy.get('rmse', np.nan):.6f}")
    lines.append('')
    lines.append('SCALE EXTRACTION')
    lines.append('----------------')
    for _, row in scale_df.iterrows():
        lines.append(f"{row['scale_name']}: {row['value']} | {row['interpretation']}")
    lines.append('')
    lines.append('COSMOLOGY TRACK (EXPLORATORY ONLY)')
    lines.append('----------------------------------')
    if cosmology_df.empty:
        lines.append('No exploratory comparison rows available.')
    else:
        preview = cosmology_df.head(8)
        for _, row in preview.iterrows():
            lines.append(
                f"{row['stage_quantity']}={row['stage_value']:.6f} vs {row['reference_quantity']}={row['reference_value']:.6f} | gap={row['absolute_gap']:.6f}"
            )
        lines.append('These are dimensionless comparison prompts only and are not evidence of physical identification.')
    lines.append('')
    lines.append('INTERPRETIVE COMMENT')
    lines.append('--------------------')
    lines.append(f'Best PDE-family surrogate: {best_operator.family}.')
    if best_green is not None:
        lines.append(f'Best Green-kernel surrogate: {best_green.family}.')
    lines.append('Interpret conservatively: Stage-6L tests whether the rank-1 constitutive channel has a useful continuum analogue, not whether a definitive physical field equation has been proved.')
    lines.append('')
    lines.append('============================================================')
    lines.append('END OF STAGE-6L NOTES')
    lines.append('============================================================')

    path.write_text('\n'.join(lines), encoding='utf-8')


# -----------------------------------------------------------------------------
# Main workflow
# -----------------------------------------------------------------------------

def main() -> None:
    precheck_echo('Checking required files...')
    files = locate_stage6l_files()

    files.output_dir.mkdir(parents=True, exist_ok=True)
    precheck_echo(f'Project root: {files.project_root}')
    precheck_echo(f'Output dir  : {files.output_dir}')

    summary = read_json(files.stage6k_summary_json)
    profile_df = pd.read_csv(files.stage6k_profile_csv)
    singular_df = pd.read_csv(files.stage6k_singular_values_csv)
    rank_df = pd.read_csv(files.stage6k_rank_reconstruction_csv)

    if files.stage6j_kernel_csv is None or not Path(files.stage6j_kernel_csv).exists():
        raise FileNotFoundError(
            'Stage-6L requires the Stage-6J kernel matrix to recover u1(s), v1(s), and continuum surrogates.\n'
            'Expected file: metric_stage_6J_outputs/stage6J_kernel_matrix_best.csv'
        )

    if files.stage6h_profile_csv is None or not Path(files.stage6h_profile_csv).exists():
        raise FileNotFoundError(
            'Stage-6L preferably needs the Stage-6H distributional profile to recover kappa(s) and rho(s).\n'
            'Expected file: metric_stage_6H_outputs/stage6H_distributional_profile.csv'
        )

    K = load_kernel_matrix(Path(files.stage6j_kernel_csv))
    n_target, n_source = K.shape
    precheck_echo(f'Kernel shape: ({n_target}, {n_source})')

    target_length = infer_coarse_target_length(summary, (n_target, n_source))
    s, kappa, rho, stage6h_df_raw, selected_columns = load_stage6h_profile(Path(files.stage6h_profile_csv), target_length)
    if len(s) != n_target:
        warn_echo(
            f'Stage-6H profile length {len(s)} does not match kernel target size {n_target}. '
            'The script will continue by resampling the Stage-6H fields to the kernel size.'
        )
        s = np.linspace(0.0, 1.0, n_target)
        kappa = np.interp(s, np.linspace(0.0, 1.0, len(kappa)), kappa)
        rho = np.interp(s, np.linspace(0.0, 1.0, len(rho)), rho)

    # Recover singular modes directly from the kernel. This is the central Stage-6L move,
    # because Stage-6K summary tables contain only diagnostics, not the full sampled vectors.
    precheck_echo('Recovering dominant singular modes from Stage-6J kernel...')
    U, S, VT = np.linalg.svd(K, full_matrices=False)
    u1 = orient_mode(U[:, 0], prefer_negative_center=True)
    v1 = orient_mode(VT[0, :], prefer_negative_center=False)
    sigma1 = float(S[0])

    # Continuum fits for dominant modes.
    stage_echo('Fitting continuum families to dominant modes...')
    u_fit_results = fit_mode_families(s, u1, side='left_target')
    v_fit_results = fit_mode_families(np.linspace(0.0, 1.0, len(v1)), v1, side='right_source')
    if not u_fit_results or not v_fit_results:
        raise RuntimeError('Could not fit any continuum family to the dominant modes.')
    best_u = u_fit_results[0]
    best_v = v_fit_results[0]

    # Differential operator tests on the recovered kappa/rho fields.
    stage_echo('Running differential operator tests...')
    screened_row = fit_screened_response(s, kappa, rho)
    general_row = fit_general_linear_ode(s, kappa, rho)
    sturm_row = fit_sturm_liouville_like(s, kappa, rho)
    operator_rows = [screened_row, general_row, sturm_row]
    operator_rows.sort(key=lambda row: (-np.nan_to_num(row.r2, nan=-np.inf), np.nan_to_num(row.rmse, nan=np.inf)))

    # Green-function surrogate comparisons.
    stage_echo('Comparing empirical kernel against Green-function surrogates...')
    best_screened_for_green = next((r for r in operator_rows if r.family == 'screened_response'), screened_row)
    green_rows = compare_green_families(
        s_t=np.linspace(0.0, 1.0, n_target),
        s_s=np.linspace(0.0, 1.0, n_source),
        empirical_K=K,
        screened_L=float(best_screened_for_green.parameters.get('L', 0.15)),
    )

    # Weak-form / energy test.
    stage_echo('Running weak-form / energy test...')
    best_energy = weak_form_energy_scan(s, kappa, rho)

    # Scale extraction.
    stage_echo('Extracting characteristic scales...')
    scale_df = extract_scale_table(s, u1, v1, sigma1, best_screened_for_green, best_energy)
    cosmology_df = exploratory_cosmology_rows(scale_df)

    # Build output profile rows.
    stage_echo('Writing CSV/JSON/TXT outputs...')
    mode_fit_rows = []
    for res in u_fit_results[:5] + v_fit_results[:5]:
        row = {
            'section': 'mode_fit',
            'side': res.side,
            'family': res.family,
            'r2': res.score_r2,
            'corr': res.corr,
            'rmse': res.rmse,
        }
        row.update({f'param_{k}': v for k, v in res.parameters.items()})
        mode_fit_rows.append(row)

    operator_fit_rows = []
    for row in operator_rows:
        base = {
            'section': 'operator_fit',
            'family': row.family,
            'variant': row.variant,
            'r2': row.r2,
            'corr': row.corr,
            'rmse': row.rmse,
            'plausibility_comment': row.plausibility_comment,
        }
        base.update({f'param_{k}': v for k, v in row.parameters.items()})
        operator_fit_rows.append(base)

    green_fit_rows = []
    for row in green_rows:
        base = {
            'section': 'green_fit',
            'family': row.family,
            'variant': row.variant,
            'r2': row.r2,
            'corr': row.corr,
            'rmse': row.rmse,
            'plausibility_comment': row.plausibility_comment,
        }
        base.update({f'param_{k}': v for k, v in row.parameters.items()})
        green_fit_rows.append(base)

    continuum_profile = pd.DataFrame({
        's': s,
        'kappa': kappa,
        'rho': rho,
        'u1': u1,
        'v1_resampled_to_target_length': np.interp(s, np.linspace(0.0, 1.0, len(v1)), v1),
        'rho_prime': first_derivative(rho, s),
        'rho_second': second_derivative(rho, s),
    })

    operator_table = pd.DataFrame(mode_fit_rows + operator_fit_rows + green_fit_rows)

    # Summary JSON.
    best_operator = operator_rows[0]
    best_green = green_rows[0] if green_rows else None
    summary_out = {
        'script_version': 'Stage-6L_continuum_law_PDE_analogue_v1.py',
        'project_root': str(files.project_root),
        'output_dir': str(files.output_dir),
        'input_files': {
            'stage6k_summary_json': str(files.stage6k_summary_json),
            'stage6k_notes_txt': str(files.stage6k_notes_txt),
            'stage6k_profile_csv': str(files.stage6k_profile_csv),
            'stage6k_singular_values_csv': str(files.stage6k_singular_values_csv),
            'stage6k_rank_reconstruction_csv': str(files.stage6k_rank_reconstruction_csv),
            'stage6j_kernel_csv': str(files.stage6j_kernel_csv),
            'stage6h_profile_csv': str(files.stage6h_profile_csv),
        },
        'recovered_columns': selected_columns,
        'kernel_shape': {'n_target': int(n_target), 'n_source': int(n_source)},
        'dominant_mode': {
            'sigma1_recovered': sigma1,
            'stage6k_energy_rank1': nan_to_none(summary.get('svd_summary', {}).get('energy_rank1')),
            'stage6k_gap_1_over_2': nan_to_none(summary.get('svd_summary', {}).get('singular_value_gap_1_over_2')),
        },
        'best_mode_fit_u1': asdict(best_u),
        'best_mode_fit_v1': asdict(best_v),
        'operator_tests_ranked': [
            {
                'family': row.family,
                'variant': row.variant,
                'r2': nan_to_none(row.r2),
                'corr': nan_to_none(row.corr),
                'rmse': nan_to_none(row.rmse),
                'parameters': {k: nan_to_none(float(v)) for k, v in row.parameters.items()},
                'plausibility_comment': row.plausibility_comment,
            }
            for row in operator_rows
        ],
        'green_function_tests_ranked': [
            {
                'family': row.family,
                'variant': row.variant,
                'r2': nan_to_none(row.r2),
                'corr': nan_to_none(row.corr),
                'rmse': nan_to_none(row.rmse),
                'parameters': {k: nan_to_none(float(v)) for k, v in row.parameters.items()},
                'plausibility_comment': row.plausibility_comment,
            }
            for row in green_rows
        ],
        'weak_form_best': {k: nan_to_none(float(v)) if isinstance(v, (int, float, np.floating)) else v for k, v in best_energy.items()},
        'scale_summary': scale_df.to_dict(orient='records'),
        'cosmology_track_preview': cosmology_df.head(10).to_dict(orient='records'),
        'interpretation_verdict': 'B' if (best_operator.r2 > 0.5 or (best_green and best_green.r2 > 0.3)) else 'C',
        'interpretation_comment': (
            'Stage-6L found a useful continuum surrogate, but the result should still be read as an analogue rather than a proved field equation.'
            if (best_operator.r2 > 0.5 or (best_green and best_green.r2 > 0.3))
            else 'Stage-6L did not yet support a stable continuum closure beyond the compact low-rank law.'
        ),
    }

    # Output paths.
    continuum_profile_csv = files.output_dir / 'stage6L_continuum_profile.csv'
    summary_json = files.output_dir / 'stage6L_continuum_summary.json'
    notes_txt = files.output_dir / 'stage6L_continuum_notes.txt'
    operator_fit_csv = files.output_dir / 'stage6L_operator_fit_table.csv'
    scale_csv = files.output_dir / 'stage6L_scale_table.csv'
    cosmology_csv = files.output_dir / 'stage6L_cosmology_track.csv'

    mode_fit_png = files.output_dir / 'stage6L_mode_fit_plot.png'
    pde_fit_png = files.output_dir / 'stage6L_pde_fit_comparison.png'
    kernel_green_png = files.output_dir / 'stage6L_kernel_vs_green.png'

    continuum_profile.to_csv(continuum_profile_csv, index=False)
    with open(summary_json, 'w', encoding='utf-8') as f:
        json.dump(summary_out, f, indent=2, allow_nan=False)
    operator_table.to_csv(operator_fit_csv, index=False)
    scale_df.to_csv(scale_csv, index=False)
    cosmology_df.to_csv(cosmology_csv, index=False)

    write_notes(
        path=notes_txt,
        summary=summary,
        best_u=best_u,
        best_v=best_v,
        operator_rows=operator_rows,
        green_rows=green_rows,
        best_energy=best_energy,
        selected_columns=selected_columns,
        scale_df=scale_df,
        cosmology_df=cosmology_df,
    )

    # Figures.
    save_mode_fit_plot(mode_fit_png, s, u1, np.interp(s, np.linspace(0.0, 1.0, len(v1)), v1), best_u, best_v)
    save_pde_fit_plot(pde_fit_png, s, kappa, rho, screened_row, general_row, sturm_row)
    if green_rows:
        best_green_family = green_rows[0].family
        if best_green_family == 'green_screened':
            Kgreen = fit_kernel_amplitude(K, green_kernel_screened(np.linspace(0.0, 1.0, n_target), np.linspace(0.0, 1.0, n_source), best_screened_for_green.parameters['L']))[1]
        elif best_green_family == 'green_boundary_left':
            Kgreen = fit_kernel_amplitude(K, green_kernel_boundary_left(np.linspace(0.0, 1.0, n_target), np.linspace(0.0, 1.0, n_source), best_screened_for_green.parameters['L']))[1]
        else:
            Kgreen = fit_kernel_amplitude(K, green_kernel_gaussian(np.linspace(0.0, 1.0, n_target), np.linspace(0.0, 1.0, n_source), max(best_screened_for_green.parameters['L'], 0.05)))[1]
        save_kernel_vs_green_plot(kernel_green_png, K, Kgreen)

    stage_echo('Done.')
    stage_echo('Wrote:')
    stage_echo(f'  CSV : {continuum_profile_csv}')
    stage_echo(f'  JSON: {summary_json}')
    stage_echo(f'  TXT : {notes_txt}')
    stage_echo(f'  CSV : {operator_fit_csv}')
    stage_echo(f'  CSV : {scale_csv}')
    stage_echo(f'  CSV : {cosmology_csv}')
    stage_echo(f'  PNG : {mode_fit_png}')
    stage_echo(f'  PNG : {pde_fit_png}')
    stage_echo(f'  PNG : {kernel_green_png}')


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        echo('[Stage-6L ERROR] The script stopped with an exception.')
        echo(f'[Stage-6L ERROR] {type(exc).__name__}: {exc}')
        traceback.print_exc()
        raise
