from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


SCRIPT_VERSION = 'Stage-6K_canonical_operator_reduction_v1.py'
PROJECT_SENTINEL = '010-Quantum_Emergent_Gravity'
OUTPUT_DIRNAME = 'metric_stage_6K_outputs'


# -----------------------------
# Utility / console formatting
# -----------------------------

def log(msg: str) -> None:
    print(msg, flush=True)


def safe_float(x, default=np.nan):
    try:
        if pd.isna(x):
            return default
        return float(x)
    except Exception:
        return default


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


# -----------------------------
# Root / file discovery
# -----------------------------

def discover_project_root() -> Path:
    """
    Prefer the real project tree if present. Fall back to current file location
    or /mnt/data so the script remains testable from container contexts.
    """
    candidates: List[Path] = []

    cwd = Path.cwd().resolve()
    candidates.extend([cwd, *cwd.parents])

    try:
        script_path = Path(__file__).resolve()
        candidates.extend([script_path.parent, *script_path.parents])
    except Exception:
        pass

    home = Path.home()
    candidates.extend(home.glob(f'**/{PROJECT_SENTINEL}'))
    candidates.extend(Path('/mnt/data').glob(f'**/{PROJECT_SENTINEL}'))

    for cand in candidates:
        if cand.name == PROJECT_SENTINEL:
            return cand
        if (cand / OUTPUT_DIRNAME).exists():
            return cand
        if (cand / 'metric_stage_6J_outputs').exists():
            return cand

    return Path('/mnt/data').resolve()


def find_first_existing(paths: List[Path]) -> Optional[Path]:
    for p in paths:
        if p.exists():
            return p
    return None


def resolve_input_paths(project_root: Path) -> Dict[str, Path]:
    root_candidates = [project_root, Path('/mnt/data').resolve()]

    kernel_candidates = []
    transfer_candidates = []
    summary_candidates = []
    notes_candidates = []
    profile_candidates = []
    stage6h_candidates = []

    for root in root_candidates:
        kernel_candidates.extend([
            root / 'metric_stage_6J_outputs' / 'stage6J_kernel_matrix_best.csv',
            root / 'stage6J_kernel_matrix_best.csv',
        ])
        transfer_candidates.extend([
            root / 'metric_stage_6J_outputs' / 'stage6J_transfer_modes.csv',
            root / 'stage6J_transfer_modes.csv',
        ])
        summary_candidates.extend([
            root / 'metric_stage_6J_outputs' / 'stage6J_nonlocal_operator_summary.json',
            root / 'stage6J_nonlocal_operator_summary.json',
        ])
        notes_candidates.extend([
            root / 'metric_stage_6J_outputs' / 'stage6J_nonlocal_operator_notes.txt',
            root / 'stage6J_nonlocal_operator_notes.txt',
        ])
        profile_candidates.extend([
            root / 'metric_stage_6J_outputs' / 'stage6J_nonlocal_operator_profile.csv',
            root / 'stage6J_nonlocal_operator_profile.csv',
        ])
        stage6h_candidates.extend([
            root / 'metric_stage_6H_outputs' / 'stage6H_distributional_profile.csv',
            root / 'stage6H_distributional_profile.csv',
        ])

    paths = {
        'kernel_csv': find_first_existing(kernel_candidates),
        'transfer_csv': find_first_existing(transfer_candidates),
        'summary_json': find_first_existing(summary_candidates),
        'notes_txt': find_first_existing(notes_candidates),
        'profile_csv': find_first_existing(profile_candidates),
        'stage6h_csv': find_first_existing(stage6h_candidates),
    }

    missing = [k for k, v in paths.items() if k != 'stage6h_csv' and v is None]
    if missing:
        raise FileNotFoundError(f'Missing required Stage-6J inputs: {missing}')

    return paths


# -----------------------------
# Linear algebra / metrics
# -----------------------------

def compute_regression_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> Dict[str, float]:
    y_true = np.asarray(y_true, dtype=float).reshape(-1)
    y_pred = np.asarray(y_pred, dtype=float).reshape(-1)

    resid = y_true - y_pred
    rmse = float(np.sqrt(np.mean(resid ** 2)))
    ss_res = float(np.sum(resid ** 2))
    ss_tot = float(np.sum((y_true - np.mean(y_true)) ** 2))
    r2 = float(1.0 - ss_res / ss_tot) if ss_tot > 0 else np.nan

    if np.std(y_true) > 0 and np.std(y_pred) > 0:
        corr = float(np.corrcoef(y_true, y_pred)[0, 1])
    else:
        corr = np.nan

    return {'corr': corr, 'r2': r2, 'rmse': rmse}


def explained_energy_from_singular_values(s: np.ndarray) -> np.ndarray:
    energy = np.square(s)
    total = float(np.sum(energy))
    if total <= 0:
        return np.zeros_like(s)
    return energy / total


def numerical_rank(s: np.ndarray, rel_tol: float = 1e-9) -> int:
    if len(s) == 0:
        return 0
    thresh = rel_tol * float(np.max(s))
    return int(np.sum(s > thresh))


def reconstruct_rank_k(U: np.ndarray, s: np.ndarray, Vt: np.ndarray, k: int) -> np.ndarray:
    k = max(0, min(int(k), len(s)))
    if k == 0:
        return np.zeros((U.shape[0], Vt.shape[1]), dtype=float)
    return (U[:, :k] * s[:k]) @ Vt[:k, :]


def cosine_similarity(a: np.ndarray, b: np.ndarray) -> float:
    a = np.asarray(a, dtype=float).reshape(-1)
    b = np.asarray(b, dtype=float).reshape(-1)
    na = np.linalg.norm(a)
    nb = np.linalg.norm(b)
    if na == 0 or nb == 0:
        return np.nan
    return float(np.dot(a, b) / (na * nb))


def principal_angle_similarity(A: np.ndarray, B: np.ndarray, rank: int = 2) -> float:
    Ua, _, _ = np.linalg.svd(A, full_matrices=False)
    Ub, _, _ = np.linalg.svd(B, full_matrices=False)
    r = min(rank, Ua.shape[1], Ub.shape[1])
    if r <= 0:
        return np.nan
    M = Ua[:, :r].T @ Ub[:, :r]
    sv = np.linalg.svd(M, compute_uv=False)
    return float(np.mean(sv))


# -----------------------------
# Template matching
# -----------------------------

def second_difference(x: np.ndarray) -> np.ndarray:
    y = np.zeros_like(x)
    if len(x) >= 3:
        y[1:-1] = x[:-2] - 2.0 * x[1:-1] + x[2:]
        y[0] = y[1]
        y[-1] = y[-2]
    return y


def build_candidate_templates(n: int) -> Dict[str, np.ndarray]:
    x = np.linspace(0.0, 1.0, n)
    centered = x - 0.5

    templates = {
        'smooth_background': np.ones(n, dtype=float),
        'linear_gradient': centered,
        'boundary_loaded': np.abs(centered),
        'central_bump': np.exp(-0.5 * (centered / 0.18) ** 2),
        'screened_exponential': np.exp(-np.abs(centered) / 0.18),
        'cosine_mode_1': np.cos(np.pi * x),
        'cosine_mode_2': np.cos(2.0 * np.pi * x),
        'antisymmetric_shift': centered * np.exp(-0.5 * (centered / 0.22) ** 2),
        'derivative_like': np.gradient(np.exp(-0.5 * (centered / 0.18) ** 2)),
        'green_response_edge': 1.0 / np.sqrt(0.02 + np.abs(centered) + 0.05),
    }

    cleaned = {}
    for name, vec in templates.items():
        vec = np.asarray(vec, dtype=float)
        vec = vec - np.mean(vec)
        norm = np.linalg.norm(vec)
        cleaned[name] = vec / norm if norm > 0 else vec
    return cleaned


def best_template_match(vec: np.ndarray) -> Dict[str, float | str]:
    v = np.asarray(vec, dtype=float).reshape(-1)
    v = v - np.mean(v)
    nv = np.linalg.norm(v)
    if nv == 0:
        return {'best_template': 'degenerate', 'best_similarity': np.nan}
    v = v / nv

    templates = build_candidate_templates(len(v))
    best_name = None
    best_sim = -np.inf
    best_abs = -np.inf
    for name, tmpl in templates.items():
        sim = cosine_similarity(v, tmpl)
        abs_sim = abs(sim) if np.isfinite(sim) else -np.inf
        if abs_sim > best_abs:
            best_abs = abs_sim
            best_sim = sim
            best_name = name
    return {'best_template': best_name, 'best_similarity': float(best_sim)}


def qualitative_shape_label(vec: np.ndarray) -> str:
    v = np.asarray(vec, dtype=float).reshape(-1)
    if len(v) < 3:
        return 'undetermined'
    v0 = v - np.mean(v)
    if np.linalg.norm(v0) == 0:
        return 'degenerate'

    smoothness = np.linalg.norm(second_difference(v0)) / (np.linalg.norm(v0) + 1e-12)
    edge_mass = (
        np.sum(np.abs(v0[: max(1, len(v) // 8)]))
        + np.sum(np.abs(v0[-max(1, len(v) // 8):]))
    ) / (np.sum(np.abs(v0)) + 1e-12)
    mid = len(v) // 2
    central_mass = np.sum(np.abs(v0[max(0, mid - len(v) // 8): min(len(v), mid + len(v) // 8)])) / (
        np.sum(np.abs(v0)) + 1e-12
    )
    antisym = np.linalg.norm(v0 + v0[::-1]) / (np.linalg.norm(v0) + 1e-12)
    sym = np.linalg.norm(v0 - v0[::-1]) / (np.linalg.norm(v0) + 1e-12)
    zero_crossings = int(np.sum(np.signbit(v0[:-1]) != np.signbit(v0[1:])))

    if edge_mass > 0.30:
        return 'boundary_loaded'
    if central_mass > 0.28:
        return 'localized_bump'
    if antisym < 0.7:
        return 'antisymmetric_shift'
    if smoothness < 0.55 and zero_crossings <= 2:
        return 'smooth_background'
    if zero_crossings >= 3 or sym < 0.7:
        return 'oscillatory'
    return 'mixed'


# -----------------------------
# Optional Stage-6H recovery
# -----------------------------

def _pick_column(df: pd.DataFrame, names: List[str]) -> Optional[str]:
    for name in names:
        if name in df.columns:
            return name
    return None


def coarse_weighted_profile(df: pd.DataFrame, n_bins: int) -> Optional[Dict[str, np.ndarray]]:
    if df is None or df.empty or n_bins <= 1:
        return None

    s_col = _pick_column(df, ['s', 's_normalized'])
    kappa_col = _pick_column(df, ['kappa', 'abs_kappa'])
    rho_col = _pick_column(df, ['density', 'rho'])
    if s_col is None or kappa_col is None or rho_col is None:
        return None

    keep_cols = [s_col, kappa_col, rho_col] + ([c for c in ['ds'] if c in df.columns])
    work = df[keep_cols].copy()
    work = work.dropna(subset=[s_col, kappa_col, rho_col]).sort_values(s_col)
    if work.empty:
        return None

    w = work['ds'].to_numpy(dtype=float) if 'ds' in work.columns else np.ones(len(work), dtype=float)
    s = work[s_col].to_numpy(dtype=float)
    kappa = work[kappa_col].to_numpy(dtype=float)
    rho = work[rho_col].to_numpy(dtype=float)

    smin = float(np.min(s))
    smax = float(np.max(s))
    if smax <= smin:
        return None
    sn = (s - smin) / (smax - smin)
    edges = np.linspace(0.0, 1.0, n_bins + 1)
    bins = np.clip(np.digitize(sn, edges[1:-1], right=False), 0, n_bins - 1)

    out_k = np.zeros(n_bins, dtype=float)
    out_r = np.zeros(n_bins, dtype=float)
    out_s = np.zeros(n_bins, dtype=float)
    counts = np.zeros(n_bins, dtype=int)
    wsum = np.zeros(n_bins, dtype=float)

    for i in range(n_bins):
        m = bins == i
        if not np.any(m):
            out_k[i] = np.nan
            out_r[i] = np.nan
            out_s[i] = 0.5 * (edges[i] + edges[i + 1])
            continue
        wi = w[m]
        wi_sum = float(np.sum(wi))
        if wi_sum <= 0:
            wi = np.ones(np.sum(m), dtype=float)
            wi_sum = float(np.sum(wi))
        out_k[i] = float(np.sum(wi * kappa[m]) / wi_sum)
        out_r[i] = float(np.sum(wi * rho[m]) / wi_sum)
        out_s[i] = float(np.sum(wi * sn[m]) / wi_sum)
        counts[i] = int(np.sum(m))
        wsum[i] = wi_sum

    for arr in [out_k, out_r]:
        if np.any(~np.isfinite(arr)):
            idx = np.arange(len(arr))
            good = np.isfinite(arr)
            if np.sum(good) >= 2:
                arr[~good] = np.interp(idx[~good], idx[good], arr[good])
            elif np.sum(good) == 1:
                arr[~good] = arr[good][0]
            else:
                return None

    return {
        's': out_s,
        'kappa': out_k,
        'rho': out_r,
        'counts': counts,
        'weight_sum': wsum,
    }


# -----------------------------
# Optional scale stability from full Stage-6J profile
# -----------------------------

def maybe_build_scale_stability(profile_df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    if profile_df is None or profile_df.empty:
        return pd.DataFrame(columns=['variant_name', 'method_family', 'score', 'r2', 'matrix_rank'])

    target_methods = ['free_kernel', 'shifted_convolution', 'mode_transfer', 'propagator']
    work = profile_df.copy()
    work = work[work['method_family'].isin(target_methods)]
    if work.empty:
        return pd.DataFrame(columns=['variant_name', 'method_family', 'score', 'r2', 'matrix_rank'])

    for (variant_name, method_family), g in work.groupby(['variant_name', 'method_family'], dropna=False):
        best = g.sort_values('score', ascending=False).iloc[0]
        rows.append({
            'variant_name': variant_name,
            'method_family': method_family,
            'direction': best.get('direction', np.nan),
            'score': safe_float(best.get('score', np.nan)),
            'r2': safe_float(best.get('r2', np.nan)),
            'corr_pred_target': safe_float(best.get('corr_pred_target', np.nan)),
            'matrix_rank': safe_float(best.get('matrix_rank', np.nan)),
            'rank': safe_float(best.get('rank', np.nan)),
            'effective_bandwidth': safe_float(best.get('effective_bandwidth', np.nan)),
        })

    return pd.DataFrame(rows)


# -----------------------------
# Main analysis
# -----------------------------

def main() -> None:
    log('[Stage-6K PRECHECK] Discovering project root...')
    project_root = discover_project_root()
    output_dir = project_root / OUTPUT_DIRNAME
    ensure_dir(output_dir)

    log(f'[Stage-6K PRECHECK] Project root: {project_root}')
    log(f'[Stage-6K PRECHECK] Output dir  : {output_dir}')
    log(f'[Stage-6K PRECHECK] Python      : {sys.executable}')

    paths = resolve_input_paths(project_root)
    for key, path in paths.items():
        log(f'[Stage-6K PRECHECK] {key}: {path}')

    with open(paths['summary_json'], 'r', encoding='utf-8') as f:
        summary = json.load(f)
    with open(paths['notes_txt'], 'r', encoding='utf-8') as f:
        notes_text = f.read()

    profile_df = pd.read_csv(paths['profile_csv'])
    kernel_df_raw = pd.read_csv(paths['kernel_csv'])
    transfer_df = pd.read_csv(paths['transfer_csv'])

    if set(['source_index', 'target_index', 'kernel_weight']).issubset(kernel_df_raw.columns):
        kernel_mat = (
            kernel_df_raw
            .pivot(index='target_index', columns='source_index', values='kernel_weight')
            .sort_index()
            .sort_index(axis=1)
        )
    else:
        kernel_mat = kernel_df_raw.copy()
        try:
            kernel_mat.columns = [int(float(c)) for c in kernel_mat.columns]
            kernel_mat = kernel_mat.sort_index(axis=1)
        except Exception:
            pass

    G = kernel_mat.to_numpy(dtype=float)
    n_target, n_source = G.shape

    log(f'[Stage-6K DATA] Kernel shape: {G.shape}')
    log(f'[Stage-6K DATA] Transfer rows: {len(transfer_df)}')
    log(f'[Stage-6K DATA] Profile rows: {len(profile_df)}')

    fk = profile_df[profile_df['method_family'] == 'free_kernel'].copy()
    if not fk.empty and 'score' in fk.columns:
        best_fk = fk.sort_values('score', ascending=False).iloc[0].to_dict()
    else:
        best_fk = {}

    U, s, Vt = np.linalg.svd(G, full_matrices=False)
    energy_ratio = explained_energy_from_singular_values(s)
    cumulative_energy = np.cumsum(energy_ratio)
    num_rank = numerical_rank(s)
    gap12 = float(s[0] / s[1]) if len(s) > 1 and s[1] > 0 else np.nan
    gap23 = float(s[1] / s[2]) if len(s) > 2 and s[2] > 0 else np.nan
    gap34 = float(s[2] / s[3]) if len(s) > 3 and s[3] > 0 else np.nan

    singular_df = pd.DataFrame({
        'mode_index': np.arange(len(s), dtype=int) + 1,
        'singular_value': s,
        'energy_ratio': energy_ratio,
        'cumulative_energy_ratio': cumulative_energy,
    })
    singular_df.to_csv(output_dir / 'stage6K_singular_values.csv', index=False)

    recon_rows = []
    source_vec = None
    target_vec = None
    stage6h_recovery = None

    if paths['stage6h_csv'] is not None and paths['stage6h_csv'].exists():
        try:
            stage6h_df = pd.read_csv(paths['stage6h_csv'])
            stage6h_recovery = coarse_weighted_profile(stage6h_df, n_bins=n_source)
            if stage6h_recovery is not None and len(stage6h_recovery['kappa']) == n_source and len(stage6h_recovery['rho']) == n_target:
                source_vec = stage6h_recovery['kappa']
                target_vec = stage6h_recovery['rho']
                log(f'[Stage-6K DATA] Recovered coarse Stage-6H vectors at n_bins={n_source}.')
        except Exception as exc:
            log(f'[Stage-6K WARN] Failed Stage-6H recovery: {exc}')

    if (source_vec is None or target_vec is None) and (not transfer_df.empty):
        mask = (
            transfer_df['variant_name'].astype(str).eq('coarse:24')
            & transfer_df['direction'].astype(str).eq('kappa_to_rho')
        )
        candidate = transfer_df.loc[mask].copy()
        if candidate.empty:
            candidate = transfer_df.copy()
        candidate = candidate.sort_values('mode_index')
        if len(candidate) >= min(n_source, n_target):
            source_vec = candidate['source_coef'].to_numpy(dtype=float)[:n_source]
            target_vec = candidate['target_coef'].to_numpy(dtype=float)[:n_target]
            log('[Stage-6K DATA] Using transfer-mode table as dimensional fallback for reconstruction.')

    if source_vec is None or target_vec is None:
        log('[Stage-6K WARN] Source/target vectors unavailable; reconstruction metrics will be NaN unless Stage-6H exists in the project tree.')

    for rank_k in [1, 2, 3]:
        Gk = reconstruct_rank_k(U, s, Vt, rank_k)
        if source_vec is not None and target_vec is not None:
            pred = Gk @ source_vec
            metrics = compute_regression_metrics(target_vec, pred)
        else:
            pred = np.full(n_target, np.nan)
            metrics = {'corr': np.nan, 'r2': np.nan, 'rmse': np.nan}

        recon_rows.append({
            'rank_k': rank_k,
            'corr_pred_target': metrics['corr'],
            'r2': metrics['r2'],
            'rmse': metrics['rmse'],
            'frobenius_fraction_retained': float(np.sqrt(np.sum(np.square(s[:rank_k])) / np.sum(np.square(s)))) if np.sum(np.square(s)) > 0 else np.nan,
            'operator_relative_error_fro': float(np.linalg.norm(G - Gk, ord='fro') / (np.linalg.norm(G, ord='fro') + 1e-12)),
        })

    recon_df = pd.DataFrame(recon_rows)
    recon_df.to_csv(output_dir / 'stage6K_rank_reconstruction_table.csv', index=False)

    profile_rows = []
    n_modes_save = min(3, len(s))
    for j in range(n_modes_save):
        left = U[:, j]
        right = Vt[j, :]
        left_match = best_template_match(left)
        right_match = best_template_match(right)
        profile_rows.append({
            'side': 'left_target',
            'mode_index': j + 1,
            'singular_value': float(s[j]),
            'energy_ratio': float(energy_ratio[j]),
            'qualitative_shape': qualitative_shape_label(left),
            'best_template': left_match['best_template'],
            'best_template_similarity': left_match['best_similarity'],
            'l2_norm': float(np.linalg.norm(left)),
            'mean': float(np.mean(left)),
            'std': float(np.std(left)),
        })
        profile_rows.append({
            'side': 'right_source',
            'mode_index': j + 1,
            'singular_value': float(s[j]),
            'energy_ratio': float(energy_ratio[j]),
            'qualitative_shape': qualitative_shape_label(right),
            'best_template': right_match['best_template'],
            'best_template_similarity': right_match['best_similarity'],
            'l2_norm': float(np.linalg.norm(right)),
            'mean': float(np.mean(right)),
            'std': float(np.std(right)),
        })
    canonical_profile_df = pd.DataFrame(profile_rows)
    canonical_profile_df.to_csv(output_dir / 'stage6K_canonical_operator_profile.csv', index=False)

    stability_df = maybe_build_scale_stability(profile_df)

    closure_rows = []
    if source_vec is not None and target_vec is not None:
        for rank_k in [1, 2]:
            Gk = reconstruct_rank_k(U, s, Vt, rank_k)
            pred = Gk @ source_vec
            metrics = compute_regression_metrics(target_vec, pred)
            contributions = []
            for j in range(rank_k):
                proj = float(np.dot(Vt[j, :], source_vec))
                amp = float(s[j] * proj)
                contributions.append(amp)
            closure_rows.append({
                'rank_k': rank_k,
                'corr_pred_target': metrics['corr'],
                'r2': metrics['r2'],
                'rmse': metrics['rmse'],
                'mode_1_amplitude': contributions[0] if len(contributions) >= 1 else np.nan,
                'mode_2_amplitude': contributions[1] if len(contributions) >= 2 else np.nan,
            })
    closure_df = pd.DataFrame(closure_rows)

    rank2_row = recon_df.loc[recon_df['rank_k'] == 2]
    rank2_r2 = safe_float(rank2_row['r2'].iloc[0]) if not rank2_row.empty else np.nan
    first_two_energy = float(np.sum(energy_ratio[:2])) if len(energy_ratio) >= 2 else float(np.sum(energy_ratio))
    first_one_energy = float(np.sum(energy_ratio[:1])) if len(energy_ratio) >= 1 else np.nan
    interpretable_count = int(np.sum(canonical_profile_df['qualitative_shape'].isin([
        'smooth_background', 'localized_bump', 'antisymmetric_shift', 'boundary_loaded'
    ]))) if not canonical_profile_df.empty else 0

    if np.isfinite(rank2_r2) and rank2_r2 >= 0.95 and first_two_energy >= 0.95:
        interpretation_verdict = 'A'
    elif first_two_energy >= 0.90:
        interpretation_verdict = 'B'
    elif num_rank <= 5:
        interpretation_verdict = 'C'
    else:
        interpretation_verdict = 'D'

    summary_out = {
        'script_version': SCRIPT_VERSION,
        'project_root': str(project_root),
        'output_dir': str(output_dir),
        'input_files': {k: (str(v) if v is not None else None) for k, v in paths.items()},
        'stage6h_recovery_used': bool(source_vec is not None and target_vec is not None and paths['stage6h_csv'] is not None),
        'upstream_stage6j_context': {
            'preferred_direction': summary.get('directionality', {}).get('preferred_direction', 'kappa_to_rho') if isinstance(summary.get('directionality'), dict) else 'kappa_to_rho',
            'best_free_kernel_profile_row': best_fk,
        },
        'kernel_shape': {'n_target': int(n_target), 'n_source': int(n_source)},
        'svd_summary': {
            'numerical_rank_rel_tol_1e-9': int(num_rank),
            'singular_value_gap_1_over_2': gap12,
            'singular_value_gap_2_over_3': gap23,
            'singular_value_gap_3_over_4': gap34,
            'energy_rank1': first_one_energy,
            'energy_rank2': first_two_energy,
            'energy_rank3': float(np.sum(energy_ratio[:3])) if len(energy_ratio) >= 3 else float(np.sum(energy_ratio)),
        },
        'reconstruction_summary': {
            'rank1': recon_df.loc[recon_df['rank_k'] == 1].iloc[0].to_dict() if (recon_df['rank_k'] == 1).any() else {},
            'rank2': recon_df.loc[recon_df['rank_k'] == 2].iloc[0].to_dict() if (recon_df['rank_k'] == 2).any() else {},
            'rank3': recon_df.loc[recon_df['rank_k'] == 3].iloc[0].to_dict() if (recon_df['rank_k'] == 3).any() else {},
        },
        'basis_interpretation_summary': {
            'interpretable_mode_count_among_saved_profiles': interpretable_count,
            'saved_mode_count': int(n_modes_save),
        },
        'scale_stability_summary': {
            'n_variant_method_rows': int(len(stability_df)),
            'variant_names_seen': sorted(stability_df['variant_name'].dropna().astype(str).unique().tolist()) if not stability_df.empty else [],
            'mean_best_score_across_variant_method_rows': float(stability_df['score'].mean()) if not stability_df.empty else np.nan,
        },
        'physical_closure_test': closure_df.to_dict(orient='records'),
        'interpretation_verdict': interpretation_verdict,
        'success_flags': {
            'rank2_reproduces_nearly_all_fit': bool(np.isfinite(rank2_r2) and rank2_r2 >= 0.95),
            'rank2_energy_dominant': bool(first_two_energy >= 0.95),
            'clear_first_modes': bool((np.isfinite(gap23) and gap23 >= 3.0) or first_two_energy >= 0.95),
            'dominant_modes_interpretable': bool(interpretable_count >= 2),
        },
    }

    with open(output_dir / 'stage6K_canonical_operator_summary.json', 'w', encoding='utf-8') as f:
        json.dump(summary_out, f, indent=2)

    lines = []
    lines.append('============================================================')
    lines.append('STAGE-6K CANONICAL OPERATOR NOTES')
    lines.append('Project: Quantum-Emergent Gravity')
    lines.append('============================================================')
    lines.append('')
    lines.append('UPSTREAM INPUT')
    lines.append('--------------')
    lines.append('Stage-6J supplies a best free-kernel operator with preferred')
    lines.append('direction kappa_to_rho and strong coarse-scale performance.')
    lines.append('')
    lines.append('SVD SUMMARY')
    lines.append('-----------')
    lines.append(f'numerical_rank(rel_tol=1e-9): {num_rank}')
    lines.append(f'energy rank-1: {first_one_energy:.6f}')
    lines.append(f'energy rank-2: {first_two_energy:.6f}')
    lines.append(f'singular gap s1/s2: {gap12:.6f}' if np.isfinite(gap12) else 'singular gap s1/s2: NaN')
    lines.append(f'singular gap s2/s3: {gap23:.6f}' if np.isfinite(gap23) else 'singular gap s2/s3: NaN')
    lines.append('')
    lines.append('RECONSTRUCTION CASCADE')
    lines.append('----------------------')
    for _, row in recon_df.iterrows():
        lines.append(
            f"rank={int(row['rank_k'])} | corr={row['corr_pred_target']:.6f} | "
            f"r2={row['r2']:.6f} | rmse={row['rmse']:.6f} | "
            f"fro_retained={row['frobenius_fraction_retained']:.6f}"
        )
    lines.append('')
    lines.append('DOMINANT MODE INTERPRETATION')
    lines.append('----------------------------')
    for _, row in canonical_profile_df.iterrows():
        lines.append(
            f"{row['side']} mode {int(row['mode_index'])}: "
            f"shape={row['qualitative_shape']} | "
            f"template={row['best_template']} | "
            f"template_similarity={row['best_template_similarity']:.6f}"
        )
    lines.append('')
    lines.append('PHYSICAL CLOSURE TEST')
    lines.append('---------------------')
    if closure_df.empty:
        lines.append('Closure metrics unavailable because source/target vectors were not recoverable.')
    else:
        for _, row in closure_df.iterrows():
            lines.append(
                f"rank={int(row['rank_k'])} | corr={row['corr_pred_target']:.6f} | "
                f"r2={row['r2']:.6f} | rmse={row['rmse']:.6f} | "
                f"a1={row.get('mode_1_amplitude', np.nan):.6f} | "
                f"a2={row.get('mode_2_amplitude', np.nan):.6f}"
            )
    lines.append('')
    lines.append('INTERPRETATION')
    lines.append('--------------')
    if interpretation_verdict == 'A':
        lines.append('A : compact emergent constitutive law exists')
    elif interpretation_verdict == 'B':
        lines.append('B : low-rank empirical relation exists but lacks full interpretation')
    elif interpretation_verdict == 'C':
        lines.append('C : operator real but basis unstable / partially diffuse')
    else:
        lines.append('D : Stage-6J fit appears too flexible to canonicalize cleanly')
    lines.append('')
    lines.append('CANDIDATE REDUCED LAW')
    lines.append('---------------------')
    lines.append('rho(s) ≈ s1 u1(s)<v1,kappa> + s2 u2(s)<v2,kappa>')
    lines.append('with rank-1 / rank-2 / rank-3 cascade tested explicitly.')
    lines.append('')
    lines.append('============================================================')
    lines.append('END OF STAGE-6K NOTES')
    lines.append('============================================================')

    with open(output_dir / 'stage6K_canonical_operator_notes.txt', 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines) + '\n')

    plt.figure(figsize=(8, 5))
    plt.plot(np.arange(1, len(s) + 1), s, marker='o')
    plt.xlabel('mode index')
    plt.ylabel('singular value')
    plt.title('Stage-6K singular spectrum')
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(output_dir / 'stage6K_spectrum_plot.png', dpi=160)
    plt.close()

    fig, axes = plt.subplots(2, 2, figsize=(10, 7), sharex=False)
    plot_modes = min(2, len(s))
    x_t = np.arange(n_target)
    x_s = np.arange(n_source)
    for j in range(plot_modes):
        axes[j, 0].plot(x_t, U[:, j], marker='o', markersize=3)
        axes[j, 0].set_title(f'left mode u{j+1}')
        axes[j, 0].set_xlabel('target index')
        axes[j, 0].set_ylabel('amplitude')
        axes[j, 0].grid(True, alpha=0.25)

        axes[j, 1].plot(x_s, Vt[j, :], marker='o', markersize=3)
        axes[j, 1].set_title(f'right mode v{j+1}')
        axes[j, 1].set_xlabel('source index')
        axes[j, 1].set_ylabel('amplitude')
        axes[j, 1].grid(True, alpha=0.25)
    plt.tight_layout()
    plt.savefig(output_dir / 'stage6K_mode_shapes.png', dpi=160)
    plt.close(fig)

    if source_vec is not None and target_vec is not None:
        plt.figure(figsize=(8, 5))
        plt.plot(np.arange(n_target), target_vec, marker='s', label='target')
        for rank_k in [1, 2, 3]:
            Gk = reconstruct_rank_k(U, s, Vt, rank_k)
            pred = Gk @ source_vec
            plt.plot(np.arange(n_target), pred, marker='o', label=f'pred rank {rank_k}')
        plt.xlabel('target mode index')
        plt.ylabel('coefficient')
        plt.title('Stage-6K rank reconstruction comparison')
        plt.legend()
        plt.grid(True, alpha=0.25)
        plt.tight_layout()
        plt.savefig(output_dir / 'stage6K_rank_fit_comparison.png', dpi=160)
        plt.close()

    log('[Stage-6K DONE] Wrote:')
    for name in [
        'stage6K_canonical_operator_profile.csv',
        'stage6K_canonical_operator_summary.json',
        'stage6K_canonical_operator_notes.txt',
        'stage6K_singular_values.csv',
        'stage6K_rank_reconstruction_table.csv',
        'stage6K_spectrum_plot.png',
        'stage6K_mode_shapes.png',
        'stage6K_rank_fit_comparison.png',
    ]:
        out_path = output_dir / name
        if out_path.exists():
            log(f'  - {out_path}')


if __name__ == '__main__':
    main()

