#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Stage-6J_intrinsic_nonlocal_response_geometry_v1.py
April 17, 2026
Author: Arturo Ortiz-Tapia

Quantum-Emergent Gravity
Stage-6J: Intrinsic Nonlocal Response Geometry

Purpose
-------
Move beyond Stage-6I local / lagged diagnostics and test whether the
curvature-like field and density-like field are coupled through a stable
intrinsic nonlocal operator.

This script is written to be Spyder-friendly and self-contained at the
contract level. It expects the frozen Stage-6H and Stage-6I files, but it is
also conservative: if some optional columns are absent, it falls back to the
required contract only.

Main outputs
------------
metric_stage_6J_outputs/
    stage6J_nonlocal_operator_profile.csv
    stage6J_nonlocal_operator_summary.json
    stage6J_nonlocal_operator_notes.txt
    stage6J_kernel_matrix_best.csv
    stage6J_transfer_modes.csv
    stage6J_best_kernel_heatmap.png
    stage6J_mode_transfer_plot.png

Method families implemented
---------------------------
1) Shifted convolutional response
2) Free kernel inversion under constrained families
3) Mode-space transfer function
4) Green-function / propagator fitting
5) Directionality comparison
6) Multi-scale robustness over smoothing / coarse / trimmed variants

Design philosophy
-----------------
- Favor stability and interpretability over overfitting.
- Use Stage-6I as a prior, not as a hard constraint.
- Keep matrix problems low-dimensional enough to remain numerically sane.
- Record failures instead of hiding them.
"""

from __future__ import annotations

import json
import math
import sys
import traceback
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Any

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

try:
    from scipy.ndimage import gaussian_filter1d
    from scipy.signal import fftconvolve
    SCIPY_AVAILABLE = True
except Exception:
    SCIPY_AVAILABLE = False
    gaussian_filter1d = None
    fftconvolve = None


# -----------------------------------------------------------------------------
# Configuration defaults
# -----------------------------------------------------------------------------
SCRIPT_VERSION = "Stage-6J_intrinsic_nonlocal_response_geometry_v1.py"
PROJECT_DIR_NAME = "010-Quantum_Emergent_Gravity"
OUTPUT_DIR_NAME = "metric_stage_6J_outputs"

DEFAULT_SMOOTHING_VARIANTS = [
    {"kind": "raw", "param": 0},
    {"kind": "moving_average", "param": 5},
    {"kind": "moving_average", "param": 11},
    {"kind": "gaussian", "param": 2.0},
    {"kind": "gaussian", "param": 5.0},
]
DEFAULT_COARSE_BIN_COUNTS = [24, 48, 96]
DEFAULT_MAX_ABS_LAG = 0.25
DEFAULT_N_LAG_STEPS = 161
DEFAULT_KERNEL_BANDWIDTHS = [0.01, 0.02, 0.04, 0.06, 0.08, 0.12, 0.16, 0.24]
DEFAULT_RIDGE_ALPHAS = [1e-6, 1e-4, 1e-2, 1e-1, 1.0, 10.0]
DEFAULT_TRIM_Q = 0.02
DEFAULT_LOW_MODE_COUNT = 12
DEFAULT_MATRIX_SAMPLE_SIZE = 96
DEFAULT_FREEKERNEL_BANDWIDTHS = [0.03, 0.06, 0.10, 0.16, 0.24, 0.36]
DEFAULT_PROPAGATOR_LENGTHS = [0.02, 0.04, 0.08, 0.12, 0.18, 0.28]
DEFAULT_ADVECTION_SHIFTS = [-0.25, -0.1875, -0.125, -0.0625, 0.0, 0.0625, 0.125, 0.1875, 0.25]
DEFAULT_POWERS = [0.5, 1.0, 1.5, 2.0]
DEFAULT_TRUNC_BANDS = [0.08, 0.14, 0.22, 0.32]

np.set_printoptions(suppress=True, precision=6)


# -----------------------------------------------------------------------------
# Small utilities
# -----------------------------------------------------------------------------
def log(msg: str) -> None:
    print(msg, flush=True)


def ensure_odd(n: int) -> int:
    n = int(max(1, n))
    return n if n % 2 == 1 else n + 1


def safe_float(x: Any, default: float = float("nan")) -> float:
    try:
        return float(x)
    except Exception:
        return default


def json_ready(obj: Any) -> Any:
    if isinstance(obj, dict):
        return {str(k): json_ready(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [json_ready(v) for v in obj]
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, (np.floating, np.integer)):
        return obj.item()
    return obj


def nan_corr(x: np.ndarray, y: np.ndarray) -> float:
    mask = np.isfinite(x) & np.isfinite(y)
    if mask.sum() < 3:
        return float("nan")
    x0 = x[mask]
    y0 = y[mask]
    sx = np.std(x0)
    sy = np.std(y0)
    if sx <= 0 or sy <= 0:
        return float("nan")
    return float(np.corrcoef(x0, y0)[0, 1])


def r2_score_manual(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    mask = np.isfinite(y_true) & np.isfinite(y_pred)
    if mask.sum() < 3:
        return float("nan")
    yt = y_true[mask]
    yp = y_pred[mask]
    ss_res = float(np.sum((yt - yp) ** 2))
    ss_tot = float(np.sum((yt - np.mean(yt)) ** 2))
    if ss_tot <= 0:
        return float("nan")
    return 1.0 - ss_res / ss_tot


def l2_rmse(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    mask = np.isfinite(y_true) & np.isfinite(y_pred)
    if mask.sum() == 0:
        return float("nan")
    return float(np.sqrt(np.mean((y_true[mask] - y_pred[mask]) ** 2)))


def approx_w1_1d(x: np.ndarray, y: np.ndarray, grid: np.ndarray) -> float:
    """Approximate 1D Wasserstein-1 on a common grid via CDF L1 distance."""
    x0 = np.clip(np.asarray(x, dtype=float), 0.0, None)
    y0 = np.clip(np.asarray(y, dtype=float), 0.0, None)
    if np.sum(x0) <= 0 or np.sum(y0) <= 0:
        return float("nan")
    px = x0 / np.sum(x0)
    py = y0 / np.sum(y0)
    cdf_x = np.cumsum(px)
    cdf_y = np.cumsum(py)
    ds = np.diff(grid, prepend=grid[0])
    return float(np.sum(np.abs(cdf_x - cdf_y) * np.abs(ds)))


def js_distance_1d(x: np.ndarray, y: np.ndarray) -> float:
    eps = 1e-12
    x0 = np.clip(np.asarray(x, dtype=float), 0.0, None)
    y0 = np.clip(np.asarray(y, dtype=float), 0.0, None)
    if np.sum(x0) <= 0 or np.sum(y0) <= 0:
        return float("nan")
    p = x0 / np.sum(x0)
    q = y0 / np.sum(y0)
    m = 0.5 * (p + q)

    def kl(a: np.ndarray, b: np.ndarray) -> float:
        mask = a > 0
        return float(np.sum(a[mask] * np.log((a[mask] + eps) / (b[mask] + eps))))

    return float(np.sqrt(0.5 * kl(p, m) + 0.5 * kl(q, m)))


def moving_average(x: np.ndarray, window: int) -> np.ndarray:
    window = ensure_odd(window)
    if window <= 1:
        return x.copy()
    kernel = np.ones(window, dtype=float) / window
    return np.convolve(x, kernel, mode="same")


def smooth_series(x: np.ndarray, kind: str, param: float) -> np.ndarray:
    if kind == "raw" or param in (0, 0.0, None):
        return x.copy()
    if kind == "moving_average":
        return moving_average(x, int(param))
    if kind == "gaussian":
        if SCIPY_AVAILABLE and gaussian_filter1d is not None:
            return gaussian_filter1d(x, sigma=float(param), mode="nearest")
        # Fallback Gaussian-like smoothing using a manually built kernel
        sigma = max(1e-6, float(param))
        radius = max(2, int(round(4 * sigma)))
        grid = np.arange(-radius, radius + 1, dtype=float)
        kernel = np.exp(-0.5 * (grid / sigma) ** 2)
        kernel /= np.sum(kernel)
        return np.convolve(x, kernel, mode="same")
    raise ValueError(f"Unsupported smoothing kind: {kind}")


def interp_shift(s: np.ndarray, x: np.ndarray, shift: float) -> np.ndarray:
    """Return x(s-shift) sampled back on s."""
    return np.interp(s - shift, s, x, left=x[0], right=x[-1])


def normalized_kernel(dist: np.ndarray, family: str, bandwidth: float, power: float = 1.0, shift: float = 0.0) -> np.ndarray:
    bw = max(1e-8, float(bandwidth))
    z = (dist - shift) / bw
    az = np.abs(z)
    if family == "gaussian":
        w = np.exp(-0.5 * z ** 2)
    elif family == "exponential":
        w = np.exp(-az)
    elif family == "compact_support":
        w = np.where(az <= 1.0, 1.0 - az, 0.0)
    elif family == "power_law_tail":
        w = 1.0 / (1.0 + az ** max(0.25, power))
    elif family == "screened_poisson":
        w = np.exp(-az) / (2.0 * bw)
    elif family == "fractional":
        w = 1.0 / ((1.0 + az) ** (1.0 + max(0.1, power)))
    elif family == "advection_diffusion":
        w = np.exp(-0.5 * z ** 2)
        w *= np.where(dist >= shift, 1.0, 0.35)
    else:
        raise ValueError(f"Unknown kernel family: {family}")
    total = float(np.sum(w))
    if total <= 0 or not np.isfinite(total):
        return np.zeros_like(w)
    return w / total


def convolution_predict(s: np.ndarray, source: np.ndarray, family: str, bandwidth: float, lag: float = 0.0, power: float = 1.0) -> np.ndarray:
    source_shifted = interp_shift(s, source, lag)
    n = len(s)
    dist_mat = s[:, None] - s[None, :]
    K = normalized_kernel(dist_mat, family=family, bandwidth=bandwidth, power=power)
    pred_base = K @ source_shifted
    return pred_base


def fit_affine(y: np.ndarray, x: np.ndarray) -> Tuple[float, float, np.ndarray]:
    mask = np.isfinite(y) & np.isfinite(x)
    if mask.sum() < 3:
        return float("nan"), float("nan"), np.full_like(y, np.nan)
    X = np.column_stack([np.ones(mask.sum()), x[mask]])
    beta, *_ = np.linalg.lstsq(X, y[mask], rcond=None)
    intercept, scale = float(beta[0]), float(beta[1])
    pred = intercept + scale * x
    return intercept, scale, pred


def effective_bandwidth_from_matrix(K: np.ndarray, s: np.ndarray, energy_q: float = 0.9) -> float:
    dist = np.abs(s[:, None] - s[None, :])
    weights = np.abs(K)
    tot = float(np.sum(weights))
    if tot <= 0:
        return float("nan")
    order = np.argsort(dist.ravel())
    d = dist.ravel()[order]
    w = weights.ravel()[order]
    cw = np.cumsum(w) / tot
    idx = int(np.searchsorted(cw, energy_q, side="left"))
    idx = min(idx, len(d) - 1)
    return float(d[idx])


def symmetry_score(K: np.ndarray) -> float:
    den = float(np.linalg.norm(K) + 1e-12)
    return float(np.linalg.norm(K - K.T) / den)


def transport_skew(K: np.ndarray, s: np.ndarray) -> float:
    dist = s[:, None] - s[None, :]
    w = np.abs(K)
    tot = float(np.sum(w))
    if tot <= 0:
        return float("nan")
    return float(np.sum(w * dist) / tot)


def numerical_rank(K: np.ndarray, tol: float = 1e-6) -> int:
    try:
        sv = np.linalg.svd(K, compute_uv=False)
    except np.linalg.LinAlgError:
        return -1
    if sv.size == 0:
        return 0
    ref = max(float(sv[0]), tol)
    return int(np.sum(sv >= tol * ref))


def resample_uniform(s: np.ndarray, y: np.ndarray, n: int) -> Tuple[np.ndarray, np.ndarray]:
    s_new = np.linspace(float(np.min(s)), float(np.max(s)), int(n))
    y_new = np.interp(s_new, s, y)
    return s_new, y_new


def coarse_bin_variant(s: np.ndarray, series: Dict[str, np.ndarray], n_bins: int) -> Tuple[np.ndarray, Dict[str, np.ndarray]]:
    edges = np.linspace(float(np.min(s)), float(np.max(s)), int(n_bins) + 1)
    centers = 0.5 * (edges[:-1] + edges[1:])
    idx = np.digitize(s, edges) - 1
    idx = np.clip(idx, 0, n_bins - 1)
    out: Dict[str, np.ndarray] = {}
    for key, arr in series.items():
        vals = np.zeros(n_bins, dtype=float)
        cnt = np.zeros(n_bins, dtype=float)
        for i, a in zip(idx, arr):
            if np.isfinite(a):
                vals[i] += a
                cnt[i] += 1.0
        vals = np.divide(vals, cnt, out=np.full_like(vals, np.nan), where=cnt > 0)
        good = np.isfinite(vals)
        if not np.all(good):
            vals = np.interp(centers, centers[good], vals[good])
        out[key] = vals
    return centers, out


def trimmed_variant(s: np.ndarray, series: Dict[str, np.ndarray], trim_q: float) -> Tuple[np.ndarray, Dict[str, np.ndarray]]:
    out = {}
    for key, arr in series.items():
        lo = float(np.nanquantile(arr, trim_q))
        hi = float(np.nanquantile(arr, 1.0 - trim_q))
        out[key] = np.clip(arr, lo, hi)
    return s.copy(), out


def cosine_basis(s: np.ndarray, n_modes: int) -> np.ndarray:
    x = (s - s.min()) / max(1e-12, s.max() - s.min())
    mats = [np.ones_like(x)]
    for k in range(1, n_modes):
        mats.append(np.cos(np.pi * k * x))
    return np.column_stack(mats)


def fourier_coeffs_real(y: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    coeff = np.fft.rfft(y)
    amp = np.abs(coeff)
    phase = np.angle(coeff)
    return amp, phase


def ridge_closed_form(X: np.ndarray, y: np.ndarray, alpha: float) -> np.ndarray:
    p = X.shape[1]
    A = X.T @ X + float(alpha) * np.eye(p)
    b = X.T @ y
    return np.linalg.solve(A, b)


# -----------------------------------------------------------------------------
# Project / file discovery
# -----------------------------------------------------------------------------
def discover_project_root() -> Path:
    here = Path.cwd().resolve()
    candidates = [here] + list(here.parents)
    for p in candidates:
        if p.name == PROJECT_DIR_NAME:
            return p
    fallback = Path.home() / "Downloads" / PROJECT_DIR_NAME
    return fallback


def read_json_if_exists(path: Path) -> Optional[dict]:
    if not path.exists():
        return None
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


# -----------------------------------------------------------------------------
# Data containers
# -----------------------------------------------------------------------------
@dataclass
class VariantData:
    variant_name: str
    variant_family: str
    s: np.ndarray
    fields: Dict[str, np.ndarray]


# -----------------------------------------------------------------------------
# Stage-6I priors
# -----------------------------------------------------------------------------
def derive_stage6i_priors(summary: Optional[dict], profile: Optional[pd.DataFrame]) -> dict:
    priors = {
        "max_abs_lag": DEFAULT_MAX_ABS_LAG,
        "n_lag_steps": DEFAULT_N_LAG_STEPS,
        "kernel_bandwidths": DEFAULT_KERNEL_BANDWIDTHS.copy(),
        "smoothing_variants": DEFAULT_SMOOTHING_VARIANTS.copy(),
        "coarse_bin_counts": DEFAULT_COARSE_BIN_COUNTS.copy(),
        "ridge_alphas": DEFAULT_RIDGE_ALPHAS.copy(),
        "likely_direction": "ambiguous",
        "suggested_lag_sign": 0.0,
        "suggested_lag_magnitude": 0.0,
        "top_spectral_overlap": float("nan"),
    }

    if isinstance(summary, dict):
        cfg = summary.get("configuration", {})
        priors["max_abs_lag"] = safe_float(cfg.get("max_abs_lag"), priors["max_abs_lag"])
        priors["n_lag_steps"] = int(cfg.get("n_lag_steps", priors["n_lag_steps"]))
        priors["kernel_bandwidths"] = list(cfg.get("kernel_bandwidths", priors["kernel_bandwidths"]))
        priors["smoothing_variants"] = list(cfg.get("smoothing_variants", priors["smoothing_variants"]))
        priors["coarse_bin_counts"] = list(cfg.get("coarse_bin_counts", priors["coarse_bin_counts"]))
        priors["ridge_alphas"] = list(cfg.get("ridge_alphas", priors["ridge_alphas"]))

    if profile is not None and not profile.empty:
        df = profile.copy()
        # Use absolute cross-correlation and lagged W1 gain as soft priors.
        df["abs_cross_max_corr"] = np.abs(df["cross_max_corr"].astype(float))
        best_cross = df.sort_values(["abs_cross_max_corr", "spectral_spectral_overlap"], ascending=False).iloc[0]
        best_w1 = df.sort_values(["lagged_w1_improvement_gain", "spectral_spectral_overlap"], ascending=False).iloc[0]

        priors["suggested_lag_sign"] = safe_float(best_cross.get("cross_optimal_lag"), 0.0)
        priors["suggested_lag_magnitude"] = abs(priors["suggested_lag_sign"])
        priors["top_spectral_overlap"] = safe_float(best_cross.get("spectral_spectral_overlap"), float("nan"))

        rho_dir = df[df["direction"] == "rho_to_kappa"]
        kap_dir = df[df["direction"] == "kappa_to_rho"]
        rho_score = float(np.nanmax(np.abs(rho_dir["cross_max_corr"]))) if not rho_dir.empty else float("nan")
        kap_score = float(np.nanmax(np.abs(kap_dir["cross_max_corr"]))) if not kap_dir.empty else float("nan")
        if np.isfinite(rho_score) and np.isfinite(kap_score):
            if rho_score > kap_score + 0.05:
                priors["likely_direction"] = "rho_to_kappa"
            elif kap_score > rho_score + 0.05:
                priors["likely_direction"] = "kappa_to_rho"
            else:
                priors["likely_direction"] = "ambiguous"

        # Add Stage-6I favorite bandwidths if present.
        bw = list(sorted(set(np.asarray(priors["kernel_bandwidths"], dtype=float).tolist() +
                             np.asarray(df["kernel_bandwidth"].astype(float).tolist()).tolist())))
        priors["kernel_bandwidths"] = [float(v) for v in bw if v > 0]

    return priors


# -----------------------------------------------------------------------------
# Input loading
# -----------------------------------------------------------------------------
def load_stage6h_profile(project_root: Path) -> Tuple[pd.DataFrame, Path]:
    path = project_root / "metric_stage_6H_outputs" / "stage6H_distributional_profile.csv"
    if not path.exists():
        raise FileNotFoundError(
            "Required Stage-6H input was not found:\n"
            f"  {path}\n"
            "This script expects the frozen Stage-6H distributional profile."
        )
    df = pd.read_csv(path)
    return df, path


def normalize_stage6h_contract(df: pd.DataFrame) -> Tuple[np.ndarray, Dict[str, np.ndarray], dict]:
    cols = set(df.columns)
    s_col = "s" if "s" in cols else "s_normalized" if "s_normalized" in cols else None
    if s_col is None:
        raise ValueError("Stage-6H profile must contain either 's' or 's_normalized'.")
    if "abs_kappa" not in cols:
        raise ValueError("Stage-6H profile must contain 'abs_kappa'.")
    if "density" not in cols:
        raise ValueError("Stage-6H profile must contain 'density'.")

    s = np.asarray(df[s_col], dtype=float)
    order = np.argsort(s)
    s = s[order]
    s_span = float(np.max(s) - np.min(s))
    if s_span <= 0:
        raise ValueError("Stage-6H intrinsic coordinate has zero span.")
    s_norm = (s - np.min(s)) / s_span

    fields: Dict[str, np.ndarray] = {}
    for name in ["abs_kappa", "density", "kappa", "theta", "ds", "curvature_mass", "density_mass"]:
        if name in cols:
            fields[name] = np.asarray(df[name], dtype=float)[order]

    # Signed curvature fallback.
    if "kappa" in fields and np.isfinite(fields["kappa"]).sum() >= 3:
        signed_kappa = fields["kappa"].copy()
    else:
        signed_kappa = fields["abs_kappa"].copy()

    fields["signed_or_abs_kappa"] = signed_kappa
    fields["abs_kappa"] = np.asarray(fields["abs_kappa"], dtype=float)
    fields["density"] = np.asarray(fields["density"], dtype=float)

    contract = {
        "rows": int(len(df)),
        "s_column_used": s_col,
        "s_min": float(np.min(s_norm)),
        "s_max": float(np.max(s_norm)),
        "required_columns_present": True,
        "optional_columns_present": [c for c in ["kappa", "theta", "ds", "curvature_mass", "density_mass"] if c in cols],
        "grid_info": {
            "n_points": int(len(s_norm)),
            "min_ds": float(np.min(np.diff(s_norm))) if len(s_norm) > 1 else float("nan"),
            "max_ds": float(np.max(np.diff(s_norm))) if len(s_norm) > 1 else float("nan"),
            "mean_ds": float(np.mean(np.diff(s_norm))) if len(s_norm) > 1 else float("nan"),
            "grid_cv": float(np.std(np.diff(s_norm)) / max(1e-12, np.mean(np.diff(s_norm)))) if len(s_norm) > 2 else float("nan"),
        },
    }
    return s_norm, fields, contract


# -----------------------------------------------------------------------------
# Variant construction
# -----------------------------------------------------------------------------
def build_variants(s: np.ndarray, fields: Dict[str, np.ndarray], priors: dict) -> List[VariantData]:
    variants: List[VariantData] = []

    smooth_cfgs = priors.get("smoothing_variants", DEFAULT_SMOOTHING_VARIANTS)
    for item in smooth_cfgs:
        kind = str(item.get("kind", "raw"))
        param = item.get("param", 0)
        new_fields = {k: smooth_series(v, kind, param) if k in ("density", "abs_kappa", "signed_or_abs_kappa") else v.copy()
                      for k, v in fields.items()}
        variants.append(VariantData(
            variant_name=f"{kind}:{param}",
            variant_family="smoothing",
            s=s.copy(),
            fields=new_fields,
        ))

    for n_bins in priors.get("coarse_bin_counts", DEFAULT_COARSE_BIN_COUNTS):
        s_c, coarse_fields = coarse_bin_variant(s, {
            "density": fields["density"],
            "abs_kappa": fields["abs_kappa"],
            "signed_or_abs_kappa": fields["signed_or_abs_kappa"],
        }, int(n_bins))
        variants.append(VariantData(
            variant_name=f"coarse:{int(n_bins)}",
            variant_family="coarse",
            s=s_c,
            fields=coarse_fields,
        ))

    s_t, trim_fields = trimmed_variant(s, {
        "density": fields["density"],
        "abs_kappa": fields["abs_kappa"],
        "signed_or_abs_kappa": fields["signed_or_abs_kappa"],
    }, trim_q=DEFAULT_TRIM_Q)
    variants.append(VariantData(
        variant_name=f"trimmed:{DEFAULT_TRIM_Q:.3f}",
        variant_family="trimmed",
        s=s_t,
        fields=trim_fields,
    ))

    return variants


# -----------------------------------------------------------------------------
# Method 1: shifted convolutional response
# -----------------------------------------------------------------------------
def evaluate_shifted_convolution(variant: VariantData, direction: str, priors: dict) -> dict:
    s = variant.s
    if direction == "kappa_to_rho":
        source = variant.fields["signed_or_abs_kappa"]
        target = variant.fields["density"]
    elif direction == "rho_to_kappa":
        source = variant.fields["density"]
        target = variant.fields["abs_kappa"]
    else:
        raise ValueError(direction)

    lag_grid = np.linspace(-float(priors["max_abs_lag"]), float(priors["max_abs_lag"]), int(priors["n_lag_steps"]))
    families = ["gaussian", "exponential", "compact_support", "power_law_tail"]
    bandwidths = [float(v) for v in priors["kernel_bandwidths"]]

    best = None
    for family in families:
        for bw in bandwidths:
            for lag in lag_grid:
                powers = DEFAULT_POWERS if family == "power_law_tail" else [1.0]
                for power in powers:
                    base = convolution_predict(s, source, family=family, bandwidth=bw, lag=float(lag), power=float(power))
                    intercept, scale, pred = fit_affine(target, base)
                    corr = nan_corr(pred, target)
                    rmse = l2_rmse(target, pred)
                    r2 = r2_score_manual(target, pred)
                    w1 = approx_w1_1d(np.clip(pred, 0, None), np.clip(target, 0, None), s)
                    js = js_distance_1d(np.clip(pred, 0, None), np.clip(target, 0, None))
                    score = (0.45 * (corr if np.isfinite(corr) else -1.0)
                             + 0.35 * (r2 if np.isfinite(r2) else -1.0)
                             - 0.20 * (rmse if np.isfinite(rmse) else 1e6))
                    row = {
                        "variant_name": variant.variant_name,
                        "variant_family": variant.variant_family,
                        "direction": direction,
                        "method_family": "shifted_convolution",
                        "kernel_family": family,
                        "kernel_bandwidth": float(bw),
                        "kernel_power": float(power),
                        "optimal_lag": float(lag),
                        "intercept": intercept,
                        "scale": scale,
                        "corr_pred_target": corr,
                        "r2": r2,
                        "rmse": rmse,
                        "w1": w1,
                        "js": js,
                        "score": score,
                        "n_points": int(len(s)),
                    }
                    if best is None or row["score"] > best["score"]:
                        best = row
                        best["pred"] = pred
    if best is None:
        raise RuntimeError("Shifted convolution search produced no valid candidate.")
    return best


# -----------------------------------------------------------------------------
# Method 2: free kernel inversion under constrained families
# -----------------------------------------------------------------------------
def fit_free_kernel_family(s: np.ndarray, source: np.ndarray, target: np.ndarray, family_name: str,
                           bandwidth: float, alpha: float, band: Optional[float] = None,
                           rank: Optional[int] = None, symmetric: bool = False) -> Tuple[np.ndarray, np.ndarray, dict]:
    dist = s[:, None] - s[None, :]
    adist = np.abs(dist)

    if family_name == "toeplitz":
        K0 = normalized_kernel(dist, family="gaussian", bandwidth=bandwidth)
    elif family_name == "banded":
        K0 = normalized_kernel(dist, family="gaussian", bandwidth=bandwidth)
        cutoff = float(band if band is not None else bandwidth * 2.0)
        K0 = np.where(adist <= cutoff, K0, 0.0)
    elif family_name == "asymmetric":
        shift = 0.5 * bandwidth
        K0 = normalized_kernel(dist, family="advection_diffusion", bandwidth=bandwidth, shift=shift)
    elif family_name == "lowrank":
        B = cosine_basis(s, int(rank or 6))
        # Predict target ≈ B A B^T source, with ridge on A coefficients.
        Z = []
        for i in range(B.shape[1]):
            for j in range(B.shape[1]):
                Z.append(B[:, i] * np.dot(B[:, j], source))
        Z = np.column_stack(Z)
        beta = ridge_closed_form(Z, target, alpha=alpha)
        A = beta.reshape(B.shape[1], B.shape[1])
        if symmetric:
            A = 0.5 * (A + A.T)
        K = B @ A @ B.T
        pred = K @ source
        info = {
            "constraint_family": family_name,
            "alpha": float(alpha),
            "bandwidth": float(bandwidth),
            "rank": int(rank or 6),
        }
        return K, pred, info
    else:
        raise ValueError(family_name)

    # Scale each row to unit mass when possible.
    row_sum = np.sum(K0, axis=1, keepdims=True)
    K0 = np.divide(K0, row_sum, out=np.zeros_like(K0), where=row_sum > 0)

    # Constrained correction: target ≈ (a I + b K0) source.
    X = np.column_stack([source, K0 @ source])
    beta = ridge_closed_form(X, target, alpha=alpha)
    a, b = float(beta[0]), float(beta[1])
    K = a * np.eye(len(s)) + b * K0
    if symmetric:
        K = 0.5 * (K + K.T)
    pred = K @ source
    info = {
        "constraint_family": family_name,
        "alpha": float(alpha),
        "bandwidth": float(bandwidth),
        "rank": int(rank or -1),
        "coeff_identity": a,
        "coeff_kernel": b,
    }
    return K, pred, info


def evaluate_free_kernel(variant: VariantData, direction: str, priors: dict) -> dict:
    # Resample to moderate size so matrix inversion remains stable and portable.
    n_target = min(DEFAULT_MATRIX_SAMPLE_SIZE, max(48, len(variant.s)))
    s = np.linspace(float(np.min(variant.s)), float(np.max(variant.s)), int(n_target))

    if direction == "kappa_to_rho":
        source = np.interp(s, variant.s, variant.fields["signed_or_abs_kappa"])
        target = np.interp(s, variant.s, variant.fields["density"])
    else:
        source = np.interp(s, variant.s, variant.fields["density"])
        target = np.interp(s, variant.s, variant.fields["abs_kappa"])

    candidates = []
    for family in ["toeplitz", "banded", "asymmetric"]:
        for bw in DEFAULT_FREEKERNEL_BANDWIDTHS:
            for alpha in priors.get("ridge_alphas", DEFAULT_RIDGE_ALPHAS):
                for symmetric in [False, True]:
                    band_choices = DEFAULT_TRUNC_BANDS if family == "banded" else [None]
                    for band in band_choices:
                        try:
                            K, pred, info = fit_free_kernel_family(
                                s, source, target,
                                family_name=family,
                                bandwidth=float(bw),
                                alpha=float(alpha),
                                band=band,
                                rank=None,
                                symmetric=symmetric,
                            )
                        except np.linalg.LinAlgError:
                            continue
                        row = {
                            "variant_name": variant.variant_name,
                            "variant_family": variant.variant_family,
                            "direction": direction,
                            "method_family": "free_kernel",
                            **info,
                            "is_symmetric_constraint": bool(symmetric),
                            "rmse": l2_rmse(target, pred),
                            "r2": r2_score_manual(target, pred),
                            "corr_pred_target": nan_corr(pred, target),
                            "effective_bandwidth": effective_bandwidth_from_matrix(K, s),
                            "matrix_rank": numerical_rank(K),
                            "symmetry_score": symmetry_score(K),
                            "transport_skew": transport_skew(K, s),
                            "n_points": int(len(s)),
                        }
                        row["score"] = (0.50 * (row["corr_pred_target"] if np.isfinite(row["corr_pred_target"]) else -1.0)
                                        + 0.35 * (row["r2"] if np.isfinite(row["r2"]) else -1.0)
                                        - 0.15 * (row["rmse"] if np.isfinite(row["rmse"]) else 1e6))
                        row["kernel_matrix"] = K
                        row["pred"] = pred
                        candidates.append(row)

    for rank in [4, 6, 8, 12]:
        for alpha in priors.get("ridge_alphas", DEFAULT_RIDGE_ALPHAS):
            for symmetric in [False, True]:
                try:
                    K, pred, info = fit_free_kernel_family(
                        s, source, target,
                        family_name="lowrank",
                        bandwidth=0.0,
                        alpha=float(alpha),
                        rank=rank,
                        symmetric=symmetric,
                    )
                except np.linalg.LinAlgError:
                    continue
                row = {
                    "variant_name": variant.variant_name,
                    "variant_family": variant.variant_family,
                    "direction": direction,
                    "method_family": "free_kernel",
                    **info,
                    "is_symmetric_constraint": bool(symmetric),
                    "rmse": l2_rmse(target, pred),
                    "r2": r2_score_manual(target, pred),
                    "corr_pred_target": nan_corr(pred, target),
                    "effective_bandwidth": effective_bandwidth_from_matrix(K, s),
                    "matrix_rank": numerical_rank(K),
                    "symmetry_score": symmetry_score(K),
                    "transport_skew": transport_skew(K, s),
                    "n_points": int(len(s)),
                }
                row["score"] = (0.50 * (row["corr_pred_target"] if np.isfinite(row["corr_pred_target"]) else -1.0)
                                + 0.35 * (row["r2"] if np.isfinite(row["r2"]) else -1.0)
                                - 0.15 * (row["rmse"] if np.isfinite(row["rmse"]) else 1e6))
                row["kernel_matrix"] = K
                row["pred"] = pred
                candidates.append(row)

    if not candidates:
        raise RuntimeError("Free-kernel search produced no valid candidates.")
    candidates = sorted(candidates, key=lambda d: d["score"], reverse=True)
    return candidates[0]


# -----------------------------------------------------------------------------
# Method 3: mode-space transfer
# -----------------------------------------------------------------------------
def evaluate_mode_transfer(variant: VariantData, direction: str, priors: dict) -> Tuple[dict, pd.DataFrame]:
    s = variant.s
    if direction == "kappa_to_rho":
        source = variant.fields["signed_or_abs_kappa"]
        target = variant.fields["density"]
    else:
        source = variant.fields["density"]
        target = variant.fields["abs_kappa"]

    n_modes = min(DEFAULT_LOW_MODE_COUNT, max(6, len(s) // 8))
    B = cosine_basis(s, n_modes=n_modes)
    source_coef, *_ = np.linalg.lstsq(B, source, rcond=None)
    target_coef, *_ = np.linalg.lstsq(B, target, rcond=None)

    rows = []
    for alpha in priors.get("ridge_alphas", DEFAULT_RIDGE_ALPHAS):
        X = np.column_stack([np.ones_like(source_coef), source_coef])
        beta = ridge_closed_form(X, target_coef, alpha=float(alpha))
        pred_coef = X @ beta
        pred_signal = B @ pred_coef
        phase_source_amp, phase_source = fourier_coeffs_real(source)
        phase_target_amp, phase_target = fourier_coeffs_real(target)
        overlap = float(np.dot(phase_source_amp, phase_target_amp) /
                        (np.linalg.norm(phase_source_amp) * np.linalg.norm(phase_target_amp) + 1e-12))
        low_mode_energy_ratio = float(np.sum(np.abs(target_coef[:min(4, len(target_coef))]) ** 2) /
                                      (np.sum(np.abs(target_coef) ** 2) + 1e-12))
        row = {
            "variant_name": variant.variant_name,
            "variant_family": variant.variant_family,
            "direction": direction,
            "method_family": "mode_transfer",
            "basis": "cosine",
            "n_modes": int(n_modes),
            "ridge_alpha": float(alpha),
            "transfer_intercept_mean": float(np.mean(beta[0])),
            "transfer_gain_mean": float(np.mean(beta[1])),
            "rmse": l2_rmse(target, pred_signal),
            "r2": r2_score_manual(target, pred_signal),
            "corr_pred_target": nan_corr(pred_signal, target),
            "spectral_overlap": overlap,
            "low_mode_energy_ratio": low_mode_energy_ratio,
        }
        row["score"] = (0.4 * (row["corr_pred_target"] if np.isfinite(row["corr_pred_target"]) else -1.0)
                        + 0.3 * (row["r2"] if np.isfinite(row["r2"]) else -1.0)
                        + 0.2 * (row["spectral_overlap"] if np.isfinite(row["spectral_overlap"]) else -1.0)
                        + 0.1 * row["low_mode_energy_ratio"])
        row["pred"] = pred_signal
        row["source_coef"] = source_coef
        row["target_coef"] = target_coef
        row["pred_coef"] = pred_coef
        rows.append(row)

    best = max(rows, key=lambda d: d["score"])

    detail = pd.DataFrame({
        "variant_name": variant.variant_name,
        "variant_family": variant.variant_family,
        "direction": direction,
        "mode_index": np.arange(len(best["source_coef"])),
        "source_coef": best["source_coef"],
        "target_coef": best["target_coef"],
        "predicted_target_coef": best["pred_coef"],
        "transfer_ratio_raw": np.divide(best["target_coef"], best["source_coef"],
                                         out=np.full_like(best["target_coef"], np.nan),
                                         where=np.abs(best["source_coef"]) > 1e-10),
    })
    return best, detail


# -----------------------------------------------------------------------------
# Method 4: propagator / Green-function fitting
# -----------------------------------------------------------------------------
def evaluate_propagators(variant: VariantData, direction: str, priors: dict) -> dict:
    s = variant.s
    if direction == "kappa_to_rho":
        source = variant.fields["signed_or_abs_kappa"]
        target = variant.fields["density"]
    else:
        source = variant.fields["density"]
        target = variant.fields["abs_kappa"]

    candidates = []
    for family in ["screened_poisson", "fractional", "advection_diffusion"]:
        for length in DEFAULT_PROPAGATOR_LENGTHS:
            powers = DEFAULT_POWERS if family == "fractional" else [1.0]
            shifts = DEFAULT_ADVECTION_SHIFTS if family == "advection_diffusion" else [0.0]
            for power in powers:
                for shift in shifts:
                    dist = s[:, None] - s[None, :]
                    K = normalized_kernel(dist, family=family, bandwidth=length, power=power, shift=shift)
                    base = K @ source
                    intercept, scale, pred = fit_affine(target, base)
                    row = {
                        "variant_name": variant.variant_name,
                        "variant_family": variant.variant_family,
                        "direction": direction,
                        "method_family": "propagator",
                        "operator_class": family,
                        "operator_length": float(length),
                        "operator_power": float(power),
                        "operator_shift": float(shift),
                        "intercept": intercept,
                        "scale": scale,
                        "rmse": l2_rmse(target, pred),
                        "r2": r2_score_manual(target, pred),
                        "corr_pred_target": nan_corr(pred, target),
                        "effective_bandwidth": effective_bandwidth_from_matrix(K, s),
                        "symmetry_score": symmetry_score(K),
                        "transport_skew": transport_skew(K, s),
                        "kernel_matrix": K,
                        "pred": pred,
                    }
                    row["score"] = (0.45 * (row["corr_pred_target"] if np.isfinite(row["corr_pred_target"]) else -1.0)
                                    + 0.35 * (row["r2"] if np.isfinite(row["r2"]) else -1.0)
                                    - 0.20 * (row["rmse"] if np.isfinite(row["rmse"]) else 1e6))
                    candidates.append(row)

    if not candidates:
        raise RuntimeError("Propagator search produced no candidates.")
    return max(candidates, key=lambda d: d["score"])


# -----------------------------------------------------------------------------
# Orchestrator
# -----------------------------------------------------------------------------
def run_stage6j() -> None:
    log("[Stage-6J PRECHECK] Discovering project root...")
    project_root = discover_project_root()
    output_dir = project_root / OUTPUT_DIR_NAME
    output_dir.mkdir(parents=True, exist_ok=True)

    log(f"[Stage-6J PRECHECK] Project root: {project_root}")
    log(f"[Stage-6J PRECHECK] Output dir  : {output_dir}")

    stage6i_summary_path = project_root / "metric_stage_6I_outputs" / "stage6I_operator_summary.json"
    stage6i_profile_path = project_root / "metric_stage_6I_outputs" / "stage6I_operator_profile.csv"
    stage6i_notes_path = project_root / "metric_stage_6I_outputs" / "stage6I_operator_notes.txt"

    log("[Stage-6J PRECHECK] Loading Stage-6H profile...")
    df_h, stage6h_path = load_stage6h_profile(project_root)
    s, fields, input_contract = normalize_stage6h_contract(df_h)

    log("[Stage-6J PRECHECK] Loading Stage-6I priors if available...")
    summary_i = read_json_if_exists(stage6i_summary_path)
    profile_i = pd.read_csv(stage6i_profile_path) if stage6i_profile_path.exists() else None
    priors = derive_stage6i_priors(summary_i, profile_i)

    log(f"[Stage-6J PRECHECK] Stage-6I likely direction prior: {priors['likely_direction']}")
    log(f"[Stage-6J PRECHECK] Stage-6I lag prior magnitude   : {priors['suggested_lag_magnitude']:.6f}")

    log("[Stage-6J BUILD] Constructing multi-scale variants...")
    variants = build_variants(s, fields, priors)
    log(f"[Stage-6J BUILD] Total variants: {len(variants)}")

    profile_rows: List[dict] = []
    transfer_rows: List[pd.DataFrame] = []
    best_kernel_artifacts: Dict[str, dict] = {}

    directions = ["kappa_to_rho", "rho_to_kappa"]
    for variant in variants:
        log(f"[Stage-6J RUN] Variant: {variant.variant_name}")
        for direction in directions:
            # 1) shifted convolution
            conv_best = evaluate_shifted_convolution(variant, direction, priors)
            profile_rows.append({k: v for k, v in conv_best.items() if k != "pred"})

            # 2) free kernel
            free_best = evaluate_free_kernel(variant, direction, priors)
            profile_rows.append({k: v for k, v in free_best.items() if k not in ("pred", "kernel_matrix")})

            # 3) mode transfer
            mode_best, mode_detail = evaluate_mode_transfer(variant, direction, priors)
            profile_rows.append({k: v for k, v in mode_best.items() if k not in ("pred", "source_coef", "target_coef", "pred_coef")})
            transfer_rows.append(mode_detail)

            # 4) propagator
            prop_best = evaluate_propagators(variant, direction, priors)
            profile_rows.append({k: v for k, v in prop_best.items() if k not in ("pred", "kernel_matrix")})

            # Store a kernel artifact candidate based on overall best matrix-based score.
            matrix_candidates = [free_best, prop_best]
            best_matrix = max(matrix_candidates, key=lambda d: d["score"])
            key = f"{variant.variant_name}__{direction}"
            best_kernel_artifacts[key] = best_matrix

    profile_df = pd.DataFrame(profile_rows)
    if profile_df.empty:
        raise RuntimeError("Stage-6J produced an empty profile table.")

    # ------------------------------------------------------------------
    # Global selections
    # ------------------------------------------------------------------
    best_by_method = {}
    for method in profile_df["method_family"].unique():
        sub = profile_df[profile_df["method_family"] == method].copy()
        if not sub.empty:
            best_by_method[method] = sub.sort_values("score", ascending=False).iloc[0].to_dict()

    direction_scores = {}
    for direction in directions:
        sub = profile_df[profile_df["direction"] == direction]
        direction_scores[direction] = {
            "mean_score": float(np.nanmean(sub["score"])) if len(sub) else float("nan"),
            "max_score": float(np.nanmax(sub["score"])) if len(sub) else float("nan"),
            "best_method": str(sub.sort_values("score", ascending=False).iloc[0]["method_family"]) if len(sub) else "none",
        }

    if np.isfinite(direction_scores["kappa_to_rho"]["mean_score"]) and np.isfinite(direction_scores["rho_to_kappa"]["mean_score"]):
        gap = direction_scores["kappa_to_rho"]["mean_score"] - direction_scores["rho_to_kappa"]["mean_score"]
        if gap > 0.05:
            preferred_direction = "kappa_to_rho"
        elif gap < -0.05:
            preferred_direction = "rho_to_kappa"
        else:
            preferred_direction = "ambiguous"
    else:
        preferred_direction = "ambiguous"

    # Stability / interpretation heuristics
    conv_df = profile_df[profile_df["method_family"] == "shifted_convolution"].copy()
    prop_df = profile_df[profile_df["method_family"] == "propagator"].copy()
    free_df = profile_df[profile_df["method_family"] == "free_kernel"].copy()
    mode_df = profile_df[profile_df["method_family"] == "mode_transfer"].copy()

    stable_kernel_count = int(np.sum(conv_df.groupby("variant_name")["score"].max() > 0.15)) if not conv_df.empty else 0
    stable_propagator_count = int(np.sum(prop_df.groupby("variant_name")["score"].max() > 0.15)) if not prop_df.empty else 0
    stable_mode_count = int(np.sum(mode_df.groupby("variant_name")["score"].max() > 0.20)) if not mode_df.empty else 0

    if stable_kernel_count >= 3 and stable_propagator_count >= 2:
        interpretation = "A"
        interpretation_text = "emergent nonlocal constitutive geometry exists"
    elif stable_kernel_count >= 2 or stable_mode_count >= 3:
        interpretation = "B"
        interpretation_text = "coupling exists but changes by scale or regime"
    elif stable_mode_count >= 1 or stable_propagator_count >= 1:
        interpretation = "C"
        interpretation_text = "shared invariants appear, but no single stable operator dominates"
    else:
        interpretation = "D"
        interpretation_text = "no meaningful stable operator was recovered beyond weak diagnostics"

    # Pick overall best kernel matrix artifact.
    best_matrix_key, best_matrix_entry = max(best_kernel_artifacts.items(), key=lambda kv: kv[1]["score"])
    best_K = best_matrix_entry["kernel_matrix"]
    if isinstance(best_K, np.ndarray):
        kernel_df = pd.DataFrame(best_K)
    else:
        kernel_df = pd.DataFrame(np.asarray(best_K, dtype=float))

    # ------------------------------------------------------------------
    # Save tabular outputs
    # ------------------------------------------------------------------
    profile_path = output_dir / "stage6J_nonlocal_operator_profile.csv"
    transfer_path = output_dir / "stage6J_transfer_modes.csv"
    kernel_matrix_path = output_dir / "stage6J_kernel_matrix_best.csv"
    summary_path = output_dir / "stage6J_nonlocal_operator_summary.json"
    notes_path = output_dir / "stage6J_nonlocal_operator_notes.txt"
    fig_kernel_path = output_dir / "stage6J_best_kernel_heatmap.png"
    fig_modes_path = output_dir / "stage6J_mode_transfer_plot.png"

    profile_df.sort_values(["method_family", "score"], ascending=[True, False]).to_csv(profile_path, index=False)
    pd.concat(transfer_rows, ignore_index=True).to_csv(transfer_path, index=False)
    kernel_df.to_csv(kernel_matrix_path, index=False)

    # ------------------------------------------------------------------
    # Figures
    # ------------------------------------------------------------------
    plt.figure(figsize=(7.0, 5.5))
    plt.imshow(best_K, aspect="auto", origin="lower")
    plt.colorbar(label="kernel weight")
    plt.title(
        "Stage-6J best kernel matrix\n"
        f"{best_matrix_entry['method_family']} | {best_matrix_entry['direction']} | {best_matrix_entry['variant_name']}"
    )
    plt.xlabel("source index")
    plt.ylabel("target index")
    plt.tight_layout()
    plt.savefig(fig_kernel_path, dpi=180)
    plt.close()

    best_mode = best_by_method.get("mode_transfer", None)
    if best_mode is not None:
        mode_detail_df = pd.concat(transfer_rows, ignore_index=True)
        mode_mask = (
            (mode_detail_df["variant_name"] == best_mode["variant_name"]) &
            (mode_detail_df["direction"] == best_mode["direction"])
        )
        sub = mode_detail_df[mode_mask].copy()
        plt.figure(figsize=(7.0, 5.5))
        plt.plot(sub["mode_index"], sub["source_coef"], marker="o", label="source")
        plt.plot(sub["mode_index"], sub["target_coef"], marker="s", label="target")
        plt.plot(sub["mode_index"], sub["predicted_target_coef"], marker="^", label="predicted target")
        plt.title(
            "Stage-6J mode transfer\n"
            f"{best_mode['direction']} | {best_mode['variant_name']}"
        )
        plt.xlabel("mode index")
        plt.ylabel("coefficient")
        plt.legend()
        plt.tight_layout()
        plt.savefig(fig_modes_path, dpi=180)
        plt.close()

    # ------------------------------------------------------------------
    # Summary JSON
    # ------------------------------------------------------------------
    summary = {
        "script_version": SCRIPT_VERSION,
        "input_profile": str(stage6h_path),
        "stage6I_summary_used": str(stage6i_summary_path) if stage6i_summary_path.exists() else None,
        "stage6I_profile_used": str(stage6i_profile_path) if stage6i_profile_path.exists() else None,
        "stage6I_notes_used": str(stage6i_notes_path) if stage6i_notes_path.exists() else None,
        "input_contract_observed": input_contract,
        "stage6I_priors": priors,
        "variants_evaluated": [{
            "variant_name": v.variant_name,
            "variant_family": v.variant_family,
            "n_points": int(len(v.s)),
        } for v in variants],
        "best_by_method": json_ready(best_by_method),
        "directionality": {
            "scores": direction_scores,
            "preferred_direction": preferred_direction,
        },
        "stability": {
            "stable_kernel_count": stable_kernel_count,
            "stable_propagator_count": stable_propagator_count,
            "stable_mode_count": stable_mode_count,
        },
        "best_kernel_artifact": {
            "key": best_matrix_key,
            "entry": json_ready({k: v for k, v in best_matrix_entry.items() if k not in ("kernel_matrix", "pred")}),
        },
        "stage6J_interpretation": {
            "label": interpretation,
            "text": interpretation_text,
        },
        "output_files": {
            "profile_csv": str(profile_path),
            "summary_json": str(summary_path),
            "notes_txt": str(notes_path),
            "kernel_matrix_csv": str(kernel_matrix_path),
            "transfer_modes_csv": str(transfer_path),
            "kernel_heatmap_png": str(fig_kernel_path),
            "mode_transfer_plot_png": str(fig_modes_path),
        },
    }
    with open(summary_path, "w", encoding="utf-8") as f:
        json.dump(json_ready(summary), f, indent=2)

    # ------------------------------------------------------------------
    # Notes TXT
    # ------------------------------------------------------------------
    lines = []
    lines.append("============================================================")
    lines.append("STAGE-6J NONLOCAL OPERATOR NOTES")
    lines.append("Project: Quantum-Emergent Gravity")
    lines.append("============================================================")
    lines.append("")
    lines.append("DECISIVE INTERPRETATION")
    lines.append("----------------------")
    lines.append(f"{interpretation} : {interpretation_text}")
    lines.append("")
    lines.append("DIRECTIONALITY")
    lines.append("-------------")
    lines.append(f"Preferred direction: {preferred_direction}")
    for k, v in direction_scores.items():
        lines.append(
            f"{k}: mean_score={v['mean_score']:.6f}, max_score={v['max_score']:.6f}, best_method={v['best_method']}"
        )
    lines.append("")
    lines.append("BEST METHOD-SPECIFIC EVIDENCE")
    lines.append("-----------------------------")
    for method, row in best_by_method.items():
        lines.append(f"[{method}]")
        lines.append(
            f"variant={row.get('variant_name')} | direction={row.get('direction')} | score={safe_float(row.get('score')):.6f}"
        )
        if method == "shifted_convolution":
            lines.append(
                f"kernel_family={row.get('kernel_family')} | bandwidth={safe_float(row.get('kernel_bandwidth')):.6f} | lag={safe_float(row.get('optimal_lag')):.6f}"
            )
        elif method == "free_kernel":
            lines.append(
                f"constraint_family={row.get('constraint_family')} | effective_bandwidth={safe_float(row.get('effective_bandwidth')):.6f} | rank={row.get('matrix_rank')}"
            )
        elif method == "mode_transfer":
            lines.append(
                f"basis={row.get('basis')} | n_modes={row.get('n_modes')} | spectral_overlap={safe_float(row.get('spectral_overlap')):.6f}"
            )
        elif method == "propagator":
            lines.append(
                f"operator_class={row.get('operator_class')} | length={safe_float(row.get('operator_length')):.6f} | shift={safe_float(row.get('operator_shift')):.6f}"
            )
        lines.append(
            f"corr={safe_float(row.get('corr_pred_target')):.6f} | r2={safe_float(row.get('r2')):.6f} | rmse={safe_float(row.get('rmse')):.6f}"
        )
        lines.append("")

    lines.append("ROBUSTNESS COUNTS")
    lines.append("-----------------")
    lines.append(f"stable_kernel_count: {stable_kernel_count}")
    lines.append(f"stable_propagator_count: {stable_propagator_count}")
    lines.append(f"stable_mode_count: {stable_mode_count}")
    lines.append("")
    lines.append("INTERPRETIVE REMARK")
    lines.append("-------------------")
    lines.append(
        "Stage-6J promotes the Stage-6I nonlocal-response hypothesis into explicit operator tests. "
        "A positive outcome here does not yet prove a unique constitutive law; rather, it indicates "
        "that curvature-like and density-like observables are better compared through response geometry, "
        "transport, propagator structure, or low-mode transfer than through a naive local pointwise closure."
    )
    lines.append("")
    lines.append("============================================================")
    lines.append("END OF STAGE-6J NOTES")
    lines.append("============================================================")
    with open(notes_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")

    log("[Stage-6J DONE] Outputs written:")
    log(f"  - {profile_path}")
    log(f"  - {summary_path}")
    log(f"  - {notes_path}")
    log(f"  - {kernel_matrix_path}")
    log(f"  - {transfer_path}")
    log(f"  - {fig_kernel_path}")
    log(f"  - {fig_modes_path}")


if __name__ == "__main__":
    try:
        run_stage6j()
    except Exception as exc:
        log("[Stage-6J FATAL] The script stopped due to an exception.")
        log(f"[Stage-6J FATAL] {type(exc).__name__}: {exc}")
        traceback.print_exc()
        raise
