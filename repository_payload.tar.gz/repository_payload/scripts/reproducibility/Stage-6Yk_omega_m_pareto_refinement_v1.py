#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
===============================================================================
STAGE-6Yk OMEGA_m PARETO REFINEMENT AND CROSS-BENCHMARK GUARDRAIL
Project: Quantum-Emergent Gravity
Author: Arturo Ortiz-Tapia / ChatGPT assistant support
Build date: 2026-05-25
===============================================================================

PURPOSE
-------
Stage-6Yj converted the Stage-6Yi / v1a results into a manuscript-facing
architecture.  Stage-6Yk is a *refinement audit*, not a new physics fit.

Question being tested:

    Can the Omega_m comparison be sharpened below the corrected
    column-locked error (~4.13%) without degrading the rest of the
    external benchmark panel?

DISCIPLINE RULES
----------------
1. No fitting to PDG constants.
2. No transformation of QEG values to reduce benchmark discrepancies.
3. No benchmark-driven retuning of upstream observables.
4. Existing Stage-6Yj rows are re-scored and audited only.
5. Any improvement candidate must be tagged as:
      - primary-safe,
      - repair-target,
      - historical-only,
      - or rejected.
6. Other constants are protected by a cross-benchmark guardrail.

INTERPRETIVE POINT
------------------
A smaller Omega_m discrepancy is not automatically better if it comes from
an ambiguity-period row, a lineage-aggregation artifact, an unspecified feature,
or a candidate that breaks broader benchmark discipline.  The goal is a
Pareto-safe improvement: Omega_m improves while the benchmark panel remains
stable or improves under the same admissibility rules.

OUTPUTS
-------
metric_stage_6Yk_outputs/
  stage6Yk_omega_m_refinement_candidates.csv
  stage6Yk_benchmark_guardrail_baseline.csv
  stage6Yk_cross_constant_feature_forcing_audit.csv
  stage6Yk_refinement_decision_table.csv
  stage6Yk_summary.json
  Stage-6Yk_omega_m_pareto_refinement_notes.txt
  stage6Yk_input_audit.csv
  stage6Yk_review_flags.csv

Run from the project root:

  python3 Stage-6Yk_omega_m_pareto_refinement_v1.py

or explicitly:

  python3 Stage-6Yk_omega_m_pareto_refinement_v1.py \
      --root /home/dakini/Downloads/010-Quantum_Emergent_Gravity

Use --overwrite to replace prior outputs.
===============================================================================
"""

from __future__ import annotations

import argparse
import json
import math
import os
from pathlib import Path
from typing import Dict, List, Tuple, Optional

import numpy as np
import pandas as pd

DEFAULT_ROOT = Path("/home/dakini/Downloads/010-Quantum_Emergent_Gravity")
YJ_DIRNAME = "metric_stage_6Yj_outputs"
YK_DIRNAME = "metric_stage_6Yk_outputs"

REQUIRED_YJ_FILES = {
    "raw": "stage6Yj_manuscript_raw_result_table.csv",
    "omega": "stage6Yj_omega_m_refinement_panel.csv",
    "curvature": "stage6Yj_curvature_refinement_panel.csv",
    "pdg": "stage6Yj_pdg_benchmark_table.csv",
    "claim": "stage6Yj_claim_status_matrix.csv",
    "summary": "stage6Yj_summary.json",
    "notes": "Stage-6Yj_manuscript_axis_notes.txt",
}

NEAR_ZERO_BENCHMARK_ABS_CUTOFF = 1.0e-2  # protects Omega_K-style near-zero comparisons
EPS = 1.0e-15


def banner(msg: str) -> None:
    print("=" * 79)
    print(msg)
    print("=" * 79)


def safe_float(x) -> float:
    try:
        if pd.isna(x):
            return float("nan")
        return float(x)
    except Exception:
        return float("nan")


def read_json(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def write_json(obj: dict, path: Path) -> None:
    with path.open("w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, sort_keys=False)


def locate_inputs(root: Path) -> Tuple[Dict[str, Path], pd.DataFrame]:
    yj_dir = root / YJ_DIRNAME
    rows = []
    paths: Dict[str, Path] = {}
    for key, fname in REQUIRED_YJ_FILES.items():
        p = yj_dir / fname
        exists = p.exists()
        status = "FOUND" if exists else "MISSING"
        rows.append({"input_key": key, "expected_path": str(p), "status": status})
        if exists:
            paths[key] = p
    return paths, pd.DataFrame(rows)


def ensure_output_dir(path: Path, overwrite: bool) -> None:
    path.mkdir(parents=True, exist_ok=True)
    intended = [
        "stage6Yk_omega_m_refinement_candidates.csv",
        "stage6Yk_benchmark_guardrail_baseline.csv",
        "stage6Yk_cross_constant_feature_forcing_audit.csv",
        "stage6Yk_refinement_decision_table.csv",
        "stage6Yk_summary.json",
        "Stage-6Yk_omega_m_pareto_refinement_notes.txt",
        "stage6Yk_input_audit.csv",
        "stage6Yk_review_flags.csv",
    ]
    existing = [x for x in intended if (path / x).exists()]
    if existing and not overwrite:
        raise FileExistsError(
            "Stage-6Yk output files already exist. Use --overwrite to replace them. Existing: "
            + ", ".join(existing)
        )


def normalize_strings(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    for col in out.columns:
        if out[col].dtype == object:
            out[col] = out[col].astype(str).replace({"nan": np.nan})
    return out


def true_error_columns(df: pd.DataFrame, prefix: str = "") -> pd.DataFrame:
    """Add robust absolute/percent error columns from qeg_value and benchmark_value."""
    out = df.copy()
    out[prefix + "qeg_value_num"] = out.get("qeg_value", pd.Series(index=out.index)).map(safe_float)
    out[prefix + "benchmark_value_num"] = out.get("benchmark_value", pd.Series(index=out.index)).map(safe_float)
    q = out[prefix + "qeg_value_num"]
    b = out[prefix + "benchmark_value_num"]
    out[prefix + "signed_difference"] = q - b
    out[prefix + "absolute_difference_true"] = (q - b).abs()
    denom = b.abs().replace(0.0, np.nan)
    out[prefix + "percent_error_true"] = 100.0 * out[prefix + "absolute_difference_true"] / denom
    out[prefix + "is_near_zero_benchmark"] = b.abs() <= NEAR_ZERO_BENCHMARK_ABS_CUTOFF
    out[prefix + "guardrail_error_metric"] = np.where(
        out[prefix + "is_near_zero_benchmark"],
        "absolute_error_near_zero_benchmark",
        "percent_error_nonzero_benchmark",
    )
    out[prefix + "guardrail_error_value"] = np.where(
        out[prefix + "is_near_zero_benchmark"],
        out[prefix + "absolute_difference_true"],
        out[prefix + "percent_error_true"],
    )
    return out


def admissible_external_rows(raw: pd.DataFrame) -> pd.DataFrame:
    df = raw.copy()
    for c in ["manuscript_status", "qeg_feature", "benchmark_key", "trust_tier"]:
        if c not in df.columns:
            df[c] = np.nan
    mask = (
        df["benchmark_key"].notna()
        & df["qeg_value"].notna()
        & df["benchmark_value"].notna()
        & (df["manuscript_status"].astype(str).str.contains("ALLOWED_EXTERNAL_BENCHMARK", na=False))
        & (~df["qeg_feature"].astype(str).str.contains("external_benchmark_anchor_only", case=False, na=False))
        & (~df["qeg_feature"].astype(str).str.contains("unspecified_feature", case=False, na=False))
    )
    return df.loc[mask].copy()


def trust_rank(trust: str) -> int:
    s = str(trust).upper()
    if "TIER_1" in s:
        return 1
    if "TIER_2" in s:
        return 2
    if "TIER_3" in s:
        return 3
    if "HISTORICAL" in s:
        return 8
    if "BENCHMARK" in s:
        return 9
    return 5


def classify_omega_candidate(row: pd.Series, primary_percent: float, historical_features: set) -> Tuple[str, str, int]:
    feat = str(row.get("qeg_feature", ""))
    trust = str(row.get("trust_tier", ""))
    mechanism = str(row.get("discrepancy_mechanism", ""))
    row_class = str(row.get("omega_m_row_class", ""))
    pct = safe_float(row.get("percent_error_true", np.nan))
    source = str(row.get("candidate_source", ""))

    if not math.isfinite(pct):
        return "REJECT", "non-numeric candidate", 99
    if "unspecified" in feat.lower():
        return "REJECT", "unspecified feature cannot become manuscript anchor", 90
    if "PRIMARY_CORRECTED" in row_class:
        return "CURRENT_PRIMARY_ANCHOR", "current corrected column-locked anchor", 20
    if "HISTORICAL" in row_class or "HISTORICAL" in trust.upper():
        if pct < primary_percent:
            return "HISTORICAL_REPAIR_TARGET", "sharper than primary but historical/ambiguity-period only", 30
        return "HISTORICAL_ONLY", "historical row not sharper than primary", 70
    if feat in historical_features and pct < primary_percent:
        return "REPAIR_TARGET_REPRODUCE_UNDER_COLUMN_LOCK", "feature is sharp but associated with historical ambiguity; must be re-derived under corrected locking", 35
    if pct < primary_percent and "TIER_1" in trust.upper():
        return "PRIMARY_SAFE_REFINEMENT_CANDIDATE", "strict Tier-1 row improves Omega_m", 10
    if pct < primary_percent and "TIER_2" in trust.upper():
        if "LINEAGE_AGGREGATION" in mechanism.upper():
            return "REPAIR_TARGET_LINEAGE_REVIEW", "strict-looking row improves Omega_m but lineage aggregation warning remains", 40
        return "SECONDARY_REFINEMENT_CANDIDATE", "Tier-2 row improves Omega_m", 25
    if pct < primary_percent:
        return "IMPROVES_BUT_LOW_TRUST", "numerically sharper but trust tier insufficient", 60
    return "DOES_NOT_IMPROVE_PRIMARY", "does not reduce corrected Omega_m error", 80


def build_omega_candidates(raw: pd.DataFrame, omega_panel: pd.DataFrame) -> Tuple[pd.DataFrame, dict]:
    raw2 = true_error_columns(raw)
    omega_raw = raw2[raw2["benchmark_key"].astype(str).eq("Omega_m")].copy()
    omega_raw["candidate_source"] = "stage6Yj_manuscript_raw_result_table"
    omega_raw["omega_m_row_class"] = "RAW_STAGE6YJ_CANDIDATE"

    omega2 = omega_panel.copy()
    omega2 = true_error_columns(omega2)
    omega2["candidate_source"] = "stage6Yj_omega_m_refinement_panel"
    for col in omega_raw.columns:
        if col not in omega2.columns:
            omega2[col] = np.nan
    for col in omega2.columns:
        if col not in omega_raw.columns:
            omega_raw[col] = np.nan

    combined = pd.concat([omega2[omega_raw.columns], omega_raw], ignore_index=True)

    primary_mask = combined["omega_m_row_class"].astype(str).str.contains("PRIMARY_CORRECTED", na=False)
    if primary_mask.any():
        primary_row = combined.loc[primary_mask].iloc[0]
        primary_value = safe_float(primary_row.get("qeg_value"))
        primary_abs = abs(primary_value - safe_float(primary_row.get("benchmark_value")))
        primary_percent = 100.0 * primary_abs / abs(safe_float(primary_row.get("benchmark_value")))
    else:
        # Fallback to global_mu with smallest true error.
        gm = combined[combined["qeg_feature"].astype(str).eq("global_mu")].copy()
        if len(gm):
            primary_row = gm.sort_values("percent_error_true").iloc[0]
            primary_percent = safe_float(primary_row.get("percent_error_true"))
        else:
            primary_row = combined.sort_values("percent_error_true").iloc[0]
            primary_percent = safe_float(primary_row.get("percent_error_true"))

    hist_features = set(
        combined.loc[
            combined["omega_m_row_class"].astype(str).str.contains("HISTORICAL", na=False),
            "qeg_feature",
        ].astype(str).tolist()
    )

    statuses = combined.apply(lambda r: classify_omega_candidate(r, primary_percent, hist_features), axis=1)
    combined["refinement_status"] = [x[0] for x in statuses]
    combined["refinement_reason"] = [x[1] for x in statuses]
    combined["refinement_rank"] = [x[2] for x in statuses]
    combined["primary_corrected_percent_error"] = primary_percent
    combined["improvement_vs_primary_percent_points"] = primary_percent - combined["percent_error_true"]
    combined["improvement_vs_primary_factor"] = primary_percent / combined["percent_error_true"].replace(0, np.nan)
    combined["trust_rank"] = combined["trust_tier"].map(trust_rank)

    keep_cols = [
        "candidate_source", "omega_m_row_class", "stage_source", "source_file", "source_row",
        "qeg_feature", "qeg_value", "benchmark_comparator", "benchmark_key", "benchmark_value",
        "absolute_difference_true", "percent_error_true", "primary_corrected_percent_error",
        "improvement_vs_primary_percent_points", "improvement_vs_primary_factor",
        "family_status", "coordinate_status", "mechanism_status", "semantic_trust_filter",
        "trust_tier", "trust_rank", "discrepancy_mechanism", "multiplicity_context",
        "manuscript_status", "refinement_status", "refinement_reason", "refinement_rank",
        "allowed_language", "forbidden_language", "raw_preservation_status",
    ]
    for c in keep_cols:
        if c not in combined.columns:
            combined[c] = np.nan
    combined = combined[keep_cols].sort_values(
        ["refinement_rank", "percent_error_true", "trust_rank", "qeg_feature"],
        na_position="last",
    ).reset_index(drop=True)

    meta = {
        "primary_corrected_percent_error": float(primary_percent),
        "primary_corrected_value": safe_float(primary_row.get("qeg_value")),
        "primary_corrected_feature": str(primary_row.get("qeg_feature")),
        "omega_m_benchmark": safe_float(primary_row.get("benchmark_value")),
    }
    return combined, meta


def build_benchmark_guardrail(raw: pd.DataFrame) -> pd.DataFrame:
    df = admissible_external_rows(raw)
    df = true_error_columns(df)
    df["trust_rank"] = df["trust_tier"].map(trust_rank)
    # Sort by trust first, then guardrail error.  Also report pure closest row separately.
    rows = []
    for key, g in df.groupby("benchmark_key", dropna=True):
        g = g.copy()
        if g.empty:
            continue
        # Trust-first baseline: best trust rank first, then error.
        trust_best = g.sort_values(["trust_rank", "guardrail_error_value", "qeg_feature"], na_position="last").iloc[0]
        # Closeness-only baseline: useful for review, not automatic manuscript choice.
        close_best = g.sort_values(["guardrail_error_value", "trust_rank", "qeg_feature"], na_position="last").iloc[0]
        metric = str(trust_best["guardrail_error_metric"])
        vals = g["guardrail_error_value"].dropna()
        rows.append({
            "benchmark_key": key,
            "benchmark_value": safe_float(trust_best.get("benchmark_value")),
            "benchmark_source": trust_best.get("benchmark_source", np.nan),
            "row_count_admissible": int(len(g)),
            "trust_first_feature": trust_best.get("qeg_feature"),
            "trust_first_value": safe_float(trust_best.get("qeg_value")),
            "trust_first_error_metric": metric,
            "trust_first_error_value": safe_float(trust_best.get("guardrail_error_value")),
            "trust_first_percent_error_true": safe_float(trust_best.get("percent_error_true")),
            "trust_first_absolute_difference_true": safe_float(trust_best.get("absolute_difference_true")),
            "trust_first_trust_tier": trust_best.get("trust_tier"),
            "trust_first_family_status": trust_best.get("family_status"),
            "trust_first_discrepancy_mechanism": trust_best.get("discrepancy_mechanism"),
            "closest_feature": close_best.get("qeg_feature"),
            "closest_value": safe_float(close_best.get("qeg_value")),
            "closest_error_metric": close_best.get("guardrail_error_metric"),
            "closest_error_value": safe_float(close_best.get("guardrail_error_value")),
            "closest_percent_error_true": safe_float(close_best.get("percent_error_true")),
            "closest_absolute_difference_true": safe_float(close_best.get("absolute_difference_true")),
            "closest_trust_tier": close_best.get("trust_tier"),
            "best_error_median": float(vals.median()) if len(vals) else np.nan,
            "best_error_min": float(vals.min()) if len(vals) else np.nan,
            "within_1pct_count": int((g["percent_error_true"] <= 1.0).sum()) if metric != "absolute_error_near_zero_benchmark" else np.nan,
            "within_5pct_count": int((g["percent_error_true"] <= 5.0).sum()) if metric != "absolute_error_near_zero_benchmark" else np.nan,
            "within_10pct_count": int((g["percent_error_true"] <= 10.0).sum()) if metric != "absolute_error_near_zero_benchmark" else np.nan,
            "within_1sigma_abs_count": np.nan,
            "guardrail_policy": "protect this table; future Omega_m refinement must not worsen trust-first rows without explicit reason",
        })
    out = pd.DataFrame(rows).sort_values("benchmark_key").reset_index(drop=True)
    return out


def build_feature_forcing_audit(raw: pd.DataFrame, omega_candidates: pd.DataFrame) -> pd.DataFrame:
    """
    Stress test: if one insisted on a single Omega_m candidate feature as a global
    comparator feature, how would it behave across the benchmark panel?

    This is intentionally conservative and often unfair. It is a guardrail against
    letting a feature win Omega_m by accidentally being bad elsewhere.
    """
    df = admissible_external_rows(raw)
    df = true_error_columns(df)
    df["trust_rank"] = df["trust_tier"].map(trust_rank)
    candidate_features = list(
        omega_candidates.loc[
            omega_candidates["refinement_status"].astype(str).str.contains(
                "CANDIDATE|REPAIR_TARGET|CURRENT_PRIMARY", regex=True, na=False
            ),
            "qeg_feature",
        ].dropna().astype(str).unique()
    )
    rows = []
    for feat in candidate_features:
        sub = df[df["qeg_feature"].astype(str).eq(feat)].copy()
        if sub.empty:
            rows.append({
                "qeg_feature": feat,
                "feature_forcing_status": "NO_ROWS_OUTSIDE_OMEGA_M",
                "benchmark_coverage_count": 0,
            })
            continue
        best_rows = []
        for key, g in sub.groupby("benchmark_key", dropna=True):
            best = g.sort_values(["trust_rank", "guardrail_error_value"], na_position="last").iloc[0]
            best_rows.append(best)
        best_df = pd.DataFrame(best_rows)
        nonzero = best_df[~best_df["is_near_zero_benchmark"]].copy()
        nearzero = best_df[best_df["is_near_zero_benchmark"]].copy()
        omega_rows = best_df[best_df["benchmark_key"].astype(str).eq("Omega_m")]
        omega_pct = safe_float(omega_rows.iloc[0].get("percent_error_true")) if len(omega_rows) else np.nan
        # Cross-constant score excludes Omega_m to avoid target leakage.
        other_nonzero = nonzero[~nonzero["benchmark_key"].astype(str).eq("Omega_m")]
        other_pct_median = safe_float(other_nonzero["percent_error_true"].median()) if len(other_nonzero) else np.nan
        other_pct_max = safe_float(other_nonzero["percent_error_true"].max()) if len(other_nonzero) else np.nan
        near_abs_median = safe_float(nearzero["absolute_difference_true"].median()) if len(nearzero) else np.nan
        if math.isfinite(omega_pct) and omega_pct <= 1.0:
            omega_class = "OMEGA_M_SUB_1_PERCENT"
        elif math.isfinite(omega_pct) and omega_pct <= 5.0:
            omega_class = "OMEGA_M_SUB_5_PERCENT"
        elif math.isfinite(omega_pct):
            omega_class = "OMEGA_M_WEAK"
        else:
            omega_class = "NO_OMEGA_M_ROW"
        # Status emphasizes that feature-forcing is NOT the intended manuscript policy.
        if math.isfinite(other_pct_median) and other_pct_median <= 10.0:
            forcing_status = "FEATURE_GLOBAL_BEHAVIOR_REASONABLE_REVIEW"
        elif math.isfinite(other_pct_median):
            forcing_status = "DO_NOT_FORCE_FEATURE_GLOBALLY"
        else:
            forcing_status = "INSUFFICIENT_CROSS_BENCHMARK_COVERAGE"
        rows.append({
            "qeg_feature": feat,
            "feature_forcing_status": forcing_status,
            "omega_m_forcing_class": omega_class,
            "omega_m_percent_error_true": omega_pct,
            "benchmark_coverage_count": int(best_df["benchmark_key"].nunique()),
            "covered_benchmarks": ";".join(sorted(best_df["benchmark_key"].astype(str).unique())),
            "other_nonzero_benchmark_median_percent_error": other_pct_median,
            "other_nonzero_benchmark_max_percent_error": other_pct_max,
            "near_zero_benchmark_median_abs_error": near_abs_median,
            "warning": "This is a stress test only. Do not require one QEG feature to explain all PDG benchmarks.",
        })
    return pd.DataFrame(rows).sort_values(
        ["omega_m_percent_error_true", "other_nonzero_benchmark_median_percent_error"],
        na_position="last",
    ).reset_index(drop=True)


def build_decision_table(omega_candidates: pd.DataFrame, guardrail: pd.DataFrame, forcing: pd.DataFrame, meta: dict) -> pd.DataFrame:
    rows = []
    primary_pct = meta["primary_corrected_percent_error"]

    # Best immediately safe candidate.
    safe = omega_candidates[omega_candidates["refinement_status"].eq("PRIMARY_SAFE_REFINEMENT_CANDIDATE")]
    secondary = omega_candidates[omega_candidates["refinement_status"].eq("SECONDARY_REFINEMENT_CANDIDATE")]
    repair = omega_candidates[omega_candidates["refinement_status"].astype(str).str.contains("REPAIR_TARGET|HISTORICAL_REPAIR", na=False)]

    if len(safe):
        best = safe.sort_values("percent_error_true").iloc[0]
        decision = "UPGRADE_PRIMARY_OMEGA_M_ANCHOR_CANDIDATE"
        reason = "A Tier-1 non-historical row improves Omega_m under current Stage-6Yj discipline."
        next_action = "Promote only after manual table review and ledger entry."
    elif len(secondary):
        best = secondary.sort_values("percent_error_true").iloc[0]
        decision = "SECONDARY_OMEGA_M_IMPROVEMENT_CANDIDATE"
        reason = "A Tier-2 non-historical row improves Omega_m, but not enough trust for automatic anchor promotion."
        next_action = "Audit provenance/semantic basis before promotion."
    elif len(repair):
        best = repair.sort_values("percent_error_true").iloc[0]
        decision = "REFINE_BY_REPRODUCING_SHARP_FEATURE_UNDER_CORRECTED_LOCKING"
        reason = (
            "A sharper Omega_m row exists, but it is historical/repair-target/lineage-review. "
            "The correct move is to rederive that feature under corrected column-locking, not to claim it now."
        )
        next_action = "Prepare Stage-6Yk follow-up or run extension that reconstructs this feature from corrected locked inputs."
    else:
        best = omega_candidates.sort_values("percent_error_true").iloc[0]
        decision = "KEEP_PRIMARY_GLOBAL_MU_ANCHOR"
        reason = "No admissible sharper candidate passed trust filters."
        next_action = "Freeze Stage-6Yj primary anchor and only discuss sharper rows historically."

    # Guardrail summary.
    n_bench = int(len(guardrail))
    omega_guard = guardrail[guardrail["benchmark_key"].astype(str).eq("Omega_m")]
    curvature_guard = guardrail[guardrail["benchmark_key"].astype(str).eq("Omega_K")]
    rows.append({
        "decision_id": "D1",
        "decision": decision,
        "selected_feature_for_review": best.get("qeg_feature"),
        "selected_qeg_value": safe_float(best.get("qeg_value")),
        "omega_m_benchmark": safe_float(best.get("benchmark_value")),
        "selected_percent_error_true": safe_float(best.get("percent_error_true")),
        "current_primary_percent_error": primary_pct,
        "improvement_percent_points": primary_pct - safe_float(best.get("percent_error_true")),
        "improvement_factor": primary_pct / safe_float(best.get("percent_error_true")) if safe_float(best.get("percent_error_true")) > EPS else np.nan,
        "reason": reason,
        "cross_benchmark_guardrail_benchmarks_tracked": n_bench,
        "omega_m_guardrail_best_feature": omega_guard.iloc[0].get("trust_first_feature") if len(omega_guard) else np.nan,
        "curvature_guardrail_best_feature": curvature_guard.iloc[0].get("trust_first_feature") if len(curvature_guard) else np.nan,
        "next_action": next_action,
        "claim_status": "BENCHMARK_REFINEMENT_AUDIT_ONLY_NO_DERIVATION_CLAIM",
    })

    # State a conservative manuscript rule regardless of numeric improvement.
    rows.append({
        "decision_id": "D2",
        "decision": "DO_NOT_USE_PDGS_AS_FIT_TARGETS",
        "selected_feature_for_review": np.nan,
        "selected_qeg_value": np.nan,
        "omega_m_benchmark": 0.315,
        "selected_percent_error_true": np.nan,
        "current_primary_percent_error": primary_pct,
        "improvement_percent_points": np.nan,
        "improvement_factor": np.nan,
        "reason": "Any sharper row must be explained by internal lineage/observable logic, not benchmark minimization.",
        "cross_benchmark_guardrail_benchmarks_tracked": n_bench,
        "omega_m_guardrail_best_feature": omega_guard.iloc[0].get("trust_first_feature") if len(omega_guard) else np.nan,
        "curvature_guardrail_best_feature": curvature_guard.iloc[0].get("trust_first_feature") if len(curvature_guard) else np.nan,
        "next_action": "Use candidate table to choose a reconstruction/audit target, not to tune constants.",
        "claim_status": "METHOD_DISCIPLINE_RULE",
    })
    return pd.DataFrame(rows)


def build_review_flags(paths: Dict[str, Path], input_audit: pd.DataFrame, omega_candidates: pd.DataFrame, decision: pd.DataFrame) -> pd.DataFrame:
    flags = []
    missing = input_audit[input_audit["status"].eq("MISSING")]
    for _, r in missing.iterrows():
        flags.append({
            "flag_type": "MISSING_INPUT",
            "severity": "BLOCKER",
            "message": f"Missing required Stage-6Yj input: {r['expected_path']}",
        })
    primary_rows = omega_candidates[omega_candidates["refinement_status"].eq("CURRENT_PRIMARY_ANCHOR")]
    if not len(primary_rows):
        flags.append({
            "flag_type": "NO_PRIMARY_OMEGA_M_ANCHOR",
            "severity": "REVIEW",
            "message": "Could not identify PRIMARY_CORRECTED_COLUMN_LOCKED_ANCHOR in omega panel.",
        })
    if len(decision) and str(decision.iloc[0].get("decision", "")).startswith("REFINE_BY"):
        flags.append({
            "flag_type": "OMEGA_M_SHARP_ROW_REQUIRES_RECONSTRUCTION",
            "severity": "ACTION",
            "message": "A sharper Omega_m row exists, but it must be reproduced under corrected column locking before promotion.",
        })
    return pd.DataFrame(flags, columns=["flag_type", "severity", "message"])


def write_notes(path: Path, summary: dict, decision: pd.DataFrame) -> None:
    d1 = decision.iloc[0].to_dict() if len(decision) else {}
    text = f"""===============================================================================
STAGE-6Yk OMEGA_m PARETO REFINEMENT NOTES
Project: Quantum-Emergent Gravity
===============================================================================

VERDICT
-------
{summary['verdict']}

WHAT THIS SCRIPT DID
--------------------
Stage-6Yk audited whether the Omega_m comparison can be improved below the
Stage-6Yj corrected column-locked anchor while protecting the broader external
benchmark panel.

This was NOT a fit to PDG constants.  The script only re-scored existing
Stage-6Yj rows and classified possible improvements by trust status.

CURRENT PRIMARY OMEGA_m ANCHOR
------------------------------
feature: {summary['primary_corrected_feature']}
value:   {summary['primary_corrected_value']:.12g}
Omega_m benchmark: {summary['omega_m_benchmark']:.12g}
percent error: {summary['primary_corrected_percent_error']:.6g}%

BEST REVIEW DECISION
--------------------
decision: {d1.get('decision')}
feature:  {d1.get('selected_feature_for_review')}
value:    {d1.get('selected_qeg_value')}
percent error: {d1.get('selected_percent_error_true')}
improvement factor vs primary: {d1.get('improvement_factor')}

INTERPRETATION
--------------
If the selected feature is a repair target rather than a primary-safe candidate,
then the correct next move is not to claim a better Omega_m value.  The correct
move is to reproduce the sharper feature under the corrected column-locked
pipeline and then re-run this guardrail.

CROSS-BENCHMARK POLICY
----------------------
Other constants are protected by the Stage-6Yk benchmark guardrail table.
Future refinement should not improve Omega_m by weakening curvature, sector
ratio, sigma8/S8, or Omega_Lambda discipline.

FORBIDDEN LANGUAGE
------------------
Do not say QEG derives Omega_m.
Do not say QEG fits Omega_m.
Do not say the sharper candidate is primary unless it survives corrected-lock
reconstruction.

ALLOWED LANGUAGE
----------------
QEG contains internally generated dimensionless invariants whose Omega_m
proximity can be refined and audited under a cross-benchmark guardrail.

===============================================================================
END NOTES
===============================================================================
"""
    path.write_text(text, encoding="utf-8")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=str(DEFAULT_ROOT), help="QEG project root")
    ap.add_argument("--overwrite", action="store_true", help="overwrite existing Stage-6Yk outputs")
    args = ap.parse_args()

    root = Path(args.root).expanduser().resolve()
    outdir = root / YK_DIRNAME

    banner("Stage-6Yk Omega_m Pareto Refinement / Cross-Benchmark Guardrail")
    print(f"Project root: {root}")
    print(f"Output dir:   {outdir}")
    print("Policy: no fitting, no tuning, benchmark audit only")

    paths, input_audit = locate_inputs(root)
    ensure_output_dir(outdir, args.overwrite)
    input_audit.to_csv(outdir / "stage6Yk_input_audit.csv", index=False)

    missing = input_audit[input_audit["status"].eq("MISSING")]
    if len(missing):
        flags = build_review_flags(paths, input_audit, pd.DataFrame(), pd.DataFrame())
        flags.to_csv(outdir / "stage6Yk_review_flags.csv", index=False)
        summary = {
            "stage": "Stage-6Yk",
            "verdict": "FAILED_MISSING_STAGE6YJ_INPUTS",
            "missing_inputs": missing["expected_path"].tolist(),
            "no_fitting_policy_enforced": True,
        }
        write_json(summary, outdir / "stage6Yk_summary.json")
        print("Missing inputs; wrote review flags.")
        return 2

    raw = normalize_strings(pd.read_csv(paths["raw"]))
    omega_panel = normalize_strings(pd.read_csv(paths["omega"]))
    curvature = normalize_strings(pd.read_csv(paths["curvature"]))
    pdg = normalize_strings(pd.read_csv(paths["pdg"]))
    yj_summary = read_json(paths["summary"])

    omega_candidates, omega_meta = build_omega_candidates(raw, omega_panel)
    guardrail = build_benchmark_guardrail(raw)
    forcing = build_feature_forcing_audit(raw, omega_candidates)
    decision = build_decision_table(omega_candidates, guardrail, forcing, omega_meta)
    flags = build_review_flags(paths, input_audit, omega_candidates, decision)

    # Verdict logic.
    d0 = str(decision.iloc[0]["decision"]) if len(decision) else "NO_DECISION"
    if d0 == "UPGRADE_PRIMARY_OMEGA_M_ANCHOR_CANDIDATE":
        verdict = "A_REFINEMENT_CANDIDATE_PRIMARY_SAFE_PENDING_LEDGER_REVIEW"
    elif d0 == "SECONDARY_OMEGA_M_IMPROVEMENT_CANDIDATE":
        verdict = "A_MINUS_REFINEMENT_CANDIDATE_SECONDARY_REVIEW_REQUIRED"
    elif d0 == "REFINE_BY_REPRODUCING_SHARP_FEATURE_UNDER_CORRECTED_LOCKING":
        verdict = "A_MINUS_REFINEMENT_PATH_IDENTIFIED_RECONSTRUCTION_REQUIRED"
    else:
        verdict = "A_MINUS_PRIMARY_ANCHOR_RETAINED_NO_SAFE_REFINEMENT_FOUND"

    # Curvature guardrail quick stats.
    curv_rows = len(curvature)
    curv_within_1sigma = int(curvature.astype(str).apply(lambda col: col.str.contains("WITHIN_1SIGMA", na=False) if col.name == "uncertainty_window_status" else pd.Series(False, index=curvature.index)).any(axis=1).sum()) if "uncertainty_window_status" in curvature.columns else 0

    summary = {
        "stage": "Stage-6Yk",
        "verdict": verdict,
        "project_root": str(root),
        "output_dir": str(outdir),
        "no_fitting_policy_enforced": True,
        "source_stage6Yj_verdict": yj_summary.get("verdict"),
        "primary_corrected_feature": omega_meta["primary_corrected_feature"],
        "primary_corrected_value": omega_meta["primary_corrected_value"],
        "omega_m_benchmark": omega_meta["omega_m_benchmark"],
        "primary_corrected_percent_error": omega_meta["primary_corrected_percent_error"],
        "decision": decision.iloc[0].to_dict() if len(decision) else {},
        "omega_candidate_rows": int(len(omega_candidates)),
        "benchmark_guardrail_rows": int(len(guardrail)),
        "feature_forcing_rows": int(len(forcing)),
        "curvature_rows_seen": curv_rows,
        "curvature_within_1sigma_rows_seen": curv_within_1sigma,
        "review_flag_count": int(len(flags)),
        "review_flag_types": flags["flag_type"].tolist() if len(flags) else [],
        "required_outputs": [
            "stage6Yk_omega_m_refinement_candidates.csv",
            "stage6Yk_benchmark_guardrail_baseline.csv",
            "stage6Yk_cross_constant_feature_forcing_audit.csv",
            "stage6Yk_refinement_decision_table.csv",
            "stage6Yk_summary.json",
            "Stage-6Yk_omega_m_pareto_refinement_notes.txt",
            "stage6Yk_input_audit.csv",
            "stage6Yk_review_flags.csv",
        ],
        "forbidden_claims": [
            "QEG derives Omega_m",
            "QEG fits Omega_m",
            "QEG improves constants by tuning to PDG",
            "QEG derives Omega_K",
        ],
    }

    omega_candidates.to_csv(outdir / "stage6Yk_omega_m_refinement_candidates.csv", index=False)
    guardrail.to_csv(outdir / "stage6Yk_benchmark_guardrail_baseline.csv", index=False)
    forcing.to_csv(outdir / "stage6Yk_cross_constant_feature_forcing_audit.csv", index=False)
    decision.to_csv(outdir / "stage6Yk_refinement_decision_table.csv", index=False)
    flags.to_csv(outdir / "stage6Yk_review_flags.csv", index=False)
    write_json(summary, outdir / "stage6Yk_summary.json")
    write_notes(outdir / "Stage-6Yk_omega_m_pareto_refinement_notes.txt", summary, decision)

    print("\nWROTE OUTPUTS")
    for fname in summary["required_outputs"]:
        p = outdir / fname
        print(f"  {fname}: {'OK' if p.exists() else 'MISSING'}")
    print("\nVERDICT:", verdict)
    print("DECISION:", d0)
    print("Review flags:", len(flags))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
