#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
===============================================================================
Quantum-Emergent Gravity
Stage-6Yj: Manuscript-Axis Synthesis / Figure-Table Freeze
Author: Arturo Ortiz-Tapia
Build Date: 2026-05-25
Prepared by: ChatGPT / GPT-5.5 Thinking
===============================================================================

PURPOSE
-------
Stage-6Yj is a publication-hardening synthesis stage.  It does NOT fit QEG
features to cosmological constants.  It ingests Stage-6Yi / Stage-6Yi-v1a
outputs and produces a paper-facing result architecture:

    1) manuscript raw result table
    2) clean PDG benchmark table
    3) Omega_m refinement panel
    4) curvature / Omega_K refinement panel
    5) discrepancy/error mechanism table
    6) claim-status matrix
    7) figure/table freeze manifest
    8) manuscript-axis outline
    9) summary JSON + notes

SCIENTIFIC DISCIPLINE RULE
--------------------------
External quantities are used ONLY as benchmarks.  No external constant may be
used to tune, transform, optimize, or select QEG internals.  Near-matches are
kept with multiplicity, trust-tier, and discrepancy-mechanism context.

EXPECTED PROJECT ROOT
---------------------
    /home/dakini/Downloads/010-Quantum_Emergent_Gravity

Usage from terminal:
    python3 Stage-6Yj_manuscript_axis_synthesis_v1.py

Optional:
    python3 Stage-6Yj_manuscript_axis_synthesis_v1.py --root /path/to/root
    python3 Stage-6Yj_manuscript_axis_synthesis_v1.py --overwrite

Outputs:
    metric_stage_6Yj_outputs/

===============================================================================
"""

from __future__ import annotations

import argparse
import json
import math
import os
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd


# -----------------------------------------------------------------------------
# Fixed stage constants.  These are comparison benchmarks, not fitting targets.
# -----------------------------------------------------------------------------
STAGE = "6Yj"
DEFAULT_ROOT = Path("/home/dakini/Downloads/010-Quantum_Emergent_Gravity")
OUTDIR_NAME = "metric_stage_6Yj_outputs"

# PDG / Review of Particle Physics 2024 cosmology benchmark spine.
# Values mirror the benchmark quantities already used in the QEG ledger/handoff.
PDG_BENCHMARKS: List[Dict[str, Any]] = [
    {
        "benchmark_key": "Omega_b",
        "symbol": "Omega_b",
        "quantity": "baryon density parameter",
        "value": 0.0493,
        "uncertainty": 0.0006,
        "units": "dimensionless",
        "source": "PDG 2024 / Planck 2018 flat Lambda-CDM table",
        "benchmark_role": "sector fraction benchmark",
        "stage6Yj_policy": "benchmark_only_no_identification",
    },
    {
        "benchmark_key": "Omega_c",
        "symbol": "Omega_c",
        "quantity": "cold dark matter density parameter",
        "value": 0.265,
        "uncertainty": 0.007,
        "units": "dimensionless",
        "source": "PDG 2024 / Planck 2018 flat Lambda-CDM table",
        "benchmark_role": "sector fraction benchmark",
        "stage6Yj_policy": "benchmark_only_no_identification",
    },
    {
        "benchmark_key": "Omega_m",
        "symbol": "Omega_m",
        "quantity": "pressureless matter density parameter Omega_c + Omega_b",
        "value": 0.315,
        "uncertainty": 0.007,
        "units": "dimensionless",
        "source": "PDG 2024 / Planck 2018 flat Lambda-CDM table",
        "benchmark_role": "primary external benchmark",
        "stage6Yj_policy": "benchmark_only_no_identification",
    },
    {
        "benchmark_key": "Omega_Lambda",
        "symbol": "Omega_Lambda",
        "quantity": "dark energy density parameter",
        "value": 0.685,
        "uncertainty": 0.007,
        "units": "dimensionless",
        "source": "PDG 2024 / Planck 2018 flat Lambda-CDM table",
        "benchmark_role": "sector-complement benchmark",
        "stage6Yj_policy": "benchmark_only_no_identification",
    },
    {
        "benchmark_key": "Omega_K",
        "symbol": "Omega_K",
        "quantity": "curvature density parameter",
        "value": 0.0007,
        "uncertainty": 0.0019,
        "units": "dimensionless",
        "source": "PDG 2024 / CMB+BAO curvature table",
        "benchmark_role": "curvature / near-flatness benchmark",
        "stage6Yj_policy": "absolute_error_not_relative_error_near_zero",
    },
    {
        "benchmark_key": "h_Planck",
        "symbol": "h",
        "quantity": "reduced Hubble parameter from Planck CMB anisotropies",
        "value": 0.674,
        "uncertainty": 0.005,
        "units": "dimensionless",
        "source": "PDG 2024 / Planck 2018",
        "benchmark_role": "secondary scale benchmark",
        "stage6Yj_policy": "benchmark_only_no_identification",
    },
    {
        "benchmark_key": "h_SH0ES",
        "symbol": "h",
        "quantity": "reduced Hubble parameter from distance ladder",
        "value": 0.730,
        "uncertainty": 0.010,
        "units": "dimensionless",
        "source": "PDG 2024 / distance-ladder summary",
        "benchmark_role": "secondary scale benchmark / tension context",
        "stage6Yj_policy": "benchmark_only_no_identification",
    },
    {
        "benchmark_key": "sigma8",
        "symbol": "sigma_8",
        "quantity": "fluctuation amplitude at 8 h^-1 Mpc scale",
        "value": 0.811,
        "uncertainty": 0.006,
        "units": "dimensionless",
        "source": "PDG 2024 / Planck 2018",
        "benchmark_role": "secondary amplitude benchmark",
        "stage6Yj_policy": "benchmark_only_no_identification",
    },
    {
        "benchmark_key": "S8",
        "symbol": "S_8",
        "quantity": "sigma8 * (Omega_m/0.3)^0.5",
        "value": 0.832,
        "uncertainty": 0.013,
        "units": "dimensionless",
        "source": "PDG 2024 / Planck 2018 derived parameter",
        "benchmark_role": "hybrid clustering benchmark",
        "stage6Yj_policy": "benchmark_only_no_identification",
    },
    {
        "benchmark_key": "Lambda_cosmological_constant",
        "symbol": "Lambda",
        "quantity": "cosmological constant",
        "value": 1.088e-56,
        "uncertainty": 0.030e-56,
        "units": "cm^-2",
        "source": "PDG 2024 / Planck 2018",
        "benchmark_role": "late-stage spacetime benchmark",
        "stage6Yj_policy": "track_only_unless_semantic_calibration_exists",
    },
    {
        "benchmark_key": "rho_Lambda",
        "symbol": "rho_Lambda",
        "quantity": "dark-energy density",
        "value": 5.83e-30,
        "uncertainty": 0.16e-30,
        "units": "g cm^-3",
        "source": "PDG 2024 / Planck 2018",
        "benchmark_role": "late-stage density benchmark",
        "stage6Yj_policy": "track_only_unless_semantic_calibration_exists",
    },
]

# Add derived dimensionless ratios to the benchmark table.  They are useful for
# QEG sector-ratio comparisons and avoid silent ad hoc arithmetic later.
_omega_b = 0.0493
_omega_c = 0.265
_omega_m = 0.315
_omega_l = 0.685
PDG_DERIVED_RATIOS: List[Dict[str, Any]] = [
    {
        "benchmark_key": "Omega_b_over_Omega_m",
        "symbol": "Omega_b/Omega_m",
        "quantity": "baryon fraction within total matter",
        "value": _omega_b / _omega_m,
        "uncertainty": np.nan,
        "units": "dimensionless ratio",
        "source": "Derived from PDG 2024 Omega_b and Omega_m benchmarks",
        "benchmark_role": "sector-ratio benchmark",
        "stage6Yj_policy": "derived_benchmark_only_no_identification",
    },
    {
        "benchmark_key": "Omega_c_over_Omega_m",
        "symbol": "Omega_c/Omega_m",
        "quantity": "cold-dark-matter fraction within total matter",
        "value": _omega_c / _omega_m,
        "uncertainty": np.nan,
        "units": "dimensionless ratio",
        "source": "Derived from PDG 2024 Omega_c and Omega_m benchmarks",
        "benchmark_role": "sector-ratio benchmark",
        "stage6Yj_policy": "derived_benchmark_only_no_identification",
    },
    {
        "benchmark_key": "Omega_m_over_Omega_Lambda",
        "symbol": "Omega_m/Omega_Lambda",
        "quantity": "matter-to-dark-energy density ratio",
        "value": _omega_m / _omega_l,
        "uncertainty": np.nan,
        "units": "dimensionless ratio",
        "source": "Derived from PDG 2024 Omega_m and Omega_Lambda benchmarks",
        "benchmark_role": "sector-ratio benchmark",
        "stage6Yj_policy": "derived_benchmark_only_no_identification",
    },
    {
        "benchmark_key": "Omega_Lambda_over_Omega_m",
        "symbol": "Omega_Lambda/Omega_m",
        "quantity": "dark-energy-to-matter density ratio",
        "value": _omega_l / _omega_m,
        "uncertainty": np.nan,
        "units": "dimensionless ratio",
        "source": "Derived from PDG 2024 Omega_Lambda and Omega_m benchmarks",
        "benchmark_role": "sector-ratio benchmark",
        "stage6Yj_policy": "derived_benchmark_only_no_identification",
    },
]

ERROR_TAXONOMY: List[Dict[str, str]] = [
    {
        "mechanism": "PROFILE_LOCKING_ERROR",
        "definition": "Historical values may shift after stricter repaired/clean source locking.",
        "example_or_trigger": "Omega_m ambiguity-period row sharper than corrected column-locked row.",
        "manuscript_use": "Explain why stricter provenance may increase numerical error but increase trust.",
    },
    {
        "mechanism": "OBSERVABLE_SELECTION_ERROR",
        "definition": "Multiple QEG observables can be close to the same external comparator.",
        "example_or_trigger": "Many candidate rows target Omega_m or Omega_Lambda.",
        "manuscript_use": "Requires multiplicity disclosure and frozen/principled feature labels.",
    },
    {
        "mechanism": "SEMANTIC_CALIBRATION_ERROR",
        "definition": "A QEG number may be dimensionless and close to a PDG quantity while its physical meaning is not calibrated.",
        "example_or_trigger": "Modal density compared to matter fraction without explicit matter-sector derivation.",
        "manuscript_use": "Benchmark-only language; no derivation claim.",
    },
    {
        "mechanism": "CURVATURE_PROXY_ERROR",
        "definition": "Near-zero curvature benchmarks cannot be scored by relative error alone.",
        "example_or_trigger": "Omega_K rows, kappa-derived curvature proxies, near-flatness classes.",
        "manuscript_use": "Use absolute error, uncertainty-window status, sign, and proxy tier.",
    },
    {
        "mechanism": "LINEAGE_AGGREGATION_ERROR",
        "definition": "Pooled rows may hide family-specific drift.",
        "example_or_trigger": "BARI / NUFIT / VALENCIA provenance must remain visible where available.",
        "manuscript_use": "State family status for every manuscript row.",
    },
    {
        "mechanism": "COORDINATE_SENSITIVITY_ERROR",
        "definition": "Some features survive benign coordinates but move under aggressive remaps.",
        "example_or_trigger": "Original/rank/arc-length stable but logit/cumulative-mass sensitive.",
        "manuscript_use": "Report coordinate trust instead of hiding sensitivity.",
    },
    {
        "mechanism": "SOURCE_MECHANISM_ERROR",
        "definition": "Target law stronger than currently identified source-side generating mechanism.",
        "example_or_trigger": "Moderate source-response R^2 but strong target two-sector law.",
        "manuscript_use": "Mechanism-supported analogy only when source evidence is adequate.",
    },
    {
        "mechanism": "NULL_ADVERSARY_ERROR",
        "definition": "Repaired generic-low-k smoothing-only adversaries are real narrow caveats.",
        "example_or_trigger": "Generic low-k smoothing rows or adversarial null scorecards.",
        "manuscript_use": "Retain caveat in figure/table and claims matrix.",
    },
]

OUTPUT_FILES_REQUIRED = [
    "stage6Yj_manuscript_raw_result_table.csv",
    "stage6Yj_pdg_benchmark_table.csv",
    "stage6Yj_omega_m_refinement_panel.csv",
    "stage6Yj_curvature_refinement_panel.csv",
    "stage6Yj_error_mechanism_table.csv",
    "stage6Yj_claim_status_matrix.csv",
    "stage6Yj_figure_table_freeze_manifest.csv",
    "stage6Yj_manuscript_axis_outline.txt",
    "stage6Yj_summary.json",
    "Stage-6Yj_manuscript_axis_notes.txt",
]


# -----------------------------------------------------------------------------
# Utility helpers
# -----------------------------------------------------------------------------
def now_stamp() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def echo(msg: str = "") -> None:
    print(msg, flush=True)


def slug(text: Any) -> str:
    """Normalize strings for fuzzy matching."""
    if text is None:
        return ""
    return re.sub(r"[^a-z0-9]+", "_", str(text).strip().lower()).strip("_")


def safe_float(x: Any) -> float:
    if x is None:
        return np.nan
    if isinstance(x, (float, int, np.floating, np.integer)):
        return float(x)
    s = str(x).strip()
    if not s or s.lower() in {"nan", "none", "null", "na", "n/a", "--"}:
        return np.nan
    # Remove percent signs and common decorations, but preserve scientific notation.
    s = s.replace("%", "")
    s = re.sub(r"[^0-9eE+\-.]", "", s)
    try:
        return float(s)
    except Exception:
        return np.nan


def rel_percent_error(qeg_value: Any, benchmark_value: Any) -> float:
    q = safe_float(qeg_value)
    b = safe_float(benchmark_value)
    if not np.isfinite(q) or not np.isfinite(b) or b == 0:
        return np.nan
    return abs(q - b) / abs(b) * 100.0


def abs_error(qeg_value: Any, benchmark_value: Any) -> float:
    q = safe_float(qeg_value)
    b = safe_float(benchmark_value)
    if not np.isfinite(q) or not np.isfinite(b):
        return np.nan
    return abs(q - b)


def sign_label(x: Any, tol: float = 1e-14) -> str:
    v = safe_float(x)
    if not np.isfinite(v):
        return "UNKNOWN"
    if abs(v) <= tol:
        return "ZERO"
    return "POSITIVE" if v > 0 else "NEGATIVE"


def find_col(df: pd.DataFrame, candidates: Sequence[str] = (), contains: Sequence[str] = ()) -> Optional[str]:
    """Find a column using exact normalized candidates first, then contains."""
    if df is None or df.empty:
        return None
    norm_to_col = {slug(c): c for c in df.columns}
    for cand in candidates:
        c = norm_to_col.get(slug(cand))
        if c is not None:
            return c
    contains_norm = [slug(x) for x in contains if slug(x)]
    if contains_norm:
        for col in df.columns:
            s = slug(col)
            if any(term in s for term in contains_norm):
                return col
    return None


def row_value(row: pd.Series, candidates: Sequence[str], default: Any = "") -> Any:
    norm_to_col = {slug(c): c for c in row.index}
    for cand in candidates:
        col = norm_to_col.get(slug(cand))
        if col is not None:
            val = row.get(col)
            if not (isinstance(val, float) and np.isnan(val)):
                return val
    return default


def first_existing(root: Path, rels: Sequence[str]) -> Optional[Path]:
    for rel in rels:
        p = root / rel
        if p.exists():
            return p
    return None


def read_csv_if_exists(path: Optional[Path], label: str, audit: List[Dict[str, Any]]) -> pd.DataFrame:
    if path is None:
        audit.append({"label": label, "path": "", "exists": False, "rows": 0, "columns": "", "status": "MISSING"})
        return pd.DataFrame()
    if not path.exists():
        audit.append({"label": label, "path": str(path), "exists": False, "rows": 0, "columns": "", "status": "MISSING"})
        return pd.DataFrame()
    try:
        df = pd.read_csv(path)
        audit.append({
            "label": label,
            "path": str(path),
            "exists": True,
            "rows": int(len(df)),
            "columns": " | ".join(map(str, df.columns)),
            "status": "LOADED",
        })
        return df
    except Exception as e:
        audit.append({"label": label, "path": str(path), "exists": True, "rows": 0, "columns": "", "status": f"READ_ERROR: {e}"})
        return pd.DataFrame()


def read_json_if_exists(path: Optional[Path], label: str, audit: List[Dict[str, Any]]) -> Dict[str, Any]:
    if path is None or not path.exists():
        audit.append({"label": label, "path": str(path or ""), "exists": False, "rows": 0, "columns": "", "status": "MISSING"})
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        audit.append({"label": label, "path": str(path), "exists": True, "rows": 1, "columns": "json", "status": "LOADED"})
        return data
    except Exception as e:
        audit.append({"label": label, "path": str(path), "exists": True, "rows": 0, "columns": "json", "status": f"READ_ERROR: {e}"})
        return {}


def build_benchmark_table() -> pd.DataFrame:
    df = pd.DataFrame(PDG_BENCHMARKS + PDG_DERIVED_RATIOS)
    df["stage6Yj_role"] = "external_benchmark_spine"
    df["fitting_allowed"] = False
    return df


def benchmark_lookup(bench_df: pd.DataFrame) -> Dict[str, Dict[str, Any]]:
    lookup: Dict[str, Dict[str, Any]] = {}
    for _, row in bench_df.iterrows():
        keys = [row.get("benchmark_key"), row.get("symbol"), row.get("quantity")]
        for key in keys:
            k = slug(key)
            if k:
                lookup[k] = row.to_dict()
    # Common aliases.
    alias_pairs = {
        "omega_matter": "Omega_m",
        "omegam": "Omega_m",
        "omega_m": "Omega_m",
        "matter_density": "Omega_m",
        "pressureless_matter_density": "Omega_m",
        "omega_k": "Omega_K",
        "omegak": "Omega_K",
        "curvature": "Omega_K",
        "curvature_parameter": "Omega_K",
        "omega_lambda": "Omega_Lambda",
        "omegalambda": "Omega_Lambda",
        "omega_l": "Omega_Lambda",
        "dark_energy": "Omega_Lambda",
        "sigma_8": "sigma8",
        "sigma8": "sigma8",
        "s_8": "S8",
        "s8": "S8",
        "omega_b_over_omega_m": "Omega_b_over_Omega_m",
        "omega_c_over_omega_m": "Omega_c_over_Omega_m",
        "omega_m_over_omega_lambda": "Omega_m_over_Omega_Lambda",
    }
    key_to_row = {slug(r["benchmark_key"]): r for _, r in bench_df.iterrows()}
    for alias, canonical in alias_pairs.items():
        row = key_to_row.get(slug(canonical))
        if row is not None:
            lookup[slug(alias)] = row.to_dict()
    return lookup


def infer_benchmark(comparator: Any, lookup: Dict[str, Dict[str, Any]]) -> Tuple[str, float, str]:
    text = str(comparator or "")
    s = slug(text)
    if not s:
        return "", np.nan, ""
    # Exact alias first.
    if s in lookup:
        row = lookup[s]
        return str(row.get("benchmark_key", "")), safe_float(row.get("value")), str(row.get("source", ""))
    # Contains-based fallback.
    for key, row in lookup.items():
        if key and (key in s or s in key):
            return str(row.get("benchmark_key", "")), safe_float(row.get("value")), str(row.get("source", ""))
    # Specific robust fallback for common names.
    if "omega" in s and "k" in s:
        row = lookup.get("omega_k", {})
        return str(row.get("benchmark_key", "Omega_K")), safe_float(row.get("value", np.nan)), str(row.get("source", ""))
    if "omega" in s and ("m" in s or "matter" in s):
        row = lookup.get("omega_m", {})
        return str(row.get("benchmark_key", "Omega_m")), safe_float(row.get("value", np.nan)), str(row.get("source", ""))
    return text, np.nan, "unmatched_external_comparator_preserved"


def classify_discrepancy(row_like: Dict[str, Any]) -> str:
    """Assign the primary discrepancy mechanism.  Multiple mechanisms are noted elsewhere."""
    text = " ".join(str(row_like.get(k, "")) for k in [
        "result_axis", "stage_source", "qeg_feature", "benchmark_comparator",
        "trust_tier", "family_status", "coordinate_status", "mechanism_status",
        "notes", "source_file",
    ])
    s = slug(text)

    if "low_k" in s or "smoothing_only" in s or "advers" in s or "null" in s:
        return "NULL_ADVERSARY_ERROR"
    if "omega_k" in s or "curvature" in s or "kappa" in s or "near_flat" in s:
        return "CURVATURE_PROXY_ERROR"
    if "historical" in s or "ambiguity" in s or "column_locked" in s or "profile_lock" in s:
        return "PROFILE_LOCKING_ERROR"
    if "coordinate" in s or "arc_length" in s or "rank_uniform" in s or "logit" in s or "remap" in s:
        return "COORDINATE_SENSITIVITY_ERROR"
    if "family" in s or "bari" in s or "nufit" in s or "valencia" in s or "pooled" in s:
        return "LINEAGE_AGGREGATION_ERROR"
    if "source" in s or "operator" in s or "mechanism" in s or "rank" in s:
        return "SOURCE_MECHANISM_ERROR"
    if "candidate" in s or "multiplicity" in s or "feature" in s:
        return "OBSERVABLE_SELECTION_ERROR"
    return "SEMANTIC_CALIBRATION_ERROR"


def infer_trust_tier(row_like: Dict[str, Any]) -> str:
    s = slug(" ".join(str(v) for v in row_like.values()))
    if "tier_1" in s or "explicit" in s or "primary_corrected" in s or "column_locked" in s:
        return "TIER_1_PRINCIPLED_OR_CORRECTED"
    if "tier_2" in s or "principled" in s or "strict_scored" in s or "canonical" in s:
        return "TIER_2_STRICT_SCORED_OR_PRINCIPLED"
    if "tier_3" in s or "heuristic" in s or "unscored" in s or "exploratory" in s:
        return "TIER_3_EXPLORATORY_OR_UNSCORED"
    if "historical" in s or "ambiguity" in s:
        return "TIER_HISTORICAL_AMBIGUITY_BOOKKEEPING"
    if "missing" in s:
        return "TIER_MISSING_INPUT_REVIEW"
    return "TIER_REVIEW_REQUIRED"


def infer_manuscript_status(row_like: Dict[str, Any]) -> str:
    s = slug(" ".join(str(v) for v in row_like.values()))
    trust = slug(str(row_like.get("trust_tier", "")))
    if "reject" in s or "unsafe" in s or "overclaim" in s:
        return "REJECTED_OVERCLAIM"
    if "tier_3" in trust or "unscored" in trust or "exploratory" in trust or "missing" in trust:
        return "TRACK_ONLY"
    if "internal" in s and "benchmark" not in s:
        return "ALLOWED_INTERNAL_RESULT"
    if "operator" in s or "mechanism_supported" in s:
        return "ALLOWED_MECHANISM_SUPPORTED_ANALOGY"
    if "benchmark" in s or "omega" in s or "pdg" in s:
        return "ALLOWED_EXTERNAL_BENCHMARK"
    return "TRACK_ONLY"


def allowed_language_for(status: str) -> str:
    if status == "ALLOWED_INTERNAL_RESULT":
        return "QEG internally produces this invariant/structure under the stated lineage and audit conditions."
    if status == "ALLOWED_EXTERNAL_BENCHMARK":
        return "This QEG quantity is compared with an external benchmark; no physical identification is asserted."
    if status == "ALLOWED_MECHANISM_SUPPORTED_ANALOGY":
        return "This comparison is a mechanism-supported analogy, contingent on the stated operator evidence."
    if status == "TRACK_ONLY":
        return "Track as exploratory/transparency bookkeeping; do not use as manuscript evidence without review."
    if status == "REJECTED_OVERCLAIM":
        return "Do not use as a claim."
    return "Review before manuscript use."


def forbidden_language_for(status: str) -> str:
    common = "Do not say QEG derives, predicts, proves, or fits cosmological constants."
    if status == "ALLOWED_INTERNAL_RESULT":
        return "Do not identify internal invariants with physical constants without external calibration."
    if status == "ALLOWED_EXTERNAL_BENCHMARK":
        return common
    if status == "ALLOWED_MECHANISM_SUPPORTED_ANALOGY":
        return common + " Do not present analogy as mechanism closure."
    if status == "TRACK_ONLY":
        return common + " Do not include as main evidence."
    if status == "REJECTED_OVERCLAIM":
        return "Do not include except as an explicitly rejected overclaim."
    return common


def standardize_benchmark_rows(
    df: pd.DataFrame,
    result_axis: str,
    stage_source: str,
    source_file: str,
    lookup: Dict[str, Dict[str, Any]],
    max_rows: Optional[int] = None,
) -> pd.DataFrame:
    """Convert heterogeneous upstream benchmark tables into Stage-6Yj schema."""
    schema_cols = [
        "result_axis", "stage_source", "source_file", "source_row", "qeg_feature", "qeg_value",
        "qeg_uncertainty_or_spread", "family_status", "coordinate_status", "mechanism_status",
        "benchmark_comparator", "benchmark_key", "benchmark_value", "benchmark_source",
        "discrepancy_percent_or_abs_error", "error_metric", "discrepancy_mechanism",
        "trust_tier", "multiplicity_context", "manuscript_status", "allowed_language", "forbidden_language",
        "raw_preservation_status",
    ]
    if df is None or df.empty:
        return pd.DataFrame(columns=schema_cols)

    # Candidate column names seen across QEG scripts; robust fallbacks included.
    feature_candidates = [
        "qeg_feature", "feature", "qeg_quantity", "observable", "qeg_observable", "metric", "metric_name",
        "candidate", "candidate_feature", "name", "parameter", "quantity", "internal_feature",
    ]
    value_candidates = [
        "qeg_value", "value", "feature_value", "internal_value", "observed_value", "candidate_value",
        "qeg_observable_value", "metric_value", "parameter_value",
    ]
    spread_candidates = [
        "qeg_uncertainty_or_spread", "uncertainty", "spread", "family_spread", "std", "stddev", "sigma",
        "qeg_spread", "value_spread",
    ]
    comparator_candidates = [
        "benchmark_comparator", "external_comparator", "comparator", "pdg_quantity", "target", "target_quantity",
        "benchmark", "external_quantity", "cosmology_quantity", "physical_quantity",
    ]
    benchmark_value_candidates = [
        "benchmark_value", "external_value", "target_value", "pdg_value", "reference_value", "comparator_value",
    ]
    discrepancy_candidates = [
        "discrepancy_percent_or_abs_error", "discrepancy_percent", "percent_error", "pct_error",
        "abs_percent_error", "relative_error_percent", "absolute_error", "abs_error", "difference", "absolute_difference",
    ]
    trust_candidates = [
        "trust_tier", "tier", "proxy_tier", "score_tier", "strict_tier", "semantic_trust", "status", "scoring_status",
        "manuscript_status", "claim_status",
    ]
    family_candidates = ["family_status", "family", "FIT", "FIT_id", "family_label", "lineage", "lineage_status"]
    coord_candidates = ["coordinate_status", "coordinate", "chart", "coordinate_system", "coord_status"]
    mechanism_candidates = ["mechanism_status", "operator_status", "source_mechanism", "mechanism"]
    multiplicity_candidates = ["multiplicity_context", "multiplicity", "near_match_count", "candidate_count", "count_context"]

    rows: List[Dict[str, Any]] = []
    iterator = df.iterrows()
    if max_rows is not None:
        iterator = list(iterator)[:max_rows]

    for idx, r in iterator:
        feature = row_value(r, feature_candidates, default=f"row_{idx}")
        qval = row_value(r, value_candidates, default=np.nan)
        spread = row_value(r, spread_candidates, default="")
        comp = row_value(r, comparator_candidates, default="")
        bval_raw = row_value(r, benchmark_value_candidates, default=np.nan)
        family = row_value(r, family_candidates, default="POOLED_OR_NOT_SPECIFIED")
        coord = row_value(r, coord_candidates, default="NOT_SPECIFIED")
        mech = row_value(r, mechanism_candidates, default="NOT_SPECIFIED")
        mult = row_value(r, multiplicity_candidates, default="see upstream strict multiplicity audit")
        disc_raw = row_value(r, discrepancy_candidates, default=np.nan)

        bkey, bval_lookup, bsource = infer_benchmark(comp, lookup)
        bval = safe_float(bval_raw)
        if not np.isfinite(bval):
            bval = bval_lookup

        # Curvature / Omega_K must be handled by absolute error near zero.
        axis_text = slug(f"{result_axis} {comp} {feature}")
        if "omega_k" in axis_text or "curvature" in axis_text:
            err = abs_error(qval, bval)
            err_metric = "absolute_error_near_zero_benchmark"
        else:
            existing = safe_float(disc_raw)
            calc = rel_percent_error(qval, bval)
            err = existing if np.isfinite(existing) else calc
            err_metric = "percent_error" if np.isfinite(err) else "not_computable"

        seed = {
            "result_axis": result_axis,
            "stage_source": stage_source,
            "source_file": source_file,
            "qeg_feature": feature,
            "qeg_value": qval,
            "benchmark_comparator": comp or bkey,
            "benchmark_key": bkey,
            "benchmark_value": bval,
            "family_status": family,
            "coordinate_status": coord,
            "mechanism_status": mech,
            "trust_tier": row_value(r, trust_candidates, default=""),
            "notes": " ".join(str(v) for v in r.to_dict().values()),
        }
        trust = seed["trust_tier"] or infer_trust_tier(seed)
        seed["trust_tier"] = trust
        disc_mech = classify_discrepancy(seed)
        status = infer_manuscript_status({**seed, "discrepancy_mechanism": disc_mech})

        rows.append({
            "result_axis": result_axis,
            "stage_source": stage_source,
            "source_file": source_file,
            "source_row": int(idx) if isinstance(idx, (int, np.integer)) else str(idx),
            "qeg_feature": feature,
            "qeg_value": qval,
            "qeg_uncertainty_or_spread": spread,
            "family_status": family,
            "coordinate_status": coord,
            "mechanism_status": mech,
            "benchmark_comparator": comp or bkey,
            "benchmark_key": bkey,
            "benchmark_value": bval,
            "benchmark_source": bsource,
            "discrepancy_percent_or_abs_error": err,
            "error_metric": err_metric,
            "discrepancy_mechanism": disc_mech,
            "trust_tier": trust,
            "multiplicity_context": mult,
            "manuscript_status": status,
            "allowed_language": allowed_language_for(status),
            "forbidden_language": forbidden_language_for(status),
            "raw_preservation_status": "PRESERVED_FROM_UPSTREAM_TABLE",
        })

    out = pd.DataFrame(rows, columns=schema_cols)
    return out


def build_evidence_axis_rows(df: pd.DataFrame, source_file: str) -> pd.DataFrame:
    cols = [
        "result_axis", "stage_source", "source_file", "source_row", "qeg_feature", "qeg_value",
        "qeg_uncertainty_or_spread", "family_status", "coordinate_status", "mechanism_status",
        "benchmark_comparator", "benchmark_key", "benchmark_value", "benchmark_source",
        "discrepancy_percent_or_abs_error", "error_metric", "discrepancy_mechanism",
        "trust_tier", "multiplicity_context", "manuscript_status", "allowed_language", "forbidden_language",
        "raw_preservation_status",
    ]
    if df is None or df.empty:
        return pd.DataFrame(columns=cols)
    axis_candidates = ["evidence_axis", "axis", "claim_axis", "category", "result_axis", "section"]
    score_candidates = ["qualified_score", "score", "axis_score", "strength", "support", "qualified_support_count", "count"]
    status_candidates = ["status", "qualified_status", "support_status", "trust_tier", "verdict"]
    rows = []
    for idx, r in df.iterrows():
        axis = row_value(r, axis_candidates, default=f"evidence_axis_row_{idx}")
        score = row_value(r, score_candidates, default=np.nan)
        trust = row_value(r, status_candidates, default="TIER_1_INTERNAL_EVIDENCE_AXIS")
        seed = {"result_axis": "evidence_axis", "qeg_feature": axis, "trust_tier": trust, "notes": " ".join(map(str, r.to_dict().values()))}
        status = "ALLOWED_INTERNAL_RESULT"
        rows.append({
            "result_axis": "evidence_axis",
            "stage_source": "Stage-6Yi-v1a qualified evidence-axis inventory/scorecard",
            "source_file": source_file,
            "source_row": idx,
            "qeg_feature": axis,
            "qeg_value": score,
            "qeg_uncertainty_or_spread": "",
            "family_status": "PIPELINE_LEVEL",
            "coordinate_status": "NOT_APPLICABLE",
            "mechanism_status": "EVIDENCE_AXIS_SUPPORT",
            "benchmark_comparator": "none_internal_result",
            "benchmark_key": "",
            "benchmark_value": np.nan,
            "benchmark_source": "",
            "discrepancy_percent_or_abs_error": np.nan,
            "error_metric": "not_applicable_internal_evidence",
            "discrepancy_mechanism": classify_discrepancy(seed),
            "trust_tier": str(trust) if str(trust).strip() else "TIER_1_INTERNAL_EVIDENCE_AXIS",
            "multiplicity_context": "qualified support counts; not raw keyword counts",
            "manuscript_status": status,
            "allowed_language": allowed_language_for(status),
            "forbidden_language": forbidden_language_for(status),
            "raw_preservation_status": "PRESERVED_FROM_UPSTREAM_EVIDENCE_AXIS_TABLE",
        })
    return pd.DataFrame(rows, columns=cols)


def build_omega_m_panel(cosmology_df: pd.DataFrame, lookup: Dict[str, Dict[str, Any]]) -> pd.DataFrame:
    omega_m_value = lookup.get("omega_m", {}).get("value", 0.315)
    rows: List[Dict[str, Any]] = []

    # Contract anchor rows from Stage-6Yi final ledger.
    anchors = [
        {
            "omega_m_row_class": "HISTORICAL_AMBIGUITY_PERIOD_ANCHOR",
            "qeg_feature": "early_central_separation",
            "qeg_value": 0.317696,
            "benchmark_comparator": "Omega_m",
            "benchmark_value": omega_m_value,
            "semantic_trust_filter": "historical_bookkeeping_only",
            "trust_tier": "TIER_HISTORICAL_AMBIGUITY_BOOKKEEPING",
            "discrepancy_mechanism": "PROFILE_LOCKING_ERROR",
            "notes": "Retained as historical ambiguity-period evidence; sharper but less trustworthy than corrected column-locked value.",
        },
        {
            "omega_m_row_class": "PRIMARY_CORRECTED_COLUMN_LOCKED_ANCHOR",
            "qeg_feature": "global_mu",
            "qeg_value": 0.327995,
            "benchmark_comparator": "Omega_m",
            "benchmark_value": omega_m_value,
            "semantic_trust_filter": "primary_corrected_external_benchmark",
            "trust_tier": "TIER_1_PRINCIPLED_OR_CORRECTED",
            "discrepancy_mechanism": "PROFILE_LOCKING_ERROR",
            "notes": "Corrected column-locked Stage-6Yh/v1a value; less sharp but more trustworthy.",
        },
    ]
    for a in anchors:
        err = rel_percent_error(a["qeg_value"], a["benchmark_value"])
        status = infer_manuscript_status(a)
        rows.append({
            **a,
            "discrepancy_percent": err,
            "absolute_difference": abs_error(a["qeg_value"], a["benchmark_value"]),
            "error_metric": "percent_error_for_nonzero_dimensionless_benchmark",
            "manuscript_status": status,
            "allowed_language": allowed_language_for(status),
            "forbidden_language": forbidden_language_for(status),
            "multiplicity_context": "contract anchor; compare with strict candidate rows separately",
            "raw_preservation_status": "STAGE_6YI_CONTRACT_ANCHOR",
        })

    if cosmology_df is not None and not cosmology_df.empty:
        # Standardize if not already standardized.
        if "benchmark_key" not in cosmology_df.columns:
            # This should not normally happen here, but keep safe.
            cosmology_df = cosmology_df.copy()
        mask = pd.Series(False, index=cosmology_df.index)
        for c in cosmology_df.columns:
            sc = slug(c)
            if any(term in sc for term in ["benchmark", "comparator", "target", "pdg", "quantity", "qeg_feature", "feature"]):
                mask = mask | cosmology_df[c].astype(str).map(lambda x: "omega_m" in slug(x) or "omegam" in slug(x) or ("matter" in slug(x) and "omega" in slug(x)))
        omega_candidates = cosmology_df[mask].copy()
        for idx, r in omega_candidates.iterrows():
            qfeat = row_value(r, ["qeg_feature", "feature", "observable", "candidate", "internal_feature"], default=row_value(r, ["qeg_feature"], default=f"strict_candidate_{idx}"))
            qval = row_value(r, ["qeg_value", "feature_value", "value", "internal_value", "candidate_value"], default=np.nan)
            bval = row_value(r, ["benchmark_value", "external_value", "target_value", "pdg_value"], default=omega_m_value)
            bval = safe_float(bval)
            if not np.isfinite(bval):
                bval = omega_m_value
            trust = row_value(r, ["trust_tier", "tier", "status", "scoring_status"], default="TIER_2_STRICT_SCORED_OR_PRINCIPLED")
            seed = {
                "omega_m_row_class": "STRICT_SCORED_CANDIDATE",
                "qeg_feature": qfeat,
                "qeg_value": qval,
                "benchmark_comparator": "Omega_m",
                "benchmark_value": bval,
                "trust_tier": trust,
                "notes": " ".join(map(str, r.to_dict().values())),
            }
            mech = classify_discrepancy(seed)
            status = infer_manuscript_status({**seed, "discrepancy_mechanism": mech})
            rows.append({
                "omega_m_row_class": "STRICT_SCORED_CANDIDATE",
                "qeg_feature": qfeat,
                "qeg_value": qval,
                "benchmark_comparator": "Omega_m",
                "benchmark_value": bval,
                "semantic_trust_filter": "strict_candidate_review",
                "trust_tier": trust or "TIER_2_STRICT_SCORED_OR_PRINCIPLED",
                "discrepancy_mechanism": mech,
                "notes": "Strict candidate row preserved from v1a panel.",
                "discrepancy_percent": rel_percent_error(qval, bval),
                "absolute_difference": abs_error(qval, bval),
                "error_metric": "percent_error_for_nonzero_dimensionless_benchmark",
                "manuscript_status": status,
                "allowed_language": allowed_language_for(status),
                "forbidden_language": forbidden_language_for(status),
                "multiplicity_context": "strict candidate; disclose multiplicity from v1a audit",
                "raw_preservation_status": "PRESERVED_FROM_STRICT_SCORED_PANEL",
            })

    out = pd.DataFrame(rows)
    # Sort anchors first, then best strict candidates by trust and discrepancy.
    if "discrepancy_percent" in out.columns:
        out["_sort_err"] = out["discrepancy_percent"].apply(safe_float)
        out["_sort_class"] = out["omega_m_row_class"].map({
            "PRIMARY_CORRECTED_COLUMN_LOCKED_ANCHOR": 0,
            "HISTORICAL_AMBIGUITY_PERIOD_ANCHOR": 1,
            "STRICT_SCORED_CANDIDATE": 2,
        }).fillna(9)
        out = out.sort_values(["_sort_class", "_sort_err"], na_position="last").drop(columns=["_sort_err", "_sort_class"])
    return out


def curvature_near_flatness_class(qval: Any, bval: Any, uncertainty: float = 0.0019) -> str:
    err = abs_error(qval, bval)
    if not np.isfinite(err):
        return "UNKNOWN"
    if err <= uncertainty:
        return "WITHIN_1SIGMA_NEAR_FLAT"
    if err <= 2 * uncertainty:
        return "WITHIN_2SIGMA_NEAR_FLAT"
    if err <= 3 * uncertainty:
        return "WITHIN_3SIGMA_REVIEW"
    if abs(safe_float(qval)) <= 0.01:
        return "NEAR_ZERO_BUT_OUTSIDE_PDG_WINDOW_REVIEW"
    return "NOT_NEAR_FLAT_BY_PDG_WINDOW"


def build_curvature_panel(curv_df: pd.DataFrame, lookup: Dict[str, Dict[str, Any]]) -> pd.DataFrame:
    omega_k_row = lookup.get("omega_k", {})
    omega_k_value = safe_float(omega_k_row.get("value", 0.0007))
    omega_k_unc = safe_float(omega_k_row.get("uncertainty", 0.0019))
    rows: List[Dict[str, Any]] = []

    # Always include benchmark anchor.
    rows.append({
        "curvature_row_class": "PDG_OMEGA_K_BENCHMARK_ANCHOR",
        "qeg_feature": "external_benchmark_anchor_only",
        "qeg_value": np.nan,
        "benchmark_comparator": "Omega_K",
        "benchmark_value": omega_k_value,
        "benchmark_uncertainty": omega_k_unc,
        "absolute_error": np.nan,
        "uncertainty_window_status": "BENCHMARK_ANCHOR",
        "sign_agreement": "NOT_APPLICABLE",
        "near_flatness_class": "PDG_NEAR_FLAT_REFERENCE",
        "proxy_tier": "BENCHMARK",
        "trust_tier": "BENCHMARK_ONLY",
        "discrepancy_mechanism": "CURVATURE_PROXY_ERROR",
        "manuscript_status": "ALLOWED_EXTERNAL_BENCHMARK",
        "allowed_language": allowed_language_for("ALLOWED_EXTERNAL_BENCHMARK"),
        "forbidden_language": forbidden_language_for("ALLOWED_EXTERNAL_BENCHMARK"),
        "notes": "Do not use relative error near zero; score QEG rows by absolute error and uncertainty-window class.",
    })

    if curv_df is not None and not curv_df.empty:
        # Keep rows that look like explicit/principled curvature or Omega_K rows.
        mask = pd.Series(False, index=curv_df.index)
        for c in curv_df.columns:
            mask = mask | curv_df[c].astype(str).map(lambda x: any(term in slug(x) for term in ["omega_k", "omegak", "curvature", "kappa", "near_flat"]))
        candidates = curv_df[mask].copy()
        for idx, r in candidates.iterrows():
            qfeat = row_value(r, ["qeg_feature", "feature", "observable", "candidate", "internal_feature", "metric_name"], default=f"curvature_candidate_{idx}")
            qval = row_value(r, ["qeg_value", "feature_value", "value", "internal_value", "candidate_value", "metric_value"], default=np.nan)
            bval = row_value(r, ["benchmark_value", "external_value", "target_value", "pdg_value"], default=omega_k_value)
            bval = safe_float(bval)
            if not np.isfinite(bval):
                bval = omega_k_value
            proxy_tier = row_value(r, ["proxy_tier", "curvature_tier", "tier", "trust_tier", "status"], default=infer_trust_tier(r.to_dict()))
            err = abs_error(qval, bval)
            qsign = sign_label(qval, tol=omega_k_unc)
            bsign = sign_label(bval, tol=omega_k_unc)
            if qsign == "UNKNOWN":
                sign_agree = "UNKNOWN"
            elif bsign == "ZERO" or qsign == "ZERO":
                sign_agree = "NEAR_ZERO_SIGN_NOT_DECISIVE"
            else:
                sign_agree = "AGREES" if qsign == bsign else "DIFFERS"
            nflat = curvature_near_flatness_class(qval, bval, omega_k_unc)
            window_status = "WITHIN_1SIGMA" if np.isfinite(err) and err <= omega_k_unc else ("OUTSIDE_1SIGMA" if np.isfinite(err) else "UNKNOWN")
            seed = {
                "curvature_row_class": "QEG_CURVATURE_PROXY_CANDIDATE",
                "qeg_feature": qfeat,
                "qeg_value": qval,
                "benchmark_comparator": "Omega_K",
                "proxy_tier": proxy_tier,
                "near_flatness_class": nflat,
                "notes": " ".join(map(str, r.to_dict().values())),
            }
            trust = proxy_tier if str(proxy_tier).strip() else infer_trust_tier(seed)
            status = infer_manuscript_status({**seed, "trust_tier": trust})
            rows.append({
                "curvature_row_class": "QEG_CURVATURE_PROXY_CANDIDATE",
                "qeg_feature": qfeat,
                "qeg_value": qval,
                "benchmark_comparator": "Omega_K",
                "benchmark_value": bval,
                "benchmark_uncertainty": omega_k_unc,
                "absolute_error": err,
                "uncertainty_window_status": window_status,
                "sign_agreement": sign_agree,
                "near_flatness_class": nflat,
                "proxy_tier": proxy_tier,
                "trust_tier": trust,
                "discrepancy_mechanism": "CURVATURE_PROXY_ERROR",
                "manuscript_status": status,
                "allowed_language": allowed_language_for(status),
                "forbidden_language": forbidden_language_for(status),
                "notes": "Preserved from Stage-6Yi-v1a tiered curvature panel; absolute-error scoring only.",
            })

    out = pd.DataFrame(rows)
    if "absolute_error" in out.columns:
        out["_sort_err"] = out["absolute_error"].apply(safe_float)
        out["_sort_class"] = out["curvature_row_class"].map({"PDG_OMEGA_K_BENCHMARK_ANCHOR": 0}).fillna(1)
        out = out.sort_values(["_sort_class", "_sort_err"], na_position="last").drop(columns=["_sort_err", "_sort_class"])
    return out


def build_claim_status_matrix(existing_claims: pd.DataFrame) -> pd.DataFrame:
    base_claims = [
        {
            "claim_id": "C1",
            "claim_text": "QEG is a lineage-preserved computational emergence pipeline from PDG-origin family data to intrinsic operator geometry.",
            "claim_class": "ALLOWED_INTERNAL_RESULT",
            "evidence_basis": "Stage-4A -> Stage-5A -> Stage-6D -> Stage-6O/6P lineage repair and family-aware rebuild.",
            "minimum_language": "The construction is lineage-preserved under the documented repair branch.",
            "forbidden_language": "Do not claim raw PDG data alone imply spacetime or cosmological constants.",
        },
        {
            "claim_id": "C2",
            "claim_text": "QEG exhibits a stable two-sector/two-lobe canonical law under repaired family-aware observables.",
            "claim_class": "ALLOWED_INTERNAL_RESULT",
            "evidence_basis": "Stage-6P/6Q family universality and canonical law extraction.",
            "minimum_language": "A stable internal two-sector law is observed across the recovered families and resolutions.",
            "forbidden_language": "Do not identify the two sectors directly with baryons/dark matter without semantic calibration.",
        },
        {
            "claim_id": "C3",
            "claim_text": "QEG quantities can be compared with PDG cosmological benchmarks as dimensionless external benchmarks.",
            "claim_class": "ALLOWED_EXTERNAL_BENCHMARK",
            "evidence_basis": "Stage-6Yi/v1a strict cosmology and curvature panels.",
            "minimum_language": "Some internally generated QEG quantities fall within small percentage neighborhoods of PDG benchmarks.",
            "forbidden_language": "Do not say QEG derives, predicts, or fits those constants.",
        },
        {
            "claim_id": "C4",
            "claim_text": "The corrected Omega_m benchmark row is near the PDG value but less sharp than historical ambiguity-period bookkeeping.",
            "claim_class": "ALLOWED_EXTERNAL_BENCHMARK",
            "evidence_basis": "Stage-6Yi final contract anchors: historical early_central_separation and corrected global_mu.",
            "minimum_language": "Corrected provenance increased trust while leaving a roughly few-percent discrepancy.",
            "forbidden_language": "Do not prefer the sharper historical value without stating its lower trust status.",
        },
        {
            "claim_id": "C5",
            "claim_text": "Curvature / Omega_K comparisons require absolute-error and near-flatness scoring, not relative-error scoring.",
            "claim_class": "ALLOWED_EXTERNAL_BENCHMARK",
            "evidence_basis": "Stage-6Yi-v1a curvature-tier correction.",
            "minimum_language": "Omega_K is near zero; absolute error and uncertainty windows are the correct manuscript quantities.",
            "forbidden_language": "Do not rank near-zero curvature rows by relative percent error.",
        },
        {
            "claim_id": "C6",
            "claim_text": "The repaired generic-low-k smoothing-only adversary remains a narrow caveat.",
            "claim_class": "TRACK_ONLY",
            "evidence_basis": "Stage-6Yf/6Yg/6Yi null-hardening history.",
            "minimum_language": "A narrow smoothing-only caveat remains and is disclosed.",
            "forbidden_language": "Do not hide or soften this caveat in manuscript framing.",
        },
        {
            "claim_id": "C7",
            "claim_text": "QEG derives the Universe or physically derives cosmological constants.",
            "claim_class": "REJECTED_OVERCLAIM",
            "evidence_basis": "Semantic calibration and mechanism closure are not sufficient for this claim.",
            "minimum_language": "Rejected overclaim.",
            "forbidden_language": "Do not use this claim.",
        },
    ]
    out = pd.DataFrame(base_claims)
    out["manuscript_status"] = out["claim_class"]
    out["allowed_language"] = out["claim_class"].map(allowed_language_for)
    out["forbidden_language_general"] = out["claim_class"].map(forbidden_language_for)

    # Append upstream claims matrix if available, in preserved/review form.
    if existing_claims is not None and not existing_claims.empty:
        rows = []
        for idx, r in existing_claims.iterrows():
            text = row_value(r, ["claim_text", "claim", "statement", "result", "allowed_claim"], default=f"upstream_claim_row_{idx}")
            cls = row_value(r, ["claim_class", "status", "manuscript_status", "claim_status"], default="TRACK_ONLY")
            if str(cls).strip() == "":
                cls = "TRACK_ONLY"
            if cls not in {"ALLOWED_INTERNAL_RESULT", "ALLOWED_EXTERNAL_BENCHMARK", "ALLOWED_MECHANISM_SUPPORTED_ANALOGY", "TRACK_ONLY", "REJECTED_OVERCLAIM"}:
                cls = infer_manuscript_status({"claim": text, "status": cls})
            rows.append({
                "claim_id": f"UPSTREAM_{idx}",
                "claim_text": text,
                "claim_class": cls,
                "evidence_basis": "Preserved from Stage-6Yi publication claims matrix.",
                "minimum_language": allowed_language_for(cls),
                "forbidden_language": forbidden_language_for(cls),
                "manuscript_status": cls,
                "allowed_language": allowed_language_for(cls),
                "forbidden_language_general": forbidden_language_for(cls),
            })
        if rows:
            out = pd.concat([out, pd.DataFrame(rows)], ignore_index=True)
    return out


def build_freeze_manifest(root: Path, outdir: Path, input_paths: Dict[str, Optional[Path]]) -> pd.DataFrame:
    entries: List[Dict[str, Any]] = []

    required_output_metadata = {
        "stage6Yj_manuscript_raw_result_table.csv": ("Results / external benchmarks", "Primary paper-facing raw result table", "ZENODO_READY_AFTER_REVIEW"),
        "stage6Yj_pdg_benchmark_table.csv": ("External benchmarks", "Canonical PDG benchmark spine", "ZENODO_READY"),
        "stage6Yj_omega_m_refinement_panel.csv": ("External benchmarks", "Omega_m ambiguity/corrected/candidate comparison", "ZENODO_READY_AFTER_REVIEW"),
        "stage6Yj_curvature_refinement_panel.csv": ("External benchmarks", "Omega_K / curvature absolute-error panel", "ZENODO_READY_AFTER_REVIEW"),
        "stage6Yj_error_mechanism_table.csv": ("Methods / limitations", "Discrepancy mechanism taxonomy", "ZENODO_READY"),
        "stage6Yj_claim_status_matrix.csv": ("Claims / discussion", "Allowed vs forbidden manuscript language", "ZENODO_READY"),
        "stage6Yj_manuscript_axis_outline.txt": ("Manuscript outline", "Proposed section architecture", "GITHUB_READY"),
        "Stage-6Yj_manuscript_axis_notes.txt": ("Ledger / notes", "Stage interpretation and caveats", "GITHUB_READY"),
    }
    for fname, (section, reason, status) in required_output_metadata.items():
        entries.append({
            "file_or_source": str(outdir / fname),
            "kind": "Stage-6Yj output",
            "reason_for_inclusion": reason,
            "manuscript_section": section,
            "trust_status": "STAGE_6YJ_PRIMARY_OUTPUT",
            "zenodo_ready_status": status,
            "exists_at_manifest_time": (outdir / fname).exists(),
        })

    upstream_roles = {
        "stage6Yi_v1a_cosmology_strict": ("External benchmarks", "strict cosmology benchmark source"),
        "stage6Yi_v1a_curvature_tiered": ("External benchmarks", "tiered curvature benchmark source"),
        "stage6Yi_v1a_omega_m_audit": ("External benchmarks", "Omega_m discrepancy source"),
        "stage6Yi_v1a_evidence_inventory": ("Evidence synthesis", "qualified evidence-axis inventory"),
        "stage6Yi_v1a_axis_scorecard": ("Evidence synthesis", "qualified evidence-axis scorecard"),
        "stage6Yi_publication_claims_matrix": ("Claims / discussion", "upstream claims matrix"),
        "stage6Yi_physicaD_readiness": ("Publication strategy", "readiness panel"),
    }
    for label, path in input_paths.items():
        section, reason = upstream_roles.get(label, ("Upstream support", label))
        entries.append({
            "file_or_source": str(path) if path else "",
            "kind": "upstream input",
            "reason_for_inclusion": reason,
            "manuscript_section": section,
            "trust_status": "UPSTREAM_PRESERVED" if path and path.exists() else "MISSING_OR_OPTIONAL",
            "zenodo_ready_status": "SOURCE_DEPENDENT",
            "exists_at_manifest_time": bool(path and path.exists()),
        })
    return pd.DataFrame(entries)


def build_manuscript_outline() -> str:
    return """===============================================================================
STAGE-6Yj MANUSCRIPT-AXIS OUTLINE
Project: Quantum-Emergent Gravity
===============================================================================

I. Data lineage and construction
   - PDG-origin family data
   - BARI / NUFIT / VALENCIA lineage rule
   - Stage-4A -> Stage-5A -> Stage-6D -> Stage-6O/6P repair branch
   - No row-index family assignment

II. Intrinsic geometry
   - Intrinsic coordinate and profile construction
   - Boundary / bulk geometry
   - Coordinate robustness and coordinate sensitivity notes

III. Operator emergence
   - Nonlocal kappa -> rho evidence
   - Low-rank / asymmetric / non-Toeplitz operator structure
   - Rejection of simple local PDE and translation-invariant Green kernels

IV. Canonical two-sector law
   - Early sector
   - Central/bulk sector
   - Family universality and resolution stability
   - Internal invariant status

V. Family universality and repair history
   - Loss of family labels downstream
   - Provenance branch recovery
   - Rebuilt family-aware modal observable
   - Why stricter provenance can increase numerical discrepancy while increasing trust

VI. Recursive stabilization and null controls
   - Recursive transport audits
   - Information-geometric and null-hardening evidence
   - Repaired generic-low-k smoothing-only caveat
   - What breaks under adversarial controls

VII. External benchmark comparisons
   - PDG benchmark spine
   - Omega_m historical vs corrected column-locked comparison
   - Omega_K / curvature absolute-error and near-flatness scoring
   - Multiplicity disclosure
   - Benchmark-only language

VIII. Discussion
   - Emergent operator geometry, not overclaimed quantum gravity
   - What is internally established
   - What remains semantic calibration
   - What would upgrade the project to A+ / Physica-D-ready evidence posture

IX. Reproducibility package
   - Scripts
   - CSV / JSON output tables
   - Notes / ledgers
   - GitHub code and Zenodo data bundle
===============================================================================
"""


def build_notes(summary: Dict[str, Any]) -> str:
    return f"""===============================================================================
STAGE-6Yj MANUSCRIPT-AXIS NOTES
Project: Quantum-Emergent Gravity
Generated: {now_stamp()}
===============================================================================

VERDICT
-------
{summary.get('verdict', 'REVIEW_REQUIRED')}

WHAT THIS SCRIPT DID
--------------------
Stage-6Yj converted the Stage-6Yi / Stage-6Yi-v1a publication-hardening audit
into a manuscript-facing evidence architecture.

It produced:

1. A standardized manuscript raw result table.
2. A clean PDG benchmark table.
3. An Omega_m refinement panel preserving both the historical ambiguity-period
   row and the corrected column-locked row.
4. A curvature / Omega_K refinement panel using absolute error and
   uncertainty-window status, not relative error near zero.
5. A discrepancy mechanism taxonomy.
6. A claim-status matrix separating allowed internal results, allowed benchmark
   comparisons, track-only rows, and rejected overclaims.
7. A figure/table freeze manifest.
8. A manuscript-axis outline.

IMPORTANT INTERPRETIVE RULE
---------------------------
QEG may compare internally generated dimensionless invariants to PDG benchmark
quantities.  This script does not fit, tune, or transform QEG features to reduce
external discrepancies.

OMEGA_m STATUS
--------------
The Stage-6Yi contract anchors are preserved:

- historical ambiguity-period value:
      early_central_separation ≈ 0.317696 vs Omega_m = 0.315

- corrected column-locked value:
      global_mu ≈ 0.327995 vs Omega_m = 0.315

The sharper historical row is retained as bookkeeping.  The corrected row is
more trustworthy for manuscript-facing comparison.

CURVATURE / OMEGA_K STATUS
--------------------------
Omega_K is near zero, so relative percent error is not the primary scoring
quantity.  The curvature panel uses:

- absolute error,
- uncertainty-window status,
- sign agreement / near-zero sign review,
- near-flatness class,
- proxy tier.

CLAIM DISCIPLINE
----------------
Allowed:

    QEG identifies a reproducible emergent operator geometry from
    lineage-preserved particle-data structures, and this geometry generates
    dimensionless invariants that can be compared nontrivially against accepted
    physical/cosmological benchmark quantities.

Forbidden:

    QEG derives the Universe.
    QEG proves quantum gravity.
    QEG derives Omega_m or Omega_K.
    QEG fits cosmology.

SUMMARY COUNTS
--------------
Raw manuscript table rows: {summary.get('manuscript_raw_rows')}
Omega_m panel rows:        {summary.get('omega_m_rows')}
Curvature panel rows:      {summary.get('curvature_rows')}
Claim matrix rows:         {summary.get('claim_rows')}
Review flags:              {summary.get('review_flag_count')}

NEXT RECOMMENDED STEP
---------------------
Inspect the Stage-6Yj tables manually.  If the raw manuscript result table is
clean, the next move is a figure/table freeze ledger plus a paper-outline draft.
If review flags remain, fix the corresponding table discipline issue before
making new scientific moves.

===============================================================================
END NOTES
===============================================================================
"""


def build_review_flags(manuscript_df: pd.DataFrame, claim_df: pd.DataFrame) -> pd.DataFrame:
    flags: List[Dict[str, Any]] = []
    if manuscript_df is not None and not manuscript_df.empty:
        for idx, r in manuscript_df.iterrows():
            feature = str(r.get("qeg_feature", ""))
            status = str(r.get("manuscript_status", ""))
            comp = str(r.get("benchmark_comparator", ""))
            trust = str(r.get("trust_tier", ""))
            err_metric = str(r.get("error_metric", ""))
            if slug(feature) in {"", "unknown", "unspecified", "generic", "row", "none"} and status not in {"TRACK_ONLY", "REJECTED_OVERCLAIM"}:
                flags.append({"row": idx, "flag": "GENERIC_FEATURE_IN_NON_TRACK_ROW", "details": feature})
            if ("omega_k" in slug(comp) or "curvature" in slug(comp)) and "percent" in slug(err_metric):
                flags.append({"row": idx, "flag": "CURVATURE_ROW_USING_PERCENT_ERROR", "details": err_metric})
            if "tier_3" in slug(trust) and status not in {"TRACK_ONLY", "REJECTED_OVERCLAIM"}:
                flags.append({"row": idx, "flag": "TIER_3_ROW_NOT_TRACK_ONLY", "details": f"trust={trust}, status={status}"})

    if claim_df is not None and not claim_df.empty:
        for idx, r in claim_df.iterrows():
            text = slug(r.get("claim_text", ""))
            cls = str(r.get("claim_class", ""))
            if any(term in text for term in ["derive_the_universe", "derives_the_universe", "derive_cosmological_constants", "proves_quantum_gravity"]):
                if cls != "REJECTED_OVERCLAIM":
                    flags.append({"row": idx, "flag": "UNSAFE_CLAIM_NOT_REJECTED", "details": str(r.get("claim_text", ""))})
    return pd.DataFrame(flags)


# -----------------------------------------------------------------------------
# Main execution
# -----------------------------------------------------------------------------
def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Stage-6Yj manuscript-axis synthesis / figure-table freeze")
    parser.add_argument("--root", type=str, default=str(DEFAULT_ROOT), help="QEG project root")
    parser.add_argument("--overwrite", action="store_true", help="Allow overwriting existing Stage-6Yj output directory")
    parser.add_argument("--max-rows", type=int, default=None, help="Optional debug limit for huge upstream tables")
    args = parser.parse_args(argv)

    root = Path(args.root).expanduser().resolve()
    if not root.exists():
        echo(f"[WARN] Requested root does not exist: {root}")
        cwd = Path.cwd().resolve()
        echo(f"[INFO] Falling back to current working directory: {cwd}")
        root = cwd

    outdir = root / OUTDIR_NAME
    if outdir.exists() and any(outdir.iterdir()) and not args.overwrite:
        echo("=" * 79)
        echo("Stage-6Yj output directory already exists and is not empty.")
        echo(f"Directory: {outdir}")
        echo("Use --overwrite to regenerate outputs in place.")
        echo("=" * 79)
        return 2
    outdir.mkdir(parents=True, exist_ok=True)

    echo("=" * 79)
    echo("QEG Stage-6Yj — Manuscript-Axis Synthesis / Figure-Table Freeze")
    echo("=" * 79)
    echo(f"Project root: {root}")
    echo(f"Output dir:   {outdir}")
    echo("Policy: benchmark-only comparisons; no fitting to external constants.")
    echo("=" * 79)

    input_paths: Dict[str, Optional[Path]] = {
        "stage6Yi_summary": first_existing(root, ["metric_stage_6Yi_outputs/stage6Yi_summary.json"]),
        "stage6Yi_notes": first_existing(root, ["metric_stage_6Yi_outputs/Stage-6Yi_publication_hardening_notes.txt"]),
        "stage6Yi_cosmology_raw": first_existing(root, ["metric_stage_6Yi_outputs/stage6Yi_cosmology_benchmark_panel.csv"]),
        "stage6Yi_curvature_raw": first_existing(root, ["metric_stage_6Yi_outputs/stage6Yi_curvature_benchmark_panel.csv"]),
        "stage6Yi_feature_multiplicity": first_existing(root, ["metric_stage_6Yi_outputs/stage6Yi_feature_multiplicity_audit.csv"]),
        "stage6Yi_omega_m_audit": first_existing(root, ["metric_stage_6Yi_outputs/stage6Yi_omega_m_discrepancy_audit.csv"]),
        "stage6Yi_publication_claims_matrix": first_existing(root, ["metric_stage_6Yi_outputs/stage6Yi_publication_claims_matrix.csv"]),
        "stage6Yi_physicaD_readiness": first_existing(root, ["metric_stage_6Yi_outputs/stage6Yi_physicaD_readiness_panel.csv"]),
        "stage6Yi_evidence_inventory": first_existing(root, ["metric_stage_6Yi_outputs/stage6Yi_evidence_axis_inventory.csv"]),
        "stage6Yi_axis_scorecard": first_existing(root, ["metric_stage_6Yi_outputs/stage6Yi_axis_strength_scorecard.csv"]),
        "stage6Yi_v1a_summary": first_existing(root, ["metric_stage_6Yi_v1a_outputs/stage6Yi_v1a_summary.json"]),
        "stage6Yi_v1a_cosmology_strict": first_existing(root, ["metric_stage_6Yi_v1a_outputs/stage6Yi_v1a_cosmology_benchmark_panel_strict.csv"]),
        "stage6Yi_v1a_cosmology_scored": first_existing(root, ["metric_stage_6Yi_v1a_outputs/stage6Yi_v1a_cosmology_benchmark_panel_strict_scored_only.csv"]),
        "stage6Yi_v1a_feature_multiplicity": first_existing(root, ["metric_stage_6Yi_v1a_outputs/stage6Yi_v1a_feature_multiplicity_audit_strict.csv"]),
        "stage6Yi_v1a_curvature_tiered": first_existing(root, ["metric_stage_6Yi_v1a_outputs/stage6Yi_v1a_curvature_benchmark_panel_tiered.csv"]),
        "stage6Yi_v1a_curvature_principled": first_existing(root, ["metric_stage_6Yi_v1a_outputs/stage6Yi_v1a_curvature_benchmark_panel_principled_scored_only.csv"]),
        "stage6Yi_v1a_curvature_multiplicity": first_existing(root, ["metric_stage_6Yi_v1a_outputs/stage6Yi_v1a_curvature_tier_multiplicity_audit.csv"]),
        "stage6Yi_v1a_omega_m_audit": first_existing(root, ["metric_stage_6Yi_v1a_outputs/stage6Yi_v1a_omega_m_discrepancy_audit_strict.csv"]),
        "stage6Yi_v1a_discrepancy_ranked": first_existing(root, ["metric_stage_6Yi_v1a_outputs/stage6Yi_v1a_discrepancy_reduction_candidates_ranked.csv"]),
        "stage6Yi_v1a_discrepancy_strict": first_existing(root, ["metric_stage_6Yi_v1a_outputs/stage6Yi_v1a_discrepancy_reduction_candidates_strict_scored.csv"]),
        "stage6Yi_v1a_evidence_inventory": first_existing(root, ["metric_stage_6Yi_v1a_outputs/stage6Yi_v1a_evidence_axis_inventory_qualified.csv"]),
        "stage6Yi_v1a_axis_scorecard": first_existing(root, ["metric_stage_6Yi_v1a_outputs/stage6Yi_v1a_axis_strength_scorecard_qualified.csv"]),
    }

    input_audit: List[Dict[str, Any]] = []
    summary_v1 = read_json_if_exists(input_paths["stage6Yi_summary"], "stage6Yi_summary", input_audit)
    summary_v1a = read_json_if_exists(input_paths["stage6Yi_v1a_summary"], "stage6Yi_v1a_summary", input_audit)

    cosmology_scored = read_csv_if_exists(input_paths["stage6Yi_v1a_cosmology_scored"], "stage6Yi_v1a_cosmology_scored", input_audit)
    cosmology_strict = read_csv_if_exists(input_paths["stage6Yi_v1a_cosmology_strict"], "stage6Yi_v1a_cosmology_strict", input_audit)
    curvature_principled = read_csv_if_exists(input_paths["stage6Yi_v1a_curvature_principled"], "stage6Yi_v1a_curvature_principled", input_audit)
    curvature_tiered = read_csv_if_exists(input_paths["stage6Yi_v1a_curvature_tiered"], "stage6Yi_v1a_curvature_tiered", input_audit)
    omega_m_audit = read_csv_if_exists(input_paths["stage6Yi_v1a_omega_m_audit"], "stage6Yi_v1a_omega_m_audit", input_audit)
    discrepancy_strict = read_csv_if_exists(input_paths["stage6Yi_v1a_discrepancy_strict"], "stage6Yi_v1a_discrepancy_strict", input_audit)
    evidence_inventory = read_csv_if_exists(input_paths["stage6Yi_v1a_evidence_inventory"], "stage6Yi_v1a_evidence_inventory", input_audit)
    axis_scorecard = read_csv_if_exists(input_paths["stage6Yi_v1a_axis_scorecard"], "stage6Yi_v1a_axis_scorecard", input_audit)
    upstream_claims = read_csv_if_exists(input_paths["stage6Yi_publication_claims_matrix"], "stage6Yi_publication_claims_matrix", input_audit)
    physicaD_panel = read_csv_if_exists(input_paths["stage6Yi_physicaD_readiness"], "stage6Yi_physicaD_readiness", input_audit)

    # Build benchmark spine.
    pdg_df = build_benchmark_table()
    lookup = benchmark_lookup(pdg_df)

    # Prefer strict scored table for manuscript rows; if missing, use strict raw.
    cosmology_source_df = cosmology_scored if not cosmology_scored.empty else cosmology_strict
    cosmology_source_label = "Stage-6Yi-v1a strict scored cosmology panel" if not cosmology_scored.empty else "Stage-6Yi-v1a strict cosmology panel"
    cosmology_source_file = str(input_paths["stage6Yi_v1a_cosmology_scored"] or input_paths["stage6Yi_v1a_cosmology_strict"] or "")

    manuscript_parts: List[pd.DataFrame] = []
    manuscript_parts.append(standardize_benchmark_rows(
        cosmology_source_df,
        result_axis="cosmology_benchmark",
        stage_source=cosmology_source_label,
        source_file=cosmology_source_file,
        lookup=lookup,
        max_rows=args.max_rows,
    ))

    curvature_source_df = curvature_principled if not curvature_principled.empty else curvature_tiered
    curvature_source_label = "Stage-6Yi-v1a principled curvature scored panel" if not curvature_principled.empty else "Stage-6Yi-v1a tiered curvature panel"
    curvature_source_file = str(input_paths["stage6Yi_v1a_curvature_principled"] or input_paths["stage6Yi_v1a_curvature_tiered"] or "")
    manuscript_parts.append(standardize_benchmark_rows(
        curvature_source_df,
        result_axis="curvature_benchmark",
        stage_source=curvature_source_label,
        source_file=curvature_source_file,
        lookup=lookup,
        max_rows=args.max_rows,
    ))

    # Add evidence-axis internal rows.
    if not evidence_inventory.empty:
        manuscript_parts.append(build_evidence_axis_rows(evidence_inventory, str(input_paths["stage6Yi_v1a_evidence_inventory"] or "")))
    if not axis_scorecard.empty:
        manuscript_parts.append(build_evidence_axis_rows(axis_scorecard, str(input_paths["stage6Yi_v1a_axis_scorecard"] or "")))

    manuscript_df = pd.concat([p for p in manuscript_parts if p is not None and not p.empty], ignore_index=True) if any(not p.empty for p in manuscript_parts) else pd.DataFrame()

    # If no manuscript inputs exist, emit a minimal review skeleton rather than crashing.
    if manuscript_df.empty:
        manuscript_df = pd.DataFrame([{
            "result_axis": "review_required",
            "stage_source": "Stage-6Yj skeleton",
            "source_file": "",
            "source_row": 0,
            "qeg_feature": "MISSING_STAGE_6YI_INPUTS",
            "qeg_value": np.nan,
            "qeg_uncertainty_or_spread": "",
            "family_status": "UNKNOWN",
            "coordinate_status": "UNKNOWN",
            "mechanism_status": "INPUTS_MISSING",
            "benchmark_comparator": "none",
            "benchmark_key": "",
            "benchmark_value": np.nan,
            "benchmark_source": "",
            "discrepancy_percent_or_abs_error": np.nan,
            "error_metric": "not_applicable",
            "discrepancy_mechanism": "SEMANTIC_CALIBRATION_ERROR",
            "trust_tier": "TIER_MISSING_INPUT_REVIEW",
            "multiplicity_context": "missing upstream tables",
            "manuscript_status": "TRACK_ONLY",
            "allowed_language": allowed_language_for("TRACK_ONLY"),
            "forbidden_language": forbidden_language_for("TRACK_ONLY"),
            "raw_preservation_status": "SKELETON_ONLY",
        }])

    # Build dedicated refinement panels.
    omega_source_df = omega_m_audit if not omega_m_audit.empty else cosmology_source_df
    omega_m_panel = build_omega_m_panel(omega_source_df, lookup)
    curvature_panel = build_curvature_panel(curvature_source_df, lookup)

    error_table = pd.DataFrame(ERROR_TAXONOMY)
    # Add counts from manuscript table by mechanism.
    if not manuscript_df.empty and "discrepancy_mechanism" in manuscript_df.columns:
        counts = manuscript_df["discrepancy_mechanism"].value_counts(dropna=False).rename_axis("mechanism").reset_index(name="manuscript_row_count")
        error_table = error_table.merge(counts, on="mechanism", how="left")
        error_table["manuscript_row_count"] = error_table["manuscript_row_count"].fillna(0).astype(int)
    else:
        error_table["manuscript_row_count"] = 0

    claim_matrix = build_claim_status_matrix(upstream_claims)
    review_flags = build_review_flags(manuscript_df, claim_matrix)

    # Figure/table manifest generated before and after writing; update exists field below.
    freeze_manifest = build_freeze_manifest(root, outdir, input_paths)

    # Write outputs.
    pdg_df.to_csv(outdir / "stage6Yj_pdg_benchmark_table.csv", index=False)
    manuscript_df.to_csv(outdir / "stage6Yj_manuscript_raw_result_table.csv", index=False)
    omega_m_panel.to_csv(outdir / "stage6Yj_omega_m_refinement_panel.csv", index=False)
    curvature_panel.to_csv(outdir / "stage6Yj_curvature_refinement_panel.csv", index=False)
    error_table.to_csv(outdir / "stage6Yj_error_mechanism_table.csv", index=False)
    claim_matrix.to_csv(outdir / "stage6Yj_claim_status_matrix.csv", index=False)
    review_flags.to_csv(outdir / "stage6Yj_review_flags.csv", index=False)
    pd.DataFrame(input_audit).to_csv(outdir / "stage6Yj_input_audit.csv", index=False)

    outline = build_manuscript_outline()
    (outdir / "stage6Yj_manuscript_axis_outline.txt").write_text(outline, encoding="utf-8")

    # Refresh manifest after primary outputs exist.
    freeze_manifest = build_freeze_manifest(root, outdir, input_paths)
    freeze_manifest.to_csv(outdir / "stage6Yj_figure_table_freeze_manifest.csv", index=False)

    missing_required_inputs = [a for a in input_audit if (not a.get("exists")) and str(a.get("label", "")).startswith("stage6Yi_v1a")]
    verdict = "A_MINUS_TO_A_MANUSCRIPT_SYNTHESIS_READY_REVIEW_FLAGS_CLEAR" if len(review_flags) == 0 and len(missing_required_inputs) < 5 else "B_PLUS_REVIEW_REQUIRED_MANUSCRIPT_SYNTHESIS_BUILT"
    if manuscript_df["manuscript_status"].eq("TRACK_ONLY").all():
        verdict = "C_REVIEW_REQUIRED_INPUTS_OR_TABLE_DISCIPLINE_INCOMPLETE"

    summary = {
        "stage": "Stage-6Yj",
        "generated_at": now_stamp(),
        "project_root": str(root),
        "output_dir": str(outdir),
        "verdict": verdict,
        "no_fitting_policy_enforced": True,
        "pdg_benchmark_rows": int(len(pdg_df)),
        "manuscript_raw_rows": int(len(manuscript_df)),
        "omega_m_rows": int(len(omega_m_panel)),
        "curvature_rows": int(len(curvature_panel)),
        "error_mechanism_rows": int(len(error_table)),
        "claim_rows": int(len(claim_matrix)),
        "freeze_manifest_rows": int(len(freeze_manifest)),
        "review_flag_count": int(len(review_flags)),
        "loaded_input_count": int(sum(1 for a in input_audit if a.get("exists") and str(a.get("status", "")).startswith("LOADED"))),
        "missing_or_failed_input_count": int(sum(1 for a in input_audit if not a.get("exists") or "ERROR" in str(a.get("status", "")))),
        "summary_v1_verdict": summary_v1.get("verdict") or summary_v1.get("final_verdict") or "not_loaded",
        "summary_v1a_verdict": summary_v1a.get("verdict") or summary_v1a.get("final_verdict") or "not_loaded",
        "required_outputs": OUTPUT_FILES_REQUIRED + ["stage6Yj_input_audit.csv", "stage6Yj_review_flags.csv"],
        "omega_m_contract_anchors": {
            "historical_ambiguity_period": {"feature": "early_central_separation", "value": 0.317696, "benchmark": 0.315},
            "primary_corrected_column_locked": {"feature": "global_mu", "value": 0.327995, "benchmark": 0.315},
        },
        "curvature_policy": "absolute_error_and_uncertainty_windows_not_relative_percent_error_near_zero",
        "forbidden_claims": [
            "QEG derives the Universe",
            "QEG proves quantum gravity",
            "QEG derives Omega_m",
            "QEG derives Omega_K",
            "QEG fits cosmology",
        ],
    }

    (outdir / "stage6Yj_summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    notes = build_notes(summary)
    (outdir / "Stage-6Yj_manuscript_axis_notes.txt").write_text(notes, encoding="utf-8")

    echo("\nStage-6Yj outputs written:")
    for fname in OUTPUT_FILES_REQUIRED + ["stage6Yj_input_audit.csv", "stage6Yj_review_flags.csv"]:
        p = outdir / fname
        echo(f"  - {p.relative_to(root) if str(p).startswith(str(root)) else p}")

    echo("\nSummary:")
    echo(json.dumps({
        "verdict": verdict,
        "manuscript_raw_rows": summary["manuscript_raw_rows"],
        "omega_m_rows": summary["omega_m_rows"],
        "curvature_rows": summary["curvature_rows"],
        "review_flag_count": summary["review_flag_count"],
        "loaded_input_count": summary["loaded_input_count"],
        "missing_or_failed_input_count": summary["missing_or_failed_input_count"],
    }, indent=2))

    if len(review_flags) > 0:
        echo("\n[REVIEW] Review flags were written to stage6Yj_review_flags.csv")
    echo("=" * 79)
    echo("Stage-6Yj complete.")
    echo("=" * 79)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        echo("\nInterrupted by user.")
        raise SystemExit(130)
