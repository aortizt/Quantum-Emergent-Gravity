#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Stage-7E-v3_result_spine_audit.py

Quantum-Emergent Gravity (QEG)
Stage-7E-v3: Result-Spine Audit and GitHub Folder Manifest

Purpose
-------
Stage-7E-v2 produced a useful milestone-based run sequence. However, a
GitHub/Zenodo release should not be governed only by "one script per
milestone." It must also prove that the major manuscript-facing results are
covered.

This script therefore performs a result-enforced audit.

It reads the Stage-7E-v2 outputs and checks coverage of the headline QEG
result spine:

1. family-root geometry and metric candidates
2. symmetry-breaking / admissibility geometry
3. rho/kappa intrinsic fields
4. nonlocal rho-kappa operator geometry
5. canonical two-lobe law and family universality
6. recursive / mechanism hardening
7. cosmology-proximity bookkeeping, especially Omega_m-like results
8. time surrogate / entropy / irreversibility evidence
9. Stage-7D GR-adjacent appendix: Friedmann, Lambda, dark energy, acceleration
10. repository compression / reproducibility

The script does NOT rerun science scripts.
The script does NOT edit existing QEG files.
The script does NOT claim physics.
It creates GitHub-preparation manifests and review notes.

Default project root:
    /home/dakini/Downloads/010-Quantum_Emergent_Gravity

Default v2 input dir:
    <root>/metric_stage_7E_outputs/canonical_run_sequence_builder_v2

Default output dir:
    <root>/metric_stage_7E_outputs/result_spine_audit_v3

Typical use
-----------
    cd /home/dakini/Downloads/010-Quantum_Emergent_Gravity/metric_stage_7E_scripts
    python3 Stage-7E-v3_result_spine_audit.py

Key outputs
-----------
    stage7E_v3_result_spine_coverage.csv
    stage7E_v3_minimal_github_manifest.csv
    stage7E_v3_expanded_github_manifest.csv
    stage7E_v3_github_copy_plan.csv
    stage7E_v3_result_to_script_map.md
    stage7E_v3_critical_review_notes.md
    stage7E_v3_summary.json
    stage7E_v3_ledger_note.txt
    stage7E_v3_ascii_transition_package.txt

Interpretive rule
-----------------
If v2 selected a plausible milestone script but the major-result spine needs
additional scripts to substantiate a headline result, v3 classifies those
additional scripts as result-critical supplements rather than forcing them
into the minimal linear run sequence.
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import re
import sys
from collections import defaultdict, OrderedDict
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple


DEFAULT_ROOT = Path("/home/dakini/Downloads/010-Quantum_Emergent_Gravity")


# ---------------------------------------------------------------------------
# Utility
# ---------------------------------------------------------------------------

def now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def read_csv_rows(path: Path) -> List[dict]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8", errors="replace") as f:
        return list(csv.DictReader(f))


def write_csv(path: Path, rows: Sequence[dict], fieldnames: Optional[Sequence[str]] = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if fieldnames is None:
        fieldnames = []
        seen = set()
        for row in rows:
            for key in row.keys():
                if key not in seen:
                    fieldnames.append(key)
                    seen.add(key)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(fieldnames), extrasaction="ignore")
        w.writeheader()
        for row in rows:
            w.writerow(row)


def write_json(path: Path, obj: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding="utf-8")


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(s).lower()).strip("_")


def compact(s: object, n: int = 500) -> str:
    x = re.sub(r"\s+", " ", str(s or "")).strip()
    return x if len(x) <= n else x[: n - 3] + "..."


def stage_from_path(path: str) -> str:
    s = str(path)
    m = re.search(r"stage[-_]?([0-9]+[A-Za-z]?)", s, re.I)
    if m:
        return "Stage-" + m.group(1).upper()
    m = re.search(r"Stage[-_]?([0-9]+[A-Za-z]?)", s, re.I)
    if m:
        return "Stage-" + m.group(1).upper()
    return ""


def version_key(path: str) -> Tuple[int, int, int, str]:
    """
    Higher is better. Handles v1, v1a, v2, v10, plus explicit stage-7C-v1o style.
    """
    base = Path(str(path)).name.lower()
    matches = re.findall(r"v([0-9]+)([a-z]?)", base)
    if not matches:
        return (-1, -1, 0, base)
    # use last version token, usually most specific
    num_s, letter = matches[-1]
    num = int(num_s)
    letter_val = ord(letter) - 96 if letter else 0
    return (num, letter_val, len(matches), base)


def score_float(row: dict, key: str, default: float = 0.0) -> float:
    try:
        x = row.get(key, default)
        if x in ("", None):
            return default
        return float(x)
    except Exception:
        return default


def split_semicolon(s: object) -> List[str]:
    if not s:
        return []
    return [x.strip() for x in str(s).split(";") if x.strip()]


# ---------------------------------------------------------------------------
# Result-spine definitions
# ---------------------------------------------------------------------------

@dataclass
class ResultSpine:
    result_id: str
    title: str
    manuscript_question: str
    result_claim_class: str
    minimal_milestones: List[str]
    preferred_script_patterns: List[str]
    result_critical_patterns: List[str]
    control_patterns: List[str]
    appendix_patterns: List[str]
    representative_output_keywords: List[str]
    github_folder: str
    notes: str


RESULT_SPINE: List[ResultSpine] = [
    ResultSpine(
        result_id="R01_family_geometry_metric_candidates",
        title="Family-root geometry and metric candidates",
        manuscript_question="How do BARI / NUFIT / VALENCIA roots enter the pipeline, and how does Stage-5/6 build metric candidates from them?",
        result_claim_class="data_lineage_and_intrinsic_geometry",
        minimal_milestones=[
            "M01_stage4_family_roots_shellbands",
            "M02_stage4B_alpha_beta_commnorm",
            "M03_stage4C_optionA_canonical_microfeatures",
            "M04_stage4D_transport_obstruction",
            "M05_stage5A_bridge_from_4D",
            "M06_stage5B_enriched_PCA_metric_candidate",
            "M07_stage5C_intrinsic_coordinate",
            "M08_stage5D_frozen_coordinate",
            "M09_stage6A_candidate_metrics",
            "M10_stage6B_metric_evaluation",
        ],
        preferred_script_patterns=[
            "stage4a_shellbands",
            "stage4b_beta_holonly_from_commnorm",
            "stage-4c_real_option-a_v5",
            "stage4d_transport_layers",
            "stage5a_bridge_from_stage4d_v1b2",
            "global_pc1",
            "intrinsic_coordinate_from_pc1_pc2_v4",
            "formalize_preferred_intrinsic_coordinate_v1b",
            "construct_candidate_metrics_from_stage5_coordinate",
            "evaluate_candidate_metrics_from_stage6a",
        ],
        result_critical_patterns=[],
        control_patterns=[],
        appendix_patterns=[],
        representative_output_keywords=[
            "stage4A_shellbands_BARI",
            "stage4C_microfeatures_canonical",
            "stage5D_formalized_preferred_intrinsic_coordinate_v1b",
            "stage6A_metric_candidates_pairwise_distances",
            "stage6B_metric_evaluation_table",
        ],
        github_folder="scripts/mainline/01_family_geometry_metric_candidates",
        notes="This is the minimal staircase from PDG-origin family roots to frozen coordinate and metric candidates.",
    ),
    ResultSpine(
        result_id="R02_symmetry_breaking_admissibility_geometry",
        title="Symmetry breaking and admissibility-boundary geometry",
        manuscript_question="Where does the metric/admissibility geometry show common support, symmetry breaking, curved boundary structure, and intrinsic curvature?",
        result_claim_class="metric_geometry_and_symmetry_breaking",
        minimal_milestones=[
            "M11_stage6C_gauge_admissibility",
            "M12_stage6D_boundary_geometry",
            "M13_stage6D_branch1_refined_boundary",
            "M14_stage6E_boundary_law",
            "M15_stage6F_curvature_geometry",
            "M16_stage6G_intrinsic_boundary",
        ],
        preferred_script_patterns=[
            "normalization_and_gauge_analysis_v2",
            "stage-6d_v2",
            "branch1_refined_boundary_v3",
            "fit_boundary_law_v1b",
            "curvature_geometry_v1c",
            "intrinsic_boundary_geometry_v1b",
        ],
        result_critical_patterns=[],
        control_patterns=[],
        appendix_patterns=[],
        representative_output_keywords=[
            "stage6C_metric_invariance_table_v2",
            "stage6D_branch1_boundary_estimate",
            "stage6E_boundary_function_fit_v1b",
            "stage6F_curvature_profile",
            "stage6G_intrinsic_profile",
        ],
        github_folder="scripts/mainline/02_symmetry_breaking_admissibility_geometry",
        notes="This covers the result that admissibility/domain restrictions act as a symmetry-breaking source of geometry.",
    ),
    ResultSpine(
        result_id="R03_rho_kappa_intrinsic_fields",
        title="Emergence of intrinsic rho/kappa fields",
        manuscript_question="How are intrinsic curvature-like kappa(s) and density-like rho(s) fields constructed and made distributional rather than sector-label dependent?",
        result_claim_class="intrinsic_field_construction",
        minimal_milestones=[
            "M17_stage6H_distributional_invariants",
            "M18_stage6I_operator_diagnostics",
        ],
        preferred_script_patterns=[
            "intrinsic_distributional_invariants",
            "operator_response_suite",
        ],
        result_critical_patterns=[],
        control_patterns=[],
        appendix_patterns=[],
        representative_output_keywords=[
            "stage6H_distributional_profile",
            "stage6I_operator_profile",
            "stage6I_operator_summary",
        ],
        github_folder="scripts/mainline/03_rho_kappa_intrinsic_fields",
        notes="This is the point where rho/kappa become explicit intrinsic objects rather than loose labels.",
    ),
    ResultSpine(
        result_id="R04_nonlocal_rho_kappa_operator",
        title="Nonlocal rho/kappa operator geometry",
        manuscript_question="How is local closure rejected, and how is a nonlocal kappa-to-rho operator recovered and compressed?",
        result_claim_class="nonlocal_operator_geometry",
        minimal_milestones=[
            "M18_stage6I_operator_diagnostics",
            "M19_stage6J_nonlocal_operator",
            "M20_stage6K_operator_reduction",
            "M21_stage6L_pde_negative_result",
        ],
        preferred_script_patterns=[
            "operator_response_suite",
            "intrinsic_nonlocal_response_geometry",
            "canonical_operator_reduction",
            "continuum_law_pde_analogue",
        ],
        result_critical_patterns=[],
        control_patterns=[],
        appendix_patterns=[],
        representative_output_keywords=[
            "stage6J_kernel_matrix_best",
            "stage6K_rank_reconstruction_table",
            "stage6L_continuum_summary",
            "stage6L_pde_fit_comparison",
        ],
        github_folder="scripts/mainline/04_nonlocal_operator_geometry",
        notes="Includes the important negative result: ordinary local PDE / simple Green closures are not the primary explanation.",
    ),
    ResultSpine(
        result_id="R05_two_lobe_law_family_universality",
        title="Two-lobe law and family universality",
        manuscript_question="How is the early+central two-lobe law discovered, formalized, repaired for family provenance, and accepted as family-universal?",
        result_claim_class="canonical_two_sector_law",
        minimal_milestones=[
            "M22_stage6M_targeted_two_lobe",
            "M23_stage6N_canonical_two_lobe_law",
            "M24_stage6O_family_lineage_repair",
            "M25_stage6P_family_universality_lock",
            "M26_stage6Q_canonical_law_extraction",
        ],
        preferred_script_patterns=[
            "targeted_modal_resolution_v2c",
            "canonical_two_lobe_law_v1a",
            "direct_modal_rho_provenance_audit",
            "two_lobe_universality_test_on_v5_candidate_v6",
            "canonical_law_extraction_v1",
        ],
        result_critical_patterns=[
            "family_universality",
            "v5_candidate_v6",
        ],
        control_patterns=[],
        appendix_patterns=[],
        representative_output_keywords=[
            "stage6M_targeted_v2c_model_comparison",
            "stage6N_canonical_two_lobe_profile",
            "stage6P_v6_family_lobe_parameters",
            "stage6Q_canonical_curve",
            "stage6Q_dimensionless_ratios",
        ],
        github_folder="scripts/mainline/05_two_lobe_law_family_universality",
        notes="This is the central publishable structural result: rho(s) approx E(s)+C(s), family-preserving.",
    ),
    ResultSpine(
        result_id="R06_mechanism_and_recursive_stability",
        title="Mechanism narrowing and recursive stability",
        manuscript_question="How are tautological reconstructions excluded, source-side mechanisms narrowed, and recursive transport stability hardened?",
        result_claim_class="controls_and_recursive_hardening",
        minimal_milestones=[
            "M27_stage6R_operator_interpretation",
            "M28_stage6S_mechanism_stability",
            "M29_stage6T_source_probe_freeze",
            "M30_stage6Y_recursive_transport_stability",
        ],
        preferred_script_patterns=[
            "operator_interpretation_layer_v2",
            "mechanism_stability_operator_probes",
            "composite_probe_freeze_amplitude_calibration_v4",
            "manuscript_freeze_provenance_clarification_v1a",
        ],
        result_critical_patterns=[
            "Stage-6Yc_branchA_scientific_claims_hardened_recursion_v1a",
            "Stage-6Yi_publication_hardening_cross_evidence_audit_v1a",
            "Stage-6Yn_manuscript_freeze_provenance_clarification_v1a",
        ],
        control_patterns=[
            "Stage-6S_mechanism_stability_operator_probes",
            "Stage-6T_composite_probe_freeze_amplitude_calibration",
            "Stage-6Yc_branchA_scientific_claims_hardened_recursion",
        ],
        appendix_patterns=[],
        representative_output_keywords=[
            "stage6R_interpretation_notes",
            "stage6S",
            "stage6T",
            "recursive",
            "null",
            "adversarial",
        ],
        github_folder="scripts/controls/01_mechanism_recursive_stability",
        notes="This result should not be buried. It is not just optional: it supports non-tautology, recursive stability, and adversarial hardening.",
    ),
    ResultSpine(
        result_id="R07_cosmology_proximity_bookkeeping",
        title="Cosmological-proximity bookkeeping, including Omega_m-like results",
        manuscript_question="Which internally generated dimensionless QEG invariants land near PDG/Planck-style cosmological benchmarks, especially Omega_m including dark matter, without claiming derivation?",
        result_claim_class="comparison_bookkeeping_not_identification",
        minimal_milestones=[
            "M26_stage6Q_canonical_law_extraction",
            "M27_stage6R_operator_interpretation",
            "M30_stage6Y_recursive_transport_stability",
            "M31_stage7A_semantic_calibration",
        ],
        preferred_script_patterns=[
            "canonical_law_extraction",
            "operator_interpretation_layer_v2",
            "publication_hardening_cross_evidence_audit_v1a",
            "manuscript_axis_synthesis_v1",
            "omega_m_pareto_refinement_v1",
            "corrected_lock_omega_m_reconstruction_v1",
            "semantic_calibration_entropic_arrow",
        ],
        result_critical_patterns=[
            "Stage-6Yi_publication_hardening_cross_evidence_audit_v1a",
            "Stage-6Yj_manuscript_axis_synthesis_v1",
            "Stage-6Yk_omega_m_pareto_refinement_v1",
            "Stage-6Yl_corrected_lock_omega_m_reconstruction_v1",
            "Stage-6Yn_manuscript_freeze_provenance_clarification_v1a",
        ],
        control_patterns=[],
        appendix_patterns=[],
        representative_output_keywords=[
            "omega_m",
            "cosmology",
            "strict near-match",
            "Omega_m",
            "curvature",
            "raw cosmology rows",
        ],
        github_folder="scripts/result_supplements/01_cosmology_proximity_bookkeeping",
        notes="V2 under-promotes this spine. These scripts should appear as result-critical supplements, not as detective work for the reader.",
    ),
    ResultSpine(
        result_id="R08_time_surrogate_entropy_irreversibility",
        title="Time surrogate, entropy, and irreversibility evidence",
        manuscript_question="How are entropy-state-space evidence, operator directionality, forward/reverse recursion, low-k evidence, and partial-reversibility sandbox separated?",
        result_claim_class="time_surrogate_evidence_not_cosmic_time_derivation",
        minimal_milestones=[
            "M31_stage7A_semantic_calibration",
            "M32_stage7B_time_surrogate_irreversibility",
            "M33_stage7C_evidence_hardening",
        ],
        preferred_script_patterns=[
            "semantic_calibration_entropic_arrow",
            "time_surrogate_robustness_operator_irreversibility",
            "one_script_to_rule_time_surrogate_evidence",
            "manuscript_evidence_hardening",
            "unknown_survivor_friedmann_transition",
        ],
        result_critical_patterns=[
            "Stage-7C-v1m_one_script_to_rule_time_surrogate_evidence",
            "Stage-7C-v1n_manuscript_evidence_hardening",
            "Stage-7C-v1o_unknown_survivor_friedmann_transition",
        ],
        control_patterns=[
            "regenerate_forward_backward_lowk_pairs",
            "witness_class_reconstruction_valid_denominator",
            "textual_evidence_triage",
        ],
        appendix_patterns=[],
        representative_output_keywords=[
            "entropy",
            "time_surrogate",
            "irreversibility",
            "forward_reverse",
            "lowk",
            "partial_reversibility",
        ],
        github_folder="scripts/controls/02_time_entropy_irreversibility",
        notes="The entropy channel must be preserved separately from partial-reversibility and low-k review channels.",
    ),
    ResultSpine(
        result_id="R09_stage7D_gr_appendix_lambda_acceleration",
        title="Stage-7D GR-adjacent appendix: Friedmann, Lambda, dark energy, acceleration",
        manuscript_question="How are Friedmann-style density/curvature/time substitutions, Lambda/dark-energy proximity, and acceleration proxies preserved as appendix-only bookkeeping?",
        result_claim_class="appendix_only_gr_adjacent_bookkeeping",
        minimal_milestones=[
            "M34_stage7D_appendix_bundle",
        ],
        preferred_script_patterns=[
            "Stage-7D_v2_friedmann_appendix_polishing",
            "Stage-7D_v3_dark_energy_closure_exploratory",
            "Stage-7D_v4_acceleration_proxy_audit",
            "Friedmann_curvature_density_time_probe",
        ],
        result_critical_patterns=[
            "Stage-7D_v2_friedmann_appendix_polishing",
            "Stage-7D_v3_dark_energy_closure_exploratory",
            "Stage-7D_v4_acceleration_proxy_audit",
            "Stage-7D_Friedmann_curvature_density_time_probe_v1",
        ],
        control_patterns=[],
        appendix_patterns=[
            "Stage-7D",
            "Friedmann",
            "dark_energy",
            "acceleration",
            "lambda",
        ],
        representative_output_keywords=[
            "friedmann",
            "lambda",
            "dark_energy",
            "acceleration",
            "appendix",
        ],
        github_folder="scripts/appendix_gr_adjacent/stage7D",
        notes="This must stay appendix-only, but the bundle should include the Lambda/dark-energy and acceleration scripts if they are separate.",
    ),
    ResultSpine(
        result_id="R10_repository_reproducibility_compression",
        title="Repository compression and reproducibility manifests",
        manuscript_question="Which Stage-7E scripts produce the inventory, crosswalk, result-spine audit, README skeleton, and GitHub/Zenodo manifests?",
        result_claim_class="reproducibility_infrastructure",
        minimal_milestones=[
            "M35_stage7E_repository_compression",
        ],
        preferred_script_patterns=[
            "Stage-7E-v1_project_inventory_ledger_crosswalk",
            "Stage-7E-v2_canonical_run_sequence_builder",
            "Stage-7E-v3_result_spine_audit",
        ],
        result_critical_patterns=[
            "Stage-7E-v1_project_inventory_ledger_crosswalk",
            "Stage-7E-v2_canonical_run_sequence_builder",
            "Stage-7E-v3_result_spine_audit",
        ],
        control_patterns=[],
        appendix_patterns=[],
        representative_output_keywords=[
            "stage7E_v1_script_inventory",
            "stage7E_v2_canonical_run_manifest",
            "stage7E_v3_result_spine_coverage",
        ],
        github_folder="scripts/reproducibility",
        notes="V3 itself will not be present in v2 inventory; it is expected to be copied manually after generation.",
    ),
]


# ---------------------------------------------------------------------------
# Data loading and matching
# ---------------------------------------------------------------------------

@dataclass
class ScriptRecord:
    source: str
    script_relpath: str
    basename: str
    milestone_id: str
    run_order: str
    paper_unit: str
    manifest_role: str
    selection_status: str
    selection_score: float
    ledger_mention_count: int
    v1_candidate_output_links: int
    deprecated_status: str
    top_crosswalk_outputs: str
    reason: str


def record_from_row(source: str, row: dict) -> Optional[ScriptRecord]:
    rel = (row.get("selected_script_relpath") or row.get("script_relpath") or row.get("matched_inventory_relpath") or "").strip()
    if not rel or rel.lower() == "nan":
        return None
    return ScriptRecord(
        source=source,
        script_relpath=rel,
        basename=Path(rel).name,
        milestone_id=str(row.get("milestone_id", "")),
        run_order=str(row.get("run_order", "")),
        paper_unit=str(row.get("paper_unit", "")),
        manifest_role=str(row.get("manifest_role", "")),
        selection_status=str(row.get("selection_status", "")),
        selection_score=score_float(row, "selection_score", score_float(row, "score", 0.0)),
        ledger_mention_count=int(score_float(row, "ledger_mention_count", 0)),
        v1_candidate_output_links=int(score_float(row, "v1_candidate_output_links", 0)),
        deprecated_status=str(row.get("deprecated_status", "")),
        top_crosswalk_outputs=str(row.get("top_crosswalk_outputs", "")),
        reason=str(row.get("selection_reasons", row.get("reasons", ""))),
    )


def load_records(v2_dir: Path) -> Tuple[List[ScriptRecord], Dict[str, List[dict]]]:
    files = {
        "canonical": "stage7E_v2_canonical_run_manifest.csv",
        "control": "stage7E_v2_control_manifest.csv",
        "appendix": "stage7E_v2_appendix_manifest.csv",
        "rescue": "stage7E_v2_rescue_provenance_manifest.csv",
        "candidates": "stage7E_v2_milestone_candidate_scores.csv",
        "mentions": "stage7E_v2_ledger_script_mentions.csv",
    }
    raw = {k: read_csv_rows(v2_dir / fn) for k, fn in files.items()}

    records: List[ScriptRecord] = []

    for source in ["canonical", "control", "appendix", "rescue"]:
        for row in raw[source]:
            rec = record_from_row(source, row)
            if rec:
                records.append(rec)

    # Candidate scores use script_relpath, not selected_script_relpath.
    for row in raw["candidates"]:
        rel = (row.get("script_relpath") or "").strip()
        if not rel:
            continue
        records.append(ScriptRecord(
            source="candidate_score",
            script_relpath=rel,
            basename=Path(rel).name,
            milestone_id=str(row.get("milestone_id", "")),
            run_order=str(row.get("milestone_order", "")),
            paper_unit="candidate_for_" + str(row.get("milestone_id", "")),
            manifest_role="candidate_score_pool",
            selection_status="candidate_not_auto_selected",
            selection_score=score_float(row, "score", 0.0),
            ledger_mention_count=int(score_float(row, "ledger_mention_count", 0)),
            v1_candidate_output_links=int(score_float(row, "v1_candidate_output_links", 0)),
            deprecated_status=str(row.get("deprecated_status", "")),
            top_crosswalk_outputs="",
            reason=str(row.get("reasons", "")),
        ))

    for row in raw["mentions"]:
        rel = (row.get("matched_inventory_relpath") or "").strip()
        if not rel:
            continue
        records.append(ScriptRecord(
            source="ledger_mention",
            script_relpath=rel,
            basename=Path(rel).name,
            milestone_id="",
            run_order="",
            paper_unit="ledger_mention",
            manifest_role="ledger_mention",
            selection_status=str(row.get("match_confidence", "")),
            selection_score=20.0,
            ledger_mention_count=1,
            v1_candidate_output_links=0,
            deprecated_status="",
            top_crosswalk_outputs="",
            reason=compact(row.get("context", ""), 300),
        ))

    return records, raw


def dedupe_records(records: Iterable[ScriptRecord]) -> List[ScriptRecord]:
    best: Dict[str, ScriptRecord] = {}
    for rec in records:
        key = rec.script_relpath
        if key not in best:
            best[key] = rec
            continue
        prev = best[key]
        # Prefer selected records, then higher score, then later version.
        prev_selected = 1 if prev.source in {"canonical", "control", "appendix", "rescue"} else 0
        rec_selected = 1 if rec.source in {"canonical", "control", "appendix", "rescue"} else 0
        prev_key = (prev_selected, prev.selection_score, version_key(prev.script_relpath))
        rec_key = (rec_selected, rec.selection_score, version_key(rec.script_relpath))
        if rec_key > prev_key:
            best[key] = rec
    return list(best.values())


def match_patterns(records: Sequence[ScriptRecord], patterns: Sequence[str]) -> List[ScriptRecord]:
    if not patterns:
        return []
    out = []
    norm_patterns = [norm(p) for p in patterns]
    for rec in records:
        target = norm(rec.script_relpath + " " + rec.basename + " " + rec.reason)
        if any(p and p in target for p in norm_patterns):
            out.append(rec)
    out = dedupe_records(out)
    out.sort(key=lambda r: (r.source in {"canonical", "control", "appendix"}, r.selection_score, version_key(r.script_relpath)), reverse=True)
    return out


def selected_by_milestone(records: Sequence[ScriptRecord], milestone_ids: Sequence[str]) -> List[ScriptRecord]:
    selected = []
    wanted = set(milestone_ids)
    for rec in records:
        if rec.source in {"canonical", "control", "appendix", "rescue"} and rec.milestone_id in wanted:
            selected.append(rec)
    return dedupe_records(selected)


def classify_github_role(result: ResultSpine, rec: ScriptRecord, is_supplement: bool = False) -> str:
    lower = norm(rec.script_relpath)
    if "stage_7d" in lower or "stage_7d" in lower or "friedmann" in lower or result.result_id.startswith("R09"):
        return "appendix_gr_adjacent"
    if result.result_id in {"R06_mechanism_and_recursive_stability", "R08_time_surrogate_entropy_irreversibility"}:
        return "control_or_hardening"
    if is_supplement or result.result_id == "R07_cosmology_proximity_bookkeeping":
        return "result_critical_supplement"
    if rec.source == "rescue":
        return "rescue_provenance"
    if result.result_id == "R10_repository_reproducibility_compression":
        return "reproducibility"
    return "mainline_core"


def target_folder_for_role(role: str, result: ResultSpine) -> str:
    if role == "mainline_core":
        return result.github_folder
    if role == "control_or_hardening":
        return result.github_folder
    if role == "result_critical_supplement":
        return result.github_folder
    if role == "appendix_gr_adjacent":
        return "scripts/appendix_gr_adjacent/stage7D"
    if role == "rescue_provenance":
        return "scripts/rescue_provenance"
    if role == "reproducibility":
        return "scripts/reproducibility"
    return "scripts/manual_review"


def script_to_manifest_row(
    result: ResultSpine,
    rec: ScriptRecord,
    role: str,
    inclusion_level: str,
    reason: str,
    rank: int,
) -> dict:
    return {
        "result_id": result.result_id,
        "result_title": result.title,
        "inclusion_level": inclusion_level,
        "github_role": role,
        "rank_within_result": rank,
        "script_relpath": rec.script_relpath,
        "basename": rec.basename,
        "source_from_v2": rec.source,
        "milestone_id": rec.milestone_id,
        "paper_unit": rec.paper_unit,
        "selection_status": rec.selection_status,
        "selection_score": rec.selection_score,
        "ledger_mention_count": rec.ledger_mention_count,
        "v1_candidate_output_links": rec.v1_candidate_output_links,
        "deprecated_status": rec.deprecated_status,
        "top_crosswalk_outputs": rec.top_crosswalk_outputs,
        "why_included": reason,
        "target_folder": target_folder_for_role(role, result),
        "copy_status": "plan_only_not_copied",
        "human_review": "",
    }


# ---------------------------------------------------------------------------
# Coverage logic
# ---------------------------------------------------------------------------

def build_result_spine(
    records: Sequence[ScriptRecord],
    raw: Dict[str, List[dict]],
) -> Tuple[List[dict], List[dict], List[dict], List[dict], List[str]]:
    manifest_rows: List[dict] = []
    coverage_rows: List[dict] = []
    review_rows: List[dict] = []

    all_records = dedupe_records(records)

    for result in RESULT_SPINE:
        selected_main = selected_by_milestone(all_records, result.minimal_milestones)
        preferred_hits = match_patterns(all_records, result.preferred_script_patterns)
        supplement_hits = match_patterns(all_records, result.result_critical_patterns)
        control_hits = match_patterns(all_records, result.control_patterns)
        appendix_hits = match_patterns(all_records, result.appendix_patterns)

        # Merge selected main + preferred hits as core coverage; keep supplements separate.
        core_candidates = dedupe_records(selected_main + preferred_hits)

        # For minimal core, keep all selected milestone scripts because they form the staircase.
        # For result-critical supplements, keep only scripts not already included.
        core_paths = {r.script_relpath for r in core_candidates}
        supplement_candidates = [r for r in dedupe_records(supplement_hits + control_hits + appendix_hits) if r.script_relpath not in core_paths]

        required_milestones_found = sorted({r.milestone_id for r in selected_main if r.milestone_id})
        missing_milestones = [m for m in result.minimal_milestones if m not in required_milestones_found]

        # Pattern coverage by best-effort substring hit in script path.
        pattern_hits = []
        missing_patterns = []
        record_text = " ".join(norm(r.script_relpath) for r in all_records)
        for pat in result.result_critical_patterns:
            if norm(pat) in record_text:
                pattern_hits.append(pat)
            else:
                missing_patterns.append(pat)

        if not missing_milestones and not missing_patterns:
            if supplement_candidates:
                coverage_status = "COVERED_WITH_RESULT_SUPPLEMENTS"
            else:
                coverage_status = "COVERED_BY_V2_CORE"
        elif not missing_milestones and missing_patterns:
            coverage_status = "CORE_COVERED_BUT_SUPPLEMENT_PATTERN_MISSING"
        elif missing_milestones and not missing_patterns:
            coverage_status = "SUPPLEMENTS_PRESENT_BUT_CORE_MILESTONE_MISSING"
        else:
            coverage_status = "NEEDS_REVIEW"

        # Special rule: R07 is not GitHub-safe if it has only v2 selected Stage-6Yn,
        # because the Omega_m result spine needs Yj/Yk/Yl-style scripts visible.
        if result.result_id == "R07_cosmology_proximity_bookkeeping":
            required_cosmo = [
                "Stage-6Yj_manuscript_axis_synthesis_v1",
                "Stage-6Yk_omega_m_pareto_refinement_v1",
                "Stage-6Yl_corrected_lock_omega_m_reconstruction_v1",
            ]
            missing_cosmo = [p for p in required_cosmo if norm(p) not in record_text]
            if missing_cosmo:
                coverage_status = "NEEDS_REVIEW_COSMOLOGY_SPINE_INCOMPLETE"
                missing_patterns += missing_cosmo
            elif coverage_status == "COVERED_BY_V2_CORE":
                coverage_status = "COVERED_WITH_RESULT_SUPPLEMENTS"

        # Special rule: R09 should include separate Stage-7D v3/v4 if present.
        if result.result_id == "R09_stage7D_gr_appendix_lambda_acceleration":
            needed = ["dark_energy", "acceleration"]
            missing_stage7d = [p for p in needed if p not in record_text]
            if missing_stage7d:
                coverage_status = "APPENDIX_CORE_PRESENT_BUT_DARKENERGY_ACCELERATION_NEED_REVIEW"
                missing_patterns += missing_stage7d
            elif coverage_status == "COVERED_BY_V2_CORE":
                coverage_status = "COVERED_WITH_RESULT_SUPPLEMENTS"

        coverage_rows.append({
            "result_id": result.result_id,
            "title": result.title,
            "manuscript_question": result.manuscript_question,
            "result_claim_class": result.result_claim_class,
            "coverage_status": coverage_status,
            "minimal_milestones_required": ";".join(result.minimal_milestones),
            "minimal_milestones_found": ";".join(required_milestones_found),
            "missing_milestones": ";".join(missing_milestones),
            "result_critical_patterns_found": ";".join(pattern_hits),
            "result_critical_patterns_missing": ";".join(missing_patterns),
            "core_script_count": len(core_candidates),
            "supplement_script_count": len(supplement_candidates),
            "recommended_github_folder": result.github_folder,
            "notes": result.notes,
        })

        if coverage_status not in {"COVERED_BY_V2_CORE", "COVERED_WITH_RESULT_SUPPLEMENTS"}:
            review_rows.append({
                "result_id": result.result_id,
                "severity": "high" if coverage_status == "NEEDS_REVIEW" else "review",
                "issue": coverage_status,
                "missing_milestones": ";".join(missing_milestones),
                "missing_patterns": ";".join(missing_patterns),
                "recommended_action": "Inspect v2 candidate scores and ledger mentions; add explicit result-critical script(s) or document why absent.",
            })

        # Emit core rows.
        core_candidates.sort(key=lambda r: (str(r.run_order).zfill(5), r.milestone_id, r.script_relpath))
        for idx, rec in enumerate(core_candidates, start=1):
            role = classify_github_role(result, rec, is_supplement=False)
            manifest_rows.append(script_to_manifest_row(
                result, rec, role, "minimal_core", "selected by v2 milestone/preferred pattern for this result spine", idx
            ))

        # Emit supplements. Cap generic matches for huge pattern families, but keep all named result-critical scripts.
        supplement_candidates.sort(key=lambda r: (r.selection_score, version_key(r.script_relpath)), reverse=True)
        for idx, rec in enumerate(supplement_candidates, start=1):
            role = classify_github_role(result, rec, is_supplement=True)
            manifest_rows.append(script_to_manifest_row(
                result, rec, role, "result_critical_supplement", "added by v3 result-spine enforcement", idx
            ))

    # Dedupe manifest while preserving strongest inclusion.
    priority = {
        "minimal_core": 4,
        "result_critical_supplement": 3,
        "expanded_context": 2,
    }
    best_by_key: OrderedDict[Tuple[str, str], dict] = OrderedDict()
    for row in manifest_rows:
        key = (row["result_id"], row["script_relpath"])
        if key not in best_by_key:
            best_by_key[key] = row
        else:
            old = best_by_key[key]
            if priority.get(row["inclusion_level"], 0) > priority.get(old["inclusion_level"], 0):
                best_by_key[key] = row
    manifest_rows = list(best_by_key.values())

    # Minimal manifest should still include result-critical supplements for R06/R07/R08/R09
    # because those are central evidence support categories, not random extras.
    minimal_rows = [
        r for r in manifest_rows
        if r["inclusion_level"] == "minimal_core"
        or r["result_id"] in {
            "R06_mechanism_and_recursive_stability",
            "R07_cosmology_proximity_bookkeeping",
            "R08_time_surrogate_entropy_irreversibility",
            "R09_stage7D_gr_appendix_lambda_acceleration",
            "R10_repository_reproducibility_compression",
        }
    ]

    return coverage_rows, minimal_rows, manifest_rows, review_rows, []


# ---------------------------------------------------------------------------
# Markdown/text reports
# ---------------------------------------------------------------------------

def make_result_map_md(coverage_rows: Sequence[dict], minimal_rows: Sequence[dict], summary: dict) -> str:
    lines = [
        "# Stage-7E-v3 Result-Spine Map",
        "",
        f"Generated: {summary['generated_utc']}",
        "",
        "## Purpose",
        "",
        "This file asks whether the GitHub candidate bundle covers the actual major QEG results, not merely one script per stage.",
        "",
        "## Result spine coverage",
        "",
        "| Result | Status | Core scripts | Supplements | Claim class |",
        "|---|---|---:|---:|---|",
    ]

    for row in coverage_rows:
        lines.append(
            f"| {row['title']} | {row['coverage_status']} | {row['core_script_count']} | "
            f"{row['supplement_script_count']} | {row['result_claim_class']} |"
        )

    lines.extend([
        "",
        "## Minimal GitHub script bundle by result",
        "",
    ])

    by_result = defaultdict(list)
    for row in minimal_rows:
        by_result[row["result_id"]].append(row)

    for result in RESULT_SPINE:
        rows = by_result.get(result.result_id, [])
        lines.extend([
            f"### {result.result_id}: {result.title}",
            "",
            f"Question: {result.manuscript_question}",
            "",
            f"Recommended folder: `{result.github_folder}`",
            "",
        ])
        if not rows:
            lines.append("_No scripts selected. Review required._")
            lines.append("")
            continue
        lines.append("| Role | Script | Why included |")
        lines.append("|---|---|---|")
        for r in rows:
            lines.append(f"| {r['github_role']} | `{r['script_relpath']}` | {r['why_included']} |")
        lines.append("")

    lines.extend([
        "## Non-claim guardrail",
        "",
        "The result-spine bundle supports a reproducible, family-preserving emergent nonlocal operator geometry with a stable two-sector law.",
        "",
        "It does not claim that QEG derives quantum gravity, GR, Friedmann equations, LambdaCDM, dark energy, cosmic time, cosmic acceleration, or the age of the Universe.",
        "",
    ])
    return "\n".join(lines)


def make_review_notes_md(review_rows: Sequence[dict], coverage_rows: Sequence[dict], summary: dict) -> str:
    lines = [
        "# Stage-7E-v3 Critical Review Notes",
        "",
        f"Generated: {summary['generated_utc']}",
        "",
        "## Verdict",
        "",
    ]

    bad = [r for r in coverage_rows if r["coverage_status"] not in {"COVERED_BY_V2_CORE", "COVERED_WITH_RESULT_SUPPLEMENTS"}]
    if bad:
        lines.append("Some result-spine items need manual review before final GitHub packaging.")
    else:
        lines.append("All result-spine items are covered by v2 core scripts and/or v3 result-critical supplements.")

    lines.extend(["", "## Review items", ""])

    if not review_rows:
        lines.append("_No critical review items._")
    else:
        lines.append("| Result | Severity | Issue | Missing patterns | Recommended action |")
        lines.append("|---|---|---|---|---|")
        for r in review_rows:
            lines.append(
                f"| {r['result_id']} | {r['severity']} | {r['issue']} | "
                f"{r['missing_patterns']} | {r['recommended_action']} |"
            )

    lines.extend([
        "",
        "## Important interpretation",
        "",
        "V2 is useful as a milestone-compression layer. V3 is stricter: it checks that the scripts reproduce the paper's major result claims.",
        "",
        "The final README should be based on `stage7E_v3_minimal_github_manifest.csv` plus the control and appendix folders.",
    ])
    return "\n".join(lines)


def make_copy_plan_rows(rows: Sequence[dict]) -> List[dict]:
    out = []
    seen = set()
    for row in rows:
        src = row["script_relpath"]
        folder = row["target_folder"]
        basename = Path(src).name
        key = (src, folder)
        if key in seen:
            continue
        seen.add(key)
        out.append({
            "source_relpath": src,
            "target_folder": folder,
            "target_relpath": f"{folder}/{basename}",
            "github_role": row["github_role"],
            "result_id": row["result_id"],
            "copy_command_hint": f"mkdir -p {folder} && cp {src} {folder}/",
            "copy_status": "plan_only_not_executed",
        })
    return out


def make_ledger_note(summary: dict) -> str:
    return f"""============================================================
Stage-7E-v3 Ledger Note
Project: Quantum-Emergent Gravity
Script: Stage-7E-v3_result_spine_audit.py
Generated: {summary['generated_utc']}
============================================================

Purpose:
  Stage-7E-v3 audits the Stage-7E-v2 milestone manifest against the
  actual manuscript-facing result spine. It prevents the GitHub package
  from being merely "one script per stage" when a major result requires
  a small staircase or a result-critical supplement.

Inputs:
  v2 output directory: {summary['v2_input_dir']}

Outputs:
  - stage7E_v3_result_spine_coverage.csv
  - stage7E_v3_minimal_github_manifest.csv
  - stage7E_v3_expanded_github_manifest.csv
  - stage7E_v3_github_copy_plan.csv
  - stage7E_v3_result_to_script_map.md
  - stage7E_v3_critical_review_notes.md
  - stage7E_v3_summary.json
  - stage7E_v3_ledger_note.txt
  - stage7E_v3_ascii_transition_package.txt

Counts:
  Result-spine items checked        : {summary['result_count']}
  Fully/core covered results        : {summary['covered_by_v2_core']}
  Covered with v3 supplements       : {summary['covered_with_supplements']}
  Review-needed results             : {summary['review_needed']}
  Minimal GitHub script rows        : {summary['minimal_manifest_rows']}
  Expanded GitHub script rows       : {summary['expanded_manifest_rows']}
  GitHub copy-plan rows             : {summary['copy_plan_rows']}

Interpretation:
  If v2 is a milestone compression layer, v3 is a result-enforcement layer.
  The recommended GitHub list is now:

      stage7E_v3_minimal_github_manifest.csv

  with supporting folder plan:

      stage7E_v3_github_copy_plan.csv

Guardrail:
  Stage-7D remains appendix-only.
  Cosmology-proximity rows remain comparison bookkeeping, not identification.
  Time-surrogate rows do not claim cosmic time.
  Rescue/provenance scripts are preserved without becoming required reruns.

============================================================
END LEDGER NOTE
============================================================
"""


def make_ascii_package(summary: dict) -> str:
    return f"""============================================================
ASCII TRANSITION PACKAGE
Project: Quantum-Emergent Gravity
Stage: Stage-7E-v3
Working Title: Result-Spine Audit and GitHub Folder Manifest
Generated: {summary['generated_utc']}
Status: READ-ONLY RESULT-ENFORCEMENT SCRIPT
============================================================

PURPOSE
-------
Stage-7E-v3 answers the question:

    Does the proposed GitHub/reproducibility bundle cover the major
    QEG results we actually intend to mention?

It is stricter than v2.

v2 selected one best script per milestone.
v3 checks whether the selected scripts cover the major result spine.

------------------------------------------------------------
RESULT SPINE CHECKED
------------------------------------------------------------

1. Family-root geometry and metric candidates
2. Symmetry breaking and admissibility-boundary geometry
3. Emergence of intrinsic rho/kappa fields
4. Nonlocal rho/kappa operator geometry
5. Two-lobe law and family universality
6. Mechanism narrowing and recursive stability
7. Cosmological-proximity bookkeeping, including Omega_m-like results
8. Time surrogate / entropy / irreversibility evidence
9. Stage-7D appendix: Friedmann, Lambda, dark energy, acceleration
10. Repository compression and reproducibility

------------------------------------------------------------
MAIN DECISION
------------------------------------------------------------

V2 is useful but incomplete as a final GitHub guide.

The safer GitHub base list is:

    stage7E_v3_minimal_github_manifest.csv

The expanded audit list is:

    stage7E_v3_expanded_github_manifest.csv

The folder-copy planning file is:

    stage7E_v3_github_copy_plan.csv

------------------------------------------------------------
COUNTS
------------------------------------------------------------

Result-spine items checked  : {summary['result_count']}
Covered by v2 core          : {summary['covered_by_v2_core']}
Covered with supplements    : {summary['covered_with_supplements']}
Review needed               : {summary['review_needed']}
Minimal manifest rows       : {summary['minimal_manifest_rows']}
Expanded manifest rows      : {summary['expanded_manifest_rows']}

------------------------------------------------------------
CLAIM GUARDRAIL
------------------------------------------------------------

Allowed main claim:
  reproducible, family-preserving emergent nonlocal operator geometry
  with a stable two-sector law.

Allowed comparison claim:
  internally generated dimensionless QEG invariants are compared against
  accepted cosmological benchmarks as bookkeeping, not identification.

Allowed appendix claim:
  Friedmann / Lambda / dark-energy / acceleration substitutions provide
  GR-adjacent appendix bookkeeping only.

Forbidden:
  QEG derives quantum gravity, GR, Friedmann equations, LambdaCDM, dark
  energy, cosmic acceleration, cosmic time, or the age of the Universe.

============================================================
END STAGE-7E-v3 ASCII TRANSITION PACKAGE
============================================================
"""


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Stage-7E-v3 result-spine audit for QEG GitHub preparation.")
    p.add_argument("--root", type=Path, default=DEFAULT_ROOT, help="Project root.")
    p.add_argument("--v2-dir", type=Path, default=None, help="Stage-7E-v2 output directory.")
    p.add_argument("--output-dir", type=Path, default=None, help="Stage-7E-v3 output directory.")
    return p.parse_args(argv)


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = parse_args(argv)
    root = args.root.expanduser().resolve()
    v2_dir = args.v2_dir
    if v2_dir is None:
        v2_dir = root / "metric_stage_7E_outputs" / "canonical_run_sequence_builder_v2"
    v2_dir = v2_dir.expanduser().resolve()
    outdir = args.output_dir
    if outdir is None:
        outdir = root / "metric_stage_7E_outputs" / "result_spine_audit_v3"
    outdir = outdir.expanduser().resolve()
    outdir.mkdir(parents=True, exist_ok=True)

    required = [
        "stage7E_v2_canonical_run_manifest.csv",
        "stage7E_v2_control_manifest.csv",
        "stage7E_v2_appendix_manifest.csv",
        "stage7E_v2_rescue_provenance_manifest.csv",
        "stage7E_v2_milestone_candidate_scores.csv",
        "stage7E_v2_ledger_script_mentions.csv",
    ]
    missing_inputs = [fn for fn in required if not (v2_dir / fn).exists()]
    if missing_inputs:
        print("ERROR: missing required v2 files:", file=sys.stderr)
        for fn in missing_inputs:
            print(f"  - {v2_dir / fn}", file=sys.stderr)
        return 2

    print("=" * 72)
    print("Stage-7E-v3: Result-spine audit and GitHub folder manifest")
    print("=" * 72)
    print(f"Project root : {root}")
    print(f"V2 input dir : {v2_dir}")
    print(f"Output dir   : {outdir}")
    print("Mode         : read-only audit; no project scripts copied or modified")
    print("-" * 72)

    records, raw = load_records(v2_dir)
    coverage_rows, minimal_rows, expanded_rows, review_rows, _ = build_result_spine(records, raw)
    copy_plan_rows = make_copy_plan_rows(minimal_rows)

    summary = {
        "generated_utc": now_iso(),
        "script_name": "Stage-7E-v3_result_spine_audit.py",
        "project_root": str(root),
        "v2_input_dir": str(v2_dir),
        "v3_output_dir": str(outdir),
        "result_count": len(RESULT_SPINE),
        "covered_by_v2_core": sum(1 for r in coverage_rows if r["coverage_status"] == "COVERED_BY_V2_CORE"),
        "covered_with_supplements": sum(1 for r in coverage_rows if r["coverage_status"] == "COVERED_WITH_RESULT_SUPPLEMENTS"),
        "review_needed": sum(1 for r in coverage_rows if r["coverage_status"] not in {"COVERED_BY_V2_CORE", "COVERED_WITH_RESULT_SUPPLEMENTS"}),
        "minimal_manifest_rows": len(minimal_rows),
        "expanded_manifest_rows": len(expanded_rows),
        "copy_plan_rows": len(copy_plan_rows),
        "review_rows": len(review_rows),
        "policy": {
            "mode": "read_only_result_enforcement",
            "stage7D_status": "appendix_only",
            "cosmology_status": "comparison_bookkeeping_not_identification",
            "time_status": "time_surrogate_evidence_not_cosmic_time_derivation",
        },
    }

    write_csv(outdir / "stage7E_v3_result_spine_coverage.csv", coverage_rows)
    write_csv(outdir / "stage7E_v3_minimal_github_manifest.csv", minimal_rows)
    write_csv(outdir / "stage7E_v3_expanded_github_manifest.csv", expanded_rows)
    write_csv(outdir / "stage7E_v3_github_copy_plan.csv", copy_plan_rows)
    write_csv(outdir / "stage7E_v3_review_needed.csv", review_rows)
    write_json(outdir / "stage7E_v3_summary.json", summary)
    write_text(outdir / "stage7E_v3_result_to_script_map.md", make_result_map_md(coverage_rows, minimal_rows, summary))
    write_text(outdir / "stage7E_v3_critical_review_notes.md", make_review_notes_md(review_rows, coverage_rows, summary))
    write_text(outdir / "stage7E_v3_ledger_note.txt", make_ledger_note(summary))
    write_text(outdir / "stage7E_v3_ascii_transition_package.txt", make_ascii_package(summary))

    print("Done.")
    print("-" * 72)
    print(f"Result-spine items checked : {summary['result_count']}")
    print(f"Covered by v2 core         : {summary['covered_by_v2_core']}")
    print(f"Covered with supplements   : {summary['covered_with_supplements']}")
    print(f"Review needed              : {summary['review_needed']}")
    print(f"Minimal manifest rows      : {summary['minimal_manifest_rows']}")
    print(f"Expanded manifest rows     : {summary['expanded_manifest_rows']}")
    print()
    print("Key files:")
    print(f"  {outdir / 'stage7E_v3_result_spine_coverage.csv'}")
    print(f"  {outdir / 'stage7E_v3_minimal_github_manifest.csv'}")
    print(f"  {outdir / 'stage7E_v3_github_copy_plan.csv'}")
    print(f"  {outdir / 'stage7E_v3_result_to_script_map.md'}")
    print("=" * 72)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
