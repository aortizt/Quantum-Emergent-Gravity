#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Stage-7E-v2_canonical_run_sequence_builder.py

Quantum-Emergent Gravity (QEG)
Stage-7E-v2: Canonical Run Sequence Builder

Purpose
-------
Build a *minimal and effective* QEG reproducibility pipeline by combining:

1. Stage-7E-v1 inventory/crosswalk outputs
2. The master evidence ledger
3. A manuscript-facing milestone taxonomy
4. Script-output crosswalk evidence
5. Rescue/control/appendix guardrails

This script does NOT edit, move, delete, or rerun any QEG scientific scripts.
It reads v1 audit outputs and the evidence ledger, then writes v2 selection
manifests for human review and eventual README/Zenodo preparation.

Default project root:
    /home/dakini/Downloads/010-Quantum_Emergent_Gravity

Default v1 input directory:
    <root>/metric_stage_7E_outputs/project_inventory_ledger_crosswalk_v1

Default v2 output directory:
    <root>/metric_stage_7E_outputs/canonical_run_sequence_builder_v2

Typical use:
    cd /home/dakini/Downloads/010-Quantum_Emergent_Gravity/metric_stage_7E_scripts
    python3 Stage-7E-v2_canonical_run_sequence_builder.py

Optional:
    python3 Stage-7E-v2_canonical_run_sequence_builder.py \
        --root /home/dakini/Downloads/010-Quantum_Emergent_Gravity \
        --ledger /home/dakini/Downloads/010-Quantum_Emergent_Gravity/__qeg_evidence__/EVIDENCE_LEDGER.md

Design principles
-----------------
- Keep one best script per scientific milestone, not every version.
- Keep rescue scripts only when they explain a scientific correction.
- Keep null/adversarial scripts as controls, not mainline reruns.
- Keep Stage-7D as appendix-only, never mainline.
- Attach canonical outputs using the v1 crosswalk automatically.
- Produce a human-editable selection CSV for override without code changes.
- Prefer the master evidence ledger over raw filename heuristics when they disagree.

Authorial guardrail
-------------------
This is a Stage-7E compression/reproducibility tool, not a new physics stage.
"""

from __future__ import annotations

import argparse
import csv
import difflib
import json
import os
import re
import sys
from collections import Counter, defaultdict
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple


DEFAULT_ROOT = Path("/home/dakini/Downloads/010-Quantum_Emergent_Gravity")
DEFAULT_V1_REL = Path("metric_stage_7E_outputs/project_inventory_ledger_crosswalk_v1")
DEFAULT_V2_REL = Path("metric_stage_7E_outputs/canonical_run_sequence_builder_v2")

EXPECTED_V1_FILES = {
    "script_inventory": "stage7E_v1_script_inventory.csv",
    "output_inventory": "stage7E_v1_output_inventory.csv",
    "ledger_inventory": "stage7E_v1_ledger_inventory.csv",
    "crosswalk": "stage7E_v1_script_output_crosswalk.csv",
    "stage_decision_map": "stage7E_v1_stage_decision_map.csv",
    "rescue_classification": "stage7E_v1_rescue_branch_classification.csv",
    "canonical_candidates": "stage7E_v1_canonical_run_candidates.csv",
    "deprecated": "stage7E_v1_deprecated_or_superseded_scripts.csv",
    "missing_or_orphaned": "stage7E_v1_missing_or_orphaned_outputs.csv",
    "summary": "stage7E_v1_summary.json",
}

EXPECTED_FAMILIES = ["BARI", "NUFIT", "VALENCIA"]

FORBIDDEN_CLAIMS = [
    "QEG derives quantum gravity",
    "QEG derives general relativity",
    "QEG derives Friedmann equations",
    "QEG derives LambdaCDM",
    "QEG derives dark energy",
    "QEG predicts Lambda",
    "QEG derives cosmic acceleration",
    "QEG derives cosmic time",
    "QEG derives the age of the Universe",
    "QEG proves emergent spacetime",
]


# ---------------------------------------------------------------------------
# Milestone taxonomy
# ---------------------------------------------------------------------------

# The taxonomy intentionally compresses the project into scientific milestones,
# not script chronology. The script will search inventory paths by substrings,
# then use ledger mentions and v1 evidence to choose a preferred representative.
#
# category:
#   mainline  -> part of minimal effective reproducibility pipeline
#   control   -> null/adversarial/control sequence
#   rescue    -> provenance correction; not required rerun unless rebuilding history
#   appendix  -> appendix-only GR-adjacent branch
#   docs      -> repository/documentation infrastructure
#
# required:
#   True means missing script should be reported as critical.
#
# The patterns are deliberately redundant: local filenames changed during the
# project, and v2 should surface best matches rather than silently fail.

MILESTONES: List[dict] = [
    {
        "order": 10,
        "milestone_id": "M01_stage4_family_roots_shellbands",
        "stage_range": "Stage-4A",
        "paper_unit": "Data lineage and family roots",
        "question": "Where do the BARI / NUFIT / VALENCIA family roots enter the pipeline?",
        "category": "mainline",
        "required": True,
        "patterns": ["stage4a_shellbands", "metric_stage_4a_shellbands", "shellbands_"],
        "prefer": ["stage4a_shellbands"],
        "avoid": ["freeze_report", "print_"],
        "expected_outputs": ["stage4A_shellbands_BARI", "stage4A_shellbands_NUFIT", "stage4A_shellbands_VALENCIA"],
    },
    {
        "order": 20,
        "milestone_id": "M02_stage4B_alpha_beta_commnorm",
        "stage_range": "Stage-4B",
        "paper_unit": "Band-level observables",
        "question": "How are alpha/beta band observables and comm_norm-derived holonomy summaries constructed?",
        "category": "mainline",
        "required": True,
        "patterns": ["stage4b_beta_holonly_from_commnorm", "metric_stage_4b_commonly_v2", "stage4b_lock_alpha", "stage4b_crossfit_alignment"],
        "prefer": ["commonly_v2", "beta_holonly_from_commnorm"],
        "avoid": ["dryrun"],
        "expected_outputs": ["stage4B_alpha_commonly_v2", "stage4B_beta_holonly"],
    },
    {
        "order": 30,
        "milestone_id": "M03_stage4C_optionA_canonical_microfeatures",
        "stage_range": "Stage-4C",
        "paper_unit": "Canonical microfeature freeze",
        "question": "Which canonical Stage-4C table freezes the Option-A comm_norm path?",
        "category": "mainline",
        "required": True,
        "patterns": ["stage-4c_real_option-a_v5", "stage4c_consolidate_optiona", "canonical_microfeature_extractor", "stage4c"],
        "prefer": ["option-a_v5", "real_option-a_v5"],
        "avoid": ["v1", "v2", "v3", "v4"],
        "expected_outputs": ["stage4C_microfeatures_canonical_v1"],
    },
    {
        "order": 40,
        "milestone_id": "M04_stage4D_transport_obstruction",
        "stage_range": "Stage-4D",
        "paper_unit": "Transport obstruction diagnostics",
        "question": "How are OT/Procrustes/obstruction transport diagnostics added?",
        "category": "mainline",
        "required": True,
        "patterns": ["stage4d_transport_layers", "stage4d_classify_obstruction"],
        "prefer": ["transport_layers_v1"],
        "avoid": [],
        "expected_outputs": ["stage4D_transport_diagnostics", "plus_transport"],
    },
    {
        "order": 50,
        "milestone_id": "M05_stage5A_bridge_from_4D",
        "stage_range": "Stage-5A",
        "paper_unit": "Stage-5 bridge formation",
        "question": "How are Stage-4D transport/microfeatures bridged into Stage-5 features?",
        "category": "mainline",
        "required": True,
        "patterns": ["stage5a_bridge_from_stage4d_v1b2", "stage5a_bridge_from_stage4d", "stage5a_bridge_from_4d"],
        "prefer": ["v1b2", "fixed"],
        "avoid": ["archive", "legacy"],
        "expected_outputs": ["stage5A_bridge_from_4D_v1b2", "stage5A_bridge_diagnostics"],
    },
    {
        "order": 60,
        "milestone_id": "M06_stage5B_enriched_PCA_metric_candidate",
        "stage_range": "Stage-5B",
        "paper_unit": "Rank-2 enriched feature geometry",
        "question": "How is the enriched PC1/PC2 geometry constructed and diagnosed?",
        "category": "mainline",
        "required": True,
        "patterns": ["stage5b_pca_dimension_test_vnext", "metric_candidate_from_global_pc1", "stage5b_metric_candidate_v2pca"],
        "prefer": ["pca_dimension_test_vnext", "global_pc1"],
        "avoid": ["bridge.py", "driver.py"],
        "expected_outputs": ["stage5B_pca_dimension_test", "stage5B_metric_candidate_from_global_PC1"],
    },
    {
        "order": 70,
        "milestone_id": "M07_stage5C_intrinsic_coordinate",
        "stage_range": "Stage-5C",
        "paper_unit": "Intrinsic angular coordinate discovery",
        "question": "How is the angular intrinsic coordinate selected and BARI quotient ambiguity resolved?",
        "category": "mainline",
        "required": True,
        "patterns": ["stage5c_intrinsic_coordinate_from_pc1_pc2_v4", "metric_stage_5c_intrinsic_coordinate_from_pc1_pc2_v4", "stage5c"],
        "prefer": ["v4"],
        "avoid": ["scaffold", "v1", "v2", "v3"],
        "expected_outputs": ["stage5C_intrinsic_coordinate_from_PC1_PC2_v4"],
    },
    {
        "order": 80,
        "milestone_id": "M08_stage5D_frozen_coordinate",
        "stage_range": "Stage-5D",
        "paper_unit": "Frozen coordinate object",
        "question": "Which formal Stage-5D artifact freezes the radial-vs-directional coordinate?",
        "category": "mainline",
        "required": True,
        "patterns": ["stage5d_formalize_preferred_intrinsic_coordinate_v1b", "metric_stage_5d_formalize_preferred_intrinsic_coordinate_v1b"],
        "prefer": ["v1b"],
        "avoid": ["fix.py", "fix2.py", "scaffold"],
        "expected_outputs": ["stage5D_formalized_preferred_intrinsic_coordinate_v1b"],
    },
    {
        "order": 90,
        "milestone_id": "M09_stage6A_candidate_metrics",
        "stage_range": "Stage-6A",
        "paper_unit": "Candidate metrics over frozen coordinate",
        "question": "How are candidate metric families constructed on (r, theta)?",
        "category": "mainline",
        "required": True,
        "patterns": ["stage_6a_construct_candidate_metrics", "6a_construct_candidate_metrics", "candidate_metrics_from_stage5"],
        "prefer": ["construct_candidate_metrics"],
        "avoid": ["coupling-spec"],
        "expected_outputs": ["stage6A_metric_candidates_pairwise_distances"],
    },
    {
        "order": 100,
        "milestone_id": "M10_stage6B_metric_evaluation",
        "stage_range": "Stage-6B",
        "paper_unit": "Metric candidate evaluation",
        "question": "How are candidate metrics compared before gauge analysis?",
        "category": "mainline",
        "required": True,
        "patterns": ["stage_6b_evaluate_candidate_metrics", "6b_evaluate_candidate_metrics"],
        "prefer": ["evaluate_candidate_metrics"],
        "avoid": [],
        "expected_outputs": ["stage6B_metric_evaluation_table"],
    },
    {
        "order": 110,
        "milestone_id": "M11_stage6C_gauge_admissibility",
        "stage_range": "Stage-6C",
        "paper_unit": "Gauge/admissibility and symmetry breaking",
        "question": "Which gauge/admissibility script identifies common support and symmetry breaking?",
        "category": "mainline",
        "required": True,
        "patterns": ["normalization_and_gauge_analysis_v2", "stage_6c_normalization", "6c_normalization"],
        "prefer": ["v2"],
        "avoid": ["v1"],
        "expected_outputs": ["stage6C_metric_invariance_table_v2", "stage6C_metric_invariance_summary_v2"],
    },
    {
        "order": 120,
        "milestone_id": "M12_stage6D_boundary_geometry",
        "stage_range": "Stage-6D",
        "paper_unit": "Admissibility boundary geometry",
        "question": "How is the curved admissibility boundary reconstructed in intrinsic coordinates?",
        "category": "mainline",
        "required": True,
        "patterns": ["stage-6d_v2_fixed", "stage-6d_v2.py", "symmetry_breaking_profile", "geometric_interpretation"],
        "prefer": ["v2_fixed", "v1c"],
        "avoid": ["branch1"],
        "expected_outputs": ["stage6D_radial_zscore_profile", "stage6D_symmetry_breaking_summary"],
    },
    {
        "order": 130,
        "milestone_id": "M13_stage6D_branch1_refined_boundary",
        "stage_range": "Stage-6D-branch1",
        "paper_unit": "Refined boundary reconstruction",
        "question": "Which branch1 script corrects the coarse boundary by restricted pooled geometry?",
        "category": "mainline",
        "required": True,
        "patterns": ["stage_6d_branch1_refined_boundary_v3", "6d_branch1_refined_boundary_v3", "branch1_refined_boundary"],
        "prefer": ["v3"],
        "avoid": ["v1.py", "v2.py"],
        "expected_outputs": ["stage6D_branch1", "refined_boundary"],
    },
    {
        "order": 140,
        "milestone_id": "M14_stage6E_boundary_law",
        "stage_range": "Stage-6E",
        "paper_unit": "Boundary law fit",
        "question": "How is the restricted boundary law fitted and stabilized?",
        "category": "mainline",
        "required": True,
        "patterns": ["stage-6e_v2_upgraded_v2b", "stage-6e_v2", "fit_boundary_law_v1b"],
        "prefer": ["v2b", "v1b"],
        "avoid": ["v1.py", "v1a.py"],
        "expected_outputs": ["stage6E_boundary_function", "stage6E_boundary_law"],
    },
    {
        "order": 150,
        "milestone_id": "M15_stage6F_curvature_geometry",
        "stage_range": "Stage-6F",
        "paper_unit": "Boundary curvature geometry",
        "question": "How is the fitted boundary elevated to curvature and induced metric diagnostics?",
        "category": "mainline",
        "required": True,
        "patterns": ["stage-6f_curvature_geometry_v1c", "stage-6f_curvature_geometry"],
        "prefer": ["v1c", "v1b"],
        "avoid": ["v1.py"],
        "expected_outputs": ["stage6F_curvature", "stage6F_geometry"],
    },
    {
        "order": 160,
        "milestone_id": "M16_stage6G_intrinsic_boundary",
        "stage_range": "Stage-6G",
        "paper_unit": "Arc-length intrinsic boundary geometry",
        "question": "How is theta-dependence removed by intrinsic arc-length geometry?",
        "category": "mainline",
        "required": True,
        "patterns": ["stage-6g_intrinsic_boundary_geometry_v1b", "stage-6g_intrinsic_boundary_geometry"],
        "prefer": ["v1b"],
        "avoid": ["v1.py"],
        "expected_outputs": ["stage6G_intrinsic_boundary"],
    },
    {
        "order": 170,
        "milestone_id": "M17_stage6H_distributional_invariants",
        "stage_range": "Stage-6H",
        "paper_unit": "Intrinsic distributional invariants",
        "question": "How are kappa(s) and rho(s) distributional invariants built?",
        "category": "mainline",
        "required": True,
        "patterns": ["stage-6h_intrinsic_distributional_invariants_v1b", "distributional_invariants"],
        "prefer": ["v1b"],
        "avoid": [],
        "expected_outputs": ["stage6H_distributional_profile"],
    },
    {
        "order": 180,
        "milestone_id": "M18_stage6I_operator_diagnostics",
        "stage_range": "Stage-6I",
        "paper_unit": "Local-vs-nonlocal operator diagnostics",
        "question": "How is local constitutive closure rejected and nonlocal coupling motivated?",
        "category": "mainline",
        "required": True,
        "patterns": ["stage-6i_operator_response_suite_v1b", "operator_response_suite"],
        "prefer": ["v1b"],
        "avoid": ["v1.py"],
        "expected_outputs": ["stage6I_operator_profile", "stage6I_operator_summary"],
    },
    {
        "order": 190,
        "milestone_id": "M19_stage6J_nonlocal_operator",
        "stage_range": "Stage-6J",
        "paper_unit": "Nonlocal response geometry",
        "question": "How is the kappa-to-rho nonlocal operator recovered?",
        "category": "mainline",
        "required": True,
        "patterns": ["stage-6j_intrinsic_nonlocal_response_geometry", "nonlocal_response_geometry"],
        "prefer": ["stage-6j"],
        "avoid": [],
        "expected_outputs": ["stage6J_nonlocal_operator_profile", "stage6J_kernel_matrix_best"],
    },
    {
        "order": 200,
        "milestone_id": "M20_stage6K_operator_reduction",
        "stage_range": "Stage-6K",
        "paper_unit": "Canonical operator reduction",
        "question": "How is the operator compressed to a compact low-rank structure?",
        "category": "mainline",
        "required": True,
        "patterns": ["stage-6k_canonical_operator_reduction", "canonical_operator_reduction"],
        "prefer": ["stage-6k"],
        "avoid": [],
        "expected_outputs": ["stage6K_canonical_operator_summary", "stage6K_singular_values"],
    },
    {
        "order": 210,
        "milestone_id": "M21_stage6L_pde_negative_result",
        "stage_range": "Stage-6L",
        "paper_unit": "Continuum/PDE analogue and negative result",
        "question": "How are local PDE/Green closures tested and rejected as primary explanation?",
        "category": "mainline",
        "required": True,
        "patterns": ["stage-6l_continuum_law_pde_analogue", "continuum_law_pde"],
        "prefer": ["stage-6l"],
        "avoid": [],
        "expected_outputs": ["stage6L_continuum_profile", "stage6L_continuum_summary"],
    },
    {
        "order": 220,
        "milestone_id": "M22_stage6M_targeted_two_lobe",
        "stage_range": "Stage-6M",
        "paper_unit": "Targeted two-lobe modal resolution",
        "question": "How is the early+central two-lobe geometry discovered rather than missed by unconstrained fitting?",
        "category": "mainline",
        "required": True,
        "patterns": ["stage-6m_targeted_modal_resolution_v2c", "targeted_modal_resolution_v2c", "operator_field_theory_modal_dynamics_v2b"],
        "prefer": ["targeted_modal_resolution_v2c", "v2c"],
        "avoid": ["v1.py", "v1b", "v1c", "v2.py", "v2b"],
        "expected_outputs": ["stage6M_targeted", "two_lobe"],
    },
    {
        "order": 230,
        "milestone_id": "M23_stage6N_canonical_two_lobe_law",
        "stage_range": "Stage-6N",
        "paper_unit": "Canonical two-lobe law in pooled coordinates",
        "question": "How is the strong pooled two-lobe law formalized?",
        "category": "mainline",
        "required": True,
        "patterns": ["stage-6n_canonical_two_lobe_law_v1a", "canonical_two_lobe_law"],
        "prefer": ["v1a"],
        "avoid": ["family_recovery", "v1.py"],
        "expected_outputs": ["stage6N", "two_lobe"],
    },
    {
        "order": 240,
        "milestone_id": "M24_stage6O_family_lineage_repair",
        "stage_range": "Stage-6O",
        "paper_unit": "Family lineage repair and modal rho selection",
        "question": "How is BARI/NUFIT/VALENCIA provenance repaired before universality testing?",
        "category": "rescue",
        "required": True,
        "patterns": ["stage-6o_direct_modal_rho_provenance_audit", "stage-6o_row_level_family_mapping", "stage-6o_family_aware_profile_rebuild", "terminal_lineage_rebuild", "provenance_bridge_audit"],
        "prefer": ["direct_modal_rho", "row_level_family_mapping", "family_aware_profile_rebuild", "terminal_lineage"],
        "avoid": ["semantic_review"],
        "expected_outputs": ["stage6O_family_aware_profile", "stage6O_clean_family_profile"],
    },
    {
        "order": 250,
        "milestone_id": "M25_stage6P_family_universality_lock",
        "stage_range": "Stage-6P",
        "paper_unit": "Family universality lock",
        "question": "How is the family-aware two-lobe law accepted as universal rather than pooled artifact?",
        "category": "mainline",
        "required": True,
        "patterns": ["two_lobe_universality_test_on_v5_candidate_v6", "family_preserving_profile_rebuild_v5", "canonical_family_modal_rho_selection"],
        "prefer": ["v6", "two_lobe_universality_test"],
        "avoid": ["v1.py", "v2.py", "v3.py", "v4.py"],
        "expected_outputs": ["stage6P_v6_family_two_lobe_fit_summary", "stage6P_v6_audit_summary"],
    },
    {
        "order": 260,
        "milestone_id": "M26_stage6Q_canonical_law_extraction",
        "stage_range": "Stage-6Q",
        "paper_unit": "Canonical law extraction",
        "question": "How is rho(s) ≈ E(s)+C(s) extracted as a compact invariant law?",
        "category": "mainline",
        "required": True,
        "patterns": ["stage-6q_canonical_law_extraction", "canonical_law_extraction"],
        "prefer": ["stage-6q"],
        "avoid": [],
        "expected_outputs": ["stage6Q", "canonical_law"],
    },
    {
        "order": 270,
        "milestone_id": "M27_stage6R_operator_interpretation",
        "stage_range": "Stage-6R",
        "paper_unit": "Operator interpretation and mechanism narrowing",
        "question": "How are simple mechanisms narrowed and pure rank-1 insufficiency identified?",
        "category": "mainline",
        "required": False,
        "patterns": ["stage-6r_operator_interpretation_layer_v2", "operator_interpretation_layer"],
        "prefer": ["v2"],
        "avoid": ["v1.py"],
        "expected_outputs": ["stage6R", "operator_interpretation"],
    },
    {
        "order": 280,
        "milestone_id": "M28_stage6S_mechanism_stability",
        "stage_range": "Stage-6S",
        "paper_unit": "Mechanism stability and non-tautology guardrail",
        "question": "How are tautological rank-1 reconstructions excluded and admissible mechanisms narrowed?",
        "category": "control",
        "required": False,
        "patterns": ["stage-6s_mechanism_stability_operator_probes", "mechanism_stability"],
        "prefer": ["stage-6s"],
        "avoid": [],
        "expected_outputs": ["stage6S", "mechanism"],
    },
    {
        "order": 290,
        "milestone_id": "M29_stage6T_source_probe_freeze",
        "stage_range": "Stage-6T",
        "paper_unit": "Non-tautological source-probe tests",
        "question": "How strong is the non-tautological source-side mechanism under strict freeze?",
        "category": "control",
        "required": False,
        "patterns": ["stage-6t_composite_probe_freeze_amplitude_calibration_v4", "source_observable_audit_probe_construction_v3", "non_tautological_source_probe"],
        "prefer": ["v4"],
        "avoid": ["v1.py", "v2.py", "v3.py"],
        "expected_outputs": ["stage6T", "source_probe"],
    },
    {
        "order": 300,
        "milestone_id": "M30_stage6Y_recursive_transport_stability",
        "stage_range": "Stage-6Y",
        "paper_unit": "Recursive transport, null competition, publication hardening",
        "question": "How are recursive stability, null/adversarial controls, and manuscript-ready invariants hardened?",
        "category": "control",
        "required": True,
        "patterns": ["brancha_scientific_claims_hardened_recursion", "publication_hardening_cross_evidence_audit_v1a", "manuscript_freeze_provenance_clarification_v1a", "corrected_lock_omega_m_reconstruction", "manuscript_axis_synthesis"],
        "prefer": ["v1a", "publication_hardening", "manuscript_freeze", "brancha_scientific_claims"],
        "avoid": ["repair_generic", "exact_residual", "alias", "recovery"],
        "expected_outputs": ["stage6Y", "recursive", "publication_hardening"],
    },
    {
        "order": 310,
        "milestone_id": "M31_stage7A_semantic_calibration",
        "stage_range": "Stage-7A",
        "paper_unit": "Physics-facing semantic calibration",
        "question": "How are QEG invariants given safe physics-facing labels without overclaiming?",
        "category": "mainline",
        "required": True,
        "patterns": ["stage-7a_semantic_calibration_entropic_arrow", "semantic_calibration"],
        "prefer": ["stage-7a"],
        "avoid": [],
        "expected_outputs": ["stage7A", "semantic"],
    },
    {
        "order": 320,
        "milestone_id": "M32_stage7B_time_surrogate_irreversibility",
        "stage_range": "Stage-7B",
        "paper_unit": "Time-surrogate and irreversibility evidence",
        "question": "How is operator irreversibility/time-surrogate evidence organized?",
        "category": "mainline",
        "required": True,
        "patterns": ["stage-7b_time_surrogate_robustness_operator_irreversibility", "time_surrogate"],
        "prefer": ["stage-7b"],
        "avoid": [],
        "expected_outputs": ["stage7B", "time_surrogate", "irreversibility"],
    },
    {
        "order": 330,
        "milestone_id": "M33_stage7C_evidence_hardening",
        "stage_range": "Stage-7C",
        "paper_unit": "Evidence hardening and channel-separated adjudication",
        "question": "How are entropy, operator directionality, low-k vectors, and partial reversibility separated?",
        "category": "control",
        "required": True,
        "patterns": ["stage-7c-v1m_one_script_to_rule_time_surrogate_evidence", "stage-7c-v1n_manuscript_evidence_hardening", "stage-7c-v1o_unknown_survivor_friedmann_transition"],
        "prefer": ["v1n", "v1m", "v1o"],
        "avoid": ["v1b", "v1c", "v1e", "v1f", "v1g", "v1h", "v1i", "v1j", "v1k", "v1l"],
        "expected_outputs": ["stage7C", "manuscript_evidence", "adjudication"],
    },
    {
        "order": 340,
        "milestone_id": "M34_stage7D_appendix_bundle",
        "stage_range": "Stage-7D",
        "paper_unit": "GR-adjacent appendix bundle",
        "question": "How is Friedmann/Lambda/acceleration proximity retained as appendix-only bookkeeping?",
        "category": "appendix",
        "required": False,
        "patterns": ["stage-7d_v2_friedmann_appendix_polishing", "stage-7d_v3_dark_energy", "stage-7d_v4_acceleration", "friedmann_curvature_density_time_probe"],
        "prefer": ["v2", "v3", "v4"],
        "avoid": [],
        "expected_outputs": ["stage7D", "friedmann", "lambda", "acceleration"],
    },
    {
        "order": 350,
        "milestone_id": "M35_stage7E_repository_compression",
        "stage_range": "Stage-7E",
        "paper_unit": "Repository compression and run manifest",
        "question": "How are scripts, outputs, ledgers, rescue branches, and appendices compressed for GitHub/Zenodo?",
        "category": "docs",
        "required": True,
        "patterns": ["stage-7e-v1_project_inventory_ledger_crosswalk", "stage-7e-v2_canonical_run_sequence_builder"],
        "prefer": ["v2", "canonical_run_sequence"],
        "avoid": [],
        "expected_outputs": ["stage7E_v2", "canonical_run_manifest"],
    },
]


# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------

@dataclass
class ScriptRecord:
    relpath: str
    basename: str
    stage_label: str
    version_label: str
    mtime_iso: str
    size_bytes: int
    sha256_prefix: str
    first_line_or_title: str
    v1_run_role: str = ""
    v1_branch_class: str = ""
    v1_canonical_score: float = 0.0
    v1_candidate_output_links: int = 0
    v1_strong_output_links: int = 0
    rescue_branch_class: str = ""
    deprecated_status: str = ""
    ledger_mention_count: int = 0
    ledger_first_context: str = ""
    basename_mention_count: int = 0


# ---------------------------------------------------------------------------
# I/O helpers
# ---------------------------------------------------------------------------


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def read_csv_dicts(path: Path) -> List[dict]:
    if not path.exists():
        raise FileNotFoundError(path)
    with path.open("r", newline="", encoding="utf-8", errors="ignore") as f:
        reader = csv.DictReader(f)
        return [dict(row) for row in reader]


def write_csv(path: Path, rows: Sequence[dict], fieldnames: Optional[Sequence[str]] = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if fieldnames is None:
        keys: List[str] = []
        for row in rows:
            for k in row.keys():
                if k not in keys:
                    keys.append(k)
        fieldnames = keys
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(fieldnames), extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def write_json(path: Path, obj: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding="utf-8")


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def safe_float(x: object, default: float = 0.0) -> float:
    try:
        if x is None or x == "":
            return default
        return float(x)
    except Exception:
        return default


def safe_int(x: object, default: int = 0) -> int:
    try:
        if x is None or x == "":
            return default
        return int(float(x))
    except Exception:
        return default


def compact(s: str, max_len: int = 300) -> str:
    s = re.sub(r"\s+", " ", str(s or "")).strip()
    if len(s) > max_len:
        return s[: max_len - 3] + "..."
    return s


def norm_path(s: str) -> str:
    s = str(s or "").replace("\\", "/")
    s = re.sub(r"/home/[^/]+/Downloads/010-Quantum_Emergent_Gravity/", "", s)
    s = re.sub(r"^/Downloads/010-Quantum_Emergent_Gravity/", "", s)
    s = s.strip()
    return s


def norm_key(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(s).lower()).strip("_")


def contains_any(text: str, patterns: Sequence[str]) -> bool:
    t = text.lower()
    return any(p.lower() in t for p in patterns)


def stage_sort_key(stage: str) -> Tuple[int, int, str]:
    stage = stage or "UNKNOWN_STAGE"
    m = re.search(r"Stage-([0-9]+)([A-Z]?)", stage)
    if m:
        return (int(m.group(1)), ord(m.group(2)) - 64 if m.group(2) else 0, stage)
    m = re.search(r"Stage-P([0-9]+)", stage)
    if m:
        return (1000 + int(m.group(1)), 0, stage)
    return (9999, 0, stage)


def version_sort_key(version: str) -> Tuple[int, int]:
    m = re.search(r"v([0-9]+)([a-z]?)", (version or "").lower())
    if not m:
        return (-1, -1)
    return (int(m.group(1)), ord(m.group(2)) - 96 if m.group(2) else 0)


# ---------------------------------------------------------------------------
# Ledger parsing
# ---------------------------------------------------------------------------


def locate_ledger(root: Path, explicit: Optional[Path] = None) -> Optional[Path]:
    candidates: List[Path] = []
    if explicit:
        candidates.append(explicit.expanduser())
    candidates.extend([
        root / "__qeg_evidence__" / "EVIDENCE_LEDGER.md",
        root / "EVIDENCE_LEDGER.md",
        root / "evidence_ledger.md",
        root / "metric_stage_7E_outputs" / "EVIDENCE_LEDGER.md",
    ])
    for p in candidates:
        try:
            if p.exists() and p.is_file():
                return p.resolve()
        except Exception:
            continue
    return None


def read_ledger_text(path: Optional[Path]) -> str:
    if not path:
        return ""
    try:
        return path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return ""


def infer_stage_from_nearby(text: str) -> str:
    m = re.search(r"Stage[-_ ]?([0-9]+[A-Za-z]?)", text, flags=re.IGNORECASE)
    if m:
        raw = m.group(1).upper()
        return f"Stage-{raw}"
    return "UNKNOWN_STAGE"


def extract_context(text: str, pos: int, radius: int = 360) -> str:
    start = max(0, pos - radius)
    end = min(len(text), pos + radius)
    return compact(text[start:end], 600)


def parse_ledger_script_mentions(ledger_text: str, inventory_relpaths: Sequence[str]) -> Tuple[List[dict], Dict[str, dict]]:
    """Return mention rows and mapping relpath->mention data.

    The ledger contains a mix of absolute paths, relative paths, filenames, and
    manual snippets. We match by exact normalized relpath when possible, then by
    basename. Unmatched mentions are kept for critical-missing review.
    """
    relpaths = [norm_path(x) for x in inventory_relpaths]
    rel_set = set(relpaths)
    basename_to_rels: Dict[str, List[str]] = defaultdict(list)
    for rel in relpaths:
        basename_to_rels[Path(rel).name].append(rel)

    # Regex captures most Python script mentions, including absolute paths.
    pattern = re.compile(r"([A-Za-z0-9_./\\\-]+\.py)")
    raw_mentions = []
    for m in pattern.finditer(ledger_text):
        raw = m.group(1)
        normalized = norm_path(raw)
        basename = Path(normalized).name
        context = extract_context(ledger_text, m.start())
        nearby_stage = infer_stage_from_nearby(context)

        matched = ""
        confidence = "unmatched"
        if normalized in rel_set:
            matched = normalized
            confidence = "exact_relpath"
        elif basename in basename_to_rels:
            candidates = basename_to_rels[basename]
            if len(candidates) == 1:
                matched = candidates[0]
                confidence = "basename_unique"
            else:
                # Prefer candidate whose stage appears in context or whose relpath appears partly.
                scored = []
                for c in candidates:
                    score = 0
                    if nearby_stage != "UNKNOWN_STAGE" and nearby_stage.lower() in c.lower():
                        score += 10
                    score += difflib.SequenceMatcher(None, normalized.lower(), c.lower()).ratio()
                    scored.append((score, c))
                scored.sort(reverse=True)
                matched = scored[0][1]
                confidence = "basename_ambiguous_best_effort"
        else:
            # Fuzzy fallback for absolute/variant spellings.
            names = list(basename_to_rels.keys())
            close = difflib.get_close_matches(basename, names, n=1, cutoff=0.88)
            if close:
                candidate_rels = basename_to_rels[close[0]]
                matched = candidate_rels[0]
                confidence = "fuzzy_basename"

        raw_mentions.append({
            "raw_mention": raw,
            "normalized_mention": normalized,
            "basename": basename,
            "nearby_stage": nearby_stage,
            "matched_inventory_relpath": matched,
            "match_confidence": confidence,
            "context": context,
        })

    # Aggregate mention data by inventory relpath.
    by_rel: Dict[str, dict] = {}
    for row in raw_mentions:
        rel = row.get("matched_inventory_relpath") or ""
        if not rel:
            continue
        d = by_rel.setdefault(rel, {
            "mention_count": 0,
            "basename_mention_count": 0,
            "first_context": row["context"],
            "match_confidences": Counter(),
            "raw_mentions": Counter(),
        })
        d["mention_count"] += 1
        d["basename_mention_count"] += 1
        d["match_confidences"][row["match_confidence"]] += 1
        d["raw_mentions"][row["raw_mention"]] += 1

    return raw_mentions, by_rel


def parse_ledger_milestone_blocks(ledger_text: str) -> List[dict]:
    """Extract stage-ish ledger blocks for manuscript stage map.

    This is intentionally approximate: the ledger is not a database. The goal is
    to provide searchable context for each milestone, not to replace reading.
    """
    if not ledger_text:
        return []
    # Split at common block separators while preserving enough context.
    chunks = re.split(r"(?=\n?=+\n|\n?#{2,}|\n?MANUAL_EVIDENCE_LEDGER_BLOCK|\n?ASCII LEDGER ENTRY|\n?LEDGER ENTRY)", ledger_text)
    rows = []
    for idx, chunk in enumerate(chunks):
        if len(chunk.strip()) < 80:
            continue
        stage = infer_stage_from_nearby(chunk[:1000])
        if stage == "UNKNOWN_STAGE" and not re.search(r"Stage[-_ ]?", chunk[:1000], flags=re.IGNORECASE):
            continue
        scripts = sorted(set(Path(norm_path(x)).name for x in re.findall(r"([A-Za-z0-9_./\\\-]+\.py)", chunk)))
        verdict = extract_label_line(chunk, ["Verdict", "VERDICT", "Result", "RESULT", "Status", "STATUS"])
        decision = extract_label_line(chunk, ["Decision", "DECISION", "Mathematical decision", "MATHEMATICAL DECISION", "Next step", "NEXT STEP"])
        rows.append({
            "block_index": idx,
            "stage_label_guess": stage,
            "scripts_mentioned": ";".join(scripts[:20]),
            "script_count": len(scripts),
            "verdict_or_status": compact(verdict, 400),
            "decision_or_next_step": compact(decision, 400),
            "context_snippet": compact(chunk, 900),
        })
    return rows


def extract_label_line(text: str, labels: Sequence[str]) -> str:
    for lab in labels:
        pat = re.compile(rf"^\s*{re.escape(lab)}\s*[:\-]?\s*(.+?)\s*$", re.MULTILINE)
        m = pat.search(text)
        if m:
            return m.group(1).strip()
    return ""


# ---------------------------------------------------------------------------
# v1 data loading and enrichment
# ---------------------------------------------------------------------------


def load_v1_tables(v1_dir: Path) -> Dict[str, object]:
    missing = []
    tables: Dict[str, object] = {}
    for key, fname in EXPECTED_V1_FILES.items():
        path = v1_dir / fname
        if not path.exists():
            missing.append(str(path))
            continue
        if fname.endswith(".json"):
            tables[key] = json.loads(path.read_text(encoding="utf-8", errors="ignore"))
        else:
            tables[key] = read_csv_dicts(path)
    if missing:
        raise FileNotFoundError("Missing required v1 files:\n" + "\n".join(missing))
    return tables


def build_script_records(tables: Dict[str, object], ledger_by_rel: Dict[str, dict]) -> Dict[str, ScriptRecord]:
    inv_rows: List[dict] = tables["script_inventory"]  # type: ignore
    canonical_rows: List[dict] = tables["canonical_candidates"]  # type: ignore
    rescue_rows: List[dict] = tables["rescue_classification"]  # type: ignore
    deprecated_rows: List[dict] = tables["deprecated"]  # type: ignore

    canon_by_rel = {norm_path(r.get("script_relpath", "")): r for r in canonical_rows}
    rescue_by_rel = {norm_path(r.get("script_relpath", "")): r for r in rescue_rows}
    dep_by_rel = defaultdict(list)
    for r in deprecated_rows:
        dep_by_rel[norm_path(r.get("script_relpath", ""))].append(r)

    records: Dict[str, ScriptRecord] = {}
    for r in inv_rows:
        rel = norm_path(r.get("relpath", ""))
        if not rel:
            continue
        c = canon_by_rel.get(rel, {})
        q = rescue_by_rel.get(rel, {})
        l = ledger_by_rel.get(rel, {})
        dep_status = ""
        if dep_by_rel.get(rel):
            dep_status = dep_by_rel[rel][0].get("supersession_certainty", "deprecated_candidate")
        records[rel] = ScriptRecord(
            relpath=rel,
            basename=r.get("basename", Path(rel).name),
            stage_label=r.get("stage_label", "UNKNOWN_STAGE"),
            version_label=r.get("version_label", "UNKNOWN_VERSION"),
            mtime_iso=r.get("mtime_iso", ""),
            size_bytes=safe_int(r.get("size_bytes")),
            sha256_prefix=r.get("sha256_prefix", ""),
            first_line_or_title=r.get("first_line_or_title", ""),
            v1_run_role=c.get("run_role", ""),
            v1_branch_class=c.get("branch_class", ""),
            v1_canonical_score=safe_float(c.get("canonical_score")),
            v1_candidate_output_links=safe_int(c.get("candidate_output_links")),
            v1_strong_output_links=safe_int(c.get("strong_output_links")),
            rescue_branch_class=q.get("branch_class", ""),
            deprecated_status=dep_status,
            ledger_mention_count=safe_int(l.get("mention_count", 0)),
            basename_mention_count=safe_int(l.get("basename_mention_count", 0)),
            ledger_first_context=l.get("first_context", ""),
        )
    return records


# ---------------------------------------------------------------------------
# Candidate scoring / selection
# ---------------------------------------------------------------------------


def output_links_for_script(crosswalk_rows: Sequence[dict], script_relpath: str, limit: int = 12) -> List[dict]:
    rows = [r for r in crosswalk_rows if norm_path(r.get("script_relpath", "")) == script_relpath]
    rows.sort(key=lambda r: (-safe_float(r.get("score")), r.get("output_relpath", "")))
    return rows[:limit]


def score_script_for_milestone(script: ScriptRecord, milestone: dict, crosswalk_rows: Sequence[dict]) -> Tuple[float, List[str]]:
    rel_low = script.relpath.lower()
    base_low = script.basename.lower()
    text = rel_low + " " + base_low

    score = 0.0
    reasons: List[str] = []

    # Pattern matching: required to be a candidate, but score still records strength.
    for p in milestone.get("patterns", []):
        if p.lower() in text:
            score += 60
            reasons.append(f"pattern:{p}")
            break

    for p in milestone.get("prefer", []):
        if p.lower() in text:
            score += 28
            reasons.append(f"preferred:{p}")

    for p in milestone.get("avoid", []):
        if p.lower() in text:
            score -= 35
            reasons.append(f"avoid:{p}")

    # Stage agreement.
    stage_hint = milestone.get("stage_range", "")
    if script.stage_label and script.stage_label != "UNKNOWN_STAGE":
        if script.stage_label.lower() in stage_hint.lower() or stage_hint.lower() in script.stage_label.lower():
            score += 20
            reasons.append("stage_agrees")

    # Ledger evidence is highly weighted; this is the whole point of v2.
    if script.ledger_mention_count:
        add = min(80, 18 * script.ledger_mention_count)
        score += add
        reasons.append(f"ledger_mentions:{script.ledger_mention_count}")

    # v1 audit support.
    score += min(30, script.v1_canonical_score / 5.0)
    if script.v1_candidate_output_links:
        score += min(22, script.v1_candidate_output_links * 0.8)
        reasons.append(f"crosswalk_links:{script.v1_candidate_output_links}")
    if script.v1_strong_output_links:
        score += min(20, script.v1_strong_output_links * 3)
        reasons.append(f"strong_links:{script.v1_strong_output_links}")

    # Version preference, but only mild; ledger can override.
    vk = version_sort_key(script.version_label)
    if vk[0] >= 1:
        score += min(18, 6 * vk[0] + vk[1])
        reasons.append(f"version:{script.version_label}")
    if re.search(r"v[0-9]+[a-z]?$", base_low):
        score += 2

    # Penalize quarantined candidates except when milestone is rescue/provenance.
    category = milestone.get("category", "mainline")
    if script.deprecated_status:
        score -= 45
        reasons.append(f"deprecated_candidate:{script.deprecated_status}")
    if category != "rescue" and ("rescue" in script.v1_branch_class or "repair" in script.v1_branch_class):
        score -= 18
        reasons.append("rescue_penalty_for_mainline")
    if category == "rescue" and ("rescue" in script.v1_branch_class or "repair" in script.v1_branch_class):
        score += 25
        reasons.append("rescue_role_bonus")

    # Appendix policy: Stage-7D should never be mainline.
    if script.stage_label == "Stage-7D" and category != "appendix":
        score -= 100
        reasons.append("stage7d_not_mainline")
    if category == "appendix" and script.stage_label == "Stage-7D":
        score += 30
        reasons.append("appendix_stage7d_bonus")

    return score, reasons


def find_candidates_for_milestone(records: Dict[str, ScriptRecord], milestone: dict) -> List[Tuple[float, ScriptRecord, List[str]]]:
    patterns = [p.lower() for p in milestone.get("patterns", [])]
    stage_hint = milestone.get("stage_range", "").lower()
    candidates = []
    for script in records.values():
        hay = (script.relpath + " " + script.basename).lower()
        stage_match = script.stage_label.lower() in stage_hint or stage_hint in script.stage_label.lower()
        pattern_match = any(p in hay for p in patterns)
        # Permit stage-only fallback for sparse stages, but not if many stage scripts exist unless ledger mentioned.
        ledger_relevant = script.ledger_mention_count > 0 and stage_match
        if pattern_match or ledger_relevant:
            candidates.append(script)
    return [(0.0, s, []) for s in candidates]


def select_milestones(records: Dict[str, ScriptRecord], crosswalk_rows: Sequence[dict]) -> Tuple[List[dict], List[dict]]:
    selected_rows: List[dict] = []
    candidate_rows: List[dict] = []

    for ms in MILESTONES:
        raw_candidates = [s for _, s, _ in find_candidates_for_milestone(records, ms)]
        scored: List[Tuple[float, ScriptRecord, List[str]]] = []
        for script in raw_candidates:
            score, reasons = score_script_for_milestone(script, ms, crosswalk_rows)
            if score > 0:
                scored.append((score, script, reasons))
                candidate_rows.append({
                    "milestone_order": ms["order"],
                    "milestone_id": ms["milestone_id"],
                    "milestone_category": ms["category"],
                    "script_relpath": script.relpath,
                    "stage_label": script.stage_label,
                    "version_label": script.version_label,
                    "score": round(score, 3),
                    "ledger_mention_count": script.ledger_mention_count,
                    "v1_canonical_score": script.v1_canonical_score,
                    "v1_candidate_output_links": script.v1_candidate_output_links,
                    "deprecated_status": script.deprecated_status,
                    "reasons": ";".join(reasons),
                })
        scored.sort(key=lambda x: (-x[0], x[1].relpath))

        if scored:
            best_score, best, reasons = scored[0]
            links = output_links_for_script(crosswalk_rows, best.relpath, limit=10)
            top_outputs = [norm_path(r.get("output_relpath", "")) for r in links]
            top_output_scores = [str(r.get("score", "")) for r in links]
            selection_status = "selected_auto"
            if len(scored) > 1 and scored[1][0] >= best_score - 12:
                selection_status = "selected_auto_close_competition"
            selected_rows.append({
                "run_order": ms["order"],
                "milestone_id": ms["milestone_id"],
                "stage_range": ms["stage_range"],
                "paper_unit": ms["paper_unit"],
                "question_answered": ms["question"],
                "manifest_role": category_to_manifest_role(ms["category"]),
                "required_for_minimal_pipeline": str(bool(ms["required"])),
                "selection_status": selection_status,
                "selected_script_relpath": best.relpath,
                "selected_script_basename": best.basename,
                "stage_label": best.stage_label,
                "version_label": best.version_label,
                "selection_score": round(best_score, 3),
                "ledger_mention_count": best.ledger_mention_count,
                "v1_canonical_score": best.v1_canonical_score,
                "v1_candidate_output_links": best.v1_candidate_output_links,
                "v1_strong_output_links": best.v1_strong_output_links,
                "deprecated_status": best.deprecated_status,
                "selection_reasons": ";".join(reasons),
                "top_crosswalk_outputs": ";".join(top_outputs),
                "top_crosswalk_output_scores": ";".join(top_output_scores),
                "expected_output_keywords": ";".join(ms.get("expected_outputs", [])),
                "human_override_action": "keep_selected / replace / demote / skip / split_milestone",
                "human_override_script_relpath": "",
                "human_notes": "",
                "ledger_context_excerpt": best.ledger_first_context,
            })
        else:
            selected_rows.append({
                "run_order": ms["order"],
                "milestone_id": ms["milestone_id"],
                "stage_range": ms["stage_range"],
                "paper_unit": ms["paper_unit"],
                "question_answered": ms["question"],
                "manifest_role": category_to_manifest_role(ms["category"]),
                "required_for_minimal_pipeline": str(bool(ms["required"])),
                "selection_status": "MISSING_REQUIRED" if ms["required"] else "missing_optional",
                "selected_script_relpath": "",
                "selected_script_basename": "",
                "stage_label": "",
                "version_label": "",
                "selection_score": "",
                "ledger_mention_count": "",
                "v1_canonical_score": "",
                "v1_candidate_output_links": "",
                "v1_strong_output_links": "",
                "deprecated_status": "",
                "selection_reasons": "no candidate matched milestone patterns or ledger/stage evidence",
                "top_crosswalk_outputs": "",
                "top_crosswalk_output_scores": "",
                "expected_output_keywords": ";".join(ms.get("expected_outputs", [])),
                "human_override_action": "replace / skip / create_reconstruction_script",
                "human_override_script_relpath": "",
                "human_notes": "",
                "ledger_context_excerpt": "",
            })

    return selected_rows, candidate_rows


def category_to_manifest_role(category: str) -> str:
    return {
        "mainline": "canonical_mainline",
        "control": "control_or_adversarial",
        "rescue": "rescue_provenance_only",
        "appendix": "appendix_only",
        "docs": "documentation_infrastructure",
    }.get(category, "manual_review")


# ---------------------------------------------------------------------------
# Additional manifests
# ---------------------------------------------------------------------------


def build_control_manifest(selected_rows: Sequence[dict]) -> List[dict]:
    return [r for r in selected_rows if r.get("manifest_role") == "control_or_adversarial"]


def build_appendix_manifest(selected_rows: Sequence[dict]) -> List[dict]:
    return [r for r in selected_rows if r.get("manifest_role") == "appendix_only"]


def build_rescue_manifest(selected_rows: Sequence[dict], rescue_rows: Sequence[dict]) -> List[dict]:
    selected_rescue = [dict(r) for r in selected_rows if r.get("manifest_role") == "rescue_provenance_only"]
    selected_paths = {r.get("selected_script_relpath") for r in selected_rescue}
    for r in rescue_rows:
        rel = norm_path(r.get("script_relpath", ""))
        if rel and rel not in selected_paths and ("rescue" in (r.get("branch_class", "") or "") or "repair" in (r.get("branch_class", "") or "")):
            selected_rescue.append({
                "run_order": "",
                "milestone_id": "additional_rescue_from_v1_classification",
                "stage_range": r.get("stage_label", ""),
                "paper_unit": "Rescue/provenance history",
                "question_answered": "What repair/rescue scripts must be preserved as provenance?",
                "manifest_role": "rescue_provenance_only",
                "required_for_minimal_pipeline": "False",
                "selection_status": "not_minimal_preserve_for_provenance",
                "selected_script_relpath": rel,
                "selected_script_basename": Path(rel).name,
                "stage_label": r.get("stage_label", ""),
                "version_label": r.get("version_label", ""),
                "selection_score": "",
                "selection_reasons": r.get("classification_reason", ""),
                "top_crosswalk_outputs": "",
                "human_override_action": "keep_as_provenance / quarantine / promote_to_control",
                "human_notes": "",
            })
    return selected_rescue


def build_deprecated_manifest(deprecated_rows: Sequence[dict]) -> List[dict]:
    rows = []
    for r in deprecated_rows:
        rows.append({
            "script_relpath": norm_path(r.get("script_relpath", "")),
            "stage_label": r.get("stage_label", ""),
            "version_label": r.get("version_label", ""),
            "family_signature": r.get("family_signature", ""),
            "superseded_by_relpath": norm_path(r.get("superseded_by_relpath", "")),
            "superseded_by_version": r.get("superseded_by_version", ""),
            "supersession_certainty": r.get("supersession_certainty", ""),
            "quarantine_recommendation": "quarantine_do_not_delete_until_manual_review",
            "note": r.get("note", ""),
        })
    return rows


def build_critical_missing(selected_rows: Sequence[dict], raw_ledger_mentions: Sequence[dict], records: Dict[str, ScriptRecord]) -> List[dict]:
    rows = []
    for r in selected_rows:
        if r.get("selection_status") == "MISSING_REQUIRED":
            rows.append({
                "issue_type": "required_milestone_no_script_selected",
                "severity": "critical",
                "stage_or_milestone": r.get("milestone_id", ""),
                "script_or_mention": "",
                "matched_inventory_relpath": "",
                "details": r.get("question_answered", ""),
                "recommended_action": "Inspect v1 script inventory and ledger; add manual override or create reconstruction script.",
            })

    for m in raw_ledger_mentions:
        if not m.get("matched_inventory_relpath"):
            base = m.get("basename", "")
            severity = "review"
            if re.search(r"stage[-_ ]?[4-7]|metric_stage", base, flags=re.IGNORECASE):
                severity = "high"
            rows.append({
                "issue_type": "ledger_mentions_script_not_in_inventory",
                "severity": severity,
                "stage_or_milestone": m.get("nearby_stage", ""),
                "script_or_mention": m.get("normalized_mention", ""),
                "matched_inventory_relpath": "",
                "details": m.get("context", ""),
                "recommended_action": "Check whether script exists outside scanned root, was renamed, is embedded in outputs, or should be recreated/documented as historical.",
            })
    return rows


# ---------------------------------------------------------------------------
# Markdown/text generation
# ---------------------------------------------------------------------------


def make_canonical_run_sequence_md(selected_rows: Sequence[dict], summary: dict) -> str:
    mainline = [r for r in selected_rows if r.get("manifest_role") in {"canonical_mainline", "documentation_infrastructure"}]
    lines = []
    lines.append("# Stage-7E-v2 Canonical Run Sequence Draft")
    lines.append("")
    lines.append(f"Generated: {summary['generated_utc']}")
    lines.append("")
    lines.append("## Purpose")
    lines.append("")
    lines.append("This is a compression draft for the minimal effective QEG pipeline. It is not yet the final GitHub README.")
    lines.append("It uses both the Stage-7E-v1 audit tables and the master evidence ledger.")
    lines.append("")
    lines.append("## Rule")
    lines.append("")
    lines.append("One best script is retained per scientific milestone. Rescue scripts are preserved as provenance; null/adversarial scripts are separated as controls; Stage-7D is appendix-only.")
    lines.append("")
    lines.append("## Minimal Mainline Sequence")
    lines.append("")
    lines.append("| Step | Milestone | Paper unit | Selected script | Status | Key outputs |")
    lines.append("|---:|---|---|---|---|---|")
    for i, r in enumerate(mainline, 1):
        script = r.get("selected_script_relpath") or "**MISSING**"
        outs = compact(r.get("top_crosswalk_outputs", ""), 180).replace(";", "<br>")
        status = r.get("selection_status", "")
        lines.append(f"| {i} | {r.get('milestone_id')} | {r.get('paper_unit')} | `{script}` | {status} | {outs} |")
    lines.append("")
    lines.append("## Human review before final README")
    lines.append("")
    lines.append("Edit `stage7E_v2_human_selection_manifest.csv`, especially rows marked `selected_auto_close_competition`, `MISSING_REQUIRED`, or with low ledger support.")
    return "\n".join(lines) + "\n"


def make_control_run_sequence_md(rows: Sequence[dict], summary: dict) -> str:
    lines = [
        "# Stage-7E-v2 Control / Adversarial Run Sequence Draft",
        "",
        f"Generated: {summary['generated_utc']}",
        "",
        "These scripts support the claims by testing nulls, adversarial alternatives, non-tautology, source-probe robustness, recursive stability, or time-surrogate ambiguity.",
        "",
        "| Order | Milestone | Selected script | Role | Notes |",
        "|---:|---|---|---|---|",
    ]
    for r in rows:
        lines.append(f"| {r.get('run_order')} | {r.get('milestone_id')} | `{r.get('selected_script_relpath') or 'MISSING'}` | {r.get('manifest_role')} | {compact(r.get('question_answered',''), 160)} |")
    return "\n".join(lines) + "\n"


def make_appendix_run_sequence_md(rows: Sequence[dict], summary: dict) -> str:
    lines = [
        "# Stage-7E-v2 Appendix-Only Run Sequence Draft",
        "",
        f"Generated: {summary['generated_utc']}",
        "",
        "Stage-7D is retained as GR-adjacent comparison bookkeeping only. It is not part of the main derivation chain.",
        "",
        "Forbidden: deriving GR, Friedmann equations, LambdaCDM, cosmic time, dark energy, or age of the Universe.",
        "",
        "| Order | Milestone | Selected script | Appendix role |",
        "|---:|---|---|---|",
    ]
    for r in rows:
        lines.append(f"| {r.get('run_order')} | {r.get('milestone_id')} | `{r.get('selected_script_relpath') or 'MISSING'}` | {r.get('paper_unit')} |")
    return "\n".join(lines) + "\n"


def make_minimal_effective_pipeline_md(selected_rows: Sequence[dict], summary: dict) -> str:
    main = [r for r in selected_rows if r.get("manifest_role") == "canonical_mainline"]
    controls = [r for r in selected_rows if r.get("manifest_role") == "control_or_adversarial"]
    rescues = [r for r in selected_rows if r.get("manifest_role") == "rescue_provenance_only"]
    appendix = [r for r in selected_rows if r.get("manifest_role") == "appendix_only"]

    lines = [
        "# Minimal Effective QEG Pipeline — Stage-7E-v2 Draft",
        "",
        f"Generated: {summary['generated_utc']}",
        "",
        "## What this file is",
        "",
        "A researcher-facing compressed map of the QEG script tree. It is intended to become the basis for the GitHub README, but it remains a draft until the human selection manifest is reviewed.",
        "",
        "## Mainline scientific chain",
        "",
        "```text",
        "PDG-origin family roots",
        "-> shell-band / commutator observables",
        "-> canonical microfeatures and Stage-5 bridge",
        "-> intrinsic angular coordinate",
        "-> candidate metric geometry and admissibility boundary",
        "-> intrinsic curvature/density fields",
        "-> nonlocal kappa-to-rho operator",
        "-> canonical two-sector law",
        "-> family universality",
        "-> recursive/time/semantic hardening",
        "-> repository/manuscript freeze",
        "```",
        "",
        "## Mainline scripts",
        "",
    ]
    for r in main:
        lines.append(f"### {r.get('run_order')}. {r.get('paper_unit')}")
        lines.append("")
        lines.append(f"Question: {r.get('question_answered')}")
        lines.append("")
        script = r.get("selected_script_relpath") or "MISSING"
        lines.append(f"Script: `{script}`")
        lines.append("")
        if r.get("top_crosswalk_outputs"):
            lines.append("Representative outputs:")
            for out in r.get("top_crosswalk_outputs", "").split(";")[:6]:
                if out:
                    lines.append(f"- `{out}`")
        lines.append("")

    lines.append("## Rescue/provenance branches")
    lines.append("")
    for r in rescues:
        lines.append(f"- `{r.get('selected_script_relpath') or 'MISSING'}` — {r.get('paper_unit')}")
    lines.append("")

    lines.append("## Controls and adversarial checks")
    lines.append("")
    for r in controls:
        lines.append(f"- `{r.get('selected_script_relpath') or 'MISSING'}` — {r.get('paper_unit')}")
    lines.append("")

    lines.append("## Appendix-only branch")
    lines.append("")
    for r in appendix:
        lines.append(f"- `{r.get('selected_script_relpath') or 'MISSING'}` — appendix-only GR-adjacent bookkeeping")
    lines.append("")

    lines.append("## Non-claim guardrail")
    lines.append("")
    for c in FORBIDDEN_CLAIMS:
        lines.append(f"- Do not write: {c}.")
    return "\n".join(lines) + "\n"


def make_readme_skeleton_md(summary: dict) -> str:
    return f"""# Quantum-Emergent Gravity — Reproducibility README Skeleton

Generated by: `Stage-7E-v2_canonical_run_sequence_builder.py`  
Generated UTC: {summary['generated_utc']}

## Scope

This repository contains a documented computational emergence pipeline. The current claim class is not that QEG derives quantum gravity or LambdaCDM. The main claim class is that the pipeline identifies a reproducible, family-preserving, nonlocal operator geometry with a stable two-sector law.

## How to reproduce

1. Review `stage7E_v2_human_selection_manifest.csv`.
2. Accept or edit any borderline selections.
3. Use `stage7E_v2_canonical_run_sequence.md` as the mainline sequence.
4. Use `stage7E_v2_control_run_sequence.md` for null/adversarial controls.
5. Use `stage7E_v2_appendix_run_sequence.md` for appendix-only GR-adjacent comparisons.
6. Do not rerun rescue scripts unless reconstructing provenance.

## Repository structure recommendation

- `scripts/mainline/` — canonical mainline scripts
- `scripts/controls/` — null/adversarial/control scripts
- `scripts/rescue_provenance/` — repair/rebuild scripts preserved for audit
- `scripts/appendix_gr_adjacent/` — Stage-7D appendix-only scripts
- `outputs/canonical_tables/` — manuscript table sources
- `outputs/canonical_figures/` — manuscript figure sources
- `ledgers/` — evidence ledgers and transition packages

## Claim guardrails

Forbidden claims:

{chr(10).join('- ' + c for c in FORBIDDEN_CLAIMS)}

## Next file to write

After human review of the v2 manifest, write the final `README.md` and Zenodo manifest.
"""


def make_ledger_note(summary: dict) -> str:
    return f"""============================================================
Stage-7E-v2 Ledger Note
Project: Quantum-Emergent Gravity
Script: Stage-7E-v2_canonical_run_sequence_builder.py
Generated: {summary['generated_utc']}
============================================================

Purpose:
  Stage-7E-v2 compresses the Stage-7E-v1 inventory/crosswalk audit using
  the master evidence ledger. Its purpose is to select a minimal effective
  QEG run sequence suitable for GitHub/Zenodo preparation, while preserving
  rescue provenance, controls, and appendix-only branches separately.

Inputs:
  v1 audit directory: {summary['v1_input_dir']}
  evidence ledger  : {summary.get('ledger_path') or 'NOT FOUND'}

Outputs:
  - stage7E_v2_ledger_script_mentions.csv
  - stage7E_v2_ledger_milestone_blocks.csv
  - stage7E_v2_milestone_candidate_scores.csv
  - stage7E_v2_canonical_run_manifest.csv
  - stage7E_v2_human_selection_manifest.csv
  - stage7E_v2_control_manifest.csv
  - stage7E_v2_appendix_manifest.csv
  - stage7E_v2_rescue_provenance_manifest.csv
  - stage7E_v2_deprecated_quarantine_manifest.csv
  - stage7E_v2_critical_missing_scripts.csv
  - stage7E_v2_canonical_run_sequence.md
  - stage7E_v2_control_run_sequence.md
  - stage7E_v2_appendix_run_sequence.md
  - stage7E_v2_minimal_effective_pipeline.md
  - stage7E_v2_readme_skeleton.md
  - stage7E_v2_summary.json
  - stage7E_v2_ledger_note.txt
  - stage7E_v2_ascii_transition_package.txt

Counts:
  Milestones in taxonomy       : {summary['milestone_count']}
  Auto-selected milestones     : {summary['selected_count']}
  Missing required milestones  : {summary['missing_required_count']}
  Mainline selected scripts    : {summary['mainline_count']}
  Control selected scripts     : {summary['control_count']}
  Rescue selected scripts      : {summary['rescue_count']}
  Appendix selected scripts    : {summary['appendix_count']}
  Ledger script mentions found : {summary['ledger_mention_rows']}
  Unmatched ledger mentions    : {summary['unmatched_ledger_mentions']}

Interpretation:
  This is still not the final README. It is the script-generated compression
  layer. The next human action is to review `stage7E_v2_human_selection_manifest.csv`,
  edit borderline rows, and then generate the final README / Zenodo manifest.

Guardrail:
  Stage-7D remains appendix-only. Rescue scripts are preserved as provenance,
  not required reruns. Controls/adversarial/null scripts are separated from
  the mainline chain.

============================================================
END LEDGER NOTE
============================================================
"""


def make_ascii_transition_package(summary: dict) -> str:
    return f"""============================================================
ASCII TRANSITION PACKAGE
Project: Quantum-Emergent Gravity
Stage: Stage-7E-v2
Working Title: Canonical Run Sequence Builder
Generated: {summary['generated_utc']}
Status: READ-ONLY COMPRESSION SCRIPT PRODUCED
============================================================

PURPOSE
-------
Stage-7E-v2 converts the broad Stage-7E-v1 inventory into a
minimal effective run-manifest draft.

It is guided by:

1. Stage-7E-v1 script inventory
2. Stage-7E-v1 script-output crosswalk
3. Stage-7E-v1 rescue/deprecated classifications
4. Master evidence ledger
5. Manuscript-facing milestone taxonomy

It does not create new physics results.
It does not rerun scientific scripts.
It does not delete or modify existing project files.

------------------------------------------------------------
MAIN DECISION
------------------------------------------------------------

The repository is too large to turn directly into GitHub documentation.
The project must first pass through a compression layer.

Therefore v2 selects:

- one best script per scientific milestone,
- separate control/adversarial scripts,
- separate rescue/provenance scripts,
- separate appendix-only Stage-7D scripts,
- deprecated/quarantine candidates,
- missing or odd ledger/inventory discrepancies.

------------------------------------------------------------
OUTPUT DIRECTORY
------------------------------------------------------------

{summary['v2_output_dir']}

------------------------------------------------------------
KEY OUTPUTS
------------------------------------------------------------

stage7E_v2_canonical_run_manifest.csv
stage7E_v2_human_selection_manifest.csv
stage7E_v2_canonical_run_sequence.md
stage7E_v2_minimal_effective_pipeline.md
stage7E_v2_control_run_sequence.md
stage7E_v2_appendix_run_sequence.md
stage7E_v2_rescue_provenance_manifest.csv
stage7E_v2_deprecated_quarantine_manifest.csv
stage7E_v2_critical_missing_scripts.csv
stage7E_v2_readme_skeleton.md

------------------------------------------------------------
SUMMARY COUNTS
------------------------------------------------------------

Milestones in taxonomy       : {summary['milestone_count']}
Auto-selected milestones     : {summary['selected_count']}
Missing required milestones  : {summary['missing_required_count']}
Mainline selected scripts    : {summary['mainline_count']}
Control selected scripts     : {summary['control_count']}
Rescue selected scripts      : {summary['rescue_count']}
Appendix selected scripts    : {summary['appendix_count']}
Ledger script mentions found : {summary['ledger_mention_rows']}
Unmatched ledger mentions    : {summary['unmatched_ledger_mentions']}

------------------------------------------------------------
NEXT ACTION
------------------------------------------------------------

Open and edit:

    stage7E_v2_human_selection_manifest.csv

Focus on rows marked:

    selected_auto_close_competition
    MISSING_REQUIRED
    missing_optional
    low ledger support
    deprecated_candidate

Then prepare:

    Stage-7E-v3_manuscript_asset_freeze.py

or write the final GitHub README if the v2 manifest is accepted.

------------------------------------------------------------
CLAIM GUARDRAIL
------------------------------------------------------------

Main claim class:

    reproducible, family-preserving emergent nonlocal operator geometry
    with a stable two-sector law.

Appendix-only claim class:

    Friedmann / Lambda / acceleration bookkeeping produces a coherent
    GR-adjacent proximity corridor.

Forbidden:

{chr(10).join('    - ' + c for c in FORBIDDEN_CLAIMS)}

============================================================
END STAGE-7E-v2 ASCII TRANSITION PACKAGE
============================================================
"""


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Build Stage-7E-v2 canonical run sequence from v1 audit outputs and master evidence ledger.")
    p.add_argument("--root", type=Path, default=DEFAULT_ROOT, help=f"QEG project root. Default: {DEFAULT_ROOT}")
    p.add_argument("--v1-dir", type=Path, default=None, help="Stage-7E-v1 output directory. Default: <root>/metric_stage_7E_outputs/project_inventory_ledger_crosswalk_v1")
    p.add_argument("--output-dir", type=Path, default=None, help="Stage-7E-v2 output directory. Default: <root>/metric_stage_7E_outputs/canonical_run_sequence_builder_v2")
    p.add_argument("--ledger", type=Path, default=None, help="Path to master evidence ledger. Default: auto-search root/__qeg_evidence__/EVIDENCE_LEDGER.md then root/EVIDENCE_LEDGER.md")
    return p.parse_args(argv)


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = parse_args(argv)
    root = args.root.expanduser().resolve()
    v1_dir = (args.v1_dir.expanduser().resolve() if args.v1_dir else (root / DEFAULT_V1_REL).resolve())
    outdir = (args.output_dir.expanduser().resolve() if args.output_dir else (root / DEFAULT_V2_REL).resolve())
    outdir.mkdir(parents=True, exist_ok=True)

    print("=" * 72)
    print("Stage-7E-v2: Canonical Run Sequence Builder")
    print("=" * 72)
    print(f"Project root : {root}")
    print(f"v1 input dir : {v1_dir}")
    print(f"v2 output dir: {outdir}")

    if not v1_dir.exists():
        print(f"ERROR: v1 input directory does not exist: {v1_dir}", file=sys.stderr)
        return 2

    ledger_path = locate_ledger(root, args.ledger)
    ledger_text = read_ledger_text(ledger_path)
    print(f"Ledger path  : {ledger_path if ledger_path else 'NOT FOUND'}")
    print(f"Ledger bytes : {len(ledger_text.encode('utf-8')) if ledger_text else 0}")

    tables = load_v1_tables(v1_dir)
    script_inventory: List[dict] = tables["script_inventory"]  # type: ignore
    crosswalk_rows: List[dict] = tables["crosswalk"]  # type: ignore
    rescue_rows: List[dict] = tables["rescue_classification"]  # type: ignore
    deprecated_rows: List[dict] = tables["deprecated"]  # type: ignore

    inventory_relpaths = [norm_path(r.get("relpath", "")) for r in script_inventory]
    raw_ledger_mentions, ledger_by_rel = parse_ledger_script_mentions(ledger_text, inventory_relpaths)
    ledger_blocks = parse_ledger_milestone_blocks(ledger_text)
    records = build_script_records(tables, ledger_by_rel)

    selected_rows, candidate_rows = select_milestones(records, crosswalk_rows)
    control_rows = build_control_manifest(selected_rows)
    appendix_rows = build_appendix_manifest(selected_rows)
    rescue_manifest = build_rescue_manifest(selected_rows, rescue_rows)
    deprecated_manifest = build_deprecated_manifest(deprecated_rows)
    critical_missing = build_critical_missing(selected_rows, raw_ledger_mentions, records)

    selected_count = sum(1 for r in selected_rows if str(r.get("selection_status", "")).startswith("selected"))
    missing_required = sum(1 for r in selected_rows if r.get("selection_status") == "MISSING_REQUIRED")
    mainline_count = sum(1 for r in selected_rows if r.get("manifest_role") == "canonical_mainline" and r.get("selected_script_relpath"))
    control_count = len([r for r in control_rows if r.get("selected_script_relpath")])
    rescue_count = len([r for r in rescue_manifest if r.get("selected_script_relpath")])
    appendix_count = len([r for r in appendix_rows if r.get("selected_script_relpath")])
    unmatched_mentions = sum(1 for r in raw_ledger_mentions if not r.get("matched_inventory_relpath"))

    summary = {
        "generated_utc": utc_now(),
        "script_name": "Stage-7E-v2_canonical_run_sequence_builder.py",
        "project_root": str(root),
        "v1_input_dir": str(v1_dir),
        "v2_output_dir": str(outdir),
        "ledger_path": str(ledger_path) if ledger_path else "",
        "ledger_bytes": len(ledger_text.encode("utf-8")) if ledger_text else 0,
        "v1_script_count": len(script_inventory),
        "v1_crosswalk_link_count": len(crosswalk_rows),
        "milestone_count": len(MILESTONES),
        "selected_count": selected_count,
        "missing_required_count": missing_required,
        "mainline_count": mainline_count,
        "control_count": control_count,
        "rescue_count": rescue_count,
        "appendix_count": appendix_count,
        "ledger_mention_rows": len(raw_ledger_mentions),
        "unmatched_ledger_mentions": unmatched_mentions,
        "critical_missing_rows": len(critical_missing),
        "stage7E_policy": {
            "mode": "read_only_compression",
            "stage7D_status": "appendix_only_guarded_GR_adjacent_bundle",
            "rescue_policy": "preserve_as_provenance_not_required_rerun",
            "control_policy": "separate_from_mainline",
            "forbidden_claims": FORBIDDEN_CLAIMS,
        },
    }

    # Prepare ledger mention rows for CSV, compressing contexts.
    ledger_mention_rows = []
    for r in raw_ledger_mentions:
        ledger_mention_rows.append({
            "raw_mention": r.get("raw_mention", ""),
            "normalized_mention": r.get("normalized_mention", ""),
            "basename": r.get("basename", ""),
            "nearby_stage": r.get("nearby_stage", ""),
            "matched_inventory_relpath": r.get("matched_inventory_relpath", ""),
            "match_confidence": r.get("match_confidence", ""),
            "context": r.get("context", ""),
        })

    # Output CSV manifests.
    write_csv(outdir / "stage7E_v2_ledger_script_mentions.csv", ledger_mention_rows)
    write_csv(outdir / "stage7E_v2_ledger_milestone_blocks.csv", ledger_blocks)
    write_csv(outdir / "stage7E_v2_milestone_candidate_scores.csv", candidate_rows)
    write_csv(outdir / "stage7E_v2_canonical_run_manifest.csv", selected_rows)
    write_csv(outdir / "stage7E_v2_human_selection_manifest.csv", selected_rows)
    write_csv(outdir / "stage7E_v2_control_manifest.csv", control_rows)
    write_csv(outdir / "stage7E_v2_appendix_manifest.csv", appendix_rows)
    write_csv(outdir / "stage7E_v2_rescue_provenance_manifest.csv", rescue_manifest)
    write_csv(outdir / "stage7E_v2_deprecated_quarantine_manifest.csv", deprecated_manifest)
    write_csv(outdir / "stage7E_v2_critical_missing_scripts.csv", critical_missing)

    # Markdown / text outputs.
    write_text(outdir / "stage7E_v2_canonical_run_sequence.md", make_canonical_run_sequence_md(selected_rows, summary))
    write_text(outdir / "stage7E_v2_control_run_sequence.md", make_control_run_sequence_md(control_rows, summary))
    write_text(outdir / "stage7E_v2_appendix_run_sequence.md", make_appendix_run_sequence_md(appendix_rows, summary))
    write_text(outdir / "stage7E_v2_minimal_effective_pipeline.md", make_minimal_effective_pipeline_md(selected_rows, summary))
    write_text(outdir / "stage7E_v2_readme_skeleton.md", make_readme_skeleton_md(summary))
    write_json(outdir / "stage7E_v2_summary.json", summary)
    write_text(outdir / "stage7E_v2_ledger_note.txt", make_ledger_note(summary))
    write_text(outdir / "stage7E_v2_ascii_transition_package.txt", make_ascii_transition_package(summary))

    print("-" * 72)
    print("Done.")
    print(f"Milestones selected       : {selected_count}/{len(MILESTONES)}")
    print(f"Missing required          : {missing_required}")
    print(f"Mainline selected         : {mainline_count}")
    print(f"Controls selected         : {control_count}")
    print(f"Rescue/provenance selected: {rescue_count}")
    print(f"Appendix selected         : {appendix_count}")
    print(f"Unmatched ledger mentions : {unmatched_mentions}")
    print()
    print("Key review files:")
    print(f"  {outdir / 'stage7E_v2_human_selection_manifest.csv'}")
    print(f"  {outdir / 'stage7E_v2_canonical_run_sequence.md'}")
    print(f"  {outdir / 'stage7E_v2_minimal_effective_pipeline.md'}")
    print(f"  {outdir / 'stage7E_v2_critical_missing_scripts.csv'}")
    print("=" * 72)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
