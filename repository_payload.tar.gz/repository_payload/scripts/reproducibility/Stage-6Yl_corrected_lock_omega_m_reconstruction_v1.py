#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Quantum-Emergent Gravity
Stage-6Yl: Corrected-Lock Omega_m Reconstruction

Author: Arturo Ortiz-Tapia / prepared with ChatGPT
Build Date: 2026-05-25

Purpose
-------
Reconstruct the sharp Omega_m comparator

    early_central_separation

under corrected column-locking and run a Pareto/cross-benchmark guardrail.

This script is intentionally conservative.

It MUST NOT:
    - fit to Omega_m
    - tune or rescale QEG outputs toward Omega_m
    - choose features only because they are close to Omega_m
    - degrade the cross-benchmark panel to improve Omega_m
    - claim that QEG derives Omega_m

It MAY:
    - recover already-defined QEG rows from corrected/locked tables
    - recompute early_central_separation from early/central lobe parameters
    - audit family and resolution stability
    - compare dimensionless invariants to PDG benchmarks as bookkeeping
    - assign promotion/demotion/rejection status

Expected project root
---------------------
/home/dakini/Downloads/010-Quantum_Emergent_Gravity

Recommended terminal run
------------------------
python3 Stage-6Yl_corrected_lock_omega_m_reconstruction_v1.py \
    --root /home/dakini/Downloads/010-Quantum_Emergent_Gravity \
    --overwrite

Spyder Console run
------------------
%runfile /path/to/Stage-6Yl_corrected_lock_omega_m_reconstruction_v1.py --args --root /home/dakini/Downloads/010-Quantum_Emergent_Gravity --overwrite

Output directory
----------------
metric_stage_6Yl_outputs/
"""

from __future__ import annotations

import argparse
import datetime as _dt
import json
import math
import os
import re
import sys
import traceback
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

try:
    import numpy as np
    import pandas as pd
except Exception as exc:  # pragma: no cover
    print("ERROR: This script requires numpy and pandas.")
    print("Import failure:", repr(exc))
    raise


# ============================================================
# Fixed benchmark bookkeeping values
# ============================================================

STAGE = "6Yl"
SCRIPT_NAME = "Stage-6Yl_corrected_lock_omega_m_reconstruction_v1.py"

OMEGA_M_BENCHMARK = 0.315
GLOBAL_MU_VALUE = 0.327995
GLOBAL_MU_PERCENT_ERROR = abs(GLOBAL_MU_VALUE - OMEGA_M_BENCHMARK) / OMEGA_M_BENCHMARK * 100.0
HISTORICAL_EARLY_CENTRAL_SEPARATION = 0.317696

# PDG / cosmology bookkeeping panel used in prior QEG stages.
# These are comparison targets only, not fit targets.
BENCHMARKS = {
    "Omega_m": {"value": 0.315, "uncertainty": 0.007, "scoring": "relative_percent"},
    "Omega_b": {"value": 0.0493, "uncertainty": 0.0006, "scoring": "relative_percent"},
    "Omega_c": {"value": 0.265, "uncertainty": 0.007, "scoring": "relative_percent"},
    "Omega_Lambda": {"value": 0.685, "uncertainty": 0.007, "scoring": "relative_percent"},
    "Omega_K": {"value": 0.0007, "uncertainty": 0.0019, "scoring": "absolute_window"},
    "sigma8": {"value": 0.811, "uncertainty": 0.006, "scoring": "relative_percent"},
    "S8": {"value": 0.832, "uncertainty": 0.013, "scoring": "relative_percent"},
}
BENCHMARKS["Omega_b/Omega_m"] = {
    "value": BENCHMARKS["Omega_b"]["value"] / BENCHMARKS["Omega_m"]["value"],
    "uncertainty": None,
    "scoring": "relative_percent",
}
BENCHMARKS["Omega_c/Omega_m"] = {
    "value": BENCHMARKS["Omega_c"]["value"] / BENCHMARKS["Omega_m"]["value"],
    "uncertainty": None,
    "scoring": "relative_percent",
}

FAMILY_TOKENS = ("BARI", "NUFIT", "VALENCIA")
LOCK_TOKENS = ("corrected", "locked", "column_lock", "column-locked", "lineage", "lineage-safe", "trusted")
BAD_COPY_TOKENS = ("historical_copy", "copy_forward", "copied", "manual", "target_forced", "pdg_fitted", "fit_to_omega")

REQUIRED_INPUTS = [
    "metric_stage_6Yj_outputs/stage6Yj_manuscript_raw_result_table.csv",
    "metric_stage_6Yj_outputs/stage6Yj_omega_m_refinement_panel.csv",
    "metric_stage_6Yj_outputs/stage6Yj_curvature_refinement_panel.csv",
    "metric_stage_6Yj_outputs/stage6Yj_pdg_benchmark_table.csv",
    "metric_stage_6Yj_outputs/stage6Yj_claim_status_matrix.csv",
    "metric_stage_6Yj_outputs/stage6Yj_error_mechanism_table.csv",
    "metric_stage_6Yj_outputs/stage6Yj_figure_table_freeze_manifest.csv",
    "metric_stage_6Yj_outputs/stage6Yj_summary.json",
    "metric_stage_6Yk_outputs/stage6Yk_omega_m_refinement_candidates.csv",
    "metric_stage_6Yk_outputs/stage6Yk_benchmark_guardrail_baseline.csv",
    "metric_stage_6Yk_outputs/stage6Yk_cross_constant_feature_forcing_audit.csv",
    "metric_stage_6Yk_outputs/stage6Yk_refinement_decision_table.csv",
    "metric_stage_6Yk_outputs/stage6Yk_summary.json",
    "metric_stage_6Yk_outputs/stage6Yk_review_flags.csv",
    "metric_stage_6Yk_outputs/Stage-6Yk_omega_m_pareto_refinement_notes.txt",
]

OPTIONAL_GLOB_PATTERNS = [
    "metric_stage_6Q_outputs/**/*canonical*.csv",
    "metric_stage_6Q_outputs/**/*.json",
    "metric_stage_6P_outputs/**/*.csv",
    "metric_stage_6O_outputs/**/*.csv",
    "metric_stage_6Yi_outputs/**/*.csv",
    "metric_stage_6Yi_outputs/**/*.json",
    "metric_stage_6Yj_outputs/**/*.csv",
    "metric_stage_6Yj_outputs/**/*.json",
    "metric_stage_6Yk_outputs/**/*.csv",
    "metric_stage_6Yk_outputs/**/*.json",
    "metric_stage_6Yk_outputs/**/*.txt",
]


# ============================================================
# Data structures
# ============================================================

@dataclass
class Candidate:
    strategy: str
    feature_name: str
    value: float
    formula: str
    source_file: str
    source_row_index: Optional[int] = None
    value_column: Optional[str] = None
    family: Optional[str] = None
    resolution: Optional[str] = None
    corrected_lock_evidence: bool = False
    lineage_evidence: bool = False
    trust_evidence: bool = False
    copied_or_historical_only: bool = False
    notes: str = ""

    def percent_error_vs_omega_m(self) -> float:
        return percent_error(self.value, OMEGA_M_BENCHMARK)

    def improvement_factor_vs_global_mu(self) -> Optional[float]:
        err = self.percent_error_vs_omega_m()
        if err <= 0:
            return math.inf
        return GLOBAL_MU_PERCENT_ERROR / err


# ============================================================
# Utilities
# ============================================================

def now_iso() -> str:
    return _dt.datetime.now().replace(microsecond=0).isoformat()


def safe_rel(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve()))
    except Exception:
        return str(path)


def mkdir_output(out_dir: Path, overwrite: bool) -> None:
    if out_dir.exists() and any(out_dir.iterdir()) and not overwrite:
        raise FileExistsError(
            f"Output directory exists and is not empty: {out_dir}\n"
            "Use --overwrite to replace Stage-6Yl outputs."
        )
    out_dir.mkdir(parents=True, exist_ok=True)


def normalize_col(c: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(c).strip().lower()).strip("_")


def normalize_text(x: Any) -> str:
    if x is None:
        return ""
    if isinstance(x, float) and math.isnan(x):
        return ""
    return str(x)


def row_text(row: pd.Series) -> str:
    return " | ".join(normalize_text(v) for v in row.values)


def any_token(text: str, tokens: Iterable[str]) -> bool:
    t = text.lower()
    return any(tok.lower() in t for tok in tokens)


def percent_error(value: Any, benchmark: float) -> float:
    try:
        v = float(value)
    except Exception:
        return math.nan
    if benchmark == 0:
        return math.nan
    return abs(v - benchmark) / abs(benchmark) * 100.0


def absolute_error(value: Any, benchmark: float) -> float:
    try:
        v = float(value)
    except Exception:
        return math.nan
    return abs(v - benchmark)


def coerce_numeric_series(s: pd.Series) -> pd.Series:
    return pd.to_numeric(s, errors="coerce")


def is_finite_unitish(x: Any) -> bool:
    try:
        v = float(x)
    except Exception:
        return False
    return math.isfinite(v) and (-1.0 <= v <= 2.0)


def choose_value_columns(df: pd.DataFrame) -> List[str]:
    cols = []
    for c in df.columns:
        cn = normalize_col(c)
        if any(bad in cn for bad in ["percent", "error", "err", "benchmark", "uncert", "rank", "index", "row", "id"]):
            continue
        if any(tok in cn for tok in [
            "value", "qeg", "candidate", "feature", "invariant", "estimate",
            "separation", "mu", "center", "centre", "mean", "median"
        ]):
            # require at least one numeric-ish value
            vals = pd.to_numeric(df[c], errors="coerce")
            if vals.notna().any():
                cols.append(c)
    return cols


def detect_family_from_row(row: pd.Series) -> Optional[str]:
    # Prefer explicit family-like columns
    for c in row.index:
        cn = normalize_col(c)
        if cn in {"family", "fit", "fit_id", "source_family", "pdg_family", "lineage_family"} or "family" in cn or cn in {"fit", "fit_id"}:
            text = normalize_text(row[c]).upper()
            for fam in FAMILY_TOKENS:
                if fam in text:
                    return fam
    text = row_text(row).upper()
    for fam in FAMILY_TOKENS:
        if fam in text:
            return fam
    return None


def detect_resolution_from_row(row: pd.Series, source_file: str = "") -> Optional[str]:
    for c in row.index:
        cn = normalize_col(c)
        if any(tok in cn for tok in ["resolution", "bins", "bin_count", "n_bins", "grid", "profile_bins"]):
            val = normalize_text(row[c])
            if val:
                return val
    text = row_text(row) + " " + source_file
    m = re.search(r"\b(48|361)\s*[-_ ]?bins?\b", text, flags=re.IGNORECASE)
    if m:
        return f"{m.group(1)}bins"
    return None


def infer_evidence(row: Optional[pd.Series], source_file: str) -> Tuple[bool, bool, bool, bool, str]:
    text = (row_text(row) if row is not None else "") + " " + source_file
    lower = text.lower()
    corrected = any(tok in lower for tok in ["corrected", "lock", "locked", "column_lock", "column-locked"])
    lineage = any(tok in lower for tok in ["lineage", "family", "bari", "nufit", "valencia", "provenance"])
    trust = any(tok in lower for tok in ["trusted", "primary", "safe", "claim_status", "manuscript", "strict"])
    copied = any(tok in lower for tok in BAD_COPY_TOKENS)
    notes = []
    if corrected:
        notes.append("corrected/lock token detected")
    if lineage:
        notes.append("lineage/family token detected")
    if trust:
        notes.append("trust/manuscript token detected")
    if copied:
        notes.append("copy/historical/target-forcing token detected")
    return corrected, lineage, trust, copied, "; ".join(notes)


def read_json_keys(path: Path) -> Dict[str, Any]:
    try:
        with open(path, "r", encoding="utf-8") as f:
            obj = json.load(f)
    except Exception as exc:
        return {"__json_read_error__": repr(exc)}
    return obj if isinstance(obj, dict) else {"__json_root_type__": type(obj).__name__}


def flatten_json(obj: Any, prefix: str = "") -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    if isinstance(obj, dict):
        for k, v in obj.items():
            key = f"{prefix}.{k}" if prefix else str(k)
            out.update(flatten_json(v, key))
    elif isinstance(obj, list):
        # Do not explode huge lists; sample first few scalar/list entries.
        for i, v in enumerate(obj[:20]):
            key = f"{prefix}[{i}]"
            out.update(flatten_json(v, key))
    else:
        out[prefix] = obj
    return out


def load_table(path: Path) -> Optional[pd.DataFrame]:
    try:
        return pd.read_csv(path)
    except Exception:
        try:
            return pd.read_csv(path, encoding="latin1")
        except Exception:
            return None


def write_json(path: Path, obj: Dict[str, Any]) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, sort_keys=True)


def df_to_csv(df: pd.DataFrame, path: Path) -> None:
    df.to_csv(path, index=False)


# ============================================================
# Input discovery and audit
# ============================================================

def discover_files(root: Path) -> Tuple[List[Path], List[Path]]:
    required = [root / rel for rel in REQUIRED_INPUTS]
    optional: List[Path] = []
    for pattern in OPTIONAL_GLOB_PATTERNS:
        optional.extend(root.glob(pattern))
    # Deduplicate while preserving sort order
    seen = set()
    all_paths = []
    for p in required + sorted(optional):
        rp = str(p)
        if rp not in seen:
            seen.add(rp)
            all_paths.append(p)
    return required, all_paths


def input_audit(root: Path, paths: List[Path]) -> pd.DataFrame:
    rows = []
    for p in paths:
        rel = safe_rel(p, root)
        status = "missing"
        nrows = None
        ncols = None
        key_columns = []
        lineage_columns = []
        corrected_lock_columns = []
        family_columns = []
        benchmark_columns = []
        notes = ""
        if p.exists():
            try:
                if p.suffix.lower() == ".csv":
                    df = load_table(p)
                    if df is None:
                        status = "failed"
                        notes = "CSV read failed"
                    else:
                        status = "loaded"
                        nrows, ncols = df.shape
                        cols_norm = {c: normalize_col(c) for c in df.columns}
                        key_columns = [
                            c for c, cn in cols_norm.items()
                            if any(tok in cn for tok in ["feature", "value", "benchmark", "claim", "status", "formula", "mu", "separation"])
                        ]
                        lineage_columns = [
                            c for c, cn in cols_norm.items()
                            if any(tok in cn for tok in ["lineage", "provenance", "source", "fit_id", "fit", "family"])
                        ]
                        corrected_lock_columns = [
                            c for c, cn in cols_norm.items()
                            if any(tok in cn for tok in ["corrected", "lock", "locked", "column"])
                        ]
                        family_columns = [
                            c for c, cn in cols_norm.items()
                            if any(tok in cn for tok in ["family", "fit", "fit_id", "bari", "nufit", "valencia"])
                        ]
                        benchmark_columns = [
                            c for c, cn in cols_norm.items()
                            if any(tok in cn for tok in ["omega", "sigma8", "s8", "benchmark", "pdg"])
                        ]
                elif p.suffix.lower() == ".json":
                    obj = read_json_keys(p)
                    status = "loaded" if "__json_read_error__" not in obj else "failed"
                    flat = flatten_json(obj)
                    nrows = 1
                    ncols = len(flat)
                    keys = list(flat.keys())
                    key_columns = [k for k in keys if re.search(r"feature|value|benchmark|claim|status|formula|mu|separation", k, re.I)]
                    lineage_columns = [k for k in keys if re.search(r"lineage|provenance|source|fit_id|fit|family", k, re.I)]
                    corrected_lock_columns = [k for k in keys if re.search(r"corrected|lock|locked|column", k, re.I)]
                    family_columns = [k for k in keys if re.search(r"family|fit|fit_id|bari|nufit|valencia", k, re.I)]
                    benchmark_columns = [k for k in keys if re.search(r"omega|sigma8|s8|benchmark|pdg", k, re.I)]
                    if status == "failed":
                        notes = obj.get("__json_read_error__", "")
                elif p.suffix.lower() == ".txt":
                    status = "loaded"
                    text = p.read_text(encoding="utf-8", errors="replace")[:20000]
                    nrows = text.count("\n") + 1
                    ncols = None
                    if any(tok.lower() in text.lower() for tok in LOCK_TOKENS):
                        corrected_lock_columns = ["text-token"]
                    if any(fam in text.upper() for fam in FAMILY_TOKENS):
                        family_columns = ["text-token"]
                        lineage_columns = ["text-token"]
                    if re.search(r"omega|sigma8|S8|benchmark|PDG", text, re.I):
                        benchmark_columns = ["text-token"]
                else:
                    status = "exists_unread"
            except Exception as exc:
                status = "failed"
                notes = repr(exc)

        rows.append({
            "file_path": rel,
            "status": status,
            "row_count": nrows,
            "column_count": ncols,
            "key_columns_detected": "; ".join(map(str, key_columns[:40])),
            "lineage_columns_detected": "; ".join(map(str, lineage_columns[:40])),
            "corrected_lock_columns_detected": "; ".join(map(str, corrected_lock_columns[:40])),
            "family_columns_detected": "; ".join(map(str, family_columns[:40])),
            "benchmark_columns_detected": "; ".join(map(str, benchmark_columns[:40])),
            "notes": notes,
            "required": rel in REQUIRED_INPUTS,
        })
    return pd.DataFrame(rows)


# ============================================================
# Candidate extraction: strategy 1, direct corrected-lock row recovery
# ============================================================

FEATURE_PATTERNS = [
    re.compile(r"early[_\-\s]*central[_\-\s]*separation", re.I),
    re.compile(r"early.*central.*separation", re.I),
    re.compile(r"central.*early.*separation", re.I),
]

MU_EARLY_PATTERNS = [
    re.compile(r"\bmu[_\-\s]*early\b", re.I),
    re.compile(r"\bearly[_\-\s]*mu\b", re.I),
    re.compile(r"early.*(center|centre|centroid|lobe)", re.I),
    re.compile(r"mu.*early", re.I),
]

MU_CENTRAL_PATTERNS = [
    re.compile(r"\bmu[_\-\s]*central\b", re.I),
    re.compile(r"\bcentral[_\-\s]*mu\b", re.I),
    re.compile(r"central.*(center|centre|centroid|lobe)", re.I),
    re.compile(r"mu.*central", re.I),
]


def matches_any(text: str, patterns: List[re.Pattern]) -> bool:
    return any(p.search(text) for p in patterns)


def extract_direct_candidates_from_csv(path: Path, root: Path) -> List[Candidate]:
    df = load_table(path)
    if df is None or df.empty:
        return []
    candidates: List[Candidate] = []
    rel = safe_rel(path, root)
    value_cols = choose_value_columns(df)

    # Row-wise search: any string column mentions early_central_separation.
    for idx, row in df.iterrows():
        text = row_text(row)
        if not matches_any(text, FEATURE_PATTERNS):
            continue

        # First preference: value columns whose column name itself mentions separation/value.
        ranked_value_cols = sorted(
            value_cols,
            key=lambda c: (
                0 if "separation" in normalize_col(c) else 1,
                0 if any(tok in normalize_col(c) for tok in ["value", "candidate", "qeg", "feature"]) else 1,
                normalize_col(c),
            ),
        )
        for c in ranked_value_cols:
            val = row.get(c)
            if not is_finite_unitish(val):
                continue
            corrected, lineage, trust, copied, notes = infer_evidence(row, rel)
            candidates.append(Candidate(
                strategy="direct_corrected_lock_row_recovery",
                feature_name="early_central_separation",
                value=float(val),
                formula=f"direct recovered table row: value from column '{c}'",
                source_file=rel,
                source_row_index=int(idx),
                value_column=str(c),
                family=detect_family_from_row(row),
                resolution=detect_resolution_from_row(row, rel),
                corrected_lock_evidence=corrected,
                lineage_evidence=lineage,
                trust_evidence=trust,
                copied_or_historical_only=copied,
                notes=notes,
            ))
            # Avoid too many equivalent values per row unless there are multiple explicit separation columns.
            if "separation" not in normalize_col(c):
                break

    # Wide-column search: any numeric column name itself is early_central_separation.
    for c in df.columns:
        cn_text = str(c)
        if not matches_any(cn_text, FEATURE_PATTERNS):
            continue
        vals = pd.to_numeric(df[c], errors="coerce")
        for idx, v in vals.dropna().items():
            if not is_finite_unitish(v):
                continue
            row = df.loc[idx]
            corrected, lineage, trust, copied, notes = infer_evidence(row, rel)
            candidates.append(Candidate(
                strategy="direct_wide_column_recovery",
                feature_name="early_central_separation",
                value=float(v),
                formula=f"direct recovered wide column: '{c}'",
                source_file=rel,
                source_row_index=int(idx),
                value_column=str(c),
                family=detect_family_from_row(row),
                resolution=detect_resolution_from_row(row, rel),
                corrected_lock_evidence=corrected,
                lineage_evidence=lineage,
                trust_evidence=trust,
                copied_or_historical_only=copied,
                notes=notes,
            ))

    return candidates


def extract_direct_candidates_from_json(path: Path, root: Path) -> List[Candidate]:
    rel = safe_rel(path, root)
    obj = read_json_keys(path)
    if "__json_read_error__" in obj:
        return []
    flat = flatten_json(obj)
    candidates: List[Candidate] = []
    full_text = json.dumps(obj, default=str)[:500000]
    corrected = any(tok in full_text.lower() or tok in rel.lower() for tok in ["corrected", "lock", "locked", "column"])
    lineage = any(tok.lower() in full_text.lower() or tok.lower() in rel.lower() for tok in ["lineage", "family", "bari", "nufit", "valencia", "provenance"])
    trust = any(tok in full_text.lower() or tok in rel.lower() for tok in ["trusted", "primary", "safe", "claim_status", "manuscript", "strict"])
    copied = any(tok in full_text.lower() or tok in rel.lower() for tok in BAD_COPY_TOKENS)

    for k, v in flat.items():
        if matches_any(k, FEATURE_PATTERNS) and is_finite_unitish(v):
            candidates.append(Candidate(
                strategy="direct_json_key_recovery",
                feature_name="early_central_separation",
                value=float(v),
                formula=f"direct recovered JSON key: '{k}'",
                source_file=rel,
                source_row_index=None,
                value_column=k,
                family=None,
                resolution=detect_resolution_from_row(pd.Series({"key": k, "value": v}), rel),
                corrected_lock_evidence=corrected,
                lineage_evidence=lineage,
                trust_evidence=trust,
                copied_or_historical_only=copied,
                notes="JSON direct key recovery",
            ))
    return candidates


# ============================================================
# Candidate extraction: strategy 2, canonical parameter reconstruction
# ============================================================

def extract_mu_pairs_wide(path: Path, root: Path) -> List[Candidate]:
    df = load_table(path)
    if df is None or df.empty:
        return []
    rel = safe_rel(path, root)
    candidates: List[Candidate] = []

    early_cols = [c for c in df.columns if matches_any(str(c), MU_EARLY_PATTERNS)]
    central_cols = [c for c in df.columns if matches_any(str(c), MU_CENTRAL_PATTERNS)]

    for ec in early_cols:
        for cc in central_cols:
            ev = pd.to_numeric(df[ec], errors="coerce")
            cv = pd.to_numeric(df[cc], errors="coerce")
            both = pd.DataFrame({"early": ev, "central": cv}).dropna()
            for idx, rr in both.iterrows():
                early = float(rr["early"])
                central = float(rr["central"])
                if not (math.isfinite(early) and math.isfinite(central)):
                    continue
                if not (-0.25 <= early <= 1.25 and -0.25 <= central <= 1.25):
                    continue
                sep = abs(central - early)
                if not (0 <= sep <= 1.25):
                    continue
                row = df.loc[idx]
                corrected, lineage, trust, copied, notes = infer_evidence(row, rel)
                candidates.append(Candidate(
                    strategy="canonical_parameter_reconstruction_wide",
                    feature_name="early_central_separation",
                    value=sep,
                    formula=f"abs({cc} - {ec}) = abs({central:.12g} - {early:.12g})",
                    source_file=rel,
                    source_row_index=int(idx),
                    value_column=f"{ec};{cc}",
                    family=detect_family_from_row(row),
                    resolution=detect_resolution_from_row(row, rel),
                    corrected_lock_evidence=corrected or "6q" in rel.lower() or "6p" in rel.lower(),
                    lineage_evidence=lineage,
                    trust_evidence=trust or "canonical" in rel.lower(),
                    copied_or_historical_only=copied,
                    notes=notes,
                ))
    return candidates


def extract_mu_pairs_long(path: Path, root: Path) -> List[Candidate]:
    df = load_table(path)
    if df is None or df.empty:
        return []
    rel = safe_rel(path, root)
    candidates: List[Candidate] = []
    value_cols = choose_value_columns(df)

    # Identify likely label columns.
    label_cols = [
        c for c in df.columns
        if any(tok in normalize_col(c) for tok in ["feature", "parameter", "name", "quantity", "metric", "invariant", "label"])
    ]
    if not label_cols or not value_cols:
        return []

    # Build records for early and central mu rows.
    records = []
    for idx, row in df.iterrows():
        labels = " | ".join(normalize_text(row.get(c)) for c in label_cols)
        kind = None
        if matches_any(labels, MU_EARLY_PATTERNS):
            kind = "early"
        elif matches_any(labels, MU_CENTRAL_PATTERNS):
            kind = "central"
        if kind is None:
            continue
        for vc in value_cols:
            val = row.get(vc)
            if is_finite_unitish(val):
                records.append({
                    "idx": int(idx),
                    "kind": kind,
                    "value": float(val),
                    "value_col": vc,
                    "family": detect_family_from_row(row),
                    "resolution": detect_resolution_from_row(row, rel),
                    "row": row,
                })
                break

    if not records:
        return []

    # Pair within same family/resolution if available; otherwise pair global rows.
    rec_df = pd.DataFrame([{k: v for k, v in r.items() if k != "row"} for r in records])
    group_keys = []
    if rec_df["family"].notna().any():
        group_keys.append("family")
    if rec_df["resolution"].notna().any():
        group_keys.append("resolution")
    if not group_keys:
        group_keys = ["__all__"]
        rec_df["__all__"] = "all"

    for _, g in rec_df.groupby(group_keys, dropna=False):
        early_rows = g[g["kind"] == "early"]
        central_rows = g[g["kind"] == "central"]
        if early_rows.empty or central_rows.empty:
            continue
        # Use first matching rows within group; script logs row ids.
        for _, er in early_rows.iterrows():
            for _, cr in central_rows.iterrows():
                early = float(er["value"])
                central = float(cr["value"])
                sep = abs(central - early)
                if not (0 <= sep <= 1.25):
                    continue
                source_row = records[int(er.name)]["row"] if isinstance(er.name, int) and er.name < len(records) else None
                row_for_evidence = source_row if source_row is not None else pd.Series({})
                corrected, lineage, trust, copied, notes = infer_evidence(row_for_evidence, rel)
                candidates.append(Candidate(
                    strategy="canonical_parameter_reconstruction_long",
                    feature_name="early_central_separation",
                    value=sep,
                    formula=f"abs(mu_central - mu_early) = abs({central:.12g} - {early:.12g}); rows {int(cr['idx'])}, {int(er['idx'])}",
                    source_file=rel,
                    source_row_index=None,
                    value_column=f"{er['value_col']};{cr['value_col']}",
                    family=er.get("family") if pd.notna(er.get("family")) else None,
                    resolution=er.get("resolution") if pd.notna(er.get("resolution")) else None,
                    corrected_lock_evidence=corrected or "6q" in rel.lower() or "6p" in rel.lower(),
                    lineage_evidence=lineage,
                    trust_evidence=trust or "canonical" in rel.lower(),
                    copied_or_historical_only=copied,
                    notes=notes,
                ))
    return candidates


def extract_all_candidates(root: Path, paths: List[Path]) -> List[Candidate]:
    candidates: List[Candidate] = []
    for p in paths:
        if not p.exists():
            continue
        if p.suffix.lower() == ".csv":
            try:
                candidates.extend(extract_direct_candidates_from_csv(p, root))
                candidates.extend(extract_mu_pairs_wide(p, root))
                candidates.extend(extract_mu_pairs_long(p, root))
            except Exception as exc:
                print(f"WARNING: candidate extraction failed for {safe_rel(p, root)}: {exc}")
        elif p.suffix.lower() == ".json":
            try:
                candidates.extend(extract_direct_candidates_from_json(p, root))
            except Exception as exc:
                print(f"WARNING: JSON candidate extraction failed for {safe_rel(p, root)}: {exc}")

    # Deduplicate approximate duplicates by strategy/source/value/family/resolution/formula.
    uniq = {}
    for c in candidates:
        key = (
            c.strategy,
            c.source_file,
            c.source_row_index,
            c.value_column,
            round(float(c.value), 12),
            c.family or "",
            c.resolution or "",
        )
        uniq[key] = c
    return list(uniq.values())


# ============================================================
# Candidate scoring and selection
# ============================================================

def candidate_priority(c: Candidate) -> Tuple[int, int, int, int, int, float, str]:
    """Lower tuple is better. Omega_m closeness is deliberately not used."""
    strategy_rank = {
        "direct_corrected_lock_row_recovery": 0,
        "direct_wide_column_recovery": 1,
        "direct_json_key_recovery": 2,
        "canonical_parameter_reconstruction_wide": 3,
        "canonical_parameter_reconstruction_long": 4,
    }.get(c.strategy, 9)

    corrected_penalty = 0 if c.corrected_lock_evidence else 1
    lineage_penalty = 0 if c.lineage_evidence else 1
    trust_penalty = 0 if c.trust_evidence else 1
    copied_penalty = 1 if c.copied_or_historical_only else 0

    # Prefer Stage-6Yj/Yk corrected manuscript tables, then canonical Stage-6Q/P.
    src = c.source_file.lower()
    src_rank = 4
    if "6yj" in src:
        src_rank = 0
    elif "6yk" in src:
        src_rank = 1
    elif "6q" in src:
        src_rank = 2
    elif "6p" in src or "6o" in src:
        src_rank = 3

    return (copied_penalty, strategy_rank, corrected_penalty, lineage_penalty, trust_penalty, float(src_rank), c.source_file)


def select_primary_candidate(candidates: List[Candidate]) -> Optional[Candidate]:
    if not candidates:
        return None
    valid = [c for c in candidates if math.isfinite(float(c.value)) and 0 <= float(c.value) <= 1.25]
    if not valid:
        return None
    return sorted(valid, key=candidate_priority)[0]


def candidates_to_dataframe(candidates: List[Candidate]) -> pd.DataFrame:
    rows = []
    for c in candidates:
        d = asdict(c)
        d["percent_error_vs_Omega_m"] = c.percent_error_vs_omega_m()
        d["improvement_factor_vs_global_mu"] = c.improvement_factor_vs_global_mu()
        d["candidate_priority_tuple"] = str(candidate_priority(c))
        rows.append(d)
    if not rows:
        return pd.DataFrame(columns=[
            "strategy", "feature_name", "value", "formula", "source_file",
            "source_row_index", "value_column", "family", "resolution",
            "corrected_lock_evidence", "lineage_evidence", "trust_evidence",
            "copied_or_historical_only", "notes", "percent_error_vs_Omega_m",
            "improvement_factor_vs_global_mu", "candidate_priority_tuple",
        ])
    return pd.DataFrame(rows)


# ============================================================
# Family / resolution stability
# ============================================================

def stability_audit(candidates: List[Candidate], selected: Optional[Candidate]) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    rows = []
    summary: Dict[str, Any] = {
        "family_stability_status": "NOT_RECOVERABLE",
        "resolution_stability_status": "NOT_RECOVERABLE",
        "family_value_range": None,
        "resolution_value_range": None,
        "family_count": 0,
        "resolution_count": 0,
    }

    if not candidates:
        return pd.DataFrame(), summary

    df = candidates_to_dataframe(candidates)
    if df.empty:
        return pd.DataFrame(), summary

    # Prefer candidates with the same strategy and source as selected for stability comparison,
    # but fall back to all reconstructed candidates if needed.
    compare = df.copy()
    if selected is not None:
        local = compare[
            (compare["strategy"] == selected.strategy)
            & (compare["source_file"] == selected.source_file)
        ]
        if len(local) >= 2:
            compare = local

    if "family" in compare.columns and compare["family"].notna().any():
        fam_df = compare.dropna(subset=["family"]).copy()
        fam_df["family"] = fam_df["family"].astype(str)
        fam_group = fam_df.groupby("family")["value"].agg(["count", "mean", "std", "min", "max"]).reset_index()
        fam_range = float(fam_group["mean"].max() - fam_group["mean"].min()) if len(fam_group) > 1 else 0.0
        summary["family_value_range"] = fam_range
        summary["family_count"] = int(len(fam_group))
        if len(fam_group) >= 3 and fam_range <= 0.025:
            summary["family_stability_status"] = "PASS_FAMILY_SPREAD_SMALL"
        elif len(fam_group) >= 2 and fam_range <= 0.05:
            summary["family_stability_status"] = "REVIEW_FAMILY_SPREAD_MODERATE"
        else:
            summary["family_stability_status"] = "REVIEW_OR_FAIL_FAMILY_SPREAD"
        for _, r in fam_group.iterrows():
            rows.append({
                "audit_type": "family",
                "group": r["family"],
                "count": int(r["count"]),
                "mean_value": r["mean"],
                "std_value": r["std"],
                "min_value": r["min"],
                "max_value": r["max"],
                "range_across_groups": fam_range,
                "status": summary["family_stability_status"],
            })

    if "resolution" in compare.columns and compare["resolution"].notna().any():
        res_df = compare.dropna(subset=["resolution"]).copy()
        res_df["resolution"] = res_df["resolution"].astype(str)
        res_group = res_df.groupby("resolution")["value"].agg(["count", "mean", "std", "min", "max"]).reset_index()
        res_range = float(res_group["mean"].max() - res_group["mean"].min()) if len(res_group) > 1 else 0.0
        summary["resolution_value_range"] = res_range
        summary["resolution_count"] = int(len(res_group))
        if len(res_group) >= 2 and res_range <= 0.025:
            summary["resolution_stability_status"] = "PASS_RESOLUTION_DRIFT_SMALL"
        elif len(res_group) >= 2 and res_range <= 0.05:
            summary["resolution_stability_status"] = "REVIEW_RESOLUTION_DRIFT_MODERATE"
        else:
            summary["resolution_stability_status"] = "REVIEW_OR_FAIL_RESOLUTION_DRIFT"
        for _, r in res_group.iterrows():
            rows.append({
                "audit_type": "resolution",
                "group": r["resolution"],
                "count": int(r["count"]),
                "mean_value": r["mean"],
                "std_value": r["std"],
                "min_value": r["min"],
                "max_value": r["max"],
                "range_across_groups": res_range,
                "status": summary["resolution_stability_status"],
            })

    return pd.DataFrame(rows), summary


# ============================================================
# Cross-benchmark guardrail
# ============================================================

def near_flatness_class(value: float, benchmark: float, uncertainty: Optional[float]) -> str:
    ae = absolute_error(value, benchmark)
    if uncertainty is None or uncertainty <= 0:
        if ae <= 0.002:
            return "near_flat_small_absolute_error"
        return "absolute_error_logged_no_window"
    if ae <= uncertainty:
        return "inside_1sigma_window"
    if ae <= 2 * uncertainty:
        return "inside_2sigma_window"
    if ae <= 3 * uncertainty:
        return "inside_3sigma_window"
    return "outside_3sigma_window"


def cross_benchmark_guardrail(selected: Optional[Candidate]) -> Tuple[pd.DataFrame, str]:
    rows = []
    guardrail_status = "PASS_NO_CROSS_BENCHMARK_Deterioration".upper()

    for name, info in BENCHMARKS.items():
        bench = float(info["value"])
        uncertainty = info.get("uncertainty")
        scoring = info["scoring"]

        previous_feature = "unchanged_or_not_reassessed"
        previous_value = np.nan
        proposed_feature = "unchanged"
        proposed_value = np.nan
        rel_error = np.nan
        abs_err = np.nan
        uncertainty_status = ""
        deterioration_flag = False
        guardrail_row_status = "UNCHANGED_BOOKKEEPING"

        if name == "Omega_m":
            previous_feature = "global_mu"
            previous_value = GLOBAL_MU_VALUE
            if selected is not None:
                proposed_feature = selected.feature_name
                proposed_value = selected.value
                rel_error = percent_error(proposed_value, bench)
                abs_err = absolute_error(proposed_value, bench)
                prev_error = percent_error(previous_value, bench)
                deterioration_flag = rel_error > prev_error
                guardrail_row_status = "PROPOSED_IMPROVES" if not deterioration_flag else "PROPOSED_DETERIORATES"
            else:
                proposed_feature = "none_reconstructed"
                proposed_value = np.nan
                rel_error = np.nan
                abs_err = np.nan
                deterioration_flag = False
                guardrail_row_status = "NO_RECONSTRUCTION"
        elif name == "Omega_K":
            # No proposed modification. Log special absolute-window logic explicitly.
            guardrail_row_status = "ABSOLUTE_WINDOW_LOGIC_REQUIRED_NO_RELATIVE_PERCENT"
            uncertainty_status = near_flatness_class(bench, bench, uncertainty)
        else:
            # No proposed modification. This is the point: Omega_m refinement must not degrade other rows.
            guardrail_row_status = "NO_CHANGE_NO_Deterioration".upper()

        if scoring == "absolute_window" and name == "Omega_K":
            # If a future proposed value is added, it must be absolute-window scored.
            rel_error = np.nan
            abs_err = 0.0
            uncertainty_status = near_flatness_class(bench, bench, uncertainty)
        elif math.isfinite(proposed_value) if isinstance(proposed_value, (int, float, np.floating)) else False:
            uncertainty_status = "not_applicable_relative_percent"

        rows.append({
            "benchmark": name,
            "benchmark_value": bench,
            "benchmark_uncertainty": uncertainty,
            "scoring_policy": scoring,
            "previous_best_feature": previous_feature,
            "previous_best_value": previous_value,
            "proposed_refined_feature": proposed_feature,
            "proposed_refined_value": proposed_value,
            "relative_percent_error": rel_error,
            "absolute_error": abs_err,
            "uncertainty_status": uncertainty_status,
            "deterioration_flag": deterioration_flag,
            "guardrail_status": guardrail_row_status,
            "claim_status": "comparison_bookkeeping_only_no_physical_identification",
        })

    guardrail_df = pd.DataFrame(rows)
    if bool(guardrail_df["deterioration_flag"].fillna(False).any()):
        guardrail_status = "FAIL_GUARDRAIL_BREACH"
    else:
        guardrail_status = "PASS_NO_CROSS_BENCHMARK_DETERIORATION"
    return guardrail_df, guardrail_status


# ============================================================
# Review flags and verdict
# ============================================================

def build_review_flags(
    root: Path,
    audit_df: pd.DataFrame,
    selected: Optional[Candidate],
    all_candidates: List[Candidate],
    stability: Dict[str, Any],
    guardrail_status: str,
) -> pd.DataFrame:
    flags = []

    def add(code: str, severity: str, blocking: bool, message: str, evidence: str = ""):
        flags.append({
            "flag_code": code,
            "severity": severity,
            "blocking": bool(blocking),
            "message": message,
            "evidence": evidence,
        })

    required_missing = audit_df[(audit_df["required"] == True) & (audit_df["status"] != "loaded")]
    if len(required_missing) > 0:
        add(
            "MISSING_REQUIRED_INPUTS",
            "WARN",
            False,
            "Some Stage-6Yj/6Yk required files are missing. Optional sources may still permit reconstruction, but promotion should be cautious.",
            "; ".join(required_missing["file_path"].head(20).astype(str).tolist()),
        )

    if selected is None:
        add(
            "NO_RECONSTRUCTED_CANDIDATE",
            "BLOCKING",
            True,
            "No reconstructed early_central_separation candidate was recovered from loaded inputs.",
            f"candidate_count={len(all_candidates)}",
        )
    else:
        if not selected.corrected_lock_evidence:
            add(
                "NO_CORRECTED_LOCK_EVIDENCE",
                "BLOCKING",
                True,
                "Selected candidate lacks explicit corrected/column-lock evidence.",
                selected.source_file,
            )
        if selected.copied_or_historical_only:
            add(
                "COPY_OR_HISTORICAL_ONLY_RISK",
                "BLOCKING",
                True,
                "Selected candidate appears copied, historical, manual, or target-forced rather than reconstructed.",
                selected.notes,
            )
        if not selected.lineage_evidence:
            add(
                "LINEAGE_EVIDENCE_WEAK",
                "WARN",
                False,
                "Selected candidate lacks strong lineage/family/provenance evidence.",
                selected.source_file,
            )
        if not selected.trust_evidence:
            add(
                "TRUST_STATUS_WEAK",
                "WARN",
                False,
                "Selected candidate lacks explicit trust/manuscript/strict label evidence.",
                selected.source_file,
            )
        err = selected.percent_error_vs_omega_m()
        if not math.isfinite(err) or err >= GLOBAL_MU_PERCENT_ERROR:
            add(
                "OMEGA_M_NOT_IMPROVED",
                "BLOCKING",
                True,
                "Selected candidate does not materially improve over global_mu.",
                f"candidate_error={err}, global_mu_error={GLOBAL_MU_PERCENT_ERROR}",
            )
        elif err >= 1.0:
            add(
                "OMEGA_M_IMPROVES_BUT_NOT_SUB_PERCENT",
                "INFO",
                False,
                "Selected candidate improves over global_mu but is not below 1 percent error.",
                f"candidate_error={err}",
            )

    fam_status = stability.get("family_stability_status", "NOT_RECOVERABLE")
    if fam_status == "NOT_RECOVERABLE":
        add(
            "FAMILY_STABILITY_NOT_RECOVERABLE",
            "WARN",
            False,
            "Family-separated reconstruction was not recoverable from available candidate rows.",
            "",
        )
    elif "FAIL" in fam_status or "REVIEW_OR_FAIL" in fam_status:
        add(
            "FAMILY_STABILITY_REVIEW",
            "WARN",
            False,
            "Family spread requires review before primary promotion.",
            json.dumps({k: stability.get(k) for k in ["family_stability_status", "family_value_range", "family_count"]}),
        )

    res_status = stability.get("resolution_stability_status", "NOT_RECOVERABLE")
    if res_status == "NOT_RECOVERABLE":
        add(
            "RESOLUTION_STABILITY_NOT_RECOVERABLE",
            "WARN",
            False,
            "Resolution-stability reconstruction was not recoverable from available candidate rows.",
            "",
        )
    elif "FAIL" in res_status or "REVIEW_OR_FAIL" in res_status:
        add(
            "RESOLUTION_STABILITY_REVIEW",
            "WARN",
            False,
            "Resolution drift requires review before primary promotion.",
            json.dumps({k: stability.get(k) for k in ["resolution_stability_status", "resolution_value_range", "resolution_count"]}),
        )

    if guardrail_status == "FAIL_GUARDRAIL_BREACH":
        add(
            "CROSS_BENCHMARK_GUARDRAIL_BREACH",
            "BLOCKING",
            True,
            "Cross-benchmark guardrail detected deterioration.",
            guardrail_status,
        )

    if not flags:
        add(
            "NO_REVIEW_FLAGS",
            "INFO",
            False,
            "No review flags triggered.",
            "",
        )
    return pd.DataFrame(flags)


def decide_verdict(
    selected: Optional[Candidate],
    review_df: pd.DataFrame,
    stability: Dict[str, Any],
    guardrail_status: str,
    required_missing_count: int,
) -> Tuple[str, str]:
    blocking = bool(review_df["blocking"].fillna(False).any()) if not review_df.empty else False

    if selected is None:
        if required_missing_count > 0:
            return (
                "E_INPUTS_INCOMPLETE_REPAIR_REQUIRED",
                "Necessary corrected-lock inputs were incomplete and no sufficient optional reconstruction source produced a candidate.",
            )
        return (
            "C_RECONSTRUCTION_FAILED_KEEP_GLOBAL_MU_PRIMARY",
            "Inputs were inspected but early_central_separation could not be reconstructed.",
        )

    err = selected.percent_error_vs_omega_m()
    improves = math.isfinite(err) and err < GLOBAL_MU_PERCENT_ERROR
    sub_percent = math.isfinite(err) and err < 1.0
    family_pass = stability.get("family_stability_status", "").startswith("PASS")
    resolution_pass = stability.get("resolution_stability_status", "").startswith("PASS")
    family_recoverable = stability.get("family_stability_status") != "NOT_RECOVERABLE"
    resolution_recoverable = stability.get("resolution_stability_status") != "NOT_RECOVERABLE"

    if guardrail_status == "FAIL_GUARDRAIL_BREACH":
        return (
            "D_REJECT_REFINEMENT_DUE_GUARDRAIL_BREAK",
            "Omega_m refinement produced or coincided with a cross-benchmark guardrail breach.",
        )

    if blocking:
        if improves:
            return (
                "B_KEEP_AS_SECONDARY_REFINED_COMPARATOR",
                "Candidate improves Omega_m but has blocking/review issues that prevent primary promotion.",
            )
        return (
            "C_RECONSTRUCTION_FAILED_KEEP_GLOBAL_MU_PRIMARY",
            "Candidate did not meet corrected reconstruction or improvement requirements.",
        )

    if improves and sub_percent and family_pass and resolution_pass:
        return (
            "A_PROMOTE_SHARP_FEATURE_PARETO_SAFE",
            "Feature reconstructed, sub-percent Omega_m error retained, family/resolution stability passed, and no guardrail breach occurred.",
        )

    if improves:
        if family_recoverable and resolution_recoverable:
            return (
                "B_KEEP_AS_SECONDARY_REFINED_COMPARATOR",
                "Feature reconstructed and improves Omega_m, but one or more promotion-strength criteria require review.",
            )
        return (
            "B_KEEP_AS_SECONDARY_REFINED_COMPARATOR",
            "Feature reconstructed and improves Omega_m, but family/resolution stability was not fully recoverable.",
        )

    return (
        "C_RECONSTRUCTION_FAILED_KEEP_GLOBAL_MU_PRIMARY",
        "Sharper feature was not strong enough under corrected reconstruction; keep global_mu primary.",
    )


# ============================================================
# Claim status and notes
# ============================================================

def build_promotion_panel(selected: Optional[Candidate], verdict: str, reason: str) -> pd.DataFrame:
    rows = [
        {
            "row_type": "baseline",
            "feature": "global_mu",
            "value": GLOBAL_MU_VALUE,
            "benchmark": "Omega_m",
            "benchmark_value": OMEGA_M_BENCHMARK,
            "percent_error": GLOBAL_MU_PERCENT_ERROR,
            "improvement_factor_vs_global_mu": 1.0,
            "status": "current_primary_manuscript_safe",
            "source": "Stage-6Yj/6Yk accepted primary anchor",
            "reason": "Primary comparator remains safe unless reconstructed sharper row passes guardrails.",
        },
        {
            "row_type": "historical_target",
            "feature": "early_central_separation",
            "value": HISTORICAL_EARLY_CENTRAL_SEPARATION,
            "benchmark": "Omega_m",
            "benchmark_value": OMEGA_M_BENCHMARK,
            "percent_error": percent_error(HISTORICAL_EARLY_CENTRAL_SEPARATION, OMEGA_M_BENCHMARK),
            "improvement_factor_vs_global_mu": GLOBAL_MU_PERCENT_ERROR / percent_error(HISTORICAL_EARLY_CENTRAL_SEPARATION, OMEGA_M_BENCHMARK),
            "status": "historical_repair_target_not_promoted_by_copy",
            "source": "Stage-6Yk historical/refinement target",
            "reason": "Included for reconciliation only; script must not copy this value as proof.",
        },
    ]
    if selected is not None:
        rows.append({
            "row_type": "reconstructed_candidate",
            "feature": selected.feature_name,
            "value": selected.value,
            "benchmark": "Omega_m",
            "benchmark_value": OMEGA_M_BENCHMARK,
            "percent_error": selected.percent_error_vs_omega_m(),
            "improvement_factor_vs_global_mu": selected.improvement_factor_vs_global_mu(),
            "status": verdict,
            "source": selected.source_file,
            "reason": reason,
        })
    else:
        rows.append({
            "row_type": "reconstructed_candidate",
            "feature": "early_central_separation",
            "value": np.nan,
            "benchmark": "Omega_m",
            "benchmark_value": OMEGA_M_BENCHMARK,
            "percent_error": np.nan,
            "improvement_factor_vs_global_mu": np.nan,
            "status": verdict,
            "source": "none",
            "reason": reason,
        })
    return pd.DataFrame(rows)


def build_claim_status_update(selected: Optional[Candidate], verdict: str) -> pd.DataFrame:
    can_promote = verdict.startswith("A_")
    return pd.DataFrame([
        {
            "topic": "Omega_m comparison",
            "allowed_language": (
                "QEG internally reconstructs an early-central separation invariant that may be compared "
                "as a dimensionless external benchmark to Omega_m."
                if selected is not None else
                "QEG retains global_mu as the primary manuscript-safe Omega_m comparator."
            ),
            "forbidden_language": "QEG derives Omega_m; QEG fits Omega_m; Omega_m was predicted by tuning.",
            "claim_status": "promote_to_primary_comparator" if can_promote else "track_or_secondary_only",
            "manuscript_recommendation": (
                "Use early_central_separation as primary Omega_m comparator with no-identification caveat."
                if can_promote else
                "Keep global_mu primary; mention early_central_separation only as secondary/review if reconstructed."
            ),
        },
        {
            "topic": "Omega_K / curvature",
            "allowed_language": "Use absolute error, uncertainty-window status, and near-flatness class.",
            "forbidden_language": "Relative percent error near zero; overclaiming curvature derivation.",
            "claim_status": "bookkeeping_only",
            "manuscript_recommendation": "Retain disciplined absolute-window treatment.",
        },
        {
            "topic": "Level 7 readiness",
            "allowed_language": (
                "Level 7 may open semantic-calibration questions after Stage-6Yl refinement is resolved or frozen."
            ),
            "forbidden_language": "Level 7 proves physical identification of QEG invariants with cosmological constants.",
            "claim_status": "gate_pending" if not can_promote else "gate_cleared_for_semantic_calibration",
            "manuscript_recommendation": "Use physics-facing semantics carefully; do not convert proximity into derivation.",
        },
    ])


def make_notes(
    selected: Optional[Candidate],
    verdict: str,
    reason: str,
    stability: Dict[str, Any],
    guardrail_status: str,
    audit_df: pd.DataFrame,
    review_df: pd.DataFrame,
) -> str:
    lines = []
    lines.append("============================================================")
    lines.append("STAGE-6Yl CORRECTED-LOCK RECONSTRUCTION NOTES")
    lines.append("============================================================")
    lines.append(f"Generated: {now_iso()}")
    lines.append("")
    lines.append("NO-FITTING POLICY")
    lines.append("-----------------")
    lines.append("No parameter was tuned, rescaled, or selected by optimization against Omega_m.")
    lines.append("Candidate priority is based on reconstruction provenance, not benchmark closeness.")
    lines.append("")
    lines.append("RESULT")
    lines.append("------")
    lines.append(f"Verdict: {verdict}")
    lines.append(f"Reason: {reason}")
    lines.append("")
    lines.append("BASELINE")
    lines.append("--------")
    lines.append(f"global_mu = {GLOBAL_MU_VALUE:.12g}")
    lines.append(f"Omega_m benchmark = {OMEGA_M_BENCHMARK:.12g}")
    lines.append(f"global_mu percent error = {GLOBAL_MU_PERCENT_ERROR:.6f}%")
    lines.append("")
    lines.append("HISTORICAL TARGET")
    lines.append("-----------------")
    lines.append(f"historical early_central_separation = {HISTORICAL_EARLY_CENTRAL_SEPARATION:.12g}")
    lines.append("This value is not accepted by copy-forward; it is included only for reconciliation.")
    lines.append("")
    if selected is not None:
        lines.append("SELECTED RECONSTRUCTED CANDIDATE")
        lines.append("--------------------------------")
        lines.append(f"strategy: {selected.strategy}")
        lines.append(f"value: {selected.value:.12g}")
        lines.append(f"formula: {selected.formula}")
        lines.append(f"source: {selected.source_file}")
        lines.append(f"source row: {selected.source_row_index}")
        lines.append(f"value column: {selected.value_column}")
        lines.append(f"family: {selected.family}")
        lines.append(f"resolution: {selected.resolution}")
        lines.append(f"percent error vs Omega_m: {selected.percent_error_vs_omega_m():.6f}%")
        lines.append(f"improvement factor vs global_mu: {selected.improvement_factor_vs_global_mu()}")
        lines.append(f"corrected/lock evidence: {selected.corrected_lock_evidence}")
        lines.append(f"lineage evidence: {selected.lineage_evidence}")
        lines.append(f"trust evidence: {selected.trust_evidence}")
        lines.append(f"copy/historical-only risk: {selected.copied_or_historical_only}")
        lines.append(f"notes: {selected.notes}")
        lines.append("")
    else:
        lines.append("No candidate was selected.")
        lines.append("")
    lines.append("STABILITY")
    lines.append("---------")
    lines.append(json.dumps(stability, indent=2, sort_keys=True))
    lines.append("")
    lines.append("CROSS-BENCHMARK GUARDRAIL")
    lines.append("-------------------------")
    lines.append(guardrail_status)
    lines.append("")
    lines.append("INPUT AUDIT SUMMARY")
    lines.append("-------------------")
    if not audit_df.empty:
        lines.append(f"Loaded files: {int((audit_df['status'] == 'loaded').sum())}")
        lines.append(f"Missing required files: {int(((audit_df['required'] == True) & (audit_df['status'] != 'loaded')).sum())}")
    lines.append("")
    lines.append("REVIEW FLAGS")
    lines.append("------------")
    if not review_df.empty:
        for _, r in review_df.iterrows():
            lines.append(f"- [{r['severity']}] {r['flag_code']} blocking={r['blocking']}: {r['message']}")
    lines.append("")
    lines.append("LEVEL-7 GATE NOTE")
    lines.append("-----------------")
    lines.append("If Stage-6Yl returns A or B, Level 7 may begin semantic-calibration questions.")
    lines.append("The first Level-7 question should remain:")
    lines.append("What kind of internally generated object can legitimately be compared to Omega_m?")
    lines.append("It should not be: Did QEG derive Omega_m?")
    lines.append("")
    lines.append("============================================================")
    lines.append("END NOTES")
    lines.append("============================================================")
    return "\n".join(lines)


# ============================================================
# Main
# ============================================================

def parse_args(argv: Optional[List[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Stage-6Yl corrected-lock Omega_m reconstruction")
    parser.add_argument(
        "--root",
        type=str,
        default="/home/dakini/Downloads/010-Quantum_Emergent_Gravity",
        help="QEG project root",
    )
    parser.add_argument(
        "--outdir",
        type=str,
        default=None,
        help="Output directory. Default: <root>/metric_stage_6Yl_outputs",
    )
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="Allow writing into an existing non-empty output directory",
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Print extra debugging information",
    )
    return parser.parse_args(argv)


def main(argv: Optional[List[str]] = None) -> int:
    args = parse_args(argv)
    root = Path(args.root).expanduser().resolve()
    out_dir = Path(args.outdir).expanduser().resolve() if args.outdir else root / "metric_stage_6Yl_outputs"

    print("=" * 72)
    print("QEG Stage-6Yl Corrected-Lock Omega_m Reconstruction")
    print("=" * 72)
    print(f"Python: {sys.executable}")
    print(f"Root:   {root}")
    print(f"Out:    {out_dir}")
    print(f"Time:   {now_iso()}")
    print("")
    print("Policy: no Omega_m fitting, no rescaling, no target-forcing.")
    print("")

    if not root.exists():
        raise FileNotFoundError(f"Project root does not exist: {root}")

    mkdir_output(out_dir, args.overwrite)

    required_paths, discovered_paths = discover_files(root)

    audit_df = input_audit(root, discovered_paths)
    df_to_csv(audit_df, out_dir / "stage6Yl_input_audit.csv")

    if args.debug:
        print("Input audit:")
        print(audit_df[["file_path", "status", "required"]].to_string(index=False))

    print("Discovering reconstruction candidates...")
    candidates = extract_all_candidates(root, discovered_paths)
    cand_df = candidates_to_dataframe(candidates)
    df_to_csv(cand_df, out_dir / "stage6Yl_reconstructed_early_central_separation.csv")

    selected = select_primary_candidate(candidates)
    stability_df, stability = stability_audit(candidates, selected)
    if stability_df.empty:
        stability_df = pd.DataFrame([{
            "audit_type": "none",
            "group": "none",
            "count": 0,
            "mean_value": np.nan,
            "std_value": np.nan,
            "min_value": np.nan,
            "max_value": np.nan,
            "range_across_groups": np.nan,
            "status": "NOT_RECOVERABLE",
        }])
    df_to_csv(stability_df, out_dir / "stage6Yl_family_resolution_stability_audit.csv")

    guardrail_df, guardrail_status = cross_benchmark_guardrail(selected)
    df_to_csv(guardrail_df, out_dir / "stage6Yl_cross_benchmark_guardrail_v2.csv")

    required_missing_count = int(((audit_df["required"] == True) & (audit_df["status"] != "loaded")).sum())
    # preliminary flags, then verdict, then panel/summary
    provisional_review = build_review_flags(root, audit_df, selected, candidates, stability, guardrail_status)
    verdict, reason = decide_verdict(selected, provisional_review, stability, guardrail_status, required_missing_count)

    # If verdict is A, warn if required files missing but optional reconstruction saved the run.
    review_df = provisional_review.copy()
    df_to_csv(review_df, out_dir / "stage6Yl_review_flags.csv")

    promotion_df = build_promotion_panel(selected, verdict, reason)
    df_to_csv(promotion_df, out_dir / "stage6Yl_omega_m_promotion_panel.csv")

    claim_df = build_claim_status_update(selected, verdict)
    df_to_csv(claim_df, out_dir / "stage6Yl_claim_status_update.csv")

    trace = {
        "stage": STAGE,
        "script": SCRIPT_NAME,
        "generated_at": now_iso(),
        "no_fitting_policy_enforced": True,
        "selection_policy": "Candidate selection prioritized reconstruction provenance, not closeness to Omega_m.",
        "selected_candidate": asdict(selected) if selected is not None else None,
        "all_candidate_count": len(candidates),
        "all_candidate_strategies": sorted(set(c.strategy for c in candidates)),
        "formula": selected.formula if selected is not None else None,
        "source_columns": selected.value_column if selected is not None else None,
        "source_files": sorted(set(c.source_file for c in candidates)),
        "trust_classification": {
            "corrected_lock_evidence": selected.corrected_lock_evidence if selected else False,
            "lineage_evidence": selected.lineage_evidence if selected else False,
            "trust_evidence": selected.trust_evidence if selected else False,
            "copied_or_historical_only": selected.copied_or_historical_only if selected else None,
        },
        "value_was_recomputed_or_copied": (
            "recomputed" if selected is not None and "reconstruction" in selected.strategy
            else "direct_recovered_row" if selected is not None
            else "none"
        ),
        "historical_target_value_for_reconciliation_only": HISTORICAL_EARLY_CENTRAL_SEPARATION,
    }
    write_json(out_dir / "stage6Yl_feature_definition_trace.json", trace)

    review_flag_types = review_df["flag_code"].astype(str).tolist() if not review_df.empty else []
    reconstructed_value = selected.value if selected is not None else None
    reconstructed_error = selected.percent_error_vs_omega_m() if selected is not None else None
    improvement_factor = selected.improvement_factor_vs_global_mu() if selected is not None else None

    summary = {
        "stage": STAGE,
        "script": SCRIPT_NAME,
        "generated_at": now_iso(),
        "verdict": verdict,
        "verdict_reason": reason,
        "no_fitting_policy_enforced": True,
        "primary_previous_feature": "global_mu",
        "primary_previous_value": GLOBAL_MU_VALUE,
        "primary_previous_percent_error": GLOBAL_MU_PERCENT_ERROR,
        "historical_target_feature": "early_central_separation",
        "historical_target_value": HISTORICAL_EARLY_CENTRAL_SEPARATION,
        "historical_target_percent_error": percent_error(HISTORICAL_EARLY_CENTRAL_SEPARATION, OMEGA_M_BENCHMARK),
        "reconstructed_feature_name": selected.feature_name if selected is not None else "early_central_separation",
        "reconstructed_feature_value": reconstructed_value,
        "reconstructed_percent_error": reconstructed_error,
        "improvement_factor": improvement_factor,
        "reconstruction_status": "RECONSTRUCTED_OR_RECOVERED" if selected is not None else "NOT_RECONSTRUCTED",
        "family_stability_status": stability.get("family_stability_status"),
        "resolution_stability_status": stability.get("resolution_stability_status"),
        "cross_benchmark_guardrail_status": guardrail_status,
        "review_flag_count": int(len(review_df)) if not review_df.empty else 0,
        "blocking_review_flag_count": int(review_df["blocking"].fillna(False).sum()) if not review_df.empty else 0,
        "review_flag_types": review_flag_types,
        "recommendation": reason,
        "forbidden_claims": [
            "QEG derives Omega_m",
            "QEG fitted Omega_m",
            "QEG tuned early_central_separation to Omega_m",
            "QEG proves physical identification at Stage-6Yl",
        ],
        "allowed_language": [
            "QEG reconstructs an internally generated dimensionless invariant.",
            "The invariant is compared to Omega_m as external benchmark bookkeeping.",
            "Promotion is conditional on corrected-lock provenance and guardrails.",
        ],
        "required_input_missing_count": required_missing_count,
        "candidate_count": len(candidates),
        "output_directory": str(out_dir),
    }
    write_json(out_dir / "stage6Yl_summary.json", summary)

    notes = make_notes(selected, verdict, reason, stability, guardrail_status, audit_df, review_df)
    (out_dir / "Stage-6Yl_corrected_lock_reconstruction_notes.txt").write_text(notes, encoding="utf-8")

    print("")
    print("Stage-6Yl finished.")
    print(f"Verdict: {verdict}")
    print(f"Reason:  {reason}")
    if selected is not None:
        print(f"Selected value: {selected.value:.12g}")
        print(f"Percent error vs Omega_m: {selected.percent_error_vs_omega_m():.6f}%")
        print(f"Improvement factor vs global_mu: {selected.improvement_factor_vs_global_mu()}")
        print(f"Source: {selected.source_file}")
    else:
        print("Selected value: none")
    print("")
    print("Outputs written:")
    for name in [
        "stage6Yl_reconstructed_early_central_separation.csv",
        "stage6Yl_omega_m_promotion_panel.csv",
        "stage6Yl_cross_benchmark_guardrail_v2.csv",
        "stage6Yl_family_resolution_stability_audit.csv",
        "stage6Yl_feature_definition_trace.json",
        "stage6Yl_claim_status_update.csv",
        "stage6Yl_review_flags.csv",
        "stage6Yl_input_audit.csv",
        "stage6Yl_summary.json",
        "Stage-6Yl_corrected_lock_reconstruction_notes.txt",
    ]:
        print(f"  - {out_dir / name}")

    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print("")
        print("=" * 72)
        print("STAGE-6Yl SCRIPT FAILED")
        print("=" * 72)
        print(repr(exc))
        traceback.print_exc()
        raise
