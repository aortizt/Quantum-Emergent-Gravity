#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Quantum-Emergent Gravity
Stage-7E: GitHub Staging Copy Curator v1

Author: Arturo Ortiz-Tapia / QEG pipeline assistant
Build date: 2026-06-03

Purpose
-------
Create a curated GitHub-ready script bundle from the Stage-7E-v3
manifest/copy-plan outputs, so reproducibility scripts do not have to be
hunted manually across the project tree.

This script is Spyder-friendly by design:
    - no command-line arguments required
    - all main paths are configured below
    - console output is verbose and ledger-style
    - dry-run mode is available by changing DRY_RUN to True

Main behavior
-------------
1. Reads the Stage-7E-v3 minimal GitHub manifest and GitHub copy plan.
2. Resolves listed Python scripts under the QEG project root.
3. Copies them into a dedicated folder inside metric_stage_7E_outputs.
4. Builds a repository-shaped payload folder, normally:

       metric_stage_7E_outputs/github_staging_reproducibility_bundle_v1/
           repository_payload/scripts/reproducibility/

5. Applies the mandatory Stage-7E reproducibility patch by ensuring these
   scripts are included when found locally:

       Stage-7E-v2_canonical_run_sequence_builder.py
       Stage-7E-v3_result_spine_audit.py

6. Includes this script itself when run from Spyder/runfile, creating the
   intended bootstrap/ouroboros reproducibility record.

7. Writes audit reports listing copied, missing, duplicated, skipped, and
   conflict entries.

Scientific discipline
---------------------
This is an infrastructure/staging script only. It does not modify QEG
results, refit models, create new physics claims, or alter the Stage-7E-v3
manifest. It only copies scripts and writes transparent staging reports.
"""

from __future__ import annotations

import csv
import hashlib
import json
import os
import re
import shutil
import sys
import traceback
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple


# ============================================================
# USER CONFIGURATION
# ============================================================

PROJECT_ROOT = Path("/home/dakini/Downloads/010-Quantum_Emergent_Gravity")

STAGE7E_OUTPUT_ROOT = PROJECT_ROOT / "metric_stage_7E_outputs"
V3_DIR = STAGE7E_OUTPUT_ROOT / "result_spine_audit_v3"
STAGE7E_SCRIPT_DIR = PROJECT_ROOT / "metric_stage_7E_scripts"

# Dedicated folder requested by the user.
STAGING_DIR = STAGE7E_OUTPUT_ROOT / "github_staging_reproducibility_bundle_v1"
REPOSITORY_PAYLOAD_DIR = STAGING_DIR / "repository_payload"
DEFAULT_REPO_SCRIPT_DIR = Path("scripts/reproducibility")

# Change to True for a non-destructive preview.
DRY_RUN = False

# If True, existing staged files are replaced when their destination matches.
# Conflicting duplicate contents are still preserved in a conflict folder.
OVERWRITE = True

# Include all local Stage-7E Python scripts in the curation bundle, not only
# the ones explicitly listed in v3. This captures v1/v2/v3 curation helpers.
INCLUDE_ALL_STAGE7E_CURATION_SCRIPTS = True

# Include the v3 audit CSV/MD/JSON/TXT files as metadata, outside the repo
# payload and also in repository_payload/_stage7E_staging_audit.
INCLUDE_STAGE7E_METADATA = True

# Restrict manifest-driven script copying to .py files.
PYTHON_ONLY = True


# ============================================================
# STAGE-7E-v3 CONTRACT FILES
# ============================================================

PRIMARY_MANIFEST = V3_DIR / "stage7E_v3_minimal_github_manifest.csv"
COPY_PLAN = V3_DIR / "stage7E_v3_github_copy_plan.csv"
FALLBACK_MANIFEST = V3_DIR / "stage7E_v3_expanded_github_manifest.csv"

HUMAN_READABLE_MAP = V3_DIR / "stage7E_v3_result_to_script_map.md"

V3_METADATA_FILES = [
    V3_DIR / "stage7E_v3_result_spine_coverage.csv",
    V3_DIR / "stage7E_v3_minimal_github_manifest.csv",
    V3_DIR / "stage7E_v3_expanded_github_manifest.csv",
    V3_DIR / "stage7E_v3_github_copy_plan.csv",
    V3_DIR / "stage7E_v3_result_to_script_map.md",
    V3_DIR / "stage7E_v3_critical_review_notes.md",
    V3_DIR / "stage7E_v3_summary.json",
    V3_DIR / "stage7E_v3_ledger_note.txt",
    V3_DIR / "stage7E_v3_ascii_transition_package.txt",
]

MANDATORY_REPRO_PATCH_BASENAMES = [
    "Stage-7E-v2_canonical_run_sequence_builder.py",
    "Stage-7E-v3_result_spine_audit.py",
]


# ============================================================
# FLEXIBLE CSV PARSING SETTINGS
# ============================================================

SOURCE_COLUMN_HINTS = [
    "source_path", "src_path", "script_path", "python_script", "script",
    "file_path", "filepath", "path", "relpath", "relative_path",
    "local_path", "absolute_path", "source_relpath", "script_relpath",
    "canonical_script", "selected_script", "run_script", "filename", "file",
]

DEST_COLUMN_HINTS = [
    "destination_path", "dest_path", "target_path", "repo_path",
    "github_path", "copy_to", "copy_dest", "destination_relpath",
    "target_relpath", "repo_relpath", "staging_path", "upload_path",
]

INCLUDE_COLUMN_HINTS = [
    "include", "selected", "github", "copy", "upload", "keep", "use",
    "manifest", "reproducibility", "is_selected",
]

FALSE_STRINGS = {"0", "false", "no", "n", "skip", "exclude", "excluded", "do_not_copy"}
TRUE_STRINGS = {"1", "true", "yes", "y", "copy", "include", "included", "selected", "keep"}


@dataclass
class CopyEntry:
    source_hint: str
    dest_hint: str
    origin: str
    reason: str
    row_index: Optional[int] = None


@dataclass
class CopyResult:
    status: str
    source_hint: str
    resolved_source: str
    destination: str
    origin: str
    reason: str
    sha256: str = ""
    bytes: int = 0
    note: str = ""


# ============================================================
# UTILITY FUNCTIONS
# ============================================================


def now_stamp() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def echo(title: str, char: str = "=") -> None:
    print(char * 72)
    print(title)
    print(char * 72)


def normalize_header(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(s).strip().lower()).strip("_")


def normalize_cell(value: object) -> str:
    if value is None:
        return ""
    return str(value).strip().strip('"').strip("'")


def looks_false(value: object) -> bool:
    s = normalize_cell(value).lower()
    return s in FALSE_STRINGS


def looks_true(value: object) -> bool:
    s = normalize_cell(value).lower()
    return s in TRUE_STRINGS


def is_probably_python_path(text: str) -> bool:
    return bool(text) and ".py" in text.lower()


def is_probably_path(text: str) -> bool:
    if not text:
        return False
    t = text.strip()
    return (
        "/" in t
        or "\\" in t
        or t.lower().endswith((".py", ".csv", ".json", ".md", ".txt"))
    )


def safe_repo_relpath(raw: str, fallback_basename: str = "") -> Path:
    """Convert a raw destination hint into a safe repository-relative path."""
    raw = normalize_cell(raw).replace("\\", "/")
    if not raw:
        raw = str(DEFAULT_REPO_SCRIPT_DIR / fallback_basename) if fallback_basename else str(DEFAULT_REPO_SCRIPT_DIR)

    # If the destination is absolute or points into the local project tree,
    # reduce it to a repository-style path when possible.
    try:
        p = Path(raw)
        if p.is_absolute():
            try:
                raw = str(p.relative_to(PROJECT_ROOT)).replace("\\", "/")
            except ValueError:
                raw = fallback_basename or p.name
    except Exception:
        pass

    # Strip common leading local repository/output prefixes if accidentally present.
    for prefix in [
        str(PROJECT_ROOT).replace("\\", "/"),
        "repository_payload/",
        "./",
    ]:
        if raw.startswith(prefix):
            raw = raw[len(prefix):]

    parts: List[str] = []
    for part in raw.split("/"):
        if part in ("", ".", ".."):  # prevent path escape
            continue
        parts.append(part)

    if not parts:
        parts = list(DEFAULT_REPO_SCRIPT_DIR.parts)
        if fallback_basename:
            parts.append(fallback_basename)

    out = Path(*parts)
    if fallback_basename and out.suffix.lower() != ".py":
        out = out / fallback_basename
    return out


def file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def ensure_dir(path: Path) -> None:
    if not DRY_RUN:
        path.mkdir(parents=True, exist_ok=True)


def read_csv_rows(path: Path) -> Tuple[List[Dict[str, str]], Dict[str, str]]:
    """Read CSV as dictionaries with normalized keys while preserving raw names."""
    if not path.exists():
        return [], {}
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames:
            return [], {}
        raw_to_norm = {name: normalize_header(name) for name in reader.fieldnames}
        rows: List[Dict[str, str]] = []
        for row in reader:
            norm_row: Dict[str, str] = {}
            for raw_name, value in row.items():
                norm_row[raw_to_norm.get(raw_name, normalize_header(raw_name))] = normalize_cell(value)
            rows.append(norm_row)
    return rows, raw_to_norm


def row_should_be_included(row: Dict[str, str]) -> bool:
    """Honor explicit include=false columns, but otherwise include rows."""
    for key, value in row.items():
        nk = normalize_header(key)
        if any(h in nk for h in INCLUDE_COLUMN_HINTS):
            if looks_false(value):
                return False
    return True


def pick_column_value(row: Dict[str, str], hints: Sequence[str]) -> str:
    normalized_hints = [normalize_header(h) for h in hints]

    # Exact normalized match first.
    for hint in normalized_hints:
        if hint in row and row[hint]:
            return row[hint]

    # Then substring match.
    for key, value in row.items():
        if value and any(h in key for h in normalized_hints):
            return value
    return ""


def extract_source_candidates_from_row(row: Dict[str, str]) -> List[str]:
    candidates: List[str] = []

    explicit = pick_column_value(row, SOURCE_COLUMN_HINTS)
    if explicit:
        candidates.append(explicit)

    # Fallback: any cell containing a Python-looking path.
    for value in row.values():
        if value and is_probably_python_path(value) and value not in candidates:
            candidates.append(value)

    # Fallback: any path-looking cell, for unusual manifests.
    if not candidates:
        for value in row.values():
            if value and is_probably_path(value) and value not in candidates:
                candidates.append(value)

    return candidates


def extract_entries_from_csv(path: Path, origin_label: str, default_reason: str) -> List[CopyEntry]:
    rows, _ = read_csv_rows(path)
    entries: List[CopyEntry] = []
    if not rows:
        return entries

    for i, row in enumerate(rows, start=1):
        if not row_should_be_included(row):
            continue
        source_candidates = extract_source_candidates_from_row(row)
        if not source_candidates:
            continue

        dest_hint = pick_column_value(row, DEST_COLUMN_HINTS)
        for source_hint in source_candidates:
            if PYTHON_ONLY and not is_probably_python_path(source_hint):
                continue
            entries.append(
                CopyEntry(
                    source_hint=source_hint,
                    dest_hint=dest_hint,
                    origin=origin_label,
                    reason=default_reason,
                    row_index=i,
                )
            )
    return entries


def path_inside(child: Path, parent: Path) -> bool:
    try:
        child.resolve().relative_to(parent.resolve())
        return True
    except Exception:
        return False


def search_by_basename(basename: str) -> List[Path]:
    """Search project tree for a basename, avoiding current staging copies."""
    hits: List[Path] = []
    if not basename:
        return hits
    if not PROJECT_ROOT.exists():
        return hits

    excluded_dir_names = {
        ".git", "__pycache__", ".ipynb_checkpoints",
        STAGING_DIR.name,
    }

    for root, dirs, files in os.walk(PROJECT_ROOT):
        root_path = Path(root)
        dirs[:] = [d for d in dirs if d not in excluded_dir_names]
        if basename in files:
            hits.append(root_path / basename)
    return sorted(set(hits), key=lambda p: (len(str(p)), str(p)))


def resolve_source_path(source_hint: str) -> Tuple[Optional[Path], str]:
    """Resolve manifest source hints to local project files."""
    raw = normalize_cell(source_hint)
    if not raw:
        return None, "empty source hint"

    raw = raw.replace("\\", "/")

    # Remove common wrappers from markdown-style links if they appear.
    markdown_match = re.search(r"\(([^)]+\.py)\)", raw)
    if markdown_match:
        raw = markdown_match.group(1)

    # If a cell contains text plus a path, extract the first .py-looking token.
    token_match = re.search(r"([^\s,;:\|]+\.py)", raw)
    if token_match:
        raw_path_text = token_match.group(1)
    else:
        raw_path_text = raw

    p = Path(raw_path_text).expanduser()

    if p.is_absolute() and p.exists():
        return p.resolve(), "absolute path exists"

    if p.is_absolute() and not p.exists():
        basename_hits = search_by_basename(p.name)
        if basename_hits:
            return basename_hits[0].resolve(), f"absolute path missing; recovered by basename among {len(basename_hits)} hit(s)"
        return None, "absolute path does not exist"

    candidates = [
        PROJECT_ROOT / p,
        STAGE7E_SCRIPT_DIR / p,
        STAGE7E_SCRIPT_DIR / p.name,
        V3_DIR / p,
        Path.cwd() / p,
    ]

    for candidate in candidates:
        if candidate.exists() and candidate.is_file():
            return candidate.resolve(), "relative path exists"

    basename_hits = search_by_basename(p.name)
    if basename_hits:
        return basename_hits[0].resolve(), f"recovered by basename among {len(basename_hits)} hit(s)"

    return None, "not found under project root"


def add_stage7e_curation_scripts(entries: List[CopyEntry]) -> None:
    """Add Stage-7E curation/helper scripts found in metric_stage_7E_scripts."""
    if not INCLUDE_ALL_STAGE7E_CURATION_SCRIPTS:
        return
    if not STAGE7E_SCRIPT_DIR.exists():
        return

    for path in sorted(STAGE7E_SCRIPT_DIR.glob("*.py")):
        name_l = path.name.lower()
        if "7e" in name_l or "stage-7e" in name_l or "stage7e" in name_l:
            entries.append(
                CopyEntry(
                    source_hint=str(path),
                    dest_hint=str(DEFAULT_REPO_SCRIPT_DIR / path.name),
                    origin="stage7e_script_dir_autoinclude",
                    reason="include Stage-7E curation/helper script",
                )
            )


def add_mandatory_patch_scripts(entries: List[CopyEntry]) -> None:
    """Add mandatory v3 reproducibility patch scripts by basename."""
    for basename in MANDATORY_REPRO_PATCH_BASENAMES:
        entries.append(
            CopyEntry(
                source_hint=basename,
                dest_hint=str(DEFAULT_REPO_SCRIPT_DIR / basename),
                origin="mandatory_stage7e_v3_patch",
                reason="Stage-7E-v3 review requires explicit reproducibility inclusion",
            )
        )


def add_self_script(entries: List[CopyEntry]) -> None:
    """Add this script itself when Spyder/runfile provides __file__."""
    try:
        self_path = Path(__file__).resolve()  # type: ignore[name-defined]
    except Exception:
        self_path = None

    if self_path and self_path.exists():
        entries.append(
            CopyEntry(
                source_hint=str(self_path),
                dest_hint=str(DEFAULT_REPO_SCRIPT_DIR / self_path.name),
                origin="bootstrap_self_include",
                reason="include this staging curator script itself",
            )
        )
    else:
        entries.append(
            CopyEntry(
                source_hint="__file__ unavailable in this execution context",
                dest_hint=str(DEFAULT_REPO_SCRIPT_DIR / "Stage-7E_github_staging_copy_curator_v1.py"),
                origin="bootstrap_self_include",
                reason="attempted to include this script itself, but __file__ was unavailable",
            )
        )


def deduplicate_entries(entries: Iterable[CopyEntry]) -> List[CopyEntry]:
    """Deduplicate by normalized source hint + destination hint, preserving reasons."""
    seen = set()
    out: List[CopyEntry] = []
    for e in entries:
        key = (normalize_cell(e.source_hint).lower(), normalize_cell(e.dest_hint).lower())
        if key in seen:
            continue
        seen.add(key)
        out.append(e)
    return out


def copy_one(entry: CopyEntry, destination_hashes: Dict[Path, str]) -> CopyResult:
    resolved, note = resolve_source_path(entry.source_hint)
    fallback_name = Path(entry.source_hint).name if entry.source_hint else ""

    if not resolved:
        return CopyResult(
            status="MISSING",
            source_hint=entry.source_hint,
            resolved_source="",
            destination="",
            origin=entry.origin,
            reason=entry.reason,
            note=note,
        )

    if PYTHON_ONLY and resolved.suffix.lower() != ".py":
        return CopyResult(
            status="SKIPPED_NON_PYTHON",
            source_hint=entry.source_hint,
            resolved_source=str(resolved),
            destination="",
            origin=entry.origin,
            reason=entry.reason,
            note="resolved file is not .py",
        )

    repo_rel = safe_repo_relpath(entry.dest_hint, fallback_basename=resolved.name)
    if repo_rel.suffix.lower() != ".py":
        repo_rel = repo_rel / resolved.name

    dest = (REPOSITORY_PAYLOAD_DIR / repo_rel).resolve()

    # Do not allow destination to escape repository payload.
    if not path_inside(dest, REPOSITORY_PAYLOAD_DIR):
        dest = (REPOSITORY_PAYLOAD_DIR / DEFAULT_REPO_SCRIPT_DIR / resolved.name).resolve()
        repo_rel = dest.relative_to(REPOSITORY_PAYLOAD_DIR)

    src_hash = file_sha256(resolved)
    size = resolved.stat().st_size

    if dest in destination_hashes and destination_hashes[dest] != src_hash:
        conflict_dir = REPOSITORY_PAYLOAD_DIR / DEFAULT_REPO_SCRIPT_DIR / "_conflicts"
        conflict_name = f"{resolved.stem}__CONFLICT__{src_hash[:10]}{resolved.suffix}"
        conflict_dest = conflict_dir / conflict_name
        ensure_dir(conflict_dest.parent)
        if not DRY_RUN:
            shutil.copy2(resolved, conflict_dest)
        return CopyResult(
            status="CONFLICT_RENAMED",
            source_hint=entry.source_hint,
            resolved_source=str(resolved),
            destination=str(conflict_dest),
            origin=entry.origin,
            reason=entry.reason,
            sha256=src_hash,
            bytes=size,
            note=f"destination already used with different hash; copied to conflict folder; resolve manually: {repo_rel}",
        )

    if dest.exists():
        existing_hash = file_sha256(dest)
        if existing_hash == src_hash:
            destination_hashes[dest] = src_hash
            return CopyResult(
                status="ALREADY_PRESENT_IDENTICAL",
                source_hint=entry.source_hint,
                resolved_source=str(resolved),
                destination=str(dest),
                origin=entry.origin,
                reason=entry.reason,
                sha256=src_hash,
                bytes=size,
                note=note,
            )
        if not OVERWRITE:
            return CopyResult(
                status="SKIPPED_EXISTS_DIFFERENT",
                source_hint=entry.source_hint,
                resolved_source=str(resolved),
                destination=str(dest),
                origin=entry.origin,
                reason=entry.reason,
                sha256=src_hash,
                bytes=size,
                note="destination exists with different content and OVERWRITE=False",
            )

    ensure_dir(dest.parent)
    if not DRY_RUN:
        shutil.copy2(resolved, dest)
    destination_hashes[dest] = src_hash

    return CopyResult(
        status="COPIED" if not DRY_RUN else "DRY_RUN_WOULD_COPY",
        source_hint=entry.source_hint,
        resolved_source=str(resolved),
        destination=str(dest),
        origin=entry.origin,
        reason=entry.reason,
        sha256=src_hash,
        bytes=size,
        note=note,
    )


def write_csv(path: Path, rows: Sequence[Dict[str, object]], fieldnames: Sequence[str]) -> None:
    ensure_dir(path.parent)
    if DRY_RUN:
        return
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: row.get(k, "") for k in fieldnames})


def write_json(path: Path, data: object) -> None:
    ensure_dir(path.parent)
    if DRY_RUN:
        return
    with path.open("w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, sort_keys=True)


def write_text(path: Path, text: str) -> None:
    ensure_dir(path.parent)
    if DRY_RUN:
        return
    path.write_text(text, encoding="utf-8")


def copy_metadata_files(results: List[CopyResult]) -> None:
    if not INCLUDE_STAGE7E_METADATA:
        return

    metadata_dir = STAGING_DIR / "stage7E_v3_metadata"
    repo_audit_dir = REPOSITORY_PAYLOAD_DIR / "_stage7E_staging_audit"

    for src in V3_METADATA_FILES:
        if not src.exists():
            continue
        for dest_dir in [metadata_dir, repo_audit_dir]:
            dest = dest_dir / src.name
            ensure_dir(dest.parent)
            if not DRY_RUN:
                shutil.copy2(src, dest)
        results.append(
            CopyResult(
                status="METADATA_COPIED",
                source_hint=str(src),
                resolved_source=str(src.resolve()),
                destination=str(metadata_dir / src.name),
                origin="stage7e_v3_metadata",
                reason="copy v3 audit/manifest metadata for staging transparency",
                sha256=file_sha256(src),
                bytes=src.stat().st_size,
                note="also copied into repository_payload/_stage7E_staging_audit",
            )
        )


def collect_entries() -> List[CopyEntry]:
    entries: List[CopyEntry] = []

    # Main manifest required by the v3 review.
    if PRIMARY_MANIFEST.exists():
        entries.extend(
            extract_entries_from_csv(
                PRIMARY_MANIFEST,
                origin_label="stage7E_v3_minimal_github_manifest",
                default_reason="main GitHub script list from Stage-7E-v3 review",
            )
        )
    elif FALLBACK_MANIFEST.exists():
        entries.extend(
            extract_entries_from_csv(
                FALLBACK_MANIFEST,
                origin_label="stage7E_v3_expanded_github_manifest_fallback",
                default_reason="fallback GitHub script list because minimal manifest was not found",
            )
        )

    # Folder-copy plan required by the v3 review.
    if COPY_PLAN.exists():
        entries.extend(
            extract_entries_from_csv(
                COPY_PLAN,
                origin_label="stage7E_v3_github_copy_plan",
                default_reason="folder-copy plan from Stage-7E-v3 review",
            )
        )

    add_stage7e_curation_scripts(entries)
    add_mandatory_patch_scripts(entries)
    add_self_script(entries)

    return deduplicate_entries(entries)


def build_readme(summary: Dict[str, object]) -> str:
    return f"""Quantum-Emergent Gravity — Stage-7E GitHub Staging Bundle
Generated: {now_stamp()}

Purpose
-------
This folder was generated by Stage-7E_github_staging_copy_curator_v1.py.
It stages Python scripts selected by the Stage-7E-v3 GitHub manifest and
copy plan so they can be uploaded to GitHub without manually hunting for
source files.

How to use
----------
Copy the CONTENTS of:

    {REPOSITORY_PAYLOAD_DIR}

to the root of the GitHub repository working tree.

The main curated scripts are under:

    repository_payload/{DEFAULT_REPO_SCRIPT_DIR.as_posix()}/

Stage-7E-v3 contract applied
----------------------------
Main script list:
    {PRIMARY_MANIFEST}

Copy plan:
    {COPY_PLAN}

Human-readable map:
    {HUMAN_READABLE_MAP}

Mandatory reproducibility patch scripts:
    - Stage-7E-v2_canonical_run_sequence_builder.py
    - Stage-7E-v3_result_spine_audit.py

Bootstrap/ouroboros inclusion
-----------------------------
This curator script attempts to copy itself into scripts/reproducibility/
when run from Spyder/runfile, preserving the staging method itself.

Summary
-------
{json.dumps(summary, indent=2, sort_keys=True)}

Important boundary
------------------
This is an infrastructure copy/staging bundle only. It does not create new
QEG results, alter manifests, refit models, or add physics claims.
"""


def main() -> int:
    echo("Stage-7E GitHub Staging Copy Curator v1")
    print(f"Started              : {now_stamp()}")
    print(f"Project root         : {PROJECT_ROOT}")
    print(f"V3 directory         : {V3_DIR}")
    print(f"Staging directory    : {STAGING_DIR}")
    print(f"Repository payload   : {REPOSITORY_PAYLOAD_DIR}")
    print(f"Dry run              : {DRY_RUN}")
    print(f"Overwrite            : {OVERWRITE}")
    print()

    if not PROJECT_ROOT.exists():
        echo("ERROR", "!")
        print(f"PROJECT_ROOT does not exist: {PROJECT_ROOT}")
        return 2

    if not V3_DIR.exists():
        echo("WARNING", "-")
        print(f"V3_DIR does not exist: {V3_DIR}")
        print("The script will still search mandatory/Stage-7E scripts by basename.")
        print()

    ensure_dir(STAGING_DIR)
    ensure_dir(REPOSITORY_PAYLOAD_DIR / DEFAULT_REPO_SCRIPT_DIR)

    entries = collect_entries()
    echo("Collected copy entries", "-")
    print(f"Entry count before copying: {len(entries)}")
    print()

    destination_hashes: Dict[Path, str] = {}
    results: List[CopyResult] = []

    for entry in entries:
        try:
            result = copy_one(entry, destination_hashes)
        except Exception as exc:
            result = CopyResult(
                status="ERROR",
                source_hint=entry.source_hint,
                resolved_source="",
                destination="",
                origin=entry.origin,
                reason=entry.reason,
                note=f"{exc}\n{traceback.format_exc()}",
            )
        results.append(result)
        print(f"{result.status:26s} | {Path(result.destination).name if result.destination else '-':45s} | {entry.origin}")

    copy_metadata_files(results)

    counts: Dict[str, int] = {}
    for r in results:
        counts[r.status] = counts.get(r.status, 0) + 1

    copied_like = [r for r in results if r.status in {"COPIED", "ALREADY_PRESENT_IDENTICAL", "DRY_RUN_WOULD_COPY", "CONFLICT_RENAMED"}]
    missing = [r for r in results if r.status in {"MISSING", "ERROR", "SKIPPED_EXISTS_DIFFERENT"}]

    summary: Dict[str, object] = {
        "generated_at": now_stamp(),
        "project_root": str(PROJECT_ROOT),
        "v3_dir": str(V3_DIR),
        "staging_dir": str(STAGING_DIR),
        "repository_payload_dir": str(REPOSITORY_PAYLOAD_DIR),
        "dry_run": DRY_RUN,
        "overwrite": OVERWRITE,
        "entries_collected": len(entries),
        "status_counts": counts,
        "copied_or_ready_count": len(copied_like),
        "missing_or_error_count": len(missing),
        "mandatory_patch_basenames": MANDATORY_REPRO_PATCH_BASENAMES,
        "primary_manifest_exists": PRIMARY_MANIFEST.exists(),
        "copy_plan_exists": COPY_PLAN.exists(),
        "fallback_manifest_exists": FALLBACK_MANIFEST.exists(),
        "include_all_stage7e_curation_scripts": INCLUDE_ALL_STAGE7E_CURATION_SCRIPTS,
    }

    report_rows = [asdict(r) for r in results]
    fields = [
        "status", "source_hint", "resolved_source", "destination", "origin",
        "reason", "sha256", "bytes", "note",
    ]

    write_csv(STAGING_DIR / "stage7E_github_staging_copy_report.csv", report_rows, fields)
    write_csv(
        STAGING_DIR / "stage7E_github_staging_missing_or_error.csv",
        [asdict(r) for r in missing],
        fields,
    )
    write_json(STAGING_DIR / "stage7E_github_staging_summary.json", summary)
    write_text(STAGING_DIR / "README_STAGE7E_GITHUB_STAGING.txt", build_readme(summary))

    # Also place a compact README inside the repository payload itself.
    write_text(REPOSITORY_PAYLOAD_DIR / "_stage7E_staging_audit" / "README_STAGE7E_GITHUB_STAGING.txt", build_readme(summary))

    echo("SUMMARY", "=")
    for key in sorted(counts):
        print(f"{key:26s}: {counts[key]}")
    print()
    print(f"Copy report          : {STAGING_DIR / 'stage7E_github_staging_copy_report.csv'}")
    print(f"Missing/error report : {STAGING_DIR / 'stage7E_github_staging_missing_or_error.csv'}")
    print(f"Summary JSON         : {STAGING_DIR / 'stage7E_github_staging_summary.json'}")
    print(f"README               : {STAGING_DIR / 'README_STAGE7E_GITHUB_STAGING.txt'}")
    print()

    if missing:
        echo("ACTION REQUIRED", "!")
        print("Some source scripts were missing, conflicted, or errored.")
        print("Open the missing/error CSV before pushing to GitHub.")
        return 1

    echo("DONE", "=")
    print("Curated GitHub staging bundle is ready for review.")
    print(f"Repository-shaped payload: {REPOSITORY_PAYLOAD_DIR}")
    return 0


if __name__ == "__main__":
    # In Spyder, run with:
    #   %runfile /path/to/Stage-7E_github_staging_copy_curator_v1.py --wdir
    # or press Run after opening this file.
    sys.exit(main())
