#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Stage-7E-v1_project_inventory_ledger_crosswalk.py

Quantum-Emergent Gravity (QEG)
Stage-7E: Pipeline Compression, Repository Freeze, and Physica D Manuscript Preparation

Purpose
-------
Read-only audit script for the local QEG project root.

This script does NOT modify, delete, move, or rewrite any existing QEG scripts.
It inventories resident scripts, outputs, ledgers, rescue branches, deprecated
branches, and likely script-output relationships, then writes a Stage-7E-v1
reproducibility/crosswalk bundle.

Default project root:
    /home/dakini/Downloads/010-Quantum_Emergent_Gravity

Default output directory:
    <project_root>/metric_stage_7E_outputs/project_inventory_ledger_crosswalk_v1

Expected outputs:
    stage7E_v1_script_inventory.csv
    stage7E_v1_output_inventory.csv
    stage7E_v1_ledger_inventory.csv
    stage7E_v1_script_output_crosswalk.csv
    stage7E_v1_stage_decision_map.csv
    stage7E_v1_rescue_branch_classification.csv
    stage7E_v1_canonical_run_candidates.csv
    stage7E_v1_deprecated_or_superseded_scripts.csv
    stage7E_v1_missing_or_orphaned_outputs.csv
    stage7E_v1_repository_layout_recommendation.md
    stage7E_v1_readme_run_sequence_draft.md
    stage7E_v1_summary.json
    stage7E_v1_ledger_note.txt
    stage7E_v1_ascii_transition_package.txt

Typical terminal use
--------------------
    cd /home/dakini/Downloads/010-Quantum_Emergent_Gravity/metric_stage_7E_scripts
    python3 Stage-7E-v1_project_inventory_ledger_crosswalk.py

Optional:
    python3 Stage-7E-v1_project_inventory_ledger_crosswalk.py \
        --root /home/dakini/Downloads/010-Quantum_Emergent_Gravity \
        --max-crosswalk-per-script 25 \
        --hash-mode prefix

Authorial guardrail
-------------------
Stage-7E is a compression/reproducibility/manuscript-architecture stage,
not a new physics-discovery or cosmology-claim stage.

The script therefore marks Friedmann/Lambda/acceleration material as
appendix-grade unless local filenames/ledgers say otherwise.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import re
import sys
from collections import Counter, defaultdict
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

DEFAULT_ROOT = Path("/home/dakini/Downloads/010-Quantum_Emergent_Gravity")

SCRIPT_EXTS = {
    ".py", ".ipynb", ".wl", ".nb", ".m", ".sh", ".R", ".r", ".jl"
}

OUTPUT_EXTS = {
    ".csv", ".tsv", ".json", ".jsonl", ".txt", ".md",
    ".png", ".jpg", ".jpeg", ".svg", ".pdf",
    ".npy", ".npz", ".pkl", ".pickle", ".parquet",
    ".xlsx", ".xls", ".dat"
}

TEXT_EXTS = {
    ".py", ".wl", ".m", ".sh", ".R", ".r", ".jl",
    ".csv", ".tsv", ".json", ".jsonl", ".txt", ".md"
}

IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".svg"}
TABLE_EXTS = {".csv", ".tsv", ".xlsx", ".xls", ".parquet"}
FIGURE_EXTS = {".png", ".jpg", ".jpeg", ".svg", ".pdf"}
LEDGER_HINTS = {
    "ledger", "note", "guardrail", "guardrails", "audit_report",
    "ascii_transition", "transition_package", "summary", "decision",
    "readme", "README", "manifest", "inventory", "crosswalk"
}

EXCLUDE_DIR_NAMES = {
    ".git", ".svn", ".hg",
    "__pycache__", ".ipynb_checkpoints",
    ".venv", "venv", "env", "node_modules",
    ".mypy_cache", ".pytest_cache",
    "dist", "build",
}

# Meaningful QEG vocabulary tokens used for rough semantic matching.
DOMAIN_TOKENS = {
    "entropy", "lowk", "low", "directionality", "reverse", "forward",
    "null", "adversarial", "family", "bari", "nufit", "valencia",
    "friedmann", "lambda", "acceleration", "curvature", "density",
    "operator", "recursive", "transport", "green", "rank", "toeplitz",
    "asymmetry", "sector", "two", "bimodal", "witness", "unknown",
    "survivor", "repair", "rescue", "recovery", "triage", "canonical",
    "appendix", "manuscript", "physica", "cosmology", "omega", "q0",
    "zacc", "ledger", "crosswalk", "inventory", "semantic", "pde",
    "geometry", "lineage", "provenance", "benchmark", "ablation"
}

NEGATIVE_OR_RESCUE_TOKENS = {
    "rescue", "repair", "recovery", "triage", "fix", "patched",
    "overexclusion", "unknown", "last_unknown", "manual_review",
    "manual", "failed", "failure", "negative", "deprecated",
    "superseded", "legacy", "old", "backup"
}

APPENDIX_TOKENS = {
    "friedmann", "lambda", "acceleration", "q0", "zacc",
    "cosmology", "omegalambda", "omega_lambda", "age"
}

NULL_TOKENS = {
    "null", "adversarial", "shuffle", "permutation", "ablation",
    "negative", "control"
}

MAINLINE_TOKENS = {
    "two_sector", "sector", "family", "bari", "nufit", "valencia",
    "operator", "recursive", "transport", "entropy", "directionality",
    "canonical", "nonlocal", "geometry", "rank", "toeplitz",
    "asymmetry", "witness"
}

FORBIDDEN_CLAIMS = [
    "QEG derives quantum gravity",
    "QEG derives general relativity",
    "QEG derives Friedmann equations",
    "QEG derives LambdaCDM",
    "QEG derives dark energy",
    "QEG predicts Lambda",
    "QEG derives cosmic acceleration",
    "QEG derives cosmic time",
    "QEG derives the age of the Universe",
    "QEG proves emergent spacetime",
]


# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------

@dataclass
class FileRecord:
    path: str
    relpath: str
    basename: str
    extension: str
    kind: str
    size_bytes: int
    mtime_iso: str
    stage_label: str
    version_label: str
    stage_version_label: str
    directory_role: str
    semantic_tokens: str
    sha256_prefix: str
    first_line_or_title: str = ""


@dataclass
class CrosswalkRecord:
    script_relpath: str
    output_relpath: str
    script_stage: str
    output_stage: str
    script_version: str
    output_version: str
    score: float
    match_class: str
    reasons: str


# ---------------------------------------------------------------------------
# General utilities
# ---------------------------------------------------------------------------

def now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def safe_rel(path: Path, root: Path) -> str:
    try:
        return str(path.relative_to(root))
    except ValueError:
        return str(path)


def iso_from_timestamp(ts: float) -> str:
    return datetime.fromtimestamp(ts).replace(microsecond=0).isoformat()


def should_skip_dir(path: Path) -> bool:
    parts = set(path.parts)
    return any(part in EXCLUDE_DIR_NAMES for part in parts)


def safe_read_text(path: Path, max_bytes: int = 400_000) -> str:
    """
    Read a bounded amount of text using permissive decoding.
    This prevents one huge file from slowing the inventory pass.
    """
    try:
        with path.open("rb") as f:
            data = f.read(max_bytes)
        return data.decode("utf-8", errors="ignore")
    except Exception:
        return ""


def sha256_file_prefix(path: Path, mode: str = "prefix", prefix_bytes: int = 256_000) -> str:
    """
    hash-mode:
        none   -> empty hash
        prefix -> hash the first prefix_bytes only
        full   -> hash entire file, slower for large binary outputs
    """
    if mode == "none":
        return ""
    h = hashlib.sha256()
    try:
        with path.open("rb") as f:
            if mode == "full":
                for chunk in iter(lambda: f.read(1024 * 1024), b""):
                    h.update(chunk)
            else:
                h.update(f.read(prefix_bytes))
        return h.hexdigest()[:16]
    except Exception:
        return ""


def write_csv(path: Path, rows: Sequence[dict], fieldnames: Optional[Sequence[str]] = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if fieldnames is None:
        fieldnames = []
        for row in rows:
            for key in row.keys():
                if key not in fieldnames:
                    fieldnames.append(key)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(fieldnames), extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def write_json(path: Path, obj: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding="utf-8")


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def normalize_token(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", s.lower()).strip("_")


def split_tokens(path_or_name: str) -> List[str]:
    normalized = normalize_token(path_or_name)
    tokens = [t for t in normalized.split("_") if t]
    # join common low-k variants
    joined: List[str] = []
    skip = False
    for i, tok in enumerate(tokens):
        if skip:
            skip = False
            continue
        if tok == "low" and i + 1 < len(tokens) and tokens[i + 1] == "k":
            joined.append("lowk")
            skip = True
        else:
            joined.append(tok)
    return joined


def semantic_tokens_for(path: Path, root: Path) -> List[str]:
    rel = safe_rel(path, root)
    tokens = split_tokens(rel)
    keep = []
    for tok in tokens:
        if tok in DOMAIN_TOKENS or tok.startswith("stage") or re.fullmatch(r"v\d+[a-z]?", tok):
            keep.append(tok)
    return sorted(set(keep))


def infer_directory_role(path: Path, root: Path) -> str:
    rel = safe_rel(path, root).lower()
    parts = rel.split(os.sep)
    joined = "/".join(parts)
    if "metric_stage_7e_outputs" in joined:
        return "stage7E_output"
    if "script" in joined or "scripts" in joined:
        return "script_directory"
    if "output" in joined or "outputs" in joined or "result" in joined or "results" in joined:
        return "output_directory"
    if "ledger" in joined:
        return "ledger_directory"
    if "figure" in joined or "fig" in joined:
        return "figure_directory"
    if "data" in joined or "dataset" in joined:
        return "data_directory"
    return "general_project_directory"


def infer_kind(path: Path) -> str:
    ext = path.suffix
    name = path.name.lower()
    if ext in SCRIPT_EXTS:
        if ext in {".ipynb", ".nb"}:
            return "notebook_or_computational_document"
        return "script"
    if any(h.lower() in name for h in LEDGER_HINTS):
        return "ledger_or_documentation"
    if ext in IMAGE_EXTS:
        return "figure_or_image"
    if ext in TABLE_EXTS:
        return "table_or_dataset"
    if ext in {".json", ".jsonl"}:
        return "structured_output"
    if ext in {".txt", ".md"}:
        return "text_output_or_documentation"
    if ext in OUTPUT_EXTS:
        return "output_artifact"
    return "other"


# ---------------------------------------------------------------------------
# Stage/version inference
# ---------------------------------------------------------------------------

def infer_stage_label(path_or_name: str) -> str:
    s = path_or_name.replace("\\", "/")

    # Canonical examples:
    # Stage-7C-v1k, stage7C_v1k, metric_stage_7C_outputs
    patterns = [
        r"Stage[-_]?([0-9]+[A-Z]?)",
        r"stage[-_]?([0-9]+[A-Z]?)",
        r"metric_stage[-_]?([0-9]+[A-Z]?)",
        r"Stage[-_]?(P[0-9]+)",
        r"stage[-_]?(P[0-9]+)",
        r"Stage[-_]?(P[0-9]+)",
    ]

    for pat in patterns:
        m = re.search(pat, s, flags=re.IGNORECASE)
        if m:
            raw = m.group(1).upper()
            if raw.startswith("P"):
                return f"Stage-{raw}"
            return f"Stage-{raw}"

    # Special fallback for P18/P19 style without "stage"
    m = re.search(r"\bP([0-9]{1,3})\b", s, flags=re.IGNORECASE)
    if m:
        return f"Stage-P{m.group(1)}"

    return "UNKNOWN_STAGE"


def infer_version_label(path_or_name: str) -> str:
    s = path_or_name.replace("\\", "/")
    patterns = [
        r"[-_](v[0-9]+[a-z]?)\b",
        r"\b(v[0-9]+[a-z]?)\b",
        r"[-_]([0-9]+[a-z])\b",
    ]
    for pat in patterns:
        m = re.search(pat, s, flags=re.IGNORECASE)
        if m:
            val = m.group(1)
            if not val.lower().startswith("v"):
                val = "v" + val
            return val.lower()
    return "UNKNOWN_VERSION"


def stage_version_label(stage: str, version: str) -> str:
    if stage == "UNKNOWN_STAGE" and version == "UNKNOWN_VERSION":
        return "UNKNOWN_STAGE_VERSION"
    if version == "UNKNOWN_VERSION":
        return stage
    if stage == "UNKNOWN_STAGE":
        return version
    return f"{stage}-{version}"


def version_sort_key(version: str) -> Tuple[int, int]:
    """
    Sort labels such as v1, v1a, v1k, v2, v10.
    Unknown versions sort first.
    """
    m = re.search(r"v([0-9]+)([a-z]?)", version.lower())
    if not m:
        return (-1, -1)
    num = int(m.group(1))
    letter = m.group(2)
    letter_val = ord(letter) - 96 if letter else 0
    return (num, letter_val)


def stage_sort_key(stage: str) -> Tuple[int, int, str]:
    if stage == "UNKNOWN_STAGE":
        return (9999, 9999, stage)
    m = re.search(r"Stage-([0-9]+)([A-Z]?)", stage)
    if m:
        num = int(m.group(1))
        suffix = ord(m.group(2)) - 64 if m.group(2) else 0
        return (num, suffix, stage)
    m = re.search(r"Stage-P([0-9]+)", stage)
    if m:
        return (1000 + int(m.group(1)), 0, stage)
    return (9998, 0, stage)


def family_signature_for_script(relpath: str) -> str:
    """
    Loose signature for supersession detection.
    Removes stage/version/date-like tokens and keeps functional core.
    """
    stem = Path(relpath).stem
    tokens = split_tokens(stem)
    filtered = []
    for t in tokens:
        if t == "stage" or t.startswith("stage"):
            continue
        if re.fullmatch(r"v[0-9]+[a-z]?", t):
            continue
        if re.fullmatch(r"[0-9]{4,8}", t):
            continue
        if t in {"script", "scripts", "metric"}:
            continue
        filtered.append(t)
    return "_".join(filtered) if filtered else normalize_token(stem)


# ---------------------------------------------------------------------------
# File inventory
# ---------------------------------------------------------------------------

def iter_project_files(root: Path) -> Iterable[Path]:
    for dirpath, dirnames, filenames in os.walk(root):
        current = Path(dirpath)
        # Mutate dirnames in place so os.walk does not descend.
        dirnames[:] = [d for d in dirnames if d not in EXCLUDE_DIR_NAMES]
        if should_skip_dir(current):
            continue
        for filename in filenames:
            path = current / filename
            if path.is_file():
                yield path


def first_line_or_title(path: Path) -> str:
    ext = path.suffix.lower()
    if ext not in TEXT_EXTS:
        return ""
    text = safe_read_text(path, max_bytes=12_000)
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        if len(stripped) > 240:
            return stripped[:237] + "..."
        return stripped
    return ""


def build_file_record(path: Path, root: Path, hash_mode: str) -> FileRecord:
    st = path.stat()
    rel = safe_rel(path, root)
    stage = infer_stage_label(rel)
    version = infer_version_label(rel)
    toks = semantic_tokens_for(path, root)
    return FileRecord(
        path=str(path),
        relpath=rel,
        basename=path.name,
        extension=path.suffix.lower(),
        kind=infer_kind(path),
        size_bytes=st.st_size,
        mtime_iso=iso_from_timestamp(st.st_mtime),
        stage_label=stage,
        version_label=version,
        stage_version_label=stage_version_label(stage, version),
        directory_role=infer_directory_role(path, root),
        semantic_tokens=";".join(toks),
        sha256_prefix=sha256_file_prefix(path, mode=hash_mode),
        first_line_or_title=first_line_or_title(path),
    )


def scan_project(root: Path, hash_mode: str) -> List[FileRecord]:
    records: List[FileRecord] = []
    for path in iter_project_files(root):
        try:
            records.append(build_file_record(path, root, hash_mode=hash_mode))
        except Exception as exc:
            # Preserve an error row instead of failing the whole audit.
            rel = safe_rel(path, root)
            records.append(FileRecord(
                path=str(path),
                relpath=rel,
                basename=path.name,
                extension=path.suffix.lower(),
                kind="scan_error",
                size_bytes=-1,
                mtime_iso="",
                stage_label=infer_stage_label(rel),
                version_label=infer_version_label(rel),
                stage_version_label=stage_version_label(infer_stage_label(rel), infer_version_label(rel)),
                directory_role=infer_directory_role(path, root),
                semantic_tokens="",
                sha256_prefix="",
                first_line_or_title=f"SCAN_ERROR: {type(exc).__name__}: {exc}",
            ))
    return records


def is_script_record(r: FileRecord) -> bool:
    if r.kind in {"script", "notebook_or_computational_document"}:
        return True
    # Some Mathematica/WL artifacts may be extensionless or odd; keep conservative.
    return False


def is_output_record(r: FileRecord) -> bool:
    if is_script_record(r):
        return False
    if r.extension in OUTPUT_EXTS:
        return True
    if r.kind in {
        "ledger_or_documentation", "figure_or_image", "table_or_dataset",
        "structured_output", "text_output_or_documentation", "output_artifact"
    }:
        return True
    return False


def is_ledger_record(r: FileRecord) -> bool:
    lower = r.basename.lower()
    if any(h.lower() in lower for h in LEDGER_HINTS):
        return True
    if "ledger" in r.relpath.lower() or "readme" in lower:
        return True
    return False


# ---------------------------------------------------------------------------
# Classification logic
# ---------------------------------------------------------------------------

def token_set_from_record(r: FileRecord) -> set:
    toks = set(split_tokens(r.relpath))
    if r.semantic_tokens:
        toks.update(r.semantic_tokens.split(";"))
    return {t for t in toks if t}


def classify_script_record(r: FileRecord) -> Tuple[str, str, int]:
    """
    Returns:
        branch_class, reason, priority_score

    branch_class options are descriptive, not final truth:
        canonical_candidate
        appendix_candidate
        rescue_or_repair
        null_or_adversarial_control
        documentation_or_inventory
        deprecated_or_superseded_candidate
        exploratory_or_support
        unknown
    """
    toks = token_set_from_record(r)
    lower = r.relpath.lower()
    priority = 0
    reasons = []

    if toks & APPENDIX_TOKENS or "stage-7d" in lower or "stage_7d" in lower:
        priority += 20
        reasons.append("GR-adjacent/Friedmann-Lambda-acceleration token -> appendix-grade by Stage-7E policy")
        return "appendix_candidate", "; ".join(reasons), priority

    if toks & NEGATIVE_OR_RESCUE_TOKENS:
        priority += 10
        reasons.append("repair/rescue/recovery/manual/unknown token present")
        return "rescue_or_repair", "; ".join(reasons), priority

    if toks & NULL_TOKENS:
        priority += 30
        reasons.append("null/adversarial/control token present")
        return "null_or_adversarial_control", "; ".join(reasons), priority

    if {"inventory", "crosswalk", "readme", "ledger"} & toks:
        priority += 20
        reasons.append("documentation/inventory/crosswalk token present")
        return "documentation_or_inventory", "; ".join(reasons), priority

    if toks & MAINLINE_TOKENS:
        priority += 60
        reasons.append("mainline operator/family/sector/entropy/directionality token present")
        return "canonical_candidate", "; ".join(reasons), priority

    if r.stage_label != "UNKNOWN_STAGE":
        priority += 35
        reasons.append("stage label found but main function unclear")
        return "exploratory_or_support", "; ".join(reasons), priority

    return "unknown", "no reliable stage/function tokens found", priority


def classify_output_record(r: FileRecord) -> str:
    toks = token_set_from_record(r)
    if toks & APPENDIX_TOKENS or "stage7d" in r.relpath.lower() or "stage_7d" in r.relpath.lower():
        return "appendix_output"
    if toks & NULL_TOKENS:
        return "null_or_control_output"
    if toks & NEGATIVE_OR_RESCUE_TOKENS:
        return "rescue_or_repair_output"
    if r.extension in FIGURE_EXTS:
        return "figure_candidate"
    if r.extension in TABLE_EXTS:
        return "table_candidate"
    if is_ledger_record(r):
        return "ledger_or_documentation_output"
    return "general_output"


# ---------------------------------------------------------------------------
# Crosswalk
# ---------------------------------------------------------------------------

def score_script_output(script: FileRecord, output: FileRecord) -> Tuple[float, List[str]]:
    score = 0.0
    reasons: List[str] = []

    if script.stage_label != "UNKNOWN_STAGE" and script.stage_label == output.stage_label:
        score += 45
        reasons.append("same_stage")

    if script.version_label != "UNKNOWN_VERSION" and script.version_label == output.version_label:
        score += 35
        reasons.append("same_version")

    script_toks = token_set_from_record(script)
    output_toks = token_set_from_record(output)
    shared_domain = sorted((script_toks & output_toks) & DOMAIN_TOKENS)
    if shared_domain:
        add = min(30, 5 * len(shared_domain))
        score += add
        reasons.append("shared_domain_tokens=" + ",".join(shared_domain[:8]))

    # Directory proximity: outputs often live in adjacent metric_stage_*_outputs directories.
    s_stage_norm = normalize_token(script.stage_label)
    if s_stage_norm and s_stage_norm in normalize_token(output.relpath):
        score += 10
        reasons.append("script_stage_in_output_path")

    # Common family signature approximation.
    sig = family_signature_for_script(script.relpath)
    sig_toks = set(sig.split("_"))
    overlap = sig_toks & output_toks & DOMAIN_TOKENS
    if overlap:
        score += min(20, 4 * len(overlap))
        reasons.append("family_signature_overlap=" + ",".join(sorted(overlap)[:6]))

    # Modification-time plausibility.
    try:
        s_time = datetime.fromisoformat(script.mtime_iso)
        o_time = datetime.fromisoformat(output.mtime_iso)
        if o_time >= s_time:
            score += 5
            reasons.append("output_not_older_than_script")
    except Exception:
        pass

    # Stage-7E should not pair every unknown with every unknown.
    if script.stage_label == "UNKNOWN_STAGE" and output.stage_label == "UNKNOWN_STAGE":
        score -= 35
        reasons.append("both_stage_unknown_penalty")

    # Penalize generic docs with no token match.
    if output.kind == "ledger_or_documentation" and not shared_domain and script.stage_label != output.stage_label:
        score -= 15
        reasons.append("generic_documentation_penalty")

    return score, reasons


def match_class_from_score(score: float) -> str:
    if score >= 90:
        return "strong_candidate_link"
    if score >= 65:
        return "moderate_candidate_link"
    if score >= 45:
        return "weak_candidate_link"
    return "below_threshold"


def build_crosswalk(
    scripts: Sequence[FileRecord],
    outputs: Sequence[FileRecord],
    max_per_script: int = 25,
    min_score: float = 45.0,
) -> List[CrosswalkRecord]:
    rows: List[CrosswalkRecord] = []
    for script in scripts:
        scored: List[Tuple[float, FileRecord, List[str]]] = []
        for output in outputs:
            if output.relpath == script.relpath:
                continue
            score, reasons = score_script_output(script, output)
            if score >= min_score:
                scored.append((score, output, reasons))
        scored.sort(key=lambda x: (-x[0], x[1].relpath))
        for score, output, reasons in scored[:max_per_script]:
            rows.append(CrosswalkRecord(
                script_relpath=script.relpath,
                output_relpath=output.relpath,
                script_stage=script.stage_label,
                output_stage=output.stage_label,
                script_version=script.version_label,
                output_version=output.version_label,
                score=round(score, 3),
                match_class=match_class_from_score(score),
                reasons=";".join(reasons),
            ))
    return rows


# ---------------------------------------------------------------------------
# Decision-map extraction from ledgers/text outputs
# ---------------------------------------------------------------------------

def extract_line_value(text: str, labels: Sequence[str]) -> str:
    """
    Extract first matching line in forms:
        Verdict: ...
        Verdict                 : ...
        Decision = ...
    """
    for label in labels:
        pat = re.compile(rf"^\s*{re.escape(label)}\s*[:=]\s*(.+?)\s*$", re.IGNORECASE | re.MULTILINE)
        m = pat.search(text)
        if m:
            return m.group(1).strip()
    return ""


def extract_block_after_label(text: str, label: str, max_lines: int = 3) -> str:
    lines = text.splitlines()
    for i, line in enumerate(lines):
        if re.match(rf"^\s*{re.escape(label)}\s*[:=]?\s*$", line, flags=re.IGNORECASE):
            block = []
            for nxt in lines[i + 1:i + 1 + max_lines]:
                stripped = nxt.strip()
                if not stripped:
                    break
                if re.match(r"^[A-Z][A-Za-z _/-]{2,30}\s*[:=]\s*", stripped):
                    break
                block.append(stripped)
            return " ".join(block).strip()
    return ""


def decision_rows_from_ledgers(ledgers: Sequence[FileRecord], root: Path) -> List[dict]:
    rows: List[dict] = []
    for r in ledgers:
        ext = r.extension.lower()
        if ext not in TEXT_EXTS:
            continue
        path = root / r.relpath
        text = safe_read_text(path, max_bytes=500_000)
        if not text:
            continue

        verdict = extract_line_value(text, ["Verdict", "Triage verdict", "Stage verdict"])
        decision = extract_line_value(text, ["Decision", "Next action", "Status", "Stage status"])
        rationale = extract_line_value(text, ["Rationale", "Reason"])
        if not verdict:
            verdict = extract_block_after_label(text, "Verdict")
        if not decision:
            decision = extract_block_after_label(text, "Decision")
        if not rationale:
            rationale = extract_block_after_label(text, "Rationale")

        claim_status = infer_claim_status_from_text(text, r)

        if verdict or decision or rationale or claim_status != "unclassified":
            rows.append({
                "source_relpath": r.relpath,
                "stage_label": r.stage_label,
                "version_label": r.version_label,
                "stage_version_label": r.stage_version_label,
                "claim_status": claim_status,
                "verdict": compact(verdict, 300),
                "decision": compact(decision, 300),
                "rationale": compact(rationale, 500),
                "mtime_iso": r.mtime_iso,
            })
    return rows


def infer_claim_status_from_text(text: str, r: FileRecord) -> str:
    lower = (text[:120_000] + " " + r.relpath).lower()
    if any(tok in lower for tok in ["appendix-only", "appendix only", "appendix-grade", "friedmann", "lambda", "acceleration proxy"]):
        return "appendix_only_or_guarded"
    if any(tok in lower for tok in ["forbidden claim", "do not claim", "not allowed"]):
        return "claim_guardrail"
    if any(tok in lower for tok in ["deprecated", "do-not-rerun", "do not rerun", "superseded"]):
        return "deprecated_or_quarantined"
    if any(tok in lower for tok in ["null", "adversarial", "negative result", "control"]):
        return "null_or_negative_control"
    if any(tok in lower for tok in ["canonical", "mainline", "family-preserving", "two-sector"]):
        return "mainline_or_canonical"
    return "unclassified"


def compact(s: str, max_len: int) -> str:
    s = re.sub(r"\s+", " ", s or "").strip()
    if len(s) > max_len:
        return s[:max_len - 3] + "..."
    return s


# ---------------------------------------------------------------------------
# Derived tables
# ---------------------------------------------------------------------------

def build_rescue_branch_classification(scripts: Sequence[FileRecord]) -> List[dict]:
    rows: List[dict] = []
    for r in scripts:
        branch_class, reason, priority = classify_script_record(r)
        rows.append({
            "script_relpath": r.relpath,
            "stage_label": r.stage_label,
            "version_label": r.version_label,
            "branch_class": branch_class,
            "priority_score": priority,
            "classification_reason": reason,
            "mtime_iso": r.mtime_iso,
            "size_bytes": r.size_bytes,
        })
    rows.sort(key=lambda row: (
        stage_sort_key(row["stage_label"]),
        version_sort_key(row["version_label"]),
        row["branch_class"],
        row["script_relpath"],
    ))
    return rows


def build_canonical_run_candidates(
    scripts: Sequence[FileRecord],
    crosswalk: Sequence[CrosswalkRecord],
) -> List[dict]:
    links_by_script = defaultdict(list)
    for c in crosswalk:
        links_by_script[c.script_relpath].append(c)

    rows: List[dict] = []
    for r in scripts:
        branch_class, reason, priority = classify_script_record(r)
        links = links_by_script.get(r.relpath, [])
        strong_links = sum(1 for x in links if x.match_class == "strong_candidate_link")
        moderate_links = sum(1 for x in links if x.match_class in {"strong_candidate_link", "moderate_candidate_link"})

        stage_known_bonus = 20 if r.stage_label != "UNKNOWN_STAGE" else 0
        version_bonus = 10 if r.version_label != "UNKNOWN_VERSION" else 0
        output_bonus = min(30, 3 * len(links)) + 5 * strong_links
        penalty = 0
        if branch_class in {"rescue_or_repair", "deprecated_or_superseded_candidate"}:
            penalty += 35
        if branch_class == "unknown":
            penalty += 20

        canonical_score = priority + stage_known_bonus + version_bonus + output_bonus - penalty

        if branch_class == "appendix_candidate":
            run_role = "appendix_or_guarded_comparison_candidate"
        elif branch_class == "canonical_candidate":
            run_role = "mainline_canonical_candidate"
        elif branch_class == "null_or_adversarial_control":
            run_role = "control_or_adversarial_candidate"
        elif branch_class == "rescue_or_repair":
            run_role = "supporting_rescue_history_not_primary_run"
        elif branch_class == "documentation_or_inventory":
            run_role = "documentation_or_stage7E_infrastructure"
        else:
            run_role = "exploratory_or_uncertain"

        rows.append({
            "recommended_order_key": "",
            "script_relpath": r.relpath,
            "stage_label": r.stage_label,
            "version_label": r.version_label,
            "run_role": run_role,
            "branch_class": branch_class,
            "canonical_score": canonical_score,
            "candidate_output_links": len(links),
            "strong_output_links": strong_links,
            "moderate_or_strong_output_links": moderate_links,
            "classification_reason": reason,
            "mtime_iso": r.mtime_iso,
        })

    rows.sort(key=lambda row: (
        stage_sort_key(row["stage_label"]),
        version_sort_key(row["version_label"]),
        -row["canonical_score"],
        row["script_relpath"],
    ))

    for idx, row in enumerate(rows, start=1):
        row["recommended_order_key"] = f"{idx:04d}"

    return rows


def build_deprecated_or_superseded(scripts: Sequence[FileRecord]) -> List[dict]:
    by_family = defaultdict(list)
    for r in scripts:
        key = (r.stage_label, family_signature_for_script(r.relpath))
        by_family[key].append(r)

    rows: List[dict] = []
    for (stage, sig), items in by_family.items():
        if len(items) < 2:
            continue
        items_sorted = sorted(
            items,
            key=lambda r: (version_sort_key(r.version_label), r.mtime_iso, r.relpath)
        )
        latest = items_sorted[-1]
        for old in items_sorted[:-1]:
            # Do not over-aggressively supersede rescue/repair variants; mark as possible.
            old_class, _, _ = classify_script_record(old)
            latest_class, _, _ = classify_script_record(latest)
            certainty = "probable" if old.version_label != latest.version_label else "possible"
            if old_class != latest_class:
                certainty = "possible_cross_branch"
            rows.append({
                "script_relpath": old.relpath,
                "stage_label": old.stage_label,
                "version_label": old.version_label,
                "family_signature": sig,
                "superseded_by_relpath": latest.relpath,
                "superseded_by_version": latest.version_label,
                "supersession_certainty": certainty,
                "note": "Do not delete automatically. Review before quarantine; Stage-7E is read-only.",
            })

    # Also mark explicit deprecated/old/legacy names.
    for r in scripts:
        toks = token_set_from_record(r)
        if toks & {"deprecated", "superseded", "legacy", "old", "backup"}:
            rows.append({
                "script_relpath": r.relpath,
                "stage_label": r.stage_label,
                "version_label": r.version_label,
                "family_signature": family_signature_for_script(r.relpath),
                "superseded_by_relpath": "",
                "superseded_by_version": "",
                "supersession_certainty": "explicit_name_token",
                "note": "Filename/path contains deprecated/superseded/legacy/old/backup token.",
            })

    rows.sort(key=lambda row: (
        stage_sort_key(row["stage_label"]),
        version_sort_key(row["version_label"]),
        row["script_relpath"],
    ))
    return rows


def build_missing_or_orphaned(
    scripts: Sequence[FileRecord],
    outputs: Sequence[FileRecord],
    crosswalk: Sequence[CrosswalkRecord],
) -> List[dict]:
    linked_outputs = {c.output_relpath for c in crosswalk}
    linked_scripts = {c.script_relpath for c in crosswalk}

    rows: List[dict] = []
    for out in outputs:
        if out.relpath not in linked_outputs and out.kind != "ledger_or_documentation":
            rows.append({
                "item_type": "orphan_output_candidate",
                "relpath": out.relpath,
                "stage_label": out.stage_label,
                "version_label": out.version_label,
                "kind": out.kind,
                "issue": "No script-output link above threshold.",
                "suggested_action": "Review filename/path; keep if manuscript asset, otherwise mark historical/support.",
            })

    for script in scripts:
        if script.relpath not in linked_scripts:
            branch_class, _, _ = classify_script_record(script)
            rows.append({
                "item_type": "script_without_matched_outputs",
                "relpath": script.relpath,
                "stage_label": script.stage_label,
                "version_label": script.version_label,
                "kind": branch_class,
                "issue": "No output link above threshold.",
                "suggested_action": "Check whether script is infrastructure, failed branch, notebook-only, or needs rerun.",
            })

    rows.sort(key=lambda row: (
        row["item_type"],
        stage_sort_key(row["stage_label"]),
        version_sort_key(row["version_label"]),
        row["relpath"],
    ))
    return rows


# ---------------------------------------------------------------------------
# Markdown/text outputs
# ---------------------------------------------------------------------------

def make_repository_layout_recommendation(summary: dict) -> str:
    generated = summary.get("generated_utc", now_iso())
    return f"""# Stage-7E-v1 Repository Layout Recommendation

Generated: {generated}

## Purpose

This recommendation supports the Stage-7E goal: make the QEG repository
auditable without forcing a reader to inspect every rescue script or every
diagnostic plot.

Stage-7E should preserve the full scientific trail while separating:

- canonical/reproducible run path,
- rescue and repair history,
- null/adversarial controls,
- appendix-grade GR-adjacent comparisons,
- deprecated or superseded exploratory branches,
- manuscript assets.

## Proposed GitHub / Zenodo Top-Level Layout

```text
010-Quantum_Emergent_Gravity/
├── README.md
├── CITATION.cff
├── LICENSE
├── environment/
│   ├── python_version.txt
│   ├── package_freeze.txt
│   └── run_notes.md
├── data_inputs/
│   ├── raw_or_external/
│   ├── curated/
│   └── provenance_notes.md
├── scripts/
│   ├── 00_inventory_and_reproducibility/
│   ├── 01_intrinsic_geometry/
│   ├── 02_nonlocal_response_geometry/
│   ├── 03_two_sector_law/
│   ├── 04_family_universality/
│   ├── 05_recursive_transport_operator_stability/
│   ├── 06_semantic_physics_calibration/
│   ├── 07_null_and_adversarial_controls/
│   ├── 08_appendix_gr_adjacent_bookkeeping/
│   └── 99_rescue_repair_deprecated/
├── outputs/
│   ├── canonical_tables/
│   ├── canonical_figures/
│   ├── null_controls/
│   ├── appendix_gr_adjacent/
│   ├── inventories_crosswalks/
│   └── historical_rescue_outputs/
├── ledgers/
│   ├── stage_decision_ledger/
│   ├── rescue_branch_ledger/
│   ├── claim_guardrails/
│   └── ascii_transition_packages/
├── manuscript/
│   ├── tables/
│   ├── figures/
│   ├── appendices/
│   └── physica_d_outline.md
└── zenodo_manifest/
    ├── file_manifest.csv
    ├── run_sequence.md
    └── reproducibility_statement.md
```

## Stage-7E Policy

1. Keep the full trail, but do not make the reader follow the full trail
   to understand the main result.
2. Mainline scripts should be discoverable in a canonical run sequence.
3. Rescue/repair scripts are preserved as scientific provenance, not
   promoted as the main route.
4. Stage-7D Friedmann/Lambda/acceleration material remains appendix-grade.
5. Deprecated scripts should be quarantined, not deleted.
6. Figures should be minimal; tables should carry most of the manuscript load.

## Current Inventory Snapshot

- Total files scanned: {summary.get("total_files", "NA")}
- Scripts/notebooks scanned: {summary.get("script_count", "NA")}
- Output/document artifacts scanned: {summary.get("output_count", "NA")}
- Ledger/documentation candidates: {summary.get("ledger_count", "NA")}
- Crosswalk links above threshold: {summary.get("crosswalk_link_count", "NA")}

## Immediate Manual Review Targets

Start with these generated files:

```text
stage7E_v1_canonical_run_candidates.csv
stage7E_v1_rescue_branch_classification.csv
stage7E_v1_deprecated_or_superseded_scripts.csv
stage7E_v1_missing_or_orphaned_outputs.csv
stage7E_v1_stage_decision_map.csv
```

These files determine what becomes canonical, appendix-only, supporting,
or quarantined before manuscript asset freeze.
"""


def make_readme_run_sequence_draft(
    canonical_rows: Sequence[dict],
    summary: dict,
    max_rows: int = 120,
) -> str:
    generated = summary.get("generated_utc", now_iso())

    # Keep likely useful rows; avoid flooding the README with every unknown script.
    selected = [
        r for r in canonical_rows
        if r["run_role"] in {
            "mainline_canonical_candidate",
            "control_or_adversarial_candidate",
            "appendix_or_guarded_comparison_candidate",
            "documentation_or_stage7E_infrastructure",
        }
    ]
    selected = selected[:max_rows]

    lines = [
        "# Stage-7E-v1 README Run Sequence Draft",
        "",
        f"Generated: {generated}",
        "",
        "## Scope",
        "",
        "This is a draft, not yet the final canonical run order.",
        "It is produced by a read-only inventory/crosswalk pass over the local QEG project.",
        "",
        "The final README should preserve rescue history but foreground the shortest",
        "auditable route from inputs to manuscript tables and figures.",
        "",
        "## Guardrail",
        "",
        "Do not interpret the Stage-7D Friedmann/Lambda/acceleration branch as a",
        "main derivation of GR or LambdaCDM. It is appendix-grade locked-reference",
        "bookkeeping using frozen QEG anchors.",
        "",
        "## Candidate Run Sequence",
        "",
        "| Order | Stage | Version | Role | Script | Candidate output links |",
        "|---:|---|---|---|---|---:|",
    ]

    for r in selected:
        lines.append(
            f"| {r['recommended_order_key']} | {r['stage_label']} | {r['version_label']} | "
            f"{r['run_role']} | `{r['script_relpath']}` | {r['candidate_output_links']} |"
        )

    if not selected:
        lines.extend([
            "",
            "_No canonical candidates were selected by the heuristic. Review the inventory CSVs._",
        ])

    lines.extend([
        "",
        "## Files To Review Before Freezing",
        "",
        "1. `stage7E_v1_script_inventory.csv`",
        "2. `stage7E_v1_output_inventory.csv`",
        "3. `stage7E_v1_script_output_crosswalk.csv`",
        "4. `stage7E_v1_stage_decision_map.csv`",
        "5. `stage7E_v1_rescue_branch_classification.csv`",
        "6. `stage7E_v1_deprecated_or_superseded_scripts.csv`",
        "",
        "## Manuscript-Oriented Compression Rule",
        "",
        "For the Physica D manuscript, write method-result units:",
        "",
        "```text",
        "question -> method -> result -> interpretation -> next constraint",
        "```",
        "",
        "Do not separate all methods from all results in a way that forces the reader",
        "to reconstruct the pipeline from dozens of disconnected scripts.",
    ])
    return "\n".join(lines) + "\n"


def make_ledger_note(summary: dict) -> str:
    generated = summary.get("generated_utc", now_iso())
    return f"""============================================================
Stage-7E-v1 Ledger Note
Project: Quantum-Emergent Gravity
Script: Stage-7E-v1_project_inventory_ledger_crosswalk.py
Generated: {generated}
============================================================

Purpose:
  Stage-7E-v1 performs a read-only inventory and crosswalk audit of
  resident QEG project scripts, outputs, ledgers, rescue branches,
  appendix branches, and possible deprecated/superseded files.

Stage-7E role:
  This is a reproducibility/compression/manuscript-preparation stage.
  It is not a new physics result stage.

Counts:
  Total files scanned              : {summary.get("total_files", "NA")}
  Script/notebook candidates       : {summary.get("script_count", "NA")}
  Output/document candidates       : {summary.get("output_count", "NA")}
  Ledger/documentation candidates  : {summary.get("ledger_count", "NA")}
  Crosswalk links above threshold  : {summary.get("crosswalk_link_count", "NA")}
  Canonical run candidate rows     : {summary.get("canonical_candidate_count", "NA")}
  Rescue/repair classification rows: {summary.get("rescue_classification_count", "NA")}
  Deprecated/superseded candidates : {summary.get("deprecated_candidate_count", "NA")}
  Missing/orphaned review rows     : {summary.get("missing_or_orphaned_count", "NA")}

Interpretation:
  The generated CSVs are audit aids, not final scientific verdicts.
  Stage-7E should use them to freeze the canonical run path, quarantine
  deprecated branches, preserve rescue provenance, and select only the
  manuscript-essential figures and tables.

Guardrails:
  - Stage-7D Friedmann/Lambda/acceleration outputs remain appendix-grade.
  - QEG should not be framed as deriving GR, LambdaCDM, dark energy,
    quantum gravity, cosmic acceleration, cosmic time, or the age of the
    Universe.
  - The strong claim remains the reproducible, family-preserving,
    emergent nonlocal operator geometry with a stable two-sector law.

Next action:
  Manually inspect the canonical run candidates, rescue classification,
  deprecated/superseded candidates, missing/orphaned outputs, and stage
  decision map. Then prepare Stage-7E-v2 canonical run sequence builder
  or Stage-7E-v3 manuscript asset freeze.
============================================================
END LEDGER NOTE
============================================================
"""


def make_ascii_transition_package(summary: dict) -> str:
    generated = summary.get("generated_utc", now_iso())
    return f"""============================================================
ASCII TRANSITION PACKAGE
Project: Quantum-Emergent Gravity
Stage: Stage-7E-v1
Working Title: Project Inventory, Ledger Crosswalk, and
Canonical Run Candidate Audit
Generated: {generated}
Status: READ-ONLY AUDIT SCRIPT PRODUCED
============================================================

## PURPOSE

Stage-7E-v1 creates the first repository-wide audit layer for the QEG
pipeline.

It does not create new physics results.

It inventories resident scripts, outputs, ledgers, candidate manuscript
assets, rescue branches, appendix-grade comparison branches, and possible
deprecated or superseded scripts.

## LOCAL ROOT

Project root audited:

```text
{summary.get("project_root", "NA")}
```

Output directory:

```text
{summary.get("output_dir", "NA")}
```

## PRODUCED FILES

```text
stage7E_v1_script_inventory.csv
stage7E_v1_output_inventory.csv
stage7E_v1_ledger_inventory.csv
stage7E_v1_script_output_crosswalk.csv
stage7E_v1_stage_decision_map.csv
stage7E_v1_rescue_branch_classification.csv
stage7E_v1_canonical_run_candidates.csv
stage7E_v1_deprecated_or_superseded_scripts.csv
stage7E_v1_missing_or_orphaned_outputs.csv
stage7E_v1_repository_layout_recommendation.md
stage7E_v1_readme_run_sequence_draft.md
stage7E_v1_summary.json
stage7E_v1_ledger_note.txt
stage7E_v1_ascii_transition_package.txt
```

## SUMMARY COUNTS

```text
Total files scanned              : {summary.get("total_files", "NA")}
Scripts/notebooks scanned        : {summary.get("script_count", "NA")}
Outputs/documents scanned        : {summary.get("output_count", "NA")}
Ledgers/documentation candidates : {summary.get("ledger_count", "NA")}
Crosswalk links above threshold  : {summary.get("crosswalk_link_count", "NA")}
Canonical run candidate rows     : {summary.get("canonical_candidate_count", "NA")}
Rescue classification rows       : {summary.get("rescue_classification_count", "NA")}
Deprecated/superseded candidates : {summary.get("deprecated_candidate_count", "NA")}
Missing/orphaned review rows     : {summary.get("missing_or_orphaned_count", "NA")}
```

## CLAIM HIERARCHY PRESERVED

Strong claim class:

```text
QEG identifies a reproducible, family-preserving emergent nonlocal
operator geometry with a stable two-sector law.
```

Moderate claim class:

```text
The operator geometry is consistent with low-rank asymmetric non-Toeplitz
transport and survives several adversarial checks.
```

Cautious physics-facing claim class:

```text
Internally generated matter-like sector proxies and related frozen anchors
show benchmark proximity under locked-reference comparison.
```

Appendix-only claim class:

```text
Friedmann / Lambda / acceleration bookkeeping produces a coherent
GR-adjacent proximity corridor.
```

Forbidden claim class:

```text
{chr(10).join("- " + c for c in FORBIDDEN_CLAIMS)}
```

## HOW TO USE THIS OUTPUT

1. Open `stage7E_v1_canonical_run_candidates.csv`.
2. Identify which scripts are truly canonical versus merely useful.
3. Open `stage7E_v1_rescue_branch_classification.csv`.
4. Preserve rescue branches as provenance, not as the main paper path.
5. Open `stage7E_v1_deprecated_or_superseded_scripts.csv`.
6. Quarantine deprecated material only after manual review.
7. Open `stage7E_v1_stage_decision_map.csv`.
8. Extract verdicts/decisions for the manuscript stage map.
9. Open `stage7E_v1_missing_or_orphaned_outputs.csv`.
10. Decide whether each orphan is a manuscript asset, appendix asset,
    historical artifact, or rerun target.

## NEXT STAGE OPTIONS

```text
Stage-7E-v2_canonical_run_sequence_builder.py
Stage-7E-v3_manuscript_asset_freeze.py
```

Recommended next action:
  Use this v1 audit bundle to manually mark canonical scripts and
  manuscript assets, then generate a shorter, explicit run sequence.

============================================================
END STAGE-7E-v1 ASCII TRANSITION PACKAGE
============================================================
"""


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Stage-7E-v1 read-only QEG project inventory and script-output crosswalk."
    )
    parser.add_argument(
        "--root",
        type=Path,
        default=DEFAULT_ROOT,
        help=f"QEG project root. Default: {DEFAULT_ROOT}",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=None,
        help="Output directory. Default: <root>/metric_stage_7E_outputs/project_inventory_ledger_crosswalk_v1",
    )
    parser.add_argument(
        "--hash-mode",
        choices=["none", "prefix", "full"],
        default="prefix",
        help="Hash mode for file fingerprinting. Default: prefix.",
    )
    parser.add_argument(
        "--max-crosswalk-per-script",
        type=int,
        default=25,
        help="Maximum output links retained for each script. Default: 25.",
    )
    parser.add_argument(
        "--min-crosswalk-score",
        type=float,
        default=45.0,
        help="Minimum script-output crosswalk score. Default: 45.",
    )
    return parser.parse_args(argv)


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = parse_args(argv)
    root = args.root.expanduser().resolve()

    if not root.exists() or not root.is_dir():
        print(f"ERROR: project root does not exist or is not a directory: {root}", file=sys.stderr)
        return 2

    outdir = args.output_dir
    if outdir is None:
        outdir = root / "metric_stage_7E_outputs" / "project_inventory_ledger_crosswalk_v1"
    outdir = outdir.expanduser().resolve()
    outdir.mkdir(parents=True, exist_ok=True)

    print("=" * 72)
    print("Stage-7E-v1: QEG project inventory and ledger crosswalk")
    print("=" * 72)
    print(f"Project root : {root}")
    print(f"Output dir   : {outdir}")
    print(f"Hash mode    : {args.hash_mode}")
    print("Mode         : read-only audit; no existing project files will be modified")
    print("-" * 72)

    records = scan_project(root, hash_mode=args.hash_mode)
    scripts = [r for r in records if is_script_record(r)]
    outputs = [r for r in records if is_output_record(r)]
    ledgers = [r for r in records if is_ledger_record(r)]

    # Exclude this Stage-7E output directory from outputs if the script is rerun,
    # except keep a clear record of Stage-7E outputs in the global inventory.
    # This prevents the crosswalk from linking v1 to its own generated CSVs too strongly.
    outdir_rel = safe_rel(outdir, root)
    outputs_for_crosswalk = [
        r for r in outputs
        if not r.relpath.startswith(outdir_rel)
    ]

    print(f"Total files scanned             : {len(records)}")
    print(f"Script/notebook candidates      : {len(scripts)}")
    print(f"Output/document candidates      : {len(outputs)}")
    print(f"Ledger/documentation candidates : {len(ledgers)}")
    print("Building script-output crosswalk...")
    crosswalk = build_crosswalk(
        scripts=scripts,
        outputs=outputs_for_crosswalk,
        max_per_script=args.max_crosswalk_per_script,
        min_score=args.min_crosswalk_score,
    )

    rescue_rows = build_rescue_branch_classification(scripts)
    canonical_rows = build_canonical_run_candidates(scripts, crosswalk)
    deprecated_rows = build_deprecated_or_superseded(scripts)
    missing_rows = build_missing_or_orphaned(scripts, outputs_for_crosswalk, crosswalk)
    decision_rows = decision_rows_from_ledgers(ledgers, root=root)

    # Sort inventory tables.
    script_rows = [asdict(r) for r in sorted(
        scripts, key=lambda r: (stage_sort_key(r.stage_label), version_sort_key(r.version_label), r.relpath)
    )]
    output_rows = [dict(asdict(r), output_class=classify_output_record(r)) for r in sorted(
        outputs, key=lambda r: (stage_sort_key(r.stage_label), version_sort_key(r.version_label), r.relpath)
    )]
    ledger_rows = [asdict(r) for r in sorted(
        ledgers, key=lambda r: (stage_sort_key(r.stage_label), version_sort_key(r.version_label), r.relpath)
    )]
    crosswalk_rows = [asdict(c) for c in sorted(
        crosswalk, key=lambda c: (stage_sort_key(c.script_stage), version_sort_key(c.script_version), c.script_relpath, -c.score)
    )]

    stage_counts = Counter(r.stage_label for r in records)
    script_stage_counts = Counter(r.stage_label for r in scripts)
    output_stage_counts = Counter(r.stage_label for r in outputs)
    branch_counts = Counter(row["branch_class"] for row in rescue_rows)
    output_class_counts = Counter(row["output_class"] for row in output_rows)

    summary = {
        "generated_utc": now_iso(),
        "script_name": "Stage-7E-v1_project_inventory_ledger_crosswalk.py",
        "project_root": str(root),
        "output_dir": str(outdir),
        "hash_mode": args.hash_mode,
        "total_files": len(records),
        "script_count": len(scripts),
        "output_count": len(outputs),
        "ledger_count": len(ledgers),
        "crosswalk_link_count": len(crosswalk_rows),
        "canonical_candidate_count": len(canonical_rows),
        "rescue_classification_count": len(rescue_rows),
        "deprecated_candidate_count": len(deprecated_rows),
        "missing_or_orphaned_count": len(missing_rows),
        "decision_map_rows": len(decision_rows),
        "stage_counts": dict(sorted(stage_counts.items(), key=lambda kv: stage_sort_key(kv[0]))),
        "script_stage_counts": dict(sorted(script_stage_counts.items(), key=lambda kv: stage_sort_key(kv[0]))),
        "output_stage_counts": dict(sorted(output_stage_counts.items(), key=lambda kv: stage_sort_key(kv[0]))),
        "branch_class_counts": dict(branch_counts),
        "output_class_counts": dict(output_class_counts),
        "stage7E_policy": {
            "mode": "read_only_audit",
            "main_purpose": "pipeline compression, repository freeze, manuscript preparation",
            "stage7D_status": "appendix_only_guarded_GR_adjacent_bundle",
            "forbidden_claims": FORBIDDEN_CLAIMS,
        },
    }

    # Write required outputs.
    write_csv(outdir / "stage7E_v1_script_inventory.csv", script_rows)
    write_csv(outdir / "stage7E_v1_output_inventory.csv", output_rows)
    write_csv(outdir / "stage7E_v1_ledger_inventory.csv", ledger_rows)
    write_csv(outdir / "stage7E_v1_script_output_crosswalk.csv", crosswalk_rows)
    write_csv(outdir / "stage7E_v1_stage_decision_map.csv", decision_rows)
    write_csv(outdir / "stage7E_v1_rescue_branch_classification.csv", rescue_rows)
    write_csv(outdir / "stage7E_v1_canonical_run_candidates.csv", canonical_rows)
    write_csv(outdir / "stage7E_v1_deprecated_or_superseded_scripts.csv", deprecated_rows)
    write_csv(outdir / "stage7E_v1_missing_or_orphaned_outputs.csv", missing_rows)
    write_json(outdir / "stage7E_v1_summary.json", summary)
    write_text(outdir / "stage7E_v1_repository_layout_recommendation.md", make_repository_layout_recommendation(summary))
    write_text(outdir / "stage7E_v1_readme_run_sequence_draft.md", make_readme_run_sequence_draft(canonical_rows, summary))
    write_text(outdir / "stage7E_v1_ledger_note.txt", make_ledger_note(summary))
    write_text(outdir / "stage7E_v1_ascii_transition_package.txt", make_ascii_transition_package(summary))

    print("Done.")
    print("-" * 72)
    print(f"Wrote Stage-7E-v1 bundle to: {outdir}")
    print()
    print("Key review files:")
    print(f"  {outdir / 'stage7E_v1_canonical_run_candidates.csv'}")
    print(f"  {outdir / 'stage7E_v1_rescue_branch_classification.csv'}")
    print(f"  {outdir / 'stage7E_v1_deprecated_or_superseded_scripts.csv'}")
    print(f"  {outdir / 'stage7E_v1_missing_or_orphaned_outputs.csv'}")
    print(f"  {outdir / 'stage7E_v1_stage_decision_map.csv'}")
    print("=" * 72)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
