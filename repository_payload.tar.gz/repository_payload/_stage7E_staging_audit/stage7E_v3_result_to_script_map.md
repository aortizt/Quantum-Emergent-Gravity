# Stage-7E-v3 Result-Spine Map

Generated: 2026-06-03T23:03:57+00:00

## Purpose

This file asks whether the GitHub candidate bundle covers the actual major QEG results, not merely one script per stage.

## Result spine coverage

| Result | Status | Core scripts | Supplements | Claim class |
|---|---|---:|---:|---|
| Family-root geometry and metric candidates | COVERED_BY_V2_CORE | 13 | 0 | data_lineage_and_intrinsic_geometry |
| Symmetry breaking and admissibility-boundary geometry | COVERED_BY_V2_CORE | 7 | 0 | metric_geometry_and_symmetry_breaking |
| Emergence of intrinsic rho/kappa fields | COVERED_BY_V2_CORE | 3 | 0 | intrinsic_field_construction |
| Nonlocal rho/kappa operator geometry | COVERED_BY_V2_CORE | 5 | 0 | nonlocal_operator_geometry |
| Two-lobe law and family universality | COVERED_WITH_RESULT_SUPPLEMENTS | 5 | 1 | canonical_two_sector_law |
| Mechanism narrowing and recursive stability | COVERED_WITH_RESULT_SUPPLEMENTS | 4 | 4 | controls_and_recursive_hardening |
| Cosmological-proximity bookkeeping, including Omega_m-like results | COVERED_WITH_RESULT_SUPPLEMENTS | 9 | 0 | comparison_bookkeeping_not_identification |
| Time surrogate, entropy, and irreversibility evidence | COVERED_WITH_RESULT_SUPPLEMENTS | 5 | 3 | time_surrogate_evidence_not_cosmic_time_derivation |
| Stage-7D GR-adjacent appendix: Friedmann, Lambda, dark energy, acceleration | COVERED_WITH_RESULT_SUPPLEMENTS | 4 | 1 | appendix_only_gr_adjacent_bookkeeping |
| Repository compression and reproducibility manifests | CORE_COVERED_BUT_SUPPLEMENT_PATTERN_MISSING | 1 | 0 | reproducibility_infrastructure |

## Minimal GitHub script bundle by result

### R01_family_geometry_metric_candidates: Family-root geometry and metric candidates

Question: How do BARI / NUFIT / VALENCIA roots enter the pipeline, and how does Stage-5/6 build metric candidates from them?

Recommended folder: `scripts/mainline/01_family_geometry_metric_candidates`

| Role | Script | Why included |
|---|---|---|
| mainline_core | `Spyder_Console_plot_global_PC1_PC2_03_14_2026.py` | selected by v2 milestone/preferred pattern for this result spine |
| rescue_provenance | `_archive_stage5A_legacy/stage5A_bridge_from_stage4D_v1b2_fixed.py` | selected by v2 milestone/preferred pattern for this result spine |
| mainline_core | `metric_stage_4A_shellbands.py` | selected by v2 milestone/preferred pattern for this result spine |
| mainline_core | `stage4B_beta_holonly_from_commnorm_v1.py` | selected by v2 milestone/preferred pattern for this result spine |
| mainline_core | `Stage-4C_REAL_Option-A_v5.py` | selected by v2 milestone/preferred pattern for this result spine |
| mainline_core | `metric_stage_4D_scripts/stage4D_transport_layers_v1.py` | selected by v2 milestone/preferred pattern for this result spine |
| mainline_core | `metric_stage_5A_scripts/stage5A_bridge_from_stage4D_v1b2.py` | selected by v2 milestone/preferred pattern for this result spine |
| mainline_core | `metric_stage_5A_scripts/stage5A_bridge_from_stage4D_v1b2_fixed.py` | selected by v2 milestone/preferred pattern for this result spine |
| mainline_core | `metric_stage_5B_outputs/metric_stage_5B_metric_candidate_from_global_PC1_v1.py` | selected by v2 milestone/preferred pattern for this result spine |
| mainline_core | `metric_stage_5C_outputs/metric_stage_5C_intrinsic_coordinate_from_PC1_PC2_v4.py` | selected by v2 milestone/preferred pattern for this result spine |
| mainline_core | `metric_stage_5D_outputs/metric_stage_5D_formalize_preferred_intrinsic_coordinate_v1b.py` | selected by v2 milestone/preferred pattern for this result spine |
| mainline_core | `metric_stage_6A_scripts/metric_stage_6A_construct_candidate_metrics_from_stage5_coordinate_v1.py` | selected by v2 milestone/preferred pattern for this result spine |
| mainline_core | `metric_stage_6B_scripts/metric_stage_6B_evaluate_candidate_metrics_from_stage6A_v1.py` | selected by v2 milestone/preferred pattern for this result spine |

### R02_symmetry_breaking_admissibility_geometry: Symmetry breaking and admissibility-boundary geometry

Question: Where does the metric/admissibility geometry show common support, symmetry breaking, curved boundary structure, and intrinsic curvature?

Recommended folder: `scripts/mainline/02_symmetry_breaking_admissibility_geometry`

| Role | Script | Why included |
|---|---|---|
| mainline_core | `metric_stage_6C_scripts/metric_stage_6C_normalization_and_gauge_analysis_v2.py` | selected by v2 milestone/preferred pattern for this result spine |
| mainline_core | `metric_stage_6D_scripts/Stage-6D_v2.py` | selected by v2 milestone/preferred pattern for this result spine |
| mainline_core | `metric_stage_6D_scripts/Stage-6D_v2_fixed.py` | selected by v2 milestone/preferred pattern for this result spine |
| mainline_core | `metric_stage_6D_branch1_scripts/metric_stage_6D_branch1_refined_boundary_v3.py` | selected by v2 milestone/preferred pattern for this result spine |
| mainline_core | `metric_stage_6E_scripts/metric_stage_6E_fit_boundary_law_v1b.py` | selected by v2 milestone/preferred pattern for this result spine |
| mainline_core | `metric_stage_6F_scripts/Stage-6F_curvature_geometry_v1c.py` | selected by v2 milestone/preferred pattern for this result spine |
| mainline_core | `metric_stage_6G_scripts/Stage-6G_intrinsic_boundary_geometry_v1b.py` | selected by v2 milestone/preferred pattern for this result spine |

### R03_rho_kappa_intrinsic_fields: Emergence of intrinsic rho/kappa fields

Question: How are intrinsic curvature-like kappa(s) and density-like rho(s) fields constructed and made distributional rather than sector-label dependent?

Recommended folder: `scripts/mainline/03_rho_kappa_intrinsic_fields`

| Role | Script | Why included |
|---|---|---|
| mainline_core | `metric_stage_6H_scripts/Stage-6H_intrinsic_distributional_invariants_v1b.py` | selected by v2 milestone/preferred pattern for this result spine |
| mainline_core | `metric_stage_6I_scripts/Stage-6I_operator_response_suite_v1.py` | selected by v2 milestone/preferred pattern for this result spine |
| mainline_core | `metric_stage_6I_scripts/Stage-6I_operator_response_suite_v1b.py` | selected by v2 milestone/preferred pattern for this result spine |

### R04_nonlocal_rho_kappa_operator: Nonlocal rho/kappa operator geometry

Question: How is local closure rejected, and how is a nonlocal kappa-to-rho operator recovered and compressed?

Recommended folder: `scripts/mainline/04_nonlocal_operator_geometry`

| Role | Script | Why included |
|---|---|---|
| mainline_core | `metric_stage_6I_scripts/Stage-6I_operator_response_suite_v1.py` | selected by v2 milestone/preferred pattern for this result spine |
| mainline_core | `metric_stage_6I_scripts/Stage-6I_operator_response_suite_v1b.py` | selected by v2 milestone/preferred pattern for this result spine |
| mainline_core | `metric_stage_6J_scripts/Stage-6J_intrinsic_nonlocal_response_geometry_v1.py` | selected by v2 milestone/preferred pattern for this result spine |
| mainline_core | `metric_stage_6K_scripts/Stage-6K_canonical_operator_reduction_v1.py` | selected by v2 milestone/preferred pattern for this result spine |
| mainline_core | `metric_stage_6L_scripts/Stage-6L_continuum_law_PDE_analogue_v1.py` | selected by v2 milestone/preferred pattern for this result spine |

### R05_two_lobe_law_family_universality: Two-lobe law and family universality

Question: How is the early+central two-lobe law discovered, formalized, repaired for family provenance, and accepted as family-universal?

Recommended folder: `scripts/mainline/05_two_lobe_law_family_universality`

| Role | Script | Why included |
|---|---|---|
| mainline_core | `metric_stage_6M_scripts/Stage-6M_targeted_modal_resolution_v2c.py` | selected by v2 milestone/preferred pattern for this result spine |
| mainline_core | `metric_stage_6N_scripts/Stage-6N_canonical_two_lobe_law_v1a.py` | selected by v2 milestone/preferred pattern for this result spine |
| mainline_core | `metric_stage_6O_scripts/Stage-6O_direct_modal_rho_provenance_audit_v1.py` | selected by v2 milestone/preferred pattern for this result spine |
| mainline_core | `metric_stage_6P_scripts/Stage-6P_two_lobe_universality_test_on_v5_candidate_v6.py` | selected by v2 milestone/preferred pattern for this result spine |
| mainline_core | `metric_stage_6Q_scripts/Stage-6Q_canonical_law_extraction_v1.py` | selected by v2 milestone/preferred pattern for this result spine |

### R06_mechanism_and_recursive_stability: Mechanism narrowing and recursive stability

Question: How are tautological reconstructions excluded, source-side mechanisms narrowed, and recursive transport stability hardened?

Recommended folder: `scripts/controls/01_mechanism_recursive_stability`

| Role | Script | Why included |
|---|---|---|
| control_or_hardening | `metric_stage_6R_scripts/Stage-6R_operator_interpretation_layer_v2.py` | selected by v2 milestone/preferred pattern for this result spine |
| control_or_hardening | `metric_stage_6S_scripts/Stage-6S_mechanism_stability_operator_probes_v1.py` | selected by v2 milestone/preferred pattern for this result spine |
| control_or_hardening | `metric_stage_6T_scripts/Stage-6T_composite_probe_freeze_amplitude_calibration_v4.py` | selected by v2 milestone/preferred pattern for this result spine |
| control_or_hardening | `metric_stage_6Yn_scripts/Stage-6Yn_manuscript_freeze_provenance_clarification_v1a.py` | selected by v2 milestone/preferred pattern for this result spine |
| control_or_hardening | `metric_stage_6Yi_v1a_outputs/Stage-6Yi_publication_hardening_cross_evidence_audit_v1a.py` | added by v3 result-spine enforcement |
| control_or_hardening | `metric_stage_6yc_scripts/Stage-6Yc_branchA_scientific_claims_hardened_recursion_v1a.py` | added by v3 result-spine enforcement |
| control_or_hardening | `metric_stage_6Yi_scripts/Stage-6Yi_publication_hardening_cross_evidence_audit_v1a.py` | added by v3 result-spine enforcement |
| control_or_hardening | `metric_stage_6yc_scripts/Stage-6Yc_branchA_scientific_claims_hardened_recursion_v1.py` | added by v3 result-spine enforcement |

### R07_cosmology_proximity_bookkeeping: Cosmological-proximity bookkeeping, including Omega_m-like results

Question: Which internally generated dimensionless QEG invariants land near PDG/Planck-style cosmological benchmarks, especially Omega_m including dark matter, without claiming derivation?

Recommended folder: `scripts/result_supplements/01_cosmology_proximity_bookkeeping`

| Role | Script | Why included |
|---|---|---|
| result_critical_supplement | `metric_stage_6Q_scripts/Stage-6Q_canonical_law_extraction_v1.py` | selected by v2 milestone/preferred pattern for this result spine |
| result_critical_supplement | `metric_stage_6R_scripts/Stage-6R_operator_interpretation_layer_v2.py` | selected by v2 milestone/preferred pattern for this result spine |
| result_critical_supplement | `metric_stage_6Yi_scripts/Stage-6Yi_publication_hardening_cross_evidence_audit_v1a.py` | selected by v2 milestone/preferred pattern for this result spine |
| result_critical_supplement | `metric_stage_6Yi_v1a_outputs/Stage-6Yi_publication_hardening_cross_evidence_audit_v1a.py` | selected by v2 milestone/preferred pattern for this result spine |
| result_critical_supplement | `metric_stage_6Yj_scripts/Stage-6Yj_manuscript_axis_synthesis_v1.py` | selected by v2 milestone/preferred pattern for this result spine |
| result_critical_supplement | `metric_stage_6Yk_scripts/Stage-6Yk_omega_m_pareto_refinement_v1.py` | selected by v2 milestone/preferred pattern for this result spine |
| result_critical_supplement | `metric_stage_6Yl_scripts/Stage-6Yl_corrected_lock_omega_m_reconstruction_v1.py` | selected by v2 milestone/preferred pattern for this result spine |
| result_critical_supplement | `metric_stage_6Yn_scripts/Stage-6Yn_manuscript_freeze_provenance_clarification_v1a.py` | selected by v2 milestone/preferred pattern for this result spine |
| result_critical_supplement | `metric_stage_7A_scripts/Stage-7A_semantic_calibration_entropic_arrow_v1.py` | selected by v2 milestone/preferred pattern for this result spine |

### R08_time_surrogate_entropy_irreversibility: Time surrogate, entropy, and irreversibility evidence

Question: How are entropy-state-space evidence, operator directionality, forward/reverse recursion, low-k evidence, and partial-reversibility sandbox separated?

Recommended folder: `scripts/controls/02_time_entropy_irreversibility`

| Role | Script | Why included |
|---|---|---|
| control_or_hardening | `metric_stage_7A_scripts/Stage-7A_semantic_calibration_entropic_arrow_v1.py` | selected by v2 milestone/preferred pattern for this result spine |
| control_or_hardening | `metric_stage_7B_scripts/Stage-7B_time_surrogate_robustness_operator_irreversibility_v1.py` | selected by v2 milestone/preferred pattern for this result spine |
| control_or_hardening | `metric_stage_7C_scripts/Stage-7C-v1m_one_script_to_rule_time_surrogate_evidence.py` | selected by v2 milestone/preferred pattern for this result spine |
| control_or_hardening | `metric_stage_7C_scripts/Stage-7C-v1n_manuscript_evidence_hardening.py` | selected by v2 milestone/preferred pattern for this result spine |
| appendix_gr_adjacent | `metric_stage_7C_scripts/Stage-7C-v1o_unknown_survivor_friedmann_transition.py` | selected by v2 milestone/preferred pattern for this result spine |
| control_or_hardening | `metric_stage_7C_scripts/Stage-7C_witness_class_reconstruction_valid_denominator_v1a.py` | added by v3 result-spine enforcement |
| control_or_hardening | `metric_stage_7C_scripts/Stage-7C-v1f_regenerate_forward_backward_lowk_pairs.py` | added by v3 result-spine enforcement |
| control_or_hardening | `metric_stage_7C_scripts/Stage-7C_textual_evidence_triage_v1d.py` | added by v3 result-spine enforcement |

### R09_stage7D_gr_appendix_lambda_acceleration: Stage-7D GR-adjacent appendix: Friedmann, Lambda, dark energy, acceleration

Question: How are Friedmann-style density/curvature/time substitutions, Lambda/dark-energy proximity, and acceleration proxies preserved as appendix-only bookkeeping?

Recommended folder: `scripts/appendix_gr_adjacent/stage7D`

| Role | Script | Why included |
|---|---|---|
| appendix_gr_adjacent | `metric_stage_7D_scripts/Stage-7D_Friedmann_curvature_density_time_probe_v1.py` | selected by v2 milestone/preferred pattern for this result spine |
| appendix_gr_adjacent | `metric_stage_7D_scripts/Stage-7D_v2_friedmann_appendix_polishing.py` | selected by v2 milestone/preferred pattern for this result spine |
| appendix_gr_adjacent | `metric_stage_7D_scripts/Stage-7D_v3_dark_energy_closure_exploratory.py` | selected by v2 milestone/preferred pattern for this result spine |
| appendix_gr_adjacent | `metric_stage_7D_scripts/Stage-7D_v4_acceleration_proxy_audit.py` | selected by v2 milestone/preferred pattern for this result spine |
| appendix_gr_adjacent | `metric_stage_7C_scripts/Stage-7C-v1o_unknown_survivor_friedmann_transition.py` | added by v3 result-spine enforcement |

### R10_repository_reproducibility_compression: Repository compression and reproducibility manifests

Question: Which Stage-7E scripts produce the inventory, crosswalk, result-spine audit, README skeleton, and GitHub/Zenodo manifests?

Recommended folder: `scripts/reproducibility`

| Role | Script | Why included |
|---|---|---|
| reproducibility | `metric_stage_7E_scripts/Stage-7E-v1_project_inventory_ledger_crosswalk.py` | selected by v2 milestone/preferred pattern for this result spine |

## Non-claim guardrail

The result-spine bundle supports a reproducible, family-preserving emergent nonlocal operator geometry with a stable two-sector law.

It does not claim that QEG derives quantum gravity, GR, Friedmann equations, LambdaCDM, dark energy, cosmic time, cosmic acceleration, or the age of the Universe.
